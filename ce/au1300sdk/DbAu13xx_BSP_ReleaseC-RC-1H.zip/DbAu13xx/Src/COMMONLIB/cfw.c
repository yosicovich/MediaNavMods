/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include <windows.h>
#include "au1x_common.h"

/* Value must avoid those already defined in COMMON\OAK\INC\pkfuncs.h */
#ifndef CACHE_SYNC_INVALIDATE_D
#define CACHE_SYNC_INVALIDATE_D 0x800
#endif

/*
OEMCacheRangeFlush()

  Single OAL entry point for all cache flush operations.

    Parameters:

      pAddr	 - starting VA on which the cache operation is to be performed
      dwLength - length of flush
      dwFlags  - specifies the cache operation to be performed:

        CACHE_SYNC_WRITEBACK: write back DATA cache
        CACHE_SYNC_DISCARD: write back and discard DATA cache
        CACHE_SYNC_INSTRUCTIONS: discard I-Cache
        CACHE_SYNC_FLUSH_I_TLB: flush instruction TLB
        CACHE_SYNC_FLUSH_D_TLB: flush data TLB
        CACHE_SYNC_FLUSH_TLB: flush both I/D TLB
        CACHE_SYNC_L2_WRITEBACK: write back L2 cache
        CACHE_SYNC_L2_DISCARD: write back and discard L2 cache
        CACHE_SYNC_ALL: perform all the above operations.

		Alchemy Specific:
		CACHE_SYNC_INVALIDATE_D: invalidate (without writeback) DATA cache

    Return Value

        None.

    Remarks

        If both pAddr and dwLength are 0, the entire cache (or TLB, as directed by dwFlags) will be flushed.
        Only the kernel can set the TLB flush flags when it calls this routine, and when a TLB flush is performed
        with dwLength == PAGE_SIZE, pAddr is guaranteed to be on a page boundary.

        This routine is not called by the kernel until after KernelRelocate() has been invoked, at which
        point global read/write data is available.  If an OEM needs to flush cache or TLB entries during
        early boot phases, they will need to implement a platform-specific API to do so.

        NOTE:  This routine could be optimized for a particular platform by using #define or const data
        to describe the size of the cache(s) or TLB.  This implementation allows dynamic cache sizing
        in order to keep porting simple.

*/
void OEMCacheRangeFlush(LPVOID pAddr, DWORD dwLength, DWORD dwFlags)
{
#define MMU_PAGE_SIZE (4 * 1024)     // bytes
#define OEMICacheLineSize 32
#define OEMDCacheLineSize 32


    // global variables defined in the platform
    extern const DWORD OEMTLBSize;          // number of entries in the TLB, minus 1

    if (dwFlags & CACHE_SYNC_DISCARD)
    {
        // write back and invalidate the selected portions of the data cache
        if(dwLength == 0) {
            if(pAddr == 0) {
                // yes, invalidate it also
                FlushDCache();
            }
        } else if(dwLength > MMU_PAGE_SIZE) {
                // too much work, invalidate the whole cache
                FlushDCache();
        } else {
            // normalize address to cache line alignment and adjust the length accordingly
            DWORD dwNormalizedAddress = (DWORD) pAddr & ~(OEMDCacheLineSize - 1);
            DWORD dwNormalizedLength = dwLength + ((DWORD) pAddr - dwNormalizedAddress);

            // flush all the indicated cache entries
            FlushDCacheLines((LPVOID) dwNormalizedAddress, dwNormalizedLength);
        }
    }
    else if (dwFlags & CACHE_SYNC_WRITEBACK) {
        // write back the address range -- is it the whole cache?
        if(dwLength == 0) {
            if(pAddr == 0) {
                // yes, write back the whole cache -- MIPS doesn't support index write back so we have
                // to invalidate also.
                FlushDCache();
            }
        } else if(dwLength > MMU_PAGE_SIZE) {
                // too much work, write back (and invalidate) the whole cache
                FlushDCache();
        } else {
            // normalize address to cache line alignment and adjust the length accordingly
            DWORD dwNormalizedAddress = (DWORD) pAddr & ~(OEMDCacheLineSize - 1);
            DWORD dwNormalizedLength = dwLength + ((DWORD) pAddr - dwNormalizedAddress);

            // write back all the indicated cache entries
            CleanDCacheLines((LPVOID) dwNormalizedAddress, dwNormalizedLength);
        }
    }
	else if (dwFlags & CACHE_SYNC_INVALIDATE_D)
	{
		InvalidateDCacheLines(pAddr, dwLength);
	}

    if (dwFlags & CACHE_SYNC_INSTRUCTIONS)
    {
        if(dwLength == 0) {
            if(pAddr == 0) {
                // flush the whole cache
                FlushICache();
            }
        } else if(dwLength > MMU_PAGE_SIZE) {
                // too much work, invalidate the whole cache
                FlushICache();
        } else {
            // normalize address to cache line alignment and adjust the length accordingly
            DWORD dwNormalizedAddress = (DWORD) pAddr & ~(OEMICacheLineSize - 1);
            DWORD dwNormalizedLength = dwLength + ((DWORD) pAddr - dwNormalizedAddress);

            // write back all the indicated cache entries
            FlushICacheLines((LPVOID) dwNormalizedAddress, dwNormalizedLength);
        }
    }

    // We assume a unified instruction/data TLB.  Although MIPS supports probing for individual
    // TLB entries, probing is not efficient because of the way Windows CE handles migrating threads
    // between processes.  Probing requires the address space ID and the virtual address to match,
    // and the CE model allows a VA to appear with multiple ASIDs.  This means we would have to probe
    // all valid ASIDs for a particular VA, so it more efficient to simply clear the whole TLB.
    if (dwFlags & CACHE_SYNC_FLUSH_TLB)
    {
        // flush the whole TLB
        MipsClearTLB(OEMTLBSize);
    }
}


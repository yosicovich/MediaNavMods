/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include <windows.h>
#include <platform.h>
#include <bsp.h>

static AU1X00_SYS * const Sys = (AU1X00_SYS *)(SYS_PHYS_ADDR+KSEG1_OFFSET);

/********************************************************************/

/*
 * Returns the core speed in Hz
 */
ULONG
OEMGetCpuFrequency(VOID)
{
	ULONG freq;

#ifdef CPU_AU1000
#ifndef DEFAULT_CPU_FREQUENCY
#define DEFAULT_CPU_FREQUENCY 396000000
#endif
	// On early Au1000, sys_cpupll did not return correct value
	if ((Cp0RdPRId() == 0x00030100) || // Au1000 DA
		(Cp0RdPRId() == 0x00030101) || // Au1000 HA
		(Cp0RdPRId() == 0x00030102))   // Au1000 HB
		freq = DEFAULT_CPU_FREQUENCY;
	else
#endif
	freq = (Sys->cpupll & SYS_CPUPLL_PLL) * XTAL_FREQ; //12000000;
	return freq;
}

/********************************************************************/

/*
 * Returns the aux PLL speed in Hz
 */

ULONG
OEMGetAuxFrequency(VOID)
{
	return (Sys->auxpll & SYS_CPUPLL_PLL) * XTAL_FREQ; //12000000;
}

/********************************************************************/

/*
 * Returns the SBUS speed in Hz
 */
ULONG
OEMGetSBUSFrequency(VOID)
{
    ULONG SD;

    SD = Sys->powerctrl;
    SD &= SYS_POWERCTRL_SD;
    SD += 2;

    return (OEMGetCpuFrequency() / SD);
}

/********************************************************************/

/*
 * Returns the PBUS speed in Hz
 */
ULONG
OEMGetPBUSFrequency(VOID)
{
    return (OEMGetSBUSFrequency() / 2);
}

/********************************************************************/

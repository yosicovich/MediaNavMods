External Module				Module Location within SVN
----------------			--------------------------
KITLLIB						WindowsCE\6.0\Au1x\Src\KITLLIB


Local Modules				Description
----------------			--------------------------
KITLDLL						Contains BSP specific KITL

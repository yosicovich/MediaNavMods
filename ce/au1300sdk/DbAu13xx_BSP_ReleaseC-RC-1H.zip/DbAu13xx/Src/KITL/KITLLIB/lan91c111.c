/*++
Copyright (c) 2004 BSQUARE Corporation. All rights reserved.

Module Name:
    lan91c111.c

Abstract:
	Ethernet KITL routines the SMSC LAN91C111 as used on the
	Pb1200 board.

Author:
	Ian Rae 13-Dec-2004

--*/

#include <windows.h>
#include <halether.h>
#include "platform.h"
#include "bceddk.h"
#include "oal.h"
#include "lan91c111.h"
#include "macaddr.h"

// Stop the linker complaining about empty libraries
int lan91c111 = 0;

// This must be defined in the board header file (eg pb1200.h) if
// a LAN91C111 is to be used.
#ifdef LAN91C111_PHYS_ADDR

static LAN91C111 *pNicRegs = (LAN91C111*)(LAN91C111_PHYS_ADDR+KSEG1_OFFSET);

static void PhyWrite(UCHAR Reg,USHORT Data);
static USHORT PhyRead(UCHAR Reg);
static UCHAR  TxAllocationResult = 0xff;

#define BANK_SELECT(n) pNicRegs->BANK = (n)

#define BASE_PACKET_FILTER (RFS_ALIGN_ERR | RFS_BAD_CRC | RFS_TOO_LONG | RFS_TOO_SHORT)

static ULONG PacketFilter = BASE_PACKET_FILTER;


static BOOL GetMacAddress(USHORT wMAC[3])
{
    MACADDR_IN_FLASH *pMif;

    pMif = (MACADDR_IN_FLASH*)(KSEG1_OFFSET + MAC_ADDR_BASE);

    wMAC[0] = pMif->u.AsShort.Mac0[0];
    wMAC[1] = pMif->u.AsShort.Mac0[1];
    wMAC[2] = pMif->u.AsShort.Mac0[2];

    return TRUE;
}

static VOID DumpFrame(PUCHAR Address, ULONG Len)
{
    unsigned long  i, j, k;
    unsigned long Addr;

    Addr = (ULONG)Address;
    k=0;

    KITLOutputDebugString("\r\nPacket base:%X, Size %d", Address, Len);

   	for (i=0;i<Len;i+=16) {
        KITLOutputDebugString("\r\n%H:", k);
        for (j=Addr;j < (Addr + 16) ;j++) {
            if (j < (Len + (ULONG)Address)) {
                KITLOutputDebugString("%B ", *(PUCHAR)(j));
                k++;
            }
        }

        Addr +=16;
    }
    KITLOutputDebugString("\r\n");

}


/* Lan91c111_Init
 *
 *   Initialize ethernet for downloading image.
 *
 * Parameters:
 *
 *   pAdapter - IN - Adapter object to initialize
 *
 * Return Value:
 *    Return TRUE if init successful, FALSE if not.
 */
BOOL Lan91c111_Init(UINT8 *pAddress, UINT32 offset, UINT16 mac[3])
{
	BOOL Status = TRUE;
    UCHAR *TmpMac;
	int i = 0;
	USHORT tmp = 0;
	USHORT *pTmp = NULL;
//	ULONG intr;

	KITLOutputDebugString("Lan91c111_Init: +OEMEthInit\r\n");

	// Reset NIC
	BANK_SELECT(0);
	pNicRegs->Bank0.RCR = RCR_SOFT_RST;
	OALStall(50000);
	pNicRegs->Bank0.RCR = 0;
	OALStall(50000);

    TmpMac = (UCHAR*)mac;
	GetMacAddress((USHORT*)TmpMac);


    KITLOutputDebugString("Lan91c111_Init: MAC Addr");
    for (i=0;i<6;i++) {
        KITLOutputDebugString(":%B",TmpMac[i]);
    }
    KITLOutputDebugString("\r\n");

	// Write MAC Address to chip
	BANK_SELECT(1);
	for (i=0;i<6;i++) {
		pNicRegs->Bank1.IAR[i] = TmpMac[i];
	}

	// Configure Configuration Register
	BANK_SELECT(1);
	pNicRegs->Bank1.CR = CR_EPH_POWER_EN | CR_NO_WAIT;

	// Configure Control Register
	BANK_SELECT(1);
	pNicRegs->Bank1.CTR = (/*CTR_AUTO_RELEASE | */CTR_TE_ENABLE);

	// Disable all interrupts
	BANK_SELECT(2);
	pNicRegs->Bank2.MSK = 0;

	KITLOutputDebugString("Lan91c111_Init: Starting Auto Negotiation");
	// Reset internal PHY
	PhyWrite(PHY_CONTROL_REG,PHY_CONTROL_RST);

	// Wait 50ms per spec
	OALStall(50000);

	while (PhyRead(PHY_CONTROL_REG) & PHY_CONTROL_RST) {
		;
	}

	// Configure PHY control
	BANK_SELECT(0);
	pNicRegs->Bank0.RPCR = RPCR_ANEG;

	PhyWrite(PHY_CONTROL_REG,PHY_CONTROL_ANEG_EN);

	// Configure and enable TX
	BANK_SELECT(0);
	pNicRegs->Bank0.TCR = (TCR_SWFDUP | TCR_PAD_EN | TCR_TXENA);

	// Configure and enable RX
	BANK_SELECT(0);
	pNicRegs->Bank0.RCR = RCR_RXEN;

	TxAllocationResult = 0xff;

	KITLOutputDebugString("Lan91c111_Init: -OEMEthInit\r\n");

    KITLOutputDebugString ("Sharing Ethernet using VMINI...\n");
	VBridgeInit();
	VBridgeKSetLocalMacAddress((char*)mac);

	return Status;
}


static void Lan91c111_Ints(BOOL bEnable)
{
	BANK_SELECT(2);
	if (bEnable) {
		pNicRegs->Bank2.MSK = INT_RCV | INT_RX_OVRN;
	} else {
		pNicRegs->Bank2.MSK = 0;
	}
}

void Lan91c111_EnableInts(VOID)
{
	Lan91c111_Ints(TRUE);
}

void Lan91c111_DisableInts(VOID)
{
	Lan91c111_Ints(FALSE);
}


// Bytes are reversed when reading 16bits from data
// Writes seem to be OK though ???
USHORT GetData16()
{
	register USHORT tmp = pNicRegs->Bank2.DATA16[0];
	return ntohs(tmp);
}

/* GetFrame
 *
 *   Check to see if a frame has been received, and if so copy to buffer. An optimization
 *   which may be performed in the Ethernet driver is to filter out all received broadcast
 *   packets except for ARPs.
 *
 * Parameters:
 *
 *   pData    - OUT - Receives frame data
 *   pwLength - IN  - Length of Rx buffer
 *            - OUT - Number of bytes received
 *
 * Return Value:
 *   Length of packet
 */
UINT16 Lan91c111_GetFrame( BYTE *pData, UINT16 *pwLength)

{
	USHORT statusWord, length=0;
	USHORT i;
	USHORT *pData16 = (USHORT*)pData;
	USHORT tmp;
	UCHAR ints;
	UINT16 Status=0;

	// Everything for Rx is in bank 2
	BANK_SELECT(2);

	while(pNicRegs->Bank2.MMUCR & MMUCR_BUSY) {
		;
	}

	// Read interrupts
	ints = pNicRegs->Bank2.IST;

	if (ints & INT_RX_OVRN) {
		pNicRegs->Bank2.ACK = INT_RX_OVRN;
//		KITLOutputDebugString("Lan91c111_GetFrame: RX Overrun\r\n");
		goto ErrorReturn;
	}

	if (!(ints & INT_RCV)) {
		// nothing to do
//		KITLOutputDebugString("Lan91c111_GetFrame: Nothing\r\n");
		*pwLength = 0;
		goto ErrorReturn;
	}

	// Setup pointer register
	pNicRegs->Bank2.PTR = PTR_RCV | PTR_READ | PTR_AUTO_INCR;

	// Get the status word
	statusWord = GetData16();

	// Filter out any frames we don't want here including frames with errors
	// Use the VMINI packetFilter settings
	if (statusWord & PacketFilter) {
		*pwLength = 0;
		goto FreeBuffer;
	}

	// read length and subtract 6 for status,byte count,control
	length = (GetData16() & 0x7FF) - 6;

	if (length > *pwLength) {
		KITLOutputDebugString("Lan91c111_GetFrame: Packet too large\r\n");
		goto FreeBuffer;
	}

	// Get the data
	for (i=0;i<length/2;i++) {
		*pData16++ = GetData16();
	}

	// Get final byte odd byte if present
	tmp = GetData16();
	if (tmp & 0x2000) {
		*(PUCHAR)pData16 = (UCHAR)tmp;
		length++;
	}

	// subtract 4 to account for CRC
	*pwLength = length-4;

//	DumpFrame(pData,length);

FreeBuffer:
	// Release buffer memory
	pNicRegs->Bank2.MMUCR = MMUCR_CMD_REMOVE_AND_RELEASE_RX_FRAME;

	// We wait for busy at the start of the next call to this routine...
ErrorReturn:


//	KITLOutputDebugString("-Lan91c111_GetFrame %d\r\n",*pwLength);
	return (*pwLength);
}

/* OEMEthSendFrame
 *
 *   Send Ethernet frame.
 *
 * Parameters:
 *
 *   pData    - IN - Data buffer
 *   dwLength - IN - Length of buffer
 *
 *  Return Value:
 *   Length
 */
UINT16 Lan91c111_SendFrame(BYTE *pData, UINT32 dwLength)
{
	UINT16  Status = 0;
	USHORT  bufferSize;
	PUSHORT pData16 = (PUSHORT)pData;
	ULONG   i;
	USHORT  tmp;
	int     timeout;

//	KITLOutputDebugString("Lan91c111_SendFrame: Send %d\r\n",dwLength);
//	DumpFrame(pData,dwLength);

	// Clear interrupt conditions
	BANK_SELECT(2);
	pNicRegs->Bank2.ACK = INT_TX_EMPTY | INT_TX;


	// Calculate buffer size, round up to even number
	bufferSize = (USHORT)(dwLength + 5);
    if (bufferSize & 1) bufferSize++;

	if (TxAllocationResult==0xFF) {
		// Allocate memory buffer
		pNicRegs->Bank2.MMUCR = MMUCR_CMD_ALLOC_TX_MEM;

		// Wait for allocation
		timeout = 10000;
		while(timeout && !(pNicRegs->Bank2.IST & INT_ALLOC)) {
			timeout--;
			OALStall(100);
		}
		if (!timeout) {
			Status = 1;
			KITLOutputDebugString("Lan91c111_SendFrame: Timeout allocating Tx buffer\r\n");
			goto ErrorReturn;
		}


		// Get allocation result
		TxAllocationResult = pNicRegs->Bank2.ARR;

		if (TxAllocationResult & AAR_FAILED) {
			Status = 1;
			KITLOutputDebugString("Lan91c111_SendFrame: Failed to allocate Tx buffer\r\n");
			goto ErrorReturn;
		}
	}

//	KITLOutputDebugString("Allocation Result (%X) = %B\r\n",&pNicRegs->Bank2.ARR,TxAllocationResult);

	// Write allocation result to Packet Num register (PNR)
	pNicRegs->Bank2.PNR = TxAllocationResult;
	// Set pointer to auto-increment
	pNicRegs->Bank2.PTR = PTR_AUTO_INCR;

    // Write the status word
	pNicRegs->Bank2.DATA16[0] = 0;
    // Write the buffer size
    pNicRegs->Bank2.DATA16[0] = bufferSize;

	// Copy data over
	for (i=0;i<dwLength/2;i++) {
		pNicRegs->Bank2.DATA16[0] = *pData16++;
	}

	// Copy over remaining byte. if any
	pData = (PUCHAR)pData16;
	if (dwLength&0x1) {
		pNicRegs->Bank2.DATA16[0] = TC_ODD_FRAME | *pData;
	} else {
		pNicRegs->Bank2.DATA16[0] = 0x0000;
	}

	// Enqueue packet into TX FIFO
	pNicRegs->Bank2.MMUCR = MMUCR_CMD_ENQUEUE_TX_PACKET;

	// Wait for success or error
	timeout = 10000;
	while(timeout && 0==(pNicRegs->Bank2.IST & (INT_TX_EMPTY|INT_TX))) {
		timeout--;
		OALStall(100);
	}
	if (!timeout) {
		KITLOutputDebugString("Lan91c111_SendFrame: Timeout during transmit\r\n");
	}

	// TX_INT indicates errors ?
	if (!timeout || pNicRegs->Bank2.IST & INT_TX) {
		BANK_SELECT(0);
		tmp = pNicRegs->Bank0.EPHSR;

		// Transmitting a multicast or broadcast packet
		// shouldn't be considered an error...
		tmp &= (EPHSR_TXUNRN|EPHSR_LOST_CARR|EPHSR_LATCOL|EPHSR_16COL);
		//tmp &= ~(EPHSR_TX_SUC|EPHSR_SQET|EPHSR_LTX_MULT|EPHSR_LTX_BRD);

		if (!timeout || tmp) {
			KITLOutputDebugString("TX ERROR\r\n");

			KITLOutputDebugString("EPHSR = %H\r\n",tmp);

			tmp = PhyRead(1);
			KITLOutputDebugString("PHY Status= %H\r\n",tmp);

			// Clear stats registers
			BANK_SELECT(0);
			tmp = pNicRegs->Bank0.ECR;

			EdbgOutputDebugString("ECR = %H\r\n",tmp);

			// Reenable TXENA
			pNicRegs->Bank0.TCR = (TCR_SWFDUP | TCR_PAD_EN | TCR_TXENA);

			Status = 1;
		}
	}

	// Clear interrupts
	BANK_SELECT(2);
	pNicRegs->Bank2.ACK = INT_TX_EMPTY | INT_TX;

ErrorReturn:

//	KITLOutputDebugString("-Lan91c111_SendFrame\r\n");

	return Status;
}




void Lan91c111_ApplyPacketFilter(UINT32 dwFilter)
{
	PacketFilter = BASE_PACKET_FILTER;

	KITLOutputDebugString("+Lan91c111_ApplyPacketFilter\r\n");

	BANK_SELECT(0);

	if (dwFilter & PACKET_TYPE_MULTICAST) {
		KITLOutputDebugString("ApplyFilter: MULTICAST ON\r\n");
	} else {
		KITLOutputDebugString("ApplyFilter: MULTICAST OFF\r\n");
		PacketFilter |= RFS_MULTICAST;
	}

    if (dwFilter & PACKET_TYPE_BROADCAST) {
		KITLOutputDebugString("ApplyFilter: BROADCAST ON\r\n");
	} else {
		KITLOutputDebugString("ApplyFilter: BROADCAST OFF\r\n");
		PacketFilter |= RFS_BROADCAST;
    }

    if (dwFilter & PACKET_TYPE_PROMISCUOUS) {
		KITLOutputDebugString("ApplyFilter: PROMISCUOUS ON\r\n");
		pNicRegs->Bank0.RCR |= RCR_PRMS;
	} else {
		KITLOutputDebugString("ApplyFilter: PROMISCUOUS OFF\r\n");
		pNicRegs->Bank0.RCR &= ~RCR_PRMS;
    }

    if (dwFilter & PACKET_TYPE_ALL_MULTICAST) {
		KITLOutputDebugString("ApplyFilter: ALL_MULTICAST ON\r\n");
		pNicRegs->Bank0.RCR |= RCR_ALMUL;
	} else {
		KITLOutputDebugString("ApplyFilter: ALL_MULTICAST OFF\r\n");
		pNicRegs->Bank0.RCR &= ~RCR_ALMUL;
    }
	KITLOutputDebugString("-Lan91c111_ApplyPacketFilter\r\n");

}

//
// Constant for the CRC32 routine
//
#define CRC32_POLY              0xEDB88320

static ULONG CRC32(PUCHAR s, UCHAR Length)
{
    UCHAR   ByteNumber;
    UCHAR   BitNumber;
    ULONG   CRCValue = 0xffffffff;
    UCHAR   CTemp;

	for( ByteNumber = 0; ByteNumber < Length; ByteNumber++ ) {
		for( CTemp = *s++, BitNumber = 0; BitNumber < 8; BitNumber++, CTemp >>= 1 ) {
            CRCValue = (CRCValue >> 1) ^ (((CRCValue ^ CTemp) & 1) ? CRC32_POLY : 0);
        }
    }
    return (CRCValue & 0x3f);
}

BOOL Lan91c111_ApplyMulticastList(UINT8 *pucMulticastAddresses, UINT32 dwNoOfAddresses)
{
    ULONG i;
    ULONG Crc;
    ULONG Reg;
    ULONG BitNum;

	KITLOutputDebugString("+Lan91c111_ApplyMulticastList %x %d\r\n",pucMulticastAddresses,dwNoOfAddresses);

	BANK_SELECT(3);

	// Clear old table
	for (i=0;i<8;i++) {
		pNicRegs->Bank3.MT[i] = 0;
	}

    for (i=0;i<dwNoOfAddresses;i++,pucMulticastAddresses+=6) {
        Crc = CRC32((PUCHAR)pucMulticastAddresses, 6);

		// From the datasheet:
		// The 64bit multicast table is used for group address filtering.
		// The hash value is defined as the six most significant bits of
		// the CRC of the destination address. The three MSBs determine the
		// register to be used (MT0-MT7), while the other three bits determine
		// the bit within the register (to be set).
		Reg = (Crc >> 29) & 0x7;
		BitNum = (Crc >> 26) & 0x7;
		pNicRegs->Bank3.MT[Reg] |= (1<<BitNum);
    }
	KITLOutputDebugString("-Lan91c111_ApplyMulticastList\r\n");

	return TRUE;
}


//
// PHY/MII access routines
//

// Write a "1" bit out to the PHY
__inline static void WRITE_PHY_ZERO() {
	pNicRegs->Bank3.MGMT = MGMT_MDOE;
	pNicRegs->Bank3.MGMT = MGMT_MDOE | MGMT_MCLK;
	pNicRegs->Bank3.MGMT = MGMT_MDOE;
}

// Write a "0" bit out to the PHY
__inline static void WRITE_PHY_ONE() {
	pNicRegs->Bank3.MGMT = MGMT_MDOE | MGMT_MDO;
	pNicRegs->Bank3.MGMT = MGMT_MDOE | MGMT_MCLK | MGMT_MDO;
	pNicRegs->Bank3.MGMT = MGMT_MDOE | MGMT_MDO;
}

// Write a "Z" high-impedance bit out to the PHY
__inline static void WRITE_PHY_Z() {
	pNicRegs->Bank3.MGMT = 0;
	pNicRegs->Bank3.MGMT = MGMT_MCLK;
	pNicRegs->Bank3.MGMT = 0;
}

// Write to a PHY Reg
static void PhyWrite(UCHAR Reg,USHORT Data)
{
	int i;

	BANK_SELECT(3);

	// Write 32 1s to sync
	for (i=0;i<32;i++) {
		WRITE_PHY_ONE();
	}

	// Start Bits <01>
	WRITE_PHY_ZERO();
	WRITE_PHY_ONE();

	// Write Command Bits <01>
	WRITE_PHY_ZERO();
	WRITE_PHY_ONE();

	// PHY Address, 00000 for interal PHY
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();

	// PHY Reg, 5 bits, MSB first
	for (i=0;i<5;i++) {
		if (Reg & 0x10) {
			WRITE_PHY_ONE();
		} else {
			WRITE_PHY_ZERO();
		}
		Reg <<= 1;
	}

	// Send turnaround bit <10>
	WRITE_PHY_ONE();
	WRITE_PHY_ZERO();

	// Send the data, 16bit, MSB first
	for (i=0;i<16;i++) {
		if (Data & 0x8000) {
			WRITE_PHY_ONE();
		} else {
			WRITE_PHY_ZERO();
		}
		Data <<= 1;
	}

	pNicRegs->Bank3.MGMT = 0;
}

// Read from a PHY Reg
static USHORT PhyRead(UCHAR Reg)
{
	int i;
	USHORT Data = 0;

	BANK_SELECT(3);

	// Write 32 1s to sync
	for (i=0;i<32;i++) {
		WRITE_PHY_ONE();
	}

	// Start Bits <01>
	WRITE_PHY_ZERO();
	WRITE_PHY_ONE();

	// Read Command Bits <10>
	WRITE_PHY_ONE();
	WRITE_PHY_ZERO();

	// PHY Address, 00000 for interal PHY
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();

	// PHY Reg, 5 bits, MSB first
	for (i=0;i<5;i++) {
		if (Reg & 0x10) {
			WRITE_PHY_ONE();
		} else {
			WRITE_PHY_ZERO();
		}
		Reg <<= 1;
	}

	// Send turnaround bit <Z>
	WRITE_PHY_Z();

	// Read the data, 16bit, MSB first
	for (i=0;i<16;i++) {
		Data <<= 1;

		pNicRegs->Bank3.MGMT = 0;
		pNicRegs->Bank3.MGMT = MGMT_MCLK;

		if (pNicRegs->Bank3.MGMT & MGMT_MDI) {
			Data |= 1;
		}

		pNicRegs->Bank3.MGMT = 0;
	}

	// Send turnaround bit <Z>
	WRITE_PHY_Z();

	return Data;
}


#endif //LAN91C111_PHYS_ADDR
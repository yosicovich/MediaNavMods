/*
    Copyright (c) 2001-2004 BSQUARE Corporation.  All rights reserved.

    halkitl.c

    Curently ethernet or serial transport are assumed.


*/


#include <windows.h>
#include <nkintr.h>
#include <halether.h>
#include <kitlprot.h>
#include "platform.h"
#include "bceddk.h"
#include "ldrarg.h"
#include "macaddr.h"
#include "flash.h"
#include "bsp.h"

#include "kitl_cfg.h"


static BOOT_ARGS *pBootArgs = (BOOT_ARGS *)(BOOT_ARG_PTR+KSEG0_OFFSET);
AU1X00_SYS * const Sys = (AU1X00_SYS *)(SYS_PHYS_ADDR+KSEG1_OFFSET);

//------------------------------------------------------------------------------


BOOL OEMKitlStartup()
{
    BOOL Status = FALSE;
    OAL_KITL_ARGS *pArgs, args;
    CHAR *szDeviceId=EBOOT_NAME"_";

    KITLOutputDebugString ("+OALKitlStart\r\n");

	/* Set the default Kitl debug flags */
	KITLSetDebug( ZONE_ERROR | ZONE_WARNING | ZONE_INIT );

    memset(&args, 0, sizeof(args));
    args.flags 				= OAL_KITL_FLAGS_ENABLED|OAL_KITL_FLAGS_VMINI; //|OAL_KITL_FLAGS_POLL;
    args.ipAddress 			= pBootArgs->EdbgAddr.dwIP;
    args.devLoc.IfcType 	= Internal;
    args.devLoc.LogicalLoc  = ETHERNET_PHYS_ADDR;
	args.devLoc.PhysicalLoc = (PVOID)(KSEG1_OFFSET + ETHERNET_PHYS_ADDR);
#if defined(ETHERNET_IS_DAUGHTERCARD)
	args.devLoc.Pin 		= HWINTR_EXT_DC;
#else
	args.devLoc.Pin 		= HWINTR_EXT_ETH;
#endif
    pArgs 					= &args;

    pArgs->flags |= OAL_KITL_FLAGS_EXTNAME;


    // Finally call KITL library
    Status = OALKitlInit(szDeviceId, pArgs, g_kitlDevices);
    KITLOutputDebugString ("-OALKitlStart\r\n");
	return Status;
}



VOID OALStall(UINT32 StallTimeUs)
{
	/*
	 * Causes a busy wait for the specified number of microseconds.
     *
	 * MHZx10^6 * 100x10^-9 = MH.Z --> MHZ/1000000
	 */
	UINT32 Us;
	UINT32 currCount, expireCount;
	UINT32 freq;
	freq = (Sys->cpupll & SYS_CPUPLL_PLL) * XTAL_FREQ; //12000000;


	// snapshot now so computations consumes a bit of this stall
	currCount = Cp0RdCount();

	Us = (freq / 1000000) + 1; // round up

	expireCount = currCount + (Us * StallTimeUs);

	if (expireCount < currCount)
	{
		// wait for wraparound to occur
		while (Cp0RdCount() > expireCount)
			;
	}

	// wait for remaining time to elapse
	while (Cp0RdCount() < expireCount)
		;


}
UINT32 OALGetTickCount()
{
	return *(PULONG)AddrCurMSec;
}


ULONG CreateDeviceName(USHORT wMAC[3], PUCHAR Name)
{
    CHAR DevNumBuf[8];

    if ((strlen(Name) + 4) < KITL_MAX_DEV_NAMELEN-1) {
        strcat(Name, _itoa(ntohs(wMAC[2]),DevNumBuf,10));
    }
    if ((strlen(Name) + 4) < KITL_MAX_DEV_NAMELEN-1) {
        strcat(Name, _itoa(ntohs(wMAC[1]),DevNumBuf,10));
    }
    if ((strlen(Name) + 4) < KITL_MAX_DEV_NAMELEN-1) {
        strcat(Name, _itoa(ntohs(wMAC[0]),DevNumBuf,10));
    }

    return strlen(Name);
}

BOOL
OEMEthQueryClientInfo(
	IN  UCHAR		Service,
	OUT EDBG_ADDR	*pPeerAddr,
	OUT PUCHAR		pWindowSize,
	OUT PUCHAR		*ppBufferPool )
{
	// We use the default window size (8) for all services.
	*pWindowSize = EDBG_WINDOW_SIZE;


	// Assign buffer to the service.
	switch (Service)
	{

		case EDBG_SVC_DBGMSG:


			if (!(pBootArgs->ucEshellFlags & KITL_FL_DBGMSG))
			{
				KITLOutputDebugString("Debug messages not using Ethernet.\r\n");
				return FALSE;
			}

			*pPeerAddr	= pBootArgs->DbgHostAddr;
			*ppBufferPool = (UCHAR *)KITL_MEMORY_START;

			KITLOutputDebugString("DBGMSG Addr %x \r\n",*pPeerAddr);
			KITLOutputDebugString("Buffer Pool  %x \r\n",*ppBufferPool);
			break;


		case EDBG_SVC_PPSH:

			if (!(pBootArgs->ucEshellFlags & KITL_FL_PPSH))
			{
				KITLOutputDebugString("CESH not using KITL.\r\n");
				return FALSE;
			}


			*pPeerAddr	= pBootArgs->CeshHostAddr;
			*ppBufferPool = (UCHAR *)(KITL_MEMORY_START + EDBG_DFLT_BUFFER_POOL_SIZE);

			break;


		case EDBG_SVC_KDBG:

			if (!(pBootArgs->ucEshellFlags & KITL_FL_KDBG))
			{
				KITLOutputDebugString("Kernel debugger not using Ethernet.\r\n");
				return FALSE;
			}

			*pPeerAddr	= pBootArgs->KdbgHostAddr;
			*ppBufferPool = (UCHAR *)(KITL_MEMORY_START + 2*EDBG_DFLT_BUFFER_POOL_SIZE);


			break;

		default:

			return FALSE;
	}

	return TRUE;
}


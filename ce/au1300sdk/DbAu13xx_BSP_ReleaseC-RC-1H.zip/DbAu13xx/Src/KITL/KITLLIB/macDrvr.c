/*++
Copyright (c) 2001-2004  BSQUARE Corporation.  All rights reserved.

Module Name:

    auether.c

Module Description:

    This file contains the implementation  of routines for initializing AuMacLayer ethernet adapter and
	routines for sending and getting ethernet frames 
    			

Author:

    Anil Hashia 1-June-2001

Revision History:
    GJS             June 2001       Change reference from Am79xx to AuMacLayer			

--*/



#include <windows.h>
#include <ldrarg.h>

#include "platform.h"
#include "bceddk.h"
#include "oal.h"

#ifdef MAC0_PHYS_ADDR

#define MACDMA_RXSTAT_ERRORS    (MACDMA_RXSTAT_LE | \
                                 MACDMA_RXSTAT_CR | \
                                 MACDMA_RXSTAT_DB | \
                                 MACDMA_RXSTAT_MI | \
                                 MACDMA_RXSTAT_CS | \
                                 MACDMA_RXSTAT_FL | \
                                 MACDMA_RXSTAT_RF | \
                                 MACDMA_RXSTAT_WT)


// Ethernet adapter registers
static PULONG NicEnableReg = (PULONG) (MACEN_PHYS_ADDR + KSEG1_OFFSET);
static AU1X00_MAC *NicMacRegs;
static AU1X00_MACDMA *NicDmaRegs;

static BOOT_ARGS *pBootArgs = (BOOT_ARGS *)(BOOT_ARG_PTR+KSEG0_OFFSET);


// Modify these atomically!
static ULONG NextTxBuffer;
static ULONG LastTxBuffer;
static ULONG NextRxBuffer;


// VMINI Stuff
#ifdef IMGSHAREETH
extern BOOL    bNewFilter;        //  User mode --> Kernel mode to set new filter.
extern DWORD   dwFilter;          //  The filter..

extern BOOL    bNewMulticast;     //  User mode --> Kernel mode for new list
extern DWORD   dwNoOfEntry;
extern UCHAR   ucMultiAddr[8][6]; //  The new list.. VMINI assumes 8 multicast list entry..
void ProcessVMiniSend(void);
#endif


void MacLayerEnableInts(BOOL bEnable)
{
    ULONG Shift = pBootArgs->NICBase + HWINTR_MAC0DMA;
    
    if (bEnable) {
        ic0->maskset = 1 << Shift;
    } else {
        ic0->maskclr = 1 << Shift;    
    }    
}

/*

*/
static ULONG AuMacLayer_ClearTxdBuf(ULONG TxBuffer)
{
    unsigned long Status;
		
	Status = NicDmaRegs->tx[TxBuffer].txaddr;
	
	// Should check for enabled and not done first
	// (actually wait for done on the last packet)
	while ((Status & (MACDMA_TXADDR_DN | MACDMA_TXADDR_EN)) == MACDMA_TXADDR_EN) {
		Status = NicDmaRegs->tx[TxBuffer].txaddr;
	}

	while (Status & MACDMA_TXADDR_DN) {

		NicDmaRegs->tx[TxBuffer].txaddr = 0;
		NicDmaRegs->tx[TxBuffer].txstat = 0;
		NicDmaRegs->tx[TxBuffer].txlen = 0;
		TxBuffer = (TxBuffer+1) % 4;
		Status = NicDmaRegs->tx[TxBuffer].txaddr;
	}
	
	return TxBuffer;
}

/* MacLayer_SendFrame
 *
 *   Send Ethernet frame.  
 *
 *  Return Value:
 *   TRUE if frame successfully sent, FALSE otherwise.
 */
BOOL
MacLayer_SendFrame(
    BYTE *pData,     // IN - Data buffer
    DWORD Length)  // IN - Length of buffer
{
    ULONG Tmp;
	BOOL Status = FALSE;

	// Clear previously Tx'd frames
	LastTxBuffer = AuMacLayer_ClearTxdBuf(LastTxBuffer);

	if (NULL == pData) {
		// Just clean transmitted buffers	
		goto ErrorReturn;
	}

	// Is there a free slot?
    
    if (NicDmaRegs->tx[NextTxBuffer].txaddr & MACDMA_TXADDR_EN) {
		// no slot available
		// How long should it wait????? At all? 
		KITLOutputDebugString ("KITL: TxBufStats(#%D): %X %X %X %X\r\n", 
			NextTxBuffer, 
			NicDmaRegs->tx[NextTxBuffer].txaddr,
			NicDmaRegs->tx[(NextTxBuffer+1) % 4].txaddr,
			NicDmaRegs->tx[(NextTxBuffer+2) % 4].txaddr,
			NicDmaRegs->tx[(NextTxBuffer+3) % 4].txaddr);
		
		Status = FALSE;
		goto ErrorReturn;

    }
    
    // Copy the data, set min len
    memcpy((PVOID)(NIC_TX_BASE + (NextTxBuffer * NIC_PACKET_LEN)),
            pData,
            Length);
    
    if (Length < 64) {
        Length = 64;    
    }
        

    // Hit go
    NicDmaRegs->tx[NextTxBuffer].txstat = 0;
    NicDmaRegs->tx[NextTxBuffer].txlen = Length;
    Tmp = (NIC_TX_PHYSADDR_BASE + (NextTxBuffer * NIC_PACKET_LEN)) | MACDMA_TXADDR_EN;
    NicDmaRegs->tx[NextTxBuffer].txaddr = Tmp;

	NextTxBuffer = (NextTxBuffer+ 1) % 4;

#if IMGSHAREETH
	ProcessVMiniSend();
#endif

	Status = TRUE;

ErrorReturn:
    return Status;    
}


/* AuMacLayer_GetFrame
 *
 *   Check to see if a frame has been received, and if so copy to buffer
 *
 * Return Value:
 *    Return TRUE if frame has been received, FALSE if not.
 */


BOOL
AuMacLayer_GetFrame(
    BYTE *pData,       // OUT - Receives frame data
    UINT16 *pwLength)  // IN  - Length of Rx buffer
                       // OUT - Number of bytes received
{
    BOOL Status = FALSE;
    UINT16 Len;
    ULONG Tmp;
    BYTE *Src;


    Tmp = NicDmaRegs->rx[NextRxBuffer].rxaddr;
    if (Tmp & MACDMA_RXADDR_DN) {

        Tmp = NicDmaRegs->rx[NextRxBuffer].rxstat;
        
        // got one, any errors?
        if (Tmp & MACDMA_RXSTAT_ERRORS ) {
            // Error occurred - ignore packet

        } else {
            // no errors
            Len =(UINT16)(Tmp & MACDMA_RXSTAT_L)-4;
            if (Len <= *pwLength) {

                // buffer is large enough so copy
                *pwLength = Len;
                Src =  (PVOID)(NIC_RX_BASE + (NextRxBuffer * NIC_PACKET_LEN));
                
                memcpy(pData, Src, Len);
                
                // packet OK
                Status = TRUE;
            }
        }

        // reset status
        NicDmaRegs->rx[NextRxBuffer].rxstat = 0;
        
        //Re-enable the buffer
        Tmp = NIC_RX_PHYSADDR_BASE + (NextRxBuffer * NIC_PACKET_LEN) | MACDMA_RXADDR_EN;
        NicDmaRegs->rx[NextRxBuffer].rxaddr = Tmp;

        
        NextRxBuffer = (NextRxBuffer+1) % 4;
    }

#ifdef KITL_INTERRUPT_MODE
    // process TX packets to disable TX DMA interrupt
    // Clear previously Tx'd frames
    MacLayer_SendFrame(NULL, 0);
#endif
    
	return Status;    
}


BOOL
MacLayer_GetFrame(
    BYTE *pData,       // OUT - Receives frame data
    UINT16 *pwLength)  // IN  - Length of Rx buffer
                       // OUT - Number of bytes received
{

#if IMGSHAREETH
    BOOL    bStatus;
    BOOL    bTaken;
    UINT16  wOriginalLength;


    ProcessVMiniSend();
    wOriginalLength = *pwLength;
    
    while (1)
    {   

        *pwLength = wOriginalLength;

        bStatus  = AuMacLayer_GetFrame(pData, pwLength);
        
        if (bStatus)
        {
            VBridgeKIndicateOneRxBuffer(pData, *pwLength, FALSE, &bTaken);
            if (!bTaken)              
                return bStatus; 

        }
        else
            break;
    }
    return (FALSE);
#else

	return AuMacLayer_GetFrame(pData,pwLength);

#endif
}



static ULONG
MiiWrite(
    AU1X00_MAC * Mac,
    ULONG PhyAddr,
    ULONG RegNo,
    ULONG Value
    )
{
    ULONG Control;

    Control = MAC_MIICTRL_PHYADDR_N(PhyAddr) |
              MAC_MIICTRL_MIIREG_N(RegNo) |
              MAC_MIICTRL_MW;
    
    while (Mac->miictrl & MAC_MIICTRL_MB);
    Mac->miidata = Value & 0xffff;
    Mac->miictrl = Control;
    while (Mac->miictrl & MAC_MIICTRL_MB);

	return 1;
}



static ULONG
MiiRead(
    AU1X00_MAC * Mac,
    ULONG PhyAddr,
    ULONG RegNo
    )
{
    ULONG Control;
    ULONG Data;

    Control = MAC_MIICTRL_PHYADDR_N(PhyAddr) |
              MAC_MIICTRL_MIIREG_N(RegNo);

    while (Mac->miictrl & MAC_MIICTRL_MB);
    Mac->miictrl = Control;

    while (Mac->miictrl & MAC_MIICTRL_MB);
    Data = Mac->miidata;

	return Data;
}

/*++
Routine Description:
	MacLayerInit(EDBG_ADAPTER *pAdapter )
	This function initializes the debug Ethernet adapter with address and interrupt information.
	
Arguments:
	NONE
    
Return Value:


--*/

BOOL MacLayerInit(EDBG_ADAPTER *pAdapter )

{
    ULONG i;
    ULONG TmpMacAddr;
    PUCHAR pTmpMac;


	OEMWriteDebugString(L"** AuMacLayerInit()\r\n");
	
    NicEnableReg = (PULONG) (MACEN_PHYS_ADDR + KSEG1_OFFSET);


#if defined(MAC1_PHYS_ADDR)
    if (1 == pBootArgs->NICBase) {
        NicEnableReg++;
        NicMacRegs = (AU1X00_MAC *) (MAC1_PHYS_ADDR + KSEG1_OFFSET);
        NicDmaRegs = (AU1X00_MACDMA *) (MACDMA1_PHYS_ADDR + KSEG1_OFFSET);

    } else 
#endif    
    {
        NicMacRegs = (AU1X00_MAC *) (MAC0_PHYS_ADDR + KSEG1_OFFSET);
        NicDmaRegs = (AU1X00_MACDMA *) (MACDMA0_PHYS_ADDR + KSEG1_OFFSET);
    
    }

	// Place the MAC into reset
    *NicEnableReg = 0;
    
    // Grab some memory for the packets. 
    // 4 Tx and 4 Rx        
    for (i=0;i<4;i++) {
        NicDmaRegs->tx[i].txstat = 0;
        NicDmaRegs->tx[i].txlen = 0;
        NicDmaRegs->tx[i].txaddr = NIC_TX_PHYSADDR_BASE + (i * NIC_PACKET_LEN);
        
        NicDmaRegs->rx[i].rxstat = 0;
        NicDmaRegs->rx[i].rxaddr = NIC_RX_PHYSADDR_BASE + (i * NIC_PACKET_LEN) | MACDMA_RXADDR_EN;
    }

    // enable clocks to MAC
    *NicEnableReg = MACEN_MAC_CE;
    
	// Wait for the clocks
	HalStallExecution(10);	// 1ms pause

    // take MAC out of reset
    *NicEnableReg = MACEN_MAC_E2 | 
                    MACEN_MAC_E1 |  
                    MACEN_MAC_E0 | 
                    MACEN_MAC_CE;
    
    
	// Wait for enable
	HalStallExecution(10);	// 1ms pause

    // Configure the MAC layer
    NicMacRegs->control = MAC_CONTROL_DO;
    

    pTmpMac = (char*)pAdapter->Addr.wMAC;

    KITLOutputDebugString("MAC Addr");
    for (i=0;i<6;i++) {
        KITLOutputDebugString(":%x",pTmpMac[i]);
    }
    KITLOutputDebugString("\r\n");


    // Write the address
    TmpMacAddr = pAdapter->Addr.wMAC[0];
    TmpMacAddr |= pAdapter->Addr.wMAC[1] << 16;
    NicMacRegs->addrlow = TmpMacAddr;
    
    TmpMacAddr = pAdapter->Addr.wMAC[2];
    NicMacRegs->addrhigh = TmpMacAddr;
    

    // accept no multicast
    NicMacRegs->hashhigh = 0;
    NicMacRegs->hashlow = 0;

	// Awake the PHY; most PHYs configured to AUTONEGOTIATE out of reset,
	// thus no need to touch the PHY
#ifdef PLATFORM_KITL_PHYINIT_CODE
	PLATFORM_KITL_PHYINIT_CODE
#endif

	// Initialize Rx and Tx buffer indexes

	NextTxBuffer = (NicDmaRegs->tx[0].txaddr & MACDMA_TXADDR_CB) >> MACDMA_TXADDR_CB_S;
	LastTxBuffer = NextTxBuffer;
	KITLOutputDebugString ("KITL: Initial Tx Buf=%d\r\n", NextTxBuffer);

	NextRxBuffer = (NicDmaRegs->rx[0].rxaddr & MACDMA_RXADDR_CB) >> MACDMA_RXADDR_CB_S;
	KITLOutputDebugString ("KITL: Initial Rx Buff=%d\r\n", NextRxBuffer);
	

	KITLOutputDebugString ("Adapter IP:= %x Port %d\r\n",pAdapter->Addr.dwIP,pAdapter->Addr.wPort);

    // Go
    NicMacRegs->control = MAC_CONTROL_DO | 
	                      MAC_CONTROL_RE | 
	                      MAC_CONTROL_TE;


#ifdef KITL_INTERRUPT_MODE
	OEMWriteDebugString(L"KITL Ethernet interrupt mode\r\n");

#ifdef HWINTR_MAC1DMA
    if (1 == pBootArgs->NICBase) 
	{
		pAdapter->SysIntrVal = OEMInterruptConnect(Internal, 0, HWINTR_MAC1DMA, 0);
    } 
	else 
#endif
	{
		pAdapter->SysIntrVal = OEMInterruptConnect(Internal, 0, HWINTR_MAC0DMA, 0);
    }

    NKDbgPrintfW(L"***** KitlInitEthernet() pBootArgs->NICBase=%d  Adapter.SysIntrVal=0x%x  KITL_MEMORY_START=0x%x\r\n", pBootArgs->NICBase, pAdapter->SysIntrVal, KITL_MEMORY_START);

#endif

	return TRUE;    
}

// VMINI stuff below
#ifdef IMGSHAREETH

void AuMacLayer_ApplyPacketFilter(DWORD dwFilter)
{
    ULONG Data;

    Data = NicMacRegs->control;
    
    // Leave these bits as they were
    Data &= MAC_CONTROL_DO |
            MAC_CONTROL_RE |
            MAC_CONTROL_TE;

    if (dwFilter & PACKET_TYPE_MULTICAST) {
        Data |= MAC_CONTROL_HP;
    }

    if (dwFilter & PACKET_TYPE_PROMISCUOUS) {
        Data |= MAC_CONTROL_PR;
    }

    if (!(dwFilter & PACKET_TYPE_BROADCAST)) {
        Data |= MAC_CONTROL_DB;
    }

    if (dwFilter & PACKET_TYPE_ALL_MULTICAST) {
        Data |= MAC_CONTROL_PM;
    }

    NicMacRegs->control = Data;
}

//
// Constant for the CRC32 routine
//
#define CRC32_POLY              0xEDB88320

static ULONG CRC32(PUCHAR s, UCHAR Length)
{
    UCHAR   ByteNumber;
    UCHAR   BitNumber;
    ULONG   CRCValue = 0xffffffff;
    UCHAR   CTemp;
	
	for( ByteNumber = 0; ByteNumber < Length; ByteNumber++ ) {
		for( CTemp = *s++, BitNumber = 0; BitNumber < 8; BitNumber++, CTemp >>= 1 ) {
            CRCValue = (CRCValue >> 1) ^ (((CRCValue ^ CTemp) & 1) ? CRC32_POLY : 0);
        }
    }

    return (CRCValue & 0x3f);
}

void AuMacLayer_ApplyMulticastList(UCHAR pucMulticastAddresses[][6], DWORD dwNoOfAddresses)
{
    ULONG i;
    ULONG BitNum;
    ULONG Mask;
    ULONG Crc;
    PULONG Reg;

#define MC_REGNO_BIT        (1<<31)
#define MC_BITNO_MASK       (0x1f<<26)
    
    NicMacRegs->hashhigh = 0;
    NicMacRegs->hashlow = 0;

    for (i=0;i<dwNoOfAddresses;i++) {
        Crc = CRC32(pucMulticastAddresses[i], 6);
        BitNum = (Crc & MC_BITNO_MASK) >> 26;
        Mask = 1 << BitNum;
        
        if (Crc & MC_REGNO_BIT) {
            Reg = (PULONG)&NicMacRegs->hashhigh;
        } else {
            Reg = (PULONG)&NicMacRegs->hashlow;
        }

        *Reg |= Mask;
    }
}

void ProcessVMiniSend(void)
{
	PBYTE   pVMiniData;
	DWORD   dwVMiniDataLength;
  
    //  Handle the filter if we need to
	if (bNewFilter) {
		bNewFilter = FALSE;
		AuMacLayer_ApplyPacketFilter(dwFilter);
	}

    //  Handle new multicast list..
    if (bNewMulticast) {
        bNewMulticast = FALSE;
        AuMacLayer_ApplyMulticastList(ucMultiAddr, dwNoOfEntry);
    }

	// Consume all the client packets.
	while ( VBridgeKGetOneTxBuffer(&pVMiniData,&dwVMiniDataLength) == TRUE) {
		MacLayer_SendFrame(pVMiniData, dwVMiniDataLength);
		VBridgeKGetOneTxBufferComplete(pVMiniData);
	}
} // ProcessVMiniSend()
#endif

#endif
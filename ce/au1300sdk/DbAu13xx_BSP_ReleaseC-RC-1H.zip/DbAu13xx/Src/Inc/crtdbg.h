#ifndef _INC_CRTDBG
#define _INC_CRTDBG

#pragma message ("")
#pragma message ("This should be included from MS code ... not PLATFORM.")
#pragma message ("")

#endif // _INC_CRTDBG
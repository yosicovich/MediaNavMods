/*++
Copyright (c) 1998  BSQUARE Corporation.  All rights reserved.

Module:

    ataboot.h

Description:

    This file contains defines and typedefs for various ATA disk offsets,
    structures, and bit positions.

Author:

    Steve Brooks

Revision History:

    8-Sept-1998     Richard Chinn
        General cleanup.

    14-Dec-1998     Richard Chinn
    Changed AtaInitializeDevice prototype to support master/slave disk
        selection via the DriveNumber parameter.
    Also added DriveNumberMask to ATA_DEVICE to support master/slave disks.

--*/

#ifndef __ATABOOT_H__
#define __ATABOOT_H__

#include <atapi.h>

//
//  ATA Port addresses:
//

#define ATA_CMD_BASE0   0x1F0
#define ATA_CTL_BASE0   0x3F6

#define ATA_CMD_BASE1   0x170
#define ATA_CTL_BASE1   0x376

#define ATA_CMD_LENGTH  0x08
#define ATA_CTL_LENGTH  0x02

//
//  ATA Register Offsets (AT Task File)
//

typedef volatile struct _ATA_CMDREG {
    UCHAR       Data;                       // Data Register
    union{
        UCHAR   Error;                      // Error Register (read)
        UCHAR   Feature;                    // Feature register (write)
    };
    UCHAR   SecCount;                       // Sector Count
    UCHAR   SecNum;                         // Sector Number
    UCHAR   CylinderLo;                     // Cylinder Number Low
    UCHAR   CylinderHi;                     // Cylinder Number High
    UCHAR   Head;                           // Drive/Head Number
    union{
        UCHAR   Status;                     // Status Register (read)
        UCHAR   Command;                    // Command Register (write)
    };
} ATA_CMDREG;


typedef volatile struct _ATA_CTLREG {
    union {
        UCHAR   AltStatus;                  // Alternate Status Reg. (read)
        UCHAR   DevControl;                 // Device Control Reg. (write)
    };
    UCHAR   Address;                        // Address Register
} ATA_CTLREG;


#define ATA_STAT_ERR    0x01                // Error
#define ATA_STAT_IDX    0x02                // Index
#define ATA_STAT_CORR   0x04                // Corrected Data
#define ATA_STAT_DRQ    0x08                // Data Request
#define ATA_STAT_DSC    0x10                // Drive Seek Complete
#define ATA_STAT_DWF    0x20                // Drive Write Fault
#define ATA_STAT_DRDY   0x40                // Drive Ready
#define ATA_STAT_BSY    0x80                // Busy

#define ATA_ERR_NONE    0x00                // No Error
#define ATA_ERR_AMNF    0x01                // Address Mark Not Found
#define ATA_ERR_TK0NF   0x02                // Track zero not found
#define ATA_ERR_ABRT    0x04                // Aborted Command
#define ATA_ERR_MCR     0x08                // Media Change Requested
#define ATA_ERR_IDNF    0x10                // ID Not Found
#define ATA_ERR_MC      0x20                // Media Change
#define ATA_ERR_UNC     0x40                // Uncorrectable Data Error
#define ATA_ERR_BBK     0x80                // Bad Block Detected
#define ATA_ERR_PARM    0x100               // Invalid parameter to ATA function


//
//  Partition Table structure. Currently only one partition is supported
//

typedef struct _PARTITION {
    UCHAR   BootFlag;                       // Bootable partition indicator
    UCHAR   Start[3];                       // Partition Start Sector
    UCHAR   SystemFlag;                     // Partition Type information
    UCHAR   End[3];                         // Partition End Sector
    ULONG   StartSector;                    // LBA of Start Sector
    ULONG   NumSectors;                     // # of sectors in partition
} PARTITION;
    
#define PARTITION_TABLE_OFFS    0x1be       // Partition table offset in sec 0
#define PART_FAT12  0x01                    // SystemFlag value for 12-bit FAT
#define PART_FAT16  0x04                    // SystemFlag value for 16-bit FAT
#define PART_FATBIG 0x06                    // SystemFlag for 16-bit BIGDOS FAT
#define PART_EXTENDED 0x05					// Extended Partition (partitions within partitions)

#define FAT12_CLUSTER_BAD   0x0ff7
#define FAT12_CLUSTER_END   0x0ff8
#define FAT12_CLUSTER_MAX   0x0ff0

#define FAT16_CLUSTER_BAD   0xfff7
#define FAT16_CLUSTER_END   0xfff8
#define FAT16_CLUSTER_MAX   0xfff0

typedef struct _BOOTSECT {
    UCHAR   x86Jump[3];                     // [00] x86 Jump instruction
    UCHAR   OEMName[8];                     // [03] OEM Name string
    UCHAR   BytesPerSec[2];                 // [0b] # of bytes per sector
    UCHAR   SecPerAlloc;                    // [0d] Sectors per cluster
    USHORT  ResvSectors;                    // [0e] # of reserved sectors
    UCHAR   NumFATs;                        // [10] # of of FATs
    UCHAR   RootDirEntries[2];              // [11] # of root directory entries
    UCHAR   LogSectors[2];                  // [13] # of logical sectors
    UCHAR   MediaDesc;                      // [15] Media Descriptor byte
    USHORT  SectorsPerFAT;                  // [16] # of sectors per FAT
    USHORT  SectorsPerTrack;                // [18] # of sectors per track
    USHORT  NumHeads;                       // [1a] Number of Heads
    USHORT  HiddenSectors;                  // [1c] Number of Hidden Sectors
	USHORT  Filler;
	UCHAR   TotSec32[4];						  // new 32bit count of sectors
} BOOTSECT;

typedef struct _DIRENTRY {
    UCHAR   FileName[8];                    // [00] ASCII File Name
    UCHAR   Extension[3];                   // [08] ASCII File Extension
    UCHAR   Attribute;                      // [0b] Attribute Byte
    UCHAR   Reserved[10];                   // [0c] Reserved Bytes
    USHORT  AccessTime;                     // [16] Time of Last Access
    USHORT  AccessDate;                     // [18] Date of Last Access
    USHORT  StartCluster;                   // [1a] Starting Cluster Number
    ULONG   Length;                         // [1c] Length of File
} DIRENTRY;

#define DIRENT_UNUSED   0x00                // Entry has never been used
#define DIRENT_DELETED  0xe5                // Entry has been deleted
#define DIRENT_E5CHAR   0x05                // First char is 0xe5
#define DIRENT_DIR      0x2e                // Entry is a directory
#define DIRENT_LONG     0x41                // Entry is long file name type

#define FATTR_RONLY     0x01                // Read Only
#define FATTR_HIDDEN    0x02                // Hidden File
#define FATTR_SYSTEM    0x04                // System File
#define FATTR_VOLUME    0x08                // Volume Label
#define FATTR_DIR       0x10                // Directory
#define FATTR_ARCHIVE   0x20                // Archive bit
#define FATTR_LONG      0x0F                // Long file name attribute


//
// Required platform specific functions.
//

/*++

Routine Description:

    Busy waits for the specified number of microseconds.

Arguments:

    usecs - Number of microseconds to wait.

Return Value:

    None.

--*/

VOID
usDelay(
    IN ULONG usecs
    );


//
// ATA Device Structure
//

typedef struct _SECTORNUM {
    BOOLEAN LBA;                            // TRUE if LBA Sector number
    union {
        ULONG   LBASector;                  // Sector number in LBA form
        struct {
            USHORT  Cylinder;               // Cylinder
            UCHAR   Head;                   // Disk Head number
            UCHAR   Sector;                 // Sector
        };
    } u;
} SECTORNUM;


typedef struct _ATA_DEVICE {

    ULONG   CmdBase;                        // Command registers port address
    ULONG   CtlBase;                        // Control registers port address
    UCHAR   DriveNumberMask;                // 0x00=Master 0x10=Slave

    USHORT  BytesPerSec;                    // # of bytes per sector
    USHORT  SecPerCluster;                  // Size of each allocation unit
    USHORT  SecPerTrack;                    // # of sectors per track
    USHORT  Heads;                          // # of heads
    USHORT  NumCyl;                         // # of Cylinders

    PARTITION Partition;                    // Primary Partition Information
    UCHAR   NumFATs;                        // FAT Number from boot sector
    USHORT  SecPerFAT;                      // Sectors per FAT from boot sector
    USHORT  DirEntries;                     // Number of root directory entries
    USHORT  ResvSectors;                    // [0e] # of reserved sectors
    volatile char *FATBuf;                  // Pointer to the device FAT
    
} ATA_DEVICE;


//
//  ATA Function Prototypes
//

ULONG
ATAInitializeDevice(
    IN PVOID CommandBase,
    IN PVOID ControlBase,
    IN ULONG DriveNumber
    );

ULONG
ATAReadSectors(
    IN OUT ATA_DEVICE *Disk,
    IN SECTORNUM Sector,
    IN ULONG Count,
    OUT PUCHAR SectorBuf
    );

ULONG
FATFileOpen(
    IN ULONG DevIndex,
    IN PUCHAR Filename
    );

VOID
FATFileClose(
    IN ULONG FileDesc
    );

ULONG
FATFileSize(
    IN ULONG FileDesc
    );

ULONG
FATFileSeek(
    IN ULONG FileDesc,
    IN ULONG Position
    );

ULONG
FATFileRead(
    IN ULONG FileDesc,
    IN ULONG Length,
    OUT PUCHAR DataBuf
    );

BOOL
FATReadBin(
    IN ULONG AtaDeviceIndex,
    IN PUCHAR FileName,
    OUT PULONG JumpAddress
    );

BOOL FlashReadBin( PULONG FlashAddress, PULONG JumpAddress);
BOOL FATReadFile( ULONG AtaDeviceIndex, PUCHAR FileName, PULONG pDestAddress, PULONG pFileSize );

#endif __ATABOOT_H__
/*
    Copyright (c) 2001-2003 BSQUARE Corporation.  All rights reserved.

	cmdtable.h
*/

//
//	Externs for the cmds in the cmd table
//

#include "ldr.h"

//
//  Commands
//
extern int Help(int argc, char *argv[]);
extern int Reset(int argc, char *argv[]);

extern int WriteValue(int argc, char *argv[]);
extern int ReadValue(int argc, char *argv[]);

extern int Jump(int argc, char *argv[]);

extern int XmodemDownload(int argc, char *argv[]);
extern int DumpMem(int argc, char *argv[]);
extern int ToyDisp(int argc, char *argv[]);
extern int FlashCmd(int argc, char *argv[]);
extern int ReadTLB(int argc, char *argv[]);
extern int WriteTlb(int argc, char *argv[]);

extern int ATAFlashCard(int argc, char *argv[]);
extern int MacAddrCmd(int argc, char *argv[]);
extern int PerReg(int argc, char *argv[]);
extern int msysCmd(int argc, char *argv[]);

extern int FlashLoad(int argc, char *argv[]);
extern int ATAFlashCopy(int argc, char *argv[]);


//
//  Help Text
//
extern char helpHelp[];
extern char resetHelp[];

extern char writeHelp[];
extern char readHelp[];

extern char jumpHelp[];
extern char xmodemDownloadHelp[];
extern char dumpMemHelp[];
extern char toyHelp[];
extern char memsetHelp[];

extern char displayHelp[];
extern char flashHelp[];
extern char readTlbHelp[];
extern char rectanglesHelp[];
extern char writeTlbHelp[];
extern char ATAHelp[];
extern char floadHelp[];
extern char atacopyHelp[];

extern char MacAddrCmdHelp[];
extern char perregHelp[];
extern char msysHelp[];

/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.

	ldr.h

	Structures and defines pertinent to the loader
*/
#ifndef __LDRDEFS_H__
#define __LDRDEFS_H__ 1
#define _CRTIMP

#define STRSAFE_NO_A_FUNCTIONS
#define STRSAFE_NO_DEPRECATE

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <dbgapi.h>
#include <halether.h>
#include <pehdr.h>
#include <romldr.h>
#include "bceddk.h"
#include "platform.h"
#include "ldrarg.h"

#define     TRUE    1
#define     FALSE   0


//
// Memory areas for peripherals
// Some peripherals must be mapped via the static banks
// as well as virtually MAPPED
// The physical mappings area defined in Alchemy's memory map doc
// The virtual mappings for the loader are defined here
// NOTE: For CE the vitrual mapping is indeterminate as
//       MmMapIoSpace is used
#define    PCMCIA_VIRTUAL_BASE      0x1A000000
#define    PCMCIA_VIRTUAL_SIZE      0x06000000

#define    VGA_TLB_NUMBER           25
#define	   PCM_IO0_TLB_INDEX	    26
#define    PCM_MEM0_TLB_INDEX       27
#define    PCM_ATTR0_TLB_INDEX      28
#define    PCI_MEM_TLB_INDEX        29
#define    PCI_CONFIG_TLB_INDEX     30
#define    PCI_IO_TLB_INDEX         31



#define _ETOK_H_ 1
//
//	CLI sizes
//
#define		CLI_MAX_CMDLINE_LEN		256
#define     CLI_MAX_ARG_COUNT		16
#define     CLI_HISTORY_SIZE		16


//
//	CLI characters
//
#define		ASCII_ESC			27
#define		ASCII_BS			8
#define		ASCII_HTAB			9
#define		ASCII_LF			10
#define		ASCII_FF			12
#define		ASCII_CR			13
#define		ASCII_SPACE			32
#define     ASCII_ARROW         0x5b
#define     ASCII_ARROWUP       0x41
#define     ASCII_ARROWDOWN     0x42
#define     ASCII_ARROWLEFT     0x44
#define     ASCII_ARROWRIGHT    0x43


// #define KITLOutputDebugString KITLOutputDebugString
//
//	Errors. list should correspond to error messages, add yours to the list
//
#undef ERROR_SUCCESS
#define	ERROR_SUCCESS		0
#define ERROR_WARNING_BASE	0x88000000
#define ERROR_ERROR_BASE	0x84000000

//
//  Used to select output error levels
//
enum {
    ERROR_LEVEL_ALL,
    ERROR_LEVEL_ERRORSONLY,
    ERROR_LEVEL_WARNING,
    ERROR_LEVEL_NONE
    };


//
//	Warnings start here, add yours to the list
//
#define ERROR_WARNING	    (ERROR_WARNING_BASE - 1)
#define WARNING_NOTFOUND    (ERROR_WARNING_BASE - 2)


//
//	Errors start here, add yours to the list
//
#define ERROR_FAILURE	        (ERROR_ERROR_BASE - 1)
#define ERROR_NOTFOUND          (ERROR_ERROR_BASE - 2)
#define ERROR_MISSINGARGS       (ERROR_ERROR_BASE - 3)
#define ERROR_UNALIGNEDACCESS   (ERROR_ERROR_BASE - 4)
#define ERROR_BADARG            (ERROR_ERROR_BASE - 5)

//
// hundreds of nano seconds to tick and vice versa
//
#define HNS_TO_TICKS(HNS)      ((ULONG)(((ULONGLONG)(HNS)*1583296744) >> 32))
#define TICKS_TO_HNS(TICKS)  (((ULONGLONG)(TICKS) *  2912711111) >> 30)

// Download image type (used to decide amongst storage options).
//
typedef enum _IMAGE_TYPE_
{
        IMAGE_LOADER,
        IMAGE_OS_BIN,
        IMAGE_OS_NB0
} IMAGE_TYPE, *PIMAGE_TYPE;


//
//	Each cmd has this prototype
//
typedef int (*CMD)(int, char **);
typedef struct {
    CMD Cmd;
    char *CmdName;
    char const *HelpText;

} CMDENTRY, *PCMDENTRY;

extern CMDENTRY	CmdTable[];

extern int SearchForCmd(
    char *CmdName
    );



//
// CLI
//
extern DispatchCmd(
	unsigned int ArgCount,
	char *ArgVList[]
	);

extern unsigned int
GetCmdLine(
	char *CLBuf,
	char *ArgV[]);


extern const char *
GetCmdName(
    unsigned int CmdNum
    );

extern const char *
GetCmdHelpText(
    unsigned int CmdNum
    );

extern void
DisplayBanner(void);

extern int climain(
    unsigned long arg0, // Heap base
    unsigned long arg1, // heap size
    unsigned long arg2,
    unsigned long arg3
    );

extern DWORD
OEMEthernetPreDownload(
    void
    );

extern DWORD
OEMEthernetDownload(
    BOOT_ARGS *pBootArgs,
    char    EbootPlatformStr[],
    DWORD   dwSubnetMask,
    BOOL    fGotIP
    );

extern void
OEMEthernetLaunch (
    DWORD dwImageStart,
    DWORD dwImageLength,
    DWORD dwLaunchAddr,
    const ROMHDR *pRomHdr);



//
//  Heap
//
extern int InitHeap(
    unsigned int HeapBase,
    unsigned int HeapSize) ;

extern void *malloc(
    unsigned int size
    );

extern void free(
    void *where
    );

//
//  Input and Output
//
extern void PutString(char *Buf);

extern void NewLine(void);

extern void Backspace(unsigned int Spaces);

extern int putch(char);
extern char getch(void);
extern int GetchTimeout(int Timeout);


extern int CheckForEscape(void);


extern int strtohex(char*, unsigned int *);


//
// OAL functions
//
extern void InitializeTimers(void);
extern unsigned long
LdrXmodemDownload(
    int Parse,
    unsigned long TargetAddr);

extern unsigned long OEMEthGetSecs(void);

extern int OEMEthDeInit (
    void );

/*
#ifndef KITLOutputDebugString
extern int KITLOutputDebugString(const char *, ...);
#endif
*/
#define dbgKITLOutputDebugString(a, b)         if (a) KITLOutputDebugString##b

extern VOID
DumpFrame(
    PUCHAR Address,
    ULONG Len
);


extern BOOL ldr_WriteFlash(
    ULONG TargetOffset,
    PVOID SourceData,
    ULONG Size,
    char Erase);


extern BOOL ldr_ReadFlash(
    PVOID Target,
    ULONG SourceOffset,
    ULONG Size);


extern BOOL  ldr_EraseFlash(
    ULONG Address,
    ULONG Size,
    BOOL Completion
    );
extern BOOL ldr_WriteFlash32(
    ULONG TargetOffset,
    ULONG SourceData
);

extern BOOL ldr_WaitForEraseComplete(
    ULONG Address
);
extern VOID CheckPoint(VOID);

extern LockIntoICache(
    ULONG Start,
    ULONG End);


extern UnlockICache(
    ULONG Start,
    ULONG End);

extern ULONG
OEMGetCpuSpeedMHz(
    VOID
    );

#endif



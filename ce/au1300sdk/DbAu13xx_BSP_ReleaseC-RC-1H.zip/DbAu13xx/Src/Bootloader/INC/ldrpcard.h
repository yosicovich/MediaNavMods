/*++
Copyright (c) 1998, 2000  BSQUARE Corporation.  All rights reserved.

Module Name:

    ldrpcard.h

Module Description:

    This file contains data type definitions and function prototypes for
    PCMCIA support.

Author:

    Steve Brooks

Revision History:

    Richard Chinn 9-Sept-1998
        Added PCMFindAtaDevices.  Changed PCMRequestConfiguration 
        to take in the ValidConfigFlags parameter.  Minor reformatting.

    Richard Chinn 1-January-2000
        Added defines for Vcc checking.
        
--*/

#ifndef _LDRPCARD_H_
#define _LDRPCARD_H_

#include <windows.h>

//
//  PCMCIA I/O and Memory Window Definitions
//

#ifndef NUM_IO_WINDOWS
#define NUM_IO_WINDOWS  2
#endif

#ifndef NUM_MEM_WINDOWS
#define NUM_MEM_WINDOWS 5
#endif

#ifndef NUM_SOCKETS
#define NUM_SOCKETS     1
#endif

#define ATTRIB_WIN_SIZE (4 * 1024)

typedef enum {
    PCMWindowDisabled = 0,
    PCMWindowIO,
    PCMWindowCommon,
    PCMWindowAttribute
} PCM_WINDOWTYPE;

typedef struct _PCM_WINDOW {
    PCM_WINDOWTYPE  Type;                   // Type of window
    UCHAR           Adapter;                // Adapter Number 
    UCHAR           Socket;                 // Socket Number
    UCHAR           Window;                 // Window number within Socket
    UCHAR           Width;                  // Width of window (8/16 bit)
    ULONG           Base;                   // Window Memory/Port Base
    ULONG           Size;                   // Window size in bytes/ports
    ULONG           Offset;                 // Memory Window Offset
} PCM_WINDOW;


//
// PCMCIA Socket Status Structure
//
// This structure is filled in by PCMGetStatus.
//

typedef union _PCM_SOCKSTAT {
    struct {
        UCHAR   WriteProt : 1;                  // Write protect status
        UCHAR   BVD1 : 1;                       // BVD1 status
        UCHAR   BVD2 : 1;                       // BVD2 status
        UCHAR   Ready : 1;                      // Status of READY signal
        UCHAR   Detect : 1;                     // Current Card Detect Status
        UCHAR   Unused : 3;
    };
    UCHAR   All;
    
} PCM_SOCKSTAT;


//
// PCMCIA Card Configuration Structure
//
// This structure defines the current configuration of a PC card.
//

typedef enum {
    PCMInterfaceNone = 0,
    PCMInterfaceMem,
    PCMInterfaceIO,
    PCMInterfaceCBus
} PCM_INTERFACE;

typedef enum {
    PCMFunctionMulti = 0,
    PCMFunctionMemory = 1,
    PCMFunctionSerial = 2,
    PCMFunctionModem = 2,
    PCMFunctionParallel = 3,
    PCMFunctionDisk = 4,
    PCMFunctionVideo = 5,
    PCMFunctionNetwork = 6,
    PCMFunctionAIMS = 7,
    PCMFunctionSCSI = 8
} PCM_FUNCTION;


typedef struct _PCM_CARDINFO {
    PCM_INTERFACE   Interface;                  // Card Interface type
    PCM_FUNCTION    Function;                   // Device Function type
    PCM_SOCKSTAT    Status;                     // Current card status
    BOOLEAN         Configured;                 // TRUE if configuration set
    UCHAR           Socket;                     // Socket number of card
    ULONG           RegBase;                    // Configuration Register base
    PCM_WINDOW      Attrib;                     // Window into Attribute space
    PCM_WINDOW      IOWindow[NUM_IO_WINDOWS];   // IO Window mapping
    PCM_WINDOW      MemWindow[NUM_MEM_WINDOWS]; // Memory Window mapping
    ULONG           DeviceSize;                 // Memory size from TPL_DEVICE
} PCM_CARDINFO;


//
// Flags used by PCMRequestConfiguration to specify what kind of
// configuration is wanted.
//
#define CFG_FORCE_IO         0x00000001
#define CFG_FORCE_8_BIT_IO   0x00000002


//
// Tuple Structure Definitions.
//
// Note that this is a variable length field.
//

#define MAX_TUPLE_DATA  ((ULONG)128)

typedef struct _PCM_TUPLE{

    UCHAR   TplCode;                        // Tuple type code
    UCHAR   TplLink;                        // Link field (bytes to next tuple)
    UCHAR   TplData[MAX_TUPLE_DATA];        // Variable length data field

} PCM_TUPLE;


//
// CIS Tuple Types.
//

#define TUP_NULL        0x00                // Null Control tuple
#define TUP_DEVICE      0x01                // Device info for common memory
#define TUP_LONGLINK    0x06                // Long-link for Multi-functions
#define TUP_CHECKSUM    0x10                // Checksum control
#define TUP_LONGLINK_A  0x11                // Longlink to attribute memory
#define TUP_LONGLINK_C  0x12                // Longlink to common memory
#define TUP_LINKTARGET  0x13                // Link Target
#define TUP_NO_LINK     0x14                // End of tuple chain
#define TUP_VERS_1      0x15                // Level 1 Version info
#define TUP_ALTSTR      0x16                // Alternate language string
#define TUP_DEVICE_A    0x17                // Device info for Attribute mem
#define TUP_JEDEC_C     0x18                // JEDEC algorithm info. Common
#define TUP_JEDEC_A     0x19                // JEDEC algorithm info. Attribute
#define TUP_CONFIG      0x1A                // Configuration tuple
#define TUP_CFTABLE     0x1B                // Configuration table entry
#define TUP_DEVICE_OC   0x1C                // Other Conditions tuple. Common
#define TUP_DEVICE_OA   0x1D                // Other Conditions tuple. Attrib
#define TUP_DEVICEGEO   0x1E                // Device Geometry (Common)
#define TUP_DEVICE_GEOA 0x1F                // Device Geometry (Attribute)
#define TUP_MANFID      0x20                // Manufacturers Identification
#define TUP_FUNCID      0x21                // Function Identification
#define TUP_FUNCE       0x22                // Function Extension
#define TUP_END         0xff                // Termination tuple

//
//  Device Types
//

#define DTYPE_NULL      0x00                // No Memory Device
#define DTYPE_ROM       0x01                // Masked ROM
#define DTYPE_OTPROM    0x02                // One Time programmable Rom
#define DTYPE_EPROM     0x03                // UV EPROM
#define DTYPE_EEPROM    0x04                // EEPROM
#define DTYPE_FLASH     0x05                // Flash EPROM
#define DTYPE_SRAM      0x06                // Static RAM
#define DTYPE_DRAM      0x07                // Dynamic RAM
#define DTYPE_FUNCSPEC  0x0D                // Function-specific memory device
#define DTYPE_EXTEND    0x0E                // Extended type

//
//  Device Speed Codes:
//

#define DSPEED_NULL     0x00                // NULL
#define DSPEED_250NS    0x01
#define DSPEED_200NS    0x02
#define DSPEED_150NS    0x03
#define DSPEED_100NS    0x04
#define DSPEED_EXT      0x07                // Extended Speed

//
//  Unit size codes
//

#define DSIZE_512B      0x00                // 512 Bytes
#define DSIZE_2K        0x01                // 2048 Bytes
#define DSIZE_8K        0x02                // 8192 Bytes
#define DSIZE_32K       0x03                // 32K Bytes
#define DSIZE_128K      0x04                // 128K Bytes
#define DSIZE_512K      0x05                // 512K Bytes
#define DSIZE_2M        0x06                // 2 MegaBytes

//
// Power Description Structure Parameter Selection Byte
//

#define TPCE_PD_NOM_V       0x01            // Nominal voltage.
#define TPCE_PD_MIN_V       0x02            // Minimum voltage.
#define TPCE_PD_MAX_V       0x04            // Maximum voltage.
#define TPCE_PD_STATIC_I    0x08            // Static current.
#define TPCE_PD_AVG_I       0x10            // Average current.
#define TPCE_PD_PEAK_I      0x20            // Peak current.
#define TPCE_PD_PDWN_I      0x40            // Power down current.

//
// Power Description Structure Parameter Definition
//

#define TPCE_PD_EXT         0x80
#define TPCE_PD_MANTISSA    0x78
#define TPCE_PD_EXPONENT    0x07

#define TPCE_PD_GET_MANTISSA(x) \
    (((x) >> 3) & 0xF)


#define TPCE_PD_GET_EXPONENT(x) \
    ((x) & TPCE_PD_EXPONENT)

//
//  Function prototypes for PCMCIA support functions:
//


//
// Platform specific functions.
//

VOID
usDelay(
    IN ULONG usecs
    );

VOID
PCMInitialize(
    VOID
    );

BOOLEAN
PCMResetSocket(
    IN UCHAR SocketNum
    );

BOOLEAN
PCMGetStatus(
    IN UCHAR SocketNum,
    OUT PCM_SOCKSTAT *Status
    );

BOOLEAN
PCMRequestIO(
    IN UCHAR Socket,
    IN ULONG Base,
    IN ULONG Size,
    IN ULONG Width,
    OUT PCM_WINDOW *Window
    );

BOOLEAN
PCMRequestWindow(
    IN UCHAR Socket,
    IN PCM_WINDOWTYPE Type,
    IN ULONG Base,
    IN ULONG Offset,
    IN ULONG Length,
    OUT PCM_WINDOW *Window
    );

VOID
PCMSetIOMode(
    IN ULONG Socket
    );


//
// Platform independent functions.
//

BOOLEAN
PCMGetFirstTuple(
    IN ULONG Socket,
    OUT PCM_TUPLE *Tuple
    );

BOOLEAN
PCMGetNextTuple(
    IN ULONG Socket,
    OUT PCM_TUPLE *Tuple
    );

ULONG
PCMFindPcCards(
    VOID
    );

PCM_CARDINFO *
PCMGetFirstCard(
    VOID
    );

PCM_CARDINFO *
PCMGetNextCard(
    IN PCM_CARDINFO *pCard
    );

PCM_CARDINFO *
PCMFindDevice(
    IN PCM_CARDINFO *pCard,
    IN PCM_FUNCTION Function
    );

BOOLEAN
PCMRequestConfiguration(
    IN PCM_CARDINFO *Card,
    IN PCM_TUPLE *Tuple,
    IN ULONG ValidConfigFlags
    );

ULONG
PCMFindAtaDevices(
    IN ULONG MaxDevices,
    OUT PULONG AtaDeviceIndices
    );


#endif _LDRPCARD_H_

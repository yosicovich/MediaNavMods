/*++
Copyright (c) 1998  BSQUARE Corporation.  All rights reserved.

Module Name:

    ldrpcicn.h

Module Description:

    PCI configurator defines, typedefs, and function prototypes used in the
    loader.

Author:

    Jason W. Murray

Revision History:

--*/

#ifndef __LDRPCICN_H__
#define __LDRPCICN_H__

#include "ldr.h"


//
// Typedefs used for specifying PIN to LINE interrupt mappings
//

#define PCI_MAX_INTERRUPTS  4

typedef UCHAR PCI_PIN_TO_LINE_TABLE[PCI_MAX_DEVICES][PCI_MAX_INTERRUPTS + 1];

typedef PCI_PIN_TO_LINE_TABLE *PPCI_PIN_TO_LINE_TABLE;

//
// Functions that the Configurator Requires
//

typedef
VOID
(*PPCI_PRINTF_ROUTINE)(
    IN PCWSTR Format, 
    ...
    );


typedef
UCHAR
(*PPCI_READ_CONFIG_UCHAR_ROUTINE)(
    IN UCHAR CycleType,
    IN UCHAR Bus,
    IN UCHAR Device,
    IN UCHAR Function,
    IN UCHAR Offset
    );

typedef
USHORT
(*PPCI_READ_CONFIG_USHORT_ROUTINE)(
    IN UCHAR CycleType,
    IN UCHAR Bus,
    IN UCHAR Device,
    IN UCHAR Function,
    IN UCHAR Offset
    );

typedef
ULONG
(*PPCI_READ_CONFIG_ULONG_ROUTINE)(
    IN UCHAR CycleType,
    IN UCHAR Bus,
    IN UCHAR Device,
    IN UCHAR Function,
    IN UCHAR Offset
    );

typedef
VOID
(*PPCI_WRITE_CONFIG_UCHAR_ROUTINE)(
    IN UCHAR CycleType,
    IN UCHAR Bus,
    IN UCHAR Device,
    IN UCHAR Function,
    IN UCHAR Offset,
    IN UCHAR Data
    );

typedef
VOID
(*PPCI_WRITE_CONFIG_USHORT_ROUTINE)(
    IN UCHAR CycleType,
    IN UCHAR Bus,
    IN UCHAR Device,
    IN UCHAR Function,
    IN UCHAR Offset,
    IN USHORT Data
    );

typedef
VOID
(*PPCI_WRITE_CONFIG_ULONG_ROUTINE)(
    IN UCHAR CycleType,
    IN UCHAR Bus,
    IN UCHAR Device,
    IN UCHAR Function,
    IN UCHAR Offset,
    IN ULONG Data
    );

typedef
BOOLEAN
(*PPCI_INTERRUPT_PIN_TO_LINE_CALLBACK_ROUTINE)(
    IN IN PPCI_SLOT_NUMBER Path,
    IN IN UCHAR Depth,
    IN IN UCHAR Pin,
    IN OUT PUCHAR Line
    );    

extern
BOOLEAN
PciConfigureEntry(
    IN PPCI_PRINTF_ROUTINE PrintfRoutine
    );

extern
PVOID
PciAllocateMemory(
    IN ULONG NumberOfBytes
    );

extern
VOID
PciFreeMemory(
    IN PVOID BaseAddress
    );

extern
VOID
PciConfigure(
    VOID
    );

extern
VOID
PciConfigureExit(
    VOID
    );


//
// PCI Host Adapter
//

typedef ULONG PCI_HOST_HANDLE, *PPCI_HOST_HANDLE;

extern
BOOLEAN
PciHostCreate(
    OUT PPCI_HOST_HANDLE NewPciHandle,
    IN PPCI_READ_CONFIG_UCHAR_ROUTINE ReadConfigUcharRoutine,
    IN PPCI_READ_CONFIG_USHORT_ROUTINE ReadConfigUshortRoutine,
    IN PPCI_READ_CONFIG_ULONG_ROUTINE ReadConfigUlongRoutine,   
    IN PPCI_WRITE_CONFIG_UCHAR_ROUTINE WriteConfigUcharRoutine,
    IN PPCI_WRITE_CONFIG_USHORT_ROUTINE WriteConfigUshortRoutine,
    IN PPCI_WRITE_CONFIG_ULONG_ROUTINE WriteConfigUlongRoutine,
    IN ULONG CacheLineSize,
    OUT PUCHAR RootBusNumber,
    OUT PUCHAR MaxSubordinateBusNumber
    );

extern
BOOLEAN
PciHostAddMemoryResource(
    IN PCI_HOST_HANDLE PciHandle,
    IN PHYSICAL_ADDRESS BaseAddress,
    IN ULONGLONG NumberOfBytes
    );

extern
BOOLEAN
PciHostAddPrefetchableMemoryResource(
    IN PCI_HOST_HANDLE PciHandle,
    IN PHYSICAL_ADDRESS BaseAddress,
    IN ULONGLONG NumberOfBytes
    );

extern
BOOLEAN
PciHostAddIoResource(
    IN PCI_HOST_HANDLE PciHandle,
    IN PHYSICAL_ADDRESS BaseAddress,
    IN ULONGLONG NumberOfBytes
    );

extern
BOOLEAN
PciHostAddInterruptPinToLineTable(
    IN PCI_HOST_HANDLE PciHandle,
    IN PPCI_SLOT_NUMBER Path,
    IN ULONG Depth,
    IN PPCI_PIN_TO_LINE_TABLE Table
    );

extern
BOOLEAN
PciHostConfigure(
    IN PCI_HOST_HANDLE PciHandle
    );

extern
VOID
PciHostDelete(
    IN PCI_HOST_HANDLE PciHandle
    );


#endif __LDRPCICN_H__
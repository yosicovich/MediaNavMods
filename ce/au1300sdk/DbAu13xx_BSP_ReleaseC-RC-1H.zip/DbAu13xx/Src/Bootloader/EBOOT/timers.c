/*++
Copyright (c) 2001  BSQUARE Corporation.  All rights reserved.

Module Name:

    timer.c

Module Description:

    Supplies 2 timer routines, one with 100nS granularity (in theory)
    the other with 1 second.
    
    
Author:
    GJS March 2001

Revision History:


--*/

#include "ldr.h"
#include "platform.h"

/********************************************************************/

static AU1X00_SYS *ClockRegs = (AU1X00_SYS *)(SYS_PHYS_ADDR+KSEG1_OFFSET);

/********************************************************************/

void
InitializeTimers(void)
{
#ifdef HAVE_32KHZ_OSC
    ULONG Trim;
    ULONG Control;
    ULONG Count;
    ULONG StatusCheck;

    KITLOutputDebugString("\r\nSetting up TOY ");
    
    //
    // Is the 32Khz running?
    //
    Control = ClockRegs->cntrctrl;
    if (!(SYS_CNTRCTRL_32S & Control)) {
        
        // Start the 32Khz
        Control = SYS_CNTRCTRL_EO;
        ClockRegs->cntrctrl = Control;
        while (!(ClockRegs->cntrctrl & SYS_CNTRCTRL_32S));
    }
    
    //
    // The 32KHz is now running
    // Stop the counter
    //
    Control &= ~SYS_CNTRCTRL_TEN;
    ClockRegs->cntrctrl = Control;
    while (ClockRegs->cntrctrl & SYS_CNTRCTRL_ETS) ;

    //
    //  Calculate trim register for the desired reschedule period
    //  Set the ticker to tick at this period. 
    //  This requires changing the trim register

    Trim = TICKER_SOURCE_CLOCK_FREQ/DEFAULT_RTC_FREQ - 1;
    
    // Write trim and wait for complete
    ClockRegs->toytrim = Trim; 
    while (ClockRegs->cntrctrl & SYS_CNTRCTRL_TTS) ;
    
    //
    // enable counter run
    //
    Control |= SYS_CNTRCTRL_TEN;
    ClockRegs->cntrctrl = Control;
    while (ClockRegs->cntrctrl & SYS_CNTRCTRL_ETS) ;
    
    // Initialize counter values and matches
    Count = ClockRegs->toyread + 1;
          
    StatusCheck = SYS_CNTRCTRL_TS  | SYS_CNTRCTRL_ETS | SYS_CNTRCTRL_TTS;
    
    // wait until all written and matched
    while (ClockRegs->cntrctrl & StatusCheck);
    
    KITLOutputDebugString("completed\r\n");
#endif
}

/********************************************************************/

unsigned long
OEMEthGetSecs(void)
{
    unsigned long time = 0;
#ifdef HAVE_32KHZ_OSC
    time = ClockRegs->toyread;
#else
// FIX!!! Need to emulate based on Count
#endif
    return time;
}

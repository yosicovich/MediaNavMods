/*++
Copyright (c) 2001  BSQUARE Corporation.  All rights reserved.

Module Name:

    pccard.c

Module Description:

    This file contains platform dependent routines which provide native
    PCMCIA support. These routines consist of the minimal set of Card and
    Socket Services functions required to support booting a Windows CE
    image from a PCMCIA device.

    The functions defined in this file are:

    PCMInitialize               - PCMCIA Hardware Initialization
    PCMResetSocket              - Reset and enable a socket
    PCMGetStatus                - Return socket status
    PCMRequestWindow            - Create PCMCIA Window mapping
    PCMReleaseWindow            - Free a RequestWindow window mapping
    PCMSetIOMode                - Set socket into IO Mode

Author:

    GJS     March 2001

Revision History:

--*/

#include "ldr.h"
#include "ldrpcard.h"
#include "platform.h"


#define PCMCIA_IO_WIN_SIZE 0x2000000
#define PCM_IO0_BASE   PCMCIA_VIRTUAL_BASE
#define PCM_IO0_END    (PCM_IO0_BASE + PCMCIA_IO_WIN_SIZE-1)
#define PCM_IO1_BASE   0x30000000
#define PCM_IO1_END    (PCM_IO0_BASE + PCMCIA_IO_WIN_SIZE-1)

#define PCMCIA_CMN_WIN_SIZE 0x2000000
#define PCM_MEM0_BASE   (PCM_IO0_BASE+PCMCIA_IO_WIN_SIZE)
#define PCM_MEM0_END    (PCM_MEM0_BASE + PCMCIA_CMN_WIN_SIZE-1)
#define PCM_MEM1_BASE   (PCM_IO1_BASE+PCMCIA_IO_WIN_SIZE)
#define PCM_MEM1_END    (PCM_MEM1_BASE + PCMCIA_CMN_WIN_SIZE-1)

static ULONG PcmIO0AllocPtr = PCM_IO0_BASE;
static ULONG PcmIO1AllocPtr = PCM_IO1_BASE;
static ULONG PcmMem0AllocPtr = PCM_MEM0_BASE;
static ULONG PcmMem1AllocPtr = PCM_MEM1_BASE;

#define PCMCIA_ATTR_WIN_SIZE 0x2000000
#define PCM_ATTR0_BASE  (PCM_MEM0_BASE + PCMCIA_CMN_WIN_SIZE)
#define PCM_ATTR0_END   (PCM_ATTR0_BASE + PCMCIA_ATTR_WIN_SIZE-1)
#define PCM_ATTR1_BASE  (PCM_MEM1_BASE + PCMCIA_CMN_WIN_SIZE)
#define PCM_ATTR1_END   (PCM_ATTR1_BASE + PCMCIA_ATTR_WIN_SIZE-1)

#ifdef PLATFORM_PB1000
static CPLD_REGS * const cpld = (CPLD_REGS *)(CPLD_BASE_PHYSADDR + KSEG1_OFFSET);
#endif

#if defined(BCSR_PHYSADDR)
static BCSR * const bcsr = (BCSR *)(BCSR_PHYSADDR + KSEG1_OFFSET);
#endif

void
PCMSleep(
    ULONG ms
    )
{
    OALStallExecution(ms * 1000);
}


VOID
usDelay(
    IN ULONG Delay
    )

/*++

Routine Description:

  Busy waits for the specified number of microseconds.

Arguments:

    Delay - Number of microseconds to busy wait.

Return Value:

    None.

--*/

{
    OALStallExecution(Delay);
}

#if defined(PLATFORM_PB1200) || defined(PLATFORM_DB1200) || defined(PLATFORM_DB13XX)
static BOOL PlatCardResetSocket(UINT32 uSocket)
{
	UINT16 tmp, pwr, vs;
	UINT16 DetectMask, Detect;
#if defined(PLATFORM_DB13XX)
	AU13XX_GPINT * gpint =	(AU13XX_GPINT *)(GPINT_PHYS_ADDR + KSEG1_OFFSET);
	gpint->dev_sel[1] |= 0xC0000000;
	gpint->dev_sel[2] |= 0xC000007F;
#endif


	DetectMask = BCSR_BIC_PC0INSERT << (uSocket*2);
	Detect = bcsr->sigstatus & DetectMask;
	if (Detect)
	{
	KITLOutputDebugString("PCMCIA: card detected in socket \r\n");

#if !defined(PLATFORM_DB13XX)
	vs = bcsr->status;
	if (uSocket == 1)
		vs >>= 2;
	vs &= 0x0003;
#else
	vs = 2;
#endif

	switch (vs)
	{
	case 0:
	case 1:
	case 2:
		KITLOutputDebugString("3V Card\r\n");
		pwr = 0x0005;
		break;
	case 3:
		KITLOutputDebugString("5V Card\r\n");
		pwr = 0x0009;
		break;
	}

	// Apply power, assert reset and turn on PCMCIA buffers
    tmp = bcsr->pcmcia;
	tmp &= ~(0xFF << (8 * uSocket));
#if !defined(PLATFORM_DB13XX)
	tmp |= (pwr << (uSocket * 8));
#endif
    tmp |= (BCSR_PCMCIA_PC0DRVEN << (8 * uSocket));
    bcsr->pcmcia = tmp;
    usDelay(300);

	// De-assert RESET
    tmp |= (BCSR_PCMCIA_PC0RST << (8 * uSocket));
	bcsr->pcmcia = tmp;
    usDelay(30);

	for (tmp = 0; tmp < 5000; ++tmp)
	{
		if (!(bcsr->sigstatus & BCSR_BIC_PC0))
			break;
		usDelay(30);
	}

	if (bcsr->sigstatus & BCSR_BIC_PC0)
	{
		KITLOutputDebugString("ERROR: Card Not Ready\r\n");
		return FALSE;
	}
	return TRUE;

	}
	else
		return FALSE;
}
#endif


static void
ShutDownSocket(
    int SockNum
    )
{
#ifdef PLATFORM_PB1000
    if(SockNum==0) {
        cpld->Control &= ~SOCKET0(CARD_POWER_MASK);
    }
    else {
        cpld->Control &= ~SOCKET1(CARD_POWER_MASK));
    }
#endif

#ifdef PLATFORM_PB1500
	ULONG bus;

	bus = bcsr->pci_pcmcia;
	bus &= ~(BCSR_PCIPCMCIA_PCVPP | BCSR_PCIPCMCIA_PCVCC | BCSR_PCIPCMCIA_PCRST | BCSR_PCIPCMCIA_PCDRVEN);
	bcsr->pci_pcmcia = bus;
#endif

#ifdef PLATFORM_PB1100
	bcsr->pci_pcmcia &= ~(BCSR_PCIPCMCIA_PCVPP | BCSR_PCIPCMCIA_PCVCC | BCSR_PCIPCMCIA_PCRST | BCSR_PCIPCMCIA_PCDRVEN);
#endif

#ifdef PLATFORM_PB1550
	bcsr->pcmcia &= ~(0x00FF << (8 * SockNum));
#endif

#if defined(PLATFORM_DB1000) || defined(PLATFORM_DB1500) || defined(PLATFORM_DB1100)
	BCSR *bcsr = (BCSR *)BCSR_KSEG1_ADDR;

	if (SockNum == 0) {
		bcsr->pcmcia &= ~(0x00FF);
	 } else {
		bcsr->pcmcia &= ~(0xFF00);
	}
#endif

#ifdef PLATFORM_DB1550
	bcsr->pcmcia &= ~(0x00FF << (8 * SockNum));
#endif

#ifdef PLATFORM_HYD1100
	AU1X00_GPIO2 *GPIO2Regs = (AU1X00_GPIO2 *)(GPIO2_PHYS_ADDR + KSEG1_OFFSET);

	GPIO2Regs->output = 0x00010001;
#endif

#ifdef PLATFORM_HYDROGEN3
	AU1X00_GPIO2 *GPIO2Regs = (AU1X00_GPIO2 *)(GPIO2_PHYS_ADDR + KSEG1_OFFSET);

	GPIO2Regs->output = 0x00010001;
#endif

}

static void
TurnOnSocket(
    int SockNum
    )
{
#ifdef PLATFORM_PB1000
    ULONG vs;
    ULONG pwr;
    ULONG tmp;

    if(SockNum==0) {
        vs = SOCKET0(cpld->Status & CARD_VS_MASK) >> 4;
    }
    else {
        vs = SOCKET1(cpld->Status & CARD_VS_MASK)>> 12;
    }

    switch(vs) {
    case 2:   //3v card,vpp=0
        KITLOutputDebugString("3V Card\r\n");
        pwr = 0x0404;   //the power control bits discribed in the Theory_of_Operation_9 is not correct.
        break;
    case 3:   //5v card,vpp=0
        KITLOutputDebugString("5V Card\r\n");
        pwr = 0x0808;
    }

    tmp = cpld->Control;
    if(SockNum==0) {
        tmp &= ~SOCKET0(CARD_POWER_MASK);
        tmp |= SOCKET0(CARD_POWER_MASK&pwr);
    }
    else {
        tmp &= ~SOCKET1(CARD_POWER_MASK);
        tmp |= SOCKET1(CARD_POWER_MASK&pwr);
    }
    cpld->Control = tmp;
#endif

#ifdef PLATFORM_PB1500
    ULONG vs;
    ULONG pwr;
    ULONG bus;

	vs = (bcsr->status & BCSR_STATUS_PCMCIAVS) >> 4;
	switch (vs)
	{
	case 0:
	case 1:
	case 2:
		KITLOutputDebugString("3V Card\r\n");
		pwr = 0x00000005;
		break;
	case 3:
		KITLOutputDebugString("5V Card\r\n");
		pwr = 0x00000009;
		break;
	}

	bus = bcsr->pci_pcmcia;
	bus &= ~(BCSR_PCIPCMCIA_PCVPP | BCSR_PCIPCMCIA_PCVCC);
	bus |= pwr;
	bcsr->pci_pcmcia = bus;
#endif

#ifdef PLATFORM_PB1100
    USHORT vs;
    USHORT pwr;
    USHORT bus;

	vs = (bcsr->status & BCSR_STATUS_PCMCIAVS) >> 4;
	switch (vs)
	{
	case 0:
	case 1:
	case 2:
		KITLOutputDebugString("3V Card\r\n");
		pwr = 0x0005;
		break;
	case 3:
		KITLOutputDebugString("5V Card\r\n");
		pwr = 0x0009;
		break;
	}

	bus = bcsr->mem_pcmcia;
	bus &= ~(BCSR_MEMPCMCIA_PCVPP | BCSR_MEMPCMCIA_PCVCC);
	bus |= pwr;
	bcsr->mem_pcmcia = bus;
#endif

#ifdef PLATFORM_PB1550
    USHORT vs;
    USHORT pwr;
	USHORT Tmp;

	vs = bcsr->status;
	if (SockNum == 1)
		vs >>= 2;
	vs &= 0x0003;

	switch (vs)
	{
	case 0:
	case 1:
	case 2:
		KITLOutputDebugString("3V Card\r\n");
		pwr = 0x0005;
		break;
	case 3:
		KITLOutputDebugString("5V Card\r\n");
		pwr = 0x0009;
		break;
	}

	Tmp = bcsr->pcmcia;
	Tmp &= ~(BCSR_PCMCIA_PC0VPP | BCSR_PCMCIA_PC0VCC) << (8 * SockNum);
	Tmp |= (pwr << (8 * SockNum));
	bcsr->pcmcia = Tmp;
#endif

#if defined(PLATFORM_DB1000) || defined(PLATFORM_DB1500) || defined(PLATFORM_DB1100)
    ULONG vs, pwr, pcmcia;
	BCSR *bcsr = (BCSR *)BCSR_KSEG1_ADDR;

	vs = bcsr->status;
	if (SockNum == 1)
		vs >>= 2;
	vs &= BCSR_STATUS_PC0VS;

	switch (vs)
	{
	case 0:
	case 1:
	case 2:
		KITLOutputDebugString("3V Card\r\n");
		pwr = 0x00000005;
		break;
	case 3:
		KITLOutputDebugString("5V Card\r\n");
		pwr = 0x00000009;
		break;
	}

	pcmcia = bcsr->pcmcia;
	pcmcia &= ~((BCSR_PCMCIA_PC0VPP | BCSR_PCMCIA_PC0VCC) << (SockNum * 8));
	pcmcia |= (pwr << (SockNum * 8));
	bcsr->pcmcia = pcmcia;
#endif

#ifdef PLATFORM_DB1550
    USHORT vs;
    USHORT pwr;
	USHORT Tmp;

	vs = bcsr->status;
	if (SockNum == 1)
		vs >>= 2;
	vs &= 0x0003;

	switch (vs)
	{
	case 0:
	case 1:
	case 2:
		KITLOutputDebugString("3V Card\r\n");
		pwr = 0x0005;
		break;
	case 3:
		KITLOutputDebugString("5V Card\r\n");
		pwr = 0x0009;
		break;
	}

	Tmp = bcsr->pcmcia;
	Tmp &= ~(BCSR_PCMCIA_PC0VPP | BCSR_PCMCIA_PC0VCC) << (8 * SockNum);
	Tmp |= (pwr << (8 * SockNum));
	bcsr->pcmcia = Tmp;
#endif

#ifdef PLATFORM_HYD1100
	// This is done automatically on card detection
#endif

#ifdef PLATFORM_HYDROGEN3
	// This is done automatically on card detection -- FIX!!! No true!!!
#endif
}

VOID
PCMInitialize(
    VOID
    )

/*++

Routine Description:

    Performs hardware initialization required prior to accessing the PCMCIA
    controller.

Arguments:

    None.

Return Value:

    None.

--*/

{
	TLBENTRY t;

    t.PageMask = 0x01ffe000;					// pagemask for 16M pages
	t.EntryHi = PCM_IO0_BASE;
	t.EntryLo0 = 0x3C000017;
	t.EntryLo1 = 0x3C200017;
	TLBWrite(PCM_IO0_TLB_INDEX,&t);

	t.EntryHi = PCM_ATTR0_BASE;
	t.EntryLo0 = 0x3D000017;
	t.EntryLo1 = 0x3D200017;
	TLBWrite(PCM_ATTR0_TLB_INDEX,&t);

	t.EntryHi = PCM_MEM0_BASE;
	t.EntryLo0 = 0x3E000017;
	t.EntryLo1 = 0x3E200017;
	TLBWrite(PCM_MEM0_TLB_INDEX,&t);

    return;
}

BOOLEAN
PCMResetSocket(
    UCHAR SocketNum
    )

/*++

Routine Description:

    This function resets the specified PCMCIA socket.

Arguments:

    SocketNum - Number of the socket to reset.

Return Value:

    TRUE if the socket was successfully reset; FALSE otherwise.

--*/

{
#ifdef PLATFORM_PB1000
    USHORT SockMask;

    if(SocketNum==0) {
        SockMask=0x00ff;
    }
    else {
        SockMask=0xff00;
    }

    ShutDownSocket(SocketNum);

    if(cpld->Status & (CARD_DETECT_MASK&SockMask)) {
        goto ErrorReturn;
    }
    KITLOutputDebugString("PCMCIA: card detected in socket %d\r\n",SocketNum);

    TurnOnSocket(SocketNum);
    PCMSleep(500);

	cpld->Control |= (SOCKET_RESET&SockMask);

    PCMSleep(25);

	cpldControl &= ~(SOCKET_RESET&SockMask);

    PCMSleep(20);

	/* Normally one would check for card READY, but this signal is
	 * not directly visible on the Pb1000. Given the fact it is buried
	 * in the CPLD equation for the IRQ signal, I dont think we can
	 * reliably determine the value!
	 */
	return TRUE;
  ErrorReturn:

    return FALSE;
#endif

#ifdef PLATFORM_PB1500
	AU1X00_GPIO2 *GPIO2Regs = (AU1X00_GPIO2 *)(GPIO2_PHYS_ADDR + KSEG1_OFFSET);

    ShutDownSocket(SocketNum);

	/* Check for Card insertion */
	if (GPIO2Regs->pinstate & GPIO2_GPIO201)
		goto ErrorReturn;

	KITLOutputDebugString("PCMCIA: card detected in socket \r\n");

    TurnOnSocket(SocketNum);
	PCMSleep(500);

	// Ensure in reset
	bcsr->pci_pcmcia &= ~BCSR_PCIPCMCIA_PCRST;

	// Enable buffers
	bcsr->pci_pcmcia |= BCSR_PCIPCMCIA_PCDRVEN;

	PCMSleep(300);

	// Bring out of reset
	bcsr->pci_pcmcia |= BCSR_PCIPCMCIA_PCRST;

	PCMSleep(25);

	/* FIX Should check for card READY */
	return TRUE;

ErrorReturn:
	return FALSE;
#endif

#ifdef PLATFORM_PB1100
    AU1X00_SYS *pGpioRegs = (AU1X00_SYS *)(SYS_PHYS_ADDR + KSEG1_OFFSET);

    ShutDownSocket(SocketNum);

	/* Check for Card insertion */
	if (pGpioRegs->pinstaterd & GPIO_9)
		goto ErrorReturn;

	KITLOutputDebugString("PCMCIA: card detected in socket \r\n");

    TurnOnSocket(SocketNum);
	PCMSleep(500);

	// Ensure in reset
	bcsr->mem_pcmcia &= ~BCSR_MEMPCMCIA_PCRST;

	// Enable buffers
	bcsr->mem_pcmcia |= (1<< 4);   // enable PCMCIA address/control/data buffers

	PCMSleep(300);

	// Bring out of reset
	bcsr->mem_pcmcia |= BCSR_MEMPCMCIA_PCRST;

	PCMSleep(25);

	/* FIX Should check for card READY */
	return TRUE;

	ErrorReturn:
	return FALSE;
#endif

#if defined(PLATFORM_PB1550)
	USHORT t;
	ULONG i, tmp;
	AU1X00_GPIO2 *GPIO2Regs = (AU1X00_GPIO2 *)(GPIO2_PHYS_ADDR + KSEG1_OFFSET);

	/* Check for Card insertion */
	t = bcsr->status;
	t &= (1 << (4 + SocketNum));
	if (t != 0)
		goto ErrorReturn;

	KITLOutputDebugString("PCMCIA: card detected in socket \r\n");

	// Apply power, assert reset, turn on PCMCIA buffers
    TurnOnSocket(SocketNum);
	t = bcsr->pcmcia;
	t &= ~(BCSR_PCMCIA_PC0RST << (SocketNum * 8));
	t |= (BCSR_PCMCIA_PC0DRVEN << (SocketNum * 8));
	bcsr->pcmcia = t;
	PCMSleep(300);

	// Bring out of reset
	t |= (BCSR_PCMCIA_PC0RST << (SocketNum * 8));
	bcsr->pcmcia = t;
	PCMSleep(30);

	/* FIX Should check for card READY */
    for (i=0; i < 2000; i++)
    {
		tmp = GPIO2Regs->pinstate;
		if ((tmp & (1 << (1 + SocketNum))) == 0)
            PCMSleep(50); // Still busy
		else
        {
            KITLOutputDebugString("Card RDY\r\n");
            return TRUE;
        }
    }

	ErrorReturn:
	return FALSE;
#endif

#if defined(PLATFORM_PB1200) || defined(PLATFORM_DB1200) || defined(PLATFORM_DB13XX)
	return PlatCardResetSocket(SocketNum);
#endif

#if defined(PLATFORM_DB1000) || defined(PLATFORM_DB1500) || defined(PLATFORM_DB1100)
	ULONG t;
	BCSR *bcsr = (BCSR *)BCSR_KSEG1_ADDR;
    AU1X00_SYS *pGpioRegs = (AU1X00_SYS *)(SYS_PHYS_ADDR + KSEG1_OFFSET);

    ShutDownSocket(SocketNum);

    PCMSleep(10);

	/* Check for Card insertion */
	t = pGpioRegs->pinstaterd;
	if (SocketNum == 0)
		t &= (1 << 0);
	else
		t &= (1 << 3);
	if (t != 0)
		goto ErrorReturn;

	KITLOutputDebugString("PCMCIA: card detected in socket \r\n");

    TurnOnSocket(SocketNum);
	PCMSleep(500);

	// Ensure in reset
	bcsr->pcmcia &= ~(BCSR_PCMCIA_PC0RST << (SocketNum * 8));

	// Enable buffers
	bcsr->pcmcia |= (BCSR_PCMCIA_PC0DRVEN << (SocketNum * 8));

	PCMSleep(300);

	// Bring out of reset
	bcsr->pcmcia |= (BCSR_PCMCIA_PC0RST << (SocketNum * 8));

	PCMSleep(25);

	/* FIX Should check for card READY */
	return TRUE;

	ErrorReturn:
	return FALSE;
#endif

#if defined(PLATFORM_DB1550)
	USHORT t;

	/* Check for Card insertion */
	t = bcsr->status;
	t &= (1 << (4 + SocketNum));
	if (t != 0)
		goto ErrorReturn;

	KITLOutputDebugString("PCMCIA: card detected in socket \r\n");

	// Apply power, assert reset, turn on PCMCIA buffers
    TurnOnSocket(SocketNum);
	t = bcsr->pcmcia;
	t &= ~(BCSR_PCMCIA_PC0RST << (SocketNum * 8));
	t |= (BCSR_PCMCIA_PC0DRVEN << (SocketNum * 8));
	bcsr->pcmcia = t;
	PCMSleep(300);

	// Bring out of reset
	t |= (BCSR_PCMCIA_PC0RST << (SocketNum * 8));
	bcsr->pcmcia = t;
	PCMSleep(30);

	/* FIX Should check for card READY */
    return TRUE;

	ErrorReturn:
	return FALSE;
#endif

#ifdef PLATFORM_HYD1100
    AU1X00_SYS *pGpioRegs = (AU1X00_SYS *)(SYS_PHYS_ADDR + KSEG1_OFFSET);
	AU1X00_GPIO2 *GPIO2Regs = (AU1X00_GPIO2 *)(GPIO2_PHYS_ADDR + KSEG1_OFFSET);

    // This will set reset
	ShutDownSocket(SocketNum);

	/* Check for Card insertion */
	if (pGpioRegs->pinstaterd & GPIO_22)
		goto ErrorReturn;

	KITLOutputDebugString("PCMCIA: card detected in socket \r\n");

    TurnOnSocket(SocketNum);
	PCMSleep(500);

	// Clear Reset
	GPIO2Regs->output = 0x00010000;
	PCMSleep(500);

	/* FIX Should check for card READY */
	return TRUE;

	ErrorReturn:
	return FALSE;
#endif

#if defined(PLATFORM_HYDROGEN3)
#define PCMCIA_RDY_POLL_INT       50
#define PCMCIA_MAX_RDY_WAIT_TIME  2000
    AU1X00_SYS *pGpioRegs = (AU1X00_SYS *)(SYS_PHYS_ADDR + KSEG1_OFFSET);
	AU1X00_GPIO2 *GPIO2Regs = (AU1X00_GPIO2 *)(GPIO2_PHYS_ADDR + KSEG1_OFFSET);
	int i;

	// Enable power
    KITLOutputDebugString("Enabling power\r\n");
	GPIO2Regs->output = 0x00020002;
	PCMSleep(500);

    // This will set reset
	ShutDownSocket(SocketNum);

	/* Check for Card insertion */
	if (pGpioRegs->pinstaterd & GPIO_22)
		goto ErrorReturn;

	KITLOutputDebugString("PCMCIA: card detected in socket \r\n");


	PCMSleep(500);
    TurnOnSocket(SocketNum);
	PCMSleep(500);

	// Clear Reset
	GPIO2Regs->output = 0x00010000;
	PCMSleep(500);

    for (i=0; i < 2000; i++)
    {
		if ((pGpioRegs->pinstaterd & GPIO_21)==0)
		{
            PCMSleep(50); // Still busy
        }
		else
        {
            KITLOutputDebugString("Card RDY\r\n");
            return TRUE;
        }
    }

	ErrorReturn:
	return FALSE;
#endif

	return FALSE;
}


BOOLEAN
PCMGetStatus(
    IN UCHAR SocketNum,
    OUT PCM_SOCKSTAT *Status
    )

/*++

Routine Description:

    Returns the status of the specified PCMCIA socket.

Arguments:

    SocketNum - Number of the socket for which status is returned.

    Status - A PCM_SOCKSTAT structure that is set with the current status.

Return Value:

    TRUE if the specified PCMCIA socket is occupied; FALSE otherwise

--*/

{
#ifdef PLATFORM_PB1000

    USHORT SockMask;

    if(SocketNum==0) {
        SockMask=0x00ff;
    }
    else {
        SockMask=0xff00;
    }

    if (!(cpld->Status & (CARD_DETECT_MASK&SockMask))) {

        Status->WriteProt = 0;      // Not supported
        Status->BVD1 = 1;           // Not supported
        Status->BVD2 = 1;           // Not supported
        Status->Ready = 1;
        Status->Detect = 1;
    }
    else {

        Status->Detect = 0;
    }

    return TRUE;

#else

	// FIX!!!
    Status->WriteProt = 0;      // Not supported
    Status->BVD1 = 1;           // Not supported
    Status->BVD2 = 1;           // Not supported
    Status->Ready = 1;
    Status->Detect = 1;
	return TRUE;

#endif

	return FALSE;
}


BOOLEAN
PCMRequestIO(
    UCHAR Socket,
    ULONG Base,
    ULONG Size,
    ULONG Width,
    PCM_WINDOW *Window
    )

/*++

Routine Description:

    Allocate an IO Window for the specified Socket and map
    it into the processor address space

    A very simple first-free allocation of available PCMCIA windows is
    performed.

Arguments:

    Socket - The socket number for which the window is allocated
    Base   - The IO Port number base address
    Size   - the size of the window to be mapped
    Width  - Size of data access (8/16 bit)
    Window - Pointer to PCM_WINDOW structure filled in by this function

Return Value:

  	TRUE  - if a window is successfully allocated and mapped
	FALSE otherwise

--*/

{
    if (Window == NULL) {
		return FALSE;                 // major bug.
	}

    if (Socket >= NUM_SOCKETS) {
		return FALSE;			      // Invalid socket number.
	}

    //
    //  Allocate a physical address region for accessing the window.
    //

    if(Base+Size>=PCMCIA_IO_WIN_SIZE) {
        KITLOutputDebugString("We need more IO address space");
        return FALSE;
    }

    if (Socket == 0) {

        if (Base == 0) {

            Window->Base = PcmIO0AllocPtr;
            PcmIO0AllocPtr += Size;
        }
		else {
            Window->Base = PCM_IO0_BASE + Base;
        }
    }
	else {

        if (Base == 0) {
            Window->Base = PcmIO1AllocPtr;
            PcmIO1AllocPtr += Size;
        }
		else {
            Window->Base = PCM_IO1_BASE + Base;
        }
    }

    Window->Offset = 0;                // Undefined for I/O.

    Window->Type = PCMWindowIO;
    Window->Adapter = 0;
    Window->Socket = Socket;
    Window->Window = 0;
    Window->Size = Size;

    return TRUE;

}


BOOLEAN
PCMRequestWindow(
    UCHAR Socket,
    PCM_WINDOWTYPE Type,
    ULONG Base,
    ULONG Offset,
    ULONG Length,
    PCM_WINDOW *Window
    )

/*++

Routine Description:

    Allocate a Memory Window for the specified Socket and map
    it into the processor address space

    A very simple first-free allocation of available PCMCIA windows is
    performed.

Arguments:

    Socket - The socket number for which the window is allocated
    Type   - the window type to setup: Common, or Attribute
    Base   - The host physical address of the window, or zero
    Offset - The memory card offset of the window
    Length - the size of the window to be mapped
    Window - Pointer to PCM_WINDOW structure filled in by this function

Return Value:

    TRUE  - if a window is successfully allocated and mapped
    FALSE otherwise

--*/

{
    if (Window == NULL) {
		return FALSE;               // major bug.
	}

    if (Socket >= NUM_SOCKETS) {
		return FALSE;				// Invalid socket number
	}

    if (Type != PCMWindowCommon &&
		Type != PCMWindowAttribute) {
		return FALSE;
	}

    if(Base+Length>=PCMCIA_CMN_WIN_SIZE) {
        KITLOutputDebugString("We need more Mem/Attr address space");
        return FALSE;
    }


    //
    //  Allocate a physical address region for accessing the window.
    //

    if (Socket == 0) {

        if (Type == PCMWindowAttribute) {

            Window->Base = PCM_ATTR0_BASE;
        }
		else if (Base == 0) {

            Window->Base = PcmMem0AllocPtr;
            PcmMem0AllocPtr += Length;
            Window->Offset = Window->Base - PCM_MEM0_BASE;
        }
		else {

            Window->Base = PCM_MEM0_BASE + Base;
            Window->Offset = Base;
        }
    }
	else {

        if (Type == PCMWindowAttribute) {

            Window->Base = PCM_ATTR1_BASE;
        }
		else if (Base == 0) {

            Window->Base = PcmMem1AllocPtr;
            PcmMem1AllocPtr += Length;
            Window->Offset = Window->Base - PCM_MEM1_BASE;
        }
		else {

            Window->Base = PCM_MEM1_BASE + Base;
            Window->Offset = Base;
        }
    }

    //
    //  Window->Base and Window->Offset have been set. Fill in the remaining
    //  window fields:
    //

    Window->Type = Type;
    Window->Adapter = 0;
    Window->Socket = Socket;
    Window->Window = 0;
    Window->Size = Length;

    return TRUE;

}


VOID
PCMSetIOMode(
    ULONG Socket
	)

/*++

Routine Description:

    Perform any necessary hardware setup to enable IO mode on the specified
    socket.

Arguments:

    Socket - the number of the socket to place in IO mode

Return Value:

    None.

--*/

{
    //
    //  No hardware setup required for I/O mode on the platform.
    //

	return;
}

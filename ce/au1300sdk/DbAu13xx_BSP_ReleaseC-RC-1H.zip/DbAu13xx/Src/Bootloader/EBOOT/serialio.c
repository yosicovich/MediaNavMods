/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.

	byte level I/O functions

    These will be hardware dependant
*/

#include "ldr.h"
#include "platform.h"

/********************************************************************/

// select the debug port here
#ifndef DEBUG_UART_BASE
#define DEBUG_UART_BASE	(UART2_PHYS_ADDR+KSEG1_OFFSET)
#endif

// select baud rate here
#ifndef DEBUG_PORT_BAUDRATE
#define DEBUG_PORT_BAUDRATE 115200
#endif

static AU1X00_UART * const Uart = (AU1X00_UART *)DEBUG_UART_BASE;

/********************************************************************/

void
OEMInitDebugSerial(VOID) //InitIo(void)
{
	ULONG BaudRate = DEBUG_PORT_BAUDRATE;
    ULONG BaudRateDivisor;

	// Enable the UART
	Uart->enable = 0;
	Uart->enable = UART_ENABLE_CE;
	Uart->enable = UART_ENABLE_CE | UART_ENABLE_E;
	Uart->fifoctrl = UART_FIFOCTRL_TFT |
	                 UART_FIFOCTRL_TR |
		             UART_FIFOCTRL_RR |
		             UART_FIFOCTRL_FE;
	Uart->mdmctrl = 0;
	Uart->linectrl = UART_LINECTRL_WLS_8;
	BaudRateDivisor = OEMGetPBUSFrequency() / (16 * BaudRate);
	Uart->clkdiv = BaudRateDivisor;
}

/********************************************************************/

int
putch(char ch)
{
	//
    //	Is it ready for tx?
    //
    while (! (Uart->linestat & UART_LINESTAT_TE))
    {
        ; // spin on it....
    }

    Uart->txdata = ch;

	return ch;
}

/********************************************************************/

char
getch(void)
{
	//
    //	Is there any Rx data?
    //
    while (!(Uart->linestat & UART_LINESTAT_DR))
    {
        ; // spin on it....
    }

    return (char)Uart->rxdata;
}

/********************************************************************/

void
OEMWriteDebugByte(BYTE c)
{
    putch(c);
}

/********************************************************************/

int
OEMReadDebugByte(void)
{
    int RetVal = OEM_DEBUG_READ_NODATA;

    if (Uart->linestat & UART_LINESTAT_DR)
    {
        RetVal = 0xff & Uart->rxdata;
    }

    return RetVal;
}

/********************************************************************/

void
OEMWriteDebugString(unsigned short *str)
{
    while (*str)
    {
        OEMWriteDebugByte((BYTE)*str);
        str++;
    }
}

/********************************************************************/

int CheckForEscape(void)
{
    int Status = FALSE;
    int Ch;

    Ch = OEMReadDebugByte();

    if (OEM_DEBUG_READ_NODATA != Ch)
    {
        Status = (Ch==ASCII_ESC);
    }

    return Status;
}

/********************************************************************/

int
GetchTimeout(int Timeout) // in milliseconds
{
    int RetVal=OEM_DEBUG_READ_NODATA;

    while (Timeout--)
    {
        RetVal=OEMReadDebugByte();
        if (OEM_DEBUG_READ_NODATA != RetVal)
        {
            break;
        }
        OALStallExecution(1000);
    }

    return RetVal;
}

/********************************************************************/


/*
	Copyright (c) 2002 BSQUARE Corporation. All rights reserved.

	BLCOMMON exports. This file maps the blcommon required functions to
    their relevant function in the loader.
    
    Assumning ethernet download initially, will add others later if reqd

    ** Pb1000 does not support FLASH functions **        
*/
#include <windows.h>
#include <halether.h>
#include <platform.h>
#include <blcommon.h>
#include "flash.h"
#include "ldr.h"
#include <bldver.h>


static BOOT_ARGS *pBootArgs = (BOOT_ARGS*)(BOOT_ARG_PTR + KSEG1_OFFSET);
static IMAGE_TYPE g_ImageType = IMAGE_OS_BIN;

#ifdef DEBUG
DBGPARAM dpCurSettings = {
    L"Undefined",
    {L"Undefined",   L"Undefined",   L"Undefined",   L"Undefined",
     L"Undefined",   L"Undefined",   L"Undefined",   L"Undefined",
     L"Undefined",   L"Undefined",   L"Undefined",   L"Undefined",
     L"Undefined",   L"Power",       L"Warning",     L"Error",
    },
    0xC000
};
#endif  // DEBUG


// mask for cache bit - bit 29
#define KSEG_BIT_MASK  0x1FFFFFFF

//
// Download funcs
//
BOOL OEMReadData (
DWORD cbData,
LPBYTE pbData
)
{
    return EbootEtherReadData(cbData, pbData);
}


void
OEMShowProgress(DWORD dwPacketNum)
{
#ifdef PLATFORM_OEMSHOWPROGRESS_CODE
	PLATFORM_OEMSHOWPROGRESS_CODE
#endif
}

/*
    @func   BOOL | OEMVerifyMemory | Verify that the memory to be used by the downloaded BIN file is valid.  This function also decides whether the image is the
                                         bootloader or not based on its address (this information is used later when deciding how to store the image in flash).
    @rdesc  TRUE = Address specified is valid memory, FALSE = Address specified is *not* valid memory.
    @comm
    @xref
*/
BOOL OEMVerifyMemory(DWORD dwStartAddr, DWORD dwLength)
{
        // Is the image being downloaded the bootloader or an OS image?
        if ((dwStartAddr >= EBOOT_STORE_ADDRESS) &&
                ((dwStartAddr + dwLength - 1) < (EBOOT_STORE_ADDRESS + EBOOT_STORE_MAX_LENGTH)))
        {
                KITLOutputDebugString("\r\n****** Downloading a bootloader image ******\r\n\r\n");
                g_ImageType = IMAGE_LOADER;             // Bootloader image.
        }

        return(TRUE);
}

BOOL OEMDebugInit(void)
{
	// We've already initialized the UART in the loader startup code.
	//
	g_pOEMVerifyMemory   = OEMVerifyMemory;
#if (CE_MAJOR_VER == 4) && (CE_MINOR_VER > 10)

	g_pOEMCheckSignature = NULL;
	g_pOEMMultiBINNotify = NULL;
#endif

    return(TRUE);
}


BOOL OEMPlatformInit(void)
{
    // Call CLI main entrypoint - it will return if the CLI is not selected.
    //
    climain(HEAP_BASE,
			HEAP_SIZE,
			0,
			0);
    
    return(TRUE);
}

/*
    Initialise the download
    This is setup for Ethernet now, but may include:
    ATA card, IDE and flash soon.
*/
DWORD OEMPreDownload (void)
{

    return OEMEthernetPreDownload();

}

void OEMLaunch (
    DWORD dwImageStart,
    DWORD dwImageLength,
    DWORD dwLaunchAddr,
    const ROMHDR *pRomHdr
)
{

	if (dwLaunchAddr)
	{
		pBootArgs->dwLaunchAddr = dwLaunchAddr;
	}
	else
	{
		dwLaunchAddr = pBootArgs->dwLaunchAddr;
	}


    OEMEthernetLaunch(
        dwImageStart,
        dwImageLength,
        dwLaunchAddr,
        pRomHdr    
        );
            
}


//
// Flash Funcs
//
BOOL OEMIsFlashAddr(DWORD dwAddr)
{
    // Mask kseg bits
    //
    dwAddr &= KSEG_BIT_MASK;
    
    if ((dwAddr >= FLASH_BASE) && 
        (dwAddr < (FLASH_BASE + FLASH_SIZE))) {
        return TRUE;
    } else {
        return FALSE;
    }
    
}

LPBYTE OEMMapMemAddr(DWORD dwImageStart, DWORD dwAddr)
{
    LPBYTE ptr;
    
    if (OEMIsFlashAddr(dwAddr))
	{
        // Cache the image at a RAM address before it's written to flash.
        // 
        ptr = (LPBYTE)((dwAddr - dwImageStart) + DEFAULT_DOWNLOAD_ADDRESS);
        
    } else
	{
        ptr = (LPBYTE)dwAddr;
    }
    
    return(ptr);
}

BOOL OEMStartEraseFlash(DWORD dwStartAddr, DWORD dwLength)
{

	return(TRUE);
}

void OEMContinueEraseFlash(void)
{

	return;
}

BOOL OEMFinishEraseFlash(void)
{
	KITLOutputDebugString("OEMFinishEraseFlash\r\n");
    return(TRUE);
}


BOOL OEMWriteFlash(DWORD dwStartAddr, DWORD dwLength)
{
	KITLOutputDebugString("Writing image to FLASH (src 0x%x, dest 0x%x, len 0x%x)...\r\n", DEFAULT_DOWNLOAD_ADDRESS,
					(dwStartAddr & KSEG_BIT_MASK) - FLASH_BASE,
					dwLength);
    ldr_WriteFlash((dwStartAddr & KSEG_BIT_MASK) - FLASH_BASE,
					(PVOID)DEFAULT_DOWNLOAD_ADDRESS,
					dwLength,
					TRUE);
     
    if (g_ImageType == IMAGE_LOADER)
    {
        KITLOutputDebugString("\r\n*** Bootloader updated - please reboot system. ***\r\n");
        while(1)
            ;
    }
   
    return(TRUE);
}





//
// Timer funcs
// see timers.c
//

extern DWORD OEMEthGetSecs (void);


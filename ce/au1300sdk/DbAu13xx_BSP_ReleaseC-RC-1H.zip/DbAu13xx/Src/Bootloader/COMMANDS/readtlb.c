/*******************************************************************
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.
 ******************************************************************/

#include "ldr.h"


char readTlbHelp[] = 
    "displays the tlb entries \r\n";
    
int
ReadTLB(int argc, char* argv[])
{
	unsigned int i;
    TLBENTRY TlbEntry;
    
    for (i=0;i<32;i++) {
    	TLBRead(i, &TlbEntry);


        KITLOutputDebugString("Entry no:%d\r\n", i);
        KITLOutputDebugString("EntryLo0= %X\r\n", TlbEntry.EntryLo0);
        KITLOutputDebugString("EntryLo1= %X\r\n", TlbEntry.EntryLo1);
        KITLOutputDebugString("EntryHi = %X\r\n", TlbEntry.EntryHi);
        KITLOutputDebugString("PageMask= %X\r\n", TlbEntry.PageMask);
        
    }


return ERROR_SUCCESS;
}



char writeTlbHelp[] = 
    "tlbwrite <entrylo0> <entrylo1> <entryhi> <pagemask> <index> \r\n";


int
WriteTlb(int argc, char* argv[])
{
    TLBENTRY TlbEntry;
    unsigned long index;
    int ErrorCode = ERROR_SUCCESS;    

    if (argc < 5) {
        KITLOutputDebugString("Missing args\r\n");
        ErrorCode = ERROR_BADARG;
        goto ErrorReturn;
    }
    
    if (!strtohex(argv[1], &TlbEntry.EntryLo0)) {
        ErrorCode = ERROR_BADARG;
        goto ErrorReturn;
    }
    
    if (!strtohex(argv[2], &TlbEntry.EntryLo1)) {
        ErrorCode = ERROR_BADARG;
        goto ErrorReturn;
    }
    if (!strtohex(argv[3], &TlbEntry.EntryHi)) {
        ErrorCode = ERROR_BADARG;
        goto ErrorReturn;
    }
    if (!strtohex(argv[4], &TlbEntry.PageMask)) {
        ErrorCode = ERROR_BADARG;
        goto ErrorReturn;
    }

    if (!strtohex(argv[5], &index)) {
        ErrorCode = ERROR_BADARG;
        goto ErrorReturn;
    }

    TLBWrite(index, &TlbEntry);

    KITLOutputDebugString("EntryLo0= %X\r\n", TlbEntry.EntryLo0);
    KITLOutputDebugString("EntryLo1= %X\r\n", TlbEntry.EntryLo1);
    KITLOutputDebugString("EntryHi = %X\r\n", TlbEntry.EntryHi);
    KITLOutputDebugString("PageMask= %X\r\n", TlbEntry.PageMask);
    KITLOutputDebugString("index = %d\r\n", index);


ErrorReturn:    
    return ErrorCode;
}
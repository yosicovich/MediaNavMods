/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.

	Jump cmd
*/

#include "ldr.h"


char jumpHelp[] = 
    "Syntax jump addr\r\n\
    \taddr - address to branch to\r\n";

int
Jump(int argc, char *argv[])
{
    void (*ptr)(int, char **);

    if (2==argc) {
	    
        if (strtohex(argv[1], (int*)&ptr)) {
        
            KITLOutputDebugString("Jumping to %X\r\n", ptr);
            (*ptr)(argc, argv);
        }
    }
   
    KITLOutputDebugString("%s",jumpHelp);
   
    
    
return ERROR_FAILURE;	
}
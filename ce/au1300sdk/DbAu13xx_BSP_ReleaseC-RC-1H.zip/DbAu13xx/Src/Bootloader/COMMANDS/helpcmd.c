/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.

	Generic help command
*/

#include "ldr.h"


char helpHelp[] = 
    "Syntax help <cmd>\r\n\
    \tcmd - show help text for command <cmd>\r\n";

int
Help(int argc, char *argv[])
{
    int CmdNum=0;
    int argNum=1;
    const char *ptr;
    

    if (1==argc) {
        KITLOutputDebugString(helpHelp);
        
        //
        // List cmds
        //
        while(NULL != (ptr=GetCmdName(CmdNum++))) {
            KITLOutputDebugString("%s\r\n",ptr);
        } 
    }
    
    //
    //  Search command list for all cmds on CL
    //
    while (argc > argNum) {
        
        CmdNum = SearchForCmd(argv[argNum++]);
        if (ERROR_NOTFOUND != CmdNum) {
            //
            // Disply help string
            //
            KITLOutputDebugString("%s", GetCmdHelpText(CmdNum));
        }        
    }
    
return ERROR_SUCCESS;	
}
/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.
    
    m-system DOC view
    
    
*/

#include "ldr.h"


char msysHelp[] = 
    "Syntax dm <AAAAAAAA> <LLLLLL>\r\n\
    \tdump memory from <AAAAAAAA> for <LLLLLL> bytes\r\n";




int
Msys(int argc, char *argv[])
{
    int ErrorCode = ERROR_SUCCESS;
	unsigned int Len;
    unsigned int Addr;
    unsigned int i;
    unsigned char Ch;
    unsigned long Tmp;
	PUCHAR j;
    
    
    if (argc < 3) {
        ErrorCode = ERROR_MISSINGARGS;
        goto ErrorReturn;        
    }    
    

    if (!strtohex(argv[1], &Addr)) {
        ErrorCode = ERROR_BADARG;
        goto ErrorReturn;
    }
    
    if (!strtohex(argv[2], &Len)) {
        ErrorCode = ERROR_BADARG;
        goto ErrorReturn;
    }
    
    KITLOutputDebugString("Dump Memory Start= %s (%X) len=%s (%d)\r\n",
            argv[1], Addr,
            argv[2], Len);
    
    
  
    Addr &= ~0xf;
   	for (i=0;i<Len;i+=16) {
       
        KITLOutputDebugString("\r\n%X: ", Addr);


        for (j = (PUCHAR)Addr; j < (PUCHAR)(Addr  + 16) ; j++) {
            Tmp = *j;
            KITLOutputDebugString("%B ", Tmp);
        }

        // now print chars
        for (j = (PUCHAR)Addr; j < (PUCHAR)(Addr  + 16) ; j++) {
            Ch = *j;

			if (Ch < 32 || Ch > 125) {
                Ch = '.';
            }

            KITLOutputDebugString("%c",Ch);            
        }
                
        Addr +=16;
    }
    
   	KITLOutputDebugString("\r\nOk\r\n");
   
   
ErrorReturn:
	return ErrorCode;

}
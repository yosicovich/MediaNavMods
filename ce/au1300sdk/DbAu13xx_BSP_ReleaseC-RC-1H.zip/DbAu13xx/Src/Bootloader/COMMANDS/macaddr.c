/*
/*++
Copyright (c) 2001 BSQUARE Corporation. All rights reserved.

Module:

    ebootcmd.c

Description:

	boot using the host eshell
    
Authors:

    GJS May 2001

Revision History

--*/

#include "ldr.h"
#include "ldrarg.h"
#include "flash.h"
#include "macaddr.h"


//
//  Private
//
static  int MACNumber;
static unsigned char DummyMac[6];
static unsigned char *pMAC=DummyMac;
static BOOL  ProgramMac=FALSE;
static BOOL EraseAddr=FALSE;
    
char MacAddrCmdHelp[] = 
    "Syntax macaddr -m<MAC#> -a<addr>\r\n\
    \tm - MAC number to display (0 or 1) 0==default\r\n\
    \ta - set address for MAC\r\n\
    \te - erase address for MAC !!WARNING this will erase theentire sector!!\r\n\
    \tEG macaddr -m0 -a005c00112220\r\n";



static int MacStringToArray(
    unsigned char *String,
    unsigned char MacArray[6]
)
{
    int i;
    char Tmp;
    int RetVal = TRUE;
    
    for (i=0;i<12;i+=2) {

    
        Tmp = String[i];
        if (Tmp >= 97)
            Tmp=Tmp-97+10;
        else if (Tmp >= 65)
            Tmp=Tmp-65+10;
        else 
            Tmp=Tmp-48;
            
        if ((Tmp < 16) && (Tmp>=0)) {
            MacArray[i/2]=Tmp<<4;
            
        } else {
            RetVal = FALSE;
            break;
        }
        
        
        Tmp = String[i+1];
        if (Tmp >= 97)
            Tmp=Tmp-97+10;
        else if (Tmp >= 65)
            Tmp=Tmp-65+10;
        else 
            Tmp=Tmp-48;
            
        if ((Tmp < 16) && (Tmp>=0)) {
            MacArray[i/2]|=Tmp;
        } else {
            RetVal = FALSE;
            break;
        }                
    }
    
return RetVal;
}


static void
ParseArg(
    char *Arg    
)
{

    switch (*Arg++) {
        case 'm':
            if (*Arg == '1') {
                MACNumber = 1;
            } 
            
        break;
        case 'a':
            if (MacStringToArray(Arg, pMAC)) {
                ProgramMac = TRUE;
            } else {
                KITLOutputDebugString("Bad MAC address\r\n");
            }
        break;
        case 'e':
            EraseAddr = TRUE;
        break;
            
        default:
        break;
    }   
}

int
MacAddrCmd(int argc, char *argv[])
{
    int i,j;
    char InArg;
    unsigned int MACLo, MACHi;
    
    
    
    MACNumber = 0;
    pMAC=DummyMac;
    ProgramMac=FALSE;
    EraseAddr=FALSE;

    if (argc > 1) {
        
        i=1;
        j=0;
        InArg=FALSE;
        
        while (i < argc) {
        
            switch (argv[i][j]) {
                case '-':
                case '/':
                    j++;
                    InArg=TRUE;
                break;
                case '\0':
                    j=0;
                    i++;
                    InArg=FALSE;
                break;
                default:
                    if (InArg) {
                        ParseArg(&argv[i][j]);
                        InArg=FALSE;
                        j=0;
                        i++;
                    } else {
                        j++;
                    }
                
            }
        }
    }
    
    // Erase the block
    if (EraseAddr) {
        ldr_EraseFlash(MAC_ADDR_BASE-FLASH_BASE, 16, TRUE);
    }
    
    if (ProgramMac) {
        MACLo = (pMAC[5] << 8) | (pMAC[4] << 0);
        MACHi = (pMAC[3] << 24) | (pMAC[2] << 16) | (pMAC[1] << 8) | (pMAC[0] << 0);

        KITLOutputDebugString("MAC Addr %d = %B:%B:%B:%B:%B:%B\r\n",
            MACNumber,
            pMAC[0], 
            pMAC[1],
            pMAC[2],
            pMAC[3],
            pMAC[4],
            pMAC[5]);
                    

        

        // Write to flash
//        ldr_WriteFlash((MACNumber*8)+4+MAC_ADDR_BASE-FLASH_BASE, &pMAC, 16, FALSE);
//        ldr_WriteFlash((MACNumber*8)+4+MAC_ADDR_BASE-FLASH_BASE, &MACHi, 4, FALSE);
        ldr_WriteFlash32((MACNumber*8)+4+MAC_ADDR_BASE-FLASH_BASE, MACLo);
        ldr_WriteFlash32((MACNumber*8)+MAC_ADDR_BASE-FLASH_BASE, MACHi);

        
        
    } else {

        pMAC =  (char*)((MACNumber*8)+MAC_ADDR_BASE+KSEG1_OFFSET);
        KITLOutputDebugString("MAC Addr %d = %B:%B:%B:%B:%B:%B\r\n",
            MACNumber,
            pMAC[0], 
            pMAC[1],
            pMAC[2],
            pMAC[3],
            pMAC[4],
            pMAC[5]);
        
        KITLOutputDebugString("Physical base location of MAC address: 0x%X\r\n",
            MAC_ADDR_BASE);
    }
    
return ERROR_SUCCESS;	
}
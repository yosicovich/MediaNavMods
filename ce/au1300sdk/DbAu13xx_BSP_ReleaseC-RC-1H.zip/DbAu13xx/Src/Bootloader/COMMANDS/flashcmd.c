/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.
    
    Flash access commands
    
	GJS - Late 2001    
*/

#include "ldr.h"
#include "flash.h"

char flashHelp[] = 
    "Syntax:  flash:  \r\n\
    \t flash erase  <flashaddressoffset> <size>   \r\n\
    \t flash write  <flashaddressoffset> <32-bit data> \r\n\
    \t flash memcpy <-e> <Target Flash Offset> <Source Address> <size> \r\n\
	\t example: flash write 40 10 \r\n\
    \t -e will erase before write\r\n\
    \t -i Flash info\r\n";
    
    
    
    
static void 
DisplayFlashInfo(
    void
)
{
    KITLOutputDebugString("\r\nDisplay Flash Info:\r\n");
    KITLOutputDebugString("Flash Physical Base Address: 0x%x\r\n", FLASH_BASE);
    KITLOutputDebugString("Flash Physical Size: 0x%x\r\n", FLASH_SIZE);
    KITLOutputDebugString("Flash Offset to Boot Vector: 0x%x\r\n", BOOT_VECTOR_OFFSET);
    
    
}



static char
ParseArg(
    int Argc,
    char *Argv[]
)
{
    unsigned long Offset;
    unsigned long Size;
    unsigned long Data;
    unsigned char *Buffer;
    unsigned char arg=1;
    char Completion=TRUE;
    char Erase = FALSE;
    char RetVal = 0;
    

    
    if (!strcmp(Argv[0], "-i")) {
        DisplayFlashInfo();
        RetVal=1;
        goto ErrorReturn;
    }
                
    if (!strcmp(Argv[0], "erase")) {
    

        if (Argc > 2) {

            if (!strcmp(Argv[arg], "-c")) {
                Completion = FALSE;
                arg++;            
            }


            
            if (!strtohex(Argv[arg++], &Offset)) {
                KITLOutputDebugString("ERROR: Failed to convert parameter Offset\r\n");
                goto ErrorReturn;
            }
            
            if (!strtohex(Argv[arg++], &Size)) {
                KITLOutputDebugString("ERROR: Failed to convert parameter Size\r\n");
                goto ErrorReturn;
            }


            KITLOutputDebugString("Erasing Flash: Offset 0x%x, Size 0x%x\r\n",
                    Offset,
                    Size);

            RetVal = ldr_EraseFlash(Offset, Size, Completion);
        }
        

    } else if (!strcmp(Argv[0], "memcpy")) {
    
        if (Argc > 3) {
            if (!strcmp(Argv[arg], "-e")) {
                Erase = TRUE;
                arg++;            
            }
        
            if (!strtohex(Argv[arg++], &Offset)) {
                KITLOutputDebugString("ERROR: Failed to convert parameter Offset\r\n");
                goto ErrorReturn;
            }


            if (!strtohex(Argv[arg++], (unsigned int*)&Buffer)) {
                KITLOutputDebugString("ERROR: Failed to convert parameter SourceBuffer\r\n");
                goto ErrorReturn;
            }
            
            if (!strtohex(Argv[arg++], &Size)) {
                KITLOutputDebugString("ERROR: Failed to convert parameter Size\r\n");
                goto ErrorReturn;
            }
            RetVal = ldr_WriteFlash(Offset, Buffer, Size, Erase);
        }
    
    
    } else if (!strcmp(Argv[0], "write")) {

        if (Argc > 2) {
            if (!strtohex(Argv[arg++], &Offset)) {
                KITLOutputDebugString("ERROR: Failed to convert parameter Offset\r\n");
                goto ErrorReturn;
            }
            
            if (!strtohex(Argv[arg++], &Data)) {
                KITLOutputDebugString("ERROR: Failed to convert parameter Data\r\n");
                goto ErrorReturn;
            }
            

            RetVal = ldr_WriteFlash32(Offset, Data);
        }
    } else if (!strcmp(Argv[0], "wait")) {
    
        if (Argc > 1) {
            if (!strtohex(Argv[arg++], &Offset)) {
                KITLOutputDebugString("ERROR: Failed to convert parameter Offset\r\n");
                goto ErrorReturn;
            }


            RetVal = ldr_WaitForEraseComplete(Offset);
        }
    
    
    } else {
        KITLOutputDebugString("Error: Cmd not found\r\n");
        KITLOutputDebugString("%s",flashHelp);
    }
    
ErrorReturn:

    return RetVal;  
}


int
FlashCmd(int argc, char *argv[])
{
    int ErrorCode = ERROR_SUCCESS;

    //
    // 
    //
    if (argc > 1) {
        if (!ParseArg(argc, &argv[1])) {
            KITLOutputDebugString("Error executing cmd.\r\n");
            ErrorCode = ERROR_FAILURE;
        }
        
        
    } else {
        KITLOutputDebugString("%s", flashHelp);
    }
    

return ErrorCode;
}
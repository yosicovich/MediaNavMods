/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.
    
    Memory access commands
    
    
*/

#include "ldr.h"


char writeHelp[] = 
    "Syntax write [-8|16|32] <addr> <Val> [count]\r\n\
    \tWrite  <Val> at address <addr>\r\n\
    \t-8|16|32 specifies access width. 32 is default\r\n\
    \tcount repeats the write to the consecutive [count] locations \r\n";

char readHelp[] = 
    "Syntax read [-8|16|32] <addr> [count]\r\n\
    \tRead  <Val> from address <addr>\r\n\
    \t-8|16|32 specifies access width. 32 is default\r\n\
    \tcount repeats the read from the consecutive [count] locations \r\n";


int
ReadValue(int argc, char *argv[])
{
    int ErrorCode = ERROR_SUCCESS;
    ULONG Addr;
    ULONG Value;
    int Size;
    int Width=4;
    int i=1;
    
        
    if (argc < 2) {
        ErrorCode = ERROR_MISSINGARGS;        
        goto ErrorReturn;        
    }


    while ((i < argc) && argv[i][0] == '-') {
        // is a switch, parse it.
        if (argv[i][1] == '8') {
            // bytes
            Width = 1;
        }
        if (argv[i][1] == '1') {
            // words
            Width = 2;
        }
        i++;        
    }

    if (!strtohex(argv[i], (int*)&Addr)) {
        ErrorCode = ERROR_BADARG;
        goto ErrorReturn;
    }
    
    if (((4==Width) && (Addr & 3)) ||
        ((2==Width) && (Addr & 1))) {
        KITLOutputDebugString(" Unaligned Address\r\n");
        ErrorCode = ERROR_UNALIGNEDACCESS;
        goto ErrorReturn;
    }


    if ((i + 1) < argc) {
        if (!strtohex(argv[i+1], (int*)&Size)) {
            ErrorCode = ERROR_BADARG;
            goto ErrorReturn;
        }
    } else {
        Size = 1;
    }

    KITLOutputDebugString("\r\n");        
    
    for (i=0;i<Size;i += Width) {
        switch (Width) {
        case 4:
            Value = *(PULONG)(Addr + i);
            KITLOutputDebugString("%X:%X",(Addr+i), Value);
			break;
        case 2:
            Value = *(PUSHORT)(Addr + i);
            KITLOutputDebugString("%X:%H",(Addr+i), Value);
			break;
        case 1:
            Value = *(PUCHAR)(Addr + i);
            KITLOutputDebugString("%X:%B",(Addr+i), Value);
			break;
        }
        KITLOutputDebugString("\r\n");        
    }
    
    KITLOutputDebugString("\r\nOk");
    
    
ErrorReturn:
    return ErrorCode;	
}

int
WriteValue(int argc, char *argv[])
{
    int ErrorCode = ERROR_SUCCESS;
    ULONG Addr;
    ULONG Value;
    int Iterations;
    int Width=4;
    int i=1;
    
    if (argc < 2) {
        ErrorCode = ERROR_MISSINGARGS;        
        goto ErrorReturn;        
    }


    while ((i < argc) && argv[i][0] == '-') {
        // is a switch, parse it.
        if (argv[i][1] == '8') {
            // bytes
            Width = 1;
        }
        if (argv[i][1] == '1') {
            // words
            Width = 2;
        }
        i++;        
    }

    if (!strtohex(argv[i], &Addr)) {
        ErrorCode = ERROR_BADARG;
        goto ErrorReturn;
    }
    
    if (((4==Width) && (Addr & 3)) ||
        ((2==Width) && (Addr & 1))) {
        KITLOutputDebugString(" Unaligned Address\r\n");
        ErrorCode = ERROR_UNALIGNEDACCESS;
        goto ErrorReturn;
    }

    // get the value if it exists
    if ((i+1) < argc) {
        if (!strtohex(argv[i+1], &Value)) {
            ErrorCode = ERROR_BADARG;
            goto ErrorReturn;
        }    
    } else {
        ErrorCode = ERROR_MISSINGARGS;        
        goto ErrorReturn;    
    }

    // set the iteration count, or default to 1    
    if ((i+2) < argc) {
        if (!strtohex(argv[i+2], &Iterations)) {
            ErrorCode = ERROR_BADARG;
            goto ErrorReturn;
        }
    } else {
        Iterations = 1;
    }

    KITLOutputDebugString("Write %x starting @ 0x%x for %u words\r\n", 
            Value,
            Addr,
            Iterations);
            
    for (i=0; i<Iterations; i+=Width) {
        switch (Width) {
        case 4:
            *(PULONG)(Addr + i) = Value;
			break;
        case 2:
            *(PUSHORT)(Addr + i) = (USHORT)Value;
			break;
        case 1:
            *(PUCHAR)(Addr + i) = (UCHAR)Value;
			break;
        }
    }
    
    KITLOutputDebugString("\r\nOk");
    
    
ErrorReturn:
    return ErrorCode;	
}
/*++
Copyright (c) 2001, 2003  BSQUARE Corporation.  All rights reserved.

Module Name:

    perreg.c

Module Description:

    This file contains the implementation of persistent registry on flash
                
Author:
    Anil Hashia 8th-Oct-2001

Revision History:
                        
--*/


#include "ldr.h"
#include "flash.h"
#include "platform.h"  // platform specific header file

// Persistent Registry Help
char perregHelp[] = 
    "Syntax:  perreg:  \r\n\
    \t perreg -erase  <Erase Persistent Registry>   \r\n\
    \t perreg -detail <Show details of registry size and location>   \r\n\
    \t perreg -dump <dump registry>";
    
    


char  CheckArguments(unsigned char ArgCount, unsigned char ValidArgCount);
void DisplayDetailsAboutPersistentRegistry(); // display details about persistent registry
        


//////////////////implemented in cli\common\ldrflash\flash.c//////////////////
extern BYTE GetStartingSector(DWORD dwMemLocation);
extern BYTE GetNumberOfSectors(DWORD dwMemLocation,DWORD dwLength);
extern BOOL EraseSectorWithCompletion(BYTE bSector);

   



/*++
Routine Description:
        BOOL EraseFlashForRegistry(DWORD dwEraseAddress,DWORD dwEraseSizeDw)

        Routine for erasing flash for storing persistent registry
        Note: erase operation is sector wise. so whole sector will be erased in which the specified
        flash location lies 
                
Arguments:
        DWORD dwEraseAddress // specifies start erase address
        DWORD dwEraseSizeDw //  specifies address range to be erased
                        
Return Value:
        TRUE to indicate erase has been successful
        
--*/



/*++
Routine Description:
    ErasePersistentRegistry()

 Arguments:NONE
Return Value:NONE
            
--*/

// erase the  Persistent Registry from flash sectors 8 and 9
void ErasePersistentRegistry()
{
    ldr_EraseFlash(REGISTRY_FLASH_START_ADDRESS-FLASH_BASE_KSEG1,REGISTRY_SIZE_MAX,TRUE);

}

/*++
Routine Description:
        BOOL CheckArguments(BYTE bArgCount,BYTE bValidArgCount)
        Check to see if command line arguments for persistent registry are valid
            
Arguments:
        BYTE bArgCount      count from the command line passed arguments
        BYTE bValidArgCount valid count
        
                  
Return Value:
        TRUE to indicate success
        FALSE failure the argument count is not equal to expected argument count
        
--*/

// Test to see if command line arguments are valid
char CheckArguments(
    unsigned char bArgCount,
    unsigned char bValidArgCount
    )
{
    char bRetValue;

    if (bArgCount !=bValidArgCount){
        bRetValue=TRUE;
        KITLOutputDebugString("%s \r\n", perregHelp);
    } else {
        bRetValue=FALSE;
    }

    return bRetValue;
}


void
DumpRegistry(
    void
)
{
    unsigned short *RegShortPtr;
    PFLASHREG_HDR sFlashHdr;// pointing to flash header stored in beginning
    unsigned char *FlashData;
    unsigned long Checksum = 1;
    unsigned long i;


    // read the flash header
    sFlashHdr = (PFLASHREG_HDR)(REGISTRY_FLASH_START_ADDRESS);


    KITLOutputDebugString("Persistent Registry Implemented on Flash \r\n");
    KITLOutputDebugString("Start Address   0x%x  REGISTRY_SIZE_MAX 0x%x \r\n",REGISTRY_FLASH_START_ADDRESS,REGISTRY_SIZE_MAX);
    KITLOutputDebugString("Registry size actual: 0x%x\r\n", sFlashHdr->dwLength);

            
   

    KITLOutputDebugString("Flash Header:: Data Length 0x%x CheckSum 0x%x \r\n",sFlashHdr->dwLength,sFlashHdr->dwCheckSum);
    
    if (ERASEFLASHLOCATIONVALUE == sFlashHdr->dwLength) {
        KITLOutputDebugString("INVALID Registry Data ! \r\n");
    } else {
        //
        // Validate checksum
        //
        FlashData = (unsigned char*)(REGISTRY_FLASH_START_ADDRESS+REGISTRY_FLASH_HEADER_SIZE);

        for (i=0; i< sFlashHdr->dwLength; i++) {
                Checksum += FlashData[i];
        }

        if (sFlashHdr->dwCheckSum != Checksum)
        {
            KITLOutputDebugString("Registry Data checksum failure.\r\n");
            
           
        } else {
            KITLOutputDebugString("VALID Registry Data. Registry will be loaded from flash \r\n");
            RegShortPtr = (unsigned short *)FlashData;
            for (i=0; i<sFlashHdr->dwLength; i+=2) {
                if (NULL == RegShortPtr) {
                    KITLOutputDebugString("\r\n");
                } else {
                    KITLOutputDebugString("%c",*RegShortPtr);
                }
                RegShortPtr++;        
            }

        }
    }
        
}

/*++
Routine Description:
        void DisplayDetailsAboutPersistentRegistry()
        Displays details about persistent registry on Flash
            
Arguments:NONE
        
                  
Return Value:NONE
        
--*/
void 
DisplayDetailsAboutPersistentRegistry(
    void
    )
{
    PFLASHREG_HDR sFlashHdr;// pointing to flash header stored in beginning
    unsigned char *FlashData;
    unsigned long Checksum = 1;
    unsigned long i;


    // read the flash header
    sFlashHdr = (PFLASHREG_HDR)(REGISTRY_FLASH_START_ADDRESS);


    KITLOutputDebugString("Persistent Registry Implemented on Flash \r\n");
    KITLOutputDebugString("Start Address   0x%x  REGISTRY_SIZE_MAX 0x%x \r\n",REGISTRY_FLASH_START_ADDRESS,REGISTRY_SIZE_MAX);
    KITLOutputDebugString("Registry size actual: 0x%x\r\n", sFlashHdr->dwLength);

            
   

    KITLOutputDebugString("Flash Header:: Data Length 0x%x CheckSum 0x%x \r\n",sFlashHdr->dwLength,sFlashHdr->dwCheckSum);
    
    if (ERASEFLASHLOCATIONVALUE == sFlashHdr->dwLength) {
        KITLOutputDebugString("INVALID Registry Data ! \r\n");
    } else {
        //
        // Validate checksum
        //
        FlashData = (unsigned char*)(REGISTRY_FLASH_START_ADDRESS+REGISTRY_FLASH_HEADER_SIZE);

        for (i=0; i< sFlashHdr->dwLength; i++) {
                Checksum += FlashData[i];
        }

        if (sFlashHdr->dwCheckSum != Checksum)
        {
            KITLOutputDebugString("Registry Data checksum failure.\r\n");
            
           
        } else {

            KITLOutputDebugString("VALID Registry Data. Registry will be loaded from flash \r\n");
        }
    }

    
}




/*++
Routine Description:
        int PerReg(int argc, char *argv[])

            
Arguments:
        int argc        Argument count
        char *argv[]    Argument list   
        
                  
Return Value:
        TRUE to indicate  success
        FALSE to indicate failure 
        
--*/
int 
PerReg(
    int argc, 
    char *argv[]
    )
{


    if (argc==1){
        KITLOutputDebugString("%s \r\n", perregHelp);

        return FALSE;  
    }


    // Test for -erase command
    if (strcmp(argv[1],"-erase")==0){

        if(CheckArguments(argc,2)) {
            return FALSE;       
        }

        KITLOutputDebugString("Erasing Persistent Registry On Flash \r\n"); 
        ErasePersistentRegistry();
        KITLOutputDebugString("Persistent Registry Erased ! \r\n"); 
        
        return 1;
            
    }

    // Test for -erase command
    if (strcmp(argv[1],"-dump")==0){

        DumpRegistry();
        
        return 1;
            
    }
    // test for persistent registry -detail command
    // default
    //
    DisplayDetailsAboutPersistentRegistry();
    

    return 1;
}



/*

    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.
    
    Initialize the M-Systems DOC is present
    
    
*/

#include "ldr.h"

volatile unsigned *rs   = (unsigned *)0xb4001000;
#define RS_Config_2 rs[0x20/4]
#define RS_Timing_2 rs[0x24/4]

#define brdcfg	(*(volatile long *)0xae00000c)
#define dccfg	(*(volatile short *)0xb8100000)

#define DTYPE short
#define DSIZE 2
volatile DTYPE    *msys = (DTYPE *)0xb8000000;
#define MSYS_PowerUp msys[0x1FFE/DSIZE]
#define MSYS_Control msys[0x1006/DSIZE]
#define MSYS_Confirm msys[0x1076/DSIZE]
#define MSYS_ID      msys[0x1000/DSIZE]
#define MSYS_Toggle  msys[0x1046/DSIZE]


char msysHelp[] = 
    "Display [setuptlb]\r\n\
    \tany extra arg causes tlb setup\r\n";



int		delay(int n)
{
	int		i;

	i = 0;
	while( n-- > 0 )
		i += (*(volatile long *)0xbfc00000);
	return i;
}

int
msysCmd(int argc, char *argv[])
{
  unsigned save_rs_config, save_rs_timing;

  int i, tog[3];
  int  rc=0;
  DTYPE data;

  save_rs_config = RS_Config_2;
  save_rs_timing = RS_Timing_2;
  RS_Config_2 = 0x00000040;
//  RS_Timing_2 = 0xffffffff;
  brdcfg = 0x7;					// remove DC_RST
  delay(1000);
  dccfg = 0x07;					// set RST and LOCK off
  delay(1000);

	KITLOutputDebugString("M-Systems checking...");

  data = MSYS_PowerUp;
  data = MSYS_PowerUp;
  data = MSYS_PowerUp;
  data = MSYS_PowerUp;

  MSYS_Control = 0x1c;
  MSYS_Confirm = 0xe3;

  MSYS_Control = 0x1d;
  MSYS_Confirm = 0xe2;

  if (MSYS_Control != 1)
  {
    KITLOutputDebugString("msystems ERROR: Not in normal mode!\r\n");
    rc = 1;
    goto error;
  }

  data = MSYS_ID;
  if (data != 0x40)
  {
    KITLOutputDebugString("msystems ERROR: Chip ID[%B] != 0x40\r\n", data);
    rc = 1;
    goto error;
  }

  // check toggle bit
  for (i = 0; i < 3; i++)
    tog[i] = MSYS_Toggle;


  if ((tog[0] & 0x4) == (tog[1] & 0x4) ||
      (tog[0] & 0x4) != (tog[2] & 0x4))
  {
    KITLOutputDebugString("msystems ERROR: Toggle error!\r\n");
    rc = 1;
    goto error;
  }

error:
  //RS_Config_1 = save_rs_config;
  //RS_Timing_1 = save_rs_timing;
  //sync();

  if (!rc)
    KITLOutputDebugString("Found and good to go\r\n");

	return ERROR_SUCCESS;
}

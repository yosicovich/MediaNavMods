/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.
    
    TOY demo
    
    
*/

#include "ldr.h"
#include "platform.h"

#ifdef HAVE_DS1693_RTC
#include "ds1693.h"
#endif

char toyHelp[] = 
    "Syntax toy <n>\r\n\
    \tdisplay timer until keypress\
    \tn=0 TOY, n=1 RTC n=2 DALLAS\r\n";
    
AU1X00_SYS * const Sys = (AU1X00_SYS *)(SYS_PHYS_ADDR+KSEG1_OFFSET);

#ifdef HAVE_DS1693_RTC
static PDS1693 Dallas = (PDS1693)(DALLAS_RTC_PHYSADDR+KSEG1_OFFSET);

int DisplayDallas(void)
{
    unsigned long hh,mm,ss;
    unsigned long dd,mo,yy;

    // Enable bank 1
    Dallas->RegA = 0x3f;
    Dallas->RegB = 0x08;
    
    hh = Dallas->Hours;
    mm = Dallas->Minutes;
    ss = Dallas->Seconds;

    KITLOutputDebugString("HH:MM:SS %B:%B:%B \r\n",hh,mm,ss);

    dd = Dallas->DateOfMonth;
    mo = Dallas->Month;
    yy = Dallas->Year;

    KITLOutputDebugString("DD:MM:YY %B:%B:%B \r\n",dd,mo,yy);

	return 0;
}
#endif

int
ToyDisp(int argc, char *argv[])
{
    int ErrorCode = ERROR_SUCCESS;
    unsigned long LastVal;
    unsigned long ThisVal;
    int Ch;
    int Type=0;
    
    if (argc > 1) {
        if (argv[1][0] == '1') {
            Type = 1;
        }
#ifdef HAVE_DS1693_RTC
         else {
            DisplayDallas();
            goto ErrorReturn;
        }
#endif
    }
    
    if (Type == 0) {
        KITLOutputDebugString("Toy Timer.\r\n");
    } else {
        KITLOutputDebugString("RTC.\r\n");
    }
    

    if (Type == 0) {
        LastVal = ThisVal = Sys->toyread;
    } else {
        LastVal = ThisVal = Sys->rtcread;
    }
    
    KITLOutputDebugString("%X",ThisVal);    
    
    do {
    
        if (Type == 0) {
            ThisVal = Sys->toyread;
        } else {
            ThisVal = Sys->rtcread;
        }
        
        if (ThisVal != LastVal) {
            KITLOutputDebugString("%c%c%c%c%c%c%c%c",
                ASCII_BS,
                ASCII_BS,
                ASCII_BS,
                ASCII_BS,
                ASCII_BS,
                ASCII_BS,
                ASCII_BS,
                ASCII_BS);
                
            KITLOutputDebugString("%X",ThisVal);
            LastVal = ThisVal;                
        }

        Ch = OEMReadDebugByte();
        if (OEM_DEBUG_READ_NODATA != Ch) {
            break;
        }
    
    } while (1);
    
	goto ErrorReturn;
ErrorReturn: 
    KITLOutputDebugString("\r\nOk\r\n");

    return ErrorCode;	
}

/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.

    xmodem download cmd
*/

#include "ldr.h"


char xmodemDownloadHelp[] = 
    "Syntax: xmodem [-s] [-a<addr>]\r\n\
    \t-a<hex addr> the target download address\r\n\
    \t-s suppress autorun\r\n";


static unsigned int Addr = DEFAULT_DOWNLOAD_ADDRESS;
static int ForceRawDownload = FALSE;
static  int AutoBoot = TRUE;



static int
ParseArg(
    char *Arg    
)
{
    int Status = TRUE;
    
    switch (*Arg++) {
        case 'a':
            // raw download, get address
            ForceRawDownload = TRUE;
            Status = strtohex(Arg, &Addr);
            if (!Status) {
                KITLOutputDebugString("Bad download address\r\n");
            }
            
        break;
        case 's':
            AutoBoot = FALSE;
        break;
        
        default:
            
        break;
    }
    
return Status;
}


int
XmodemDownload(int argc, char *argv[])
{
    void (*pfn)(void);

    int ErrorCode = ERROR_SUCCESS;
    
    int i,j;
    char InArg;
    
    
    if (argc > 1) {
        
        i=1;
        j=0;
        InArg=FALSE;
        
        while (i < argc) {
        
            switch (argv[i][j]) {
                case '-':
                case '/':
                    j++;
                    InArg=TRUE;
                break;
                case '\0':
                    j=0;
                    i++;
                    InArg=FALSE;
                break;
                default:
                    if (InArg) {
                        if (!ParseArg(&argv[i][j])) {
                            ErrorCode = ERROR_FAILURE;
                            goto ErrorReturn;
                        }
                        
                        InArg=FALSE;
                        j=0;
                        i++;
                    } else {
                        j++;
                    }
             }        
        }
    }
     
    if (ForceRawDownload) {
        Addr = LdrXmodemDownload(FALSE, Addr);
        AutoBoot = FALSE;
    } else {
        Addr = LdrXmodemDownload(TRUE, Addr);
    }
    KITLOutputDebugString("Image downloaded at %X\r\n",Addr);
    
    if (AutoBoot) {
        pfn = (void*)(Addr-4);
        (*pfn)();
    }   
    
ErrorReturn:    
    return ErrorCode;	
}
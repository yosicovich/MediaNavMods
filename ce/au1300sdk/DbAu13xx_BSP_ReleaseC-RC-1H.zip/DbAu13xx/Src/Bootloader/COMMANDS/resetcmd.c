/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.

	Reset Command
    
    
*/

#include "ldr.h"

char resetHelp[] = {
    "Syntax reset\r\n\
    \tJump to ROM reset vector\r\n"
};

extern void startup(void);
int
Reset(int argc, char *argv[])
{


    KITLOutputDebugString("Reset.\r\n");    
    startup();
    
	return 0;
}
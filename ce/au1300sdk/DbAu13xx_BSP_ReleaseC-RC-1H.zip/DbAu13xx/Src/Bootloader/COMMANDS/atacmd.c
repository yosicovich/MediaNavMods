/*
/*++
Copyright (c) 2001 BSQUARE Corporation. All rights reserved.

Module:

    ebootcmd.c

Description:

	boot using the host eshell

Authors:

    GJS May 2001

Revision History

--*/

#include "ldr.h"
#include "ldrpcard.h"
#include "ldrata.h"
#include "ldrarg.h"
#include "platform.h"
#include "flash.h"



char ATAHelp[] = "Syntax atacard [<filename>]\r\n";
char floadHelp[] = "Syntax fload - loads directly from flash\r\n";
char atacopyHelp[] = "Syntax atacopy [<filename>] - copy file from CF to FLASH\r\n";

static unsigned long Addr = DEFAULT_DOWNLOAD_ADDRESS;
static int ForceRawDownload = FALSE;
static     int AutoBoot = TRUE;
static char FileName[100];

int
ATAFlashCard(int argc, char *argv[])
{
    void (*pfn)(void);
    BOOT_ARGS *pBootArgs = (BOOT_ARGS*)(BOOT_ARG_PTR + KSEG1_OFFSET);
    int ErrorCode = ERROR_SUCCESS;

    ULONG AtaDeviceIndices[4];
    ULONG NumAtaDevices;
    ULONG AtaDevice;
    ULONG NumPcCards;
    ULONG k;

    strcpy(FileName,"nk.bin");

//#define AMD_DEMO 1
#ifdef AMD_DEMO
	while (1)
#endif
	{
	    NumPcCards=PCMFindPcCards();
	    if(NumPcCards==0) {
	        KITLOutputDebugString("No PCMCIA card\r\n");
	        ErrorCode = ERROR_FAILURE;
	        goto ErrorReturn;
	    }

	    NumAtaDevices = PCMFindAtaDevices(4, AtaDeviceIndices);

	    if(NumAtaDevices==0) {
	        KITLOutputDebugString("No ATA PC card\r\n");
	        ErrorCode = ERROR_FAILURE;
	        goto ErrorReturn;
	    }

	    KITLOutputDebugString("Found %u ATA PC cards in system.\r\n",NumAtaDevices);

	    if (argc > 1) {
	        strcpy(FileName,argv[1]);
	    }

	    for(k=0;k<NumAtaDevices;k++) {
	        AtaDevice = AtaDeviceIndices[k];

	        if(FATReadBin(AtaDevice, FileName, &Addr)) {
	            KITLOutputDebugString("Image loaded at %X\r\n",Addr);
				// After writing image to RAM, start from scratch (do a cold boot and clear memory).
				pBootArgs->ucEshellFlags|=EDBG_FL_CLEANBOOT;

	            if (AutoBoot) {
	                pfn = (void*)(Addr-4);
	                (*pfn)();
	            }
	        }
	        else {
	            KITLOutputDebugString("Open file \"%s\" failed on device: %u\r\n",FileName,AtaDevice);
	        }
	    }

ErrorReturn:
		;
	}

    return ErrorCode;

}
int
FlashLoad(int argc, char *argv[])
{
    void (*pfn)(void);
    BOOT_ARGS *pBootArgs = (BOOT_ARGS*)(BOOT_ARG_PTR + KSEG1_OFFSET);
    int ErrorCode = ERROR_SUCCESS;

	if(FlashReadBin((PULONG)NK_BIN_FLASH_ADDR, &Addr)) {
		KITLOutputDebugString("Image loaded at %X\r\n",Addr);
		// After writing image to RAM, start from scratch (do a cold boot and clear memory).
		pBootArgs->ucEshellFlags|=EDBG_FL_CLEANBOOT;

        if (AutoBoot) {
			pfn = (void*)(Addr-4);
            (*pfn)();
        }
    }
    else {
        KITLOutputDebugString("Loading nk.bin from flash failed\r\n");
    }

    return ErrorCode;

}

// Copy nk.bin file from CF card to FLASH
int
ATAFlashCopy(int argc, char *argv[])
{
    BOOT_ARGS *pBootArgs = (BOOT_ARGS*)(BOOT_ARG_PTR + KSEG1_OFFSET);
    int ErrorCode = ERROR_SUCCESS;
	ULONG FileSize;

    ULONG AtaDeviceIndices[4];
    ULONG NumAtaDevices;
    ULONG AtaDevice;
    ULONG NumPcCards;
    ULONG k;

    strcpy(FileName,"nk.bin");

    NumPcCards=PCMFindPcCards();
    if(NumPcCards==0) {
        KITLOutputDebugString("No PCMCIA card\r\n");
        ErrorCode = ERROR_FAILURE;
        goto ErrorReturn;
    }

    NumAtaDevices = PCMFindAtaDevices(4, AtaDeviceIndices);

    if(NumAtaDevices==0) {
        KITLOutputDebugString("No ATA PC card\r\n");
        ErrorCode = ERROR_FAILURE;
        goto ErrorReturn;
    }

    KITLOutputDebugString("Found %u ATA PC cards in system.\r\n",NumAtaDevices);

    if (argc > 1) {
        strcpy(FileName,argv[1]);
    }

    for(k=0;k<NumAtaDevices;k++) {
        AtaDevice = AtaDeviceIndices[k];

        if(FATReadFile(AtaDevice, FileName, (PULONG)NK_BIN_RAM_BUFFER, &FileSize)) {

			// Erase FLASH for image
			if(ldr_EraseFlash(NK_BIN_FLASH_OFFSET,FileSize + 8,TRUE)) {
				// Write the image to FLASH
				if(ldr_WriteFlash(NK_BIN_FLASH_OFFSET+8,(PULONG)NK_BIN_RAM_BUFFER,FileSize,FALSE)) {
					// Write filesize and signature
					ldr_WriteFlash32(NK_BIN_FLASH_OFFSET+4,FileSize);
					ldr_WriteFlash32(NK_BIN_FLASH_OFFSET,NK_BIN_SIG_WORD);
				} else {
					KITLOutputDebugString("Failed writing to FLASH\r\n");
					ErrorCode = ERROR_FAILURE;
					goto ErrorReturn;
				}
			} else {
				KITLOutputDebugString("Failed erasing FLASH\r\n");
				ErrorCode = ERROR_FAILURE;
				goto ErrorReturn;
			}

			KITLOutputDebugString("File %s successfully copied into FLASH. Use fload to execute.\r\n",FileName);
		}
        else {
            KITLOutputDebugString("Open file \"%s\" failed on device: %u\r\n",FileName,AtaDevice);
        }
    }

ErrorReturn:
    return ErrorCode;

}

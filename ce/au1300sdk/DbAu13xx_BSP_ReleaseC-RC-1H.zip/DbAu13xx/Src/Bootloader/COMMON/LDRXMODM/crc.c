/*++

Copyright (c) 1997,1998 BSQUARE Corporation. All rights reserved.

Module:

    crc.c

Abstract:

    This modules provides CRC calculation for both host and target
        
Author(s):

    DC

Revision(s):

    X-1    Date        author

--*/


//
//  Includes
//
#include <windows.h>
#include <stdio.h>

#define CRC_POLY 0x8000

static USHORT crc_table[256];         // CRC Computation Table of Poly's
static UCHAR crc_table_computed=0;   // Set the Table Comp Flag to 0 on startup

void   BuildCRCTable (void);
USHORT  UpdateCRC     (USHORT crc, PUCHAR pBuf, ULONG len);



ULONG DoCRC (PUCHAR pBuf,USHORT WorkCRC,ULONG len)
{
    if(WorkCRC == (UpdateCRC (0xffff,pBuf,len) & 0xffff))
		return(TRUE);
	else
		return(FALSE);

}



USHORT UpdateCRC (USHORT crc, UCHAR *buf, ULONG len)
{
	int WorkCRC,i;
    ULONG LengthCounter;
	WorkCRC=0;
	for(LengthCounter=0;LengthCounter<len;LengthCounter++)
	{
		WorkCRC=WorkCRC ^ (int)*buf++ <<8;
		for(i=0;i<8;i++)
			if(WorkCRC & 0x8000)
				WorkCRC = WorkCRC << 1 ^ 0x1021;
			else
				WorkCRC <<=1;
	}
	WorkCRC &= 0xFFFF;
	return(WorkCRC);
}




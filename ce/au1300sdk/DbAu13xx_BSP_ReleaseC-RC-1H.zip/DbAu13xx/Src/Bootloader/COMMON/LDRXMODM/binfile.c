/*++

Copyright (c) 1998,1999 BSQUARE Corporation. All rights reserved.

Module:
 
    binfile.c

Abstract:

    This file provides the Packet Parsing Interface for Serial Downloads.

Author(s):

    Duane Charron

Revision(s):

    REV.    REV. DATE      REV. Author

    X-1     10-July-98    duanec

--*/

#include "ldr.h"
#include <stdio.h>
#include "xmodem.h"

UCHAR *HercinBuffer;

ULONG RecordLeftOver=0;
ULONG BufferOffset=0,BinState;
ULONG CurrentRecordSize=0;
ULONG CurrentBinLength=0;
extern DWORD ImageStartAddress;
struct
{
	ULONG ImageAddress;
	ULONG ImageLength;
}ImageData;

struct
{
	ULONG RecordAddress;
	ULONG RecordLength;
	ULONG RecordChecksum;
}RecordData;

void InitBinEngine(
    int Parse,
    unsigned int Buffer
    )
{
	
    BinState=(Parse)?LOOKING_FOR_BIN_HEADER:RAW_DATA;
    
    HercinBuffer=(char*)Buffer;
}


DWORD
ParsePacket(PUCHAR DataPacket,ULONG PacketLength)
{
	ULONG DataFlag=1;
	ULONG BinOffset=0;
	ULONG CmpResult;
	PUCHAR TmpCopyPointer;
    DWORD StartAddress;
    
	do
	{
		switch(BinState)
        {
            case LOOKING_FOR_BIN_HEADER:
				CmpResult = memcmp(DataPacket,"B000FF\x0A",7);
                if(CmpResult)      // If Positive, Not a Bin File!
				{
                    BinState=RAW_DATA;
					memcpy(HercinBuffer,DataPacket,PacketLength);
					BinOffset+=PacketLength;
                    StartAddress=(DWORD)HercinBuffer;
				}
                else
				{
//					KITLOutputDebugString("Bin File\r\n");
                    BinState=GET_IMAGE_HEADER;
					BinOffset+=7;
                    PacketLength-=7;
				}
            break;
            case GET_IMAGE_HEADER:
				memcpy(&ImageData,DataPacket+BinOffset,sizeof(ImageData));
				BinOffset+=sizeof(ImageData);
                PacketLength -=sizeof(ImageData);
				BinState=GET_RECORD_HEADER;
            break;


            case GET_RECORD_HEADER:
				if(PacketLength >= sizeof(RecordData))      // Parsing a Previous Packet
				{
                    if(!RecordLeftOver)
                    {
					    memcpy(&RecordData,DataPacket+BinOffset,sizeof(RecordData));
					    BinOffset+=sizeof(RecordData);
                        PacketLength -=sizeof(RecordData);
                    }
                    else
                    {
						TmpCopyPointer=(PUCHAR)&RecordData;
						TmpCopyPointer+=(sizeof(RecordData)-RecordLeftOver);
					    memcpy(TmpCopyPointer,DataPacket+BinOffset,RecordLeftOver);
					    BinOffset=RecordLeftOver;
                        PacketLength -=RecordLeftOver;
						RecordLeftOver=0;

                    }
					BinState=PLACE_BIN_DATA_IN_RAM;
                    CurrentBinLength=RecordData.RecordLength;
					BufferOffset=RecordData.RecordAddress;
                    if(!RecordData.RecordAddress)       // OK, Bin File is Done, Let's Rock!
                    {
                        StartAddress=(DWORD)RecordData.RecordLength;
                        DataFlag=FALSE;
                        
                    }

				}
				else
                {
					memcpy(&RecordData,DataPacket+BinOffset,PacketLength);
                    RecordLeftOver=sizeof(RecordData)-PacketLength;
                    DataFlag=FALSE;
                }



            break;

            case PLACE_BIN_DATA_IN_RAM:
				if((CurrentBinLength <= PacketLength)  && (CurrentBinLength > 0))
				{
					memcpy((PUCHAR)BufferOffset,DataPacket+BinOffset,CurrentBinLength);
					BinOffset+=CurrentBinLength;
					PacketLength-=CurrentBinLength;
					CurrentBinLength=0;
					BinState=GET_RECORD_HEADER;
				}
				else
				{
					memcpy((PUCHAR)BufferOffset,DataPacket+BinOffset,PacketLength);
					BufferOffset+=PacketLength;
					CurrentBinLength-=PacketLength;
					BinState=PLACE_BIN_DATA_IN_RAM;
					DataFlag=FALSE;
				}

            break;
			case RAW_DATA:
    		    memcpy(HercinBuffer+BufferOffset,DataPacket,PacketLength);
				BufferOffset+=PacketLength;
				DataFlag=FALSE;
			break;
            default:
			break;

        }
	}while(DataFlag);

return StartAddress;
}


/*++

Copyright (c) 1998 BSQUARE Corporation. All rights reserved.

Module:
 
    xmodem.h

Abstract:

    Include file for the Xmodem Interface for Serial Downloads.

--*/

#define LS_TSR_EMPTY        0x40
#define LS_THR_EMPTY        0x20
#define LS_RX_BREAK         0x10
#define LS_RX_FRAMING_ERR   0x08
#define LS_RX_PARITY_ERR    0x04
#define LS_RX_OVERRUN       0x02
#define LS_RX_DATA_READY    0x01

#define LS_RX_ERRORS        ( LS_RX_FRAMING_ERR | LS_RX_PARITY_ERR | LS_RX_OVERRUN )


#define SOH		0x01
#define STX		0x02
#define EOT 	0x04
#define ACK 	0x06
#define DLE 	0x10
#define XON 	0x11
#define XOFF 	0x13
#define NAK     0x15
#define SYN		0x16
#define CAN		0x18

#define MAX_X_PACKET	128
#define MAX_Y_PACKET	1024

#define RUNTIME_TIMEOUT 2
#define INITIAL_TIMEOUT 1

enum PROTOCOL_STATES
{
	WAIT_FOR_STARTUP=20,
	BEGINNING_OF_PACKET,
	CHECK_SEQUENCE,
	CHECK_COMP_SEQUENCE,
	GET_DATA,
	DO_CHECKSUM,
	DO_CRC1,
	DO_CRC2,
	TIMEOUT,
	XFER_COMPLETE,
	XFER_ABORT,
	TOSS_PACKET
};
enum PARSE_BIN_STATES
{
	LOOKING_FOR_BIN_HEADER=1,
	GET_IMAGE_HEADER,
	GET_RECORD_HEADER,
	PLACE_BIN_DATA_IN_RAM,
	RAW_DATA
};

enum CHECKSUM_TYPES
{
	CKSUM,
	CRC16,
	CRC32
};
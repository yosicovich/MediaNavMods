/*++

Copyright (c) 1998 BSQUARE Corporation. All rights reserved.

Module:
 
    xmodem.c

Abstract:

    This file provides the Xmodem Interface for Serial Downloads.

Author(s):

    Duane Charron

Revision(s):

    REV.    REV. DATE      REV. Author

    X-1     10-July-98    duanec

--*/

#include <ldr.h>

#include "xmodem.h"

// Global Data......



ULONG NextState,CurrentState,PreviousState;
int CurrentInput;
UCHAR SequenceCount,CompSequenceCount,PayloadBuffer[MAX_Y_PACKET];              // Let's FIFO this thing!
ULONG TimeoutValue,PayloadIndex,AbortCounter,PutIndex,PullIndex;
DWORD CurrentPacketSize;
DWORD ImageStartAddress;
ULONG CkSumType = CRC16;
USHORT CurrentCRCValue=0;
BYTE  NakValue = 'C';		// Startup of CRC VS CkSum!


void BuildCRCTable(void);             // Build the CRC Table 

// bin.c File
extern DWORD ParsePacket(PUCHAR DataPacket,ULONG PacketLength);
extern void InitBinEngine(int Parse, unsigned int Buffer);

extern ULONG DoCRC (PUCHAR pBuf,USHORT WorkCRC,ULONG len);

void InitXmodem(void)
{
	KITLOutputDebugString("Starting Xmodem Init\r\n");

    NextState=BEGINNING_OF_PACKET;
    CurrentState=BEGINNING_OF_PACKET;
    PreviousState=BEGINNING_OF_PACKET;
    TimeoutValue=INITIAL_TIMEOUT;


	PayloadIndex=0;
	SequenceCount=1;
    CompSequenceCount=0xff-(0xff & SequenceCount);
    NakValue = 'C';
}

ULONG DoCheckSum(PUCHAR CheckSumBuffer,int PacketChecksum,ULONG PacketSize)
{
	ULONG i;
	UCHAR LocalCheckSum;
	LocalCheckSum=0;
	for(i=0;i<PacketSize;i++)
		LocalCheckSum+=CheckSumBuffer[i];
	LocalCheckSum &=0xff;				// Mask off the Upper Bit
	if(LocalCheckSum == PacketChecksum)
	{
		return TRUE;		
	}
	else
	{
		return FALSE;
	}
}





int ParseCommand(int XCommand)
{
        int Status = TRUE;
        
        switch(XCommand)
        {
            case SOH:                            // Start of Header
                NextState=CHECK_SEQUENCE;
				CurrentPacketSize=MAX_X_PACKET;
				CkSumType=CRC16;
            break;
			case STX:
				NextState=CHECK_SEQUENCE;
				CurrentPacketSize=MAX_Y_PACKET;
				CkSumType=CRC16;
			break;
            case EOT: 	// Normal Completion!
				KITLOutputDebugString("-EOT-\r\n");
                NextState=XFER_COMPLETE;
            break;
            case CAN:
				KITLOutputDebugString("-CAN-\r\n");
                NextState=XFER_COMPLETE;        // Sender is Aborting!
            break;
            case ACK:
            case NAK:
            case XON:
            case XOFF:
            case SYN:
            break;
            
            default:            
//			  KITLOutputDebugString("UnDefined Protocol Character Received %x\r\n",XCommand);
                Status = FALSE;
            break;
        }
return Status;
}


void FlushUART(void)
{
	ULONG ReadCounter;
	ReadCounter=0;
	while(OEMReadDebugByte() != OEM_DEBUG_READ_NODATA); // Flush out the FIFO
	{
		ReadCounter++;
	}
}

// Start of LdrXmodemDownload
//

unsigned long 
LdrXmodemDownload(
    int Parse,
    unsigned long TargetAddr)
{
	ULONG TimeoutCounter,NumberOfRetrys,ReadFlag;
	UCHAR TmpSeqCount;
	ULONG PacketCounter=0,CheckFlag=0;

	NumberOfRetrys=1;
	TimeoutCounter=0;

    KITLOutputDebugString("XMODEM: Parse=%x Target=%X\r\n",
            Parse,
            TargetAddr);
            
    
	// If parse is true and the file is a bin then TargetAddr will be ignored
    InitBinEngine(Parse,TargetAddr);
    
	
	InitXmodem();

    do
    {
		ReadFlag=TRUE;
        if(CurrentState!=NextState)   // Change to the next State before Getting Input
		{
            PreviousState=CurrentState;
            CurrentState=NextState;
		}
        
    	TimeoutCounter = TimeoutValue  + OEMEthGetSecs();
                
		do
		{
			if(CurrentState != XFER_COMPLETE)
            {
				CurrentInput=OEMReadDebugByte();
            }
			else {
				CurrentInput=EOT;
            }
                
            if((CurrentInput != OEM_DEBUG_READ_NODATA) && (CurrentInput != OEM_DEBUG_COM_ERROR))          // If we got a Character,  Reset the Timer!
			{        

				ReadFlag=FALSE;
			}
			else
            {

                if(OEMEthGetSecs() > TimeoutCounter)
                {
                    PreviousState=CurrentState;
                    CurrentState=TIMEOUT;
                    NextState=TIMEOUT;
                    ReadFlag=FALSE;
                }
            }
		} while( ReadFlag);  // Wait till Timeout or Data was Read

        switch(CurrentState)
        {
            case BEGINNING_OF_PACKET:
                if (ParseCommand(CurrentInput)) {
				    NakValue=NAK;				    // This was done to allow Auto Setup of CRC VS CkSum                
                    TimeoutValue=RUNTIME_TIMEOUT;
                }
            break;
            case CHECK_SEQUENCE:
				
                if(CurrentInput == SequenceCount) 
                {
                    SequenceCount++;
					NextState=CHECK_COMP_SEQUENCE;
                }
                else 
				{
						NextState=TOSS_PACKET;
                }
                
            break;
			case CHECK_COMP_SEQUENCE:
				 TmpSeqCount = SequenceCount-1;
				 TmpSeqCount = ~(TmpSeqCount);
				 if( (CurrentInput & 0xff) == TmpSeqCount)
				 {
					    NextState=GET_DATA;
                        PayloadIndex=0;
				 }
                else 
                {
					
					NextState=TOSS_PACKET;
					TimeoutValue=INITIAL_TIMEOUT;   // Use 1 Second for Retry on Toss!
                }
			break;
            case GET_DATA:
                 PayloadBuffer[PayloadIndex]=CurrentInput;
                 PayloadIndex++;
//				 KITLOutputDebugString("[CP %d PI %d]",CurrentPacketSize,PayloadIndex);
                 if(PayloadIndex > (CurrentPacketSize -1))        // Get the Data!
                 {
					 if(CkSumType == CKSUM)
						NextState=DO_CHECKSUM;
					 else
						 NextState=DO_CRC1;
                 }                    
            break;
            case DO_CHECKSUM:
                 
                if(DoCheckSum(PayloadBuffer,CurrentInput,CurrentPacketSize))
                {
                    ImageStartAddress = ParsePacket(PayloadBuffer,PayloadIndex);
					PayloadIndex=0;


					PacketCounter++;
                    OEMWriteDebugByte(ACK);  // Send the Ack, Get Ready for the Next Packet!
                }
				else 
				{
                    NextState=TOSS_PACKET;
				}
            break;
			case DO_CRC1:
					CurrentCRCValue=CurrentInput << 8;	// Get Lower 8 Bits of the CRC
                    NextState=DO_CRC2;
			break;
			case DO_CRC2:
				CurrentCRCValue|=CurrentInput;  // Get the Upper 8 Bits of the 
				if(CkSumType == CRC16)  // Add a holder for CRC32
				{
					if(DoCRC(PayloadBuffer,CurrentCRCValue,CurrentPacketSize))
					{
					  ImageStartAddress = ParsePacket(PayloadBuffer,PayloadIndex);
                      NextState=BEGINNING_OF_PACKET;
					  PayloadIndex=0;



					  PacketCounter++;
                      OEMWriteDebugByte(ACK);  // Send the Ack, Get Ready for the Next Packet!
					}
					else 
					{
                        NextState=TOSS_PACKET;
					} 
				}
			break;
            case TIMEOUT:
					if(PreviousState == GET_DATA)  // Check for a Less than 128 Byte Packet Length
					{
						if(CkSumType == CKSUM)
							CheckFlag=DoCheckSum(PayloadBuffer,PayloadBuffer[PayloadIndex-1],PayloadIndex-1);
						else
						{
							CurrentCRCValue=PayloadBuffer[PayloadIndex-2] << 8;	// Get Lower 8 Bits of the CRC
						    CurrentCRCValue|=PayloadBuffer[PayloadIndex-1];
							CheckFlag=DoCRC(PayloadBuffer,CurrentCRCValue,PayloadIndex-1);
						}
						if(CheckFlag)
						{
							NextState=BEGINNING_OF_PACKET;
							PayloadIndex=0;


							OEMWriteDebugByte(ACK);  // Send the Ack, Get Ready for the Next Packet!
						}
						else
						{
						 	PayloadIndex=0;							  // Reset the Packet Pointer
							NextState=BEGINNING_OF_PACKET;
							PreviousState=TIMEOUT;
							FlushUART();


							TimeoutValue=RUNTIME_TIMEOUT;   // Use 1 Second for Retry on Toss!
							OEMWriteDebugByte(NakValue);  // Keep Sending NAK Till We Get Data From Host!
						}
 

					}
					else
					{
						if(PreviousState > CHECK_SEQUENCE)  // Increment Sequence counter for Retrys
						{
							    SequenceCount--;
							    CompSequenceCount=0xff-(0xff & SequenceCount);
						}
   						PayloadIndex=0;							  // Reset the Packet Pointer
						NextState=BEGINNING_OF_PACKET;
						PreviousState=TIMEOUT;
						FlushUART();


						TimeoutValue=RUNTIME_TIMEOUT;   // Use 1 Second for Retry on Toss!
						OEMWriteDebugByte(NakValue);  // Keep Sending NAK Till We Get Data From Host!
					}

            break;
            case XFER_COMPLETE:             // Don't do Anything,  Just Allow Xfer to Stop!
				OEMWriteDebugByte(ACK);  // Send the Ack, Get Ready for the Next Packet!
            break;
            case XFER_ABORT:                // We Are Getting Out of here!
                if(AbortCounter++ == 2)
                {
                    CurrentState=XFER_COMPLETE;
                    OEMWriteDebugByte(ACK);  // Keep Sending NAK Till We Get Data From Host!
                }
                else
                    OEMWriteDebugByte(NAK);  // Keep Sending NAK Till We Get Data From Host!
            break;

            case TOSS_PACKET:             // Don't do Anything. Just a Place Holder for Tossing a bad Packet out!
			break;

            default:
            break;
        }                    
    }while(CurrentState != XFER_COMPLETE);
    return(ImageStartAddress);
}



/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.

	String function for the loader
    These are all char based!
    
    
*/
#include "ldr.h"

#if 0
#pragma function(strcpy, strcmp, strlen)

char *
strcpy( 
    char *strDestination, 
    const char *strSource )
{
    char *Dest = strDestination;
    
    do {
        *strDestination++ = *strSource;
    } while(*strSource++);

return Dest;
}


int 
strcmp( 
    const char *string1, 
    const char *string2 )
{
    int cmp=0;
    
    while(!cmp && *string1 && *string2) {
        cmp = *string1++ - *string2++;
    }

return cmp;
}    
size_t 
strlen( 
    const char *string )
{
    unsigned int len=0;
    
    while(*string++) {
        len++;
    }
return len;
}

char *
strchr( 
    const char *string, 
    int c )

{
    unsigned int len=0;
    
    do{
        if (c == *string)
            return (char*)string;         
    
    } while(*string++ );
    
    
return NULL;
}
#endif



/*
    Converts a hex string to a ULONG
    
    if string typed is: 12345678
    
    In memory == Mem Address :  01234567 
                 String chars:  12345678
    
                
    Hence first char will be shifted to the MSB
    Str is the string
    Val pointer to the storage location.                
                
*/
int
strtohex(
    char *Str,
    unsigned int *Val
    )
{
    int Len;
    unsigned int Value = 0;
    int Shift = 0;
    int RetVal=FALSE;
    

    Len = strlen(Str);
    Shift = (Len-1) * 4;
    
    while (Len--) {
    
        RetVal = TRUE;
        
        //
        // nibble at a time
        //
        if (*Str <= '9' && *Str >= '0') {
            Value |= ((*Str - '0') << Shift);
        } else if (*Str <= 'f' && *Str >= 'a') {
            Value |= ((*Str - 'a' + 10) << Shift);
        } else if(*Str <= 'F' && *Str >= 'A') {
            Value |= ((*Str - 'A' + 10) << Shift);            
        } else if ((*Str == ' ') || (*Str == '\0')) {
            break;
        
        } else {
            Value = 0;
            
            RetVal=FALSE;
            
            break;
        }
        Shift -= 4;
        Str++;
    }
    
    *Val = Value;
    
return RetVal;    
}
/*++

Copyright (c) 2001 BSQUARE Corporation. All rights reserved.

Module:
    cli.c

Abstract:
	Command line interpreter for the Bsquare Loader.
	The prototype for all commands is the same - standard ARGC/ARGV

	Dispatches commands to those defined in a table.
	Provied the supported utilites such as 
	- cmd line parsing
	- retrieving switches and values
	- Displaying the cmd line
	- Help handling

Author(s):

    GJS 2001
    
Revision(s):



*/




#include "ldr.h"


//
//	static Globals
//
static int ErrorLevel = ERROR_WARNING_BASE;

//
//	History functions
//
enum {
	NEXT,
	PREVIOUS,
	ADD};

typedef struct {
	unsigned int Len;
	char Buf[CLI_MAX_CMDLINE_LEN];
} HISTORY_BUFFER;

//
// Private functions
//


/*
	SetErrorLevel

	Noise reduction

	Inputs:
	Level	 - One of the defined error levels

	
*/
static void SetErrorLevel(
	int Level
)
{
	switch (Level)
	{
	default:
	case ERROR_LEVEL_ALL:
		ErrorLevel = 0;
	break;
	case ERROR_LEVEL_ERRORSONLY:
		ErrorLevel = ERROR_ERROR_BASE;
	break;
	case ERROR_LEVEL_WARNING:
		ErrorLevel = ERROR_WARNING_BASE;
	break;
	case ERROR_LEVEL_NONE:
		ErrorLevel = 0x80000000;
	}
}

/*
	ErrorReport:

	Checks the error level and prints the code if the level is high enough

	Inputs:
		CmdName		- Cmd name
		ErrorCode	- Value return by function

	Returns:
		Void
*/
static void ErrorReport(
	char *CmdName,
	int ErrorCode
)
{
	
	if (ErrorCode <= ErrorLevel) {
		KITLOutputDebugString(" %s return code = %x\r\n",CmdName, ErrorCode);
	}
}


/*
    
*/
static unsigned int
CLHistory(
	char *Buf,
	unsigned int Function
)
{
    static  int Initialized = FALSE;
    static	HISTORY_BUFFER *HistoryBuffer;
    static  unsigned int HistoryPosition = 0; 
    static  unsigned int HistorySize = 1;
    unsigned int i;
    unsigned int Len;
    


    
    Len = 0;
        	
	if (!Initialized) {
		//
		//	Try to init
		//
		HistoryBuffer = (HISTORY_BUFFER*)malloc(
				CLI_HISTORY_SIZE*sizeof(HISTORY_BUFFER));
		
		

		if (HistoryBuffer) {
			Initialized = TRUE;
            memset (HistoryBuffer, 0, CLI_HISTORY_SIZE*sizeof(HISTORY_BUFFER));            
		}
	}

	if (Initialized) {

		switch (Function) {
		case ADD:
        
            if (HistorySize==CLI_HISTORY_SIZE) {
                // Move them all down one
                //
                for (i=1;i<HistorySize;i++) {
                    memcpy(&HistoryBuffer[i-1].Buf,
                            &HistoryBuffer[i].Buf,
                            CLI_MAX_CMDLINE_LEN);
                }
                
            }
            memcpy(&HistoryBuffer[HistorySize-1].Buf,
                Buf,
                CLI_MAX_CMDLINE_LEN);
                
            HistoryBuffer[HistorySize-1].Len = strlen(Buf);
            
            
            if (HistorySize<CLI_HISTORY_SIZE) {
                HistorySize++;
            }
            
            HistoryPosition = HistorySize;
            Len=HistoryBuffer[HistoryPosition].Len;
			break;
		case NEXT:
        
            //
            // Grab more recent cmd line
            //
            if (HistoryPosition < (HistorySize-1)) { 
                HistoryPosition++;    
            }
            
            memcpy(Buf,
                &HistoryBuffer[HistoryPosition].Buf,                
                CLI_MAX_CMDLINE_LEN);
            
            Len=HistoryBuffer[HistoryPosition].Len;    
            break;

		case PREVIOUS:

            //
            // Grab older cmd line
            //

            if (HistoryPosition > 0) { 
                HistoryPosition--;    
            }
            
            memcpy(Buf,
                &HistoryBuffer[HistoryPosition].Buf,                
                CLI_MAX_CMDLINE_LEN);        
            Len=HistoryBuffer[HistoryPosition].Len;
			break;
		}
        
	} 
    
    
    return Len;
}



    
    
int
DispatchCmd(
	unsigned int ArgCount,
	char *ArgVList[]
	) 
{
	char *CmdName;
	int CmdNumber;
	int RetVal;

	CmdName = ArgVList[0];

	CmdNumber = SearchForCmd(CmdName);

	//
	//	Was the cmd found? if so dispatch, otherwise call help
	//  0 in the table is help
	//
	if (ERROR_NOTFOUND != CmdNumber) {
        RetVal = (*CmdTable[CmdNumber].Cmd)(ArgCount, ArgVList);
    }
    
	ErrorReport(CmdName, RetVal);
	return RetVal;
}


//
//	Public functions
//


/*
	DispatchCmd(ArgCount, &ArgVList);

	All commands have the same prototype, and recieve the same
	parameters as this cmd.
	It will search for the cmd using the first entry in the arg list.
	If found it will be dispatched

	The cmd should return a standard error code from the ldr.h

	Parms:
		Argc - count of arv list size
		ArgVList - Points to the beginning of each arg on the CL
	
	  Returns:
		Error status from cmd
*/




/*
	PutString

	Write the cmd line to the output
*/
void
PutString(
	char *Buf
)
{

	while(*Buf) {
		putch(*Buf);
		Buf++;
	}
}

void
NewLine(
		void
)
{

	putch(ASCII_LF);
	putch(ASCII_CR);
}

/*
	Backspace
	  Erase characters from the end of the CL

	Erases Spaces charaters
*/
void
Backspace(
	unsigned int Spaces
)
{
	while (Spaces--) {
		// move back
		putch(ASCII_BS);
		// put space
		putch(ASCII_SPACE);

		// move back 2
		putch(ASCII_BS);
	};
}

/*
	ReadCmdLine

	Get string from input source up to Cmd line max len
	ESC clears the cmd line
	
		Arrow up retrieve previous cmd line
		Arrow down retrieves next
	
	Parms:
		Buf - buffer large enough to hold the max cmd line len

	Returns
		Zero terminatated cmd line
		
*/
static unsigned int
ReadCmdLine(
	char *Buf
)
{
	unsigned int Len;
    int w;
	char c;
	int Changed=FALSE;		// Has the CL been edited?
	
	Len = 0;
	
	
	do {
		c = getch();

SecondPass:
		switch (c) {


		case ASCII_ESC:
            w = GetchTimeout(5);
            if (w != OEM_DEBUG_READ_NODATA) {
                c = (char)w & 0xff;

            } else {
                c = ASCII_ESC;
            }
            
            switch (c) {
            case ASCII_ESC:	// Erase line

    			Backspace(Len);
    			Buf[0]='\0';
    			Len=0;
    			Changed=FALSE;

    			break;
    		
    		case ASCII_ARROW:
                c = getch();
                
                GetchTimeout(10);
                
                switch (c) {
                case ASCII_ARROWUP:	// Previous cmd line in history

                    Backspace(Len);
        			Len = CLHistory(Buf, PREVIOUS);
        			PutString(Buf);
        			Changed=FALSE;
                    c = getch();
        			break;
        		
        		case ASCII_ARROWDOWN:	// Nextcmd line in history
                    
        			Backspace(Len);
        			Len = CLHistory(Buf, NEXT);
        			PutString(Buf);
        			Changed=FALSE;
                    c = getch();
        			break;
        		
                default:
                    break;
                }
            default:
                goto SecondPass;
                break;                
            }
            break;        

		case ASCII_BS:	// Erase and move left
			if (Len) {
				Len--;
				Backspace(1);
				Changed=TRUE;
			}

			break;

		case ASCII_CR:		// Zero terminate, add to History
			
			// Swap ENTER for NULL
			
			Buf[Len]='\0';
			if (Changed) {
				CLHistory(Buf, ADD);
    			Changed = FALSE;
            }
            
			break;
		default:
			// Add to buffer if there is room
			if (Len < CLI_MAX_CMDLINE_LEN) {
				Buf[Len]=c;
				Len++;
                putch(c);
			}
            Changed = TRUE;
			break;
		}
	} while(c != ASCII_CR);

return Len;
}

/*
	GetNextParm

	Function:
		Search for the next non-whitespace and return a ptr to it.
		Will walk over current text
        changes spaces to NULL to assist with strlen later
        
	Parms:
		CliPtr - Ptr to the current pos in the zero terminated CL
		
	return:
		NULL - none found
		Pointer the the character
*/
char *
GetNextParm(
		char *CliPtr
)
{
	int InSpace;
	char c;
	
	InSpace = (*CliPtr==' ')?TRUE:FALSE;

	//
	//	loop until new text found
	//
	while (*CliPtr != '\0') {
		c = *CliPtr;
		
		if (InSpace) {
			//
			// Still in space?
			//
			if (c!=' ') {
				break;
			} else {
                *CliPtr = '\0';
            }
		} else {
			if (c == ' ') {
                InSpace = TRUE;
                *CliPtr = '\0';
            } else {
                InSpace = FALSE;
            }            
		}		
		CliPtr++;
	}

return (*CliPtr)?CliPtr:NULL;
}




/*
	GetCmdLine

	Get a line from the input source. Use this as input
	to the parser, which will fill the ArgV pointers

	Parms:
		CmdBuf - buffer large enough to hold the max cmd line len
		ArgV - Array of pointers

	returns:
		Number of arguments on the cmd line
		Each ArgV entry will point to the beginning of each arg


*/
unsigned int
GetCmdLine(
	char *CLBuf,
	char *ArgV[]
)
{
	unsigned int Len;
	char *ptr;
	unsigned int ArgCount = 0;


    //
    //  
    //
    KITLOutputDebugString("\r\n>");
    
	//
	//	Firstly, get the CL string from the input source
	//
	Len = ReadCmdLine(CLBuf);
	

    
	if (Len) {
		
		ArgCount=0;
		ArgV[0]=CLBuf;
      	ptr = CLBuf;
        
		while(ptr && (++ArgCount < CLI_MAX_ARG_COUNT)) {
			
			ptr = GetNextParm(ptr);
  			ArgV[ArgCount]=ptr;
            
		}
	}

    
return ArgCount;	
}





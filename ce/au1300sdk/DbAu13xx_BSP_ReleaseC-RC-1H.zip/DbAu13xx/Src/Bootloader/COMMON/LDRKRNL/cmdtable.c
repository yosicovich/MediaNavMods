/*
    Copyright (c) 2001-2003 BSQUARE Corporation.  All rights reserved.

	cmdtable.c
    
    
    To add a command follow these steps:
    
     - Add the source code and help text for the command in the COMMANDS directory
     - add the command, its name and help pointer to the CmdTable array
     - Add the extern for the command and help text to the cmdtable.h file in INC

     Job done.
	 Revision History:
	 15th May 2001 Added Flash command in command Table

*/

#include "ldr.h"
#include "cmdtable.h"



    
//
//	The commands in this table need to be externed in cmdtable.h
//	All commands take the same parameters:
//  CMD cmdname(unsigned int ArgC, char *ArgV[]);
//
CMDENTRY	CmdTable[] = {
	 {Help,         "help",         helpHelp    },
     {WriteValue,   "write",        writeHelp   },
     {ReadValue,    "read",         readHelp    },
     {Jump,         "jump",         jumpHelp    },
     {XmodemDownload, "xmodem",     xmodemDownloadHelp},
     {DumpMem,      "dump",         dumpMemHelp},
     {ToyDisp,      "toy",          toyHelp},
     {Reset,        "reset",        resetHelp   },
	 {FlashCmd,     "flash",        flashHelp   },
     {ReadTLB,      "tlbread",      readTlbHelp },
     {WriteTlb,     "tlbwrite",     writeTlbHelp },
     {ATAFlashCard, "atacard",      ATAHelp },
     {ATAFlashCopy,			"atacopy",      atacopyHelp				},
     {FlashLoad,	"fload",        floadHelp },
     {MacAddrCmd,   "macaddr",      MacAddrCmdHelp },
	 {PerReg,       "perreg",       perregHelp   },
	 //{msysCmd,      "msys",         msysHelp   },

	NULL, NULL, NULL
};

#define CMD_COUNT sizeof(CmdTable)/sizeof(CMDENTRY)


/*
    Scan through external cmd table until the string is found
    
    NOTE: It will find the first match and the string length MUST match too
    
    Return:
        +ve - cmd number
        -ve - error number
*/
int
SearchForCmd(
    char *CmdName
    )
{
    int CmdNum = ERROR_NOTFOUND;
    int i=0;

        
    while (CmdTable[i].Cmd && CmdTable[i].CmdName) {
        if (0 == strcmp(CmdTable[i].CmdName, CmdName)) {
            if (strlen(CmdTable[i].CmdName) == strlen(CmdName)) {
                CmdNum = i;
                break;
            }
        }
        i++;
    }

    return CmdNum;    
}



const char *
GetCmdName(
    unsigned int CmdNum
    )
{
const char *ptr=NULL;

    if (CMD_COUNT > CmdNum) {
        ptr = CmdTable[CmdNum].CmdName;
    }

    return ptr;
}    



const char *
GetCmdHelpText(
    unsigned int CmdNum
    )
{    
    
    return CmdTable[CmdNum].HelpText;

}

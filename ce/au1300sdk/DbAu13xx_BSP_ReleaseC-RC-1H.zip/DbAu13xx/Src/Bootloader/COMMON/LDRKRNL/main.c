/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.

	main.c

    Gets the system ready to run 'C'

Revision History:

*/
#include "ldr.h"
#include <pehdr.h>
#include <romldr.h>
#include "ldrarg.h"
#include <pci.h>
#include "platform.h"
#include "cmdtable.h"
#define CLI_AUTOBOOT 1

//
// Replaced by romimage with the real TOC address.
//

extern ROMHDR* volatile const pTOC;

static BOOT_ARGS *pBootArgs = (BOOT_ARGS*)(BOOT_ARG_PTR + KSEG1_OFFSET);

static int
CheckSelectState(void)
{
    AU1X00_SYS *pGpioRegs = (AU1X00_SYS *)(SYS_PHYS_ADDR + KSEG1_OFFSET);

#ifdef PLATFORM_AUTOBOOT_CODE
	PLATFORM_AUTOBOOT_CODE
#endif

	// Default to autobooting
    return TRUE;
}


static void
AutoBoot(
    int Count,
    char *pCmd
)
{
    if (CheckSelectState())
    {
    	DispatchCmd(Count, &pCmd);
    }
}

void
DataRelocate(void)

/*++

Routine Description:

    Moves all writeable sections of the image into RAM.
	This called by ldrinit.s to setup using C code...

Arguments:

    None.

Return Value:

    None.

--*/

{
    unsigned long loop;
    COPYentry   *cptr;

    for (loop = 0; (unsigned) loop < (unsigned) pTOC->ulCopyEntries; loop++)
    {
        cptr = (COPYentry *)(pTOC->ulCopyOffset + loop * sizeof(COPYentry));

        if (cptr->ulCopyLen)
        {
            memcpy((PVOID) cptr->ulDest,
                   (PVOID)cptr->ulSource,
                   cptr->ulCopyLen);
        }

        if (cptr->ulCopyLen != cptr->ulDestLen)
        {
            memset((PVOID)(cptr->ulDest + cptr->ulCopyLen),
                   0,
                   cptr->ulDestLen - cptr->ulCopyLen);
        }
    }
}


void DisplayInfo(void)
{
	ULONG prid, cpupll;

    AU1X00_SYS *Sys = (AU1X00_SYS *)(SYS_PHYS_ADDR + KSEG1_OFFSET);

    KITLOutputDebugString("Bsquare Loader (EBOOT)\r\nBuild Timestamp %s\r\n", __TIMESTAMP__);
	KITLOutputDebugString(PLATFORM_DESCRIPTION "\r\n");

	// Display CPU rev and frequency
	prid = cp0RdPRId();
	switch (prid)
	{
	case 0x00030100: KITLOutputDebugString("Au1000 DA "); break;
	case 0x00030201: KITLOutputDebugString("Au1000 HA "); break;
	case 0x00030202: KITLOutputDebugString("Au1000 HB "); break;
	case 0x00030203: KITLOutputDebugString("Au1000 HC "); break;
	case 0x00030204: KITLOutputDebugString("Au1000 HD "); break;

	case 0x01030200: KITLOutputDebugString("Au1500 AB "); break;
	case 0x01030201: KITLOutputDebugString("Au1500 AC "); break;
	case 0x01030202: KITLOutputDebugString("Au1500 AD "); break;

	case 0x02030200: KITLOutputDebugString("Au1100 AB "); break;
	case 0x02030201: KITLOutputDebugString("Au1100 BA "); break;
	case 0x02030202: KITLOutputDebugString("Au1100 BC "); break;
	case 0x02030203: KITLOutputDebugString("Au1100 BD "); break;
	case 0x02030204: KITLOutputDebugString("Au1100 BE "); break;

	case 0x03030200: KITLOutputDebugString("Au1550 AA "); break;

	case 0x04030200: KITLOutputDebugString("Au1200 AB "); break;
	case 0x04030201: KITLOutputDebugString("Au1200 AC "); break;

// todo -- determine lower nibble
    case 0x800C8000: OEMWriteDebugString(L"Au13xx AA "); break;
    case 0x800C8001: OEMWriteDebugString(L"Au13xx AA "); break;
    case 0x800C8002: OEMWriteDebugString(L"Au13xx AA "); break;
    case 0x800C8003: OEMWriteDebugString(L"Au13xx AA "); break;

	default: KITLOutputDebugString("Unknown Au1x00! "); break;
	}
	cpupll = (Sys->cpupll & SYS_CPUPLL_PLL) * 12;
    KITLOutputDebugString("(PRId %X) @ %dMHZ\r\n\r\n", prid, cpupll);

    KITLOutputDebugString("BootArgs are at %X, SIG = %x\r\n",pBootArgs, pBootArgs->dwSig);
    KITLOutputDebugString("Free Memory starts at 0x%X\r\n", FREEMEM_START);

	// Tell user how to get to command line
#ifdef PLATFORM_AUTOBOOT_STRING
	KITLOutputDebugString("\r\n" PLATFORM_AUTOBOOT_STRING "\r\n\r\n");
#endif

    if (!CheckSelectState())
        KITLOutputDebugString("Type \"help\" for command listing, or \"help <cmd>\" for specific help\r\n");
}
extern void _puts(char*);

/*
    registers a0 - a3 may contain useable values
    these arrive in arg0-3
*/
int climain(
    unsigned long arg0, // Heap base
    unsigned long arg1, // heap size
    unsigned long arg2,
    unsigned long arg3
    )
{
	char CmdBuf[CLI_MAX_CMDLINE_LEN];
	char *ArgVList[CLI_MAX_ARG_COUNT*sizeof(char *)];
	unsigned int ArgCount;

    //
    // Copy out the global space
    //
//    DataRelocate();

    //
    // Wipe the boot arg area if hard reset
	//
	// NOTE: The booter never sees anything but a hard reset, for
	// example, if resume from suspend, the booter is bypassed
	// completely since code in reset_X.s jumps back into CE.
	//
    memset((char *)(BOOT_ARG_PTR + KSEG1_OFFSET), 0, sizeof(BOOT_ARGS));
    pBootArgs->dwSig = BOOTARG_SIG;
    pBootArgs->dwLen = sizeof(BOOT_ARGS);
    pBootArgs->MajorVer = DRVGLB_MAJOR_VER;
    pBootArgs->MinorVer = DRVGLB_MINOR_VER;
    pBootArgs->BootupType = 0; //HAL_COLD_BOOT

    // Display board info
    DisplayInfo();

    //
    // Init the heap
    //
    InitHeap(
        arg0,
        arg1);



	//
	//	Grab some cmd space
	//
	if (NULL==CmdBuf) {
		//
		//	Very bad - out of memory
		//
		KITLOutputDebugString("OUT OF MEMORY - Aborting\r\n");
		goto ErrorReturn;
	}

	if (NULL==ArgVList ) {
		//
		//	Very bad - out of memory
		//
		KITLOutputDebugString("OUT OF MEMORY - Aborting\r\n");
		goto ErrorReturn;
	}

    //
    // Look for M-Systems DOC, if present then setup
    //
    //msysCmd(0,NULL);

#ifdef PLATFORM_OEMINIT_CODE
	PLATFORM_OEMINIT_CODE
#endif

    //
    // Initialize timers.
    //
    InitializeTimers();

    //
    // Check autoboot options
    //
#undef AMD_DEMO
#ifdef AMD_DEMO
	if (CheckSelectState())
    	AutoBoot(1, "atacard");
#else
    if (CheckSelectState()) {
        return TRUE;
    }

//AutoBoot(1, "atacard");
#ifdef CLI_AUTOBOOT
#if CLI_AUTOBOOT == 1
//    AutoBoot(1, "atacard");

#endif
#endif
#endif // AMD_DEMO

	//
	//	Loop getting commands then dispatching them
	//
	while(1) {

		//
		//	Get command line
		//
		ArgCount = GetCmdLine(CmdBuf, (char**)&ArgVList);

		KITLOutputDebugString("\r\n");
		//
		//	Dispatch the Cmd
		//
		if (ArgCount) {
			DispatchCmd(ArgCount, (char**)&ArgVList);
		}
	}


ErrorReturn:
	return 0;
}

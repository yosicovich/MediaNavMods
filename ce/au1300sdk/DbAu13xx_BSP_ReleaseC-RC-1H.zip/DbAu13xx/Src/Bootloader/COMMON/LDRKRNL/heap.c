/*******************************************************************
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.
 ******************************************************************/

#include "ldr.h"


/* memory chunk descriptor */
typedef struct chunkHeader {
  unsigned int Magic ;             // magic number
  unsigned int chunkSize ;         // size of chunk in chunks
  unsigned int allocatedSize ;     // allocated size in bytes
  struct chunkHeader *next ;       // next chunk in the list
} chunkHeader_t ;

struct chunkStatistics {
  unsigned int totalMemory ;
  unsigned int allocatedMemory ;
  unsigned int maxChunks ;
  unsigned int totalBlocks ;
} ;

static struct chunkStatistics statistics ;

#define HEADER_SIZE sizeof(chunkHeader_t) 
#define CHUNK_MAGIC 0xDEADBEEF

/* minimum size of memory to be allocated */
#define CHUNK_SIZE_IN_BITS 7
#define CHUNK_SIZE (1 << CHUNK_SIZE_IN_BITS) 

/* How many times to try and merge the chunks when freeing them */
#define MAX_MERGE_ATTEMPTS 2

/* How many times do we try to allocate memory when there are not any 
   blocks of chunks big enough */
#define MAX_ALLOCATE_ATTEMPTS 5 

/* first memory chunk pointers (held in ascending memory order) */
chunkHeader_t *first = NULL ;



/* local (static) routines */
static int easyMergeChunks(chunkHeader_t *blockP) ;
static void mergeChunks(void) ;
static chunkHeader_t *firstFit(unsigned int chunks)  ;

/* ----------------------------- static source code ----------------------------- */
static void 
mergeChunks(
    void
    )
{
    chunkHeader_t *blockP ;
    int i ;
    int count ; 

    /* See if you can merge this freed chunk with another one */
    for (i = 0; i < MAX_MERGE_ATTEMPTS; i++) {
        count = 0 ;
        blockP = first;

        while (blockP) {
            count += (easyMergeChunks(blockP))?1:0;
            blockP = blockP->next ;
        }

        /* if we didn't merge any chunks this pass, then give up */
        if (count == 0) {
            break;
        }
    }
}

static chunkHeader_t *
firstFit(
    unsigned int chunks
    ) 
{
    chunkHeader_t *blockP = first ;
    chunkHeader_t *ptr;

    /* very, very simple algorithm, find the first chunk big enough */
    while (blockP) {

        if (blockP->Magic != CHUNK_MAGIC) {
            KITLOutputDebugString("ERROR: corrupt heap @ 0x%x\n", blockP) ;
            break;
        }

        if ((blockP->chunkSize > chunks) && (blockP->allocatedSize == 0)) {
            ptr = blockP ;
        }
        blockP = blockP->next ;
    }
    return ptr ;
}

/* merge this chunk and the next, if they are both free */
static int 
easyMergeChunks(
    chunkHeader_t *blockP
    )
{
    chunkHeader_t *nextP = blockP->next ;
    int Status = FALSE;
       
    if (nextP) {
        if ((blockP->allocatedSize == 0) && (nextP->allocatedSize == 0)) {

            // merge the next chunk.
            blockP->next = nextP->next ;
            blockP->chunkSize += nextP->chunkSize ;
            nextP->Magic = ~CHUNK_MAGIC ;

            /* account for the death of a block of chunks */
            statistics.totalBlocks-- ;
            Status = TRUE;
            

        }
    }
    return Status;
}

/* -------------------------- externally available routines ------------------------ */
/* initialize the heap allocation scheme */

int InitHeap(
    unsigned int HeapBase,
    unsigned int HeapSize
    )
{

    KITLOutputDebugString("HeapBase = 0x%x, Size=%u\r\n", HeapBase, HeapSize);

    /* set up the free block (one big one to start with) */
    first = (chunkHeader_t *)HeapBase ;
    first->Magic = CHUNK_MAGIC ;
    first->allocatedSize = 0 ;             
    first->chunkSize = HeapSize >> CHUNK_SIZE_IN_BITS ;
    first->next = NULL ;

    /* set up the statistics */
    statistics.totalMemory = HeapSize ;
    statistics.allocatedMemory = 0 ;
    statistics.maxChunks = HeapSize >> CHUNK_SIZE_IN_BITS ;
    statistics.totalBlocks = 1 ;

    /* return successfully */
    return TRUE ;
}

/* allocate memory, make this as quick as possible */
void *malloc(
    unsigned int size
    )
{
      unsigned int chunks ;
      chunkHeader_t *blockP ;
      int tries ;

      /* figure out the number of chunks we need */
      chunks = (~(CHUNK_SIZE - 1) & 
	        (CHUNK_SIZE + size + sizeof(chunkHeader_t))) >> CHUNK_SIZE_IN_BITS ;

      /* find the best fit for this number of blocks (retry if neccessary) */
      for (tries = 0; tries < MAX_ALLOCATE_ATTEMPTS; tries++) {

            /* find the first block that fits */
            blockP = firstFit(chunks) ;

            /* if we got a chunk, do we need to break it into smaller chunks? */
            if (blockP) {
                if (blockP->chunkSize > chunks) {
                	chunkHeader_t *newP ;

                	/* make a new chunk and thread it into the list, make sure that
                	   the allocator gets the chunk at the end,this tends to keep the free
                	   blocks of chunks at the start of the memory list. */
                        newP = (chunkHeader_t *)((char *)blockP 
                				 + ((blockP->chunkSize - chunks) * CHUNK_SIZE)) ;

                	newP->Magic = CHUNK_MAGIC ;
                	newP->next = blockP->next ;
                	newP->allocatedSize = 0 ;
                	newP->chunkSize = blockP->chunkSize - chunks ;

                	blockP->next = newP ;
                	blockP->chunkSize -= chunks ;
                	
                	/* account for the birth of a chunk */
                	statistics.totalBlocks++ ;

                	/* Use the new block of chunks */
                	blockP = newP ;
                }

                /* account for this memory */
                statistics.allocatedMemory += (chunks * CHUNK_SIZE) ;

                /* mark this memory allocated */
                blockP->Magic = CHUNK_MAGIC ;
                blockP->allocatedSize = size ;
                blockP->chunkSize = chunks ;

                /* return the caller a pointer to its memory */
                return (void *)((unsigned char *)blockP + sizeof(chunkHeader_t)) ;
            } 

            /* try and merge any free chunks that are next to each other 
               and then retry the allocate */
            mergeChunks() ;

      }   /* ran out of retries, give up */

  return NULL ;
}

void free(
    void *where
    )
{
    chunkHeader_t *blockP = (chunkHeader_t *)((char *)where - sizeof(chunkHeader_t)) ;
    
    /* check the magic header number */
    if (blockP->Magic == CHUNK_MAGIC) {
      /* check that this block is indeed allocated */
        if (blockP->allocatedSize != 0) {
                
            /* account for this memory */
            statistics.allocatedMemory -= (blockP->chunkSize * CHUNK_SIZE) ;

            /* mark this block of chunks as free, don't attempt to merge (yet) */
            blockP->allocatedSize = 0 ;
        }
    }
}





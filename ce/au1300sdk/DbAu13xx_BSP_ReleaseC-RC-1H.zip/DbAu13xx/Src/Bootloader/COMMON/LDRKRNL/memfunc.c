/*
    Copyright (c) 2001-2002 BSQUARE Corporation.  All rights reserved.

	memfunc.c
    
    memory functions.
    
    No optimizations are attempted!!
*/
#include "ldr.h"


//
// The compiler will try to use intrinsics for these, tell it to stop
// otherwise it can't link properly.
//
#pragma function(memset, memcpy, memcmp)


void *
memset(
    void *ptr,
    int c,
    size_t size)
{

    while (size--) {
        ((char*)ptr)[size] = c;
    }
    
    return ptr;
}



void *
memcpy( 
    void *dest, 
    const void *src, 
    size_t count )
{
    while (count--) {
        ((char*)dest)[count] = ((char*)src)[count];
    }

return dest;
}    


int 
memcmp( 
    const void *buf1, 
    const void *buf2, 
    size_t count )
{

    int cmpval=0;
    
    while (!cmpval && count--) {
        cmpval = *(((const char*)buf1)++) - *(((const char*)buf2)++);
    }

    return cmpval;
}    
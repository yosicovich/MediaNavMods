/*++
Copyright (c) 2002-2005  BSQUARE Corporation.  All rights reserved.

Module Name:

    amdflash.c

Module Description:
    Mirrorbit flash driver
    ldr_xx is the exported API

Author:
    GLS 2002
    
Revision History:


--*/


#include "ldr.h"
#include "platform.h"
#include "flash.h"

int amdflash = 0; // make linker happy

#ifdef HAVE_AMD_FLASH

// If a board has more than one FLASH bank it should be 
// defined as such in the board specific header file
#ifndef FLASH_BANKS
#define FLASH_BANKS 1
#endif

static char SpinArray[] = "|/-\\";
static void Spinner(BOOL Init)
{
    static char Last=0;
    if (!Init)
        putch(8);
    
    putch(SpinArray[Last]);
    Last++;
    Last = Last % sizeof(SpinArray);
}

    
/*++
Routine Description:
    Return the size of sector, uses FLASH_WIDTH define to
	handle the case of two 16bit FLASH parts in parallel 
	to form up a 32bit word.

Arguments:
    Sector - Sector number 
    
Return Value:
    Size in bytes of the sector including both parts
--*/
static ULONG GetSectorSize(ULONG Sector)
{
    ULONG SectorSize;

    if (Sector < BOOTSECTOR_COUNT) {
        SectorSize = BOOTSECTOR_SIZE_BYTES; 
    } else {
        SectorSize = SECTOR_SIZE_BYTES;
    }

    return SectorSize * (FLASH_WIDTH/16);
}

/*++
Routine Description:
    Return the base address of a FLASH bank

Arguments:
	Bank   - Bank number (zero based)
    
Return Value:
    Base address of the FLASH bank
--*/
static ULONG GetBankBaseAddress(ULONG Bank)
{
	ULONG BankBase;

	BankBase = FLASH_BASE_KSEG1 + ((FLASH_SIZE/FLASH_BANKS) * Bank);

//	KITLOutputDebugString("GetBankBaseAddress 0x%X = 0x%X\r\n",Bank,BankBase);

	return BankBase;
} 

/*++
Routine Description:
    Returns the FLASH bank containing the specified address

Arguments:
    Address - FLASH Address 
    
Return Value:
    FLASH bank containing Address
--*/
static ULONG AddressToBank(ULONG Address)
{
	int Bank;

	for (Bank=FLASH_BANKS-1; Bank>=0; Bank--) {
		if (Address >= GetBankBaseAddress(Bank)) {
			break;
		}
	}

	return Bank;
}

/*++
Routine Description:
    Get the address of the specified sector

Arguments:
	Bank   - Bank number (zero based)
    Sector - Sector number
        
Return Value:
    Address of the sector   
--*/
static ULONG GetSectorAddress(ULONG Bank, ULONG Sector)
{
    ULONG SectorAddr;
	ULONG i;

	SectorAddr = GetBankBaseAddress(Bank);

	for (i=0; i<Sector; i++) {
		SectorAddr += GetSectorSize(Sector);
	}

//	KITLOutputDebugString("GetSectorAddress 0x%X 0x%X = 0x%X\r\n",Bank,Sector,SectorAddr);

	return SectorAddr;
}

/*++
Routine Description:
    Returns the FLASH bank and sector containing the specified address

Arguments:
    Address - FLASH Address
	pBank   - pointer to ULONG to receive the Bank containing Address
	pSector - pointer to ULONG to receive the Sector containing Address
    
Return Value:
--*/
static VOID AddressToBankAndSector(ULONG Address,
                                   ULONG *pBank,
								   ULONG *pSector )
{
	int Bank;
	ULONG Sector;

//	KITLOutputDebugString("+AddressToBankAndSector 0x%X\r\n",Address);

	// Find the Bank number first
	for (Bank=FLASH_BANKS-1; Bank>=0; Bank--) {
		if (Address >= GetBankBaseAddress(Bank)) {
			break;
		}
	}

	// Now work out the sector number
	Sector = 0;

	while (Address >= GetSectorAddress(Bank,Sector)) {
		Sector++;
	}
	Sector--;
	
	*pBank = Bank;
	*pSector = Sector;

//	KITLOutputDebugString("-AddressToBankAndSector 0x%X = 0x%X 0x%X\r\n",Address,Bank,Sector);
}


/*++
Routine Description:
    IssueFlashCommand RESET/UNLOCK/ERASE/.....
        
Arguments:
    Command - command id
	Param1, Param2 - Command Dependent:
		CMDRESET:        Param1 - FLASH Bank
		CMDUNLOCK:       Param1 - FLASH Bank
		CMDERASESET:     Param1 - FLASH Bank
		CMDERASESECTOR:  Param1 - FLASH Bank
		                 Param2 - Sector
		CMDPROGRAM:      Param1 - FLASH Bank
		CMDWRITEBUFFER:  Param1 - Program Location
		                 Param2 - Word Count - 1. Present twice in 32bit word
		CMDCOMMITBUFFER: Param1 - Program Location
        
Return Value:
        NONE
        
--*/
    
static void IssueFlashCommand( ULONG Command, 
                               ULONG Param1, 
                               ULONG Param2 )
{
	ULONG Address; // will hold address of the flash

	//KITLOutputDebugString("IFC: %H %X %X\r\n",Command, Param1, Param2);

	switch (Command){
		case CMDRESET:
			Address = GetBankBaseAddress(Param1);
			WRITE_FLASH(Address, AMD_RESET32);  // Set the Device to Read Mode
			break;

		case CMDUNLOCK:
			Address = GetBankBaseAddress(Param1);
			WRITE_FLASH(Address + LATCH_OFFSET1, AMD_UNLOCK1);
			WRITE_FLASH(Address + LATCH_OFFSET2, AMD_UNLOCK2);
			break;
            
		case CMDERASESET:
			Address = GetBankBaseAddress(Param1);
			WRITE_FLASH(Address + LATCH_OFFSET1, AMD_ERASESET);
			break;
        
		case CMDERASESECTOR:
			Address = GetSectorAddress(Param1,Param2);
			WRITE_FLASH(Address, AMD_ERASESECTOR); // issue erase sector command
			break;
        
		case CMDPROGRAM:
			Address = GetBankBaseAddress(Param1);
			WRITE_FLASH(Address + LATCH_OFFSET1, AMD_PROGRAM);
			break;

		case CMDWRITEBUFFER:                
			WRITE_FLASH(Param1, AMD_PROGRAMBUFFER);
			WRITE_FLASH(Param1, Param2);      // word count - 1
			break;
                
		case CMDCOMMITBUFFER:
			WRITE_FLASH(Param1, AMD_COMMITBUFFER);
			break;

		default:
			break;
     }
}

/*++
Routine Description:
	Erases the specified sector

Arguments:
	Sector - Sector number to be erased
	Bank   - Bank being worked on
    
Return Value:
	TRUE to indicate that erase command has been successfully erased
--*/

static BOOL EraseSector(ULONG Bank, ULONG Sector)
{
    IssueFlashCommand(CMDUNLOCK, Bank, 0); // issue unlock command // no data to write
    IssueFlashCommand(CMDERASESET, Bank, 0); //  // erase setup command
    IssueFlashCommand(CMDUNLOCK, Bank, 0);
    IssueFlashCommand(CMDERASESECTOR, Bank, Sector); // issue erase sector command

    return TRUE;
}

/*++
Routine Description:
        ULONG GetFlashStatus(ULONG Address)
        
        Get the status of operations(write/erase) on the flash

Arguments:
        ULONG Address.. Address of the flash to check status
        
Return Value:
            STATUSREADY flash has completed an operation and is ready for new operation
            STATUSERASESUSPEND .. flash erase has been suspended
            STATUSTIMEOUT Time out
            STATUSBUSY  Busy
            STATUSERROR Error           
--*/

static ULONG GetFlashStatus(ULONG Address)
{
	ULONG NewRead, OldRead; // holds first and second consecutive flash reads
	ULONG Status;                //  holds dwFirstRead XOR dwSecondRead 
	ULONG LastTime = 0;
	ULONG Bank;
    ULONG StatusTimeoutValue = STATUS_TIMEOUTVALUE;

#if (FLASH_WIDTH==16)
	StatusTimeoutValue &= 0xFFFF;
#endif

	Bank = AddressToBank(Address);

    //
    // Two consecutive reads to check if bits are toggling
    //  

    OldRead = READ_FLASH(Address);
    NewRead = READ_FLASH(Address);    

    do {
        //
        // XOR to see if bits toggled
        //
        Status = OldRead ^ NewRead; 
        if (0 == (Status & STATUS_TOGGLEVALUE)) {
            Status = STATUSREADY;
            break;
        }

        
        if ((NewRead & StatusTimeoutValue) == StatusTimeoutValue) {
        
            NewRead = READ_FLASH(Address);
            OldRead = READ_FLASH(Address);
            
            Status = OldRead ^ NewRead; 

            if (0 == (Status & STATUS_TOGGLEVALUE)) {
                Status = STATUSREADY;
                break;
            }    
			        
            KITLOutputDebugString("FLASH: Fail status 0x%X\r\n", OldRead);            
            Status = STATUSTIMEOUT;
            
            IssueFlashCommand(CMDRESET,Bank,0);

            break;
        }
        
        OldRead = NewRead;
        NewRead = READ_FLASH(Address);
        

    } while (1);
 
    return Status;
}

/*++
Routine Description:
    BOOL EraseSectorWithCompletion(BYTE bSector)

    Erases the specified sector and waits until sector is completely erased 
    Typical sector erase time varies from 0.7 seconds to 15 seconds.. See data sheet

Arguments:
    BYTE bSector. Sector number to be erased .. 0 denotes SA0 and 70 denotes SA70
    
Return Value:
    TRUE to indicate that sector has been successfully erased and flash is ready for other operation
--*/
BOOL EraseSectorWithCompletion( ULONG Bank,
                                ULONG Sector,
                                BOOL  Completion )
{
    ULONG   Address;
    ULONG   Status;
    
    Address = GetSectorAddress(Bank, Sector);

    EraseSector(Bank, Sector);

    if (Completion) {   
        //
        // wait until flash state machine is ready for other operation
        //
        Status = GetFlashStatus(Address);

        if (Status != STATUSREADY) {
            KITLOutputDebugString("FLASH: Erase failed on Sector 0x%x", Sector);
        }
    } else {
        Status = STATUSREADY;
    }
    
	return (Status == STATUSREADY);
}


/*
    Program an entire write buffers worth of data
*/
static BOOL Flash_WriteBuffer( ULONG Location,
                               PVOID pSrcData,
                               ULONG ByteCount )
{
    ULONG Size;
    ULONG Data;
    BOOL Status = FALSE;
	ULONG Bank = AddressToBank(Location);
#if (FLASH_WIDTH==32)
	PULONG pData;
#elif (FLASH_WIDTH==16)
	PUSHORT pData;
#endif
    
	pData = pSrcData;

    if ((ByteCount & 3) || (0 == ByteCount)) {
        KITLOutputDebugString("Flash Write buffer requires a whole multiple of words\r\n");
        return FALSE;
    }
    
    //
    // issue Program Command
    // The Write buffer is AMD_WRITE_BUFFER_SIZE entries deep
    // With 2 chips it is 32 bits wide
    Size = (ByteCount/(FLASH_WIDTH/8));
   
    IssueFlashCommand(CMDUNLOCK, Bank, 0);    
    IssueFlashCommand(CMDWRITEBUFFER, Location, Size-1 |( (Size-1) << 16));
    
    while (Size--) {
        WRITE_FLASH(Location, *pData);
        Location = Location + (FLASH_WIDTH/8);
        pData++;
    }

    Location = Location - (FLASH_WIDTH/8);

    IssueFlashCommand(CMDCOMMITBUFFER, Location, 0);
                   
    //
    // wait until flash is ready to accept new command
    //
    Data = GetFlashStatus(Location);
	   
    if (Data == STATUSTIMEOUT) {
        Status = FALSE;        
        KITLOutputDebugString("Flash Write timeout at %X \r\n", Location);
    } else {
        Status = TRUE;
    }

    return Status;
}

/*++
Routine Description:
        Writes ULONG to the flash at specified offset.
Arguments:
        ULONG Offset    Bytes Offset from flash base
        ULONG dwData    Data to be written 
        
Return Value:
        TRUE to indicate that flash location has been successfully written  
--*/

static BOOL Flash_Write32( ULONG Location,
                           ULONG dwData )
{
	ULONG Bank = AddressToBank(Location);
	int i;

	// Loop through two 16bit values if the
	// FLASH is 16bits wide.
	for (i=0;i<(32/FLASH_WIDTH);i++) {

		// issue Program Command
		IssueFlashCommand(CMDUNLOCK, Bank, 0);
		IssueFlashCommand(CMDPROGRAM, Bank, 0);    

		WRITE_FLASH(Location, dwData);

		// wait till data is written to the flash 
		// and flash is ready to accept new command
		Spinner(TRUE);

		while (GetFlashStatus(Location) != STATUSREADY) {
			Spinner(FALSE);
		}

		putch(8);

		// These two lines are only really doing anything useful
		// when we have 16bit wide FLASH
		Location = Location + (FLASH_WIDTH/8);
		dwData = dwData >> FLASH_WIDTH;
	}

    return TRUE;
}

static BOOL WaitForErase(ULONG Address)
{
    ULONG   Status;
    
    Status = GetFlashStatus(Address);    
    
	return Status;    
}

void ldr_LockFlash( PVOID Address, 
                    ULONG Size )
{
    return;
}


void ldr_UnlockFlash( PVOID Address, 
                      ULONG Size )
{
    return;
}


BOOL  ldr_EraseFlash( ULONG Address, 
                      ULONG Size, 
                      BOOL Completion )
{
    ULONG Sector;
	ULONG Bank;
	ULONG EndAddress;
	ULONG CurrentAddress;
	ULONG tmp;
	ULONG i;

	// Check parameters...
	if (Address+Size-1 > FLASH_SIZE) {
		KITLOutputDebugString("Paramters Address 0x%X and Size 0x%X invalid. FLASH Range is 0->0x%X\r\n",
		                       Address,Size,FLASH_SIZE-1);
		return FALSE;
	}

    Address += FLASH_BASE_KSEG1;
	EndAddress = Address + Size - 1;
	CurrentAddress = Address;
    
    //
    // erase the sectors in this range
    //
    KITLOutputDebugString("Erasing from 0x%x to 0x%x\r\n",
            Address,
            EndAddress);

	for (i=0;i<FLASH_BANKS;i++) {
		IssueFlashCommand(CMDRESET, i, 0);
	}

    Spinner(TRUE);
	     
	do {
		AddressToBankAndSector(CurrentAddress, &Bank, &Sector);

        Spinner(FALSE);
		//KITLOutputDebugString("Erasing Bank %d Sector %d Address %X\r\n",
		//		Bank,Sector,Address);

        EraseSectorWithCompletion(Bank, Sector, Completion);

		CurrentAddress += GetSectorSize(Sector);
	}
	while (CurrentAddress < EndAddress);

    putch(8);
    
	// Verify Erase
	for (i=0;i<Size;i+=4) {
		tmp = READ_FLASH_ULONG(Address+i);
		if (0xFFFFFFFF != tmp) {
			KITLOutputDebugString("FLASH: Erase Verify Failure @ 0x%X (0x%X)\r\n", Address + i,tmp);
			return FALSE;
		}
	}
    
    KITLOutputDebugString("Erased\r\n");    
    return TRUE;
}


/*++
Routine Description:
    Copies the supplied buffer to Flash. No attempt is made to verify 
    content, or previous erasure of the area.
    
Arguments:
    ULONG TargetOffset  - Offset from base of flash to begin
    PVOID SourceData    - Source buffer 
    ULONG Size          - The source buffer length in bytes, 
                            must be multiple of 4
    
Return Value:
        TRUE to indicate that data buffer has been successfully copied
        
--*/

// write buffer to the flash from given memory location
BOOL ldr_WriteFlash( ULONG TargetOffset,
                     PVOID SourceData,
                     ULONG Size,
                     char  Erase)
{
    BOOL Status = TRUE;
    PULONG SrcWords = SourceData;
    ULONG i;
    ULONG Target = TargetOffset + FLASH_BASE_KSEG1;
	ULONG Bank = AddressToBank(Target);
    
	// Check parameters...
	if (TargetOffset+Size-1 > FLASH_SIZE) {
		KITLOutputDebugString("Paramters TargetOffset 0x%X and Size 0x%X invalid. FLASH Range is 0->0x%X\r\n",
		                       TargetOffset,Size,FLASH_SIZE-1);
		return FALSE;
	}

    //
    // Round up to whole word
    //
    if (Size & 0x3) {
        Size += Size % 4;
    }
    
    IssueFlashCommand(CMDRESET, Bank, 0);
        
    //
    // Firstly check that is is erased
    //
    if (!Erase) {
        for (i=0;i<Size;i++) {
            if (0xff != *(PUCHAR)(Target+i)) {
                KITLOutputDebugString("Area not erased, Continue? (y/n) ");
                i = getch();
                if ('Y'==i || 'y'==i) {
                    break;
                }
                Status = FALSE;

                goto ErrorReturn;            
            }
        }
    } 

    if (Erase) {
        
        // 
        // Erase the area before write
        //
        ldr_EraseFlash(TargetOffset, Size, TRUE);    
    } 
        
    KITLOutputDebugString("Writing FLASH @ 0x%X, Size 0x%X\r\n",Target, Size);    

    //
    // Get to next buffer boundary
    //
    while (Size && (Target & (AMD_WRITE_BUFFER_SIZE-1)) && Status) {
        
        Status = Flash_Write32(Target, *SrcWords);
        
		if (!Status) {
			KITLOutputDebugString("FLASH: Write failure at 0x%x\r\n", Target);
		}

		Size -= 4;
        Target += 4;
        SrcWords++;
    }

    IssueFlashCommand(CMDRESET, Bank, 0);

    Spinner(TRUE);

	// Round Size up to multiple of 4 bytes
	Size = (Size+3) & ~0x3;

    while (Size && Status) {
        ULONG CopySize;

        Spinner(FALSE);
        // AMD_WRITE_BUFFER_SIZE specifies the number of bytes of write buffer
        CopySize = min(Size, AMD_WRITE_BUFFER_SIZE);

        Status = Flash_WriteBuffer(Target, SrcWords, CopySize);
        
        Size -= CopySize;
        Target += CopySize;
        SrcWords = &SrcWords[CopySize/4];
    }

    putch(8);

ErrorReturn:
    if (!Status) {
        KITLOutputDebugString("Flash write Error\r\n");
    }
        
    return Status;
}

BOOL ldr_WaitForEraseComplete(ULONG Address)
{
    Address += FLASH_BASE_KSEG1;

    return WaitForErase(Address);
}

BOOL ldr_WriteFlash32( ULONG TargetOffset,
                       ULONG SourceData )
{
    BOOL Status = TRUE;
	ULONG Bank;
	
    TargetOffset += FLASH_BASE_KSEG1;

	Bank = AddressToBank(TargetOffset);
    
    IssueFlashCommand(CMDRESET, Bank, 0);

    KITLOutputDebugString("Writing @ 0x%X, Data= 0x%X\r\n",TargetOffset, SourceData);

    Status = Flash_Write32(TargetOffset, SourceData);

	return Status;
}

BOOL ldr_ReadFlash(
    PVOID Target, 
    ULONG SourceOffset, 
    ULONG Size)
{
    BOOL Status=TRUE;
    PUCHAR TargetChar = Target;
	ULONG Bank;

    SourceOffset += FLASH_BASE_KSEG1;

	Bank = AddressToBank(SourceOffset);
    
    IssueFlashCommand(CMDRESET, Bank, 0);
    
    while (Size--) {
        TargetChar[Size] = *(PUCHAR)(SourceOffset+Size);
    } 

    return Status;
}

BOOL ldrFlashInit(void)
{
    return TRUE;
}

#endif // HAVE_AMD_FLASH


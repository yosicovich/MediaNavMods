/*++
Copyright (c) 2002  BSQUARE Corporation.  All rights reserved.

Module Name:

    flash.c

Module Description:

    Flash access routines for Strataflash				

Author:

    GJS 2002

Revision History:

--*/


#include "ldr.h"
#include "platform.h"  // platform specific header file
#include "flash.h"

int intelflash = 1; // make linker happy

#ifdef HAVE_INTEL_FLASH

#ifndef BYTE

typedef unsigned char BYTE ;
#endif

static ULONG FlashBase = FLASH_BASE_KSEG1;

    
/*++
Routine Description:
    ULONG GetSectorSize(BYTE bSector)
    
    Get the size of sector, note that there are 2 flash parts in
    parallel.

Arguments:
    BYTE bSector. Sector number 
    
Return Value:
      Size in butes of the sector including both parts
    
--*/

ULONG GetSectorSize(
    ULONG bSector
    )
{

   return  SECTOR_SIZE_BYTES;
}


/*++
Routine Description:
    ULONG GetSectorAddress(BYTE bSector)
    
      Get the address of the specified sector


Arguments:
        BYTE bSector sector number
        
Return Value:
        Address of the sector   
            
--*/
ULONG GetSectorAddress(
    ULONG Sector
    )
{

    ULONG Addr;

    Addr = GetSectorSize(0) * Sector;
    Addr += FlashBase;
    return Addr;
}


/*++
Routine Description:
        void IssueFlashCommand(ULONG dwCommand, BYTE bSector, ULONG dwOffset,ULONG dwData)
        
        IssueFlashCommands RESET/UNLOCK/ERASE/UNLOCKBYPASS.....
        
Arguments:
        ULONG   dwCommand   // command id
        BYTE    bSector     // sector number    
        ULONG   dwOffset    // offset
        ULONG   dwData      // data
        
Return Value:
        NONE
        
--*/
    
void IssueFlashCommand(
    ULONG dwCommand, 
    BYTE bSector, 
    PULONG TargetAddress,
    ULONG dwData
    )
{

    ULONG dwAddress; // will hold address of the flash

    // See Table 14 of data sheet for list of commands

     switch (dwCommand){
        case    CMDRESET:
                dwAddress=FlashBase;
                WRITE_FLASH((PULONG)dwAddress, INTEL_READ_ARRAY);                
                break;
    

        case    CMDERASESECTOR:
                dwAddress = GetSectorAddress(bSector);
                WRITE_FLASH((PULONG)dwAddress,INTEL_BLOCK_ERASE);
                WRITE_FLASH((PULONG)dwAddress,INTEL_BLOCK_ERASE2);
                break;

        


        case    CMDREADIDCODES:
                dwAddress=FlashBase;
                WRITE_FLASH((PULONG)dwAddress, INTEL_READ_IDENTIFIER_CODES);
                break;


        case    CMDCLEARSTATUS:
                dwAddress=FlashBase;
                WRITE_FLASH((PULONG)dwAddress, INTEL_CLEAR_STATUS_REGISTER);
                break;

        case    CMDREADSTATUS:
                dwAddress=FlashBase;
                WRITE_FLASH((PULONG)dwAddress, INTEL_READ_STATUS_REGISTER);
                break;
                
                
        case    CMDWRITEWORD:
                WRITE_FLASH(TargetAddress, INTEL_WORD_PROGRAM);
                break;
                

        case    CMDWRITEBUFFER:
                WRITE_FLASH(TargetAddress, INTEL_WRITE_TO_BUFFER);
                break;
                
        default:
                break;

     }
     __asm("sync");
}

/*++
Routine Description:
	ULONG GetManufacturerID()

    Gets the Manufacturer ID by using Autoselect command sequence

Arguments:
	NONE
    
Return Value:
	Manufacturer ID for AMD is 01.. Since we are accessing 2 flash parts in 16 bit mode the
	return value for AMD flash should be 0x00010001
--*/


ULONG GetManufacturerID()
{
	ULONG dwData;// holds data read from offset

	IssueFlashCommand(CMDREADIDCODES,0,NULL,0); // issue AUTOSELECT command

	dwData = *(PUCHAR)FlashBase;

	return dwData ;	 
}

/*++
Routine Description:
	ULONG GetDeviceID()

    Gets the Device ID by using Autoselect command sequence

Arguments:
	NONE
    
Return Value:
	Device ID
--*/

ULONG GetDeviceID()
{
	ULONG dwData;// holds data read from offset
	
	IssueFlashCommand(CMDREADIDCODES,0,NULL,0); // issue AUTOSELECT command

	dwData = *(PUCHAR)(FlashBase+1);

	return dwData ;	 	        
}



/*++
Routine Description:
        ULONG GetFlashStatus(ULONG volatile *pdwMem)
        
        Get the status of operations(write/erase) on the flash

Arguments:
        ULONG volatile *pdwMem.. Address of the flash to check status
        
Return Value:
            STATUSREADY flash has completed an operation and is ready for new operation
            STATUSERASESUSPEND .. flash erase has been suspended
            STATUSTIMEOUT Time out
            STATUSBUSY  Busy
            STATUSERROR Error           
--*/

ULONG GetFlashStatus(
    PULONG TargetAddr
    )
{
    ULONG StartTime;
    ULONG Status;
    AU1X00_SYS *Sys = (AU1X00_SYS*)(SYS_PHYS_ADDR + KSEG1_OFFSET);

    StartTime = Sys->toyread;

    while ((0x00800080 & *TargetAddr) != 0x00800080) {
            //
            // Check for timeout
            //
            if (FLASH_TIMEOUT_PERIOD < (Sys->toyread - StartTime)) {
            
                KITLOutputDebugString("Flash status timeout at 0x%x\r\n",
                        TargetAddr);
                
                Status = FALSE;
                goto ErrorReturn;
            }   
    }
    
    Status = TRUE;
ErrorReturn:    
    
    *TargetAddr = INTEL_CLEAR_STATUS_REGISTER;

	return Status;
}

BOOL WaitForErase(
    PULONG Address
)
{
    ULONG   Status;
    
    Status = GetFlashStatus(Address);    
    
    //
    // Clear status
    //
    IssueFlashCommand(CMDCLEARSTATUS, 0,NULL,0);
    IssueFlashCommand(CMDRESET, 0,NULL,0);

	return Status;    
}



/*++
Routine Description:
    BOOL EraseSector(BYTE bSector)

    Erases the specified sector and waits till sector is completely erased 
    Typical sector erase time varies from 0.7 seconds to 15 seconds.. See data sheet

Arguments:
    BYTE bSector. Sector number to be erased
    
Return Value:
    TRUE to indicate that sector has been successfully erased
--*/

BOOL EraseSectorWithCompletion(
    ULONG Sector,
    BOOL Completion
    )
{
    PULONG  Address;
    ULONG   Status;

    Address = (PULONG)GetSectorAddress(Sector);

    IssueFlashCommand(CMDCLEARSTATUS, 0, NULL, 0);
    IssueFlashCommand(CMDRESET, 0, NULL, 0);
    
    *Address = INTEL_BLOCK_ERASE;
    *Address = INTEL_BLOCK_ERASE2;    
    
    //
    // wait till flash state machine is ready for operation
    //
    if (Completion) {
        Status = WaitForErase(Address);
    }
        
	return Status;
}





/*++
Routine Description:

        
        Writes ULONG to the flash at specified offset.
Arguments:

        ULONG Offset    Bytes Offset from flash base
        ULONG dwData    Data to be written 
        
Return Value:
        TRUE to indicate that flash location has been successfully written  
--*/

BOOL Flash_Write32(
    PULONG Address,
    ULONG Data
    )
{
    ULONG Status;
    
    *Address = INTEL_CLEAR_STATUS_REGISTER;
    
    //
    // issue Program Command
    //
    *Address = INTEL_WORD_PROGRAM;
    *Address = Data;

    //
    // wait till word is written to the flash 
    // and flash is ready to accept new command
    //
    Status = GetFlashStatus(Address);
    
    return Status;
}



/*++
Routine Description:
        BYTE GetStartingSector(ULONG dwMemLocation)

        Get the sector associated with the location on the flash
Arguments:
        ULONG dwMemLocation Specifies the location on the flash
        
Return Value:
        Sector associated with specified flash location
--*/

ULONG GetStartingSector(
    ULONG dwMemLocation
    )
{
    ULONG StartingSector;

    dwMemLocation -= FlashBase;
    StartingSector = (dwMemLocation / GetSectorSize(0));

    return StartingSector;
}

/*++
Routine Description:
        BYTE GetNumberOfSectors(ULONG dwMemLocation,ULONG dwLength)

        Get the number of sectors associated with location range on the flash
Arguments:
        ULONG dwMemLocation Specifies the location on the flash
        ULONG dwLength      Specifies location range on the flash   

Return Value:
        Number of sectors in specified flash location range.
        Number of sectors=0 signifies that sector is in same location range    
--*/

ULONG GetNumberOfSectors(
    ULONG dwMemLocation,
    ULONG dwLength
    )
{
    ULONG StartSector;
    ULONG EndSector;
    ULONG NumOfSectors;
    
    StartSector = GetStartingSector(dwMemLocation);
    EndSector = GetStartingSector(dwMemLocation + dwLength -1);

    NumOfSectors = 1 + EndSector - StartSector;
    
    return NumOfSectors;
}



void ldr_LockFlash(
    PVOID Address, 
    ULONG Size
    )
{
//    Address += FlashBase;
    return;
}


void ldr_UnlockFlash(
    PVOID Address, 
    ULONG Size
    )
{
//    Address += FlashBase;
    return;
}


BOOL  ldr_EraseFlash(
    ULONG Address, 
    ULONG Size,
    BOOL Completion
    )
{

    ULONG CurrentSector;
    ULONG EndingSector;

    ULONG NumOfSectors;
    ULONG Top, Bottom;

    Address += FlashBase;

    CurrentSector = GetStartingSector(Address);
    NumOfSectors = GetNumberOfSectors(Address, Size);

    EndingSector = CurrentSector + NumOfSectors - 1;

    //
    // erase the sectors in this range
    //
    KITLOutputDebugString("Erasing from 0x%x to 0x%x, Sectors 0x%x to 0x%x\r\n",
            Address,
            Address+Size,
            CurrentSector,
            EndingSector);
            
    //
    // Pull code into ICACHE if possible
    // Any calls to KITLOutputDebugString will probably kill this
    // Only error conditions should cause this though
    //
    Top = (ULONG)GetSectorSize;
    Bottom = (ULONG)ldr_WriteFlash32;

    // Cache lines are 32 bytes    
    Top &= ~31;
    Bottom &= ~31;
    LockIntoICache(Top, Bottom);
    
    *(PULONG)Address = INTEL_READ_ARRAY;
            
    for (; CurrentSector <= EndingSector; CurrentSector++){
        EraseSectorWithCompletion(CurrentSector, Completion);
    }

    if (Completion) {
        *(PULONG)Address = INTEL_READ_ARRAY;
    }
    
    Top &= ~31;
    Bottom &= ~31;
    UnlockICache(Top, Bottom);
    
    return TRUE;
}


BOOL ldr_WaitForEraseComplete(
    ULONG Address
)
{
    Address += FlashBase;
    return WaitForErase((PULONG)Address);
}
    
    
BYTE ldr_ReadFlashByte(
    ULONG SourceOffset
)
{
    SourceOffset += FlashBase;
    
    *(PULONG)SourceOffset = INTEL_READ_ARRAY;

    return *(PUCHAR)SourceOffset;
}


/*++
Routine Description:
    Copies the supplied buffer to Flash. No attempt is made to verify 
    content
    
    
Arguments:
    ULONG TargetOffset  - Offset from base of flash to begin
    PVOID SourceData    - Source buffer 
    ULONG Size          - The source buffer length in bytes, 
                            must be multiple of 4
    
Return Value:
        TRUE to indicate that data buffer has been successfully copied
        
--*/

// write buffer to the flash from given memory location
BOOL ldr_WriteFlash(
    ULONG TargetOffset,
    PVOID SourceData,
    ULONG Size,
    char  Erase)
{
    BOOL Status = TRUE;
    PULONG SrcWords = (PULONG)SourceData;
    ULONG i;
    ULONG StartTime;
    PULONG TargetAddr;
    ULONG WordsRemaining;
    ULONG NextSectorStartsAt;
    ULONG StartingSector;
    ULONG Top,Bottom;
    AU1X00_SYS *Sys = (AU1X00_SYS*)(SYS_PHYS_ADDR + KSEG1_OFFSET);    

    //
    // Point to flash. Only interested in whole words
    //
    TargetOffset &= ~3;
    TargetAddr = (PULONG)(TargetOffset + FlashBase);

    KITLOutputDebugString("Writing @ 0x%X, Size %u\r\n",TargetAddr, Size);

    //
    // Pull code into ICACHE if possible
    // Any calls to KITLOutputDebugString will probably kill this
    // Only error conditions should cause this though
    //
    Top = (ULONG)GetSectorSize;
    Bottom = (ULONG)ldr_WriteFlash32;

    // Cache lines are 32 bytes    
    Top &= ~31;
    Bottom &= ~31;
    if (Bottom - Top > 16384) {
        KITLOutputDebugString("Warning: cache not large enough to lock flash functions!!  %u\r\n",
            Bottom-Top);        
    }
    
    LockIntoICache(Top, Bottom);
    
    *TargetAddr = INTEL_CLEAR_STATUS_REGISTER;
    *TargetAddr = INTEL_READ_ARRAY;                  

    //
    // Round up to whole word
    //
    if (Size & 0x3) {
        Size += Size % 4;
    }
    
    //
    // Firstly check that is is erased
    //
    if (!Erase) {
        for (i=0;i<Size;i++) {
            if (0xff != *(PUCHAR)(TargetAddr+i)) {
                KITLOutputDebugString("Area not erased, Continue? (y/n) ");
                i = getch();
                if ('Y'==i || 'y'==i) {
                    break;
                }
                Status = FALSE;

                goto ErrorReturn;            
            }
        }
    } else {
        // 
        // Erase the area before write
        //
        ldr_EraseFlash(TargetOffset, Size, TRUE);    
    }    
    
    //
    // Step one, write as words until the next buffer boundary
    // this is done to avoid crossing a block(sector) boundary
    // 
    StartingSector = TargetOffset / GetSectorSize(0);
    NextSectorStartsAt = (StartingSector+1) * GetSectorSize(0);
    WordsRemaining = (NextSectorStartsAt - TargetOffset) /sizeof(ULONG);
                    
    //
    // Check words remaining in this sector
    //
    if (WordsRemaining < INTEL_WRITE_BUFFER_SIZE) {
        //
        // Update parameters
        //
        TargetOffset += WordsRemaining * sizeof(ULONG);
        
        //
        // Crosses a sector boundary
        //    
        while (WordsRemaining--) {
            if (!Flash_Write32(TargetAddr, *SrcWords++)) {
                //
                // A write error occurred
                //
                KITLOutputDebugString("A flash write error occured at %x.\r\n",    
                    TargetAddr);
                
                Status = FALSE;
                goto ErrorReturn;
            }
            TargetAddr++;
            Size -= sizeof(ULONG);
        }

        StartingSector = TargetOffset / GetSectorSize(0);
    }
    
    //
    // Step 2, write whole buffers until there is insufficient data
    // to fill a whole buffer. 
    // 
    
    WordsRemaining = (Size / sizeof(ULONG));

    while (WordsRemaining >= INTEL_WRITE_BUFFER_SIZE) {
  
        StartTime = Sys->toyread;
        
        //
        // Issue write to buffer cmd
        //
		*TargetAddr = INTEL_WRITE_TO_BUFFER;

        //
        // wait for XSR.7 to go high
        // or timeout
        //
        while ((0x00800080 & *TargetAddr) != 0x00800080 ) {
                //
                // Check for timeout
                //
                if (FLASH_TIMEOUT_PERIOD < (Sys->toyread - StartTime)) {
                
                    KITLOutputDebugString("Flash write timeout at 0x%x\r\n",
                            TargetAddr);
                    
                    Status = FALSE;
                    goto ErrorReturn;
                }
                
                *TargetAddr = INTEL_WRITE_TO_BUFFER;        
        }
        
        //
        // Write word count-1
        //
        *TargetAddr = (INTEL_WRITE_BUFFER_SIZE-1) | ((INTEL_WRITE_BUFFER_SIZE-1) << 16));

        for (i=0;i<INTEL_WRITE_BUFFER_SIZE;i++) {
			// Write the data word
            *TargetAddr = *SrcWords++;

            TargetAddr++;
            Size -= sizeof(ULONG);
            WordsRemaining--;
        }
        
        --TargetAddr;

        *TargetAddr = INTEL_WRITE_TO_BUFFER_CONFIRM;

        Status = GetFlashStatus(TargetAddr);

        if (!Status) {
            goto ErrorReturn;
        }
		    
        ++TargetAddr;
    }
            
    //
    // Step 3 - write the remaining data as words
    // 
    while (WordsRemaining--) {
            if (!Flash_Write32(TargetAddr, *TargetAddr)) {
                //
                // A write error occurred
                //
                KITLOutputDebugString("A flash write error occured at %x.\r\n",    
                    TargetAddr);
                
                Status = FALSE;
                goto ErrorReturn;
            }
            TargetAddr++;
            Size -= sizeof(ULONG);
    }

ErrorReturn:

    *TargetAddr = INTEL_READ_STATUS_REGISTER;
    Status = GetFlashStatus(TargetAddr);

    Top &= ~31;
    Bottom &= ~31;
    UnlockICache(Top, Bottom);
    
    if (!Status) {
        KITLOutputDebugString("Flash write Error\r\n");
    }

    return Status;
}


BOOL ldr_WriteFlash32(
    ULONG TargetOffset,
    ULONG SourceData
)
{
    BOOL Status;
    ULONG Top, Bottom;

    //
    // Pull code into ICACHE if possible
    // Any calls to KITLOutputDebugString will probably kill this
    // Only error conditions should cause this though
    //
    Top = (ULONG)GetSectorSize;
    Bottom = (ULONG)ldr_ReadFlash;

    // Cache lines are 32 bytes    
    Top &= ~31;
    Bottom &= ~31;
    LockIntoICache(Top, Bottom);
    
    TargetOffset += FlashBase;

    *(PULONG)TargetOffset = INTEL_READ_ARRAY;

    KITLOutputDebugString("Writing @ 0x%X, Data= 0x%X\r\n",TargetOffset, SourceData);
    
    Status = Flash_Write32((PULONG)TargetOffset, SourceData);

    *(PULONG)TargetOffset = INTEL_READ_ARRAY;

    Top &= ~31;
    Bottom &= ~31;
    UnlockICache(Top, Bottom);

    return Status;    
}


BOOL ldr_ReadFlash(
    PVOID Target, 
    ULONG SourceOffset, 
    ULONG Size)
{
    BOOL Status=TRUE;
    PUCHAR TargetChar = Target;
    
    SourceOffset += FlashBase;
    
    *(PULONG)SourceOffset = INTEL_READ_ARRAY;
    
    while (Size--) {
        TargetChar[Size] = *(PUCHAR)(SourceOffset+Size);        
    } 
    
    return Status;
}

#endif // HAVE_INTEL_FLASH


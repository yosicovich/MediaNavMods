/*++
Copyright (c) 2004 BSQUARE Corporation. All rights reserved.

Module Name:  
    eboot.c
    
Abstract:  

	Defines common to eboot for both Au1x00 integrated NIC and 
	the SMSC LAN91C111 as used on the Pb1200 board.

Author:

	Ian Rae - 13-Dec-2004

--*/

#include <ldr.h>
//#include <ldrarg.h>
#include "platform.h"
#include "macaddr.h"
#include <kitl.h>
#include <blcommon.h>


// CPU Id for Eshell
#define EDBG_CPUID EDBG_CPU_R4101

// Function prototypes
extern VOID DumpFrame(PUCHAR Address, ULONG Len);
extern ULONG CreateDeviceName(EDBG_ADDR *Addr, PUCHAR Name);
extern BOOL GetMacAddress(USHORT wMAC[3]);
extern BOOL OEMEthInit(EDBG_ADAPTER *pAdapter);



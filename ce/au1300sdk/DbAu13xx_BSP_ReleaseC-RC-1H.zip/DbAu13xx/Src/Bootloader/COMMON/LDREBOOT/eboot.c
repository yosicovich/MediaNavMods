/*++
Copyright (c) 2004 BSQUARE Corporation. All rights reserved.

Module Name:  
    eboot.c
    
Abstract:  

	Routines common to both Au1x00 integrated NIC and the SMSC
	LAN91C111 as used on the Pb1200 board.

Author:

	Ian Rae - 13-Dec-2004

--*/

#include "eboot.h"

static EDBG_ADAPTER Adapter;

//
//DHCP requires this EdbgDebugZone
//
DWORD EdbgDebugZone = 0;

VOID DumpFrame(PUCHAR Address, ULONG Len)
{
    unsigned long  i, j, k;
    unsigned long Addr;
    
    Addr = (ULONG)Address;
    k=0;

    KITLOutputDebugString("\r\nPacket base:%X, Size %d", Address, Len);       
    
   	for (i=0;i<Len;i+=16) {
        KITLOutputDebugString("\r\n%H:", k);       
        for (j=Addr;j < (Addr + 16) ;j++) {
            if (j < (Len + (ULONG)Address)) {
                KITLOutputDebugString("%B ", *(PUCHAR)(j));
                k++;
            }
        }

        Addr +=16;
    }
    KITLOutputDebugString("\r\n");       
    
}

ULONG CreateDeviceName(EDBG_ADDR *Addr, PUCHAR Name)
{
    CHAR DevNumBuf[8];

    if ((strlen(Name) + 4) < KITL_MAX_DEV_NAMELEN-1) {
        strcat(Name, _itoa(ntohs(Addr->wMAC[2]),DevNumBuf,10));
    }
    if ((strlen(Name) + 4) < KITL_MAX_DEV_NAMELEN-1) {
        strcat(Name, _itoa(ntohs(Addr->wMAC[1]),DevNumBuf,10));
    }
    if ((strlen(Name) + 4) < KITL_MAX_DEV_NAMELEN-1) {    
        strcat(Name, _itoa(ntohs(Addr->wMAC[0]),DevNumBuf,10));
    }
           
    return strlen(Name);
}

/*
    Get the MAC address.
    Note the MAC address is written in network byte order 
    (big endian)
*/
BOOL GetMacAddress(USHORT wMAC[3])
{
    static BOOT_ARGS *pBootArgs = (BOOT_ARGS*)(BOOT_ARG_PTR + KSEG1_OFFSET);    
    MACADDR_IN_FLASH *pMif;
    
    pMif = (MACADDR_IN_FLASH*)(KSEG1_OFFSET + MAC_ADDR_BASE);

    if (0 == pBootArgs->NICBase) {    
        wMAC[0] = pMif->u.AsShort.Mac0[0];
        wMAC[1] = pMif->u.AsShort.Mac0[1];
        wMAC[2] = pMif->u.AsShort.Mac0[2];
    } else {
        wMAC[0] = pMif->u.AsShort.Mac1[0];
        wMAC[1] = pMif->u.AsShort.Mac1[1];
        wMAC[2] = pMif->u.AsShort.Mac1[2];
    }

    return TRUE;    
}

//***********************************
// External interface functions.
// OEMxxx()
//**********************************

DWORD OEMEthernetDownload(BOOT_ARGS *pBootArgs,
                          CHAR       EbootPlatformStr[],
                          DWORD      dwSubnetMask,
                          BOOL       fGotIP)
{

	BOOL  fGotJumpImg = FALSE;
    BOOL Status = 0;
    
    ULONG SubnetMask;
    ULONG DHCPLeaseTime;
    PULONG pDHCPLeaseTime=NULL;
    ULONG RetVal;


    KITLOutputDebugString("+OEMEthernetDownload\r\n");    
    if (fGotIP) {
        // use args from pBootArgs
        memcpy(&Adapter.Addr,
            &pBootArgs->EdbgAddr,
            sizeof(EDBG_ADDR));
            
    }
    
    // This function will set the MAC address in the struct too
    if (!OEMEthInit(&Adapter)) {
        KITLOutputDebugString("Failed to initialize Ethernet\r\n");
        goto ErrorReturn;
    }


    
    if (!fGotIP) {
        KITLOutputDebugString("Using DHCP\r\n");
        pDHCPLeaseTime = &DHCPLeaseTime;    
    }
    
    //
    // Create the name of the device
    //
    pBootArgs->DeviceName[0] = '\0';
    strcpy(pBootArgs->DeviceName, EbootPlatformStr);
    
	CreateDeviceName(&Adapter.Addr, pBootArgs->DeviceName);
    
	KITLOutputDebugString("Device Name: %s\r\n",pBootArgs->DeviceName);

    //
    // Start eboot. When this returns the TFTP connection
    // will have been established
    //
    Status = EbootInitEtherTransport(&Adapter.Addr,
                                     &SubnetMask,
                                     &fGotJumpImg,
                                     pDHCPLeaseTime,
                                     4,0,
                                     EbootPlatformStr, 
                                     pBootArgs->DeviceName,
                                     EDBG_CPUID,
                                     0);

    if (!Status) {
        KITLOutputDebugString("EbootInitEtherTransport returned error\r\n");
        RetVal = BL_ERROR;
        goto ErrorReturn;
    } else {
        KITLOutputDebugString("EbootInitEtherTransport completed.\r\n");
    }
    
    //
    // update bootarg struct
    //
    KITLOutputDebugString("Writing bootargs @ %X\r\n",pBootArgs);
    KITLOutputDebugString ("Setting bootarg IP address: %s\r\n",
                                      inet_ntoa(Adapter.Addr.dwIP));
                                      
    pBootArgs->EdbgAddr.dwIP = Adapter.Addr.dwIP;
    pBootArgs->EdbgAddr.wPort = Adapter.Addr.wPort;
    pBootArgs->DHCPLeaseTime =  DHCPLeaseTime;
    pBootArgs->SubnetMask = SubnetMask;



 ErrorReturn:
    KITLOutputDebugString("-OEMEthernetDownload\r\n");    


    return fGotJumpImg? BL_JUMP : BL_DOWNLOAD;
}    
    

void OEMEthernetLaunch (
    DWORD dwImageStart, 
    DWORD dwImageLength, 
    DWORD dwLaunchAddr, 
    const ROMHDR *pRomHdr)
{
    EDBG_OS_CONFIG_DATA *pCfgData;
    EDBG_ADDR EshellHostAddr;
    void (*pfn)(void);
    static BOOT_ARGS *pBootArgs = (BOOT_ARGS*)(BOOT_ARG_PTR + KSEG1_OFFSET);

    KITLOutputDebugString ("ImgStart %X, ImgLen %X LaunchAddr %X\r\n",
        dwImageStart, dwImageLength, dwLaunchAddr);

    if (!(pCfgData = EbootWaitForHostConnect(&pBootArgs->EdbgAddr, &EshellHostAddr))) {
        KITLOutputDebugString ("EbootWaitForHostConenct failed, oh dear.\r\n");
        return;
    }            
    if (pCfgData) {
        if (pCfgData->Flags & KITL_FL_DBGMSG) {
            KITLOutputDebugString("Enabling %s over KITL, IP: %S, port:%u\r\n",
                KITL_SVCNAME_DBGMSG,
                inet_ntoa(pCfgData->DbgMsgIPAddr),pCfgData->DbgMsgPort);
            memcpy(&pBootArgs->DbgHostAddr.wMAC,&EshellHostAddr.wMAC,6);
            pBootArgs->DbgHostAddr.dwIP  = pCfgData->DbgMsgIPAddr;
            pBootArgs->DbgHostAddr.wPort = pCfgData->DbgMsgPort;
        }
        if (pCfgData->Flags & KITL_FL_PPSH) {
            KITLOutputDebugString("Enabling %s over KITL, IP: %S, port:%u\n",
                KITL_SVCNAME_PPSH,
                inet_ntoa(pCfgData->PpshIPAddr),pCfgData->PpshPort);
            memcpy(&pBootArgs->CeshHostAddr.wMAC,&EshellHostAddr.wMAC,6);
            pBootArgs->CeshHostAddr.dwIP  = pCfgData->PpshIPAddr;
            pBootArgs->CeshHostAddr.wPort = pCfgData->PpshPort;
        }
        if (pCfgData->Flags & KITL_FL_KDBG) {
            KITLOutputDebugString("Enabling %s over KITL, IP: %S, port:%u\n",
                KITL_SVCNAME_KDBG,
                inet_ntoa(pCfgData->KdbgIPAddr),pCfgData->KdbgPort);
            memcpy(&pBootArgs->KdbgHostAddr.wMAC,&EshellHostAddr.wMAC,6);
            pBootArgs->KdbgHostAddr.dwIP  = pCfgData->KdbgIPAddr;
            pBootArgs->KdbgHostAddr.wPort = pCfgData->KdbgPort;
        }
        pBootArgs->ucEshellFlags |= pCfgData->Flags;
        pBootArgs->KitlTransport = pCfgData->KitlTransport;
        memcpy(&pBootArgs->EshellHostAddr, &EshellHostAddr, sizeof(EDBG_ADDR));
    }

    KITLOutputDebugString("\r\nDownload successful! image Start Address is %X\r\n",dwLaunchAddr);

    //
    // Jump to downloaded image
    //
    pfn = (void*)(dwLaunchAddr);
    (*pfn)();
}

DWORD OEMEthernetPreDownload()
{
    char PlatformString[64];
    char *cptr;
    WCHAR *wptr;
    static BOOT_ARGS *pBootArgs = (BOOT_ARGS*)(BOOT_ARG_PTR + KSEG1_OFFSET);
    
    wptr = TEXT(EBOOT_NAME);
    
    //
    // Only want the last word of the string
    //
    
    cptr = PlatformString;

    while (*wptr) {
        if (*wptr == 32) {
			// if a space then restart
            cptr = PlatformString;
        } else {
            *cptr = (char) *wptr;
            cptr++;
        }
        wptr++;
    }

    *cptr++ = '_';
    *cptr = '\0';
    
    //
    // Force use DHCP
    //
    return OEMEthernetDownload(pBootArgs, PlatformString, 0, FALSE);
}


    
//VOID SC_WriteDebugLED(WORD wIndex, DWORD dwPattern) {
//    return;
//}



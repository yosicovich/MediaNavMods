/*++
Copyright (c) 1998,2001-2004 BSQUARE Corporation. All rights reserved.

Module Name:  
    auether.c
    
Abstract:  
	Ethernet download routines for the Au1x00 integrated NIC.
    
--*/

#include "eboot.h"

// Only valid for devices with MAC controllers
// Currently this is everything bar the Au1200
#ifdef MAC0_PHYS_ADDR

static PULONG NicEnableReg;
static AU1X00_MAC *NicMacRegs;
static AU1X00_MACDMA *NicDmaRegs;
static ULONG   NextRxBuffer;
static ULONG   NextTxBuffer;
static ULONG   LastTxBuffer;

#define MACDMA_RXSTAT_ERRORS    (MACDMA_RXSTAT_LE | \
                                 MACDMA_RXSTAT_CR | \
                                 MACDMA_RXSTAT_DB | \
                                 MACDMA_RXSTAT_MI | \
                                 MACDMA_RXSTAT_CS | \
                                 MACDMA_RXSTAT_FL | \
                                 MACDMA_RXSTAT_RF | \
                                 MACDMA_RXSTAT_WT)


BOOL DEBUG_FRAMES=0;

/* OEMEthGetFrame
 *
 *   Check to see if a frame has been received, and if so copy to buffer. An optimization
 *   which may be performed in the Ethernet driver is to filter out all received broadcast
 *   packets except for ARPs.  
 *
 * Parameters:
 *
 *   pData    - OUT - Receives frame data
 *   pwLength - IN  - Length of Rx buffer
 *            - OUT - Number of bytes received
 *
 * Return Value:
 *    Return TRUE if frame has been received, FALSE if not.
 */
BOOL OEMEthGetFrame( BYTE *pData, UINT16 *pwLength) 
                      
{
    BOOL Status = FALSE;
    UINT16 Len;
    PULONG pSrc;
    PULONG pUlong;
    UINT16 i;

    if (NicDmaRegs->rx[NextRxBuffer].rxaddr & MACDMA_RXADDR_DN) {

		if (DEBUG_FRAMES)
			KITLOutputDebugString("OEMEthGetFrame %X, len:%d dmaregs:%X\r\n", pData, *pwLength, NicDmaRegs );

        // got one, any errors?
        if (NicDmaRegs->rx[NextRxBuffer].rxstat & MACDMA_RXSTAT_ERRORS ) {
            // Error occurred - ignore packet

        } else {
            // no errors
            Len =(UINT16)(NicDmaRegs->rx[NextRxBuffer].rxstat & MACDMA_RXSTAT_L);
            
			if (Len <= *pwLength) {

                // buffer is large enough so copy
                *pwLength = Len;
                pSrc =  (PULONG)(NIC_RX_BASE + (NextRxBuffer * NIC_PACKET_LEN));
                
                pUlong = (PULONG)pData;
                for (i=0;i<Len;i+=4) {
                    *pUlong = *pSrc;
                    pUlong++;
                    pSrc++;
                }
                
                // packet OK
                Status = TRUE;
            }
        }

        // reset status
        NicDmaRegs->rx[NextRxBuffer].rxstat = 0;
        
        //Re-enable the buffer
        NicDmaRegs->rx[NextRxBuffer].rxaddr = NIC_RX_PHYSADDR_BASE + (NextRxBuffer * NIC_PACKET_LEN) | MACDMA_RXADDR_EN;
        
        NextRxBuffer = (NextRxBuffer==3)?0:NextRxBuffer+1;

		if (DEBUG_FRAMES)
			KITLOutputDebugString("OEMEthGotFrame len:%d\r\n", *pwLength);

    }

	return Status;    
}


/* OEMEthSendFrame
 *
 *   Send Ethernet frame.  
 *
 * Parameters:
 *
 *   pData    - IN - Data buffer
 *   dwLength - IN - Length of buffer
 *
 *  Return Value:
 *   TRUE if frame successfully sent, FALSE otherwise.
 */
BOOL
OEMEthSendFrame(
    BYTE *pData,     // IN - Data buffer
    DWORD dwLength)  // IN - Length of buffer
{
    ULONG StartTime;
    ULONG TimeNow;
    ULONG Status;
    ULONG * pUlong, *pSrc;
    UCHAR *pUchar;
    ULONG i;
    

	if (DEBUG_FRAMES)
		KITLOutputDebugString("OEMEthSendFrame len:%d \r\n", dwLength);
        
    //
    // Wait for a free slot
    //
    
    if (!(NicDmaRegs->tx[NextTxBuffer].txaddr & MACDMA_TXADDR_EN)) {
        //
        // Copy the data, ignore any extra chars at the end.
        //
        pUlong = (PULONG)(NIC_TX_BASE + (NextTxBuffer * NIC_PACKET_LEN));
        pSrc = (PULONG)pData;
        for (i=0;i<dwLength;i+=4) {
            *pUlong = *pSrc;
            pUlong++;
            pSrc++;
        }
        
        if (dwLength<64) {            
            // zero pad the buffer and change len
            pUchar = (unsigned char *)(NIC_TX_BASE + (NextTxBuffer * NIC_PACKET_LEN));
            for (;dwLength<64;dwLength++) {
                pUchar[dwLength]=0;
            }
        }
    

    
        //
        // Hit go
        //
        NicDmaRegs->tx[NextTxBuffer].txstat = 0;
        NicDmaRegs->tx[NextTxBuffer].txlen = dwLength;

        NicDmaRegs->tx[NextTxBuffer].txaddr = (NIC_TX_PHYSADDR_BASE + (NextTxBuffer * NIC_PACKET_LEN)) | MACDMA_TXADDR_EN;
        NextTxBuffer = (NextTxBuffer==3)?0:NextTxBuffer+1;

    } else {    
    
        //
        // Clear previously Tx'd frames
        //
        do {
        
            // is this buffer done?
            Status = NicDmaRegs->tx[LastTxBuffer].txaddr;
            if (Status & MACDMA_TXADDR_DN) {
            
                // Don't care about errors
                // inc buffer
                LastTxBuffer = (LastTxBuffer==3)?0:LastTxBuffer + 1;
                NicDmaRegs->tx[LastTxBuffer].txaddr = 0;
                NicDmaRegs->tx[NextTxBuffer].txstat = 0;
            } else {
                break;
            }
        
        } while (LastTxBuffer != NextTxBuffer);
    
    
        //
        // Wait for a free slot
        //
        StartTime = OEMEthGetSecs();
        while (NicDmaRegs->tx[NextTxBuffer].txaddr & MACDMA_TXADDR_EN) {
            TimeNow = OEMEthGetSecs();
            if (TimeNow > (2+StartTime)) {
            
                int i;
            
                KITLOutputDebugString ("Ethernet Tx Timeout %d\r\n", NextTxBuffer);
                for (i=0;i<4;i++) {
                    KITLOutputDebugString("Addr:%X, Len:%x, stat:%X\r\n:",
                        NicDmaRegs->tx[i].txaddr,
                        NicDmaRegs->tx[i].txlen,
                        NicDmaRegs->tx[i].txstat);
                
                }
            
                NicDmaRegs->tx[NextTxBuffer].txaddr = 0;
            }
        }
    
        //
        // Copy the data
        //
        pUlong = (PULONG)(NIC_TX_BASE + (NextTxBuffer * NIC_PACKET_LEN));
        pSrc = (PULONG)pData;
        for (i=0;i<dwLength;i+=4) {
            *pUlong = *pSrc;
            pUlong++;
            pSrc++;
        }

    
        //
        // Hit go
        //
        NicDmaRegs->tx[NextTxBuffer].txstat = 0;
        NicDmaRegs->tx[NextTxBuffer].txlen = dwLength;

        NicDmaRegs->tx[NextTxBuffer].txaddr = (NIC_TX_PHYSADDR_BASE + (NextTxBuffer * NIC_PACKET_LEN)) | MACDMA_TXADDR_EN;

        NextTxBuffer = (NextTxBuffer==3)?0:NextTxBuffer+1;
        
		if (DEBUG_FRAMES)
			KITLOutputDebugString("OEMEthSentFrame len:%d \r\n", dwLength);
        
    }    

    return TRUE;    
}


//BOOL OEMEthDeInit (
//    VOID )
//{
//   NicMacRegs->control = 0;
//    *NicEnableReg = 0;
//
//	return 0;    
//}

BOOL OEMEthInit (
    EDBG_ADAPTER *pAdapter )
{
    ULONG i;
    ULONG TmpMacAddr;
    UCHAR *TmpMac;
    static BOOT_ARGS *pBootArgs = (BOOT_ARGS*)(BOOT_ARG_PTR + KSEG1_OFFSET);    


    NicEnableReg = (PULONG) (MACEN_PHYS_ADDR + KSEG1_OFFSET);

#if defined(CPU_AU1000) || defined(CPU_AU1500)
    if (1 == pBootArgs->NICBase) {
        NicEnableReg++;
        NicMacRegs = (AU1X00_MAC*) (MAC1_PHYS_ADDR + KSEG1_OFFSET);
        NicDmaRegs = (AU1X00_MACDMA*) (MACDMA1_PHYS_ADDR + KSEG1_OFFSET);
    } else 
#endif
    {
        NicMacRegs = (AU1X00_MAC*) (MAC0_PHYS_ADDR + KSEG1_OFFSET);
        NicDmaRegs = (AU1X00_MACDMA*) (MACDMA0_PHYS_ADDR + KSEG1_OFFSET);
    }
    
    // Need to write the MAC address
    // From???
    //
    GetMacAddress(pAdapter->Addr.wMAC);
    
    TmpMac = (PUCHAR)pAdapter->Addr.wMAC;

    KITLOutputDebugString("MAC Addr");
    for (i=0;i<6;i++) {
        KITLOutputDebugString(":%B",TmpMac[i]);
    }
    KITLOutputDebugString("\r\n");
    

    *NicEnableReg = 0;

    // Set initial conditions
    NextRxBuffer = (NicDmaRegs->rx[0].rxaddr & MACDMA_RXADDR_CB) >> MACDMA_RXADDR_CB_S;
    NextTxBuffer = (NicDmaRegs->tx[0].txaddr & MACDMA_TXADDR_CB) >> MACDMA_TXADDR_CB_S;
    LastTxBuffer = NextTxBuffer;
    

    // Grab some memory for the packets. 
    // 4 Tx and 4 Rx    
    for (i=0;i<4;i++) {
        NicDmaRegs->tx[i].txstat = 0;
        NicDmaRegs->tx[i].txlen = 0;
        NicDmaRegs->tx[i].txaddr = NIC_TX_PHYSADDR_BASE + (i * NIC_PACKET_LEN);
        
        NicDmaRegs->rx[i].rxstat = 0;
        NicDmaRegs->rx[i].rxaddr = NIC_RX_PHYSADDR_BASE + (i * NIC_PACKET_LEN) | MACDMA_RXADDR_EN;
    }

    // enable clocks to MAC
    *NicEnableReg = MACEN_MAC_CE;
    
    // take MAC out of reset
    *NicEnableReg = MACEN_MAC_E0 | 
                    MACEN_MAC_E1 |
                    MACEN_MAC_E2 |
                    MACEN_MAC_CE;
    
    
    //
    // Configure the MAC layer
    //
    NicMacRegs->control = MAC_CONTROL_DO;

    //
    // Write the address
    //
    TmpMacAddr = pAdapter->Addr.wMAC[0];
    TmpMacAddr |= pAdapter->Addr.wMAC[1] << 16;
    NicMacRegs->addrlow = TmpMacAddr;
    
    TmpMacAddr = pAdapter->Addr.wMAC[2];
    NicMacRegs->addrhigh = TmpMacAddr;

    // accept all multicast
    NicMacRegs->hashhigh = 0xffffffff;
    NicMacRegs->hashlow = 0xffffffff;

    //
    // Need to wake the PHY
	//
	// NOTE: Most PHYs are configured to AUTONEGOTIATE out of reset,
	// thus there isn't a need to touch the PHY.
    //
#ifdef PLATFORM_EBOOT_PHYINIT_CODE
	PLATFORM_EBOOT_PHYINIT_CODE
#endif
    
    //
    // Go
    // 
    NicMacRegs->control = MAC_CONTROL_DO | MAC_CONTROL_RE | MAC_CONTROL_TE;

	return TRUE;    
}

#endif	// MAC0_PHYS_ADDR


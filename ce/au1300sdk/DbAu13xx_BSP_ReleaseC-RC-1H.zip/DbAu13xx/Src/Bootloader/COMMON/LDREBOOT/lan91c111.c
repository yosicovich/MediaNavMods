/*++
Copyright (c) 2004 BSQUARE Corporation. All rights reserved.

Module Name:  
    auether.c
    
Abstract:  
	Ethernet download routines the SMSC LAN91C111 as used on the 
	Pb1200 board.
    
Author:
	Ian Rae 13-Dec-2004

--*/

#include "eboot.h"
#include "lan91c111.h"

// Stop the linker complaining about empty libraries
int lan91c111 = 0;

// This must be defined in the board header file (eg pb1200.h) if
// a LAN91C111 is to be used.
#ifdef LAN91C111_PHYS_ADDR

static LAN91C111 *pNicRegs = (LAN91C111*)(LAN91C111_PHYS_ADDR+KSEG1_OFFSET);

#define BANK_SELECT(n) pNicRegs->BANK = (n)

// Write a "1" bit out to the PHY
__inline void WRITE_PHY_ZERO() {
	pNicRegs->Bank3.MGMT = MGMT_MDOE;
	pNicRegs->Bank3.MGMT = MGMT_MDOE | MGMT_MCLK;
	pNicRegs->Bank3.MGMT = MGMT_MDOE;
}

// Write a "0" bit out to the PHY
__inline void WRITE_PHY_ONE() {
	pNicRegs->Bank3.MGMT = MGMT_MDOE | MGMT_MDO;
	pNicRegs->Bank3.MGMT = MGMT_MDOE | MGMT_MCLK | MGMT_MDO;
	pNicRegs->Bank3.MGMT = MGMT_MDOE | MGMT_MDO;
}

// Write a "Z" high-impedance bit out to the PHY
__inline void WRITE_PHY_Z() {
	pNicRegs->Bank3.MGMT = 0;
	pNicRegs->Bank3.MGMT = MGMT_MCLK;
	pNicRegs->Bank3.MGMT = 0;
}

// Write to a PHY Reg
void PhyWrite(UCHAR Reg,USHORT Data)
{
	int i;

	BANK_SELECT(3);

	// Write 32 1s to sync
	for (i=0;i<32;i++) {
		WRITE_PHY_ONE();
	}

	// Start Bits <01>
	WRITE_PHY_ZERO();
	WRITE_PHY_ONE();

	// Write Command Bits <01>
	WRITE_PHY_ZERO();
	WRITE_PHY_ONE();

	// PHY Address, 00000 for interal PHY
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();

	// PHY Reg, 5 bits, MSB first
	for (i=0;i<5;i++) {
		if (Reg & 0x10) {
			WRITE_PHY_ONE();
		} else {
			WRITE_PHY_ZERO();
		}
		Reg <<= 1;
	}

	// Send turnaround bit <10>
	WRITE_PHY_ONE();
	WRITE_PHY_ZERO();

	// Send the data, 16bit, MSB first
	for (i=0;i<16;i++) {
		if (Data & 0x8000) {
			WRITE_PHY_ONE();
		} else {
			WRITE_PHY_ZERO();
		}
		Data <<= 1;
	}

	pNicRegs->Bank3.MGMT = 0;
}

// Read from a PHY Reg
USHORT PhyRead(UCHAR Reg)
{
	int i;
	USHORT Data = 0;

	BANK_SELECT(3);

	// Write 32 1s to sync
	for (i=0;i<32;i++) {
		WRITE_PHY_ONE();
	}

	// Start Bits <01>
	WRITE_PHY_ZERO();
	WRITE_PHY_ONE();

	// Read Command Bits <10>
	WRITE_PHY_ONE();
	WRITE_PHY_ZERO();

	// PHY Address, 00000 for interal PHY
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();
	WRITE_PHY_ZERO();

	// PHY Reg, 5 bits, MSB first
	for (i=0;i<5;i++) {
		if (Reg & 0x10) {
			WRITE_PHY_ONE();
		} else {
			WRITE_PHY_ZERO();
		}
		Reg <<= 1;
	}

	// Send turnaround bit <Z>
	WRITE_PHY_Z();

	// Read the data, 16bit, MSB first
	for (i=0;i<16;i++) {
		Data <<= 1;

		pNicRegs->Bank3.MGMT = 0;
		pNicRegs->Bank3.MGMT = MGMT_MCLK;

		if (pNicRegs->Bank3.MGMT & MGMT_MDI) {
			Data |= 1;
		}

		pNicRegs->Bank3.MGMT = 0;
	}

	// Send turnaround bit <Z>
	WRITE_PHY_Z();

	return Data;
}

/* OEMEthInit
 *
 *   Initialize ethernet for downloading image.
 *
 * Parameters:
 *
 *   pAdapter - IN - Adapter object to initialize
 *
 * Return Value:
 *    Return TRUE if init successful, FALSE if not.
 */
BOOL OEMEthInit (EDBG_ADAPTER *pAdapter)
{
	BOOL Status = TRUE;
    UCHAR *TmpMac;
	int i = 0;
	USHORT tmp = 0;
	USHORT *pTmp = NULL;

	KITLOutputDebugString("LAN91C111: +OEMEthInit\r\n");

	// Reset NIC
	BANK_SELECT(0);
	pNicRegs->Bank0.RCR = RCR_SOFT_RST;
	OALStallExecution(50000);
	pNicRegs->Bank0.RCR = 0;
	OALStallExecution(50000);

    // Get the MAC address
    GetMacAddress(pAdapter->Addr.wMAC);
    TmpMac = (PUCHAR)pAdapter->Addr.wMAC;

    KITLOutputDebugString("LAN91C111: MAC Addr");
    for (i=0;i<6;i++) {
        KITLOutputDebugString(":%B",TmpMac[i]);
    }
    KITLOutputDebugString("\r\n");
    
	// Write MAC Address to chip
	BANK_SELECT(1);
	for (i=0;i<6;i++) {
		pNicRegs->Bank1.IAR[i] = TmpMac[i];
	}

	// Configure Configuration Register
	BANK_SELECT(1);
	pNicRegs->Bank1.CR = CR_EPH_POWER_EN | CR_NO_WAIT;

	// Configure Control Register
	BANK_SELECT(1);
	pNicRegs->Bank1.CTR = (CTR_AUTO_RELEASE | CTR_TE_ENABLE);

	// Disable all interrupts
	BANK_SELECT(2);
	pNicRegs->Bank2.MSK = 0;

	KITLOutputDebugString("LAN91C111: Performing Auto Negotiation");
	// Reset internal PHY
	PhyWrite(PHY_CONTROL_REG,PHY_CONTROL_RST);

	// Wait 50ms per spec
	OALStallExecution(50000);

	while (PhyRead(PHY_CONTROL_REG) & PHY_CONTROL_RST) {
		;
	}

	// Configure PHY control
	BANK_SELECT(0);
	pNicRegs->Bank0.RPCR = RPCR_ANEG;

	PhyWrite(PHY_CONTROL_REG,PHY_CONTROL_ANEG_EN);

	// Configure and enable TX
	BANK_SELECT(0);
	pNicRegs->Bank0.TCR = (TCR_SWFDUP | TCR_PAD_EN | TCR_TXENA);

	// Configure and enable RX
	BANK_SELECT(0);
	pNicRegs->Bank0.RCR = RCR_RXEN;


	KITLOutputDebugString("LAN91C111: -OEMEthInit\r\n");
	
	return Status;
}

// Bytes are reversed when reading 16bits from data
// Writes seem to be OK though ???
USHORT GetData16()
{
	register USHORT tmp = pNicRegs->Bank2.DATA16[0];
	return ntohs(tmp);
}

/* OEMEthGetFrame
 *
 *   Check to see if a frame has been received, and if so copy to buffer. An optimization
 *   which may be performed in the Ethernet driver is to filter out all received broadcast
 *   packets except for ARPs.  
 *
 * Parameters:
 *
 *   pData    - OUT - Receives frame data
 *   pwLength - IN  - Length of Rx buffer
 *            - OUT - Number of bytes received
 *
 * Return Value:
 *    Return TRUE if frame has been received, FALSE if not.
 */
BOOL OEMEthGetFrame( BYTE *pData, UINT16 *pwLength) 
                      
{
    BOOL Status = FALSE;
	USHORT statusWord, length;
	USHORT i;
	USHORT *pData16 = (USHORT*)pData;
	USHORT tmp;
	UCHAR ints;
	
	// Everything for Rx is in bank 2
	BANK_SELECT(2);

	// Read interrupts
	ints = pNicRegs->Bank2.IST;

	if (ints & INT_RX_OVRN) {
		pNicRegs->Bank2.ACK = INT_RX_OVRN;
		KITLOutputDebugString("LAN91C111: RX Overrun\r\n");
		return FALSE;
	}
	
	if (!(ints & INT_RCV)) {
		// nothing to do
		return FALSE;
	}

	// Setup pointer register
	pNicRegs->Bank2.PTR = PTR_RCV | PTR_READ | PTR_AUTO_INCR;

	// Get the status word
	statusWord = GetData16();

	if (statusWord & RFS_ALIGN_ERR) {
		KITLOutputDebugString("LAN91C111: RX Align Error %H\r\n",statusWord);
		goto FreeBuffer;
	}
	if (statusWord & RFS_BAD_CRC) {
		KITLOutputDebugString("LAN91C111: RX Bad CRC %H\r\n",statusWord);
		goto FreeBuffer;
	}

	// read length and subtract 6 for status,byte count,control
	length = (GetData16() & 0x7FF) - 6;

	if (length > *pwLength) {
		KITLOutputDebugString("LAN91C111: Packet too large\r\n");
		goto FreeBuffer;
	}

	// Get the data
	for (i=0;i<length/2;i++) {
		*pData16++ = GetData16();
	}

	// Get final byte odd byte if present
	tmp = GetData16();
	if (tmp & 0x2000) {
		*(PUCHAR)pData16 = (UCHAR)tmp;
		length++;
	}

	// subtract 4 to account for CRC
	*pwLength = length-4;

	Status = TRUE;

//	KITLOutputDebugString("LAN91C111: Received packet of %d bytes\r\n",length);
//	DumpFrame(pData,length);

FreeBuffer:
	// Release buffer memory
	pNicRegs->Bank2.MMUCR = MMUCR_CMD_REMOVE_AND_RELEASE_RX_FRAME;

	while(pNicRegs->Bank2.MMUCR & MMUCR_BUSY) {
		;
	}

//	KITLOutputDebugString("LAN91C111: -OEMEthGetFrame\r\n");
	return Status;
}

/* OEMEthSendFrame
 *
 *   Send Ethernet frame.  
 *
 * Parameters:
 *
 *   pData    - IN - Data buffer
 *   dwLength - IN - Length of buffer
 *
 *  Return Value:
 *   TRUE if frame successfully sent, FALSE otherwise.
 */
BOOL
OEMEthSendFrame(BYTE *pData, DWORD dwLength)
{
	BOOL    Status = TRUE;
	USHORT  bufferSize;
	UCHAR   allocationResult;
	PUSHORT pData16 = (PUSHORT)pData;
	ULONG   i;
	USHORT  tmp;

//	KITLOutputDebugString("LAN91C111: +OEMEthSendFrame\r\n");	
//	DumpFrame(pData,dwLength);

	// Clear interrupt conditions
	BANK_SELECT(2);
	pNicRegs->Bank2.ACK = INT_TX_EMPTY | INT_TX;


	// Calculate buffer size, round up to even number
	bufferSize = (USHORT)(dwLength + 5);
    if (bufferSize & 1) bufferSize++;

	// Allocate memory buffer
	pNicRegs->Bank2.MMUCR = MMUCR_CMD_ALLOC_TX_MEM /* |
	                  (bufferSize>>8)*/;


	// Wait for allocation
	while(!(pNicRegs->Bank2.IST & INT_ALLOC)) {
		;
	}

	// Get allocation result
	allocationResult = pNicRegs->Bank2.ARR;

	if (allocationResult & AAR_FAILED) {
		Status = FALSE;
		KITLOutputDebugString("Failed to allocate Tx buffer\r\n");
		goto ErrorReturn;
	}

//	KITLOutputDebugString("Allocation Result (%X) = %B\r\n",&pNicRegs->Bank2.ARR,allocationResult);

	// Write allocation result to Packet Num register (PNR)
	pNicRegs->Bank2.PNR = allocationResult;
	// Set pointer to auto-increment
	pNicRegs->Bank2.PTR = PTR_AUTO_INCR;

    // Write the status word
	pNicRegs->Bank2.DATA16[0] = 0;
    // Write the buffer size
    pNicRegs->Bank2.DATA16[0] = bufferSize;

	// Copy data over
	for (i=0;i<dwLength/2;i++) {
		pNicRegs->Bank2.DATA16[0] = *pData16++;
	}

	// Copy over remaining byte. if any
	pData = (PUCHAR)pData16;
	if (dwLength&0x1) {
		pNicRegs->Bank2.DATA16[0] = TC_ODD_FRAME | *pData;
	} else {
		pNicRegs->Bank2.DATA16[0] = 0x0000;
	}

	// Enqueue packet into TX FIFO
	pNicRegs->Bank2.MMUCR = MMUCR_CMD_ENQUEUE_TX_PACKET;

	// Wait for success or error
	while(0==(pNicRegs->Bank2.IST & (INT_TX_EMPTY|INT_TX))) {
		;
	}

	// TX_INT indicates errors ?
	if (pNicRegs->Bank2.IST & INT_TX) {
		BANK_SELECT(0);
		tmp = pNicRegs->Bank0.EPHSR;

		// Transmitting a multicast or broadcast packet
		// shouldn't be considered an error...
		tmp &= ~(EPHSR_SQET|EPHSR_LTX_MULT|EPHSR_LTX_BRD);

		if (tmp) {
			KITLOutputDebugString("TX ERROR\r\n");

			KITLOutputDebugString("EPHSR = %H\r\n",tmp);

			tmp = PhyRead(1);
			KITLOutputDebugString("PHY Status= %H\r\n",tmp);

			// Clear stats registers
			BANK_SELECT(0);
			tmp = pNicRegs->Bank0.ECR;

			KITLOutputDebugString("ECR = %H\r\n",tmp);

			// Reenable TXENA
			pNicRegs->Bank0.TCR = (TCR_SWFDUP | TCR_PAD_EN | TCR_TXENA);


			// Release buffer memory ?
			BANK_SELECT(2);
			pNicRegs->Bank2.MMUCR = MMUCR_CMD_RELEASE_PACKET;

			while(pNicRegs->Bank2.MMUCR & MMUCR_BUSY) {
				;
			}

			Status = FALSE;
		}
	}

	// Clear interrupts
	BANK_SELECT(2);
	pNicRegs->Bank2.ACK = INT_TX_EMPTY | INT_TX;

ErrorReturn:

//	KITLOutputDebugString("LAN91C111: -OEMEthSendFrame\r\n");
	

	return Status;
}

#endif
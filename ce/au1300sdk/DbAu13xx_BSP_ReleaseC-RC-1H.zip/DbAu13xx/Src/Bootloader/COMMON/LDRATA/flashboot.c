/*++
Copyright (c) 1998,2004 BSQUARE Corporation. All rights reserved.

Module:

    flashboot.c

Description:

    This file will read an nk.bin from FLASH at the address specified.

Authors:

    Steve Brooks
    Curtis Jordan

Revision History

	Ian Rae - 11-17-04 - updated

--*/


#include <ldr.h>
#include <ldrata.h>
#include "platform.h"
#include "flash.h"



//
// Typedefs for .bin file parsing.  These require packing.
//

#include <pshpack1.h>

//
// Header for an MS BIN file.
//
typedef struct _BINFILE_HEADER {
    UCHAR SyncBytes[7];
    ULONG ImageAddress;
    ULONG ImageLength;
} BINFILE_HEADER, *PBINFILE_HEADER;


//
// Header for each record in an MS BIN file.
//
typedef struct _BINFILE_RECORD_HEADER {
        ULONG LoadAddress;
        ULONG Length;
        ULONG CheckSum;
} BINFILE_RECORD_HEADER, *PBINFILE_RECORD_HEADER;

#include <poppack.h>


#define READ_DEBUG1 0                           // Minimal output
#define READ_DEBUG2 0                           // Lots of output

ULONG
FlashFileRead(
    IN PUCHAR FlashArea,
    IN ULONG Length,    // in bytes
    OUT PUCHAR DataBuf
    )

/*++

Routine Description:

    Read the specified number of bytes from a file.

Arguments:

    FileDesc - File descriptor for the file from which to read.

    Length - The number of bytes to read.

    DataBuf - Buffer to receive the requested data.

Return Value:

    The number of bytes actually read is returned.  A return value of
    indicates that the operation failed.

--*/

{

    dbgKITLOutputDebugString(READ_DEBUG2, (
               "FlashFileRead: BytesRead=0x%x",
                Length));

    memcpy(DataBuf, FlashArea, Length);

    return(Length);
}






BOOL FlashReadBin( PULONG FlashAddress, PULONG JumpAddress)
/*++

Routine Description:

    This routine handles reading a BIN file.  It attempts to read the
    specified BIN file from the ATA device.  If it completes successfully,
    the jump address stored in the BIN file's last record is provided to
    the caller.

Arguments:

    FlashAddress - Flash address of nk.bin image.

    StartAddress - Location where the jump address read from the last record
        of the .bin file is to be placed.

Return Value:

    Returns TRUE if successful, FALSE otherwise.

--*/

{
    BINFILE_HEADER BinFileHeader;
    BINFILE_RECORD_HEADER BinRecordHeader;

    ULONG Destination;
    ULONG BytesToRead;
    ULONG BytesRead;
    ULONG BytesProcessed;
    ULONG FileSize;
    LONG CheckSum;
    PUCHAR pData;
	ULONG lpuFlashFileAddr;

	// Check Valid word
	if (READ_FLASH_ULONG(FlashAddress) != NK_BIN_SIG_WORD) {
		dbgKITLOutputDebugString(1, ("Flashboot: SIG NK.B not found at %x\r\n", FlashAddress));
		return FALSE;
	}

	// Read file size
	FileSize = READ_FLASH_ULONG(FlashAddress+1);
	lpuFlashFileAddr = (ULONG)(FlashAddress+2);

	//
    // Read the BIN file header.
    //
    BytesToRead = sizeof(BINFILE_HEADER);
    BytesRead = FlashFileRead((PUCHAR)lpuFlashFileAddr, BytesToRead, (PUCHAR)&BinFileHeader);
	lpuFlashFileAddr += BytesRead;

    //dbgKITLOutputDebugString(1, (
    //         "Image Address = %x  Image Size = %x  \r\n",
    //         BinFileHeader.ImageAddress,
    //         BinFileHeader.ImageLength));

    //
    // Sweep through the BIN file records and load the image.
    //
    BytesProcessed = sizeof(BINFILE_HEADER);

    //dbgKITLOutputDebugString(1, ("FileSize  - sizeof(BINFILE_RECORD_HEADER) %x  \r\n", (FileSize - sizeof(BINFILE_RECORD_HEADER))));

    while (BytesProcessed < FileSize - sizeof(BINFILE_RECORD_HEADER)) {
        BytesToRead = sizeof(BINFILE_RECORD_HEADER);
        BytesRead = FlashFileRead((PUCHAR)lpuFlashFileAddr, BytesToRead, (PUCHAR)&BinRecordHeader);
		lpuFlashFileAddr += BytesRead;

        BytesToRead = BinRecordHeader.Length;
        Destination = BinRecordHeader.LoadAddress;

        dbgKITLOutputDebugString(1, (
                 "Record: Address = %x  Length = %x  \r\n",
                 Destination,
                 BytesToRead));

        BytesRead = FlashFileRead((PUCHAR)lpuFlashFileAddr, BytesToRead, (PUCHAR)Destination);
		lpuFlashFileAddr += BytesRead;

        //
        // Checksum the data.
        //
        CheckSum = 0;
        for (pData = (PUCHAR)Destination;
             pData < (PUCHAR)Destination + BytesRead;
             pData++) {
            CheckSum += *pData;
        }

        if ((ULONG)CheckSum != BinRecordHeader.CheckSum) {
            dbgKITLOutputDebugString(1, ("ERROR: Record checksum failure.  Aborting.\r\n"));
            goto ErrorReturn;
        }

        BytesProcessed += BytesRead + sizeof(BINFILE_RECORD_HEADER);
	    //dbgKITLOutputDebugString(1, ("bytes processed  %x  \r\n", BytesProcessed));

    }

    //
    // Process the termination record which contains the jump address.
    //
    BytesToRead = sizeof(BINFILE_RECORD_HEADER);
    BytesRead = FlashFileRead((PUCHAR)lpuFlashFileAddr, BytesToRead, (PUCHAR)&BinRecordHeader);
	lpuFlashFileAddr += BytesRead;

    if (BinRecordHeader.LoadAddress != 0 ||
        BinRecordHeader.CheckSum != 0) {
        dbgKITLOutputDebugString(1, ("WARNING: Termination record invalid format.\r\n"));
    }

    *JumpAddress = BinRecordHeader.Length;

    return TRUE;

ErrorReturn:
    dbgKITLOutputDebugString(1, (
             "Failed reading from FLASH.\r\n"));

    return FALSE;
}

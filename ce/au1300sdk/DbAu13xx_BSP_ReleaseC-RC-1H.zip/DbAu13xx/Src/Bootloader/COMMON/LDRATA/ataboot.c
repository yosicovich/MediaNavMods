/*++
Copyright (c) 1998,2003 BSQUARE Corporation. All rights reserved.

Module:

    ataboot.c

Description:

    This file provides support routines for access to ATA disk devices and
    the FAT file system.

Authors:

    Steve Brooks
    Curtis Jordan

Revision History

    4-Sept-1998     Richard Chinn
        Adapted for use with the loader.  Minor restructuring and renaming.
        Added FATReadBin to read in .bin files.

    9-Oct-1998      Richard Chinn
        Removed ldrpcard.h include.
        Added command to set the ATA controller to 8-bit mode.
        Fixed AtaWaitForDisk function.  Added check for busy bit before
            checking the rest of the status register's contents.

    30-Nov-1998     Richard Chinn
        Changed data register accesses to be 16-bit (as they should be).
            Removed code that turned on the 8-bit mode.
        Added drive reset.
        Increased MAX_FAT_SIZE.
        These above modifications should allow this code to be used on a
            number of standard hard drives with FAT16.

    14-Dec-1998     Richard Chinn
        Added support for slave disks (drive 1).  Only master (drive 0) was
            supported on an ATA controller.
        Changed ATA controller reset sequence to enable interrupts.  This is
            necessary for the CE ATA driver.
        Added initialization for AtaDiskCount.  It wasn't initialized before.

--*/


#include <ldr.h>
#include <ldrata.h>
#include <bceddk.h>

#define UPCASE(x)   ((x) >= 'A' && (x) <= 'Z' ? (x) | 0x20 : (x))

#define MAX_ATA_DEV     2

//
// Maximum parameter values for ATA devices. Devices which exceed these
// values cannot currently be supported:
//

#define MAX_SECTOR_SIZE     1024
#define MAX_FAT_SIZE        (2*MAX_SECTOR_SIZE*64)

//
// The AtaDisks Table. This table contains information about each of the
// available ATA devices. It is populated by ATAFindDevices.
//
// Currently, there is a single FAT buffer shared between all devices.  This
// means that only one file may be open at once, system-wide.
//

ATA_DEVICE  AtaDisks[MAX_ATA_DEV];
ULONG AtaDiskCount = 0;

UCHAR  AtaDataBuf[MAX_SECTOR_SIZE];                 // One sector data buffer
UCHAR  AtaFATBuf[MAX_FAT_SIZE];                     // FAT buffer

//
// The FileTable Structure. This structure contains information about open
// files. The file handle returned from FATFileOpen is the index into
// this table plus one. (A zero return value indicates a failed FileOpen)
//

#define NUM_FILES       1

struct _FileTable{
    BOOLEAN     Opened;                         // TRUE if file is opened
    ATA_DEVICE  *Disk;                          // ATA Device containing file
    DIRENTRY    DirEntry;                       // Directory entry for the file
    ULONG       Position;                       // File Pointer. (byte offset)
    ULONG       Cluster;                        // Current cluster for file ops
    UCHAR       SecBuf[MAX_SECTOR_SIZE];        // Sector buffer for partial IO
} FileTable[NUM_FILES];



//
// Typedefs for .bin file parsing.  These require packing.
//

#include <pshpack1.h>

//
// Header for an MS BIN file.
//
typedef struct _BINFILE_HEADER {
    UCHAR SyncBytes[7];
    ULONG ImageAddress;
    ULONG ImageLength;
} BINFILE_HEADER, *PBINFILE_HEADER;


//
// Header for each record in an MS BIN file.
//
typedef struct _BINFILE_RECORD_HEADER {
        ULONG LoadAddress;
        ULONG Length;
        ULONG CheckSum;
} BINFILE_RECORD_HEADER, *PBINFILE_RECORD_HEADER;

#include <poppack.h>


static
ULONG
AtaWaitForDisk(
    IN OUT ATA_DEVICE* Disk,
    IN UCHAR WaitMask
    )

/*++

Routine Description:

    This routine polls the status register and waits for any of the bits
    specified in the WaitMask parameter to become set.  Once one of the bits
    is set, the function returns the last read status register value.  If
    the function times out, 0x800000xx is returned where xx is the last read
    status register value.

Arguments:

    Disk - Device to wait on.

    WaitMask - Bits to wait on.

Return Value:

    Returns the last read status register value or 0x800000xx.

--*/

{
    ATA_CMDREG *CmdReg;
    ULONG i;
    UCHAR Status;

    CmdReg = (ATA_CMDREG*)Disk->CmdBase;

    //
    // Poll the status register 100000 times with a 100 us retry interval
    // before giving up.  The delay amount here appears to be important as
    // too short of a delay can cause some cards to fail.  This is probably
    // because some cards are not be able to set the proper bits in the
    // status register once a command has been issued before polling begins.
    // The delay allows the card to set bits in the status register before
    // it is polled for the first time.  The delay also helps to normalize
    // the wait time across various platforms where a simple loop will have
    // widely varying run times.
    //
    for (i = 0; i < 100000; i++) {
        usDelay(100);
        Status = CmdReg->Status;
		if (Status & ATA_STAT_ERR)
			break;

        if (!(Status & ATA_STAT_BSY) &&
            (Status & WaitMask)) {
            return Status;

        }
    }

    dbgKITLOutputDebugString(1, (
             "AtaWaitForDisk timeout.\r\n"
             "    Status = 0x%B\r\n"
             "    Error = 0x%B\r\n"
             "    SecCount = 0x%B\r\n"
             "    SecNum = 0x%B\r\n"
             "    CylinderLo = 0x%B\r\n"
             "    CylinderHi = 0x%B\r\n"
             "    Head = 0x%B\r\n",
             Status,
             CmdReg->Error,
             CmdReg->SecCount,
             CmdReg->SecNum,
             CmdReg->CylinderLo,
             CmdReg->CylinderHi,
             CmdReg->Head));

    return Status | 0x80000000;
}



ULONG
ATAInitializeDevice(
    IN PVOID CommandBase,
    IN PVOID ControlBase,
    IN ULONG DriveNumber
    )

/*++

Routine Description:

    Initializes an ATA device.  May be called multiple times to initialize
    multiple ATA devices.

Arguments:

    CommandBase - ATA command registers base address.

    ControlBase - ATA control register base address.

    DriveNumber - Drive number to access.
                  0 = Master
                  1 = Slave

Return Value:

    Returns the the device index for the initialized ATA device if successful.
    This index is used by the FATFile routines to specifiy which ATA device to
    access.  If unsuccessful, 0xFFFFFFFF is returned.

--*/

{
    SECTORNUM Sector;
    BOOTSECT *BootSect;
    static ATA_DEVICE *Disk = AtaDisks;
    ULONG SecPerCyl;
    ATA_CMDREG *CmdReg;
    ATA_CTLREG *CtlReg;

	int DataSec, CountOfClusters, BPB_TotSec32,BPB_TotSec16,RootDirSectors,BPB_RootEntCnt,TotSec;

    //
    // Check if we can handle another ATA device.  Also validate the
    // parameters.  If everything looks good, continue with initialization.
    //

    if (AtaDiskCount >= MAX_ATA_DEV ||
        CommandBase == NULL) {
        return 0xFFFFFFFF;
    }

    Disk->CmdBase = (ULONG)CommandBase;
    Disk->CtlBase = (ULONG)ControlBase;

    if (DriveNumber == 1) {
        Disk->DriveNumberMask = 0x10;
    } else {
        Disk->DriveNumberMask = 0x00;
    }

    //
    // Reset the ATA device that will be used.
    //

    CmdReg = (ATA_CMDREG*)Disk->CmdBase;
    CtlReg = (ATA_CTLREG*)Disk->CtlBase;

    CmdReg->Head = Disk->DriveNumberMask;

    CtlReg->DevControl = 0x8 | ATA_CTRL_RESET;

    usDelay(50);

    //
    // The loader does not use interrupts, however, if we are loading from
    // a hard disk or other ATA device that will be used under CE, we need
    // to make sure interrupts are enabled once CE is running.
    //

    CtlReg->DevControl = 0x8 | ATA_CTRL_ENABLE_INTR;
    AtaWaitForDisk(Disk, 0xFF);

    //
    // Reset complete.  Read the partition table.
    //

    Sector.LBA = TRUE;
    Sector.u.LBASector = 0;
    Disk->BytesPerSec = 512;                        // Default to minimum

    if (ATAReadSectors(Disk, Sector, 1, AtaDataBuf) != ATA_ERR_NONE) {
        return 0xFFFFFFFF;
    }

#if 0
	{
	// Dump Sector 0 contents for debugging purposes
	int i;
	for (i = 0; i < Disk->BytesPerSec; ++i)
	dbgKITLOutputDebugString(1, ("%B ", AtaDataBuf[i]));
	}
#endif

	if ((AtaDataBuf[510] != 0x55) || (AtaDataBuf[511] != 0xAA))
	{
		dbgKITLOutputDebugString(1, ("Sector0 0xAA55 signature not found!\r\n"));
		return 0xFFFFFFFF;
	}

	// Determine if this sector contains a partition table or not.
	// Newer OS, like XP, may not put a partition table, but rather
	// immediately start the FAT filesystem at sector 0.
	BootSect = (BOOTSECT *)AtaDataBuf;
	if ((BootSect->MediaDesc & 0xF0) == 0xF0)
	{
		Disk->Partition.StartSector = 0;
	}
	else
	{
	    //
	    // Copy the partition table and extract the disk geometry and
	    // directory information from the boot sector.
	    //
		memcpy(&Disk->Partition,
			   &AtaDataBuf[PARTITION_TABLE_OFFS],
			   sizeof(PARTITION));

		if (Disk->Partition.SystemFlag == PART_EXTENDED) {
			// An extended "partition within a partition"....
			int ExtendedPartStart = Disk->Partition.StartSector;

			dbgKITLOutputDebugString(1, ("Extended partition found\r\n"));

		    Sector.u.LBASector = ExtendedPartStart;
			if (ATAReadSectors(Disk, Sector, 1, AtaDataBuf) != ATA_ERR_NONE){
				return 0xFFFFFFFF;
			}
			memcpy(&Disk->Partition,
				   &AtaDataBuf[PARTITION_TABLE_OFFS],
				   sizeof(PARTITION));

			// fix-up the partition start to account for the extra level of indirection
			Disk->Partition.StartSector += ExtendedPartStart;
		}
	}

    Sector.u.LBASector = Disk->Partition.StartSector;
    if (ATAReadSectors(Disk, Sector, 1, AtaDataBuf) != ATA_ERR_NONE){
        return 0xFFFFFFFF;
    }

    BootSect = (BOOTSECT *)AtaDataBuf;

    Disk->BytesPerSec = (BootSect->BytesPerSec[1] << 8) +
                        BootSect->BytesPerSec[0];

    Disk->SecPerCluster = BootSect->SecPerAlloc;

    Disk->SecPerFAT = (USHORT)BootSect->SectorsPerFAT;
    Disk->NumFATs = BootSect->NumFATs;
    Disk->ResvSectors = BootSect->ResvSectors;

    //
    // Validate the sector and FAT sizes.
    //

	// Taken from the "definitive source"....
	// http://www.microsoft.com/hwdev/hardware/fatgen.asp

	BPB_RootEntCnt = (BootSect->RootDirEntries[1] << 8) +
                        BootSect->RootDirEntries[0];

	RootDirSectors = ((BPB_RootEntCnt*32) + (Disk->BytesPerSec-1)) / Disk->BytesPerSec;

	BPB_TotSec16 = (BootSect->LogSectors[1] << 8) +
                        BootSect->LogSectors[0];

	BPB_TotSec32 = (BootSect->TotSec32[3] << 24) +
	               (BootSect->TotSec32[2] << 16) +
	               (BootSect->TotSec32[1] << 8) +
                    BootSect->TotSec32[0];

	if (BPB_TotSec16 != 0 ) {
		TotSec = BPB_TotSec16;
	} else {
		TotSec = BPB_TotSec32;
	}


	DataSec = TotSec - ( BootSect->ResvSectors
	                           + (BootSect->NumFATs * BootSect->SectorsPerFAT)
							   + RootDirSectors);

	CountOfClusters = DataSec / BootSect->SecPerAlloc;

	if (CountOfClusters < 4085) {
		// FAT12
		Disk->Partition.SystemFlag = PART_FAT12;
		dbgKITLOutputDebugString(1, ("Volume is FAT12 format with %d clusters\r\n",CountOfClusters));
	} else if (CountOfClusters < 65525) {
		// FAT16
		Disk->Partition.SystemFlag = PART_FAT16;
		dbgKITLOutputDebugString(1, ("Volume is FAT16 format with %d clusters\r\n",CountOfClusters));
	} else {
		dbgKITLOutputDebugString(1, ("Volume is FAT32 format with %d clusters\r\n",CountOfClusters));
		dbgKITLOutputDebugString(1, ("FAT32 is not supported by this loader\r\n"));
		return 0xFFFFFFFF;
		// FAT32 TODO
	}

    switch (Disk->Partition.SystemFlag) {

    case PART_FAT12 :
    case PART_FAT16 :
    case PART_FATBIG :
       if ((Disk->BytesPerSec > MAX_SECTOR_SIZE) ||
            (Disk->SecPerFAT*Disk->BytesPerSec > MAX_FAT_SIZE)) {
            dbgKITLOutputDebugString(1, (
                     "ATA device not supported.  Unknown FAT.\r\n"));
            return 0xFFFFFFFF;
        } else {

            //
            // FAT parameters okay.
            //
            break;
        }

        //
        // Else fall through and continue.
        //

    default :
           dbgKITLOutputDebugString(1, ("ATA device FAT not supported.\r\n"));
           return 0xFFFFFFFF;
    }

    Disk->SecPerTrack = BootSect->SectorsPerTrack;
    Disk->Heads = BootSect->NumHeads;

    SecPerCyl = BootSect->SectorsPerTrack * BootSect->NumHeads;

    if (SecPerCyl == 0) {

        SecPerCyl = 512; // force a reasonable value

        dbgKITLOutputDebugString(1,(
                 ("ATABOOT: WARNING - SecPerCyl = 0.  Using 512.\r\n")));

    }

    Disk->NumCyl = (USHORT)((Disk->Partition.NumSectors) / SecPerCyl);

    Disk->DirEntries = (BootSect->RootDirEntries[1] << 8) +
                       BootSect->RootDirEntries[0];

    Disk->FATBuf = NULL;

    //
    // Point to next device.
    //

    Disk += 1;

    //
    // Return the count of devices.
    //

    AtaDiskCount = Disk - AtaDisks;

    return(AtaDiskCount - 1);
}



ULONG
ATAReadSectors(
    IN OUT ATA_DEVICE *Disk,
    IN SECTORNUM Sector,
    IN ULONG Count,
    OUT PUCHAR SectorBuf
    )

/*++

Routine Description:

    This function reads the specified number of sectors from an ATA device.

Arguments:

    Disk - Pointer to an ATA disk structure.

    SectorNum - The starting sector number (LBA) from which to read.

    Count - The number of sectors to read.

    SectorBuf - Pointer to a buffer which receives the data.


Return Value:

    The value of the IDE error register is returned.  This value is zero
    if the operation completed successfully.

--*/

{
    ULONG RetVal = ATA_ERR_NONE;
    ULONG WaitResult;
    ATA_CMDREG *CmdReg = (ATA_CMDREG *)Disk->CmdBase;
    ULONG ii;
    UCHAR Status;
    USHORT AtaData;

	//
    // Validate the parameters.
    //

    if (Count == 0 || Count > 256){
        return( ATA_ERR_PARM );
    }

    //
    // Set the ATA registers to perform the read operation.
    //

    if (Sector.LBA){
        CmdReg->SecNum = LOBYTE(Sector.u.LBASector);
        CmdReg->CylinderLo = LOBYTE(Sector.u.LBASector >> 8);
        CmdReg->CylinderHi = LOBYTE(Sector.u.LBASector >> 16);
        CmdReg->Head = LOBYTE(0xE0 | (Sector.u.LBASector>>24) | Disk->DriveNumberMask);
    } else {
        CmdReg->SecNum = Sector.u.Sector;
        CmdReg->CylinderLo = LOBYTE(Sector.u.Cylinder);
        CmdReg->CylinderHi = LOBYTE(Sector.u.Cylinder >> 8);
        CmdReg->Head = LOBYTE(0xA0 | Sector.u.Head | Disk->DriveNumberMask);
    }

    CmdReg->SecCount = (UCHAR)(Count == 256 ? 0 : Count);

    //
    // Delay for some time before issuing the read command.  Some cards seem
    // to need this delay to work reliably.
    //
    usDelay(100);

    CmdReg->Command = ATA_CMD_READ;

    //
    // Wait for a data request signal from the controller.
    //

    WaitResult = AtaWaitForDisk(Disk, ATA_STAT_DRQ);

    if (WaitResult & 0x80000000) {
        dbgKITLOutputDebugString(1, ("ATAReadSectors: error waiting for DRQ on sector %B.\r\n", Sector.u.LBASector));
    }

    Status = (UCHAR)(WaitResult & 0xFF);


    if (Status & ATA_STAT_ERR) {

        dbgKITLOutputDebugString(1, ("ATA Command Status = 0x%B\r\n", Status));

        RetVal = CmdReg->Error;

        dbgKITLOutputDebugString(1, ("Error During Read: 0x%B\r\n", RetVal));

    } else {

        if (Count == 0) {
            Count = 256;
        }

        while (Count--) {

            //
            // Wait for next sector to become available.
            //
            WaitResult = AtaWaitForDisk(Disk, ATA_STAT_DRQ);

            if (WaitResult & 0x8000000) {
                dbgKITLOutputDebugString(1, ("ATAReadSectors: error waiting for DRQ.\r\n"));
            }

            if (Status & ATA_STAT_ERR) {

                dbgKITLOutputDebugString(1, ("ATA Command Status = 0x%B\r\n", Status));

                RetVal = CmdReg->Error;

                dbgKITLOutputDebugString(1, ("Error During Read: 0x%B\r\n", RetVal));

                break;
            }

            //
            // Read the sector data into the local buffer.
            //

            //
            // Some cards require a delay before accessing the data register
            // once DRQ is asserted.
            //
            usDelay(100);

            //
            // If the sector buffer is not aligned on a USHORT boundary, the
            // data must be copied one byte at a time to prevent alignment
            // exceptions on certain platforms.
            //

            for (ii = 0; ii < (ULONG)Disk->BytesPerSec/2; ii += 1) {

                AtaData = *(PUSHORT)&CmdReg->Data;

                *SectorBuf++ = LOBYTE(AtaData);
                *SectorBuf++ = HIBYTE(AtaData);

            }
        }
    }

    return(RetVal);
}


static
ULONG
ATAWriteSectors(
    IN OUT ATA_DEVICE *Disk,
    IN SECTORNUM Sector,
    IN ULONG Count,
    IN PUCHAR SectorBuf
    )

/*++

Routine Description:

    This function writes the specified number of sectors to an ATA device.

Arguments:

    Disk - Pointer to an ATA disk structure.

    SectorNum - The starting sector number (LBA) to write.

    Count - The number of sectors to write.

    SectorBuf - Pointer to a buffer which contains the data to write.

Return Value:

    The value of the IDE error register is returned.  This value is zero if
    the operation completed successfully.

Note:

    This function is not currently supported.  Though the code here should
    work, it has not been tested and is only here as a placeholder.

--*/

{
    ULONG RetVal = ATA_ERR_NONE;
    ULONG WaitResult;
    ATA_CMDREG *CmdReg = (ATA_CMDREG *)Disk->CmdBase;
    ULONG ii;
    UCHAR Status;
    USHORT AtaData;
    UCHAR HiByte;
    UCHAR LoByte;

    //
    // Validate the parameters.
    //

    if (Count == 0 || Count > 256) {
        return(ATA_ERR_PARM);
    }

    //
    // Set the ATA registers to perform the write operation.
    //

    if (Sector.LBA){
        CmdReg->SecNum = LOBYTE(Sector.u.LBASector);
        CmdReg->CylinderLo = LOBYTE(Sector.u.LBASector >> 8);
        CmdReg->CylinderHi = LOBYTE(Sector.u.LBASector >> 16);
        CmdReg->Head = LOBYTE(0xE0 | (Sector.u.LBASector>>24) | Disk->DriveNumberMask);
    } else {
        CmdReg->SecNum = Sector.u.Sector;
        CmdReg->CylinderLo = LOBYTE(Sector.u.Cylinder);
        CmdReg->CylinderHi = LOBYTE(Sector.u.Cylinder >> 8);
        CmdReg->Head = LOBYTE(0xA0 | Sector.u.Head | Disk->DriveNumberMask);
    }

    CmdReg->SecCount = (UCHAR)(Count == 256 ? 0 : Count);

    CmdReg->Command = ATA_CMD_WRITE;

    //
    // Wait for a drive request signal from the controller.
    //

    WaitResult = AtaWaitForDisk(Disk, ATA_STAT_DRQ);

    if (WaitResult & 0x80000000) {
        dbgKITLOutputDebugString(1, ("ATAWriteSectors: error waiting for DRQ.\r\n"));
    }

    Status = (UCHAR)(WaitResult & 0xFF);

    if ( Status & ATA_STAT_ERR ){

        dbgKITLOutputDebugString(1, ("ATA Command Status = 0x%B\r\n", Status));

        RetVal = CmdReg->Error;

        dbgKITLOutputDebugString(1, ("Error During Write: 0x%B\r\n", RetVal));

    } else {

        if (Count == 0) {
            Count = 256;
        }

        while (Count--) {

            //
            // The target will assert DRQ when ready for another sector.
            //

            WaitResult = AtaWaitForDisk(Disk, ATA_STAT_DRQ);

            if (WaitResult & 0x8000000) {
                dbgKITLOutputDebugString(1, ("ATAWriteSectors: error waiting for DRQ.\r\n"));
            }

            if (Status & ATA_STAT_ERR) {

                dbgKITLOutputDebugString(1, ("ATA Command Status = 0x%B\r\n", Status));

                RetVal = CmdReg->Error;

                dbgKITLOutputDebugString(1, ("Error During Write: 0x%B\r\n", RetVal));

                break;
            }

            //
            // Write the next block of data into the sector buffer.
            //

            for (ii = 0; ii < (ULONG)Disk->BytesPerSec/2; ii += 1) {

                LoByte = *SectorBuf++;
                HiByte = *SectorBuf++;

                AtaData = MAKEWORD(LoByte, HiByte);

                *(PUSHORT)&CmdReg->Data = AtaData;
            }
        }
    }

    return( RetVal );
}


static
ULONG
FATExtractName(
    IN PUCHAR Pathname,
    IN PUCHAR Filename
    )

/*++

Routine Description:

    Extract the next component from the specified pathname. The pathname
    component is converted into the 11 character filename:extension format
    of a FAT directory entry.

Arguments:

    Pathname - Pointer to an ASCII pathname.

    Filename - Pointer to an ASCII string which receives the filename.

Return Value:

    The size in characters of the next pathname component (file or dir)

Notes:

    This function operates only on 8.3 format filenames.

--*/

{
    ULONG ii;
    ULONG FLen, ExLen;
    ULONG FirstSlash = 0;

    //
    // Put the filename into the 11 character format of a directory entry.
    //

    //
    // Skip initial slash and remember it.
    //
    if (Pathname[0] == '\\') {
        Pathname += 1;
        FirstSlash = 1;
    }

    FLen = 8;
    for (ii = 0; ii < 8; ii += 1){

        if (*Pathname != 0 &&
            *Pathname != '.' && *Pathname != '\\') {

            Filename[ii] = *Pathname++;

        } else {

            Filename[ii] = ' ';

            if (FLen == 8) {
                FLen = ii;
            }

        }

    }

    //
    // Skip to extension.
    //
    if (*Pathname == '.' ) {
        Pathname += 1;
    }

    ExLen = 3;
    for (ii = 0; ii < 3; ii += 1) {

        if (*Pathname != 0 && *Pathname != '\\') {
            Filename[ii+8] = *Pathname++;
        } else {
            Filename[ii+8] = ' ';

            if (ExLen == 3) {
                ExLen = ii;
            }
        }
    }

    return (FLen + ExLen + FirstSlash);
}


static
ULONG
FATGetNextCluster(
    IN OUT ATA_DEVICE *Disk,
    IN ULONG Cluster
    )

/*++

Routine Description:

    Returns the next cluster in the FAT chain on the specified disk.

Arguments:

    Disk  - The ATA device containing the FAT chain to follow.

    Cluster - The cluster number from which the next cluster is determined.

Return Value:

    The number of the next cluster in the FAT chain is returned.
    FAT_CLUSTER_BAD is returned if the current cluster or chain is invalid

--*/

{
    SECTORNUM Sector;
    PUCHAR FatPtr;
    USHORT FatEntry;
    ULONG FatOffs;
    ULONG BadSector;

    if (Disk->Partition.SystemFlag == PART_FAT12) {

        BadSector = FAT12_CLUSTER_BAD;
        if ( Cluster >= FAT12_CLUSTER_MAX ){
            return(BadSector);
        }

    } else {

        BadSector = FAT16_CLUSTER_BAD;
        if ( Cluster >= FAT16_CLUSTER_MAX ){
            return(BadSector);
        }

    }

    //
    // If the FAT for the specified device hasn't been read, get it now.
    //

    if (!Disk->FATBuf){

        Sector.LBA = TRUE;
        Sector.u.LBASector = Disk->Partition.StartSector + Disk->ResvSectors;

        if (ATAReadSectors(Disk, Sector, Disk->SecPerFAT, AtaFATBuf) != 0) {
            return(BadSector);
        }

        Disk->FATBuf = AtaFATBuf;
    }

    if ( Disk->Partition.SystemFlag == PART_FAT12 ){

        //
        // Determine the byte within the FAT containing the current
        // cluster number.
        //

        FatPtr = (PUCHAR)Disk->FATBuf;

        FatOffs = (Cluster * 12) >> 3;

        if (Cluster & 0x01) {
            //
            // Odd cluster. 4 bit offset.
            //

            FatEntry = (FatPtr[FatOffs] & 0xf0) >> 4;
            FatEntry |= FatPtr[FatOffs+1] << 4;

        } else {

            FatEntry = FatPtr[FatOffs];
            FatEntry |= (FatPtr[FatOffs+1] & 0x0f) << 8;

        }

    } else if ((Disk->Partition.SystemFlag == PART_FAT16) ||
               (Disk->Partition.SystemFlag == PART_FATBIG)) {

        //
        // Determine the byte within the FAT containing the current
        // cluster number.
        //

        FatPtr = (PUCHAR)Disk->FATBuf;

        FatOffs = (Cluster * 2);

        FatEntry = FatPtr[FatOffs] + (FatPtr[FatOffs+1] << 8);

    } else {
        //
        // Error: Unknown FAT.
        //

        return(BadSector);

    }

    return(FatEntry);
}



ULONG
FATFileOpen(
    IN ULONG DevIndex,
    IN PUCHAR Filename
    )

/*++

Routine Description:

    Open a file on the specified ATA device.

Arguments:

    DevIndex - Index of the ATA device to use for opening the file.

    Filename - Character string representing the name of the file to open.

Return Value:

    The return value is a file handle to be used in subsequent operations.
    If the file could not be opened, the return value is zero.

--*/

{
    struct _FileTable *CurFile;
    ATA_DEVICE *Disk;
    UCHAR FName[13];
    BOOLEAN SubDir;
    BOOLEAN Match;
    SECTORNUM Sector;
    DIRENTRY *CurEntry;
    ULONG Entries;
    ULONG ii;


    //
    // Find an available file table entry.
    //

    for (CurFile = &FileTable[0]; CurFile < &FileTable[NUM_FILES]; CurFile++) {
        if (!CurFile->Opened) {
            break;
        }
    }

    if (CurFile == &FileTable[NUM_FILES]) {
        //
        // No file table entries.
        //
        return(0);
    }

    //
    // Validate the device argument and establish a pointer to the device.
    //

    if (DevIndex >= AtaDiskCount) {
        //
        // Invalid device.
        //
        return(0);
    }
    Disk = &AtaDisks[DevIndex];

    Entries = Disk->DirEntries;

    Sector.LBA = TRUE;
    Sector.u.LBASector = Disk->Partition.StartSector;
    Sector.u.LBASector += Disk->ResvSectors + Disk->NumFATs * Disk->SecPerFAT;

    Filename += FATExtractName(Filename, FName);

    if (SubDir = (Filename[0] == '\\')) {
        Filename += 1;
    }

    while (Entries > 0 && !ATAReadSectors(Disk, Sector, 1, AtaDataBuf)) {

        CurEntry = (DIRENTRY *)AtaDataBuf;

        while (CurEntry < (DIRENTRY *)&AtaDataBuf[Disk->BytesPerSec]) {

            if (CurEntry->FileName[0] != DIRENT_UNUSED &&
                CurEntry->FileName[0] != DIRENT_DELETED) {

                if (CurEntry->FileName[0] == DIRENT_E5CHAR) {
                    CurEntry->FileName[0] = 0xe5;
                }

                Match = TRUE;
                for (ii = 0; ii < 11 && Match == TRUE; ii += 1) {
                   Match &= UPCASE(CurEntry->FileName[ii]) ==
                            UPCASE(FName[ii]);
                }

                //
                // Compare the filename and extension for the current entry.
                //

                if (Match) {

                    //
                    // Matching entry found.
                    //

                    if (SubDir) {

                        //
                        // Exit inner while loop and calculate the next
                        // sector from which to read.
                        //

                        break;
                    }

                    memcpy(&CurFile->DirEntry, CurEntry, sizeof(DIRENTRY));
                    CurFile->Cluster = CurEntry->StartCluster;
                    CurFile->Position = 0;
                    CurFile->Disk = Disk;
                    CurFile->Opened = TRUE;

                    return((CurFile - FileTable) + 1);
                }

            }

            CurEntry += 1;
            Entries -= 1;

        } // while CurEntry


        //
        // Determine the next sector to read and update the entry count.
        //

        if (SubDir && (CurEntry->Attribute & FATTR_DIR)) {

            //
            // Determine the starting sector for the subdirectory.
            //

            Sector.u.LBASector = Disk->Partition.StartSector + Disk->ResvSectors;
            Sector.u.LBASector += (Disk->NumFATs * Disk->SecPerFAT);
            Sector.u.LBASector +=
                ((Disk->DirEntries * sizeof(DIRENTRY)) / Disk->BytesPerSec);
            Sector.u.LBASector +=
                ((CurEntry->StartCluster-2) * Disk->SecPerCluster);

            //
            // Determine whether the next part of the pathname is another
            // directory.
            //

            Filename += FATExtractName(Filename, FName);

            if (SubDir = (Filename[0] == '\\')) {
                Filename += 1;
            }

            Entries = (Disk->SecPerCluster * Disk->BytesPerSec) /
                      sizeof(DIRENTRY);
        } else {
            Sector.u.LBASector += 1;
        }

    } // while Entries

    return(0);
}



VOID
FATFileClose(
    IN ULONG FileDesc
    )

/*++

Routine Description:

    Close a file previously opened by FATFileOpen.

Arguments:

    FileDesc - File descriptor returned by FATFileOpen.

Return Value:

    None.

--*/

{
    FileDesc -= 1;

    if (FileDesc < NUM_FILES && FileTable[FileDesc].Opened) {
        FileTable[FileDesc].Opened = FALSE;
    }

}



ULONG
FATFileSize(
    IN ULONG FileDesc
    )

/*++

Routine Description:

    Return the size in bytes of the specified file

Arguments:

    FileDesc - File descriptor for the file.

Return Value:

    Returns the number of bytes in the file identified by FileDesc.  Zero
    is returned if FileDesc is not a valid file descriptor

--*/

{
    FileDesc -= 1;                              // FileOpen returns Index+1

    if (FileDesc >= NUM_FILES || !FileTable[FileDesc].Opened) {
        return(0);
    }

    return(FileTable[FileDesc].DirEntry.Length);
}



ULONG
FATFileSeek(
    IN ULONG FileDesc,
    IN ULONG Position
    )

/*++

Routine Description:

    Set the file pointer for the specified file to the requested position.

Arguments:

    FileDesc - File descriptor for the file to perform the seek operation.

    Position - Position in the file to place the file pointer.

Return Value:

    The new file position is returned.  If a position beyond the length
    of the file was requested, the file pointer is placed at the end of
    the file and the file length, in bytes, is returned.

--*/

{
    struct _FileTable *File;
    ATA_DEVICE *Disk;
    SECTORNUM Sector;
    ULONG ClusterSize;
    ULONG Offset;
    ULONG SeekPos;
    ULONG DataArea;

    FileDesc -= 1;                              // FileOpen returns Index+1

    if (FileDesc >= NUM_FILES || !FileTable[FileDesc].Opened) {
        return(0);
    }
    File = &FileTable[FileDesc];
    Disk = File->Disk;
    ClusterSize = Disk->BytesPerSec * Disk->SecPerCluster;

    if (Position >= File->DirEntry.Length) {

        File->Position = File->DirEntry.Length;

        if (Disk->Partition.SystemFlag == PART_FAT12) {
            File->Cluster = FAT12_CLUSTER_END;
        } else {
            File->Cluster = FAT16_CLUSTER_END;
        }
        return(File->Position);
    }

    File->Position = Position;

    //
    // Follow the cluster chain to set the current file cluster.
    //

    File->Cluster = File->DirEntry.StartCluster;

    for (SeekPos = 0;
         SeekPos+ClusterSize <= Position;
         SeekPos += ClusterSize) {
        File->Cluster = FATGetNextCluster(Disk, File->Cluster);
    }

    //
    // Prime the sector buffer by reading in the current sector.
    // The data area on the disk follows the boot sector, FATs, and root
    // directory.
    //

    Offset = Position & (ClusterSize-1);
    if (Offset & (Disk->BytesPerSec-1)) {

        DataArea = Disk->Partition.StartSector + Disk->ResvSectors;
        DataArea += (Disk->NumFATs*Disk->SecPerFAT);
        DataArea +=
            ((Disk->DirEntries * sizeof(DIRENTRY)) / Disk->BytesPerSec);

        Sector.LBA = TRUE;
        Sector.u.LBASector =
            DataArea + ((File->Cluster-2)*Disk->SecPerCluster);
        Sector.u.LBASector += Offset / Disk->BytesPerSec;

        if (ATAReadSectors(Disk, Sector, 1, File->SecBuf) != ATA_ERR_NONE) {
            return(0);
        }
    }

    return(File->Position);
}



#define READ_DEBUG1 0                           // Minimal output
#define READ_DEBUG2 0                           // Lots of output

ULONG
FATFileRead(
    IN ULONG FileDesc,
    IN ULONG Length,
    OUT PUCHAR DataBuf
    )

/*++

Routine Description:

    Read the specified number of bytes from a file.

Arguments:

    FileDesc - File descriptor for the file from which to read.

    Length - The number of bytes to read.

    DataBuf - Buffer to receive the requested data.

Return Value:

    The number of bytes actually read is returned.  A return value of
    indicates that the operation failed.

--*/

{
    struct _FileTable *File;
    ATA_DEVICE *Disk;
    SECTORNUM Sector;
    ULONG ClusterSize;
    ULONG DataArea;
    ULONG BytesRead;
    ULONG SecNum, SecOffset;
    ULONG CopyLen;


    FileDesc -= 1;                              // FileOpen returns Index+1

    if (FileDesc >= NUM_FILES || !FileTable[FileDesc].Opened) {
        return(0);
    }

    File = &FileTable[FileDesc];
    Disk = File->Disk;
    ClusterSize = Disk->BytesPerSec * Disk->SecPerCluster;

    dbgKITLOutputDebugString(READ_DEBUG1, (
             "FATFileRead: Position=0x%X  Length=0x%x\r\n",
             File->Position,
             Length));

    //
    // The data area on the disk follows the boot sector, FATs, and root
    // directory.
    //

    DataArea = Disk->Partition.StartSector + Disk->ResvSectors;
    DataArea += (Disk->NumFATs*Disk->SecPerFAT);
    DataArea += ((Disk->DirEntries * sizeof(DIRENTRY)) / Disk->BytesPerSec);

    BytesRead = 0;
    Sector.LBA = TRUE;

    while (BytesRead < Length) {

        //
        // For non-cluster accesses, determine the sector number and offset
        // within the current cluster.
        //

        SecOffset = File->Position & (Disk->BytesPerSec-1);
        SecNum = (File->Position & (ClusterSize-1)) / Disk->BytesPerSec;

        Sector.u.LBASector = DataArea +
                             ((File->Cluster-2)*Disk->SecPerCluster);
        Sector.u.LBASector += SecNum;


        //
        // Perform small and unaligned reads into the file's sector buffer.
        // Copy bytes out of the sector buffer as long as it is valid.
        //

        while (SecOffset != 0 || (Length-BytesRead < Disk->BytesPerSec)) {

            dbgKITLOutputDebugString(READ_DEBUG2, (
                     "FATFileRead(0): BytesRead=0x%x",
                     BytesRead));

            dbgKITLOutputDebugString(READ_DEBUG2, (
                     "  SecNum=0x%x  SecOffs=0x%x\r\n",
                     SecNum, SecOffset));

            if (SecOffset == 0) {

                //
                // Small read from a sector boundary. Read a sector into the
                // sector buffer.
                //

                if (ATAReadSectors(Disk,
                                   Sector,
                                   1,
                                   File->SecBuf) != ATA_ERR_NONE){
                    return(BytesRead);
                }
            }

            //
            // The current sector buffer is valid. Copy bytes out of the
            // sector buffer.
            //

            CopyLen = min(Length-BytesRead, Disk->BytesPerSec - SecOffset);

            memcpy(DataBuf, &File->SecBuf[SecOffset], CopyLen);
            File->Position += CopyLen;

            if (!(File->Position & (ClusterSize-1))) {

                File->Cluster = FATGetNextCluster(Disk, File->Cluster);
                Sector.u.LBASector = DataArea +
                                     ((File->Cluster-2)*Disk->SecPerCluster);

                SecNum = 0;

            } else {

                Sector.u.LBASector += 1;
                SecNum += 1;

            }
            SecOffset = 0;

            DataBuf += CopyLen;
            BytesRead += CopyLen;

            if (BytesRead == Length){
                return(BytesRead);
            }

        } // SecOffset != 0


        //
        // On a sector boundary or a sub-cluster read on a cluster boundary.
        //

        if ( SecNum > 0 || (Length-BytesRead < ClusterSize) ){

            dbgKITLOutputDebugString(READ_DEBUG2, (
                     "FATFileRead(1): BytesRead=0x%x",
                     BytesRead));

            dbgKITLOutputDebugString(READ_DEBUG2, (
                     "  SecNum=0x%x  SecOffs=0x%x\r\n",
                     SecNum, SecOffset));

            CopyLen = (Disk->SecPerCluster-SecNum) * Disk->BytesPerSec;

            if (CopyLen > (Length-BytesRead)) {

                CopyLen = Length-BytesRead;

            }

            if (ATAReadSectors(Disk,
                               Sector,
                               CopyLen/Disk->BytesPerSec,
                               DataBuf) != ATA_ERR_NONE ) {
                return(BytesRead);
            }

            CopyLen &= ~(Disk->BytesPerSec-1);

            File->Position += CopyLen;

            if (!(File->Position & (ClusterSize-1))) {
                File->Cluster = FATGetNextCluster(Disk, File->Cluster);
            }

            DataBuf += CopyLen;
            BytesRead += CopyLen;

        } // SecNum > 0

        //
        // On a cluster boundary. Perform cluster sized operations.
        //

        while (Length-BytesRead >= ClusterSize) {

            //
            // Perform cluster size read operations:
            // Cluster #2 starts at the beginning of the data area.
            //

            Sector.u.LBASector = DataArea +
                                 ((File->Cluster-2)*Disk->SecPerCluster);

            //
            // Read the buffer one cluster at a time.
            //

            dbgKITLOutputDebugString(READ_DEBUG2, (
                     "FATFileRead: BytesRead=0x%x",
                     BytesRead));

            dbgKITLOutputDebugString(READ_DEBUG2, (
                     "Cluster=0x%x  Sector=0x%x  Pos=0x%x\r\n",
                     File->Cluster,
                     Sector.u.LBASector,
                     File->Position));

            if (ATAReadSectors(File->Disk,
                               Sector,Disk->SecPerCluster,
                               DataBuf) == ATA_ERR_NONE) {

                BytesRead += ClusterSize;
                DataBuf += ClusterSize;
                File->Cluster = FATGetNextCluster(Disk, File->Cluster);
                File->Position += ClusterSize;

            } else {
                return(BytesRead);
            }

        } // Cluster boundary

    }

    return(BytesRead);
}






BOOL
FATReadBin(
    IN ULONG AtaDeviceIndex,
    IN PUCHAR FileName,
    OUT PULONG JumpAddress
    )

/*++

Routine Description:

    This routine handles reading a BIN file.  It attempts to read the
    specified BIN file from the ATA device.  If it completes successfully,
    the jump address stored in the BIN file's last record is provided to
    the caller.

Arguments:

    AtaDeviceIndex - Index that identifies the ATA device to access.

    FileName - Name of the .bin file to read.

    StartAddress - Location where the jump address read from the last record
        of the .bin file is to be placed.

Return Value:

    Returns TRUE if successful, FALSE otherwise.

--*/

{
    BINFILE_HEADER BinFileHeader;
    BINFILE_RECORD_HEADER BinRecordHeader;
    ULONG FatFileHandle;
    ULONG Destination;
    ULONG BytesToRead;
    ULONG BytesRead;
    ULONG BytesProcessed;
    ULONG FileSize;
    LONG CheckSum;
    PUCHAR pData;

    //
    // Attempt to open the file.
    //
    FatFileHandle = FATFileOpen(AtaDeviceIndex, FileName);

    if (FatFileHandle == 0) {
        goto ErrorReturn;
    }

    //
    // Determine file size.
    //
    FileSize = FATFileSize(FatFileHandle);

    if (FileSize < sizeof(BINFILE_HEADER) + 2*sizeof(BINFILE_RECORD_HEADER)) {
        dbgKITLOutputDebugString(1, (
                 "BIN file size %u bytes is too small.\r\n",
                 FileSize));
        goto ErrorReturn;
    }

    //
    // Read the BIN file header.
    //
    BytesToRead = sizeof(BINFILE_HEADER);
    BytesRead = FATFileRead(FatFileHandle,
                            BytesToRead,
                            (PUCHAR)&BinFileHeader);

    if (BytesRead != BytesToRead) {
        goto ErrorReturn;
    }

    dbgKITLOutputDebugString(1, (
             "Image Address = 0x%x  Image Size = 0x%x\r\n",
             BinFileHeader.ImageAddress,
             BinFileHeader.ImageLength));

    //
    // Sweep through the BIN file records and load the image.
    //
    BytesProcessed = sizeof(BINFILE_HEADER);

    while (BytesProcessed < FileSize - sizeof(BINFILE_RECORD_HEADER)) {
        BytesToRead = sizeof(BINFILE_RECORD_HEADER);
        BytesRead = FATFileRead(FatFileHandle,
                                BytesToRead,
                                (PUCHAR)&BinRecordHeader);

        if (BytesRead != BytesToRead) {
            goto ErrorReturn;
        }

        BytesToRead = BinRecordHeader.Length;
        Destination = BinRecordHeader.LoadAddress;

        dbgKITLOutputDebugString(0, (
                 "Record: Address = 0x%x  Length = %u\r\n",
                 Destination,
                 BytesToRead));

        BytesRead = FATFileRead(FatFileHandle,
                                BytesToRead,
                                (PUCHAR)Destination);

        if (BytesRead != BytesToRead) {
            goto ErrorReturn;
        }

        //
        // Checksum the data.
        //
        CheckSum = 0;
        for (pData = (PUCHAR)Destination;
             pData < (PUCHAR)Destination + BytesRead;
             pData++) {
            CheckSum += *pData;
        }

        if ((ULONG)CheckSum != BinRecordHeader.CheckSum) {
            dbgKITLOutputDebugString(1, ("ERROR: Record checksum failure.  Aborting.\r\n"));
            goto ErrorReturn;
        }

        BytesProcessed += BytesRead + sizeof(BINFILE_RECORD_HEADER);
    }

    //
    // Process the termination record which contains the jump address.
    //
    BytesToRead = sizeof(BINFILE_RECORD_HEADER);
    BytesRead = FATFileRead(FatFileHandle,
                            BytesToRead,
                            (PUCHAR)&BinRecordHeader);

    if (BytesRead != BytesToRead) {
        dbgKITLOutputDebugString(1, ("Failed to read termination record.\r\n"));
        goto ErrorReturn;
    }

    if (BinRecordHeader.LoadAddress != 0 ||
        BinRecordHeader.CheckSum != 0) {
        dbgKITLOutputDebugString(1, ("WARNING: Termination record invalid format.\r\n"));
    }

    *JumpAddress = BinRecordHeader.Length;

    return TRUE;

ErrorReturn:
    dbgKITLOutputDebugString(1, (
             "Failed reading %s on ATA device %u.\r\n",
             FileName,
             AtaDeviceIndex));

    return FALSE;
}

BOOL FATReadFile( ULONG AtaDeviceIndex, PUCHAR FileName, PULONG pDestAddress, PULONG pFileSize )
/*++

Routine Description:

    This routine reads a file from an ATA device into system memory.
	It returns the filesize.

Arguments:

    AtaDeviceIndex - Index that identifies the ATA device to access.
    FileName - Name of the file to read.
    DestAddress - Where file should be copied to
	FileSize    - Return the filesize here

Return Value:

    Returns TRUE if successful, FALSE otherwise.

--*/

{
    ULONG FatFileHandle;
    ULONG BytesRead;
    ULONG FileSize;

    //
    // Attempt to open the file.
    //
    FatFileHandle = FATFileOpen(AtaDeviceIndex, FileName);

    if (FatFileHandle == 0) {
        goto ErrorReturn;
    }

    //
    // Determine file size.
    //
    FileSize = FATFileSize(FatFileHandle);


    dbgKITLOutputDebugString(1, ("File found, size %d bytes. Reading into RAM...\r\n", FileSize));

	// Read the file
    BytesRead = FATFileRead(FatFileHandle,
                            FileSize,
                            (PUCHAR)pDestAddress);

    if (BytesRead != FileSize) {
        goto ErrorReturn;
    }

    dbgKITLOutputDebugString(1, ("File read OK!\r\n"));

    *pFileSize = FileSize;

    return TRUE;

ErrorReturn:
    dbgKITLOutputDebugString(1, (
             "Failed reading %s on ATA device %u.\r\n",
             FileName,
             AtaDeviceIndex));

    return FALSE;
}



/*++
    Copyright (c) 1998 BSQUARE Corporation. All rights reserved.

Module:

    pcmboot.c

Module Description:

    This file contains functions which implement the minimal set of PCMCIA
    Card Services functions required to support booting a Windows CE image
    from a PCMCIA device.

Author:

    Steve Brooks

Functions:

    PCMGetFirstTuple            - Return first CIS Tuple
    PCMGetNextTuple             - Return next CIS Tuple
    PCMFindPcCards              - Find all inserted PC Cards
    PCMGetFirstCard             - return pointer to first available card
    PCMGetNextCard              - return pointer to next available card

    PCMFindDevice               - Search Sockets for bootable device
    PCMRequestConfiguration     - Set Configuration parameters

Revision History:

    8-Sept-1998     Richard Chinn
    Changed PCMRequestConfiguration to take in a parameter that is used
    to find valid I/O configurations and set the correct I/O access width.
    So far, this is all that is needed,  The next step may be to pass
    configuration choices up to the caller to choose.

    Changed PCMFindDevice to pass in configuration flags to
    PCMRequestConfiguration based on the card function.  This is pretty coarse
    grained, but until it becomes necessary to pass configuration choices
    back to the caller, this should be sufficient.

    Added PCMFindAtaDevices.  This function searchs the PC cards for ATA
    devices and calls the ATA initialization routine.

    10-Sept-1998    Richard Chinn
    Added support to PCMFindPcCards to read TUP_DEVICE and extract the
    device size.  This size is stored in the card structure and is used by
    PCMFindDevice to configure memory cards that don't contain configuration
    tables.  This allows most linear memory cards to have a window opened
    at the base of common memory.

    14-Dec-1998     Richard Chinn
    Changed the call to AtaInitializeDevice to include a drive number of 0.
    This is needed to support changes to the ATA loader component.  Also
    removed the forced 8-bit I/O for ATA cards as the ATA loader component
    has been changed to use 16-bit accesses.
 
--*/

#include <ldr.h>
#include <ldrpcard.h>
#include <ldrata.h>


PCM_CARDINFO  PcCards[NUM_SOCKETS]; // Info for all installed PC Cards
ULONG PcCardCount;                  // Number of cards found

PUCHAR PCMTuplePtr = NULL;          // CIS tuple ptr for GetFirst/GetNextTuple


#if DEBUG
static
VOID
PCMDumpTuple(
    IN PCM_TUPLE *Tuple
    )

/*++

Routine Description:

    Dumps the contents of a CIS tuple. For debugging purposes only.

Arguments:

    Tuple - Pointer to a character array of CIS tuple data

Return Value:

    None.

--*/

{
    ULONG Count;

    dbgKITLOutputDebugString(1, ("Tuple Code=0x%B\r\n", Tuple->TplCode));

    for (Count = 0; Count < Tuple->TplLink; Count += 1) {

        dbgKITLOutputDebugString(1, ("%B ", Tuple->TplData[Count]));

        if (!(Count & 0x0f)) {
            dbgKITLOutputDebugString(1, ("\r\n"));                     // wrap the line
        }

    }
    dbgKITLOutputDebugString(1, ("\r\n\r\n"));
}
#else

#define PCMDumpTuple(t)

#endif // DEBUG


BOOLEAN
PCMGetFirstTuple(
    IN ULONG Socket,
    OUT PCM_TUPLE *Tuple
    )

/*++

Routine Description:

    Read the first tuple structure from the CIS of the current PC Card.

Arguments:

    Tuple - Pointer to a byte array which will receive the first tuple.

Return Value:

    TRUE if the current PC Card is available, and Tuple is updated;
    FALSE otherwise.

--*/

{
    ULONG Index;
    PCM_CARDINFO *PcCard;

    if (Socket >= NUM_SOCKETS) return FALSE;

    PcCard = &PcCards[Socket];
    PCMTuplePtr = (PUCHAR)PcCard->Attrib.Base;

#if DEBUG
    if (PcCard->Interface == PCMInterfaceNone ||
        PcCard->Attrib.Type != PCMWindowAttribute ||
        PCMTuplePtr == NULL  ||
        Tuple == NULL) {

        return FALSE;                                   // Serious error
    }
#endif

    if (*PCMTuplePtr == TUP_END) return FALSE;          // No CIS data.

    //
    // Copy the contents of the first tuple.
    // PCMTuplePtr is a pointer into CIS space, which is an eight bit space
    // and can only be accessed via even addresses.
    //

    Tuple->TplCode = PCMTuplePtr[0];
    Tuple->TplLink = PCMTuplePtr[2];

    for (Index = 0; Index < PCMTuplePtr[2]; Index += 1) {

        Tuple->TplData[Index] = PCMTuplePtr[4+(Index*2)];

    }
    PCMTuplePtr += 4 + (PCMTuplePtr[2] * 2);

    return(TRUE);
}



BOOLEAN
PCMGetNextTuple(
    IN ULONG Socket,
    OUT PCM_TUPLE *Tuple
    )

/*++

Routine Description:

    Read the next tuple structure from the CIS of the current PC Card.
    This function assumes that PCMTuplePtr has been set by PCMGetFirstTuple.

Arguments:

    Tuple - Pointer to a byte array which will receive the tuple.

Return Value:

    TRUE if a tuple is returned; FALSE otherwise.

--*/

{
    ULONG Index;
    PCM_CARDINFO *PcCard;

    if (Socket >= NUM_SOCKETS) return FALSE;

    PcCard = &PcCards[Socket];

#if DEBUG
    if (PcCard->Interface == PCMInterfaceNone ||
        PcCard->Attrib.Type != PCMWindowAttribute  ||
        PCMTuplePtr == NULL  ||
        Tuple == NULL) {

        return FALSE;                                   // Serious error
    }
#endif

    if (*PCMTuplePtr == TUP_END) {                      // No more CIS Data

        PCMTuplePtr = NULL;
        return FALSE;

    }

    //
    // Copy the contents of the tuple.
    // PCMTuplePtr is a pointer into CIS space, which is an eight bit space
    // and can only be accessed via even addresses.
    //

    Tuple->TplCode = PCMTuplePtr[0];
    Tuple->TplLink = PCMTuplePtr[2];

    for (Index = 0; Index < min(Tuple->TplLink, MAX_TUPLE_DATA); Index += 1) {

        Tuple->TplData[Index] = PCMTuplePtr[4+(Index*2)];
    }
    PCMTuplePtr += 4 + (Tuple->TplLink * 2);

    return(TRUE);
}



ULONG
PCMFindPcCards(
    VOID
    )

/*++

Routine Description:

    Searchs for all installed PC cards and initializes the PC cards array.

Arguments:

    None.

Return Value:

    The number of currently inserted PC cards.  A zero return value indicates
    that no PC cards are currently inserted.

--*/

{
    PCM_TUPLE Tuple;
    PCM_SOCKSTAT Status;
    UCHAR Data;
    ULONG ConfigBase;
    UCHAR SocketNum;
    ULONG ii;

    //
    // Platform specific hardware initialization.  All cards should be
    // powered and reset upon return.
    //
    PCMInitialize();

    PcCardCount = 0;

    for (SocketNum = 0; SocketNum < NUM_SOCKETS; SocketNum += 1) {

        PcCards[SocketNum].Interface = PCMInterfaceNone;
        if (!PCMResetSocket(SocketNum) ||
            !PCMGetStatus(SocketNum, &Status)) {
            continue;                                       // No card here
        }

        PcCards[SocketNum].Socket = SocketNum;
        PcCards[SocketNum].Status = Status;

        if (!PCMRequestWindow(SocketNum,
                              PCMWindowAttribute,
                              0,
                              0,
                              ATTRIB_WIN_SIZE,
                              &PcCards[SocketNum].Attrib)) {
            continue;
        }

        PcCards[SocketNum].Function = PCMFunctionMemory;    // Default to mem.
        PcCards[SocketNum].Interface = PCMInterfaceMem;     // Default to mem.
        PcCards[SocketNum].Configured = FALSE;


        if (PCMGetFirstTuple(SocketNum, &Tuple)) {

            do {
    
                PCMDumpTuple(&Tuple);

                //
                // Read the CIS to determine the card interface type and
                // configuration register base, if any.
                //

                switch (Tuple.TplCode) {

                case TUP_CONFIG:
                    //
                    // Configuration tuple.  Determine the configuration
                    // register base address.  Also store the device size
                    // stored in the TPL_DEVICE tuple.
                    //

                    Data = Tuple.TplData[0] & 0x03;     // Address size-1
                    ConfigBase = 0;

                    for (ii = 2+Data; ii >= 2; ii -= 1) {

                        ConfigBase = (ConfigBase << 8) + Tuple.TplData[ii];

                    }
                    PcCards[SocketNum].RegBase = ConfigBase;
                    break;

                case TUP_FUNCID:
                    //
                    // PC card function identification. The first data byte
                    // contains the function ID.
                    //

                    PcCards[SocketNum].Function = Tuple.TplData[0];
                    break;

                case TUP_DEVICE:
                    //
                    // Common memory device information tuple.  This is
                    // usually only useful for memory cards.  The device size
                    // is stored in the card structure.
                    //

                    if (Tuple.TplData[0] & 0x7) {

                        //
                        // This a non-NULL device.  Read the device size byte
                        // and calculate the size in bytes.  Store the value
                        // into the card structure.
                        //

                        ULONG SizeCode[] = {
                            512,                // 0 (512 bytes)
                            2*1024,             // 1 (2 KB)
                            8*1024,             // 2 (8 KB)
                            32*1024,            // 3 (32 KB)
                            128*1024,           // 4 (128 KB)
                            512*1024,           // 5 (512 KB)
                            2*1024*1024,        // 6 (2 MB)
                            0                   // 7 (Reserved)
                        };
                        UCHAR DeviceSize;
                        
                        DeviceSize = ((Tuple.TplData[0] & 0x7) == 0x7)?
                                     Tuple.TplData[2] :
                                     Tuple.TplData[1];

                        PcCards[SocketNum].DeviceSize =
                            (((DeviceSize & 0xF8) >> 3) + 1) *
                            SizeCode[DeviceSize & 0x7];

                    } else {

                        //
                        // This is a NULL device.  It is probably not a
                        // memory card, so device size wouldn't have much
                        // meaning.
                        //

                        PcCards[SocketNum].DeviceSize = 0;

                    }
                    break;

                default:
                    break;

                }

            } while (PCMGetNextTuple(SocketNum, &Tuple));

        }

        PcCardCount += 1;
    }

    return(PcCardCount);
}



PCM_CARDINFO *
PCMGetFirstCard(
    VOID
    )

/*++

Routine Description:

    Returns a pointer to the first available PC card.

Arguments:

    None.

Return Value:

    A pointer to a PCM_CARDINFO structure describing the first installed 
    card.  NULL is returned if no PC cards are installed.

--*/

{
    ULONG Count;

    for (Count = 0; Count < NUM_SOCKETS; Count += 1) {

        if (PcCards[Count].Interface != PCMInterfaceNone) {
            return(&PcCards[Count]);
        }
    }
    return(NULL);
}
    


PCM_CARDINFO *
PCMGetNextCard(
    IN PCM_CARDINFO *pCard
    )

/*++

Routine Description:

    Returns a pointer to the next available PC card.

Arguments:

    pCard - PCM_CARDINFO pointer returned by PCMGetFirst/GetNextCard

Return Value:

    A pointer to a PCM_CARDINFO structure describing the next installed
    card.  NULL is returned if no more PC cards are available.
--*/

{
    ULONG Count;

    Count = pCard - &PcCards[0] + 1;

    while (Count < NUM_SOCKETS) {

        if (PcCards[Count].Interface != PCMInterfaceNone) {
            return(&PcCards[Count]);
        }

        Count += 1;
    }

    return(NULL);
}


PCM_CARDINFO *
PCMFindDevice(
    IN PCM_CARDINFO *pCard,
    IN PCM_FUNCTION Function
    )

/*++

Routine Description:

    Find and initialize a PC card device of the requested type.  The device
    will be configured via a call to PCMRequestConfiguration().  Reset should
    be handled by the power on sequencing of the platform specific hardware
    initialization

Arguments:

    pCard - Pointer to PCM_CARDINFO structure previously returned, or NULL
        if this is the first time the function is being called.

Return Value:

    A pointer to a PCM_CARDINFO structure describing the next device of the
    requested type.  NULL is returned if no device was found.

--*/

{
    ULONG ValidConfigFlags;
    PCM_TUPLE Tuple;

    if (pCard == NULL) {
        pCard = PCMGetFirstCard();
    } else {
        pCard = PCMGetNextCard(pCard);
    }

    //
    // Determine what flags to pass into PCMRequestConfiguration.
    //

    switch (Function) {
    case PCMFunctionDisk:
        ValidConfigFlags = CFG_FORCE_IO;
        break;

    case PCMFunctionNetwork:
        ValidConfigFlags = CFG_FORCE_IO | CFG_FORCE_8_BIT_IO;
        break;

    case PCMFunctionMulti:
    case PCMFunctionMemory:
    case PCMFunctionSerial: // PCMFunctionModem
    case PCMFunctionParallel:
    case PCMFunctionVideo:
    case PCMFunctionAIMS:
    case PCMFunctionSCSI:
        ValidConfigFlags = 0;
        break;

    default:
        dbgKITLOutputDebugString(1, ("PCMFindDevice: Unknown card function.\r\n"));
        break;
    }


    while (pCard != NULL) {

        if (pCard->Function == Function) {

            //
            // Search the CIS for a configuration tuple to be established
            // (simply establish the first configuration).
            //

            if (!pCard->Configured &&
                PCMGetFirstTuple(pCard->Socket, &Tuple)) {

	            do {
	
	                if (Tuple.TplCode == TUP_CFTABLE) {

	                    //
	                    // A configuration tuple entry has been found. Call
	                    // PCMRequestConfiguration() to perform any hardware
	                    // setup required.
                        //
	                    // PCMRequestConfiguration returns TRUE when a card
	                    // has been initialized to the specified configuration.
	                    //
	
	                    if (PCMRequestConfiguration(pCard,
                                                    &Tuple,
                                                    ValidConfigFlags)) {

                            pCard->Configured = TRUE;
	                        break;
	                    }
	                }

	            } while (PCMGetNextTuple(pCard->Socket, &Tuple));

                //
                // If the card was not configured and it is a memory card,
                // assume that we just want to open a memory window at the
                // base of common memory.  The size of the window is set to
                // the size of the memory which described in the TPL_DEVICE
                // field.  If this fails, the card configuration fails and
                // we quit.
                //
                if (pCard->Configured == FALSE &&
                    pCard->Function == PCMFunctionMemory) {

                    dbgKITLOutputDebugString(1, (
                             "Attempting to configure a memory device.\r\n"));

                    if (pCard->DeviceSize != 0 &&
                        PCMRequestWindow(pCard->Socket,
                                         PCMWindowCommon,
                                         0,
                                         0,
                                         pCard->DeviceSize,
                                         &pCard->MemWindow[0])) {

                        pCard->Configured = TRUE;

                    }

                    break;                              // Done with this card

                }

            }

            break;                                      // Device found
        }

        pCard = PCMGetNextCard(pCard);
    }

    return(pCard);
}

BOOLEAN
PCMRequestConfiguration(
    IN PCM_CARDINFO *Card,
    IN PCM_TUPLE *Tuple,
    IN ULONG ValidConfigFlags
    )

/*++

Routine Description:

    Performs hardware setup from the specified configuration table entry.
    Currently this function simply selects the first configuration that
    satisfies two input parameters.  One is I/O, and the other is 8-bit
    I/O.

Arguments:

    Card - Pointer to a PCM_CARDINFO structure for the specified card.

    Tuple - Pointer to a PCM_TUPLE structure describing a configuration
        table entry.

    ValidConfigFlags - Flags indicating what configurations are acceptable.

Return Value:

    TRUE if a non-default configuration has been established; FALSE otherwise.

--*/

{
    BOOLEAN Success = TRUE;
    BOOLEAN ForceIoConfiguration;
    BOOLEAN Force8BitIo;
    ULONG Index;
    UCHAR WindowNum;
    ULONG IOBase, IOLength;
    ULONG CardAddr, MemLength;
    ULONG HostAddr;
    LONG ii, Adrsize, Lensize;
    CHAR Interface;
    CHAR Feature;

    ForceIoConfiguration = (ValidConfigFlags & CFG_FORCE_IO)? TRUE : FALSE;

    Force8BitIo = (ValidConfigFlags & CFG_FORCE_8_BIT_IO)? TRUE : FALSE;


    if (Tuple->TplCode != TUP_CFTABLE) return FALSE;

    if (Tuple->TplData[0] & 0x80) {                 // Interface byte present

        Interface = Tuple->TplData[1];
        Index = 2;

        dbgKITLOutputDebugString(1, ("Interface=0x%x\r\n", Interface));

    } else {
        Index = 1;                                  // Location of FS byte
    }
    Feature = Tuple->TplData[Index++];

    dbgKITLOutputDebugString(1, ("Feature=0x%x\r\n", Feature));

    //
    // If we are searching for an I/O configuration, we can quit now if this
    // configuration table entry doesn't have an I/O descriptor.
    //
    
    if (ForceIoConfiguration && !(Feature & 0x08)) {
        goto InvalidConfiguration;
    }


    if (Feature & 0x03) {                           // Power requirements

        //
        // Power supply requirements are currently ignored.
        // The PD byte indicates which parameters are specified. For each
        // parameter, there are one or two definition bytes.
        //

        UCHAR TpcePD = Tuple->TplData[Index++];

        dbgKITLOutputDebugString(1, ("TpcePD = 0x%x\r\n", TpcePD));

        for (ii = 0x01; ii <= 0x40; ii <<= 1) {

            if (TpcePD & ii) {                      // Parameter specified

                //
                // Read definition byte.  Continue over extension byte(s).
                //

                while (Tuple->TplData[Index++] & 0x80);
            }
        }
    }

    if (Feature & 0x04) {                           // Timing description

        //
        //  Parse the configuration timing information (currently ignored).
        //

        UCHAR TpceTD = Tuple->TplData[Index++];
        UCHAR Scale;

        dbgKITLOutputDebugString(1, ("TpceTD = 0x%x\r\n", TpceTD));

        //
        // Determine whether Ready, Wait, or both parameters specified:
        // (parameters currently ignored.  Skip parameters if present).
        //

        Scale = TpceTD & 0x03;                      // Extract wait scale
        if (Scale != 0x03) {
            Index += 1;
        }

        Scale = (TpceTD & 0x1c) >> 2;               // Extract ready scale
        if (Scale != 0x07) {
            Index += 1;
        }
    }

    if (Feature & 0x08) {                           // I/O space description

        //
        // Parse the I/O space configuration:
        //

        UCHAR TpceIO = Tuple->TplData[Index++];
        UCHAR IoWidth;
        
        dbgKITLOutputDebugString(1, ("TpceIO = 0x%B\r\n", TpceIO));


        //
        // Validate the I/O access width, then set the I/O access width
        // variable so that the correct window can be requested from hardware.
        //

        if (Force8BitIo) {
            IoWidth = 8;
        } else {
            IoWidth = TpceIO & 0x40 ? 16 : 8;
        }



        if (TpceIO & 0x80) {                        // Address range follows

            //
            // Loop through the I/O ranges.
            //

            UCHAR IoDesc = Tuple->TplData[Index++];

            Adrsize = (IoDesc & 0x30) >> 4;
            Lensize = (IoDesc & 0xc0) >> 6;

            if (Adrsize == 3) Adrsize = 4;
            if (Lensize == 3) Lensize = 4;


            dbgKITLOutputDebugString(1, ("IoDesc = 0x%x\r\n", IoDesc));

            for (WindowNum = 0;
                 WindowNum < (IoDesc & 0x0f)+1;
                 WindowNum += 1) {

                if (Adrsize == 0 || Lensize == 0) continue;        // ??

                //
                // Read the little endian I/O base and length fields from
                // the address range descriptors.
                //

                IOBase = 0;
                for (ii = Adrsize-1; ii >= 0; ii -= 1) {

                    IOBase = (IOBase << 8) + Tuple->TplData[Index+ii];

                }
                Index += Adrsize;

                IOLength = 0;
                for (ii = Lensize-1; ii >= 0; ii -= 1) {

                    IOLength = (IOLength << 8) + Tuple->TplData[Index+ii];

                }
                Index += Lensize;
                    

                //
                // Attempt to allocate the specified window.
                //

                dbgKITLOutputDebugString(1, (
                         "Request IO Window: Base=0x%x  Length=0x%x\r\n",
                         IOBase,
                         IOLength));


                if (WindowNum >= NUM_IO_WINDOWS ||
                    !PCMRequestIO(Card->Socket,
                                  IOBase,
                                  IOLength+1,
                                  IoWidth,
                                  &Card->IOWindow[WindowNum])) {

                    Success = FALSE;

                }

            } // for WindowNum

        } else if ((Adrsize = (TpceIO & 0x1f)) > 0) {

            //
            //  Adrsize == The number of I/O address lines decoded. Open
            //  an arbitrary I/O window based on the decode size
            //

            if (Adrsize < 27) {                    // Error - Reserved Value

                if (!PCMRequestIO(Card->Socket,
                                  0,
                                  (1 << Adrsize),
                                  IoWidth,
                                  &Card->IOWindow[0])) {

                    Success = FALSE;

                }
            }

        } // I/O window allocation


    } // I/O space description


    if (Feature & 0x10) {                               // IRQ Description

        //
        // Parse the IRQ description structure (currently ignored).
        //

        UCHAR TpceIR = Tuple->TplData[Index++];

        dbgKITLOutputDebugString(1, ("TpceIR = 0x%x\r\n", TpceIR));

        if (TpceIR & 0x10) {                            // IRQ levels follow

            dbgKITLOutputDebugString(1, ("Mask byte 0 = 0x%x\r\n", Tuple->TplData[Index]));
            dbgKITLOutputDebugString(1, ("Mask byte 1 = 0x%x\r\n", Tuple->TplData[Index+1]));

            Index += 2;
        }

    }

    if (Feature & 0x60) {                              // Memory space desc.

        UCHAR TpceMS;

        dbgKITLOutputDebugString(1, ("MemSpace = %d\r\n", (Feature & 0x60) >> 5));

        //
        //  Parse the memory space description structure.
        //  Cases 0 & 1 are ignored - window allocated only if base and
        //  address are both specified.
        //

        switch ((Feature & 0x60) >> 5) {

        case 0x00:                              // Use default
            break;                              // (currently ignored)

        case 0x01:                              // Single 2 byte length

            MemLength = Tuple->TplData[Index++];
            MemLength += (Tuple->TplData[Index++] << 8);

            dbgKITLOutputDebugString(1, ("MemLength = 0x%x\r\n", MemLength));
            break;

        case 0x02:                              // 2 byte len & addr follows

            MemLength = Tuple->TplData[Index++];
            MemLength += (Tuple->TplData[Index++] << 8);

            CardAddr = Tuple->TplData[Index++];
            CardAddr += (Tuple->TplData[Index++] << 8);

            dbgKITLOutputDebugString(1, (
                     "CardAddr=0x%x  Length=0x%x\r\n",
                     CardAddr,
                     MemLength));

            if (!PCMRequestWindow(Card->Socket,
                                  PCMWindowCommon,
                                  0,
                                  CardAddr,
                                  MemLength+1,
                                  &Card->MemWindow[WindowNum]
                                  )) {

                Success = FALSE;

            }
            break;

        case 0x03:                            // Mem selection byte follows
            
            //
            // Loop through the memory ranges.
            //

            TpceMS = Tuple->TplData[Index++];

            dbgKITLOutputDebugString(1, ("TpceMS = 0x%x\r\n", TpceMS));

            Adrsize = (TpceMS & 0x18) >> 3;
            Lensize = (TpceMS & 0x60) >> 5;

            if (Adrsize == 3) Adrsize = 4;
            if (Lensize == 3) Lensize = 4;

            for (WindowNum = 0;
                 WindowNum < (TpceMS & 0x07) + 1;
                 WindowNum += 1) {

                if (Adrsize == 0 || Lensize == 0) continue;   // ??

                //
                //  Read the little endian memory base and length fields from
                //  the address range descriptors.
                //

                CardAddr = 0;
                for (ii = Adrsize-1; ii >= 0; ii -= 1) {

                    CardAddr = (CardAddr << 8) + Tuple->TplData[Index+ii];

                }
                Index += Adrsize;
                CardAddr <<= 8;                        // 256 byte units

                MemLength = 0;
                for (ii = Lensize-1; ii >= 0; ii -= 1) {

                    MemLength = (MemLength << 8) + Tuple->TplData[Index+ii];

                }
                Index += Lensize;
                MemLength <<= 8;                       // 256 byte units
                    

                if (TpceMS & 0x80) {                   // Host address follows

                    HostAddr = 0;
                    for (ii = Adrsize-1; ii >= 0; ii -= 1) {

                        HostAddr = (HostAddr << 8) + Tuple->TplData[Index+ii];

                    }
                    Index += Lensize;
                    HostAddr <<= 8;                    // 256 byte units
                }

                if (WindowNum >= NUM_MEM_WINDOWS ||
                    !PCMRequestWindow(Card->Socket,
                                      PCMWindowCommon,
                                      HostAddr,
                                      CardAddr,
                                      MemLength+1,
                                      &Card->MemWindow[WindowNum])) {

                    Success = FALSE;

                }
            }

        default:
            //
            // Shouldn't ever occur.
            //
            dbgKITLOutputDebugString(1, ("PCMRequestConfiguration - ERROR.\r\n"));
            break;

        } // switch

    }  // Feature & Mem-Desc


    if (Feature & 0x80) {                              // Misc descriptor

        UCHAR TpceMI = Tuple->TplData[Index++];

        dbgKITLOutputDebugString(1, ("TpceMI = 0x%x\r\n", TpceMI));
    }

    //
    // If no failures have occurred establish this configuration.
    //

    if (Success) {

        if (Tuple->TplData[0] & 0x80 && ((Interface & 0x0f) == 0x01)) {

            //
            //  This is an I/O configuration.  Set the socket into I/O mode.
            //

            PCMSetIOMode(Card->Socket);
            Card->Interface = PCMInterfaceIO;

        }

        if (Card->Attrib.Type == PCMWindowAttribute) {

            PUCHAR COR = (PUCHAR)(Card->Attrib.Base + Card->RegBase);
            UCHAR tmp;

            tmp = (Tuple->TplData[0] & 0x3F);
            *COR = tmp;

            if (Force8BitIo) {
                //
                // If we are forcing 8-bit I/O, make sure the IOIS8 bit is
                // set in the function configuration and status register.
                //
                tmp = *(COR+2);
                tmp |= 0x20;
                *(COR+2) = tmp;
            }

            return(TRUE);
        }        
    }


InvalidConfiguration:
    return(FALSE);
}



ULONG
PCMFindAtaDevices(
    IN ULONG MaxDevices,
    OUT PULONG AtaDeviceIndices
    )

/*++

Routine Description:

    Finds PC card ATA devices in the system and returns the number of
    devices that were found.  Device indices (handles to the ATA devices)
    are stored in the output parameter.

Arguments:

    MaxDevices - Maximum number of devices that are to be found.  This is
        the maximum number of device indices that may be stored in the
        buffer pointed to by AtaDeviceIndices.

    AtaDeviceIndices -  Location where the ATA device indices are to be
        stored.

Return Value:

    Returns the number of PC card ATA devices that were found and
    initialized.  This is the number of ATA device indices that are stored
    at AtaDeviceIndices.

--*/

{
    PCM_CARDINFO  *PcCard;
    ULONG NumPcCardAtaDevices;
    ULONG AtaDeviceIndex;
    PVOID AtaCommandBase;
    PVOID AtaControlBase;

    if (AtaDeviceIndices == NULL) {
        return 0;
    }

    //
    // Search for ATA PC Card Devices:
    //
    PcCard = NULL;
    NumPcCardAtaDevices = 0;

    while (PcCard = PCMFindDevice(PcCard, PCMFunctionDisk)) {

        if (NumPcCardAtaDevices >= MaxDevices) {
            break;
        }

        //
        // PC card ATA devices typically have four differnet configurations.
        // They are memory mapped, contiguous I/O, primary I/O, and secondary
        // I/O.  This code handles the typical cases which works with SanDisk
        // and M-Systems compact flash parts.
        //
        // Memory mapped and contiguous I/O configurations place the command
        // registers at the base of the window.  The control/alternate status
        // register is at offset 0xE from the base.
        //
        // Primary and secondary I/O configurations are the common
        // configurations used by PCs.  These use two I/O windows, one for the
        // command registers, and the other for the control/alternate status
        // register.  The I/O bases are at 0x1F0/0x3F6 for primary and at
        // 0x170/0x376 for secondary.
        //
        // Note that the ATA code is written such that it assumes that I/O
        // windows are used.  This means that memory windows won't work.
        //

        if (PcCard->MemWindow[0].Type == PCMWindowCommon) {

            //
            // Memory configuration (currently not supported).
            //

            continue;

            AtaCommandBase = (PVOID)(PcCard->MemWindow[0].Base +
                                     PcCard->MemWindow[0].Offset);

            AtaControlBase = (PVOID)(PcCard->MemWindow[0].Base +
                                     PcCard->MemWindow[0].Offset +
                                     0xE);

        } else if (PcCard->IOWindow[0].Type == PCMWindowIO &&
                   PcCard->IOWindow[1].Type == PCMWindowDisabled) {

            //
            // Contiguous I/O configuration.
            //

            AtaCommandBase = (PVOID)(PcCard->IOWindow[0].Base +
                                     PcCard->IOWindow[0].Offset);

            AtaControlBase = (PVOID)(PcCard->IOWindow[0].Base +
                                     PcCard->IOWindow[0].Offset +
                                     0xE);

        } else if (PcCard->IOWindow[0].Type == PCMWindowIO &&
                   PcCard->IOWindow[1].Type == PCMWindowIO) {

            //
            // Primary or secondary I/O configuration.
            //

            AtaCommandBase = (PVOID)(PcCard->IOWindow[0].Base +
                                     PcCard->IOWindow[0].Offset);

            AtaControlBase = (PVOID)(PcCard->IOWindow[1].Base +
                                     PcCard->IOWindow[1].Offset);

        } else {

            //
            // Unknown configuration.
            //

            continue;
        }

        AtaDeviceIndex = ATAInitializeDevice(AtaCommandBase,
                                             AtaControlBase,
                                             0);

        if (AtaDeviceIndex == 0xFFFFFFFF) {

            //
            // ATA device initialization failed.
            //

            continue;
        }


        dbgKITLOutputDebugString(1, (
                 "ATA Device %u: Command=0x%x  Control=0x%x\r\n",
                 AtaDeviceIndex,
                 AtaCommandBase,
                 AtaControlBase));

        AtaDeviceIndices[NumPcCardAtaDevices] = AtaDeviceIndex;
        NumPcCardAtaDevices += 1;
    }

    return NumPcCardAtaDevices;
}

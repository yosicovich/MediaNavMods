#include <stdio.h>
#include "render.h"
#include "fixed.h"
#include "texture.h"
#include "mesh.h"
#include "font.h"
#include "timer.h"

unsigned long gCtgPrintCnt=1;
unsigned long gKnotCount=1;

#define USE_16BPP 1

EGLDisplay glesDisplay;
EGLSurface glesSurface;
EGLContext glesContext;

extern HWND hWnd;
extern HDC hDC;
extern Timer *timer;
extern unsigned int x,y, w, h;

int WindowWidth = 0;
int WindowHeight = 0;

BitmappedFont *font = NULL;
Mesh *mesh = NULL;
Texture *meshTexture = NULL;

bool InitOGLES()
{
  EGLConfig configs[10];
  EGLConfig config;
  EGLint matchingConfigs;

#if USE_16BPP
  const EGLint configAttribs[] =
  {
      EGL_RED_SIZE,       5,
      EGL_GREEN_SIZE,     6,
      EGL_BLUE_SIZE,      5,
      EGL_ALPHA_SIZE,     EGL_DONT_CARE,
      EGL_DEPTH_SIZE,     16,
      EGL_STENCIL_SIZE,   EGL_DONT_CARE,
      EGL_SURFACE_TYPE,   EGL_WINDOW_BIT,
      EGL_NONE,           EGL_NONE
  };
#else
  const EGLint configAttribs[] =
  {
      EGL_RED_SIZE,       8,
      EGL_GREEN_SIZE,     8,
      EGL_BLUE_SIZE,      8,
      EGL_ALPHA_SIZE,     EGL_DONT_CARE,
      EGL_DEPTH_SIZE,     16,
      EGL_STENCIL_SIZE,   EGL_DONT_CARE,
      EGL_SURFACE_TYPE,   EGL_WINDOW_BIT,
      EGL_NONE,           EGL_NONE
  };
#endif

  hDC = GetWindowDC(hWnd);
  glesDisplay = eglGetDisplay(hDC);

  if(!eglInitialize(glesDisplay, NULL, NULL))
  {
    RETAILMSG(1, (TEXT("failed: eglInitialize\r\n")));
    return false;
  }

  if(!eglChooseConfig(glesDisplay, configAttribs, &configs[0], 10,  &matchingConfigs))
  {
    RETAILMSG(1, (TEXT("failed: eglChooseConfig\r\n")));
    return false;
  }

  if(matchingConfigs < 1)
  {
    RETAILMSG(1, (TEXT("failed: No Matching configs\r\n")));
	return false;
  }

#if USE_16BPP
  	for ( int i=0; i < matchingConfigs; i++ ){
		EGLint value;

		/* Use this to explicitly check that the EGL config has the expected color depths */
		eglGetConfigAttrib( glesDisplay, configs[i], EGL_RED_SIZE, &value );
		if ( 5 != value ){
			continue;
		}
		eglGetConfigAttrib( glesDisplay, configs[i], EGL_GREEN_SIZE, &value );
		if ( 6 != value ){
			continue;
		}
		eglGetConfigAttrib( glesDisplay, configs[i], EGL_BLUE_SIZE, &value );
		if ( 5 != value ){
			continue;
		}
		eglGetConfigAttrib( glesDisplay, configs[i], EGL_ALPHA_SIZE, &value );
		if ( 0 != value ){
			continue;
		}
		eglGetConfigAttrib( glesDisplay, configs[i], EGL_SAMPLES, &value );
		if ( 4 != value ){
			continue;
		}

		config = configs[i];
		break;
	}

#else
	config = configs[0];
#endif

// full screen  glesSurface = eglCreateWindowSurface(glesDisplay, config, hWnd, NULL); //configAttribs);
  glesSurface = eglCreateWindowSurface(glesDisplay, config, hWnd, NULL ); //configAttribs);
  if(!glesSurface)
  {
    RETAILMSG(1, (TEXT("failed: eglCreateWindowSurface\r\n")));
    return false;
  }
  glesContext=eglCreateContext(glesDisplay,config,0, NULL); //configAttribs);

  if(!glesContext)
  {
    RETAILMSG(1, (TEXT("failed: eglCreateContext\r\n")));
    return false;
  }

  eglMakeCurrent(glesDisplay, glesSurface, glesSurface, glesContext);

  glClearColorx(FixedFromFloat(0.5f), FixedFromFloat(0.5f), FixedFromFloat(0.5f), 0);
  glShadeModel(GL_SMOOTH);
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_CULL_FACE);

  RECT r;
  GetWindowRect(hWnd, &r);
  WindowWidth = r.right - r.left;
  WindowHeight = r.bottom - r.top;
  glViewport(0, 0, WindowWidth, WindowHeight);
	  RETAILMSG(1, (TEXT("left:%d top:%d w:%d h:%d\r\n"), r.left, r.top, WindowWidth, WindowHeight));
  SetPerspective();
  //Load all needed resources and create needed objects
  font = new BitmappedFont("\\Storage Card\\Typhoon\\resources\\font.raw"); //Load font texture, as an 1-byte raw file
  bool result = font->GetState();
  mesh = new Mesh("\\Storage Card\\Typhoon\\resources\\knot.gsd", true);
  result &= mesh->GetState();
  meshTexture = new Texture("\\Storage Card\\Typhoon\\resources\\fire128.tga",GL_LINEAR_MIPMAP_LINEAR);
  result &= meshTexture->GetState();
  return result;
}
//----------------------------------------------------------------------------
void Render()
{
  static ULONG cnt=0;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//Setup a good point of view
	SetPerspective(); // Change this to move Knots around the screen
	glLoadIdentity();
	glTranslatex(0,0,FixedFromInt(-100));
	glRotatex(FixedFromInt(10),ONE,0,0);
	static GLfixed angle = ZERO;
	glRotatex(angle, 0, ONE,0);
	GLfixed speed = DivideFixed(FixedFromInt(timer->GetTimeBetweenTwoFrames()), FixedFromInt(100));
	angle += speed;

	//draw the mesh
	glEnable(GL_TEXTURE_2D);
	meshTexture->BindTexture();
	mesh->Draw();
	glDisable(GL_TEXTURE_2D);

	//draw the fps line.
  SetOrtho2D();
  glLoadIdentity();
  glColor4x(ONE,ONE,ONE,0);
  BitmappedFont::EnableStates();
  font->Print(0,0,"FPS: %d RmiDrawCnt:%d",timer->GetFPS(),gCtgPrintCnt*3);

// #define CTG_PRINT_TEST
#ifdef CTG_PRINT_TEST
  for(unsigned long i=0;i<gCtgPrintCnt;i++)
  {
    int x, y;
	x = (rand() % 700)+25; // 3 char print
	y = (rand() % 400)+25;
	font->Print(x,y,"RMI");
  }
#else
//for(int i =500;i>0;i-=5)
//  font->Print(0,i,"12345678901234567890");

#endif

/* Draw cnt is actual gCtgPrintCnt * 3--- 3 is for size of string */
  if ( !(++cnt%500) )
	  RETAILMSG(1, (TEXT("FPS:[%d] RmiDrawCnt:%d\r\n"),timer->GetFPS(),gCtgPrintCnt*3));
  BitmappedFont::DisableStates();


  eglSwapBuffers(glesDisplay, glesSurface);
}
//----------------------------------------------------------------------------
void Clean()
{
  if(mesh) delete mesh;
  if(font) delete font;
  if(meshTexture) delete meshTexture;
  if(glesDisplay)
  {
    eglMakeCurrent(glesDisplay, NULL, NULL, NULL);
    if(glesContext) eglDestroyContext(glesDisplay, glesContext);
    if(glesSurface) eglDestroySurface(glesDisplay, glesSurface);
    eglTerminate(glesDisplay);
  }
}
//----------------------------------------------------------------------------
void SetOrtho2D()
{
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrthox(FixedFromInt(0), FixedFromInt(WindowWidth),
           FixedFromInt(0), FixedFromInt(WindowHeight),
           FixedFromInt(-1), FixedFromInt(1));
  glMatrixMode(GL_MODELVIEW);
}
//----------------------------------------------------------------------------
void SetPerspective()
{
  RECT r;
  GetWindowRect(hWnd, &r);
  float ratio = (float)(r.right - r.left)/(r.bottom - r.top);


  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  Perspective(45.0f,ratio, 1.0f, 200.0f);
  glMatrixMode(GL_MODELVIEW);
}
//----------------------------------------------------------------------------
void Perspective (GLfloat fovy, GLfloat aspect, GLfloat zNear,  GLfloat zFar)
{
  GLfixed xmin, xmax, ymin, ymax, aspectFixed, znearFixed;

  aspectFixed = FixedFromFloat(aspect);
  znearFixed = FixedFromFloat(zNear);

  ymax = MultiplyFixed(znearFixed, FixedFromFloat((GLfloat)tan(fovy * 3.1415962f / 360.0f)));
  ymin = -ymax;

  xmin = MultiplyFixed(ymin, aspectFixed);
  xmax = MultiplyFixed(ymax, aspectFixed);
  glFrustumx(xmin, xmax, ymin, ymax, znearFixed, FixedFromFloat(zFar));
}


//----------------------------------------------------------------------------
void SetOrtho()
{
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrthox(FixedFromInt(-100), FixedFromInt(100),
           FixedFromInt(-100), FixedFromInt(100),
           FixedFromInt(-100) , FixedFromInt(100));
  glMatrixMode(GL_MODELVIEW);
}

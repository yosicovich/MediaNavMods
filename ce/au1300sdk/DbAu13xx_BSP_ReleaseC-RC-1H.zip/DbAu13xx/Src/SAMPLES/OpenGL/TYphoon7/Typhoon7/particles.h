#ifndef PARTICLES_H
#define PARTICLES_H
#include <windows.h> 
#include <GLES/gl.h>
#include <math.h>
#include <stdlib.h>
#include "fixed.h"
#include "texture.h"

const GLfixed GRAVITY = FixedFromFloat(-4.905f); //This variable is (-0.5 *9.81), needed for the parabolic shot equation


#define PIDIV180 0.01745329f
inline float DEGTORAD(int x) {return x * PIDIV180;};

class ParticleSystem
{
public:
  //particle system constructor: it receives the texture filename, the desired number of particles
  //and the position of the particle emmiter
  ParticleSystem(const char *textureFilename, int numberOfParticles, GLfixed x, GLfixed y, GLfixed z);
  ~ParticleSystem();  

  //DrawParticles will update and draw the whole particle system, must be called each frame
  void DrawParticles(unsigned int elapsedTime);

private:
  void UpdateParticles(unsigned int elapsedTime); //updates the particles position based on the elapsed time with the last frame
  void ResetParticle(int i); //resets a particle under certain conditions (lifetime = 0, or position.y = 0)
  GLfixed m_sin[360]; //pregenerated sin table
  GLfixed m_cos[360]; //pregenerated cos table
  GLfixed m_emmiter[3]; //emmiter possition
  int m_numberOfParticles;
  Texture *m_texture; //particles' texture
  
  //Particle data
  GLfixed *m_totalLifeTime; //in milliseconds
  GLfixed *m_lifeTime;      //in milliseconds
  GLfixed *m_position;  
  GLfixed *m_startSpeed;
  GLubyte *m_color;  
  int     *m_startAngle;  
  
};



#endif
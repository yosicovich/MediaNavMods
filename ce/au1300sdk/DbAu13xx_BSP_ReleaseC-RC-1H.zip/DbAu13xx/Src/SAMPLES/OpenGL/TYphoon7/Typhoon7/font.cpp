#include "font.h"
GLfixed BitmappedFont::m_textureCoordinates[];
bool BitmappedFont::m_instanced(false);

BitmappedFont::BitmappedFont(const char *textureFont, int fontWidth , int fontHeight):m_fontWidth(fontWidth),m_fontHeight(fontHeight)
{
  m_texture = NULL;
  m_state = true;
  //first, we need create the font texture
  m_texture = new Texture(textureFont,GL_NEAREST, GL_NEAREST, GL_CLAMP_TO_EDGE,GL_CLAMP_TO_EDGE, 256, 128, 8);

  //check if the texture is well created
  if(!m_texture->GetState())
  {
    delete m_texture;
    m_texture = NULL;
    m_state = false;
    return;
  }

  //next we will create the texture coordinates table, but this time using full fixed point math
  //This is exactly the same code than last tutorials, but uses the fixed point math. Nothing more has changed
  if(m_instanced) return;
  m_instanced = true;

  const GLfixed rows = FixedFromInt(8);
  const GLfixed columns = FixedFromInt(16);
  const GLfixed xoffset = DivideFixed(ONE, columns); // the font texture has 16 columns
  const GLfixed yoffset = DivideFixed(ONE, rows); //the font texture has 8 rows

  //prebuild the texture coordinates array for all characters
  for(int i=0;i<128;i++)
  {
    int aux = i % 16;
    const GLfixed cx = MultiplyFixed(FixedFromInt(aux), xoffset);
    aux = i / 16;
    const GLfixed cy = MultiplyFixed(FixedFromInt(aux), yoffset);
    const int index = i * 8;
    m_textureCoordinates[  index  ] = cx;
    m_textureCoordinates[index + 1] = ONE - cy - yoffset;

    m_textureCoordinates[index + 2] = cx + xoffset;
    m_textureCoordinates[index + 3] = ONE - cy - yoffset;

    m_textureCoordinates[index + 4] = cx + xoffset;
    m_textureCoordinates[index + 5] = ONE - cy;

    m_textureCoordinates[index + 6] = cx;
    m_textureCoordinates[index + 7] = ONE - cy;
  }
}

//----------------------------------------------------------------------------
BitmappedFont::~BitmappedFont()
{
  if(m_texture) delete m_texture;
}
//----------------------------------------------------------------------------
void BitmappedFont::EnableStates()
{
  /*This function exists because we can use it to enable all needed states to display the text
    for many Print calls, instead of call this states on every Print call*/
  glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_BLEND);
  glBlendFunc(GL_ONE, GL_ONE);
}
//----------------------------------------------------------------------------
void BitmappedFont::DisableStates()
{
  glDisable(GL_TEXTURE_2D);
  glDisableClientState(GL_VERTEX_ARRAY);
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glDisable(GL_BLEND);
}

//----------------------------------------------------------------------------
// #define QUICK_FONT

#ifndef QUICK_FONT
void BitmappedFont::Print(int x, int y, const char *fmt, ...)
{
  //Convert the variable argument list, to a single char[] array
  //be careful, the final string length must fit into this array
  char text[256];
  va_list ap;
  if (fmt == NULL)
    return;

  va_start(ap, fmt);
    vsprintf(text, fmt, ap);
  va_end(ap);
  if(text[0]=='\0')
    return;

  int length = (int)strlen(text);

  //Set up our arrays
  const GLushort indices[]= {1, 2, 0, 3};  //triangle strip
  GLfixed vertices[12];
  m_texture->BindTexture();
  glVertexPointer(3, GL_FIXED, 0, vertices);

  const GLfixed fy = FixedFromInt(y);
  const GLfixed fheight = FixedFromInt(m_fontHeight);

  //go throught all chars int the array
  //Code translated to use fixed point math
  for(int i = 0;i < length;i++)
  {
    /*We have to substract 32 units, because the characters stored in our font texture starts in the
      ASCII code 32 (the first 32 ASCII code, are control codes, usually non-displayables(*/
    const int c = text[i]-32;
    const GLfixed originX = FixedFromInt(x + (i * m_fontWidth));
    const GLfixed offsetX = originX + FixedFromInt(m_fontWidth);

    //Compute the dimensions and position of the 'quad' (in reality is a triangle strip with two triangles)
    vertices[0] = originX;    vertices[1] = fy;            vertices[2] = 0;
    vertices[3] = offsetX;    vertices[4] = fy;            vertices[5] = 0;
    vertices[6] = offsetX;    vertices[7] = fy + fheight;  vertices[8] = 0;
    vertices[9] = originX;    vertices[10]= fy + fheight;  vertices[11]= 0;

    //we access to the corresponding texture coordinates in the precomputed texture coordinates array
    glTexCoordPointer(2, GL_FIXED, 0, &m_textureCoordinates[c*8]);

    //draw the character
    glDrawElements(GL_TRIANGLE_STRIP,4,GL_UNSIGNED_SHORT,indices);
  }

  return;
}
#else // QUICK_FONT
#define MAX_STR_LEN 20
void BitmappedFont::Print(int x, int y, const char *fmt, ...)
{
  //Convert the variable argument list, to a single char[] array
  //be careful, the final string length must fit into this array
  char text[256];
  va_list ap;
  if (fmt == NULL)
    return;

  va_start(ap, fmt);
    vsprintf(text, fmt, ap);
  va_end(ap);
  if(text[0]=='\0')
    return;

  int length = (int)strlen(text);

  if (length > MAX_STR_LEN) length = MAX_STR_LEN;

  //Set up our arrays
  const GLushort indices[(4*MAX_STR_LEN)]= {
        3, 0, 2, 1,
        7, 4, 6, 5,
        11, 8, 10, 9,
        15, 12, 14, 13,
        19, 16, 18, 17,
        23, 20, 22, 21,
        27, 24, 26, 25,
        31, 28, 30, 29,
        35, 32, 34, 33,
        39, 36, 38, 37,
        43, 40, 42, 41,
        47, 44, 46, 45,
        51, 48, 50, 49,
        55, 52, 54, 53,
        59, 56, 58, 57,
        63, 60, 62, 61,
        67, 64, 66, 65,
        71, 68, 70, 69,
        75, 72, 74, 73,
        79, 76, 78, 77,
	};  //triangle strip
  GLfixed vertices[12*MAX_STR_LEN];
  GLfixed texcoord[8*MAX_STR_LEN];
  GLfixed *vp;
  GLfixed *tp;
  const unsigned int vp_inc = sizeof(vertices)/(sizeof(vertices[0])*MAX_STR_LEN);
  m_texture->BindTexture();
  glVertexPointer(3, GL_FIXED, 0, vertices);

  const GLfixed fy = FixedFromInt(y);
  const GLfixed fheight = FixedFromInt(m_fontHeight);

  const GLfixed rows = FixedFromInt(8);
  const GLfixed columns = FixedFromInt(16);
  const GLfixed xoffset = DivideFixed(ONE, columns); // the font texture has 16 columns
  const GLfixed yoffset = DivideFixed(ONE, rows); //the font texture has 8 rows


  //go throught all chars int the array
  //Code translated to use fixed point math

  vp = vertices;
  tp = texcoord;
  for(int i = 0;i < length;i++)
  {
    /*We have to substract 32 units, because the characters stored in our font texture starts in the
      ASCII code 32 (the first 32 ASCII code, are control codes, usually non-displayables(*/
    const int c = text[i]-32;
    const GLfixed originX = FixedFromInt(x + (i * m_fontWidth));
    const GLfixed offsetX = originX + FixedFromInt(m_fontWidth);

    //Compute the dimensions and position of the 'quad' (in reality is a triangle strip with two triangles)
    vp[0] = originX;    vp[1] = fy;            vp[2] = 0; // bottom left
    vp[3] = offsetX;    vp[4] = fy;            vp[5] = 0; // bottom right
    vp[6] = offsetX;    vp[7] = fy + fheight;  vp[8] = 0; // top left
    vp[9] = originX;    vp[10]= fy + fheight;  vp[11]= 0; // top right
	vp+=vp_inc;

    int aux = c % 16;
    const GLfixed cx = MultiplyFixed(FixedFromInt(aux), xoffset);
    aux = c / 16;
    const GLfixed cy = MultiplyFixed(FixedFromInt(aux), yoffset);


	*tp++ = cx;
    *tp++ = ONE - cy - yoffset;

    *tp++ = cx + xoffset;
    *tp++ = ONE - cy - yoffset;

    *tp++ = cx + xoffset;
    *tp++ = ONE - cy;

    *tp++ = cx;
    *tp++ = ONE - cy;

	/*
	printf(" vp=(%.8X,%.8X)-(%.8X,%.8X) tc=(%.8X,%.8X)-(%.8X,%.8X)\n",
		   vertices[3*indices[2+(i*2)]],vertices[3*indices[2+(i*2)] + 1 ],
		   vertices[3*indices[3+(i*2)]],vertices[3*indices[3+(i*2)] + 1 ],
		   texcoord[2*indices[2+(i*2)]],texcoord[2*indices[2+(i*2)] + 1 ],
		   texcoord[2*indices[3+(i*2)]],texcoord[2*indices[3+(i*2)] + 1 ]
		   );
	*/


	/*printf( "originX, offsetX: %f, %f\n", (float)originX/65536, (float)offsetX/65536 );
	printf( "fy, fheight     : %f, %f\n", (float)fy/65536, (float)fheight/65536 );
	printf( "m_fontWidth: %d\n", m_fontWidth );*/

  }

  //we access to the corresponding texture coordinates in the computed texture coordinates array
  glTexCoordPointer(2, GL_FIXED, 0, &texcoord);

  //draw the character
  glDrawElements(GL_TRIANGLE_STRIP,(length*4),GL_UNSIGNED_SHORT,indices);

  return;
}
#endif

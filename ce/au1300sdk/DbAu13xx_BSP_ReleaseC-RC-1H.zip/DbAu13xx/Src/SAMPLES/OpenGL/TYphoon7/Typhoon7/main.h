#ifndef _TUTORIAL1_H
#define _TUTORIAL1_H

#include <windows.h> //needed include for window system calls
#include "timer.h"

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPTSTR lpCmdLine,int nCmdShow);
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

#endif

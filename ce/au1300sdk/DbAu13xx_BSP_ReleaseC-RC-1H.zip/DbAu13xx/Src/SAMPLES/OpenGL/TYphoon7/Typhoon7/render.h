#ifndef RENDER_H
#define RENDER_H

#include <windows.h>
#include <GLES/gl.h>
#include <GLES/egl.h>

bool InitOGLES();
void Render();
void SetOrtho2D();
void SetOrtho();
void SetPerspective();
void Perspective (GLfloat fovy, GLfloat aspect, GLfloat zNear,  GLfloat zFar);
void Clean();


#endif

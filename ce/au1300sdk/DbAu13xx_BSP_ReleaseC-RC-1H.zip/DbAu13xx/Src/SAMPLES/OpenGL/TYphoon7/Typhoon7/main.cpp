#include "main.h" //We need the defines and prototypes from in.
#include "render.h"

//Some useful global handles
HINSTANCE hInst; //Will hold the current instance of the application.
HWND hWnd; // A handle to the window we will create.
HDC hDC;   // A handle to the device context of the window.

Timer *timer = NULL;

DWORD		g_dwColorRed = 0x00;
DWORD		g_dwColorGreen = 0x00;
DWORD		g_dwColorBlue = 0x08;
COLORREF    g_KeyColor = RGB(g_dwColorRed, g_dwColorGreen, g_dwColorBlue); // Overlay Color


TCHAR szAppName[] = L"OpenGLES"; /*The application name and the window caption*/

unsigned int x=0,y=64, w=320, h=240;

/*This is the WinMain function. Here we will create the rendering window, initialize OpenGL ES, write the message loop, and, at the end, clean all and release all used resources*/
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine,	int nCmdShow)
{
  MSG msg; //This is the message variable for the message loop
  WNDCLASS	wc; /*This structure will hold some init values for our window*/
  hInst = hInstance; // Initialization of our global variable
  bool done = false;
  HBRUSH hbrColorKey = CreateSolidBrush(g_KeyColor);

  /*This block of code is to ensure that the user only can run one
    instance of the application. First we search for a window with the
    same class name, if found, we will focus it and return*/
  if(hWnd = FindWindow(szAppName, szAppName))
  {
    /* Set focus to foremost child window. The "| 0x01" is used to
       bring any owned windows to the foreground and activate them.*/
//    SetForegroundWindow((HWND)((ULONG) hWnd | 0x00000001));
//    return 0;

	x += w;

  }

  wc.style          = CS_HREDRAW | CS_VREDRAW; /*Will force a redraw
  if the window is resized, both horizontally or vertically*/
  wc.lpfnWndProc    = (WNDPROC) WndProc; /*this is a function pointer,
  to tell the OS what function should call when a message needs to be
  processed*/
  wc.cbClsExtra     = 0;
  wc.cbWndExtra     = 0;
  wc.hInstance      = hInstance;
  wc.hIcon          = LoadIcon(hInstance, NULL);//Load default icon
  wc.hCursor	      = 0; // Default cursor
  wc.hbrBackground = hbrColorKey; // colorkeyed so that the GLES drawings will show up.
  wc.lpszMenuName	  = NULL; //This application does not have a menu
  wc.lpszClassName  = szAppName; /*Important, here we must fill the
   application class name (the class name is not the same than the
   caption of the window, but many times they are the same)*/

  //Before creating the window, we must register this new window class
  if(!RegisterClass(&wc))
    return false;

  hWnd=CreateWindow(szAppName, //Class Name
                    szAppName, //Caption string
                    WS_VISIBLE,//Window style
                    x, y, //Starting [x,y] pos.
                    w,h, //Width and height
                    NULL, NULL, //Parent window and menu handle
                    hInst, NULL); /*Instance handle. Custom value to
                    pass in the creation with the WM_CREATE message*/

  if(!hWnd) return false;

  //Create our timer
  timer = new Timer();

  if(!InitOGLES()) //OpenGL ES Initialization
  {
    MessageBox(hWnd,L"OpenGL ES init error.",L"Error",MB_OK | MB_ICONERROR);
    return false;
  }

  //Bring the window to front, focus it and refresh it
  SetWindowText(hWnd, L"OpenGLES");
  ShowWindow(hWnd, nCmdShow);
  UpdateWindow(hWnd);

  //Message Loop
  while(!done)
  {
    if(PeekMessage(&msg,NULL,0,0,PM_REMOVE))
    {
		if(msg.message==WM_QUIT)
			done = true;
		else if (msg.message==WM_KEYDOWN )
		{
			extern unsigned long gCtgPrintCnt;
			if ( msg.wParam == VK_UP )
				gCtgPrintCnt+=10;
			if ( msg.wParam == VK_DOWN )
			{
				if ( gCtgPrintCnt > 10 )
					gCtgPrintCnt-=10;
			}
		}
	    else
		{
	      TranslateMessage(&msg);
	      DispatchMessage(&msg);
		}

    }
//	Sleep(66);
	Render();
	timer->UpdateTimer(); //update the timer

  }
  //Clean up all
  Clean();
  delete timer;
  DestroyWindow(hWnd);
  UnregisterClass(szAppName, hInst);
  return 0;
}
//----------------------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  HDC hDC = GetWindowDC(hWnd);

  switch (message)
  {
  case WM_PAINT:
    RECT rect;
	HBRUSH hBrush;
	HGDIOBJ holdBrush;


	GetClientRect(hWnd, &rect);
	hBrush=CreateSolidBrush(g_KeyColor);
	holdBrush=SelectObject(hDC,hBrush);
	FillRect(hDC,&rect,hBrush);

	SelectObject(hDC,holdBrush);
	DeleteObject(hBrush);

    ValidateRect(hWnd,NULL);
    return 0;

  case WM_DESTROY:
    PostQuitMessage(0);
    return 0;

  };
  return DefWindowProc(hWnd, message, wParam, lParam);
}


#ifndef FIXED_H
#define FIXED_H
#include <windows.h> 
#include <GLES/gl.h>

const unsigned int PRECISION = 16;
const GLfixed ONE  = 1 << PRECISION;
const GLfixed ZERO = 0;

inline GLfixed FixedFromInt(int value) {return value << PRECISION;};
inline GLfixed FixedFromFloat(float value) {return (GLfixed)(value * (float)(ONE));};
inline float FloatFromFixed(GLfixed value) {return (float)value / (float)ONE;};
inline int IntFromFixed(GLfixed value) {return value >> PRECISION;};

inline GLfixed MultiplyFixed(GLfixed op1, GLfixed op2) 
{
  return  (GLfixed)(((__int64)op1 * op2) >> PRECISION);     
};

inline GLfixed DivideFixed(GLfixed op1, GLfixed op2) 
{
  return (GLfixed)( ((__int64)op1 << PRECISION) / op2);
};

#endif
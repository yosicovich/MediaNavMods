#pragma once

#include "thread.h"

#define DECLARE_PTR(type, ptr, expr) type* ptr = (type*)(expr);

#include <comdef.h>
#define SMARTPTR(x)	_COM_SMARTPTR_TYPEDEF(x, __uuidof(x))
SMARTPTR(IMediaSample);

class CCIMOutputStream;

class DECLSPEC_UUID("55D36CED-7FC1-47ea-8AAE-C4C82F4EB655") 
CCIMCapture 
: public CBaseFilter,
  public thread
{
public:
    static CUnknown * WINAPI CreateInstance(LPUNKNOWN lpunk, HRESULT *phr);

	LPAMOVIESETUP_FILTER GetSetupData()
	{
		return const_cast<LPAMOVIESETUP_FILTER>(&m_sudFilter);
	}

	// filter registration table
	static const AMOVIESETUP_MEDIATYPE m_sudType;
	static const AMOVIESETUP_PIN m_sudPin;
	static const AMOVIESETUP_FILTER m_sudFilter;

    // CBaseFilter methods
    int GetPinCount();
    CBasePin *GetPin(int n);
	STDMETHODIMP Stop();
	STDMETHODIMP Run(REFERENCE_TIME tStart);
    STDMETHODIMP GetState(DWORD dwMSecs, FILTER_STATE* State);

    IFilterGraph *GetGraph()	{ return m_pGraph;}
	CIM_Utils* CIMUtils()		{ return &cCIMUtils; }
	REFGUID Subtype();

private:
    CCIMCapture(LPUNKNOWN lpunk, HRESULT *phr);
    ~CCIMCapture();
    DWORD ThreadProc();

private:
    CCritSec m_csFilter;
    CCIMOutputStream* m_pOutput;

	CIM_Utils cCIMUtils;
	int m_CIMCaptureMode;
};

class CCIMOutputStream 
: public CBaseOutputPin, 
  public IAMStreamConfig, 
  public IKsPropertySet
{
public:
	DECLARE_IUNKNOWN
    STDMETHODIMP NonDelegatingQueryInterface(REFIID riid, void **ppv);

public:

	//  IQualityControl implementations

	STDMETHODIMP Notify(IBaseFilter * pSender, Quality q);

    //  IAMStreamConfig implementations

    HRESULT STDMETHODCALLTYPE SetFormat(AM_MEDIA_TYPE *pmt);
    HRESULT STDMETHODCALLTYPE GetFormat(AM_MEDIA_TYPE **ppmt);
    HRESULT STDMETHODCALLTYPE GetNumberOfCapabilities(int *piCount, int *piSize);
    HRESULT STDMETHODCALLTYPE GetStreamCaps(int iIndex, AM_MEDIA_TYPE **pmt, BYTE *pSCC);

    //  IKsPropertySet implementations

    HRESULT STDMETHODCALLTYPE Set(REFGUID guidPropSet, DWORD dwID, void *pInstanceData, DWORD cbInstanceData, void *pPropData, DWORD cbPropData);
    HRESULT STDMETHODCALLTYPE Get(REFGUID guidPropSet, DWORD dwPropID, void *pInstanceData,DWORD cbInstanceData, void *pPropData, DWORD cbPropData, DWORD *pcbReturned);
    HRESULT STDMETHODCALLTYPE QuerySupported(REFGUID guidPropSet, DWORD dwPropID, DWORD *pTypeSupport);
    
    //  CBaseOutputPin implementations
    CCIMOutputStream(CCIMCapture *pParent, CCritSec* pLock, HRESULT *phr, LPCWSTR pPinName);

    HRESULT DecideBufferSize(IMemAllocator *pIMemAlloc, ALLOCATOR_PROPERTIES *pProperties);
    HRESULT CheckMediaType(const CMediaType *pMediaType);
    HRESULT GetMediaType(int iPosition, CMediaType *pmt);
    
    HRESULT Active();
    HRESULT Inactive();
    HRESULT DeliverEndOfStream();
    HRESULT DeliverBeginFlush();
    HRESULT DeliverEndFlush();
	HRESULT Deliver(IMediaSample* pSample);

private:
    CCIMCapture *m_pParent;
    COutputQueue* m_pOutputQ;
};

/*
  cim_capture.cpp - implementation of the cim_capture DShow capture filter

  This file contains the DirectShow code gluing the capture filter to the
  CIM device as exposed in the cim_utils class.  It also contains the DLL
  glue code, what little there is of it.
*/

#include <windows.h>
#include <platform.h>
#include <streams.h>
#include <olectl.h>
#include <initguid.h>

#include "cim_utils.h"
#include "cim_capture.h"
#include "AuMedia.h"
_COM_SMARTPTR_TYPEDEF(IAuMediaSample, IID_AuMediaSample);


const AMOVIESETUP_MEDIATYPE CCIMCapture::m_sudType = 
{ 
    &MEDIATYPE_Video, 
    &MEDIASUBTYPE_YV12 
};

const AMOVIESETUP_PIN CCIMCapture::m_sudPin =
{
    L"Output",             // Pin string name
    FALSE,                 // Is it rendered
    TRUE,                  // Is it an output
    FALSE,                 // Can we have none
    FALSE,                 // Can we have many
    &CLSID_NULL,           // Connects to filter
    NULL,                  // Connects to pin
    1,                     // Number of types
    &m_sudType		       // Pin Media types
};

const AMOVIESETUP_FILTER CCIMCapture::m_sudFilter =
{
    &__uuidof(CCIMCapture),  // Filter CLSID
    L"Alchemy CIM Capture Filter",     // String name
    MERIT_NORMAL,	      // Filter merit
    1,                     // Number pins
    &m_sudPin             // Pin details
};

CFactoryTemplate g_Templates[] = 
{
    {
		CCIMCapture::m_sudFilter.strName,
		CCIMCapture::m_sudFilter.clsID,
        CCIMCapture::CreateInstance,
        NULL,
		&CCIMCapture::m_sudFilter
    },
};

int g_cTemplates = NUMELMS(g_Templates);

STDAPI DllRegisterServer()
{
	return AMovieDllRegisterServer2(true);
}

STDAPI DllUnregisterServer()
{
	return AMovieDllRegisterServer2(false);
}

extern "C" BOOL WINAPI DllEntryPoint(HINSTANCE, ULONG, LPVOID);

BOOL APIENTRY DllMain(HANDLE hModule, DWORD  dwReason, LPVOID lpReserved)
{
	return DllEntryPoint((HINSTANCE)(hModule), dwReason, lpReserved);
}


//////////////////////////////////////////////////////////////////////////
//  CCIMCapture is the source filter which masquerades as a capture device
//////////////////////////////////////////////////////////////////////////

CUnknown * WINAPI CCIMCapture::CreateInstance(LPUNKNOWN lpunk, HRESULT *phr)
{
    ASSERT(phr);
    CUnknown *punk = new CCIMCapture(lpunk, phr);
    return punk;
}

CCIMCapture::CCIMCapture(LPUNKNOWN lpunk, HRESULT *phr) 
: CBaseFilter(NAME("CCIMCapture"), lpunk, &m_csFilter, *m_sudFilter.clsID)
{
	m_pOutput = new CCIMOutputStream(this, &m_csFilter, phr,  L"Video Output");

	// Note that MODE 3 produces a decent display, althought the camera
	// doesn't power up, it's useful for debugging.

	m_CIMCaptureMode = 28;			// ADV A/D from compositie video is Mode 28

	cCIMUtils.Initialize(m_CIMCaptureMode);
}

CCIMCapture::~CCIMCapture()
{
	delete m_pOutput;
}

REFGUID 
CCIMCapture::Subtype()
{
	switch(m_CIMCaptureMode)
	{
	case 28:
		return MEDIASUBTYPE_YVYU;

	default:
		return GUID_NULL;
	}
}

    // CBaseFilter methods
int 
CCIMCapture::GetPinCount()
{
	return 1;
}
CBasePin *
CCIMCapture::GetPin(int n)
{
	if (n == 0)
	{
		return m_pOutput;
	}
	return NULL;
}

STDMETHODIMP 
CCIMCapture::Stop()
{
	StopThread();
	return __super::Stop();
}

STDMETHODIMP 
CCIMCapture::Run(REFERENCE_TIME tStream)
{
	HRESULT hr = __super::Run(tStream);
	if (SUCCEEDED(hr))
	{
		StartThread();
	}
	return hr;
}

STDMETHODIMP 
CCIMCapture::GetState(DWORD dwMSecs, FILTER_STATE* State)
{
	HRESULT hr = __super::GetState(dwMSecs, State);
	if ((hr == S_OK) && (*State == State_Paused))
	{
		hr = VFW_S_CANT_CUE;
	}
	return hr;
}


DWORD 
CCIMCapture::ThreadProc()
{
	long nFrames = 0;
	DWORD dwTicks = GetTickCount();

	CIMUtils()->StartCapture();

	while (!ShouldExit())
	{
		IMediaSamplePtr pSample;
		HRESULT hr = m_pOutput->GetDeliveryBuffer(&pSample, NULL, NULL, 0);
		if (FAILED(hr))
		{
			break;
		}
		long cFrame = pSample->GetSize();

		IAuMediaSamplePtr pAuSample = pSample;
		if(pAuSample == NULL) 
		{
			BYTE* pDest;
			pSample->GetPointer(&pDest);
			CIMUtils()->GrabFrame(pDest, cFrame);
		}
		else
		{
			BYTE* pPhysical = NULL;
			pAuSample->GetPhysPointer(&pPhysical);
			physaddr_t paDest = physaddr_t(pPhysical);
			if (paDest == 0)
			{
				return E_FAIL;
			}
		
			CIMUtils()->GrabFrameDirect(paDest, pSample->GetSize());
			pAuSample = NULL;
		}
		pSample->SetSyncPoint(TRUE);

		m_pOutput->Deliver(pSample);
		nFrames++;
	}
	dwTicks = GetTickCount() - dwTicks;
	long fpsx10 = nFrames * 10 / (dwTicks/1000);
	RETAILMSG(1, (L"Frames %d fps %d.%01d\n", nFrames, fpsx10/10, fpsx10%10));
	CIMUtils()->StopCapture();

	return 0;
}

//////////////////////////////////////////////////////////////////////////
// CCIMOutputStream is the one and only output pin of CCIMCapture which handles 
// all the stuff.
//////////////////////////////////////////////////////////////////////////

CCIMOutputStream::CCIMOutputStream(CCIMCapture *pParent, CCritSec* pLock, HRESULT *phr, LPCWSTR pPinName) 
: CBaseOutputPin(NAME("CCIMOutputStream"), pParent, pLock, phr, pPinName), 
  m_pParent(pParent)
{
}

HRESULT CCIMOutputStream::NonDelegatingQueryInterface(REFIID riid, void **ppv)
{   
    // Standard COM stuff
    if(riid == _uuidof(IAMStreamConfig))
	{
		return GetInterface((IAMStreamConfig*)this, ppv);
	}
    else if(riid == _uuidof(IKsPropertySet))
	{
		return GetInterface((IKsPropertySet*)this, ppv);
	}
    else
	{
        return __super::NonDelegatingQueryInterface(riid, ppv);
	}
    return S_OK;
}

// Notify
// Ignore quality management messages sent from the downstream filter
STDMETHODIMP CCIMOutputStream::Notify(IBaseFilter * pSender, Quality q)
{
    return E_NOTIMPL;
} // Notify


// See Directshow help topic for IAMStreamConfig for details on this method
HRESULT CCIMOutputStream::GetMediaType(int iPosition, CMediaType *pmt)
{
    if(iPosition < 0) return E_INVALIDARG;
    if(iPosition > 0) return VFW_S_NO_MORE_ITEMS;

    DECLARE_PTR(VIDEOINFOHEADER, pvi, pmt->AllocFormatBuffer(sizeof(VIDEOINFOHEADER)));
    ZeroMemory(pvi, sizeof(VIDEOINFOHEADER));
	REFGUID subtype = m_pParent->Subtype();

	if ((subtype == MEDIASUBTYPE_UYVY)||
		(subtype == MEDIASUBTYPE_YV12) ||
		(subtype == MEDIASUBTYPE_YVYU))
	{
	    pvi->bmiHeader.biBitCount = 16;
	}
	else
	{
		// unsupported subtype?
		return VFW_S_NO_MORE_ITEMS;
	}

    pvi->bmiHeader.biSize       = sizeof(BITMAPINFOHEADER);
	pvi->bmiHeader.biWidth      = m_pParent->CIMUtils()->Width();
    pvi->bmiHeader.biHeight     = m_pParent->CIMUtils()->Height();
    pvi->bmiHeader.biPlanes     = 1;
    pvi->bmiHeader.biSizeImage  = GetBitmapSize(&pvi->bmiHeader);

    pvi->AvgTimePerFrame = (UNITS/30);

    SetRectEmpty(&(pvi->rcSource)); // we want the whole image area rendered.
    SetRectEmpty(&(pvi->rcTarget)); // no particular destination rectangle

    pmt->SetType(&MEDIATYPE_Video);
    pmt->SetFormatType(&FORMAT_VideoInfo);
	pmt->SetSubtype(&subtype);

	pmt->SetTemporalCompression(FALSE);
    pmt->SetSampleSize(pvi->bmiHeader.biSizeImage);
    
    return S_OK;

} // GetMediaType

// This method is called to see if a given output format is supported
HRESULT CCIMOutputStream::CheckMediaType(const CMediaType *pmt)
{
	if ((*pmt->Type() != MEDIATYPE_Video) ||
		(*pmt->Subtype() != m_pParent->Subtype()) ||
		(*pmt->FormatType() != FORMAT_VideoInfo)
		)
	{
		return VFW_E_TYPE_NOT_ACCEPTED;
	}
    VIDEOINFOHEADER *pvi = (VIDEOINFOHEADER *)(pmt->Format());
	
	if ((pvi->bmiHeader.biWidth != m_pParent->CIMUtils()->Width()) ||
		(abs(pvi->bmiHeader.biHeight) != m_pParent->CIMUtils()->Height()))
	{
		return VFW_E_TYPE_NOT_ACCEPTED;
	}

	return S_OK;
} // CheckMediaType

// This method is called after the pins are connected to allocate buffers to stream data
HRESULT CCIMOutputStream::DecideBufferSize(IMemAllocator *pAlloc, ALLOCATOR_PROPERTIES *pProperties)
{
    HRESULT hr = NOERROR;

    pProperties->cBuffers = 5;
    pProperties->cbBuffer = m_mt.GetSampleSize();

    ALLOCATOR_PROPERTIES Actual;
    hr = pAlloc->SetProperties(pProperties,&Actual);

    if(FAILED(hr)) return hr;
    if(Actual.cbBuffer < pProperties->cbBuffer) return E_FAIL;

    return NOERROR;
} // DecideBufferSize

HRESULT 
CCIMOutputStream::Active()
{
    HRESULT hr = CBaseOutputPin::Active();
    if (SUCCEEDED(hr) && IsConnected())
    {
        m_pOutputQ = new COutputQueue(
                                     GetConnected(),
                                     &hr,
                                     false,
                                     true,
                                     1,
                                     false,
                                     10);
        if (m_pOutputQ == NULL)
        {
            hr = E_OUTOFMEMORY;
        } else if (FAILED(hr))
        {
            delete m_pOutputQ;
            m_pOutputQ = NULL;
        }
    }
    return hr;

}

HRESULT 
CCIMOutputStream::Inactive()
{
    HRESULT hr = CBaseOutputPin::Inactive();

    // we are transitioning into stop mode -- delete the queue
    delete m_pOutputQ;
    m_pOutputQ = NULL;

    return hr;
}

HRESULT 
CCIMOutputStream::DeliverEndOfStream()
{
    if (m_pOutputQ != NULL)
    {
        m_pOutputQ->EOS();
    }
    return S_OK;
}

HRESULT 
CCIMOutputStream::DeliverBeginFlush()
{
    if (m_pOutputQ != NULL)
    {
        m_pOutputQ->BeginFlush();
    }
    return S_OK;
}

HRESULT 
CCIMOutputStream::DeliverEndFlush()
{

	if (m_pOutputQ != NULL)
    {
        m_pOutputQ->EndFlush();
    }

    return S_OK;
}

HRESULT 
CCIMOutputStream::Deliver(IMediaSample* pSample)
{
	HRESULT hr = S_OK;
	if (m_pOutputQ)
	{
		pSample->AddRef();
		hr = m_pOutputQ->Receive(pSample);
	}
	return hr;
}



//////////////////////////////////////////////////////////////////////////
//  IAMStreamConfig
//////////////////////////////////////////////////////////////////////////

STDMETHODIMP CCIMOutputStream::SetFormat(AM_MEDIA_TYPE *pmt)
{
    DECLARE_PTR(VIDEOINFOHEADER, pvi, m_mt.pbFormat);
	if (m_mt!= *pmt)
	{
		m_mt = *pmt;
		IPin* pin; 
		ConnectedTo(&pin);
		if(pin)
		{
			IFilterGraph *pGraph = m_pParent->GetGraph();
			pGraph->Reconnect(this);
		}
	}
    return S_OK;
}

STDMETHODIMP CCIMOutputStream::GetFormat(AM_MEDIA_TYPE **ppmt)
{
    *ppmt = CreateMediaType(&m_mt);
    return S_OK;
}

STDMETHODIMP CCIMOutputStream::GetNumberOfCapabilities(int *piCount, int *piSize)
{
    *piCount = 1;
    *piSize = sizeof(VIDEO_STREAM_CONFIG_CAPS);
    return S_OK;
}

STDMETHODIMP CCIMOutputStream::GetStreamCaps(int iIndex, AM_MEDIA_TYPE **pmt, BYTE *pSCC)
{
	// !! needs work -- does not make sense at the moment since iIndex is unused
	//    and in any case we have no alternative sizes or formats to offer

	if (iIndex != 0)
	{
		return S_FALSE;
	}

    *pmt = CreateMediaType(&m_mt);
    DECLARE_PTR(VIDEOINFOHEADER, pvi, (*pmt)->pbFormat);
    DECLARE_PTR(VIDEO_STREAM_CONFIG_CAPS, pvscc, pSCC);
    
    pvscc->guid = FORMAT_VideoInfo;
    pvscc->VideoStandard = AnalogVideo_None;
    pvscc->InputSize.cx = pvi->bmiHeader.biWidth;
    pvscc->InputSize.cy = pvi->bmiHeader.biHeight;
    pvscc->MinCroppingSize.cx = 80;
    pvscc->MinCroppingSize.cy = 60;
    pvscc->MaxCroppingSize.cx = 720;
    pvscc->MaxCroppingSize.cy = 240; //!! ?
    pvscc->CropGranularityX = 80;
    pvscc->CropGranularityY = 60;
    pvscc->CropAlignX = 0;
    pvscc->CropAlignY = 0;

    pvscc->MinOutputSize.cx = 80;
    pvscc->MinOutputSize.cy = 60;
    pvscc->MaxOutputSize.cx = 720;
    pvscc->MaxOutputSize.cy = 240;	// !!?
    pvscc->OutputGranularityX = 0;
    pvscc->OutputGranularityY = 0;
    pvscc->StretchTapsX = 0;
    pvscc->StretchTapsY = 0;
    pvscc->ShrinkTapsX = 0;
    pvscc->ShrinkTapsY = 0;
    pvscc->MinFrameInterval = 200000;   //50 fps
    pvscc->MaxFrameInterval = 50000000; // 0.2 fps
    pvscc->MinBitsPerSecond = (80 * 60 * 3 * 8) / 5;
    pvscc->MaxBitsPerSecond = 720 * 240 * 2 * 8 * 50;

    return S_OK;
}

//////////////////////////////////////////////////////////////////////////
// IKsPropertySet
//////////////////////////////////////////////////////////////////////////


HRESULT CCIMOutputStream::Set(REFGUID guidPropSet, DWORD dwID, void *pInstanceData, 
                        DWORD cbInstanceData, void *pPropData, DWORD cbPropData)
{// Set: Cannot set any properties.
    return E_NOTIMPL;
}

// Get: Return the pin category (our only property). 
HRESULT CCIMOutputStream::Get(
    REFGUID guidPropSet,   // Which property set.
    DWORD dwPropID,        // Which property in that set.
    void *pInstanceData,   // Instance data (ignore).
    DWORD cbInstanceData,  // Size of the instance data (ignore).
    void *pPropData,       // Buffer to receive the property data.
    DWORD cbPropData,      // Size of the buffer.
    DWORD *pcbReturned     // Return the size of the property.
)
{
    if (guidPropSet != AMPROPSETID_Pin)             return E_PROP_SET_UNSUPPORTED;
    if (dwPropID != AMPROPERTY_PIN_CATEGORY)        return E_PROP_ID_UNSUPPORTED;
    if (pPropData == NULL && pcbReturned == NULL)   return E_POINTER;
    
    if (pcbReturned) *pcbReturned = sizeof(GUID);
    if (pPropData == NULL)          return S_OK; // Caller just wants to know the size. 
    if (cbPropData < sizeof(GUID))  return E_UNEXPECTED;// The buffer is too small.
        
	*(GUID *)pPropData = PIN_CATEGORY_PREVIEW;
    return S_OK;
}

// QuerySupported: Query whether the pin supports the specified property.
HRESULT CCIMOutputStream::QuerySupported(REFGUID guidPropSet, DWORD dwPropID, DWORD *pTypeSupport)
{
    if (guidPropSet != AMPROPSETID_Pin) return E_PROP_SET_UNSUPPORTED;
    if (dwPropID != AMPROPERTY_PIN_CATEGORY) return E_PROP_ID_UNSUPPORTED;
    // We support getting this property, but not setting it.
    if (pTypeSupport) *pTypeSupport = KSPROPERTY_SUPPORT_GET; 
    return S_OK;
}

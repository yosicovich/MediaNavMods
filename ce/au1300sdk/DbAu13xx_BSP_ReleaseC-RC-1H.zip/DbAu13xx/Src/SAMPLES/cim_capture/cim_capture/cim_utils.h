#pragma once

#include "..\..\..\inc\camera.h"
#include "mem_ioctl.h"
#include "au1x00.h"

#define GENERATE_DEBUG_OUTPUT 0

// clearly separate physical address from virtual address
typedef DWORD   physaddr_t;

// CIM_Utils
// Class containing various utilities necessary to setup the CIM,
// ..allocate and control memory, and the like.

class CIM_Utils {
public:
	CIM_Utils();
	~CIM_Utils();
	BOOL Initialize(INT nIndex, bool bPrealloc = false);
	BOOL StartCapture(void);
    BOOL GrabFrameDirect(physaddr_t dest, long cData);
	BOOL GrabFrame(UCHAR *pYUVBytes, long lDataLen);
	BOOL StopCapture(void);
	BOOL DeInitialize(void);

	int Width() { return m_Mode.width;}
	int Height() { 
		if (m_Mode.height > 240)
		{
			return m_Mode.height/2;
		}
		return m_Mode.height;
	}
private:
	BOOL OpenDevices(void);
	BOOL CloseDevices(void);
	BOOL ConfigureCIM(DWORD Index);
	BOOL GetVideoMemory(PMEM_IOCTL pMem, DWORD Size);
	BOOL FreeVideoMemory(PMEM_IOCTL pMem);
private:
	BOOL m_bClassInitialized;
	HANDLE m_hCAM;
	HANDLE m_hMEM;
	MEM_IOCTL m_memYUV;
	CameraMode m_Mode;
	BOOL m_bCaptureActive;
	DWORD m_memSize;
	INT m_BitsPerPixel;
};

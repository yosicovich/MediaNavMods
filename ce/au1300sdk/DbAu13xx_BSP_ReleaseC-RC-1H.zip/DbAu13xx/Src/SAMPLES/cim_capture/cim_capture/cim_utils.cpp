/*****************************************************************************
Copyright 2003-2007 Raza Microelectronics, Inc.(RMI). All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY Raza Microelectronics, Inc. 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#define SOC_AU13XX

#include <windows.h>
#include <platform.h>
#include <ceddk.h>

#include "cim_utils.h"

/*
 * Very basic constructor, just initialize member variables to sane defaults.
 */

CIM_Utils::CIM_Utils()
: m_hCAM(NULL),
  m_hMEM(NULL),
  m_bCaptureActive(false),
  m_bClassInitialized(false),
  m_BitsPerPixel(16)
{
    ZeroMemory(&m_Mode, sizeof(m_Mode));
	ZeroMemory(&m_memYUV, sizeof(m_memYUV));
	RETAILMSG(GENERATE_DEBUG_OUTPUT, (L"CIM_Utils constructed\n"));
}

/*
 * DO basic clean-up on the way out
 */

CIM_Utils::~CIM_Utils()
{
	if(m_bClassInitialized)
	{
		DeInitialize();
	}

	RETAILMSG(GENERATE_DEBUG_OUTPUT, (L"CIM_Utils destroyed\n"));
}

// Initialize the utility class.  Takes care of setting up the CIM block,
// allocating memory for the YUV capture buffer and the snapshot buffer,
// and preparing us to capture incoming image data.

BOOL CIM_Utils::Initialize(INT nIndex, bool bPrealloc)
{
	if(m_bClassInitialized == TRUE) {
		return TRUE;	// Already initialized
	}

	RETAILMSG(GENERATE_DEBUG_OUTPUT, (L"Initializing CIM for mode %d\n", nIndex));

	OpenDevices();

	if(ConfigureCIM(nIndex) != TRUE) {
		RETAILMSG(1, (L"Could not configure CIM for mode index %d\n", nIndex));
		return FALSE;
	}
		
	m_memSize =  (Width() * Height() * m_BitsPerPixel) / 8;

	RETAILMSG(GENERATE_DEBUG_OUTPUT, (L"YUVSize %d w: %d h:%d \n", m_memSize,Width(),Height()));

	if (bPrealloc)
	{
		// allocate local memory in case non-VR allocator used 
		// -- can also be done on demand in GetFrame.
		GetVideoMemory(&m_memYUV, m_memSize);
	}

	m_bClassInitialized = TRUE;

	RETAILMSG(GENERATE_DEBUG_OUTPUT, (L"Class Initialized\n"));

	return TRUE;
}

// StartCapture resumes the capture thread.  Incoming data flows into
// a ring of YUV buffers which can be grabbed and fed out to the user.

BOOL CIM_Utils::StartCapture(void)
{
	if(m_bCaptureActive) {
		RETAILMSG(GENERATE_DEBUG_OUTPUT, (L"Capture already active, ignoring\n"));
		return TRUE;		// This isn't an error, respond accordingly
	}

	m_bCaptureActive = TRUE;

	RETAILMSG(GENERATE_DEBUG_OUTPUT, (L"Capture now ACTIVE\n"));

	return TRUE;
}

// StopCapture simply suspends the capture thread so that no additional image
// data comes in to the capture buffers.

BOOL CIM_Utils::StopCapture(void)
{
	if(!m_bCaptureActive) {
		RETAILMSG(GENERATE_DEBUG_OUTPUT, (L"Capture inactive, ignoring\n"));
		return TRUE;		// This isn't an error, respond accordingly
	}

	m_bCaptureActive = FALSE;

	RETAILMSG(GENERATE_DEBUG_OUTPUT, (L"Capture now INACTIVE\n"));

	return TRUE;
}

// DeInitialize terminates the capture thread, frees up buffers, and
// generally cleans up from a capture run.

BOOL CIM_Utils::DeInitialize(void)
{
	if(!m_bClassInitialized) {
		RETAILMSG(GENERATE_DEBUG_OUTPUT, (L"Class not initialized, nothing done\n"));
		return TRUE;
	}

	CloseDevices();

//	Make sure capture is stopped, otherwise bad things could happen.

	if(StopCapture() == FALSE) {
		RETAILMSG(1, (L"Failed to stop capture\n"));
		return FALSE;
	}

// Free up all the video memory we were consuming.

#ifdef USE_LOCALLY_ALLOCATED_MEMORY
	if(FreeVideoMemory(&m_memYUV) != TRUE) {
		RETAILMSG(, (L"Cannot free block at %p", m_memYUV));
	}
#endif

	m_bClassInitialized = FALSE;

	RETAILMSG(GENERATE_DEBUG_OUTPUT, (L"Class deinitialized\n"));

	return TRUE;
}

// capture to physical memory pointer managed elsewhere
BOOL 
CIM_Utils::GrabFrameDirect(physaddr_t dest, long cData)
{
	// I've used a non-pointer type for physaddr_t elsewhere so that
	// the two do not get mixed. Here we need a pointer type again.
	PVOID pa = PVOID(dest);
    DWORD dwOutLen = 0;
    if (!DeviceIoControl(
            m_hCAM, 
            IOCTL_CAMERA_CAPTURE,
            NULL, 
            0, 
            pa, 
            cData, 
            &dwOutLen, NULL)) 
    {
        RETAILMSG(1,(L"FAILED TO CAPTURE FRAME!: %d\r\n", GetLastError()));
        return FALSE;
    }
    return true;
}

// GrabFrame will allocate and return a buffer of raw bytes that is the
// next image captured from the CIM.  NOTE - this is a RAW YUV buffer,
// NOT RGB - no conversion is performed from the format returned from the
// CIM.  This function will wait for up to 3 seconds for a capture to happen,
// it *is* possible for the capture to fail so we need to allow for that.

BOOL CIM_Utils::GrabFrame(UCHAR *pYUVBytes, long lDataLen)
{
	GetVideoMemory(&m_memYUV, lDataLen);
    if (m_memYUV.pPhysical == NULL) {
        return false;
    }
	physaddr_t pa = physaddr_t(m_memYUV.pPhysical);
    if (!GrabFrameDirect(pa, m_memYUV.dwSize)) {
        return false;
    }

    long cCopy = min(lDataLen, long(m_memYUV.dwSize));
	memcpy(pYUVBytes, m_memYUV.pVirtual, cCopy);
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL CIM_Utils::OpenDevices(void)
{

    m_hCAM = CreateFile(L"CAM1:", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (m_hCAM == INVALID_HANDLE_VALUE) {
        RETAILMSG(1,(L"Cannot open CAM1: %d\r\n", GetLastError()));
        return FALSE;
    }

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL CIM_Utils::CloseDevices(void)
{
	BOOL retVal = TRUE;

	if (m_hCAM)
	{
		if(!CloseHandle(m_hCAM)) {
			RETAILMSG(1, (L"Can't close CAM handle\n"));
			retVal = FALSE;	
		} else
			m_hCAM = NULL;
	}

	if (m_hMEM)
	{
		if(!CloseHandle(m_hMEM)) {
			RETAILMSG(1, (L"Can't close MEM handle\n"));
			retVal = FALSE;
		} else
			m_hMEM = NULL;
	}

	return retVal;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL CIM_Utils::ConfigureCIM(DWORD Index)
{
	DWORD dwOutLen;

	////////////////////////////////
	//	Set our CIM configuration
	////////////////////////////////
	if (!DeviceIoControl(m_hCAM, IOCTL_CAMERA_CONFIGURE,
                         &Index, sizeof(Index), NULL, 0, &dwOutLen, NULL)) {
        RETAILMSG(1,(L"Cannot set current camera mode: %d\r\n", GetLastError()));
        return FALSE;
    }

    if (!DeviceIoControl(m_hCAM, IOCTL_CAMERA_QUERY,
                         NULL, 0, &m_Mode, sizeof(CameraMode), &dwOutLen, NULL)) {
        RETAILMSG(1,(L"Cannot get current camera mode: %d\r\n", GetLastError()));
        return FALSE;
    }
	RETAILMSG(GENERATE_DEBUG_OUTPUT,(TEXT("Camera config: mode:%d w:%d h:%d %s\r\n"), m_Mode.mode, m_Mode.width, m_Mode.height, m_Mode.modename ));

	switch(Index)
	{
	case 28:
	default:
		m_BitsPerPixel = 16;
		break;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL CIM_Utils::GetVideoMemory(PMEM_IOCTL pMem, DWORD Size)
{
	if (pMem->pPhysical != NULL)
	{
		if (pMem->dwSize < Size)
		{
			FreeVideoMemory(pMem);
		}
		else
		{
			return true;
		}
	}

	if (m_hMEM == NULL)
	{
		m_hMEM = CreateFile(L"MEM1:", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
		if (m_hMEM == INVALID_HANDLE_VALUE) {
			RETAILMSG(1,(L"Cannot open MEM1: %d\r\n", GetLastError()));
			return FALSE;
		}
	}

	// get memory for YUV and RGB buffers
	pMem->dwRegion		= REGION_LCD;
	pMem->dwSize 		= Size;
	pMem->dwFlags 		= 0;

	DWORD dwOutLen = 0;
    if (!DeviceIoControl(m_hMEM, MEM_REQUEST_BLOCK,
                         pMem, sizeof(MEM_IOCTL), NULL, 0, &dwOutLen, NULL)) {
        RETAILMSG(1,(L"Cannot get memory size:%d\r\n", pMem->dwSize));
		return FALSE;
    }

	RETAILMSG(GENERATE_DEBUG_OUTPUT,(L"memory: size:%d Phys:%x Virt:%x\r\n",
        	 pMem->dwSize, pMem->pPhysical, pMem->pVirtual ));

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL CIM_Utils::FreeVideoMemory(PMEM_IOCTL pMem)
{
	if (pMem->pPhysical != NULL)
	{
		DWORD dwOutLen;
		if (!DeviceIoControl(m_hMEM, MEM_FREE_BLOCK, pMem, sizeof(MEM_IOCTL), NULL, 0, &dwOutLen, NULL))
		{
			RETAILMSG(1, (TEXT("Failed to free memory\r\n")));
			return FALSE;
		}
		pMem->pPhysical = NULL;
	}
	return TRUE;
}

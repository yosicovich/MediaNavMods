#ifndef __AUMEDIA_H
#define __AUMEDIA_H

// {0ba13ea1-70e5-11db-9690-00e08161165f}
DEFINE_GUID(CLSID_VREND, 
0xba13ea1, 0x70e5, 0x11db, 0x96, 0x90, 0x0, 0xe0, 0x81, 0x61, 0x16, 0x5f );

// {3145504D-0000-0010-8000-00AA00389B71}
DEFINE_GUID(MEDIASUBTYPE_MPE1, 
0x3145504D, 0x0000, 0x0010, 0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71);

// {7A46365B-568E-40CD-93B5-5F9B2DC1CAE7
DEFINE_GUID(IID_AuMediaSample, 
  0x7A46365B, 0x568E, 0x40CD, 0x93, 0xB5, 0x5F, 0x9B, 0x2D, 0xC1, 0xCA, 0xE7);


DECLARE_INTERFACE_(IAuMediaSample,IUnknown)
{
public:
	// IUnknown
    STDMETHOD(QueryInterface)(THIS_ REFIID riid, LPVOID *ppvObj) PURE;
    STDMETHOD_(ULONG,AddRef)(THIS) PURE;
    STDMETHOD_(ULONG,Release)(THIS) PURE;

	// IAuMediaSample
	STDMETHOD_(HRESULT,GetPhysPointer)(BYTE** ppBuffer) PURE;
	STDMETHOD_(HRESULT,GetVirtPointer)(BYTE** ppBuffer) PURE;
};


#endif __AUMEDIA_H
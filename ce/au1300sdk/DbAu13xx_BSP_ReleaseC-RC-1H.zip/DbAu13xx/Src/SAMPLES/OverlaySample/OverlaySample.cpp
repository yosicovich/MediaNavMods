// OverlaySample.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "OverlaySample.h"
#include <windows.h>
#include <commctrl.h>
#include "lcd_ioctl.h"
#include "os_api.h"

#define MAX_LOADSTRING 100


#define BYTES_PP 2 // Hard coded for 16Bpp
#define NUM_OVERLAY2_POSITIONS 2
#define NUM_MODES 3

// Global Variables:
HINSTANCE			g_hInst;			// current instance
HWND				g_hWndCommandBar;	// command bar handle
COLORREF			g_crColorKey;
OVERLAY_IOCTL		g_ovlIoctl1;
OVERLAY_IOCTL		g_ovlIoctl2;
PMEM_IOCTL			pMemOverlay1;
PMEM_IOCTL			pMemOverlay2;
RECT				rcOverlay1[NUM_OVERLAY2_POSITIONS];
DWORD				g_CurMode = 0;

// Forward declarations of functions included in this code module:
ATOM			MyRegisterClass(HINSTANCE, LPTSTR);
BOOL			InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);


///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void MoveOverlay(POVERLAY_IOCTL pOverlay, DWORD dwX, DWORD dwY, DWORD dwWidth, DWORD dwHeight, DWORD dwBytesPP)
{
	RETAILMSG(1, (TEXT("MoveOverlay %d to (%d, %d) (%d x %d)\r\n"), pOverlay->ndx, dwX, dwY, dwWidth, dwHeight));
	// Clear and then set the overlay origins -- WINCTRL0_O_MASK
	pOverlay->winctrl0 &= ~(WINCTRL0_OX(WINCTRL0_O_MASK) | WINCTRL0_OY(WINCTRL0_O_MASK));
	pOverlay->winctrl0 |= (WINCTRL0_OX(dwX) | WINCTRL0_OY(dwY));

	// Clear and then set the overlay size -- WINCTRL1_SZ_MASK
	pOverlay->winctrl1 &= ~(WINCTRL1_SZX(WINCTRL1_SZ_MASK) | WINCTRL1_SZY(WINCTRL1_SZ_MASK));
	pOverlay->winctrl1 |= (WINCTRL1_SZX(dwWidth) | WINCTRL1_SZY(dwHeight));
	
	// Clear and then set the stride (BX) -- WINCTRL2_BX_MASK
	pOverlay->winctrl2 &= ~(WINCTRL2_BX(WINCTRL2_BX_MASK));
	pOverlay->winctrl2 |= (WINCTRL2_BX(dwWidth * dwBytesPP));
	OS_SetOverlayConfig(*pOverlay);
}

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
COLORREF GetColorKey(void)
{
	LCD_COLORKEY_IOCTL	ckIoctl;
	ULONG				ulColorKey;
	COLORREF			crColorKey;

	OS_GetScreenColorkey(&ckIoctl);
	
	ulColorKey = ckIoctl.colorkey;

	DWORD	dwColorRed = GET_COLORKEY_RED(ulColorKey);
	DWORD	dwColorGrn = GET_COLORKEY_GRN(ulColorKey);
	DWORD	dwColorBlu = GET_COLORKEY_BLU(ulColorKey);

	crColorKey = RGB(dwColorRed, dwColorGrn, dwColorBlu);

	return crColorKey;
}

///////////////////////////////////////////////////////////////////////////////
//
///////////////////////////////////////////////////////////////////////////////
void PaintOverlays(DWORD dwMode)
{
	DWORD		dwScreenWidth = OS_GetScreenWidth();
	DWORD		dwScreenHeight = OS_GetScreenHeight();

	///////////////////////////////////////////////////////////////////////////////
	// Set overlay 2's size and position. We assume this one is always full screen.
	///////////////////////////////////////////////////////////////////////////////
	MoveOverlay(&g_ovlIoctl2, 0, 0, (dwScreenWidth - 1), (dwScreenHeight - 1), BYTES_PP);

	
	if (NUM_OVERLAY2_POSITIONS > dwMode)
	{
		MoveOverlay(&g_ovlIoctl1, rcOverlay1[dwMode].left, rcOverlay1[dwMode].top, 
			(RECT_WIDTH(rcOverlay1[dwMode]) - 1), (RECT_HEIGHT(rcOverlay1[dwMode]) - 1), BYTES_PP);
		OS_ShowOverlay(1, TRUE);
	}
	else
	{
		/////////////////////////////////////////////////////////////////////////////////////
		// If we aren't going to have an overlay visible. Turn it off to improve performance.
		/////////////////////////////////////////////////////////////////////////////////////
		OS_ShowOverlay(1, FALSE);
	}

	if ((RECT_WIDTH(rcOverlay1[dwMode]) != dwScreenWidth ) && (RECT_HEIGHT(rcOverlay1[dwMode]) != dwScreenHeight))
	{
		OS_ShowOverlay(2, TRUE);
	}
	else
	{
		/////////////////////////////////////////////////////////////////////////////////////
		// If we aren't going to have an overlay visible. Turn it off to improve performance.
		/////////////////////////////////////////////////////////////////////////////////////
		OS_ShowOverlay(2, FALSE);
	}
}

//
//
//
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	//////////////////////////////////////////
	// Allocate 2 buffers.  1 for each overlay
	//////////////////////////////////////////
	DWORD		dwScreenWidth = OS_GetScreenWidth();
	DWORD		dwScreenHeight = OS_GetScreenHeight();
	DWORD		dwSize = dwScreenWidth * dwScreenHeight * BYTES_PP;
	HANDLE		hMem = mem_open_driver();
	
	pMemOverlay1 = mem_alloc(hMem, dwSize, REGION_LCD, 0);
	pMemOverlay2 = mem_alloc(hMem, dwSize, REGION_LCD, 0);

	///////////////////////////////////////////////////////
	// Fill the color with color to tell the overlays apart
	///////////////////////////////////////////////////////
	memset (pMemOverlay1->pVirtual, 0x55, dwSize);
	memset (pMemOverlay2->pVirtual, 0xAA, dwSize);

	//////////////////////////
	// Set the overlay buffers
	//////////////////////////
	OVERLAY_UPDATE_IOCTL 	ovlIoctl;
	ovlIoctl.ndx = g_ovlIoctl2.ndx;
	ovlIoctl.phys = pMemOverlay2->pPhysical;
	OS_UpdateOverlay(ovlIoctl);

	ovlIoctl.ndx = g_ovlIoctl1.ndx;
	ovlIoctl.phys = pMemOverlay1->pPhysical;
	OS_UpdateOverlay(ovlIoctl);


	//////////////////////////////////////////////
	// Create some positions for the other overlay
	//////////////////////////////////////////////
	rcOverlay1[0].top = 0;
	rcOverlay1[0].left = 0;
	rcOverlay1[0].bottom = dwScreenHeight;
	rcOverlay1[0].right = dwScreenWidth;

	rcOverlay1[1].top = 0;
	rcOverlay1[1].left = 0;
	rcOverlay1[1].bottom = dwScreenHeight/2;
	rcOverlay1[1].right = dwScreenWidth/2;



	HACCEL hAccelTable;
	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_OVERLAYSAMPLE));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_OVERLAYSAMPLE));
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}


//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    HWND hWnd;
    TCHAR szTitle[MAX_LOADSTRING];		// title bar text
    TCHAR szWindowClass[MAX_LOADSTRING];	// main window class name

    g_hInst = hInstance; // Store instance handle in our global variable


    LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING); 
    LoadString(hInstance, IDC_OVERLAYSAMPLE, szWindowClass, MAX_LOADSTRING);


    if (!MyRegisterClass(hInstance, szWindowClass))
    {
    	return FALSE;
    }

    hWnd = CreateWindow(szWindowClass, szTitle, WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);

    if (!hWnd)
    {
        return FALSE;
    }

	/////////////////////////////////////////////////
	// Get the color key so the overlays will show up
	/////////////////////////////////////////////////
	g_crColorKey = GetColorKey();

	////////////////////////////////////////////////////////////
	// Create overlay 1 -- This is equivalent to the MAE overlay
	////////////////////////////////////////////////////////////
	g_ovlIoctl1.bufctrl = 0;
	g_ovlIoctl1.flags = 0;
	g_ovlIoctl1.reserved0 = 0;
	g_ovlIoctl1.reserved1 = 0;
	g_ovlIoctl1.winctrl0 = 0;
	g_ovlIoctl1.winctrl1 = 0; // Display driver will fill this pipe and priority
	
	/**************************************************************************
	From Au13xx Data Book (Page 290)
	Colorkey Mode.
		00 	Disable colorkey.
		01 	Match full screen colorkey to other pipe's pixel. Uses next pixel from
			this buffer. Must be only enabled window on this pipe. See Section
			9.2.23.1 on page 299 for more information on full screen mode.
		10	Windowed colorkey matches other pipe's pixel. Selects Alpha from
			other pipe, overriding priority (Video man mode). See Section 9.2.23.2
			on page 299 for more information on windowed mode.
		11	Windowed colorkey matches other pipe's pixel. Selects Alpha from this
			window, overriding priority (Weatherman mode). See Section 9.2.23.2
			on page 299 for more information on windowed mode.
			See lcd_colorkey to define the 24-bit color used in colorkey mode.
	**************************************************************************/
	g_ovlIoctl1.winctrl2 = WINCTRL2_CKMODE(3); 

	g_ovlIoctl1.winctrl1 = WINCTRL1_FORM(AU_RGB_565);
	g_ovlIoctl1.ndx = 1;
	OS_CreateOverlay(&g_ovlIoctl1);

	////////////////////////////////////////////////////////////////
	// Create overlay 2 -- This is the equivalent to the OGL overlay
	////////////////////////////////////////////////////////////////
	g_ovlIoctl2.bufctrl = 0;
	g_ovlIoctl2.flags = 0;
	g_ovlIoctl2.reserved0 = 0;
	g_ovlIoctl2.reserved1 = 0;
	g_ovlIoctl2.winctrl0 = 0;
	g_ovlIoctl2.winctrl1 = 0; // Display driver will fill this pipe and priority
	
	/**************************************************************************
	From Au13xx Data Book (Page 290)
	Colorkey Mode.
		00 	Disable colorkey.
		01 	Match full screen colorkey to other pipe's pixel. Uses next pixel from
			this buffer. Must be only enabled window on this pipe. See Section
			9.2.23.1 on page 299 for more information on full screen mode.
		10	Windowed colorkey matches other pipe's pixel. Selects Alpha from
			other pipe, overriding priority (Video man mode). See Section 9.2.23.2
			on page 299 for more information on windowed mode.
		11	Windowed colorkey matches other pipe's pixel. Selects Alpha from this
			window, overriding priority (Weatherman mode). See Section 9.2.23.2
			on page 299 for more information on windowed mode.
			See lcd_colorkey to define the 24-bit color used in colorkey mode.
	**************************************************************************/
	g_ovlIoctl2.winctrl2 = WINCTRL2_CKMODE(3); 

	g_ovlIoctl2.winctrl1 = WINCTRL1_FORM(AU_RGB_565);
	g_ovlIoctl2.ndx = 2;
	OS_CreateOverlay(&g_ovlIoctl2);


    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    if (g_hWndCommandBar)
    {
        CommandBar_Show(g_hWndCommandBar, TRUE);
    }

    return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int wmId, wmEvent;
    PAINTSTRUCT ps;
    HDC hdc;

	
    switch (message) 
    {
        case WM_COMMAND:
            wmId    = LOWORD(wParam); 
            wmEvent = HIWORD(wParam); 
            // Parse the menu selections:
            switch (wmId)
            {
                case IDM_HELP_ABOUT:
                    DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, About);
                    break;
                case IDM_FILE_EXIT:
                    DestroyWindow(hWnd);
                    break;
                default:
                    return DefWindowProc(hWnd, message, wParam, lParam);
            }
            break;
		case WM_LBUTTONUP:
			{
				g_CurMode++;

				if (g_CurMode == NUM_MODES)
				{
					g_CurMode = 0;
				}
				PaintOverlays(g_CurMode);
			}
			break;
        case WM_CREATE:
            g_hWndCommandBar = CommandBar_Create(g_hInst, hWnd, 1);
            CommandBar_InsertMenubar(g_hWndCommandBar, g_hInst, IDR_MENU, 0);
            CommandBar_AddAdornments(g_hWndCommandBar, 0, 0);
            break;
        case WM_PAINT:
			{
				RECT	rcClient;
				HBRUSH	hbrColorKey = CreateSolidBrush(g_crColorKey);
				hdc = BeginPaint(hWnd, &ps);
				GetClientRect(hWnd, &rcClient);
				FillRect(hdc, &rcClient, hbrColorKey);
				DeleteObject(hbrColorKey);  
				PaintOverlays(g_CurMode);
				EndPaint(hWnd, &ps);
			}
            break;
        case WM_DESTROY:
            CommandBar_Destroy(g_hWndCommandBar);
            PostQuitMessage(0);
            break;


        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_INITDIALOG:
            RECT rectChild, rectParent;
            int DlgWidth, DlgHeight;	// dialog width and height in pixel units
            int NewPosX, NewPosY;

            // trying to center the About dialog
            if (GetWindowRect(hDlg, &rectChild)) 
            {
                GetClientRect(GetParent(hDlg), &rectParent);
                DlgWidth	= rectChild.right - rectChild.left;
                DlgHeight	= rectChild.bottom - rectChild.top ;
                NewPosX		= (rectParent.right - rectParent.left - DlgWidth) / 2;
                NewPosY		= (rectParent.bottom - rectParent.top - DlgHeight) / 2;
				
                // if the About box is larger than the physical screen 
                if (NewPosX < 0) NewPosX = 0;
                if (NewPosY < 0) NewPosY = 0;
                SetWindowPos(hDlg, 0, NewPosX, NewPosY,
                    0, 0, SWP_NOZORDER | SWP_NOSIZE);
            }
            return (INT_PTR)TRUE;

        case WM_COMMAND:
            if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL))
            {
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            }
            break;

        case WM_CLOSE:
            EndDialog(hDlg, message);
            return TRUE;

    }
    return (INT_PTR)FALSE;
}

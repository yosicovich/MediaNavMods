/***********************************************************************
This product is the confidential property of NetLogic Microsystems Inc. 
(�NetLogic�), is provided under a non-disclosure agreement or license 
agreement, and is protected under applicable copyright, patent, and trade 
secret laws. 

Unauthorized use, reproduction, distribution or other dissemination without 
the prior written authorization from NetLogic is strictly prohibited.  

NetLogic disclaims all warranties of any nature, express or implied, 
including, without limitation, the warranties of fitness for a particular 
purpose, merchantability and/or non-infringement of third party rights. 

NetLogic assumes no liability for any error or omissions in this PRODUCT, 
or for the use of this PRODUCT. In no event shall NetLogic be liable to 
any other party for any special, PUNITIVE, incidental or consequential 
damages, whether based on breach of contract, tort, product liability, 
infringement of intellectual property rights or otherwise. NetLogic reserves 
the right to make changes to, or discontinue, its products At any time. 

Distribution of the product herein does not convey a license or any other right
in any patent, trademark, or other intellectual property of NetLogic.

Use of the product shall serve as acceptance of these terms and conditions.  If
you do not accept these terms, you should return or destroy the product and any 
other accompanying information immediately.

Copyright, 2009-20010, NetLogic Microsystems, Inc. All rights reserved.   
***************************_ NetLogic_3_******************************/

#ifndef __CIM_SAMPLE_H
#define __CIM_SAMPLE_H


#define SOC_AU13XX
#include "camera.h"
#include "maelcd.h"
#include "lcd_ioctl.h"
#include "mem_ioctl.h"
#include "maeioctl.h"
#include "au1x00.h"


#define OVERLAY_INDEX MAE_PLANE
#define NUM_BUFFERS 4
#define BPP			16


HANDLE OpenCIM(void);
void CloseCIM(HANDLE h);
BOOL ConfigureCIM(HANDLE h, DWORD Index, CameraMode *pMode);
ULONG RenderThread(DWORD flags);
ULONG CaptureThread(DWORD flags);


typedef struct {
	HANDLE	hCAM;
	HANDLE	hEvent;		
} capture_thread_context_t;

typedef struct {
	RECT SrcRect;
	RECT DstRect;
	RECT EncRect;
	DWORD dwFormat;
	mae_be_request_t	mbe_req;
	HANDLE	hEvent;
} render_thread_context_t;

#endif // __CIM_SAMPLE_H
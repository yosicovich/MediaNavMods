/***********************************************************************
This product is the confidential property of NetLogic Microsystems Inc. 
(�NetLogic�), is provided under a non-disclosure agreement or license 
agreement, and is protected under applicable copyright, patent, and trade 
secret laws. 

Unauthorized use, reproduction, distribution or other dissemination without 
the prior written authorization from NetLogic is strictly prohibited.  

NetLogic disclaims all warranties of any nature, express or implied, 
including, without limitation, the warranties of fitness for a particular 
purpose, merchantability and/or non-infringement of third party rights. 

NetLogic assumes no liability for any error or omissions in this PRODUCT, 
or for the use of this PRODUCT. In no event shall NetLogic be liable to 
any other party for any special, PUNITIVE, incidental or consequential 
damages, whether based on breach of contract, tort, product liability, 
infringement of intellectual property rights or otherwise. NetLogic reserves 
the right to make changes to, or discontinue, its products At any time. 

Distribution of the product herein does not convey a license or any other right
in any patent, trademark, or other intellectual property of NetLogic.

Use of the product shall serve as acceptance of these terms and conditions.  If
you do not accept these terms, you should return or destroy the product and any 
other accompanying information immediately.

Copyright, 2009-20010, NetLogic Microsystems, Inc. All rights reserved.   
***************************_ NetLogic_3_******************************/
#define SOC_AU13XX

#define MAEBE_SCFHSR_SRI_N(N) (N<<16)
#define MAEBE_SCFVSR_SRI_N(N) (N<<16)

#include <windows.h>
#include <ceddk.h>
#include <platform.h>
#include "au1x00.h"

#include "cim_sample.h"
#include "os_api.h"

#define TOP_OFFSET 16 // This is set to 16 to remove the 16 lines of VBI data from each field

#define WIDTH(x) ((x).right - (x).left)
#define HEIGHT(x) ((x).bottom - (x).top)

void USAGE( void )
{
	printf("CIM_SAMPLE Usage: <CIM Mode> \n");
		printf("\tNTSC              28 \n");
		printf("Output width and height are optional.  If not provided the CIM Mode width and height will be used.\n");
}

///////////////////////////////////////////////////////////////////////////////
//	Globals
///////////////////////////////////////////////////////////////////////////////
volatile BOOL		g_bQuit = FALSE;
PMEM_IOCTL			memYUV[NUM_BUFFERS];
PMEM_IOCTL			memWeavedYUV[NUM_BUFFERS];
PMEM_IOCTL			memRGB[NUM_BUFFERS];


///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
int _tmain(int argc, TCHAR *argv[], TCHAR *envp[])
{
	CameraMode			mode;
	RECT				encRect;
	DWORD				dwYUVSize;
	DWORD				dwRGBFormat = AU_RGB_565;
	DWORD				dwYUVFormat = FOURCC_UYVY;
	DWORD				dwRGBSize;
	void				*pOverlayBuff = NULL;
	DWORD				outputHeight;
	DWORD				outputWidth;
	HANDLE				hMEM = NULL;
	OVERLAY_IOCTL		ovlIoctl;
	DWORD				dwBytesPerPixel = 2; // Hard code for RGB 565
	DWORD				dwStride = 0;
	HANDLE				hCaptureThread;
	HANDLE				hRenderThread;
	RECT				dstRect;
	RECT				srcRect;
	HANDLE				hCaptureEvent;
	int					nCIMMode = 28; // default to ADV7180 if no other mode is specified
	DWORD				dwScreenWidth = OS_GetScreenWidth();
	DWORD				dwScreenHeight = OS_GetScreenHeight();

	render_thread_context_t RenderThreadContext;
	capture_thread_context_t CaptureThreadContext;

	if ( argc != 1 ) {
		nCIMMode = _wtol(argv[1]);
	}

	////////////////////////
	//	Configure CIM Device
	////////////////////////
	CaptureThreadContext.hCAM = OpenCIM();
		
	RETAILMSG(1,(L"configure to %d\r\n", nCIMMode));

	if (!ConfigureCIM(CaptureThreadContext.hCAM, nCIMMode, &mode))
	{
		RETAILMSG(1, (TEXT("Failed to configure camera device\r\n")));
		return 1;
	}


	//////////////////////////
	//	Setup image dimensions
	//////////////////////////
	encRect.top = 0;
	encRect.bottom = mode.height;
	encRect.left = 0;
	encRect.right = mode.width;

	srcRect.top = TOP_OFFSET;
	srcRect.bottom = mode.height;
	srcRect.left = 0;
	srcRect.right = mode.width; 

	if (argc == 4)
	{
		outputWidth = _wtol(argv[2]);
		outputHeight = _wtol(argv[3]);

	}
	else
	{
		outputWidth =  WIDTH(srcRect);
		outputHeight =  HEIGHT(srcRect);
	}

	// Check to make sure that the output width/height does not exceed that of the display
	if (outputWidth > dwScreenWidth)
	{
		outputWidth = dwScreenWidth;
	}

	if (outputHeight > dwScreenHeight)
	{
		outputHeight = dwScreenHeight;
	}

	//RETAILMSG(1, (TEXT("Final output size: %d x %d\r\n"), outputWidth, outputHeight));

	dstRect.top = 0;
	dstRect.bottom = outputHeight;
	dstRect.left = 0;
	dstRect.right = outputWidth;
	dwStride = dwBytesPerPixel * outputWidth;

	/////////////////////
	//	Create an overlay
	/////////////////////
	ovlIoctl.bufctrl = 0;
	ovlIoctl.flags = 0;
	ovlIoctl.reserved0 = 0;
	ovlIoctl.reserved1 = 0;
	ovlIoctl.winctrl0 = 0;
	ovlIoctl.winctrl1 = 0; // Display driver will fill this pipe and priority
	ovlIoctl.winctrl2 = WINCTRL2_CKMODE(0);
	ovlIoctl.winctrl1 = WINCTRL1_FORM(dwRGBFormat) | WINCTRL1_PO(0) | WINCTRL1_PRI(3);
	ovlIoctl.ndx = OVERLAY_INDEX;

	OS_CreateOverlay(&ovlIoctl);

	////////////////////
	// Configure overlay
	////////////////////
	ovlIoctl.winctrl0 |= (WINCTRL0_OX(0) | WINCTRL0_OY(0)); // set the overlay origins -- WINCTRL0_O_MASK
	ovlIoctl.winctrl1 |= (WINCTRL1_SZX(outputWidth - 1) | WINCTRL1_SZY(outputHeight - 1)); // set the overlay size -- WINCTRL1_SZ_MASK
	ovlIoctl.winctrl2 |= (WINCTRL2_BX(dwStride)); // set the stride (BX) -- WINCTRL2_BX_MASK
	OS_SetOverlayConfig(ovlIoctl);

	///////////////////////
	//	Open mempool driver
	///////////////////////
	hMEM = mem_open_driver();
	if (NULL == hMEM)
	{
		RETAILMSG(1, (TEXT("Failed to open mempool driver\r\n")));
	}

	////////////////////////////////
	//	Allocate YUV and RGB buffers
	////////////////////////////////
	dwYUVSize =  (encRect.right - encRect.left) * (encRect.bottom - encRect.top) * (BPP/8);
	dwRGBSize =  dwScreenWidth * dwScreenHeight * (BPP/8); // This needs to be as big as you might ever made the image

	for( int i=0; i<NUM_BUFFERS; i++ )
	{
		memYUV[i] = mem_alloc(hMEM, dwYUVSize, REGION_ITE, 0);
		memWeavedYUV[i] = mem_alloc(hMEM, dwYUVSize, REGION_ITE, 0);
		memRGB[i] = mem_alloc(hMEM, dwRGBSize, REGION_LCD, 0);

		memset(memYUV[i]->pVirtual, dwYUVSize, 0x00);
		memset(memWeavedYUV[i]->pVirtual, dwYUVSize, 0x00);
		memset(memRGB[i]->pVirtual, dwRGBSize, 0x00);
	}


	////////////////////////////////////
	// Create an event to signal capture
	////////////////////////////////////
	hCaptureEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	CaptureThreadContext.hEvent = hCaptureEvent;
	RenderThreadContext.hEvent = hCaptureEvent;

	////////////////////////
	// Create capture thread
	////////////////////////
	hCaptureThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CaptureThread,
                                     (LPVOID *)&CaptureThreadContext, 0, NULL);


	///////////////////////
	// Create render thread
	///////////////////////
	RenderThreadContext.dwFormat	= dwYUVFormat;
	RenderThreadContext.EncRect		= encRect;
	RenderThreadContext.SrcRect		= srcRect;
	RenderThreadContext.DstRect		= dstRect;
	hRenderThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)RenderThread,
                                     (LPVOID *)&RenderThreadContext, 0, NULL);

	//////////////////////////////////
	// Capture images until ESC is hit
	//////////////////////////////////
	for(int ndx=0; !GetAsyncKeyState(VK_ESCAPE); ndx++ )
	{
		Sleep(100);
	}

	///////////////////////////////////////////////////////////////////
	//	cleanup:
	//	disable and destroy overlay, free memory, and close all devices
	///////////////////////////////////////////////////////////////////
	OS_ShowOverlay(ovlIoctl.ndx, FALSE);
	g_bQuit = TRUE;
	OS_DestroyOverlay(ovlIoctl);

	for( int i=0; i<NUM_BUFFERS; i++ )
	{
		mem_free(hMEM, memYUV[i]);
		mem_free(hMEM, memWeavedYUV[i]);
		mem_free(hMEM, memRGB[i]);
	}

	///////////////////////////
	// Close the mempool driver
	///////////////////////////
	if (NULL != hMEM)
	{
		mem_close_driver(hMEM);
	}

	CloseCIM(CaptureThreadContext.hCAM);

    return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
HANDLE OpenCIM(void)
{
	HANDLE h = CreateFile(L"CAM1:", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    
	if (h == INVALID_HANDLE_VALUE) {
        RETAILMSG(1,(L"Cannot open CAM1: %d\r\n", GetLastError()));
        return NULL;
    }

	return h;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
void CloseCIM(HANDLE h)
{
    if (h)
	{
		CloseHandle(h);
	}
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL ConfigureCIM(HANDLE h, DWORD Index, CameraMode *pMode)
{
	DWORD dwOutLen;

	////////////////////////////////
	//	Set our CIM configuration
	////////////////////////////////
	if (!DeviceIoControl(h, IOCTL_CAMERA_CONFIGURE,
                         &Index, sizeof(Index), NULL, 0, &dwOutLen, NULL)) {
        RETAILMSG(1,(L"Cannot set current camera mode: %d\r\n", GetLastError()));
        return FALSE;
    }

    if (!DeviceIoControl(h, IOCTL_CAMERA_QUERY,
                         NULL, 0, pMode, sizeof(CameraMode), &dwOutLen, NULL)) {
        RETAILMSG(1,(L"Cannot get current camera mode: %d\r\n", GetLastError()));
        return FALSE;
    }
	RETAILMSG(1,(TEXT("Camera config: mode:%d w:%d h:%d %s\r\n"), pMode->mode, pMode->width, pMode->height, pMode->modename ));

	return TRUE;
}

ULONG CaptureThread(DWORD dwContext)
{
	DWORD						ndx=0;
	DWORD						dwOutLen;
	PMEM_IOCTL					pMem;
	capture_thread_context_t *pThreadContext = (capture_thread_context_t *)dwContext;

	while (!g_bQuit)
	{
		if ( ndx == NUM_BUFFERS )
			ndx = 0;

		pMem = memYUV[ndx];

		if (!DeviceIoControl(pThreadContext->hCAM, IOCTL_CAMERA_CAPTURE,
	                         NULL, 0, pMem->pPhysical, pMem->dwSize, &dwOutLen, NULL)) {
	        RETAILMSG(1,(L"FAILED TO CAPTURE FRAME!: %d\r\n", GetLastError()));
	    }

		SetEvent(pThreadContext->hEvent);
		ndx++;
	}

	return 0;
}

ULONG RenderThread(DWORD dwContext)
{
	HANDLE					hITE = NULL;
	HANDLE					hPowerManagementEvent = NULL;
	DWORD					ndx = 0;
	PMEM_IOCTL				pSrcMem;
	PMEM_IOCTL				pDstMem;
	PMEM_IOCTL				pWeavedSrcMem;
	static BOOL				bFirstFrame = TRUE;
	OVERLAY_UPDATE_IOCTL	ovlUpdateIoctl;
	mae_be_request_t		mbe_req;
	render_thread_context_t *pThreadContext = (render_thread_context_t *)dwContext;
	
	DWORD dwSrcWidth = WIDTH(pThreadContext->SrcRect);
	DWORD dwSrcHeight = HEIGHT(pThreadContext->SrcRect);
	DWORD dwDstWidth = WIDTH(pThreadContext->DstRect);
	DWORD dwDstHeight = HEIGHT(pThreadContext->DstRect);
	DWORD dwEncHeight = HEIGHT(pThreadContext->EncRect);

	UINT32 uSrcOffSet = (pThreadContext->SrcRect.top * dwSrcWidth) * (BPP/8);
	UINT32 uSrcAddr;

	RETAILMSG(1, (TEXT("uSrcOffSet = %d\r\n"), uSrcOffSet));

	ovlUpdateIoctl.ndx = OVERLAY_INDEX;
	ovlUpdateIoctl.flags = LCD_UPDATE_IN_VBLANK;

	/////////////////////////////////////////////////////////////////////////////
	// Open hand to UserActivity.  We'll touch this each fram so screen stays on. 
	/////////////////////////////////////////////////////////////////////////////
	hPowerManagementEvent = OpenEvent(EVENT_ALL_ACCESS,FALSE,TEXT("PowerManager/ActivityTimer/UserActivity"));

	///////////////////
	//	Open ITE driver
	///////////////////
	hITE = maeite_open_driver();

	if(NULL == hITE)
	{
		RETAILMSG(1, (TEXT("Failed to open ITE driver\r\n")));
		return 1;
	}

	////////////////
	// Configure ITE
	////////////////
	// Coefficients
	maeite_set_default_csc(&mbe_req);
	maeite_set_default_scf(&mbe_req, ITE_MODE_INTERLACED);
	// Scaler ratios
	mbe_req.scfhsr = maeite_calc_sr(dwSrcWidth, dwDstWidth);
	mbe_req.scfvsr = maeite_calc_sr((dwSrcHeight), dwDstHeight);
	// disable scaler if it's 1:1 -- Except when doing interlaced to get rid of jaggies.  This example is always interlaced for now.
	// mbe_req.scfdisable = (mbe_req.scfhsr == MAEBE_SCFHSR_SRI_N(1)) && (mbe_req.scfvsr == MAEBE_SCFVSR_SRI_N(1)) ;
	// Destination registers
	mbe_req.dstcfg |= MAEBE_DSTCFG_OF_N(DSTCFG_OF_16BPP);
	mbe_req.dstcfg |= (1 << 10);
	mbe_req.dstheight = dwDstHeight;
	mbe_req.dststr = dwDstWidth * (BPP/8);
	mbe_req.magic = MAEBE_MAGIC;

	while (!g_bQuit)
	{
		WaitForSingleObject(pThreadContext->hEvent, INFINITE);

		if ( ndx == NUM_BUFFERS )
			ndx = 0;

		pSrcMem = memYUV[ndx];
		pDstMem = memRGB[ndx];
		pWeavedSrcMem = memWeavedYUV[ndx];

		// calculate source start address
		uSrcAddr = (UINT32) pWeavedSrcMem->pPhysical;
		
		// setup source registers
		maeite_setup_src_regs(&mbe_req, pThreadContext->dwFormat, uSrcAddr, 
			dwSrcWidth, (dwSrcHeight));

		////////////////
		// Weave the YUV
		////////////////
		DWORD FieldSize = mbe_req.srcastr * (dwEncHeight / 2); // one field should be exactly one half of the buffer
		DWORD YUVLineSize = mbe_req.srcastr;
		UINT32 pCurrentWeaved = (UINT32) pWeavedSrcMem->pVirtual;
		UINT32 pCurrentOddField = (UINT32) pSrcMem->pVirtual;
		UINT32 pCurrentEvenField = (UINT32) pCurrentOddField + FieldSize;


		for (DWORD x = 0; x < (dwSrcHeight/2); x++)
		{
			memcpy((void *)pCurrentWeaved, (void *)pCurrentOddField, YUVLineSize);
			pCurrentWeaved += YUVLineSize;
			pCurrentOddField += YUVLineSize;

			memcpy((void *)pCurrentWeaved, (void *)pCurrentEvenField, YUVLineSize);	
			pCurrentWeaved += YUVLineSize;
			pCurrentEvenField += YUVLineSize;
		}
		////////////
		// End Weave
		////////////

		mbe_req.dstaddr = (uint32) pDstMem->pPhysical;

		maeite_submit_frame(hITE, &mbe_req, 0, 0);

		ovlUpdateIoctl.phys = pDstMem->pPhysical;
		OS_SetNextOverlayBuffer(ovlUpdateIoctl);

		// Keep the LCD going.
		SetEvent(hPowerManagementEvent);

		if (bFirstFrame)
		{
				OS_ShowOverlay(ovlUpdateIoctl.ndx, TRUE);
				bFirstFrame = FALSE;
		}

		ndx++;
	}

	////////////////////
	//	Close ITE driver
	////////////////////
	maeite_close_driver(hITE);


	///////////////////////////
	// Close Power Event handle
	///////////////////////////
	CloseHandle(hPowerManagementEvent);

	return 0;

}
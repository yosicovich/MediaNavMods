#define SOC_AU13XX

#include <windows.h>
#include <ceddk.h>
#include <platform.h>
#include "au1x00.h"
#include "lcd_ioctl.h"
#include "Gui.h"



#define PLAY_BUTTON_PATH TEXT("\\USB Disk\\NETL_Player_Images\\PlayButton.bmp")
#define PAUSE_BUTTON_PATH TEXT("\\USB Disk\\NETL_Player_Images\\PauseButton.bmp")
#define MENU_BUTTON_PATH TEXT("\\USB Disk\\NETL_Player_Images\\MenuButton.bmp")
#define TOP_STATUS_BAR_PATH TEXT("\\USB Disk\\NETL_Player_Images\\TopStatusBar.bmp")
#define BOTTOM_STATUS_BAR_PATH TEXT("\\USB Disk\\NETL_Player_Images\\BottomStatusBar.bmp")


#define TEST_CLIP TEXT("\\USB Disk\\Africa.wmv")

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
int SetAENBit(DWORD dwPlane, BOOL bEnable)
{
	int retval;
	HDC hDC = GetDC(NULL);
	OVERLAY_IOCTL ovlIoctl;

	ovlIoctl.flags = OVERLAY_CONFIG_GET;
	ovlIoctl.ndx = dwPlane;

	retval = ExtEscape(hDC, LCD_OVERLAY_CONFIG, sizeof(ovlIoctl), (LPCSTR)&ovlIoctl, 0, NULL);
	
	ovlIoctl.flags = 0;

	RETAILMSG(1, (TEXT("(Plane %d) ORIG - ovlIoctl.winctrl0 = 0x%x\r\n"), dwPlane, ovlIoctl.winctrl0));

	if (bEnable)
	{
		ovlIoctl.winctrl0 |= LCD_WINCTRL0_AEN;
	}
	else
	{
		ovlIoctl.winctrl0 &= ~LCD_WINCTRL0_AEN;
	}

	RETAILMSG(1, (TEXT("(Plane %d) NEW - ovlIoctl.winctrl0 = 0x%x\r\n"), dwPlane, ovlIoctl.winctrl0));

	retval = ExtEscape(hDC, LCD_OVERLAY_CONFIG, sizeof(ovlIoctl), (LPCSTR)&ovlIoctl, 0, NULL);

	return retval;
}


///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BitMap_t::BitMap_t()
{
	UnloadBitmap();
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BitMap_t::BitMap_t(const TCHAR *szFileName)
{
	UnloadBitmap();
	LoadBitmap(szFileName);
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BitMap_t::~BitMap_t()
{
	UnloadBitmap();
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void BitMap_t::LoadBitmap(const TCHAR* szFileName)
{
	int		nReturnValue = 0;
	int		nReadSize = 0;
	DWORD	dwBytesRead;
	BYTE	*pBitmapInfo = NULL;

	///////////////////////
	// Open the bitmap file
	///////////////////////
	m_hBitmapFile = CreateFile(szFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,0);

	if (NULL == m_hBitmapFile)
	{
		// TODO:
		// Do something here to deal with the error
		DWORD dwError = GetLastError();
		nReturnValue =  dwError;
		goto EXIT_FUNCTION;
	}

	m_dwFileSize = GetFileSize(m_hBitmapFile, NULL);

	if(INVALID_FILE_SIZE == m_dwFileSize)
	{
		// TODO:
		// Do something here to deal with the error
		DWORD dwError = GetLastError();
		nReturnValue =  dwError;
		goto EXIT_FUNCTION;
	}

	/////////////////////////////////////////
	// Read the file to get the bitmap header
	/////////////////////////////////////////
	nReadSize = sizeof(BITMAPFILEHEADER);

	if((0 == ReadFile(m_hBitmapFile, &m_BitmapFileHeader, nReadSize, &dwBytesRead, NULL)) || (nReadSize != dwBytesRead))
	{
		// TODO:
		// Do something here to deal with the error
		DWORD dwError = GetLastError();
		nReturnValue =  dwError;
		goto EXIT_FUNCTION;
	}

	if (m_BitmapFileHeader.bfType != BITMAP_SIGNATURE) 
	{
		// TODO:
		// Do something here to deal with the error
		nReturnValue =  -1;
		goto EXIT_FUNCTION;
	}

	///////////////////////
	// Read the bitmap info
	///////////////////////
	nReadSize = m_BitmapFileHeader.bfOffBits - sizeof(BITMAPFILEHEADER);

	if (nReadSize < 0)
	{
		// TODO:
		// Do something here to deal with the error
		nReturnValue =  -1;
		goto EXIT_FUNCTION;
	}

	pBitmapInfo = new UINT8[nReadSize];
	if((0 == ReadFile(m_hBitmapFile, pBitmapInfo, nReadSize, &dwBytesRead, NULL)) || (nReadSize != dwBytesRead))
	{
		// TODO:
		// Do something here to deal with the error
		goto EXIT_FUNCTION;
	}

	m_BitmapInfo = *(BITMAPINFO *)pBitmapInfo;

	///////////////////////////////////
	// Make sure we have a valid bitmap
	///////////////////////////////////
	if(0 == m_BitmapInfo.bmiHeader.biSizeImage)
	{
		nReadSize = (m_BitmapInfo.bmiHeader.biBitCount * m_BitmapInfo.bmiHeader.biWidth + 7) / 8;
		if(0 != nReadSize % 2)
		{
			nReadSize += 1;
		}
		nReadSize *= abs(m_BitmapInfo.bmiHeader.biHeight);
		m_BitmapInfo.bmiHeader.biSizeImage = nReadSize;
	}

	if(m_dwFileSize < m_BitmapFileHeader.bfOffBits + m_BitmapInfo.bmiHeader.biSizeImage)
	{
		m_BitmapInfo.bmiHeader.biSizeImage = m_dwFileSize - m_BitmapFileHeader.bfOffBits;
	}

	/////////////////////////////////////////////////
	// Create and fill the DIB buffer with the bitmap
	/////////////////////////////////////////////////
	m_hBitmap = CreateDIBSection(NULL, &m_BitmapInfo, DIB_RGB_COLORS, (VOID **) &m_pBitmapData, NULL, 0);

	if (NULL == m_hBitmap)
	{
		// TODO:
		// Do something here to deal with the error
		goto EXIT_FUNCTION;
	}

	nReadSize = m_BitmapInfo.bmiHeader.biSizeImage; 

	if((0 == ReadFile(m_hBitmapFile, m_pBitmapData, nReadSize, &dwBytesRead, NULL)) || (nReadSize != dwBytesRead))
	{
		// TODO:
		// Do something here to deal with the error
		goto EXIT_FUNCTION;
	}

EXIT_FUNCTION:
	if (pBitmapInfo)
	{
		delete pBitmapInfo;
	}

	return;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void BitMap_t::UnloadBitmap()
{
	memset(&m_BitmapFileHeader, 0, sizeof(BITMAPFILEHEADER));
	memset(&m_BitmapInfo, 0, sizeof(BITMAPINFO));

	if (m_hBitmap)
	{
		DeleteObject(m_hBitmap);
		m_hBitmap = NULL;
	}

	if (m_hBitmapFile)
	{
		CloseHandle(m_hBitmapFile);
		m_hBitmapFile = NULL;
	}

	m_dwFileSize = 0;	

	m_pBitmapData = NULL;
}


///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD BitMap_t::GetPixelColor(int x, int y)
{
	DWORD dwColor = 0;
	DWORD dwReadPosition = 0;
//	COLORREF crPixel;
	
	// Calculate the line to start on
	dwReadPosition = y * m_BitmapInfo.bmiHeader.biWidth * m_BitmapInfo.bmiHeader.biBitCount;  

	// Now the pixel on that line
	dwReadPosition += x * m_BitmapInfo.bmiHeader.biBitCount;

	dwColor = *((DWORD *)m_pBitmapData + dwReadPosition);

	return dwColor;
}


Gui_t::Gui_t() :
m_pPlayer(NULL),
m_hwndGui(NULL)
{
	int		nTop, nLeft, nBottom, nRight;

	SetAENBit(DESKTOP_PLANE, FALSE);

	// Load our widgets for the GUI
	// TODO:
	// Move all of the bitmap configuration/position to a seperate file.  
	// Perhaps XML so that it's easily skinable.
	
	/////////////////
	// Top status bar
	/////////////////
	m_Widgets[TOP_STATUS_BAR].BitmapImage.LoadBitmap(TOP_STATUS_BAR_PATH);
	m_Widgets[TOP_STATUS_BAR].bActionEnabled = FALSE;
	m_Widgets[TOP_STATUS_BAR].bVisible = TRUE;

	nTop = 0;
	nLeft = 0;
	nBottom = m_Widgets[TOP_STATUS_BAR].BitmapImage.getBitmapHeight();
	nRight = m_Widgets[TOP_STATUS_BAR].BitmapImage.getBitmapWidth();

	m_Widgets[TOP_STATUS_BAR].rcWidget.left	= nLeft; 
	m_Widgets[TOP_STATUS_BAR].rcWidget.top		= nTop;
	m_Widgets[TOP_STATUS_BAR].rcWidget.right	= nRight;
	m_Widgets[TOP_STATUS_BAR].rcWidget.bottom	= nBottom;
	m_Widgets[TOP_STATUS_BAR].AlphaValue = 0x7f;

	////////////////////
	// Bottom status bar
	////////////////////
	m_Widgets[BOTTOM_STATUS_BAR].BitmapImage.LoadBitmap(BOTTOM_STATUS_BAR_PATH);
	m_Widgets[BOTTOM_STATUS_BAR].bActionEnabled = FALSE;
	m_Widgets[BOTTOM_STATUS_BAR].bVisible = TRUE;

	nTop = 480 - m_Widgets[BOTTOM_STATUS_BAR].BitmapImage.getBitmapHeight();
	nLeft = 0;
	nBottom = nTop + m_Widgets[BOTTOM_STATUS_BAR].BitmapImage.getBitmapHeight();
	nRight = nLeft + m_Widgets[BOTTOM_STATUS_BAR].BitmapImage.getBitmapWidth();
	
	m_Widgets[BOTTOM_STATUS_BAR].rcWidget.left		= nLeft; 
	m_Widgets[BOTTOM_STATUS_BAR].rcWidget.top		= nTop;
	m_Widgets[BOTTOM_STATUS_BAR].rcWidget.right		= nRight;
	m_Widgets[BOTTOM_STATUS_BAR].rcWidget.bottom	= nBottom;
	m_Widgets[BOTTOM_STATUS_BAR].AlphaValue = 0x7f;

	//////////////
	// Play button
	//////////////
	m_Widgets[PLAY_BUTTON].BitmapImage.LoadBitmap(PLAY_BUTTON_PATH);
	m_Widgets[PLAY_BUTTON].bActionEnabled = TRUE;
	m_Widgets[PLAY_BUTTON].bVisible = TRUE;
	
	nTop = 405;
	nLeft = 262;
	nBottom = nTop + m_Widgets[PLAY_BUTTON].BitmapImage.getBitmapHeight();
	nRight = nLeft + m_Widgets[PLAY_BUTTON].BitmapImage.getBitmapWidth();
	
	m_Widgets[PLAY_BUTTON].rcWidget.left	= nLeft; 
	m_Widgets[PLAY_BUTTON].rcWidget.top		= nTop;
	m_Widgets[PLAY_BUTTON].rcWidget.right	= nRight;
	m_Widgets[PLAY_BUTTON].rcWidget.bottom	= nBottom;
	m_Widgets[PLAY_BUTTON].AlphaValue		= 0xff;


	///////////////
	// Pause button
	///////////////
	m_Widgets[PAUSE_BUTTON].BitmapImage.LoadBitmap(PAUSE_BUTTON_PATH);
	m_Widgets[PAUSE_BUTTON].bActionEnabled = TRUE;
	m_Widgets[PAUSE_BUTTON].bVisible = FALSE;

	nTop = 405;
	nLeft = 262;
	nBottom = nTop + m_Widgets[PAUSE_BUTTON].BitmapImage.getBitmapHeight();
	nRight = nLeft + m_Widgets[PAUSE_BUTTON].BitmapImage.getBitmapWidth();
	
	m_Widgets[PAUSE_BUTTON].rcWidget.left		= nLeft; 
	m_Widgets[PAUSE_BUTTON].rcWidget.top		= nTop;
	m_Widgets[PAUSE_BUTTON].rcWidget.right		= nRight;
	m_Widgets[PAUSE_BUTTON].rcWidget.bottom		= nBottom;
	m_Widgets[PAUSE_BUTTON].AlphaValue			= 0xff;

	//////////////
	// Menu button
	//////////////
	m_Widgets[MENU_BUTTON].BitmapImage.LoadBitmap(MENU_BUTTON_PATH);
	m_Widgets[MENU_BUTTON].bActionEnabled = TRUE;
	m_Widgets[MENU_BUTTON].bVisible = TRUE;

	nTop = 405;
	nLeft = 675;
	nBottom = nTop + m_Widgets[MENU_BUTTON].BitmapImage.getBitmapHeight();
	nRight = nLeft + m_Widgets[MENU_BUTTON].BitmapImage.getBitmapWidth();
	
	m_Widgets[MENU_BUTTON].rcWidget.left	= nLeft; 
	m_Widgets[MENU_BUTTON].rcWidget.top		= nTop;
	m_Widgets[MENU_BUTTON].rcWidget.right	= nRight;
	m_Widgets[MENU_BUTTON].rcWidget.bottom	= nBottom;
	m_Widgets[MENU_BUTTON].AlphaValue		= 0xff;

	m_pPlayer = new DShowPlayer_t();
	m_pPlayer->LoadMedia(TEST_CLIP);
}

Gui_t::~Gui_t()
{
	RECT rcDefault = {0, 0, 0, 0};
	// Unload our widgets for the GUI
	for (int x = 0 ; x < NUM_WIDGETS ; x++)
	{
		m_Widgets[x].BitmapImage.UnloadBitmap();
		m_Widgets[x].bActionEnabled = FALSE;
		m_Widgets[x].bVisible = FALSE;
		m_Widgets[x].rcWidget = rcDefault;
	}

	if (m_pPlayer)
	{
		delete m_pPlayer;
	}

	SetAENBit(DESKTOP_PLANE, TRUE);

	DestroyRegion();

}

void Gui_t::CreateGui(HINSTANCE hInstance, LPCTSTR lpTemplate, HWND hWndParent, DLGPROC lpDialogFunc)


{
	DWORD dwError;

	if (m_hwndGui)
	{
		return;
	}

	m_hwndGui = CreateDialog(hInstance, lpTemplate, hWndParent, lpDialogFunc);

	if (NULL == m_hwndGui)
	{
		// TODO:
		// Do something here to deal with the error
		dwError = GetLastError();
		return;
	}

	CreateRegion();
}

void Gui_t::OnMouseDown(HWND hWnd, POINT pt)
{
	// TODO:
	// If we're using the timer to turn off the GUI we need to turn it back on 
	// if it's off on every mouse down event.
}

void Gui_t::OnMouseUp(HWND hWnd, POINT pt)
{
	for (int x = 0 ; x < NUM_WIDGETS ; x++)
	{
		if (m_Widgets[x].bVisible && m_Widgets[x].bActionEnabled)
		{
			if (PtInRect(&(m_Widgets[x].rcWidget), pt))
			{
				switch (x)
				{
				case PLAY_BUTTON:
					m_Widgets[PLAY_BUTTON].bVisible = FALSE;
					m_Widgets[PAUSE_BUTTON].bVisible = TRUE;
					InvalidateRect(hWnd, &(m_Widgets[PAUSE_BUTTON].rcWidget), FALSE);

					// TODO:
					// Move this so it only happens on the first playback or something instead of doing it on every play.
					// Reparent the window to our window.
					m_pPlayer->SetEventHandler(hWnd);
					m_pPlayer->SetOwnerVideoWindow(hWnd, (WS_CHILD));
					m_pPlayer->SetVideoWindowSize(800, 480);
					m_pPlayer->SetVideoWindowPosition(0, 0); //(WindowRect.top, WindowRect.top);
					m_pPlayer->Play();
					break;
				case PAUSE_BUTTON:
					m_Widgets[PAUSE_BUTTON].bVisible = FALSE;
					m_Widgets[PLAY_BUTTON].bVisible = TRUE;
					InvalidateRect(hWnd, &(m_Widgets[PLAY_BUTTON].rcWidget), FALSE);
					m_pPlayer->Pause();
					break;
				case MENU_BUTTON:
					// This can bring up a submenu, but for now we'll use it to exit the app.
					PostMessage(hWnd, WM_QUIT, 0, 0);
					break;
				default:
					// TODO:
					// Do something here to deal with the error
					MessageBox(hWnd, TEXT("Clicked on a non-existant button? Did you set a widget to bActionEnabled that doesn't have an action associated with it?"), TEXT("Unexplained error"), MB_OK); 
					break;
				}
				
				// We found the action widget let's break out.
				break;
			}
		}
	}

}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void Gui_t::OnTimer(HWND hWnd)
{
	// TODO:
	// We can use this to turn off the GUI after some period of time.
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void Gui_t::OnDraw(HDC hDC, RECT rcUpdateRect)
{
	HBITMAP	hBitmap;
	HDC		hBkgdDC = CreateCompatibleDC(hDC);
	int		xOriginDest, yOriginDest;
	int		xDestWidth, xDestHeight;

	
	BLENDFUNCTION bf;
	memset(&bf, 0, sizeof(BLENDFUNCTION));
	bf.BlendOp = AC_SRC_OVER;
	bf.BlendFlags = 0;
	bf.AlphaFormat = 0; // Don't use the source value
	bf.SourceConstantAlpha = 0; 

	// TODO:
	// We should really only redraw what is within the rcUpdateRect RECT passed in.
	// This will reduce the amount of drawing done and thereby reduce CPU untilization.
	// For now we'll just redraw the entire GUI while we're still working on this class.
	for (int x = 0 ; x < NUM_WIDGETS ; x++)
	{
		if (m_Widgets[x].bVisible)
		{
			hBitmap = m_Widgets[x].BitmapImage.getBitmapHandle();

			xOriginDest = m_Widgets[x].rcWidget.left;
			yOriginDest = m_Widgets[x].rcWidget.top;
			xDestWidth = m_Widgets[x].BitmapImage.getBitmapWidth();
			xDestHeight = m_Widgets[x].BitmapImage.getBitmapHeight();

			bf.SourceConstantAlpha = m_Widgets[x].AlphaValue;
			
			SelectObject(hBkgdDC, hBitmap);

			BOOL ret = AlphaBlend(hDC, xOriginDest, yOriginDest, xDestWidth, xDestHeight,
				hBkgdDC, 0, 0, xDestWidth, xDestHeight, bf);

			if (FALSE == ret)
			{
				// TODO:
				// Do something here to deal with the error
				DWORD dwError = GetLastError();
			}
		}		
	}

	DeleteDC(hBkgdDC); 
}

void Gui_t::CreateRegion()
{
	HRGN	hRgnTop		= NULL;
	HRGN	hRgnBottom	= NULL;
	int		iRet;
	DWORD	dwError = 0;

	//create an empty region
	m_hRgn = CreateRectRgn(0,0,0,0);

	if (m_Widgets[TOP_STATUS_BAR].bVisible == TRUE)
	{
		hRgnTop = CreateRectRgn(m_Widgets[TOP_STATUS_BAR].rcWidget.left, 
									m_Widgets[TOP_STATUS_BAR].rcWidget.top,
									m_Widgets[TOP_STATUS_BAR].rcWidget.right,
									m_Widgets[TOP_STATUS_BAR].rcWidget.bottom);
	}

	if (m_Widgets[BOTTOM_STATUS_BAR].bVisible == TRUE)
	{
		hRgnBottom = CreateRectRgn(m_Widgets[BOTTOM_STATUS_BAR].rcWidget.left, 
									m_Widgets[BOTTOM_STATUS_BAR].rcWidget.top,
									m_Widgets[BOTTOM_STATUS_BAR].rcWidget.right,
									m_Widgets[BOTTOM_STATUS_BAR].rcWidget.bottom);
	}


	iRet = CombineRgn(m_hRgn, hRgnTop, hRgnBottom, RGN_OR);

	switch (iRet)
	{
		case NULLREGION:
		case ERROR:
			goto EXIT_FUNCTION;

		case SIMPLEREGION:
		case COMPLEXREGION:
		default:
			break;
	}

	iRet = SetWindowRgn(m_hwndGui, m_hRgn, TRUE);

	if (iRet == 0)
	{
		// TODO:
		// Handle this error.
		dwError = GetLastError();
		goto EXIT_FUNCTION;
	}

	iRet = SetWindowPos(m_hwndGui, HWND_TOPMOST, 0, 0, 800, 480, NULL);

EXIT_FUNCTION:
	if (hRgnTop)
		DeleteObject(hRgnTop);
	if (hRgnBottom)
		DeleteObject(hRgnBottom);
}

 void Gui_t::DestroyRegion()
{
	if (m_hRgn)
		DeleteObject(m_hRgn);
}
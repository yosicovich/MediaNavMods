#include "DShowPlayer.h"

#ifndef RETAILMSG
#define RETAILMSG(a, b)
#endif


///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
DShowPlayer_t::DShowPlayer_t() :
m_pGraphBuilder (NULL),
m_pMediaControl (NULL),
m_pMediaEvent(NULL),
m_pVideoWindow(NULL),
m_nState(Uninitialized)
{
	RETAILMSG(1, (TEXT("Constructor!!!!\r\n")));
	 // Initialize COM
	CoInitialize(NULL);
}

void DShowPlayer_t::WaitForState(FILTER_STATE State)
{
    // Make sure we have switched to the required state
    LONG   lfs ;

	if (NULL == m_pMediaControl)
	{
		return;
	}

    do
    {
        m_pMediaControl->GetState(10, &lfs) ;
    } while (State != lfs) ;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
DShowPlayer_t::~DShowPlayer_t()
{
	RETAILMSG(1, (TEXT("Destructor!!!!\r\n")));

	Stop();

	WaitForState(State_Stopped);

	ClearEventHandler();
	ClearOwnerVideoWindow();
	UnloadMedia();
	

	// Finish using COM
	CoUninitialize();

	RETAILMSG(1, (TEXT("Destructor DIGGITY DONE!!!!\r\n")));
}


///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
int DShowPlayer_t::LoadMedia(const TCHAR *szMediaFile)
{
	HRESULT hr;

	RETAILMSG(1, (TEXT("Loading media %s\r\n"), szMediaFile));

	// Create a FilterGraph
	hr = CoCreateInstance(CLSID_FilterGraph,
						NULL,
						CLSCTX_INPROC,
						IID_IGraphBuilder,
						(LPVOID *)&m_pGraphBuilder);
	if (FAILED(hr))
	{
		RETAILMSG(1, (TEXT("Failed to create Filter Graph!!!\r\n")));
	}

	// Get MediaControl Interface
	hr = m_pGraphBuilder->QueryInterface(IID_IMediaControl,
						(LPVOID *)&m_pMediaControl);

	if (FAILED(hr))
	{
		RETAILMSG(1, (TEXT("Failed to get IID_IMediaControl interface!!!\r\n")));
	}

	m_pGraphBuilder->RenderFile(szMediaFile , NULL);



	return 0;
}


///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
int DShowPlayer_t::UnloadMedia()
{

	RETAILMSG(1, (TEXT("Unloading media\r\n")));
	// Release
	if (m_pMediaControl)
	{
		m_pMediaControl->Release();
		m_pMediaControl = NULL;
	}

	if (m_pGraphBuilder)
	{
		m_pGraphBuilder->Release();
		m_pGraphBuilder = NULL;
	}

	m_nState = Uninitialized;
	return 0;
}


///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
int DShowPlayer_t::SetEventHandler(HWND hWndApp)
{
	HRESULT hr;

	RETAILMSG(1, (TEXT("SetEventHandler\r\n")));

	if (m_pMediaEvent)
	{
		// We only handle one event handler at a time
		return -1;
	}

	if (m_pGraphBuilder)
	{
		hr = m_pGraphBuilder->QueryInterface(IID_IMediaEventEx, 
							(LPVOID *)&m_pMediaEvent);

		if (FAILED(hr))
		{
			return -1;
		}

		hr = m_pMediaEvent->SetNotifyWindow((OAHWND) hWndApp, WM_PLAY_EVENT,
			(ULONG)(LPVOID)m_pMediaEvent) ;
	    
		if (FAILED(hr))
		{
			return -1;
		}
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
int DShowPlayer_t::ClearEventHandler()
{
	RETAILMSG(1, (TEXT("ClearEventHandler\r\n")));
	if (m_pMediaEvent) {
        // clear any already set notification arrangement
        m_pMediaEvent->SetNotifyWindow(NULL, WM_PLAY_EVENT, (ULONG)(LPVOID)m_pMediaEvent) ;
        m_pMediaEvent->Release() ;
        m_pMediaEvent = NULL ;
    }

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
int DShowPlayer_t::SetOwnerVideoWindow(HWND hWnd, long lStyle)
{
	HRESULT hr;

	RETAILMSG(1, (TEXT("SetOwnerVideoWindow\r\n")));

	if (m_pVideoWindow || (NULL == m_pGraphBuilder))
	{
		return -1;
	}

	hr = m_pGraphBuilder->QueryInterface(IID_IVideoWindow,   (void **)&m_pVideoWindow);

	//m_pVideoWindow->put_Owner((OAHWND)hWnd);
	m_pVideoWindow->put_WindowStyle(lStyle);

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
int DShowPlayer_t::ClearOwnerVideoWindow()
{
	RETAILMSG(1, (TEXT("ClearOwnerVideoWindow\r\n")));

	if (m_pVideoWindow == NULL)
	{
		return -1;
	}

	m_pVideoWindow->put_Owner((OAHWND)NULL);
	m_pVideoWindow->Release();
	m_pVideoWindow = NULL;

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
int DShowPlayer_t::SetVideoWindowSize(int nWidth, int nHeight)
{
	RETAILMSG(1, (TEXT("SetVideoWindowSize\r\n")));
	if (NULL == m_pVideoWindow)
	{
		return -1;
	}

	m_pVideoWindow->put_Width(nWidth);
	m_pVideoWindow->put_Height(nHeight);

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
int DShowPlayer_t::SetVideoWindowPosition(int nTop, int nLeft)
{
	RETAILMSG(1, (TEXT("SetVideoWindowPosition\r\n")));
	if (NULL == m_pVideoWindow)
	{
		return -1;
	}

	m_pVideoWindow->put_Top(nTop);
	m_pVideoWindow->put_Left(nLeft);

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
int DShowPlayer_t::Pause()
{
	HRESULT hr;

	RETAILMSG(1, (TEXT("Pause\r\n")));

	if (m_pMediaControl)
	{
		hr = m_pMediaControl->Pause();
		m_nState = Paused;
	}

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
int DShowPlayer_t::Play()
{
	HRESULT hr;

	RETAILMSG(1, (TEXT("Play\r\n")));

	if (m_pMediaControl)
	{
		hr = m_pMediaControl->Run();
		m_nState = Playing;
	}

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
//
///////////////////////////////////////////////////////////////////////////////
int DShowPlayer_t::Stop()
{
	HRESULT hr;

	RETAILMSG(1, (TEXT("Stop\r\n")));

	if (m_pMediaControl)
	{
		hr = m_pMediaControl->Stop();
		m_nState = Stopped;
	}

	return 0;
}
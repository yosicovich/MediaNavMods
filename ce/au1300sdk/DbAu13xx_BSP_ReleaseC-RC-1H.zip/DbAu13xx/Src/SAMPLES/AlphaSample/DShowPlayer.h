#ifndef __DSHOWPLAYER_H
#define __DSHOWPLAYER_H

#include <dshow.h>

class DShowPlayer_t
{
private:
	IGraphBuilder *m_pGraphBuilder;
	IMediaControl *m_pMediaControl;
	IMediaEventEx *m_pMediaEvent;
	IVideoWindow  *m_pVideoWindow;

	int m_nState;

protected:

public:
	DShowPlayer_t();
	~DShowPlayer_t();

	int Pause();
	int Play();
	int Stop();
	int GetState() { return m_nState; }
	int LoadMedia(const TCHAR *szMediaFile);
	int UnloadMedia();

	int SetEventHandler(HWND hWndApp);
	int ClearEventHandler();

	int SetOwnerVideoWindow(HWND hWnd, long lStyle);
	int ClearOwnerVideoWindow();

	int SetVideoWindowSize(int nWidth, int nHeight);
	int SetVideoWindowPosition(int nTop, int nLeft);

	void WaitForState(FILTER_STATE State);

	IMediaEventEx *GetMediaEvent() { return m_pMediaEvent; }
};


// Player state
typedef enum {
    Uninitialized = 0, Stopped, Paused, Playing, Scanning
} PLAYER_STATE ;

// Define a special WM message for playback related events from DShow filtergraph
#define WM_PLAY_EVENT     WM_USER + 100
#define WM_SIZE_CHANGE    WM_USER + 101


#endif __DSHOWPLAYER_H
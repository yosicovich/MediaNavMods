#ifndef __GUI_H
#define __GUI_H

#include "DShowPlayer.h"

#define BITMAP_SIGNATURE (0x4D42)


///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
enum GuiWidgetId_t
{
	TOP_STATUS_BAR = 0,
	BOTTOM_STATUS_BAR,
	PLAY_BUTTON,
	PAUSE_BUTTON,
	MENU_BUTTON,
	PROGRESS_BAR,
	NUM_WIDGETS
};



///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
class BitMap_t {
private:
	// File info
	HANDLE				m_hBitmapFile;
	DWORD				m_dwFileSize;

	// Bitmap info
	BITMAPFILEHEADER	m_BitmapFileHeader;
	BITMAPINFO			m_BitmapInfo;
	BYTE				*m_pBitmapData;
	HBITMAP				m_hBitmap;

protected:

public:
	BitMap_t();
	BitMap_t(const TCHAR *szFileName);
	~BitMap_t();

	void LoadBitmap(const TCHAR* szFileName);
	void UnloadBitmap();
	DWORD getBitmapSize() { return m_BitmapInfo.bmiHeader.biSizeImage; };
	DWORD getBitmapWidth() { return m_BitmapInfo.bmiHeader.biWidth; };
	DWORD getBitmapHeight() { return m_BitmapInfo.bmiHeader.biHeight; };
	HBITMAP getBitmapHandle() { return m_hBitmap; };
	DWORD GetPixelColor(int x, int y);
};

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
typedef struct Widget_t
{
	RECT		rcWidget;		// The RECT of where in the  client window this widget exists
	BitMap_t	BitmapImage;	// The bitmap to draw for this widget
	BOOL		bVisible;		// Enable this to draw this widget
	BOOL		bActionEnabled; // Set this if clicking on this widget should cause some action
	UINT8		AlphaValue;
} Widget_t;

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
class Gui_t
{
private:
	Widget_t		m_Widgets[NUM_WIDGETS];
	DShowPlayer_t	*m_pPlayer;
	HWND			m_hwndGui;
	HRGN			m_hRgn;
protected:

public:
	Gui_t();
	~Gui_t();
	void OnMouseDown(HWND hWnd, POINT pt);
	void OnMouseUp(HWND hWnd, POINT pt);
	void OnTimer(HWND hWnd);
	void OnDraw(HDC hDC, RECT rcUpdateRect);

	void DestroyRegion();
	void CreateRegion();

	void CreateGui(HINSTANCE hInstance, LPCTSTR lpTemplate, HWND hWndParent, DLGPROC lpDialogFunc);
};



#endif
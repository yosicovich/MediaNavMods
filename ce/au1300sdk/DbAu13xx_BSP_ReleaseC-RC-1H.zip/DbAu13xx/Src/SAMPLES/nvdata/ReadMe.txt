////////////////////////////////////////////////////////////////////////

Sept 21, 2009: Flash driver to allow an application to program the Flash.

FEATURE NAME: Non Volatile Data Driver for Au1x00 platforms

MANUFACTURER: Raza Microelectronics Incorporated Corporation


DESCRIPTION:
This is a Flash driver for Au1x00. This allows applications to program
certain areas of the flash.


BUILD INSTRUCTIONS:
This project is built with Platform Builder. Open your platform
builder, load your workspace and select insert existing project from
Project/Insert tab. Point it to the .pbxml file and click open. The
project should open in your workspace. From there you can build
the project by right click and pressing build current project.

HOW TO USE:
The driver is loaded automatically at bootup if you follow the procedures
above. The Init routine is called during bootup. In your application open
the driver by making the following call:

	filehandle = CreateFile(
			TEXT("DFL1:"),
			GENERIC_READ | GENERIC_WRITE,
			0,
			0,
			OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			0);

Then the ReadFile, WriteFile and SetFilePointer can be used.
In order to actually write the data to flash an IOCTL, nvdata_COMMIT needs to be sent to the driver.
Until then the data that is written is cached in memory.


History:
========

////////////////////////////////////////////////////////////////////////

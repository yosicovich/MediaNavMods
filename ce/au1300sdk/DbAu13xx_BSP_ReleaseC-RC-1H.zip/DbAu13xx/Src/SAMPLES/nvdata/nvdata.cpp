/*****************************************************************************
Copyright 2003-2009 Raza Microelectronics, Inc.(RMI). All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY Raza Microelectronics, Inc. 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
#include <windows.h>
#include <ceddk.h>
#include <devload.h>
#include <ddkreg.h>
#include <nkintr.h>
#include "stdafx.h"
#include <Mmsystem.h>
#include "nvdata.h"

#define MODULE                  L"nvdata: "

//#define DEBUG 1

#ifdef DEBUG
#define ZONE_INIT               1
#define ZONE_INFO               2
#define ZONE_ERROR              3
#define ZONE_FUNCTION           (ZONE_INIT|ZONE_INFO|ZONE_ERROR)
#else
#define ZONE_INIT               0
#define ZONE_INFO               0
#define ZONE_ERROR              1
#define ZONE_FUNCTION           ZONE_ERROR
#endif

/* Defined in YAMON's nvdat.bin file for each particular board */
#define ID_STRING     "Au1x00 NVDAT"
#define ID_STRING_LEN 12
#define NVRAM_BYTES   1024*32
#define NVRAM_START   0xBFC00000
#define NVRAM_END     0xBFD00000
#define SECTOR_SIZE   512

static unsigned char nvram_cache[NVRAM_BYTES];
static unsigned char *nvram = NULL;
DWORD nCurPos = 0;
CRITICAL_SECTION g_CriticalSection;

static DWORD nvram_erase( void );
static DWORD nvram_program( unsigned char *, DWORD );

BOOL APIENTRY DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

void ShowVersion(void)
{
    TCHAR     szTemp[1024];
    wsprintf (szTemp,TEXT("nonVolatile Data Driver(nvdata), v1.0\n"));
    OutputDebugString(szTemp);
}

int DFL_Init(void)
{
    char *ptr;

    ShowVersion();

    /* Look for our signature "Au1x00 NVDAT". This marks the beginning of the writeable area */
    for ( ptr=(char*)NVRAM_START; ptr<(char*)NVRAM_END; ptr++)
    {
        if (!memcmp(ptr, ID_STRING, ID_STRING_LEN))
        {
            RETAILMSG(ZONE_INIT, (MODULE L"Au1x00 NV Data @ %p\n", ptr));
            nvram = (unsigned char*)ptr;
            break;
        }
    }

    if (!nvram)
    {
        RETAILMSG(ZONE_ERROR, (MODULE L"ERROR: Could not find Au1x00 NV data!!\n"));
        RETAILMSG(ZONE_ERROR, (MODULE L"Please make sure the flash is initialized properly!!\n"));
        return(0);
    }

    /* Read initial data */
    for (int i=0; i<NVRAM_BYTES; i++)
    {
        nvram_cache[i] = nvram[i];
    }

    InitializeCriticalSection(&g_CriticalSection);

#if TEST_PROGRAM_HERE
    nvram_cache[0x20] = 0xB0;
    nvram_cache[0x21] = 0x0B;
    nvram_cache[0x22] = 0xFA;
    nvram_cache[0x23] = 0xCE;
    nvram_program(nvram_cache, NVRAM_BYTES);
#endif

    return (1);
}

BOOL DFL_Deinit(PVOID hFMD)
{
    return(TRUE);
}

int DFL_Open(
    HANDLE  pHead,          // @parm Handle returned by VOY_Init.
    DWORD   AccessCode,     // @parm access code.
    DWORD   ShareMode       // @parm share mode - Not used in this driver.
)
{
    return 1;
}

BOOL DFL_Close(HANDLE pHead)
{
    return(TRUE);
}

VOID DFL_PowerDown(VOID)
{
    return;
}

VOID DFL_PowerUp(VOID)
{
    return;
}

DWORD DFL_Seek(
    DWORD hOpenContext,
    long Amount,
    WORD Type
)
{
    switch (Type)
    {
    case FILE_BEGIN:
        /* nothing to do */
        break;
    case FILE_CURRENT:
        Amount += nCurPos;
        break;
    case FILE_END:
        Amount = NVRAM_BYTES - Amount;
        break;
    }

    /* For safety's sake, we don't allow seeking beyond our reserved area */
    if (Amount >= NVRAM_BYTES)
        return -1;

    if (Amount >= 0)
        nCurPos = Amount;

    RETAILMSG(ZONE_INFO, (MODULE L"DFL_Seek: current position 0x%x\n",(char *)&nvram_cache[nCurPos]));

    return (Amount >= 0) ? (nCurPos) : -1;
}

DWORD DFL_Read(
    DWORD hOpenContext,
    LPVOID pBuffer,
    DWORD Count
)
{
    unsigned i=nCurPos,cnt;

    if ( (i >= NVRAM_BYTES) || (i+Count >= NVRAM_BYTES) )
        return 0;

    /* Limit number of bytes per read */
    cnt = SECTOR_SIZE < Count ? SECTOR_SIZE : Count;

    EnterCriticalSection(&g_CriticalSection);
    memcpy(pBuffer, &nvram_cache[i], cnt);
    LeaveCriticalSection(&g_CriticalSection);

    nCurPos += cnt;

    RETAILMSG(ZONE_INFO, (MODULE L"DFL_Read: Bytes read %d current position 0x%x\n",cnt,(char *)&nvram_cache[nCurPos]));
    return cnt;
}

DWORD DFL_Write(
    DWORD hOpenContext,
    LPCVOID pBuffer,
    DWORD Count
)
{
    unsigned i=nCurPos,cnt;

    if ( (i >= NVRAM_BYTES) || (i+Count >= NVRAM_BYTES) )
        return 0;

    cnt = SECTOR_SIZE < Count ? SECTOR_SIZE : Count;

    EnterCriticalSection(&g_CriticalSection);
    memcpy(&nvram_cache[i], pBuffer, cnt);
    LeaveCriticalSection(&g_CriticalSection);

    nCurPos += i;

    RETAILMSG(ZONE_INFO, (MODULE L"DFL_Write: Bytes written %d current position 0x%x\n",cnt,(char *)&nvram_cache[nCurPos]));

    return cnt;
}

BOOL DFL_IOControl( HANDLE pHandle,
                    DWORD dwCode, LPVOID pBufIn,
                    DWORD dwLenIn, LPVOID pBufOut, DWORD dwLenOut,
                    PDWORD pdwActualOut)
{
    RETAILMSG(ZONE_INFO, (MODULE L"##### IOControl - code 0x%x #####\n",dwCode));

    switch (dwCode)
    {
    case NVDATA_COMMIT:
        if ( NVRAM_BYTES != nvram_program(nvram_cache, NVRAM_BYTES))
        {
            return FALSE;
        }
        break;
    }

    return TRUE;
}

static DWORD nvram_erase( void )
{
    volatile short	*flash = (volatile short *)(nvram);
    unsigned long timeout=0x1000; //0xFFFFFF;

    flash[0x555] = 0xaa;
    flash[0x2AA] = 0x55;
    flash[0x555] = 0x80;
    flash[0x555] = 0xaa;
    flash[0x2AA] = 0x55;
    flash[0]  	 = 0x30;

    /* This is a hack -- We know that the first bytes are "Au1x00 NVDAT"
       Wait until this is 0xFFFF to continue
     */
    while ( (--timeout) && (unsigned short)flash[0] != 0xFFFF) Sleep(20); // 20ms

    if (!timeout)
    {
        RETAILMSG(ZONE_ERROR, (MODULE L"Timeout erasing Au1x00 NV Data Flash\n"));
        return(1);
    }
    return(0);
}

static DWORD nvram_program( unsigned char *buf, DWORD count )
{
    unsigned i;
    volatile short	*flash;
    volatile short  *pdst;
    volatile short  *psrc=(short*)buf;

    /*
     * Erase the NV Data sector
     */
    if (nvram_erase())
        return(-1);

    EnterCriticalSection(&g_CriticalSection);

    /* Copy 16bits at a time
     * Src and Dest need to be bus aligned
     */

    // command base address
    flash = (volatile short *)(nvram);
    for (i=0,pdst=(short*)nvram; i<count; i+=2, pdst++,psrc++)
    {
        unsigned long timeout=0xFFFFFF;
        short data;

        /* These are the commands to write a halfword into AMD flash */
        data = *psrc;
        flash[0x555] = 0x00AA;
        flash[0x2AA] = 0x0055;
        flash[0x555] = 0x00A0;
        *pdst = data;

        while (*pdst != data && (--timeout)) ;

        if (!timeout)
        {
            RETAILMSG(ZONE_ERROR, (MODULE L"Timeout programming flash location %p\n", pdst));
            return -1;
        }

    }

    LeaveCriticalSection(&g_CriticalSection);

    return count;
}

Initializing NVDATA under YAMON

Copy nvdat.srec to your TFTP server accessible by YAMON.

At the yamon prompt, do the following:

YAMON> erase bfcf0000 8000
YAMON> load /nvdat.srec



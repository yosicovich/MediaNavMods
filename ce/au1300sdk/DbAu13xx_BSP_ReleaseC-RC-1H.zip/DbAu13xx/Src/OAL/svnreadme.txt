External Module				Module Location within SVN
----------------			--------------------------
OALLIB						WindowsCE\6.0\Au1x\Src\OALLIB


Local Modules				Description
----------------			--------------------------
OALEXE						Contains BSP specific OAL

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include <windows.h>
#include <nkexport.h>
#include "bsp.h"
#include "platform.h"
#include <oal_intr.h>
#include <oal_log.h>
#include <bceddk.h>

unsigned int au1x_ic_controller=0;

#if defined(INTR_AU1X00_IC)

/********************************************************************/
// Enable shared interrupts on those platforms that need it
#if defined(PCI_PHYS_ADDR) || defined(CPU_AU1200)
#define INTERRUPT_SHARING
#else
#undef INTERRUPT_SHARING
#endif

/********************************************************************/

#define INTR_MAX_IRQ_SHARE_COUNT 6

// Used as the quick way to get the Sysintr associated with this bit
// NOTE: This structure must be a power of 2 in size in order for
// NOTE: isr.s to use efficient math on the array of this struct.
// NOTE: Any change in size to this struct must be reflected in isr.s.
typedef struct
{
    ULONG	SysIntr;	// Ths sysintr using this HW intr
    ULONG	Shared;		// Count of the number of Sysintr's sharing the IRQ
} HARDWARE_INTR_TABLE;


// NOTE: This structure must be a power of 2 in size in order for
// NOTE: isr.s to use efficient math on the array of this struct.
// NOTE: Any change in size to this struct must be reflected in isr.s.
typedef struct
{
	ULONG	Ic0Request;	// Offset 0: Bits in ic0_reqXint upon interrupt
	ULONG	Ic1Request;	// Offset 4: Bits in ic1_reqXint upon interrupt
	ULONG	Ic0Mask;	// Offset 8: Mask to apply to IC0 upon interrupt
	ULONG	Ic1Mask;	// Offset C: Mask to apply to IC1 upon interrupt
    ULONG	HwIntr;     // The hardware irq # associated with this sysintr
    ULONG	DdmaRequest;// Offset 14: Bits in ddma_intstat upon interrupt
    ULONG	DdmaMask;	// Offset 18: Mask to apply to DDMA upon interrupt
	ULONG   ExtRequest;	// Offset 1C: Bits in ext IRQ logic upon interrupt
	ULONG   ExtMask;	// Offset 20: Mask to apply to ext IRQ upon interrupt
    USHORT	Shared;     // True if this is a shared device
    USHORT	InUse;      // TRUE is used
	ULONG   Padding[6];	// Bring the structure size up to 64 bytes
} SYSINTR_ALLOC_TABLE;

#ifdef INTERRUPT_SHARING
//
// In order to access this from assembly is s important to keep its
// size on a power of 2, hence the share count == 6, so size = 8
//
typedef struct
{
    UCHAR	Count;		// How many SysIntrs are in the array > 1
    UCHAR	Remaining;	// The next Sysintr to return (0xff = done)
    UCHAR	SysIntr[INTR_MAX_IRQ_SHARE_COUNT];
}SHARED_INTR_TABLE, *PSHARED_INTR_TABLE;
#endif

//
// Storage holder for the interrupt controller register sets across sleep.
//
static struct _IntrState {
    ULONG config0ReadSet;
    ULONG config1ReadSet;
    ULONG config2ReadSet;
    ULONG sourceReadSet;
    ULONG assignRequestReadSet;
    ULONG maskReadSet;
    ULONG wakeupRead;
} IntrStates[2];

/********************************************************************/

//
// interrupt regs
//
AU1X00_IC * const ic0 =
	(AU1X00_IC *)(IC0_PHYS_ADDR + KSEG1_OFFSET);
AU1X00_IC * const ic1 =
	(AU1X00_IC *)(IC1_PHYS_ADDR + KSEG1_OFFSET);

#if defined(DDMA_PHYS_ADDR)
AU1X00_DDMA * const ddma =
	(AU1X00_DDMA *)(DDMA_PHYS_ADDR + KSEG1_OFFSET);
#endif

BCSR * const bcsr = (BCSR*)(BCSR_PHYSADDR + KSEG1_OFFSET);

// imports from timer.c
extern volatile DWORD dwReschedIncrement;
extern volatile DWORD dwPerfTimerAtTick;
extern volatile UINT64 CurTicks;

// imports from util.S
extern ULONG getMSB(ULONG);

/*

The IntrPriority table is used by the CE kernel to determine which interrupt
to service. When an interrupt exception occurs, the CE kernel uses the 6-bit
field from Cause[15:10] as an index into this 64-entry array. The array then
returns the interrupt vector of 0..5 to call out.

The IntrMask table is used to mask out lower priority interrupts. Thus these
two tables work hand-in-hand to enforce the priority scheme.

*/
unsigned char IntrPriority[]=
{
	-4, 		// 0000 00 spurious
	0*4,		// 0000 01 Cause[10] 0
	1*4,		// 0000 10 Cause[11] 1
	0*4,		// 0000 11 Cause[10] 0
	2*4,		// 0001 00 Cause[12] 2
	0*4,		// 0001 01 Cause[10] 0
	1*4,		// 0001 10 Cause[11] 1
	0*4,		// 0001 11 Cause[10] 0
	3*4,		// 0010 00 Cause[13] 3
	0*4,		// 0010 01 Cause[10] 0
	1*4,		// 0010 10 Cause[11] 1
	0*4,		// 0010 11 Cause[10] 0
	2*4,		// 0011 00 Cause[12] 2
	0*4,		// 0011 01 Cause[10] 0
	1*4,		// 0011 10 Cause[11] 1
	0*4,		// 0011 11 Cause[10] 0
	4*4,		// 0100 00 Cause[14] 4
	0*4,		// 0100 01 Cause[10] 0
	1*4,		// 0100 10 Cause[11] 1
	0*4,		// 0100 11 Cause[10] 0
	2*4,		// 0101 00 Cause[12] 2
	0*4,		// 0101 01 Cause[10] 0
	1*4,		// 0101 10 Cause[11] 1
	0*4,		// 0101 11 Cause[10] 0
	3*4,		// 0110 00 Cause[13] 3
	0*4,		// 0110 01 Cause[10] 0
	1*4,		// 0110 10 Cause[11] 1
	0*4,		// 0110 11 Cause[10] 0
	2*4,		// 0111 00 Cause[12] 2
	0*4,		// 0111 01 Cause[10] 0
	1*4,		// 0111 10 Cause[11] 1
	0*4,		// 0111 11 Cause[10] 0
	5*4, 		// 1000 00 Cause[15] 5
	5*4,		// 1000 01 Cause[15] 5
	5*4,		// 1000 10 Cause[15] 5
	5*4,		// 1000 11 Cause[15] 5
	5*4,		// 1001 00 Cause[15] 5
	5*4,		// 1001 01 Cause[15] 5
	5*4,		// 1001 10 Cause[15] 5
	5*4,		// 1001 11 Cause[15] 5
	5*4,		// 1010 00 Cause[15] 5
	5*4,		// 1010 01 Cause[15] 5
	5*4,		// 1010 10 Cause[15] 5
	5*4,		// 1010 11 Cause[15] 5
	5*4,		// 1011 00 Cause[15] 5
	5*4,		// 1011 01 Cause[15] 5
	5*4,		// 1011 10 Cause[15] 5
	5*4,		// 1011 11 Cause[15] 5
	5*4,		// 1100 00 Cause[15] 5
	5*4,		// 1100 01 Cause[15] 5
	5*4,		// 1100 10 Cause[15] 5
	5*4,		// 1100 11 Cause[15] 5
	5*4,		// 1101 00 Cause[15] 5
	5*4,		// 1101 01 Cause[15] 5
	5*4,		// 1101 10 Cause[15] 5
	5*4,		// 1101 11 Cause[15] 5
	5*4,		// 1110 00 Cause[15] 5
	5*4,		// 1110 01 Cause[15] 5
	5*4,		// 1110 10 Cause[15] 5
	5*4,		// 1110 11 Cause[15] 5
	5*4,		// 1111 00 Cause[15] 5
	5*4,		// 1111 01 Cause[15] 5
	5*4,		// 1111 10 Cause[15] 5
	5*4			// 1111 11 Cause[15] 5
};

// CE kernel inverts mask before applying
unsigned char IntrMask[]=
{
	0x00,	// 0000 00 spurious interrupt
	0x1F,	// 0000 01 Status[14:10] masked, Status[15] enabled
	0x1E,	// 0000 10 Status[14:11] masked, Status[15,10] enabled
	0x1C,	// 0001 00 Status[14:12] masked, Status[15,11:10] enabled
	0x18,	// 0010 00 Status[14:13] masked, Status[15,12:10] enabled
	0x10,	// 0100 00 Status[14:14] masked, Status[15,13:10] enabled
	0x3F,	// 1000 00 Status[15:10] masked, none enabled
	0x00	// padding
};

volatile unsigned long TickCount = 0;
volatile unsigned long IRQCount = 0;
volatile unsigned long RTCTickCount = 0;


//
// The interrupt allocation is tracked using 2 tables
// One table is in HARDWARE interrupt order. This allows fast lookup of sysintr
// Next is in SysIntr order and holds the main information to handle the interrupt
//
// This table takes the SysIntr as the array index
// NOTE: This table must be visible to isr.s.
SYSINTR_ALLOC_TABLE LocalSysIntrMap[SYSINTR_MAXIMUM+1];

//
// this table takes the hardware interrupt as the array index
// It is used here and externally in isr.s
// Why +1? The last hardware interrupt is numbered HWINTR_MAXIMUM,
// the first is 0.
//
HARDWARE_INTR_TABLE HwIntrMap[HWINTR_MAXIMUM+1];
#ifdef INTERRUPT_SHARING
static SHARED_INTR_TABLE   SharedIntrMap[HWINTR_MAXIMUM+1];
#endif

// Configuration of interrupt sources pre-defined
static INTR_MODE InterruptConfiguration[HWINTR_MAXIMUM] =
{
#define irqNA 0	| INTR_MODE_NOIDLE_WAKEUP
#define irqLL INTR_MODE_NEGATIVE_LOGIC | INTR_MODE_LEVEL
#define irqHL INTR_MODE_POSITIVE_LOGIC | INTR_MODE_LEVEL
#define irqFE INTR_MODE_NEGATIVE_LOGIC | INTR_MODE_EDGE
#define irqRE INTR_MODE_POSITIVE_LOGIC | INTR_MODE_EDGE

#ifdef USE_CP0_TIMER
#define irqTK irqRE // normal
#define irqWK irqRE // normal
#else
#define irqTK irqRE | INTR_MODE_HIGH_PRIORITY | INTR_MODE_NOIDLE_WAKEUP | INTR_MODE_UNMASK
#define irqWK irqRE | INTR_MODE_HIGH_PRIORITY
#define irqZK irqRE | INTR_MODE_HIGH_PRIORITY | INTR_MODE_UNMASK
#endif

	// NOTE: Shared interrupts should use INTR_MODE_UNMASK

	/*
	 * IC0 is fixed, integrated peripherals
	 */
#if defined(CPU_AU1000)
	irqHL, //  0 UART0
	irqHL, //  1 UART1
	irqHL, //  2 UART2
	irqHL, //  3 UART3
	irqHL, //  4 SSI0
	irqHL, //  5 SSI1
	irqHL, //  6 DMA0
	irqHL, //  7 DMA1
	irqHL, //  8 DMA2
	irqHL, //  9 DMA3
	irqHL, // 10 DMA4
	irqHL, // 11 DMA5
	irqHL, // 12 DMA6
	irqHL, // 13 DMA7
	irqRE, // 14 TOY tick
	irqRE, // 15 TOY Match 0
	irqRE, // 16 TOY Match 1
	irqRE, // 17 TOY Match 2
	irqTK, // 18 RTC tick
	irqWK, // 19 RTC Match 0
	irqRE, // 20 RTC Match 1
	irqRE, // 21 RTC Match 2
	irqHL, // 22 IrDA TX
	irqHL, // 23 IrDA RX
	irqHL, // 24 USBD
	irqRE, // 25 USBD Suspend
	irqLL, // 26 USBH
	irqRE, // 27 AC97 ACSYNC
	irqHL, // 28 MAC0
	irqHL, // 29 MAC1
	irqNA, // 30 Reserved
	irqRE, // 31 AC97 Command

#elif defined(CPU_AU1500)
	irqHL, //  0 UART0
	irqLL | INTR_MODE_UNMASK, //  1 PCI INTA#
	irqLL | INTR_MODE_UNMASK, //  2 PCI INTB#
	irqHL, //  3 UART3
	irqLL | INTR_MODE_UNMASK, //  4 PCI INTC#
	irqLL | INTR_MODE_UNMASK, //  5 PCI INTD#
	irqHL, //  6 DMA0
	irqHL, //  7 DMA1
	irqHL, //  8 DMA2
	irqHL, //  9 DMA3
	irqHL, // 10 DMA4
	irqHL, // 11 DMA5
	irqHL, // 12 DMA6
	irqHL, // 13 DMA7
	irqRE, // 14 TOY tick
	irqRE, // 15 TOY Match 0
	irqRE, // 16 TOY Match 1
	irqRE, // 17 TOY Match 2
	irqTK, // 18 RTC tick
	irqWK, // 19 RTC Match 0
	irqRE, // 20 RTC Match 1
	irqRE, // 21 RTC Match 2
	irqHL, // 22 PCI Error
	irqNA, // 23 Reserved
	irqHL, // 24 USBD
	irqRE, // 25 USBD Suspend
	irqLL, // 26 USBH
	irqRE, // 27 AC97 ACSYNC
	irqHL, // 28 MAC0
	irqHL, // 29 MAC1
	irqNA, // 30 Reserved
	irqRE, // 31 AC97 Command

#elif defined(CPU_AU1100)
	irqHL, //  0 UART0
	irqHL, //  1 UART1
	irqHL, //  2 SD0 or SD1
	irqHL, //  3 UART3
	irqHL, //  4 SSI0
	irqHL, //  5 SSI1
	irqHL, //  6 DMA0
	irqHL, //  7 DMA1
	irqHL, //  8 DMA2
	irqHL, //  9 DMA3
	irqHL, // 10 DMA4
	irqHL, // 11 DMA5
	irqHL, // 12 DMA6
	irqHL, // 13 DMA7
	irqRE, // 14 TOY tick
	irqRE, // 15 TOY Match 0
	irqRE, // 16 TOY Match 1
	irqRE, // 17 TOY Match 2
	irqTK, // 18 RTC tick
	irqWK, // 19 RTC Match 0
	irqRE, // 20 RTC Match 1
	irqRE, // 21 RTC Match 2
	irqHL, // 22 IrDA TX
	irqHL, // 23 IrDA RX
	irqHL, // 24 USBD
	irqRE, // 25 USBD Suspend
	irqLL, // 26 USBH
	irqRE, // 27 AC97 ACSYNC
	irqHL, // 28 MAC0
	irqHL, // 29 GPIO2xx
	irqHL, // 30 LCD
	irqRE, // 31 AC97 Command

#elif defined(CPU_AU1550)
	irqHL, //  0 UART0
	irqLL | INTR_MODE_UNMASK, //  1 PCI INTA#
	irqLL | INTR_MODE_UNMASK, //  2 PCI INTB#
	irqHL | INTR_MODE_UNMASK, //  3 DDMA
	irqHL, //  4 Crypto
	irqLL | INTR_MODE_UNMASK, //  5 PCI INTC#
	irqLL | INTR_MODE_UNMASK, //  6 PCI INTD#
	irqLL, //  7 PCI Reset
	irqHL, //  8 UART1
	irqHL, //  9 UART3
	irqHL, // 10 PSC0
	irqHL, // 11 PSC1
	irqHL, // 12 PSC2
	irqHL, // 13 PSC3
	irqRE, // 14 TOY tick
	irqRE, // 15 TOY Match 0
	irqRE, // 16 TOY Match 1
	irqRE, // 17 TOY Match 2
	irqTK, // 18 RTC tick
	irqWK, // 19 RTC Match 0
	irqRE, // 20 RTC Match 1
	irqRE, // 21 RTC Match 2
	irqHL, // 22 PCI Error
	irqRE, // 23 NAND
	irqHL, // 24 USBD
	irqRE, // 25 USBD Suspend
	irqLL, // 26 USBH
	irqHL, // 27 MAC0
	irqHL, // 28 MAC1
	irqNA, // 29 Reserved
	irqNA, // 30 Reserved
	irqNA, // 31 Reserved

#elif defined(CPU_AU1200)
	irqHL, //  0 UART0
	irqHL, //  1 SWC
	irqHL, //  2 SD0,1
	irqHL | INTR_MODE_UNMASK, //  3 DDMA
	irqHL, //  4 MAE BE
#ifndef PLATFORM_INTR_IC0_05
#define PLATFORM_INTR_IC0_05 irqNA
#endif
	PLATFORM_INTR_IC0_05,
#ifndef PLATFORM_INTR_IC0_06
#define PLATFORM_INTR_IC0_06 irqNA
#endif
	PLATFORM_INTR_IC0_06,
#ifndef PLATFORM_INTR_IC0_07
#define PLATFORM_INTR_IC0_07 irqNA
#endif
	PLATFORM_INTR_IC0_07,
	irqHL, //  8 UART1
	irqHL, //  9 MAE FE
	irqHL, // 10 PSC0
	irqHL, // 11 PSC1
	irqHL, // 12 AES
	irqHL, // 13 CIM
	irqRE, // 14 TOY tick
	irqRE, // 15 TOY Match 0
	irqRE, // 16 TOY Match 1
	irqRE, // 17 TOY Match 2
	irqTK, // 18 RTC tick
	irqZK, // 19 RTC Match 0

	irqRE, // 20 RTC Match 1
	irqRE, // 21 RTC Match 2
#ifndef PLATFORM_INTR_IC0_22
#define PLATFORM_INTR_IC0_22 irqNA
#endif
	PLATFORM_INTR_IC0_22,
	irqRE, // 23 NAND
#ifndef PLATFORM_INTR_IC0_24
#define PLATFORM_INTR_IC0_24 irqNA
#endif
	PLATFORM_INTR_IC0_24,
#ifndef PLATFORM_INTR_IC0_25
#define PLATFORM_INTR_IC0_25 irqNA
#endif
	PLATFORM_INTR_IC0_25,
#ifndef PLATFORM_INTR_IC0_26
#define PLATFORM_INTR_IC0_26 irqNA
#endif
	PLATFORM_INTR_IC0_26,
#ifndef PLATFORM_INTR_IC0_27
#define PLATFORM_INTR_IC0_27 irqNA
#endif
	PLATFORM_INTR_IC0_27,
#ifndef PLATFORM_INTR_IC0_28
#define PLATFORM_INTR_IC0_28 irqNA
#endif
	PLATFORM_INTR_IC0_28,
	irqHL | INTR_MODE_UNMASK, // 29 USB (shared among ehcd, ohcd, otg, udc)
	irqHL, // 30 LCD
	irqHL, // 31 MAE DONE

#else
#error "Error: Unknown Au1x00 SOC"
#endif

	/*
	 * IC1 is platform-specific
	 */

#ifndef PLATFORM_INTR_IC1_00
#define PLATFORM_INTR_IC1_00 irqNA
#endif
		PLATFORM_INTR_IC1_00,

#ifndef PLATFORM_INTR_IC1_01
#define PLATFORM_INTR_IC1_01 irqNA
#endif
		PLATFORM_INTR_IC1_01,

#ifndef PLATFORM_INTR_IC1_02
#define PLATFORM_INTR_IC1_02 irqNA
#endif
		PLATFORM_INTR_IC1_02,

#ifndef PLATFORM_INTR_IC1_03
#define PLATFORM_INTR_IC1_03 irqNA
#endif
		PLATFORM_INTR_IC1_03,

#ifndef PLATFORM_INTR_IC1_04
#define PLATFORM_INTR_IC1_04 irqNA
#endif
		PLATFORM_INTR_IC1_04,

#ifndef PLATFORM_INTR_IC1_05
#define PLATFORM_INTR_IC1_05 irqNA
#endif
		PLATFORM_INTR_IC1_05,

#ifndef PLATFORM_INTR_IC1_06
#define PLATFORM_INTR_IC1_06 irqNA
#endif
		PLATFORM_INTR_IC1_06,

#ifndef PLATFORM_INTR_IC1_07
#define PLATFORM_INTR_IC1_07 irqNA
#endif
		PLATFORM_INTR_IC1_07,

#ifndef PLATFORM_INTR_IC1_08
#define PLATFORM_INTR_IC1_08 irqNA
#endif
		PLATFORM_INTR_IC1_08,

#ifndef PLATFORM_INTR_IC1_09
#define PLATFORM_INTR_IC1_09 irqNA
#endif
		PLATFORM_INTR_IC1_09,

#ifndef PLATFORM_INTR_IC1_10
#define PLATFORM_INTR_IC1_10 irqNA
#endif
		PLATFORM_INTR_IC1_10,

#ifndef PLATFORM_INTR_IC1_11
#define PLATFORM_INTR_IC1_11 irqNA
#endif
		PLATFORM_INTR_IC1_11,

#ifndef PLATFORM_INTR_IC1_12
#define PLATFORM_INTR_IC1_12 irqNA
#endif
		PLATFORM_INTR_IC1_12,

#ifndef PLATFORM_INTR_IC1_13
#define PLATFORM_INTR_IC1_13 irqNA
#endif
		PLATFORM_INTR_IC1_13,

#ifndef PLATFORM_INTR_IC1_14
#define PLATFORM_INTR_IC1_14 irqNA
#endif
		PLATFORM_INTR_IC1_14,

#ifndef PLATFORM_INTR_IC1_15
#define PLATFORM_INTR_IC1_15 irqNA
#endif
		PLATFORM_INTR_IC1_15,

#ifndef PLATFORM_INTR_IC1_16
#define PLATFORM_INTR_IC1_16 irqNA
#endif
		PLATFORM_INTR_IC1_16,

#ifndef PLATFORM_INTR_IC1_17
#define PLATFORM_INTR_IC1_17 irqNA
#endif
		PLATFORM_INTR_IC1_17,

#ifndef PLATFORM_INTR_IC1_18
#define PLATFORM_INTR_IC1_18 irqNA
#endif
		PLATFORM_INTR_IC1_18,

#ifndef PLATFORM_INTR_IC1_19
#define PLATFORM_INTR_IC1_19 irqNA
#endif
		PLATFORM_INTR_IC1_19,

#ifndef PLATFORM_INTR_IC1_20
#define PLATFORM_INTR_IC1_20 irqNA
#endif
		PLATFORM_INTR_IC1_20,

#ifndef PLATFORM_INTR_IC1_21
#define PLATFORM_INTR_IC1_21 irqNA
#endif
		PLATFORM_INTR_IC1_21,

#ifndef PLATFORM_INTR_IC1_22
#define PLATFORM_INTR_IC1_22 irqNA
#endif
		PLATFORM_INTR_IC1_22,

#ifndef PLATFORM_INTR_IC1_23
#define PLATFORM_INTR_IC1_23 irqNA
#endif
		PLATFORM_INTR_IC1_23,

#ifndef PLATFORM_INTR_IC1_24
#define PLATFORM_INTR_IC1_24 irqNA
#endif
		PLATFORM_INTR_IC1_24,

#ifndef PLATFORM_INTR_IC1_25
#define PLATFORM_INTR_IC1_25 irqNA
#endif
		PLATFORM_INTR_IC1_25,

#ifndef PLATFORM_INTR_IC1_26
#define PLATFORM_INTR_IC1_26 irqNA
#endif
		PLATFORM_INTR_IC1_26,

#ifndef PLATFORM_INTR_IC1_27
#define PLATFORM_INTR_IC1_27 irqNA
#endif
		PLATFORM_INTR_IC1_27,

#ifndef PLATFORM_INTR_IC1_28
#define PLATFORM_INTR_IC1_28 irqNA
#endif
		PLATFORM_INTR_IC1_28,

#ifndef PLATFORM_INTR_IC1_29
#define PLATFORM_INTR_IC1_29 irqNA
#endif
		PLATFORM_INTR_IC1_29,

#ifndef PLATFORM_INTR_IC1_30
#define PLATFORM_INTR_IC1_30 irqNA
#endif
		PLATFORM_INTR_IC1_30,

#ifndef PLATFORM_INTR_IC1_31
#define PLATFORM_INTR_IC1_31 irqNA
#endif
		PLATFORM_INTR_IC1_31,
};

/********************************************************************/

static ULONG
GetFreeSysIntr (VOID)
{
	ULONG SysIntr = SYSINTR_NOP;
	int index;

	for (index = SYSINTR_FIRMWARE; index <= SYSINTR_MAXIMUM; index++)
	{
		if (!LocalSysIntrMap[index].InUse)
		{
			SysIntr = index;
			break;
		}
	}

	return SysIntr;
}

/********************************************************************/

static void
configInterrupt (int HwIntr, INTR_MODE IntrMode)
{
	AU1X00_IC * ic;
	ULONG bit;

	if ((HwIntr >= HWINTR_IC0_BASE) && (HwIntr <= HWINTR_IC0_MAX))
	{
		bit = (1 << HwIntr);
		ic = (AU1X00_IC *)ic0;
	}
	else

	if ((HwIntr >= HWINTR_IC1_BASE) && (HwIntr <= HWINTR_IC1_MAX))
	{
		bit = (1 << (HwIntr - HWINTR_IC1_BASE));
		ic = (AU1X00_IC *)ic1;
		/*
		 * IC1 GPIO interrupts require the GPIO be configured as an
		 * input. Configuring GPIOs as inputs is specifically not done
		 * here, and instead is relegated to the reset_X.s file. If
		 * interrupts from GPIOs do not occur, then likely the GPIO
		 * has not been properly configured as an input, or the
		 * appropriate INTR_IC0 macro is mis-configured in the platform
		 * header file.
		 */
	}
	else
		return; /* FIX!!! Should print error message */

	if (IntrMode & INTR_MODE_POSITIVE_LOGIC)
		ic->cfg0set = bit;
	else
		ic->cfg0clr = bit;

	if (IntrMode & INTR_MODE_NEGATIVE_LOGIC)
		ic->cfg1set = bit;
	else
		ic->cfg1clr = bit;

	if (IntrMode & INTR_MODE_EDGE)
		ic->cfg2clr = bit;
	else
		ic->cfg2set = bit;

	if (IntrMode & INTR_MODE_HIGH_PRIORITY)
		ic->assignset = bit;
	else
		ic->assignclr = bit;

	// Clear any false interrupts
	ic->risingclr = bit;
	ic->fallingclr = bit;

	if (IntrMode & INTR_MODE_UNMASK) {
		ic->maskset = bit;
		// Add wake flag if set
		if (IntrMode & INTR_MODE_NOIDLE_WAKEUP)
			ic->wakeclr = bit;
		else
			ic->wakeset = bit;
	}
	else
		ic->maskclr = bit;
}

/********************************************************************/
ULONG Cp0CountHandler( VOID )
{
	ULONG	cmp;

	 cmp = Cp0RdCompare();
	 Cp0WrCompare(cmp); // ack interrupt

	return SYSINTR_NOP;
}

ULONG OEMInterruptHandler( ULONG HwIntr )
{
	ULONG SysIntr = SYSINTR_NOP;
	ULONG i0,i1; // ic0, ic1 combo
	ULONG i0r0, i0r1, i1r0, i1r1; // ic0r0, ic0r1, ic1r0, ic1r1
	// These are '0' in case we dont' have DDMA/ExtIrqs
	ULONG d0=0;  // DDMA intstat
	ULONG e0=0;  // external/board intstat

	// take snapshot of registers
	i0r0 = ic0->req0int; i0r1 = ic0->req1int;
	i1r0 = ic1->req0int; i1r1 = ic1->req1int;

	// combine interrupt req lines into single 32bit word
	i0 = i0r0 | i0r1;
	i1 = i1r0 | i1r1;

	if ( HwIntr <= HWINTR_IC0_BASE || HwIntr >= HWINTR_IC1_MAX )
		goto spurious_interrupt;

#if defined(DDMA_PHYS_ADDR)
	if ( HWINTR_DDMA == HwIntr )
	{
		ULONG channel;

		d0 = ddma->intstat;
		// We need channel number in order to clear interrupt
		channel = getMSB(d0);
		ddma->channel[channel].irq = 0;

		// Channel + DDMA_BASE is our hw interrupt
		HwIntr = channel+HWINTR_DDMA_BASE;

	}
#endif

#if defined(HWINTR_EXT_BASE_HOOK)
	HWINTR_EXT_BASE_HOOK_CODE
#endif

	SysIntr = HwIntrMap[HwIntr].SysIntr;
	LocalSysIntrMap[SysIntr].Ic0Request  = i0;
	LocalSysIntrMap[SysIntr].Ic1Request  = i1;
	LocalSysIntrMap[SysIntr].DdmaRequest = d0;
	LocalSysIntrMap[SysIntr].ExtRequest  = e0;

	// mask and ack all interrupts corresponding to this group
	ic0->maskclr 	= LocalSysIntrMap[SysIntr].Ic0Mask;
	ic0->fallingclr = LocalSysIntrMap[SysIntr].Ic0Mask;
	ic0->risingclr 	= LocalSysIntrMap[SysIntr].Ic0Mask;
	WBSYNC();
	ic1->maskclr 	= LocalSysIntrMap[SysIntr].Ic1Mask;
	ic1->fallingclr = LocalSysIntrMap[SysIntr].Ic1Mask;
	ic1->risingclr 	= LocalSysIntrMap[SysIntr].Ic1Mask;
	WBSYNC();

	ddma->inten &= ~LocalSysIntrMap[SysIntr].DdmaMask;

/*
	 *	Is this a timer tick?
	 */
	if ( HWINTR_RTCTICK == HwIntr )
	{
		dwPerfTimerAtTick = Cp0RdCount();

		// Unmask Interrupt, CE kernel expects it so...
		ic0->maskset 	= 1<<HWINTR_RTCTICK;
		ic0->risingclr 	= 1<<HWINTR_RTCTICK;
		WBSYNC();

		/* The RTCTICK occurs every 32 ticks of a 32768Hz clock. This provides a
		   clock that is ~976.5us, 23.5us fast. If left
		   unaccounted, then every 42.666 RTCTICK interrupts the system
		   erroneously advances an extra millisecond; let's not let that happen
		   NOTE: RTCTickCount is a local variable used to track tick counts,
		   it is NOT part of the CE timer system.
		*/
		if(++RTCTickCount == 43)
			RTCTickCount=0;
		else
		{
			CurMSec++;
			CurTicks += (UINT64) dwReschedIncrement;
#ifdef PLATFORM_ISR_TICK_DEBUG_CODE
	PLATFORM_ISR_TICK_DEBUG_CODE
#endif
			SysIntr = SYSINTR_RESCHED;
		}
	}
	else
	{
		++IRQCount;
#ifdef PLATFORM_ISR_DEBUG_CODE
		PLATFORM_ISR_DEBUG_CODE
#endif
		SysIntr = NKCallIntChain((BYTE)HwIntr);

		/*
		 *	If this is chained interrupt then return sysintr back
		 */
	    if (SYSINTR_CHAIN == SysIntr)
			SysIntr = HwIntrMap[HwIntr].SysIntr;
	}

spurious_interrupt:

	return SysIntr;
}

static ULONG Ic0Req0Handler( VOID )
{
	return OEMInterruptHandler(getMSB(ic0->req0int)+HWINTR_IC0_BASE);
}
static ULONG Ic0Req1Handler( VOID )
{
	return 	OEMInterruptHandler(getMSB(ic0->req1int)+HWINTR_IC0_BASE);
}
static ULONG Ic1Req0Handler( VOID )
{
	return 	OEMInterruptHandler(getMSB(ic1->req0int)+HWINTR_IC1_BASE);
}
static ULONG Ic1Req1Handler( VOID )
{
	return 	OEMInterruptHandler(getMSB(ic1->req1int)+HWINTR_IC1_BASE);
}

/********************************************************************/
/*
 * This function is called by the OEMInit to bring up the Interrupt system.
 */
VOID
OEMInterruptInit(VOID)
{
    UINT i;
    BOOL Status = TRUE;

    OEMWriteDebugString(L"+OEMInterruptInit\r\n");

    // Initialize the tables
    memset((char*)LocalSysIntrMap, 0, sizeof(LocalSysIntrMap));
    for (i = 0; i <= HWINTR_MAXIMUM; i++)
    {
		HwIntrMap[i].SysIntr = SYSINTR_NOP;
		HwIntrMap[i].Shared = 0;
#ifdef INTERRUPT_SHARING
		SharedIntrMap[i].Count = 0;
#endif
    }

	// Reserve required kernel interrupts
#define RESERVE_INTR(sysintr,hwintr) \
	HwIntrMap[hwintr].SysIntr = sysintr; \
	LocalSysIntrMap[sysintr].HwIntr = hwintr; \
	LocalSysIntrMap[sysintr].Ic0Mask = (1<<hwintr); \
	LocalSysIntrMap[sysintr].InUse = TRUE;

	RESERVE_INTR(SYSINTR_RESCHED, HWINTR_RTCTICK);
	RESERVE_INTR(SYSINTR_IDLEWAKEUP, HWINTR_RTCMATCH0);
	RESERVE_INTR(SYSINTR_RTC_ALARM, HWINTR_TOYMATCH2);
	RESERVE_INTR(SYSINTR_TIMING, HWINTR_RTCTICK);
	//RESERVE_INTR(SYSINTR_PROFILE, HWINTR_???);
#undef RESERVE_INTR

	// Install low-level interrupt service routines. See file
	// isr.s for description of interrupt handling scheme.
    if (!HookInterrupt(0, (PVOID)Ic0Req0Handler)) goto ErrorReturn;
    if (!HookInterrupt(1, (PVOID)Ic0Req1Handler)) goto ErrorReturn;
    if (!HookInterrupt(2, (PVOID)Ic1Req0Handler)) goto ErrorReturn;
    if (!HookInterrupt(3, (PVOID)Ic1Req1Handler)) goto ErrorReturn;
    if (!HookInterrupt(5, (PVOID)Cp0CountHandler)) goto ErrorReturn;
    // Halt system if interrupts do not map
ErrorReturn:
    if (!Status) {
        OEMWriteDebugString(L"FATALERROR!! Cannot hook interrupts. Halting.\r\n");
        goto ErrorReturn;
    }

	/*
	 * Initialize interrupt controllers to a safe state
	 */
    ic0->cfg0clr =    ~0;
    ic0->cfg1clr =    ~0;
    ic0->cfg2clr =    ~0;
    ic0->maskclr =    ~0;
    ic0->assignset =  ~0;
    ic0->wakeclr =    ~0;
    ic0->srcset =     ~0;
    ic0->fallingclr = ~0;
    ic0->risingclr =  ~0;
    ic0->testbit =     0;

    ic1->cfg0clr =    ~0;
    ic1->cfg1clr =    ~0;
    ic1->cfg2clr =    ~0;
    ic1->maskclr =    ~0;
    ic1->assignset =  ~0;
    ic1->wakeclr =    ~0;
    ic1->srcset =     ~0;
    ic1->fallingclr = ~0;
    ic1->risingclr =  ~0;
    ic1->testbit =     0;

	/*
	 * Now intialize all interrupts to correct configuration
	 */
	for (i = 0; i < HWINTR_MAXIMUM; ++i)
		configInterrupt(i, InterruptConfiguration[i]);

#if 0
	RETAILMSG(1,(TEXT("    maskrd        (0x%x) = 0x%x\r\n"), &ic0->maskrd, ic0->maskrd));
	RETAILMSG(1,(TEXT("    cfg0          (0x%x) = 0x%x\r\n"), &ic0->cfg0rd, ic0->cfg0rd));
	RETAILMSG(1,(TEXT("    cfg1          (0x%x) = 0x%x\r\n"), &ic0->cfg1rd, ic0->cfg1rd));
	RETAILMSG(1,(TEXT("    cfg2          (0x%x) = 0x%x\r\n"), &ic0->cfg2rd, ic0->cfg2rd));
	RETAILMSG(1,(TEXT("    srcrd         (0x%x) = 0x%x\r\n"), &ic0->srcrd, ic0->srcrd));
	RETAILMSG(1,(TEXT("    assign        (0x%x) = 0x%x\r\n"), &ic0->assignrd, ic0->assignrd));
	RETAILMSG(1,(TEXT("    wakerd        (0x%x) = 0x%x\r\n"), &ic0->wakerd, ic0->wakerd));
	RETAILMSG(1,(TEXT("    req0          (0x%x) = 0x%x\r\n"), &ic0->req0int, ic0->req0int));
	RETAILMSG(1,(TEXT("    req1          (0x%x) = 0x%x\r\n"), &ic0->req1int, ic0->req1int));

	RETAILMSG(1,(TEXT("    maskrd        (0x%x) = 0x%x\r\n"), &ic1->maskrd, ic1->maskrd));
	RETAILMSG(1,(TEXT("    cfg0          (0x%x) = 0x%x\r\n"), &ic1->cfg0rd, ic1->cfg0rd));
	RETAILMSG(1,(TEXT("    cfg1          (0x%x) = 0x%x\r\n"), &ic1->cfg1rd, ic1->cfg1rd));
	RETAILMSG(1,(TEXT("    cfg2          (0x%x) = 0x%x\r\n"), &ic1->cfg2rd, ic1->cfg2rd));
	RETAILMSG(1,(TEXT("    srcrd         (0x%x) = 0x%x\r\n"), &ic1->srcrd, ic1->srcrd));
	RETAILMSG(1,(TEXT("    assign        (0x%x) = 0x%x\r\n"), &ic1->assignrd, ic1->assignrd));
	RETAILMSG(1,(TEXT("    wakerd        (0x%x) = 0x%x\r\n"), &ic1->wakerd, ic1->wakerd));
	RETAILMSG(1,(TEXT("    req0          (0x%x) = 0x%x\r\n"), &ic1->req0int, ic1->req0int));
	RETAILMSG(1,(TEXT("    req1          (0x%x) = 0x%x\r\n"), &ic1->req1int, ic1->req1int));
#endif

	/*
	 * Disable DDMA channel interrupts
	 */
#if defined(DDMA_PHYS_ADDR)
	ddma->inten = 0;
#endif

	/*
	 * Now initialize any external interrupt controllers
	 */
#ifdef PLATFORM_INTR_EXTERNAL_INIT_CODE
	PLATFORM_INTR_EXTERNAL_INIT_CODE
#endif

    OEMWriteDebugString(L"-OEMInterruptInit\r\n");


}

/********************************************************************/

//
// Windows CE required linkages. See on-line help for details.
//

BOOL
OEMInterruptEnable(
      IN DWORD SysIntr,
      IN LPVOID Data,
      IN DWORD DataLength
      )
{
	DWORD HwIntr;
	AU1X00_IC * ic=NULL;
	ULONG bit;

	/*
	 * This function is called by the kernel when a device driver calls
	 * InterruptInitialize.  This function is called with interrupts on.
	 * This routine only handles the Au1x00 side of the setup.
	 * All interrupt sources have already been configured, just enable it
	 */
	if (SysIntr <= SYSINTR_MAXIMUM)
	{
		// Handle any external controllers
#ifdef PLATFORM_INTR_EXTERNAL_ENABLE_CODE
		PLATFORM_INTR_EXTERNAL_ENABLE_CODE
#endif

#if defined(DDMA_PHYS_ADDR)
		if (LocalSysIntrMap[SysIntr].DdmaMask != 0)
		{
		    ULONG IntrState, Mask;

		    IntrState = DISABLE_INTERRUPTS();
			Mask = ddma->inten;
			Mask |= LocalSysIntrMap[SysIntr].DdmaMask;
			ddma->inten = Mask;
		    RESTORE_INTERRUPTS(IntrState);
		}
#endif
  		ic0->maskset = LocalSysIntrMap[SysIntr].Ic0Mask;
  		ic1->maskset = LocalSysIntrMap[SysIntr].Ic1Mask;

		// Configure the wake registers properly
		HwIntr = LocalSysIntrMap[SysIntr].HwIntr;
		if ((HwIntr >= HWINTR_IC0_BASE) && (HwIntr <= HWINTR_IC0_MAX))
		{
			bit = (1 << HwIntr);
			ic = (AU1X00_IC *)ic0;
		}
		else if ((HwIntr >= HWINTR_IC1_BASE) && (HwIntr <= HWINTR_IC1_MAX))
		{
			bit = (1 << (HwIntr - HWINTR_IC1_BASE));
			ic = (AU1X00_IC *)ic1;
		}
		if ( NULL != ic )
			ic->wakeset = bit;
    }
	return TRUE;
}


// BUGBUG: For now, need to ref-count
//------------------------------------------------------------------------------
//
//  Function:  OEMInterruptMask (DWORD sysIntr, BOOL fDisable)
//
//  This function disables the IRQ given its corresponding SysIntr value.
//
//
VOID OEMInterruptMask (DWORD sysIntr, BOOL fDisable)
{
    if (fDisable) {
        OEMInterruptDisable (sysIntr);
    } else {
        OEMInterruptEnable (sysIntr, NULL, 0);
    }
}


/********************************************************************/

VOID
OEMInterruptDisable(IN DWORD SysIntr)
{
	DWORD HwIntr;
	AU1X00_IC * ic=NULL;
	ULONG bit;

	/*
	 * Disables a hardware interrupt.  This routine is called by the
	 * kernel when a device driver calls InterruptDisable.  The system
	 * is preemtible when this function is called.
	 */
	if (SysIntr <= SYSINTR_MAXIMUM)
	{
		// Handle any external controllers
#ifdef PLATFORM_INTR_EXTERNAL_DISABLE_CODE
		PLATFORM_INTR_EXTERNAL_DISABLE_CODE
#endif

#if defined(DDMA_PHYS_ADDR)
		if (LocalSysIntrMap[SysIntr].DdmaMask != 0)
		{
		    ULONG IntrState, Mask;

		    IntrState = DISABLE_INTERRUPTS();
			Mask = ddma->inten;
			Mask &= ~LocalSysIntrMap[SysIntr].DdmaMask;
			ddma->inten = Mask;
		    RESTORE_INTERRUPTS(IntrState);
		}
#endif
	  	ic0->maskclr = LocalSysIntrMap[SysIntr].Ic0Mask;
	  	ic1->maskclr = LocalSysIntrMap[SysIntr].Ic1Mask;

		// Configure the wake registers properly
		HwIntr = LocalSysIntrMap[SysIntr].HwIntr;
		if ((HwIntr >= HWINTR_IC0_BASE) && (HwIntr <= HWINTR_IC0_MAX))
		{
			bit = (1 << HwIntr);
			ic = (AU1X00_IC *)ic0;
		}
		else if ((HwIntr >= HWINTR_IC1_BASE) && (HwIntr <= HWINTR_IC1_MAX))
		{
			bit = (1 << (HwIntr - HWINTR_IC1_BASE));
			ic = (AU1X00_IC *)ic1;
		}
		if ( NULL != ic )
			ic->wakeclr = bit;
    }
}

/********************************************************************/

VOID
OEMInterruptDone(IN DWORD SysIntr)
{
	/*
	 * Signals completion of interrupt processing.  OEMInterruptDone
	 * is called by the kernel when a device driver calls InterruptDone.
	 * The system is preemtible when this function is called.
	 */
	if (SysIntr <= SYSINTR_MAXIMUM)
	{
		// Handle any external controllers
#ifdef PLATFORM_INTR_EXTERNAL_ENABLE_CODE
		PLATFORM_INTR_EXTERNAL_ENABLE_CODE
#endif

#if defined(DDMA_PHYS_ADDR)
		if (LocalSysIntrMap[SysIntr].DdmaMask != 0)
		{
		    ULONG IntrState, Mask;

		    IntrState = DISABLE_INTERRUPTS();
			Mask = ddma->inten;
			Mask |= LocalSysIntrMap[SysIntr].DdmaMask;
			ddma->inten = Mask;
		    RESTORE_INTERRUPTS(IntrState);
		}
#endif
	  	ic0->maskset = LocalSysIntrMap[SysIntr].Ic0Mask;
	  	ic1->maskset = LocalSysIntrMap[SysIntr].Ic1Mask;
    }
}

/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/

//
// BCEDDK required interrupt functionality
//

ULONG
OEMInterruptConnect(
    IN INTERFACE_TYPE InterfaceType,
    IN ULONG BusNumber,
    IN ULONG BusInterrupt,
    IN ULONG InterruptMode
    )

/*++

Routine Description:

    This routine allocates a SYSINTR and associates the SYSINTR with
    the specified system wide interrupt vector.

Arguments:

    InterfaceType - Ignored

    BusNumber - Ignored

    BusInterrupt - Specifies up to 4 hardware Au1x00 HwIntrs

    InterruptMode - Specfies the INTR_MODE of corresponding HwIntrs

Return Value:

    This routine returns a valid SYSINTR.  A return value of SYSINTR_NOP
    indicates that the SYSINTRs have been exhausted, or error encountered.

--*/

{
    ULONG SysIntr = SYSINTR_NOP;
    ULONG IntrState;
	ULONG HwIntr, IntrMode;
	int index, numHwIntrs = 0;
	BOOL inuse = FALSE;

	/*
	 * CE 4.2 PCI bus support uses IOCTL_HAL_REQUEST_IRQ and then
	 * IOCTL_HAL_REQUEST_SYSINTR so that the incoming BusInterrupt
	 * is already an Au1x00 ICx HwIntr. Thus all requests are for
	 * direct HwIntrs.
	 */

	//RETAILMSG(1,(TEXT("OIC() irq=%08X\r\n"), BusInterrupt));

    IntrState = DISABLE_INTERRUPTS();

	// Check to see if any of the HwIntrs are already in use
	for (index = 0; index < 4; ++index)
	{
		HwIntr = BusInterrupt >> (index * 8);
		HwIntr &= 0x000000FF;
		// HwIntr 0 (UART0) only valid in BusInterrupt[7..0]
		if ((HwIntr == 0) && (index > 0))
			continue;
		++numHwIntrs;
		if (HwIntrMap[HwIntr].SysIntr != SYSINTR_NOP)
			inuse = TRUE;
	}

	// Allocate and configure SYSINTR
    if (!inuse)
    {
        // parameters usable, setup sysintr in table
        SysIntr = GetFreeSysIntr();
        if (SYSINTR_NOP != SysIntr)
        {
            LocalSysIntrMap[SysIntr].Shared = 0;
			LocalSysIntrMap[SysIntr].HwIntr = BusInterrupt;

			//RETAILMSG(1,(TEXT("OEMIC : ")));
			for (index = 0; index < 4; ++index)
			{
				HwIntr = BusInterrupt >> (index * 8);
				HwIntr &= 0x000000FF;
				IntrMode = InterruptMode >> (index * 8);
				IntrMode &= 0x000000FF;

				// HwIntr 0 (UART0) only valid in BusInterrupt[7..0]
				if ((HwIntr == 0) && (index > 0))
					continue;

				//RETAILMSG(1,(TEXT("HwIntr %d "), HwIntr));
				if ((HwIntr >= HWINTR_IC0_BASE) && (HwIntr <= HWINTR_IC0_MAX))
					LocalSysIntrMap[SysIntr].Ic0Mask |= (1 << HwIntr);
				else if ((HwIntr >= HWINTR_IC1_BASE) && (HwIntr <= HWINTR_IC1_MAX))
					LocalSysIntrMap[SysIntr].Ic1Mask |= (1 << (HwIntr - HWINTR_IC1_BASE));
				else if ((HwIntr >= HWINTR_EXT_BASE) && (HwIntr <= HWINTR_EXT_MAX))
					LocalSysIntrMap[SysIntr].ExtMask |= (1 << (HwIntr - HWINTR_EXT_BASE));
#if defined(DDMA_PHYS_ADDR)
				else if ((HwIntr >= HWINTR_DDMA_BASE) && (HwIntr <= HWINTR_DDMA_MAX))
					LocalSysIntrMap[SysIntr].DdmaMask |= (1 << (HwIntr - HWINTR_DDMA_BASE));
#endif


	            HwIntrMap[HwIntr].SysIntr = SysIntr;
	            HwIntrMap[HwIntr].Shared = 0;

				// Allow INTR_MODE override
				if ((InterruptConfiguration[HwIntr] == (irqNA)) &&
					(IntrMode != 0))
				{
					configInterrupt(HwIntr, IntrMode);
				}
			}
			//RETAILMSG(1,(TEXT("\r\n")));

            // Signal ready to use
            LocalSysIntrMap[SysIntr].InUse = TRUE;
        }
	}
#ifdef INTERRUPT_SHARING
	else
	{
		if (numHwIntrs == 1)
		{
			// NOTE: No check is performed to ensure that shared interrupts
			// are configured with the appropriate interrupt configuration;
			// ie level; this is to be done in the configuration of the
			// interrupt controller per platform.

			// NOTE: At this time, shared interrupts on GPIOs not supported.
			// Is there room for another share?

			HwIntr = BusInterrupt;

			if (INTR_MAX_IRQ_SHARE_COUNT > HwIntrMap[BusInterrupt].Shared)
			{
				SysIntr = GetFreeSysIntr();
				// was there a free sysintr?
				if (SYSINTR_NOP != SysIntr)
				{
					HwIntrMap[BusInterrupt].Shared++;

					if ((HwIntr >= HWINTR_IC0_BASE) && (HwIntr <= HWINTR_IC0_MAX))
						LocalSysIntrMap[SysIntr].Ic0Mask |= (1 << HwIntr);
					else
						LocalSysIntrMap[SysIntr].Ic1Mask |= (1 << (HwIntr - HWINTR_IC1_BASE));

					LocalSysIntrMap[SysIntr].HwIntr = BusInterrupt;
					// Signal ready to use
					LocalSysIntrMap[SysIntr].InUse = TRUE;

					SharedIntrMap[BusInterrupt].SysIntr[SharedIntrMap[BusInterrupt].Count] = (UCHAR)SysIntr;
					SharedIntrMap[BusInterrupt].Count++;
				}
			}
		}
    }
#endif

    RESTORE_INTERRUPTS(IntrState);

    DEBUGMSG(ZONE_INTR,(L"OEMInterruptConnect(BI=0x%08X SI=%d)\r\n",BusInterrupt, SysIntr));

    return SysIntr;
}

/********************************************************************/

VOID
OEMInterruptDisconnect(IN ULONG SysIntr)

/*++

Routine Description:

    This routine disconnects the given SYSINTR.  The SYSINTR will no
    longer be associated with the vector specified in InterruptConnect.
    Only disconnects dynamically allocated sysintrs i.e. this in the
    SYSINTR_FIRMWARE region
Arguments:

    SysIntr - Specifies the SYSINTR to be disconnected.

Return Value:

    None.

--*/

{
    ULONG HwIntr;
    ULONG IntrState;
    ULONG index;

	IntrState = DISABLE_INTERRUPTS();

	if ((SysIntr >= SYSINTR_FIRMWARE) &&
		(SysIntr <= SYSINTR_MAXIMUM) &&
		LocalSysIntrMap[SysIntr].InUse)
	{
		for (index = 0; index < 4; ++index)
		{
			HwIntr = LocalSysIntrMap[SysIntr].HwIntr >> (index * 8);
			HwIntr &= 0x000000FF;

			// HwIntr 0 (UART0) only valid in BusInterrupt[7..0]
			if ((HwIntr == 0) && (index > 0))
				continue;

			//RETAILMSG(1,(TEXT("HwIntr %d "), HwIntr));
			if (HwIntrMap[HwIntr].Shared)
			{
#ifdef INTERRUPT_SHARING
				ULONG Last,i;

				// handle shared case
				HwIntrMap[HwIntr].Shared--;
				SharedIntrMap[HwIntr].Count--;
				Last = SharedIntrMap[HwIntr].SysIntr[SharedIntrMap[HwIntr].Count];

				//
				// Remove Sysintr from chain
				//
				if (HwIntrMap[HwIntr].Shared)
				{
					for (i=0;i<SharedIntrMap[HwIntr].Count;i++)
					{
						if (SharedIntrMap[HwIntr].SysIntr[i] == SysIntr)
						{
							SharedIntrMap[HwIntr].SysIntr[i] = (UCHAR)Last;
							break;
						}
					}
				}
				else
				{
					// Only 1 left therefore not shared anymore
					HwIntrMap[HwIntr].SysIntr = Last;
				}
#endif
			} else {
                OEMInterruptDisable(SysIntr);
				HwIntrMap[HwIntr].SysIntr = SYSINTR_NOP;
				HwIntrMap[HwIntr].Shared = 0;
			}
		}
		LocalSysIntrMap[SysIntr].Ic0Mask = 0;
		LocalSysIntrMap[SysIntr].Ic1Mask = 0;
		LocalSysIntrMap[SysIntr].DdmaMask = 0;
		LocalSysIntrMap[SysIntr].ExtMask = 0;
        LocalSysIntrMap[SysIntr].HwIntr = 0;
        LocalSysIntrMap[SysIntr].Shared = 0;
        LocalSysIntrMap[SysIntr].InUse = FALSE;
    }

    RESTORE_INTERRUPTS(IntrState);
}

/********************************************************************/

BOOL
OEMInterruptClearEdge(IN DWORD SysIntr)
{
	if (SysIntr <= SYSINTR_MAXIMUM)
	{
	  	ic0->risingclr = LocalSysIntrMap[SysIntr].Ic0Mask;
	  	ic0->fallingclr = LocalSysIntrMap[SysIntr].Ic0Mask;
	  	ic1->risingclr = LocalSysIntrMap[SysIntr].Ic1Mask;
	  	ic1->fallingclr = LocalSysIntrMap[SysIntr].Ic1Mask;
    }
	return TRUE;
}

/********************************************************************/

ULONG
OEMInterruptQuerySysIntr(ULONG HwIntr)
{
    ULONG SysIntr = SYSINTR_NOP;

    if (HwIntr < HWINTR_MAXIMUM)
    {
        SysIntr = HwIntrMap[HwIntr].SysIntr;
    }

    return SysIntr;
}

/********************************************************************/
ULONG
OEMInterruptQueryEvents (IN DWORD SysIntr)
{
	ULONG EventList = 0;
	ULONG Ic0Pending, Ic1Pending;
#if defined(DDMA_PHYS_ADDR)
	ULONG DdmaPending;
#endif
	ULONG ExtPending;
	ULONG HwIntr;
	int index;

	// Apply IcXMask against IcXRequest, and see if remaining
	// bits match an interrupt from the interrupt set.

	if (SysIntr <= SYSINTR_MAXIMUM)
    {
		// FIX!!! Does this need interrupts disabled?

		Ic0Pending = LocalSysIntrMap[SysIntr].Ic0Request &
			LocalSysIntrMap[SysIntr].Ic0Mask;
		Ic1Pending = LocalSysIntrMap[SysIntr].Ic1Request &
			LocalSysIntrMap[SysIntr].Ic1Mask;
#if defined(DDMA_PHYS_ADDR)
		DdmaPending = LocalSysIntrMap[SysIntr].DdmaRequest &
			LocalSysIntrMap[SysIntr].DdmaMask;
#endif
		ExtPending = LocalSysIntrMap[SysIntr].ExtRequest &
			LocalSysIntrMap[SysIntr].ExtMask;

		for (index = 0; index < 4; ++index)
		{
			HwIntr = LocalSysIntrMap[SysIntr].HwIntr >> (index * 8);
			HwIntr &= 0x000000FF;

			// HwIntr 0 (UART0) only valid in IntrSetA[7..0]
			if ((HwIntr == 0) && (index > 0))
				continue;

			if ((HwIntr >= HWINTR_IC1_BASE) && (HwIntr <= HWINTR_IC0_MAX))
			{
				if (Ic0Pending & (1 << HwIntr))
					EventList |= (1 << index);
			}
			else if ((HwIntr >= HWINTR_IC1_BASE) && (HwIntr <= HWINTR_IC1_MAX))
			{
				if (Ic0Pending & (1 << (HwIntr - HWINTR_IC1_BASE)))
					EventList |= (1 << index);
			}
			else if ((HwIntr >= HWINTR_EXT_BASE) && (HwIntr <= HWINTR_EXT_MAX))
			{
				if (ExtPending & (1 << (HwIntr - HWINTR_EXT_BASE)))
					EventList |= (1 << index);
			}
#if defined(DDMA_PHYS_ADDR)
			else if ((HwIntr >= HWINTR_DDMA_BASE) && (HwIntr <= HWINTR_DDMA_MAX))
			{
				if (DdmaPending & (1 << (HwIntr - HWINTR_DDMA_BASE)))
					EventList |= (1 << index);
			}
#endif
		}
    }

    return EventList;
}

/********************************************************************/
BOOL OALIntrRequestIrqs(DEVICE_LOCATION *pDevLoc, UINT32 *pCount, UINT32 *pIrqs)
{
	DEBUGMSG(ZONE_INTR,(L"+-OALIntrRequestIrqs %x %x\r\n", pDevLoc->Pin ,pDevLoc->LogicalLoc));
	*pCount =1;
	pIrqs[0] = pDevLoc->Pin;
	return TRUE;
}

//------------------------------------------------------------------------------
//
//  Function:  OALIoCtlHalRequestSysIntr
//
//  This function return existing SysIntr for non-shareable IRQs and create
//  new Irq -> SysIntr mapping for shareable.
//
BOOL OALIoCtlHalRequestSysIntr(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    BOOL rc;
    UINT32 *pInpData = pInpBuffer, sysIntr;
    UINT32 inpElems = inpSize / sizeof (UINT32);

    OALMSG(OAL_INTR&&OAL_FUNC, (L"+OALIoCtlHalRequestSysIntr\r\n"));

    // We know output size already
    if (pOutSize != NULL) *pOutSize = sizeof(UINT32);

    // Check input parameters
    if ((pInpBuffer == NULL || inpElems < 1 || (inpSize % sizeof(UINT32) != 0)) ||
       (!pOutBuffer && pOutSize > 0)
    ) {
        NKSetLastError(ERROR_INVALID_PARAMETER);
        rc = FALSE;
        OALMSG(1, (L"WARN: IOCTL_HAL_REQUEST_SYSINTR invalid parameters %d\r\n",__LINE__));
        goto cleanUp;
    }

    if (pOutBuffer == NULL || outSize < sizeof(UINT32)
    ) {
        NKSetLastError(ERROR_INSUFFICIENT_BUFFER);
        rc = FALSE;
        OALMSG(1, (L"WARN: IOCTL_HAL_REQUEST_SYSINTR invalid parameters %d\r\n",__LINE__));
        goto cleanUp;
    }



    // Find if it is new or old call type
    if (inpElems > 1 && pInpData[0] == -1)
    {
        if (inpElems > 2 &&
            (pInpData[1] == OAL_INTR_TRANSLATE || pInpData[1] == OAL_INTR_DYNAMIC ||
             pInpData[1] == OAL_INTR_STATIC || pInpData[1] == OAL_INTR_FORCE_STATIC)
           ) {
            // Second UINT32 contains flags, third and subsequents IRQs
            sysIntr = OALIntrRequestSysIntr(inpElems - 2, &pInpData[2], pInpData[1]);
        } else {
            NKSetLastError(ERROR_INVALID_PARAMETER);
            rc = FALSE;
    	    OALMSG(1, (L"WARN: IOCTL_HAL_REQUEST_SYSINTR invalid parameters %d\r\n",__LINE__));
            goto cleanUp;
        }
    } else {
        if (inpElems == 1) {

            // This is legacy call, first UINT32 contains IRQ
            sysIntr = OALIntrRequestSysIntr(1, pInpData, 0);
        } else {
            NKSetLastError(ERROR_INVALID_PARAMETER);
            rc = FALSE;
	        OALMSG(1, (L"WARN: IOCTL_HAL_REQUEST_SYSINTR invalid parameters %d\r\n",__LINE__));
            goto cleanUp;
        }
    }

    // Store obtained SYSINTR
    *(UINT32*)pOutBuffer = sysIntr;
    rc = (sysIntr != SYSINTR_UNDEFINED);

cleanUp:
    OALMSG(OAL_INTR&&OAL_FUNC, (
        L"+OALIoCtlHalRequestSysIntr(rc = %d)\r\n", rc
    ));
    return rc;
}

//------------------------------------------------------------------------------
//
//  Function:  OEMReleaseSysIntr
//
//  This function releases a previously-requested SYSINTR.
//
BOOL OALIoCtlHalReleaseSysIntr(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    BOOL rc;

    OALMSG(OAL_INTR&&OAL_FUNC, (L"+OALIoCtlHalRequestSysIntr\r\n"));

    // We know output size
    if (pOutSize != NULL) *pOutSize = 0;

    // Check input parameters
    if (pInpBuffer == NULL || inpSize != sizeof(UINT32)) {
        OALMSG(OAL_WARN, (
            L"WARN: IOCTL_HAL_RELEASE_SYSINTR invalid parameters\r\n"
        ));
        NKSetLastError(ERROR_INVALID_PARAMETER);
        rc = FALSE;
        goto cleanUp;
    }

    // Call function itself
    rc = OALIntrReleaseSysIntr(*(UINT32*)pInpBuffer);

cleanUp:
    OALMSG(OAL_INTR&&OAL_FUNC, (
        L"+OALIoCtlHalRequestSysIntr(rc = %d)\r\n", rc
    ));
    return rc;
}

//------------------------------------------------------------------------------
//
//  Function: OALIoCtlHalRequestIrq
//
//  This function returns IRQ for device on given location.
//
BOOL OALIoCtlHalRequestIrq(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    BOOL rc = FALSE;
    DEVICE_LOCATION *pDevLoc, devLoc;
    UINT32 count;

    OALMSG(OAL_INTR&&OAL_FUNC, (L"+OALIoCtlHalRequestIrq\r\n"));

    // Check parameters
    if (
        pInpBuffer == NULL || inpSize != sizeof(DEVICE_LOCATION) ||
        pOutBuffer == NULL || outSize < sizeof(UINT32)
    ) {
        NKSetLastError(ERROR_INVALID_PARAMETER);
        OALMSG(OAL_WARN, (
            L"WARN: IOCTL_HAL_REQUEST_IRQ invalid parameters\r\n"
        ));
        goto cleanUp;
    }

    // Call function itself (we must first fix PCI bus device location...)
    pDevLoc = (DEVICE_LOCATION*)pInpBuffer;
    memcpy(&devLoc, pDevLoc, sizeof(devLoc));
    if (devLoc.IfcType == PCIBus) devLoc.BusNumber >>= 8;
    count = outSize/sizeof(UINT32);
    rc = OALIntrRequestIrqs(&devLoc, &count, pOutBuffer);
    if (pOutSize != NULL) *pOutSize = count * sizeof(UINT32);

cleanUp:
    OALMSG(OAL_INTR&&OAL_FUNC, (
        L"-OALIoCtlHalRequestSysIntr(rc = %d)\r\n", rc
    ));
    return rc;
}


//------------------------------------------------------------------------------
//
//  Function:  OALIntrRequestSysIntr
//
//  This function allocate new SYSINTR for given IRQ and it there isn't
//  static mapping for this IRQ it will create it.
//
UINT32 OALIntrRequestSysIntr(UINT32 count, const UINT32 *pIrqs, UINT32 flags)
{
    UINT32 sysIntr;

    OALMSG(OAL_INTR&&OAL_FUNC, (
        L"+OALIntrRequestSysIntr(%d, 0x%08x, 0x%08x irq:0x%08x)\r\n", count, pIrqs, flags, pIrqs[0]
    ));

	sysIntr = OEMInterruptConnect(Internal, 0, pIrqs[0], 0);

    OALMSG(OAL_INTR&&OAL_FUNC, (
        L"-OALIntrRequestSysIntr(sysIntr = %d)\r\n", sysIntr
    ));
    return sysIntr;
}


//------------------------------------------------------------------------------
//
//  Function:  OALIntrReleaseSysIntr
//
//  This function release given SYSINTR and remove static mapping if exists.
//
BOOL OALIntrReleaseSysIntr(UINT32 sysIntr)
{
    OALMSG(OAL_INTR&&OAL_FUNC, (L"+OALIntrReleaseSysIntr(%d)\r\n", sysIntr));
	OEMInterruptDisconnect(sysIntr);
    OALMSG(OAL_INTR&&OAL_FUNC, (L"-OALIntrReleaseSysIntr\r\n"));
    return TRUE;
}


VOID
StoreIntrRegState(VOID)
{
    int i;
	AU1X00_IC *ic;

    for (i = 0; i < sizeof IntrStates / sizeof IntrStates[0]; i++)
    {
		if (i == 0)
			ic = (AU1X00_IC *)ic0;
		else
			ic = (AU1X00_IC *)ic1;

        IntrStates[i].config0ReadSet = ic->cfg0rd;
        IntrStates[i].config1ReadSet = ic->cfg1rd;
        IntrStates[i].config2ReadSet = ic->cfg2rd;

        IntrStates[i].sourceReadSet = ic->srcrd;
        IntrStates[i].assignRequestReadSet = ic->assignrd;

        IntrStates[i].maskReadSet = ic->maskrd;
        IntrStates[i].wakeupRead = ic->wakerd;
    }
}


VOID
RestoreIntrState(
    VOID
    )
{
    int i;
	AU1X00_IC *ic;

    for (i = 0; i < 2; i++)
    {
		if (i == 0)
			ic = (AU1X00_IC *)ic0;
		else
			ic = (AU1X00_IC *)ic1;

		ic->wakeclr = 0xFFFFFFFF;
        ic->wakeset = IntrStates[i].wakeupRead;

        ic->maskclr = 0xFFFFFFFF;

        ic->cfg0clr = 0xFFFFFFFF;
        ic->cfg0set = IntrStates[i].config0ReadSet;

        ic->cfg1clr = 0xFFFFFFFF;
        ic->cfg1set = IntrStates[i].config1ReadSet;

        ic->cfg2clr = 0xFFFFFFFF;
        ic->cfg2set = IntrStates[i].config2ReadSet;

        ic->srcclr =  0xFFFFFFFF;
        ic->srcset =  IntrStates[i].sourceReadSet;

        ic->assignclr = 0xFFFFFFFF;
        ic->assignset = IntrStates[i].assignRequestReadSet;

		ic->wakeset = IntrStates[i].wakeupRead;

        ic->maskset = IntrStates[i].maskReadSet;
    }
}


#endif
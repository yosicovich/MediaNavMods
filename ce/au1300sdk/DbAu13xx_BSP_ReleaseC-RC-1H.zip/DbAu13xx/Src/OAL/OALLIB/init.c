/*++

Copyright (c) 2001-2004 BSQUARE Corporation. All rights reserved.

Module Name:

    init.c

Abstract:

    This module implements the initialization code necessary to run the
    Windows CE kernel on Alchemy platforms.

Author:

Revision History:

--*/

#include <windows.h>
#include "bsp.h"
#include "platform.h"
#include <pehdr.h>
#include <romldr.h>
#include "ldrarg.h"
#include "memmap.s"
#include "macaddr.h"

#define USB_DIAG_OFFSET 0xC
#include <oal_log.h>
#include <oal_cache.h>

// profiler.c
extern void OEMProfileTimerEnable( DWORD dwUSec );
extern void OEMProfileTimerDisable(void);

/********************************************************************/

extern ROMHDR *const volatile pTOC;
static BOOT_ARGS *pBootArgs = (BOOT_ARGS*)(BOOT_ARG_PTR + KSEG1_OFFSET);

DWORD bootupType=HAL_COLD_BOOT;
BOOL gKITLIsPresent = FALSE;

// enable this with BSP_USE_PERSISTENT_REG environment variable
#ifdef USE_PERSISTENT_REG
//
// Support for Persistent Registry.
// Persistent storage used is Flash
//
extern DWORD ReadRegistryFromOEM(DWORD dwFlags, LPBYTE lpData, DWORD cbData);
extern BOOL  WriteRegistryToOEM (DWORD dwFlags, LPBYTE lpData, DWORD cbData);

extern DWORD
    (*pReadRegistryFromOEM)(DWORD dwFlags, LPBYTE lpData, DWORD cbData);
extern BOOL
    (*pWriteRegistryToOEM) (DWORD dwFlags, LPBYTE lpData, DWORD cbData);
#endif

//
// These functions reads/write into RAM a registry file from
// persistent storage defined by the OEM.
//


/********************************************************************/

/*++

Routine Description:

    Display some basic information about the memory map on bootup.

Arguments:

    None.

Return Value:

    None.

--*/
static VOID
DumpMemoryMap(
    VOID
    )
{

    NKDbgPrintfW(L"Start of SDRAM:       0x%08x\r\n", SDRAM_BASE_ADDRESS);

    NKDbgPrintfW(L"Start of BootArgs:    0x%08x, Size = 0x%x\r\n",
                 BOOTARG_PHYSADDR_BASE,
                 BOOTARG_SIZE
                );

    NKDbgPrintfW(L"Ethernet Rx DMA area: 0x%08x, Size = 0x%x\r\n",
                 NIC_RX_PHYSADDR_BASE,
                 NIC_PACKET_LEN * 4
                );

    NKDbgPrintfW(L"Ethernet Tx DMA area: 0x%08x, Size = 0x%x\r\n",
                 NIC_TX_PHYSADDR_BASE,
                 NIC_PACKET_LEN * 4
                );

    NKDbgPrintfW(L"Free area start:      0x%08x\r\n", FREEMEM_START);

}

//------------------------------------------------------------------------------
//
//  Function:  OEMCacheGlobalsInit
//
//  This function initializes globals variables which holds cache parameters.
//  It must be called before any other cache/TLB function.
//
VOID OEMCacheGlobalsInit()
{
    g_oalCacheInfo.L1Flags          = CF_COHERENT;
#ifdef OVERWRITE_COMMON_CACHEINIT
    g_oalCacheInfo.L1ISetsPerWay    = 128;
    g_oalCacheInfo.L1INumWays       = 4;
    g_oalCacheInfo.L1ILineSize      = 32;
    g_oalCacheInfo.L1ISize          = (16 * 1024);
    g_oalCacheInfo.L1DSetsPerWay    = 128;
    g_oalCacheInfo.L1DNumWays       = 4;
    g_oalCacheInfo.L1DLineSize      = 32;
    g_oalCacheInfo.L1DSize          = (16 * 1024);

    // No L2 Cache
    g_oalCacheInfo.L2Flags          = 0;
    g_oalCacheInfo.L2ISetsPerWay    = 0;
    g_oalCacheInfo.L2INumWays       = 0;
    g_oalCacheInfo.L2ILineSize      = 0;
    g_oalCacheInfo.L2ISize          = 0;
    g_oalCacheInfo.L2DSetsPerWay    = 0;
    g_oalCacheInfo.L2DNumWays       = 0;
    g_oalCacheInfo.L2DLineSize      = 0;
    g_oalCacheInfo.L2DSize          = 0;
#endif

}

/********************************************************************/

/*
 * OEMInit is called by the kernel after it has performed minimal
 * initialization.  Interrupts are disabled and the kernel is not
 * ready to handle exceptions.
 */

VOID
OEMInit(VOID)
{
    WCHAR *BootCause;
    ULONG  prid;
	ULONG  cpupll;
	int bclk;
	ULONG tmp;

    INTERRUPTS_OFF();

    OEMWriteDebugString(L"+OEMInit\r\n");

	g_pOemGlobal->dwArchFlagOverride = 0;

#if 0
	{
		DWORD *p;
		OEMWriteDebugString(L"OemGloabl dump\r\n");
		for(  p = (DWORD*)g_pOemGlobal;
			  (DWORD)p< (DWORD)((DWORD)g_pOemGlobal + sizeof(OEMGLOBAL));
			  p++ ) {
			NKDbgPrintfW(L"Address %08X: %x\r\n", p, *p);
		}
	}
#endif


	// Display platform name
	OEMWriteDebugString(TEXT(PLATFORM_DESCRIPTION));
	OEMWriteDebugString(L"\n\r");

	// Perform any platform-specific initialization here
#ifdef PLATFORM_OEMINIT_CODE
	PLATFORM_OEMINIT_CODE
#endif

    // Update kernel variables
    g_pOemGlobal->pfnProfileTimerEnable = OEMProfileTimerEnable;
    g_pOemGlobal->pfnProfileTimerDisable = OEMProfileTimerDisable;

    // Initialize global cache constants
    OALCacheGlobalsInit();
	OEMCacheGlobalsInit();

    //
    // Store the start of the image in scratch register 1.
    //
    Sys->scratch1 = pTOC->physfirst;

	bootupType = Sys->scratch0;

    // Clear the boot cause scratch register.
    Sys->scratch0 = HAL_COLD_BOOT;

    //
    // Read scratch register 0 to see if we are doing warm reset.
    //
    switch (bootupType)
    {
	    case HAL_WARM_BOOT:
	        BootCause = L"Warm Reboot\r\n";

	        //
	        // Booting kernel with existing memory configuration:
	        //
//	        pBootArgs->ucEshellFlags &= ~KITL_FL_CLEANBOOT;
	        break;

	    case HAL_SUSPENDRESUME_BOOT:
	        BootCause = L"Resume Reboot\r\n";
	        break;

	    case HAL_COLD_BOOT:	// This and anything else is a cold boot.
	    default:
	        BootCause = L"Cold Boot\r\n";

	        // ensure clean memory config
	        memset((void*)pTOC->ulRAMFree, 0, sizeof(DWORD) * 3);
	        break;
    }

    OEMWriteDebugString(BootCause);

    //
    // Reset the interrupt mappings.
    //
    OEMInterruptInit();

    //
    // Setup the CPU clock sources and scheduler tick.
    //
    InitClock();


// enable this with BSP_USE_PERSISTENT_REG environment variable
#ifdef USE_PERSISTENT_REG
    //
    // Patch in Persistent registry functions.
    //
    pWriteRegistryToOEM	 = (void*) WriteRegistryToOEM;
    pReadRegistryFromOEM = (void*) ReadRegistryFromOEM;
#endif USE_PERSISTENT_REG

    //DumpMemoryMap();

    //
    // Check Boot Args
    //
    NKDbgPrintfW(L"BootArgs are at %X, SIG = %x\r\n",pBootArgs, pBootArgs->dwSig);
    if (pBootArgs->dwSig == BOOTARG_SIG)
    {
		// Removed Kitl logic
		OEMWriteDebugString(L"BOOTARG Sig is good\r\n");
	}
    else
    {
        OEMWriteDebugString(L"BOOTARG Sig is bad\r\n");
    }

	// Display CPU rev and frequency
	bclk = TRUE;
	prid = Cp0RdPRId();
	switch (prid)
	{
	case 0x00030100: OEMWriteDebugString(L"Au1000 DA "); bclk = FALSE; break;
	case 0x00030201: OEMWriteDebugString(L"Au1000 HA "); bclk = FALSE; break;
	case 0x00030202: OEMWriteDebugString(L"Au1000 HB "); bclk = FALSE; break;
	case 0x00030203: OEMWriteDebugString(L"Au1000 HC "); break;
	case 0x00030204: OEMWriteDebugString(L"Au1000 HD "); break;

	case 0x01030200: OEMWriteDebugString(L"Au1500 AB "); break;
	case 0x01030201: OEMWriteDebugString(L"Au1500 AC "); break;
	case 0x01030202: OEMWriteDebugString(L"Au1500 AD "); break;

	case 0x02030200: OEMWriteDebugString(L"Au1100 AB "); break;
	case 0x02030201: OEMWriteDebugString(L"Au1100 BA "); break;
	case 0x02030202: OEMWriteDebugString(L"Au1100 BC "); break;
	case 0x02030203: OEMWriteDebugString(L"Au1100 BD "); break;
	case 0x02030204: OEMWriteDebugString(L"Au1100 BE "); break;

	case 0x03030200: OEMWriteDebugString(L"Au1550 AA "); bclk = FALSE; break;

	case 0x04030200: OEMWriteDebugString(L"Au1200 AB "); bclk = TRUE; break;
    case 0x04030201: OEMWriteDebugString(L"Au1200 AC "); bclk = TRUE; break;

    case 0x04030202: OEMWriteDebugString(L"Au1250 AD "); bclk = TRUE; break;
    case 0x05030202: OEMWriteDebugString(L"Au1210 AD "); bclk = TRUE; break;

// todo -- determine lower nibble
    case 0x800C8000: OEMWriteDebugString(L"Au13xx AA "); bclk = FALSE; break;
    case 0x800C8001: OEMWriteDebugString(L"Au13xx AA "); bclk = FALSE; break;
    case 0x800C8002: OEMWriteDebugString(L"Au13xx AA "); bclk = FALSE; break;
    case 0x800C8003: OEMWriteDebugString(L"Au13xx AA "); bclk = FALSE; break;

	default: OEMWriteDebugString(L"Unknown Au1x00! "); bclk = FALSE; break;
	}
	cpupll = (Sys->cpupll & SYS_CPUPLL_PLL) * 12;
    NKDbgPrintfW(L"(PRId %08X) @ %dMHZ\r\n", prid, cpupll);

#if defined(AU1200)
	// Disable MAE Clock to consume less power. The driver will re-enable when needed.
	tmp = Sys->powerctrl;
	Sys->powerctrl = tmp | (1<<17);
#endif

    // Enable BCLK switching to consume less power
	if (bclk)
	{
#if defined(AU1200)
		PULONG USB_Diag = (PULONG) (USB_PHYS_ADDR + KSEG1_OFFSET + USB_DIAG_OFFSET);

		// USB 2.0 can not be enabled while BClk is enabled. Setting USB 2.0 in powerdown mode.
		*USB_Diag |= (1<<7);
#endif

        OEMWriteDebugString(L"BCLK switching enabled\r\n");


        /* Enable BCLK switching */
		tmp = Sys->powerctrl;
		Sys->powerctrl = tmp | 0x60;
    }


    // Initialize the KITL connection if required
    KITLIoctl (IOCTL_KITL_STARTUP, NULL, 0, NULL, 0, NULL);

    OEMWriteDebugString(L"-OEMInit\r\n");
}

/********************************************************************/

BOOL
OEMGetExtensionDRAM(
    OUT PULONG MemStart,
    OUT PULONG MemLength
    )
{
    //This module implements the required callbacks for OAL to report
    //extension sDRAM to the kernel.  There is none...

    return FALSE;
}

/********************************************************************/

/*
 * Initialize the CPU clock subsystem.
 *
 * NB: This code is also called from the scheduler as part of resuming from
 * suspend. It executes in an exception context, so don't use anything that
 * requires a reschedule or an interrupt.
 */
VOID
InitClock(VOID)
{
    OALMSG(OAL_FUNC, (L"+InitClock\r\n"));

	//
	// The CPU core frequency is established in the reset_X.S file
	//

#ifdef CPU_AU1000
	//
	// Early Au1000 silicon has errata wrt/ USB clocking. See
	// Au1000 Errata #23 "The USB Host will not operate at all frequencies"
	// Change CPU frequency now for workaround before any other clock
	// computations occur
	//
	VOID au1000UsbWorkaround (VOID);
    ULONG  prid;

	prid = Cp0RdPRId();
    if ((prid == 0x00030100) || /* Au1000 DA */
        (prid == 0x00030201) || /* Au1000 HA */
        (prid == 0x00030202) )  /* Au1000 HB */
    {
		au1000UsbWorkaround();
	}
#endif

	// Put code here that is needed by *both* OEMInit() and Resume from Suspend
#ifdef PLATFORM_PREANDRESUMEINIT_CODE
	PLATFORM_PREANDRESUMEINIT_CODE
#endif

#ifdef BSP_USE_IDLE1SLEEP
	bootupType = Sys->scratch0;

	if (bootupType == HAL_SUSPENDRESUME_BOOT)
	{
		RETAILMSG(1,(TEXT("Resuming from IDLE1 sleep, skipping HalTickerInit()\r\n")));
		return;
	}
#endif

    //
    // The system-level registers are set up for the various clock sources.
    // Now initialize the RTC device for the scheduler and time of year.
    //
    HalTickerInit();

    OALMSG(OAL_FUNC, (L"-InitClock\r\n"));

}

/********************************************************************/

static VOID WriteMacToRegistry(LPCWSTR szPath, UINT16 mac[3])
{
    LONG rc, i, d;
    HKEY hKey;
    ULONG disp;
    WCHAR szMAC[18], *pos;

    rc = NKRegCreateKeyEx(
       HKEY_LOCAL_MACHINE, szPath, 0, NULL, 0, 0, NULL, &hKey, &disp
    );

    if (rc != ERROR_SUCCESS) return;

    pos = szMAC;
    for (i = 0; i < 3; i++) {
       d = (mac[i] >> 4) & 0x0F;
       *pos++ = (WCHAR)(d < 10 ? L'0' + d : L'A' + d - 10);
       d = (mac[i] >> 0) & 0x0F;
       *pos++ = (WCHAR)(d < 10 ? L'0' + d : L'A' + d - 10);
       *pos++ = L'-';
       d = (mac[i] >> 12) & 0x0F;
       *pos++ = (WCHAR)(d < 10 ? L'0' + d : L'A' + d - 10);
       d = (mac[i] >> 8) & 0x0F;
       *pos++ = (WCHAR)(d < 10 ? L'0' + d : L'A' + d - 10);
       if (i < 2) *pos++ = L'-';
    }
    *pos = L'\0';

    NKRegSetValueEx(
       hKey, L"NetworkAddress", 0, REG_SZ, (UCHAR*)szMAC, sizeof(szMAC)
    );

    NKRegCloseKey(hKey);
}

//------------------------------------------------------------------------------
//
//  Function:  OALIoCtlHalInitRegistry
//
BOOL OALIoCtlHalInitRegistry()
{
    USHORT mac[3];
    MACADDR_IN_FLASH *pMif;

    pMif = (MACADDR_IN_FLASH*)(KSEG1_OFFSET + MAC_ADDR_BASE);


	gKITLIsPresent = TRUE;
	if (!gKITLIsPresent) {
		// Set registry entry for MAC1 network address
		mac[0] = pMif->u.AsShort.Mac0[0];
		mac[1] = pMif->u.AsShort.Mac0[1];
		mac[2] = pMif->u.AsShort.Mac0[2];
		WriteMacToRegistry(L"Comm\\AU1MAC1\\Parms", mac);
	}

	// Set registry entry for MAC2 network address
	mac[0] = pMif->u.AsShort.Mac1[0];
	mac[1] = pMif->u.AsShort.Mac1[1];
	mac[2] = pMif->u.AsShort.Mac1[2];
    WriteMacToRegistry(L"Comm\\AU1MAC2\\Parms", mac);

    return TRUE;
}
/********************************************************************/

/********************************************************************/

#ifdef CPU_AU1000
VOID
au1000UsbWorkaround(
    VOID
)
{
	//
    // The workaround for setting up the USB clock properly for early
	// Au1000 silicon.
    //
    ULONG Value;

	OEMWriteDebugString(L"\r\n\r\n");
	OEMWriteDebugString(L"Please contact AMD at pcs.support@amd.com and request and updated Au1000\r\n");
	OEMWriteDebugString(L"\r\n\r\n");
    OEMWriteDebugString(L"Changing CPU clock to 384MHz for Au1000 USB workaround...\r\n");
	OEMWriteDebugString(L"\r\n\r\n");

    //
    // Before we adjust the CPU clock, delay a little for any prior UART
    // FIFO contents to be transmitted since it will be affected.
    // Use the CPU cycle counter since interrupts are disabled.
    //
	OALStallExecution(4*10); // ~4ms

    //
    // Disable FRDIV2 during the modification of clksrc.
    //
    Value = Sys->freqctrl0;
    Value &= ~0xFFF00000;
    Sys->freqctrl0 = Value);

    //
    // Disable the USBH clock.
    //
    Value = Sys->clksrc;
    Value &= ~0x00007c00;
    Sys->clksrc = Value;

    //
    // Reduce the CPU clock speed while we set up the USB clock.
    //
    Sys->cpupll = 4;

    //
    // Now we can safely set up FRDIV2 for the USB clock.
    // With a CPU clock of 384 MHz, we need a divisor of 8
    // to obtain a 48 MHz USB clock.
    //
    Value = Sys->freqctrl0;
    Value &= ~0xFFF00000;
    Value |= ((8 / 2 - 1) << 22) | (1 << 21) | (0 << 20);
    Sys->freqctrl0 = Value;

    //
    // Route FR2 to the USBH clock, and enable it.
    //
    Value = Sys->clksrc;
    Value &= ~0x00007c00;
    Value |= (4 << 12) | (0 << 11) | (0 << 10);
    Sys->clksrc = Value;

    //
    // Now that the clocks are safely set up and settled,
    // set the speed back up to normal (384 MHz).
    //
    Sys->cpupll = 32;

    OEMWriteDebugString(L"InitClock(): Au1000 CPU clock restored.\r\n");
}
#endif


void OEMWriteDebugLED (WORD wIndex, DWORD dwPattern)
{
}

/********************************************************************/


/*++

Copyright:

    Copyright (c) 1997-2004 BSQUARE Corporation. All rights reserved.

Module:

    pci1500.c

Abstract:

    Implements the Au1 PCI configuration interfaces.

Author:

    Chao Chen

Revision:
	GJS	2002
    

--*/


#include <windows.h>
#include "platform.h"
#include "bceddk.h"
#include "pci.h"

#if defined(PCI_PHYS_ADDR)

#undef DEBUGMSG
#define DEBUGMSG RETAILMSG


#ifdef PCI_VIRT_CONFIG_BASE
#undef PCI_VIRT_CONFIG_BASE
#endif


#define  PCI_USE_TYPE0_CYCLES 1

#define MASK_FOR_PAGE_16K         0x7fff

//
// Global variables.
//
static UCHAR ucPCIMaxBus;
static UCHAR ucPCIMaxDeviceNumber = PCI_MAX_DEVICES;
static UCHAR ucPCIMaxDevice[MAX_SUPPORTED_PCI_BUS];

static CRITICAL_SECTION csPCIConfig;

static BOOL bPCIInitialized;

//
// extern the directly accessed kernel functions
//
extern LPVOID SC_VirtualAlloc(
LPVOID lpAddress, 
DWORD dwSize, 
DWORD flAllocationType, 
DWORD flProtect 
); 
extern BOOL SC_VirtualFree(
LPVOID lpAddress, 
DWORD dwSize, 
DWORD dwFreeType 
); 
extern BOOL SC_VirtualCopy( 
LPVOID lpvDest, 
LPVOID lpvSrc, 
DWORD cbSize, 
DWORD fdwProtect 
);

//
// PCI configuration access functions.
//

BOOL CheckForAbort(
)
{
    ULONG Error;
    PULONG Ptr=(PULONG)(PCI_PHYS_ADDR+PCI_CONFIG+KSEG1_OFFSET);

    Error = *Ptr;

    if (Error & (0xF << 24))
    {
    	Error &= ~(0xF << 24);
    	*Ptr = Error;
        
        return TRUE;
    }
    
	return FALSE;    
}

#if PCI_USE_TYPE0_CYCLES
ULONG
PCIReadBusData(
    IN ULONG BusNumber,
    IN PCI_SLOT_NUMBER SlotNumber,
    IN PVOID Buffer,
    IN ULONG Offset,
    IN ULONG Length
    )

/*++

Description:

    Reads PCI configuration data from the bus.  Note, this routine does not
    synchronize the access to the PCI bus.

Arguments:

    BusNumber - PCI bus number.

    SlotNumber - PCI slot number.

    Buffer - Buffer to read data to.

    Offset - Byte offset where data should start.

    Length - Length of data to read.

Returns:

    Amount of data read from the bus.

--*/

{
    ULONG MaxWriteLen;
    PUCHAR CurrentData;
    ULONG CurrentOffset;      
    ULONG EndOffset;
    ULONG WriteAmount=0;
    ULONG Diff;
    TYPE0_PCI_ADDRESS type0Address;
    PVOID BaseAddress;
    PHYSICAL_ADDRESS PhysicalAddress;
    BOOL Status;

    //
    // Figure out mapping entry for the TLB
    //
    type0Address.u.AsULONG = 0;
    type0Address.u.bits.Device = 1 << SlotNumber.u.bits.DeviceNumber;
    type0Address.u.bits.Function =  SlotNumber.u.bits.FunctionNumber;

    //
    // Use CE mappings
    //
    BaseAddress = SC_VirtualAlloc(
        0,
        0x4000,
        MEM_RESERVE,
        PAGE_NOACCESS
        );

    // VirtualAlloc returns NULL on failure.
    if(BaseAddress == NULL) {
        RETAILMSG(1,(L"VirtualAlloc failure in PCI\r\n"));
        goto ErrorReturn;
    }
    
    //
    // Page align the address
    //
    PhysicalAddress.QuadPart = PCI_CONFIG0_PHYS_ADDR;
    PhysicalAddress.LowPart += type0Address.u.AsULONG;
    PhysicalAddress.LowPart &= ~0x3fff;
    
    Status = SC_VirtualCopy(
        BaseAddress,
        (PVOID)(PhysicalAddress.QuadPart >> 8),
        0x4000,
        PAGE_READWRITE | PAGE_PHYSICAL | PAGE_NOCACHE
        );
        
    // VirtualCopy returns FALSE if it fails.
    if(Status == FALSE) {
        RETAILMSG(1,(L"VirtualCopy failure in PCI\r\n"));
        SC_VirtualFree(
            BaseAddress,
            0,
            MEM_RELEASE
            );

        BaseAddress = NULL;
        goto ErrorReturn;
    }
    
    //
    // Setup for virtual access
    //    
    type0Address.u.bits.Device = 1 << SlotNumber.u.bits.DeviceNumber;
    type0Address.u.bits.Function =  SlotNumber.u.bits.FunctionNumber;
    type0Address.u.AsULONG &= 0x3fff;
    type0Address.u.AsULONG += (ULONG)BaseAddress;
    
    //
    // Loop through the config space starting at offset. For each new
    // position in config space perform a long, short or char word
    // operation.
    //

    EndOffset = Offset + Length;
    CurrentOffset = Offset;
    CurrentData = (PUCHAR)Buffer;

    while(1)
    {
        //
        // Determine the maximum number of bytes we can read based on how
        // many bytes we have left to write in the buffer.
        //
        MaxWriteLen = EndOffset - CurrentOffset;

        //
        // If we can't write any more bytes, we know we're done.
        //
        if(MaxWriteLen == 0)
            break;

        type0Address.u.bits.Register = CurrentOffset / sizeof(ULONG);

        //
        // If we can't read more than 1 byte or if the alignment of
        // our current offset is no better than byte aligned, do a 
        // byte operation.
        //  

        if((MaxWriteLen <= 1) || (CurrentOffset & 0x01) )
        {
            Diff = CurrentOffset & 0x03;

            *(PUCHAR)CurrentData = *(PUCHAR)(type0Address.u.AsULONG + Diff);

            //
            // Update the iterators.
            //

            CurrentOffset += 1;
            CurrentData += 1;
            if (CheckForAbort())
                *((PUCHAR)CurrentData)=~0;
        }

        //
        // If we can't write more than 3 bytes or if the alignment of
        // our current offset is no better than short aligned, do a 
        // short operation.
        //

        else if((MaxWriteLen <= 3) || (CurrentOffset & 0x02) )
        {
            Diff = CurrentOffset & 0x02;

            *(PUSHORT)CurrentData = *(PUSHORT)(type0Address.u.AsULONG + Diff);

            if (CheckForAbort())
                *((PUSHORT)CurrentData)=~0;
            
//        printf("ReadUshort @ %x = %x\r\n",(type0Address.u.AsULONG + Diff), *((PUSHORT)CurrentData));      

            //
            // Update the iterators.
            //
            CurrentOffset += 2;
            CurrentData += 2;
        }

        //
        // At this point we know there are at least 4 bytes to write and
        // the current offset is long aligned so do a long operation.
        //

        else
        {
            *((PULONG)CurrentData) = *(PULONG)type0Address.u.AsULONG;

            if (CheckForAbort())
                *((PULONG)CurrentData)=~0;

            //
            // Update the iterators.
            //
            CurrentOffset += 4;
            CurrentData += 4;
        }
    }

    WriteAmount = CurrentOffset - Offset;

    //
    // Whack the TLB entry
    //
    SC_VirtualFree(
        BaseAddress,
        0,
        MEM_RELEASE
        );
ErrorReturn:
          
    return WriteAmount;
}


ULONG
PCIWriteBusData(
    IN ULONG BusNumber,
    IN PCI_SLOT_NUMBER SlotNumber,
    IN PVOID Buffer,
    IN ULONG Offset,
    IN ULONG Length
    )

/*++

Description:

    Writes PCI configuration data to the bus.  Note, this routine does not
    synchronize the access to the PCI bus.

Arguments:

    BusNumber - PCI bus number.

    SlotNumber - PCI slot number.

    Buffer - Buffer to write data to.

    Offset - Byte offset where data should start.

    Length - Length of data to read.

Returns:

    Amount of data read from the bus.

--*/

{
    ULONG MaxWriteLen;
    PUCHAR CurrentData;
    ULONG CurrentOffset;      
    ULONG EndOffset;
    ULONG WriteAmount;
    ULONG Diff;
    TYPE0_PCI_ADDRESS type0Address;
    PVOID BaseAddress;
    PHYSICAL_ADDRESS PhysicalAddress;
    BOOL Status;

    //
    // Figure out mapping entry for the TLB
    //
    type0Address.u.AsULONG = 0;
    type0Address.u.bits.Device = 1 << SlotNumber.u.bits.DeviceNumber;
    type0Address.u.bits.Function =  SlotNumber.u.bits.FunctionNumber;

    //
    // Use CE mappings
    //
    BaseAddress = SC_VirtualAlloc(
        0,
        0x4000,
        MEM_RESERVE,
        PAGE_NOACCESS
        );

    // VirtualAlloc returns NULL on failure.
    if(BaseAddress == NULL)
        goto ErrorReturn;
    
    //
    // Page align the address
    //
    PhysicalAddress.QuadPart = PCI_CONFIG0_PHYS_ADDR;
    PhysicalAddress.LowPart += type0Address.u.AsULONG;
    PhysicalAddress.LowPart &= ~(MASK_FOR_PAGE_16K >> 1);
    
    Status = SC_VirtualCopy(
        BaseAddress,
        (PVOID)(PhysicalAddress.QuadPart >> 8),
        0x4000,
        PAGE_READWRITE | PAGE_PHYSICAL | PAGE_NOCACHE
        );
    
    // VirtualCopy returns FALSE if it fails.
    if (Status == FALSE)
    {
        SC_VirtualFree(
            BaseAddress,
            0,
            MEM_RELEASE
            );

        BaseAddress = NULL;
        goto ErrorReturn;
    }
    
    //
    // Setup for virtual access
    //    
    type0Address.u.bits.Device = 1 << SlotNumber.u.bits.DeviceNumber;
    type0Address.u.bits.Function =  SlotNumber.u.bits.FunctionNumber;
    type0Address.u.AsULONG &= MASK_FOR_PAGE_16K;
    type0Address.u.AsULONG += (ULONG)BaseAddress;
    
    //
    // Setup loop.
    //
    EndOffset = Offset + Length;
    CurrentOffset = Offset;
    CurrentData = (PUCHAR)Buffer;

    while(1)
    {
        //
        // Determine the maximum number of bytes we can read based on how
        // many bytes we have left to write in the buffer.
        //
        MaxWriteLen = EndOffset - CurrentOffset;

        //
        // If we can't write any more bytes, we know we're done.
        //
        if(MaxWriteLen == 0)
          break;

        //
        // Setup the config space address register.
        //
        type0Address.u.bits.Register = CurrentOffset / sizeof(ULONG);

        //
        // If we can't read more than 1 byte or if the alignment of
        // our current offset is no better than byte aligned, do a 
        // byte operation.
        //  
        if((MaxWriteLen <= 1) || (CurrentOffset & 0x01) )
        {
          Diff = CurrentOffset & 0x03;
          
          *(PUCHAR)(type0Address.u.AsULONG + Diff) = *(PUCHAR)CurrentData;
          
          //
          // Update the iterators.
          //
          CurrentOffset += 1;
          CurrentData += 1;
        }

        //
        // If we can't write more than 3 byte or if the alignment of
        // our current offset is no better than short aligned, do a 
        // short operation.
        //

        else if((MaxWriteLen <= 3) || (CurrentOffset & 0x02) )
        {
          Diff = CurrentOffset & 0x02;
          
          *(PUSHORT)(type0Address.u.AsULONG + Diff) = *(PUSHORT)CurrentData;
          
          //
          // Update the iterators.
          //
          CurrentOffset += 2;
          CurrentData += 2;
        }

        //
        // At this point we know there are at least 4 bytes to write and
        // the current offset is long aligned so do a long operation.
        //
        else
        {
          *(PULONG)type0Address.u.AsULONG = *(PULONG)CurrentData; 
          
          //
          // Update the iterators.
          //
          CurrentOffset += 4;
          CurrentData += 4;
        }
    }

    WriteAmount = CurrentOffset - Offset;

    if (CheckForAbort())
        WriteAmount=0;

    //
    // Whack the TLB entry
    //
    SC_VirtualFree(
        BaseAddress,
        0,
        MEM_RELEASE
        );
ErrorReturn:                
          
    return WriteAmount;
}


#else // use type 1 cycles
ULONG
PCIReadBusData(
    IN ULONG BusNumber,
    IN PCI_SLOT_NUMBER SlotNumber,
    IN PVOID Buffer,
    IN ULONG Offset,
    IN ULONG Length
    )

/*++

Description:

    Reads PCI configuration data from the bus.  Note, this routine does not
    synchronize the access to the PCI bus.

Arguments:

    BusNumber - PCI bus number.

    SlotNumber - PCI slot number.

    Buffer - Buffer to read data to.

    Offset - Byte offset where data should start.

    Length - Length of data to read.

Returns:

    Amount of data read from the bus.

--*/

{
    ULONG MaxWriteLen;
    PUCHAR CurrentData;
    ULONG CurrentOffset;      
    ULONG EndOffset;
    ULONG WriteAmount;
    ULONG Diff;
    TYPE1_PCI_ADDRESS type1Address;

    //
    // Fill in bus, device, and function information.
    // To map the physcial location
    //
    type1Address.u.AsULONG = PCI_VIRT_CONFIG1_BASE;
    type1Address.u.bits.Bus = BusNumber;
    type1Address.u.bits.Device = SlotNumber.u.bits.DeviceNumber;
    type1Address.u.bits.Function =  SlotNumber.u.bits.FunctionNumber;

    //
    // Loop through the config space starting at offset. For each new
    // position in config space perform a long, short or char word
    // operation.
    //
    EndOffset = Offset + Length;
    CurrentOffset = Offset;
    CurrentData = (PUCHAR)Buffer;

    while(1)
    {
        //
        // Determine the maximum number of bytes we can read based on how
        // many bytes we have left to write in the buffer.
        //
        MaxWriteLen = EndOffset - CurrentOffset;

        //
        // If we can't write any more bytes, we know we're done.
        //
        if(MaxWriteLen == 0)
                break;

        type1Address.u.bits.Register = CurrentOffset / sizeof(ULONG);

        //
        // If we can't read more than 1 byte or if the alignment of
        // our current offset is no better than byte aligned, do a 
        // byte operation.
        //  

        if((MaxWriteLen <= 1) || (CurrentOffset & 0x01) )
        {
        	printf("ReadUchar\r\n"); 
            Diff = CurrentOffset & 0x03;

            *((PUCHAR)CurrentData) = *(PUCHAR)(type1Address.u.AsULONG + Diff);

            if (CheckForAbort())
                *((PUCHAR)CurrentData) = ~0;

            //
            // Update the iterators.
            //
            CurrentOffset += 1;
            CurrentData += 1;
        }

        //
        // If we can't write more than 3 byte or if the alignment of
        // our current offset is no better than short aligned, do a 
        // short operation.
        //

        else if((MaxWriteLen <= 3) || (CurrentOffset & 0x02) )
        {
            Diff = CurrentOffset & 0x02;
            
        printf("ReadUshort @ %x\r\n",(type0Address.u.AsULONG + Diff),CurrentData);      

            *(PUSHORT)CurrentData = *(PUSHORT)(type1Address.u.AsULONG + Diff);

            if (CheckForAbort())
                *((PUSHORT)CurrentData) = ~0;

            //
            // Update the iterators.
            //
            CurrentOffset += 2;
            CurrentData += 2;
        }

        //
        // At this point we know there are at least 4 bytes to write and
        // the current offset is long aligned so do a long operation.
        //

        else
        {
            *(PULONG)CurrentData = *(PULONG)type1Address.u.AsULONG;

            if (CheckForAbort())
                *((PULONG)CurrentData) = ~0;

            //
            // Update the iterators.
            //
            CurrentOffset += 4;
            CurrentData += 4;
        }
    }

    WriteAmount = CurrentOffset - Offset;
          
    return WriteAmount;
}


ULONG
PCIWriteBusData(
    IN ULONG BusNumber,
    IN PCI_SLOT_NUMBER SlotNumber,
    IN PVOID Buffer,
    IN ULONG Offset,
    IN ULONG Length
    )

/*++

Description:

    Writes PCI configuration data to the bus.  Note, this routine does not
    synchronize the access to the PCI bus.

Arguments:

    BusNumber - PCI bus number.

    SlotNumber - PCI slot number.

    Buffer - Buffer to write data to.

    Offset - Byte offset where data should start.

    Length - Length of data to read.

Returns:

    Amount of data read from the bus.

--*/

{
    ULONG MaxWriteLen;
    PUCHAR CurrentData;
    ULONG CurrentOffset;      
    ULONG EndOffset;
    ULONG WriteAmount;
    TYPE1_PCI_ADDRESS type1Address;
    ULONG Diff;

    //
    // Fill in bus, device, and function information.
    // To map the physcial location
    //
    type1Address.u.AsULONG = PCI_VIRT_CONFIG1_BASE;
    type1Address.u.bits.Bus = BusNumber;
    type1Address.u.bits.Device = SlotNumber.u.bits.DeviceNumber;
    type1Address.u.bits.Function =  SlotNumber.u.bits.FunctionNumber;

    printf("PCIRead @ VIRT:%x\r\n", type1Address.u.AsULONG);  
    //
    // Loop throught the config space starting at offset. For each new
    // position in config space perform a long, short or char word
    // operation.
    //

    //
    // Setup loop.
    //

    EndOffset = Offset + Length;
    CurrentOffset = Offset;
    CurrentData = (PUCHAR)Buffer;

    while(1)
    {
        //
        // Determine the maximum number of bytes we can read based on how
        // many bytes we have left to write in the buffer.
        //

        MaxWriteLen = EndOffset - CurrentOffset;

        //
        // If we can't write any more bytes, we know we're done.
        //
        if(MaxWriteLen == 0)
          break;

        //
        // Setup the config space address register.
        //

        type1Address.u.bits.Register = CurrentOffset / sizeof(ULONG);

        //
        // If we can't read more than 1 byte or if the alignment of
        // our current offset is no better than byte aligned, do a 
        // byte operation.
        //  

        if((MaxWriteLen <= 1) || (CurrentOffset & 0x01) )
        {
          Diff = CurrentOffset & 0x03;
          
          *(PUCHAR)(type1Address.u.AsULONG + Diff) = *(PUCHAR)CurrentData;
          
          //
          // Update the iterators.
          //
          CurrentOffset += 1;
          CurrentData += 1;
        }

        //
        // If we can't write more than 3 byte or if the alignment of
        // our current offset is no better than short aligned, do a 
        // short operation.
        //
        else if((MaxWriteLen <= 3) || (CurrentOffset & 0x02) )
        {
          Diff = CurrentOffset & 0x02;
          
          *(PUSHORT)(type1Address.u.AsULONG + Diff) = *(PUSHORT)CurrentData;
          
          //
          // Update the iterators.
          //
          CurrentOffset += 2;
          CurrentData += 2;
        }

        //
        // At this point we know there are at least 4 bytes to write and
        // the current offset is long aligned so do a long operation.
        //

        else
        {
          *(PULONG)type1Address.u.AsULONG = *(PULONG)CurrentData; 
          
          //
          // Update the iterators.
          //
          CurrentOffset += 4;
          CurrentData += 4;
        }
    }

    WriteAmount = CurrentOffset - Offset;
      
    return WriteAmount;
}

#endif // Type1


VOID
PCIInitBusInfo(
    VOID
    )

/*++

Routine Description:

    Initializes the PCI bus and configuration data for use.

Arguments:

    None.

Returns:

    None.

--*/

{
  PCI_COMMON_CONFIG pciCommonConfig;
  PCI_SLOT_NUMBER   SlotNumber;
  USHORT            bus, device;
  DWORD             dwResult;

  //
  // See if the bus has been initialized.
  //

  if ( bPCIInitialized )
    return;

  bPCIInitialized = TRUE;

  InitializeCriticalSection(&csPCIConfig);

RETAILMSG(1,(L"PCIInintBusInfo\r\n"));

  //
  // Enumerate the PCI bus.
  //

  ucPCIMaxBus = 1;
  SlotNumber.u.bits.FunctionNumber = 0;

  for ( bus = 0; bus < ucPCIMaxBus; bus++ )
  {
    for ( device = 0; device < ucPCIMaxDeviceNumber; device++ )
    {
      SlotNumber.u.bits.DeviceNumber = device;

      dwResult = PCIReadBusData(bus,
				SlotNumber,
				&pciCommonConfig,
				0,
				offsetof(PCI_COMMON_CONFIG, u.type1.IOBase));

      if ( pciCommonConfig.VendorID != 0xFFFF )
      {
	
	//
        // A device has been found.
        //

	if ( ucPCIMaxDevice[bus] <= device )
	{
	  ucPCIMaxDevice[bus] = device + 1;
	}

	if ( bus == 0 && (pciCommonConfig.HeaderType & 0x7F) == 1 )
	{
	  //
	  // It is a bridge.
	  //

	  if ( ucPCIMaxBus <= pciCommonConfig.u.type1.SubordinateBusNumber )
	  {
	    //
            // Get the new max bus number from the bridge.
            //

            ucPCIMaxBus = pciCommonConfig.u.type1.SubordinateBusNumber + 1;

	    if ( ucPCIMaxBus > (MAX_SUPPORTED_PCI_BUS + 1) )
	    {
	      
	      DEBUGMSG(1, (TEXT("Error: Too many PCI busses\r\n")));
	      ucPCIMaxBus = MAX_SUPPORTED_PCI_BUS + 1;
	    }
	  }
	}
      }
    }
  }

  //
  // See if any buses or devices have been found.
  //

  if ( ucPCIMaxBus == 1 && ucPCIMaxDevice[0] == 0 )
  {
    ucPCIMaxBus = (UCHAR)~0;
  }
}


ULONG
PCIGetBusDataByOffset(
    IN ULONG BusNumber,
    IN ULONG Slot,
    IN PVOID Buffer,
    IN ULONG Offset,
    IN ULONG Length
    )

/*++

Routine Description:

    Reads PCI configuration data from the bus.  Note, this routine synchronizes
    the access to the PCI bus.

Arguments:

    BusNumber - PCI bus number.

    Slot - PCI slot number.

    Buffer - Buffer to read data to.

    Offset - Byte offset where data should start.

    Length - Length of data to read.

Returns:

    Amount of data read from the bus.

--*/

{
  PCI_SLOT_NUMBER SlotNumber;

  //
  // See if the PCI bus has been initialized.
  //
  if ( bPCIInitialized == FALSE )
  {
      PCIInitBusInfo();
  }
  
  //
  // Check the bus number.
  //

  if ( ucPCIMaxBus == (UCHAR)~0U || BusNumber >= ucPCIMaxBus )
    return (0);

  //
  // Check the slot number.
  //

  SlotNumber.u.AsULONG = Slot;

  if ( SlotNumber.u.bits.DeviceNumber >= ucPCIMaxDeviceNumber )
    return (0);

  //
  // Synchronize access to the PCI bus.
  //
  EnterCriticalSection(&csPCIConfig);

  Length = PCIReadBusData(BusNumber,
			  SlotNumber,
			  Buffer,
			  Offset,
			  Length);

  LeaveCriticalSection(&csPCIConfig);

  return (Length);
}


ULONG
PCISetBusDataByOffset(
    IN ULONG BusNumber,
    IN ULONG Slot,
    IN PVOID Buffer,
    IN ULONG Offset,
    IN ULONG Length
    )

/*++

Routine Description:

    Writes PCI configuration data to the bus.  Note, this routine synchronizes
    access to the PCI bus.

Arguments:

    BusNumber - PCI bus number.

    Slot - PCI slot number.

    Buffer - Buffer to write from.

    Offset - Byte offset where data should start.

    Length - Length of data to write.

Returns:

    Amount of data written to the bus.

--*/

{
  PCI_SLOT_NUMBER SlotNumber;

  //
  // See if the PCI bus has been initialized.
  //
  if ( bPCIInitialized == FALSE )
    PCIInitBusInfo();

  //
  // Check for valid bus number.
  //

  if ( ucPCIMaxBus == (UCHAR)~0U || BusNumber >= ucPCIMaxBus )
    return (0);
 
  //
  // Check for valid slot number.
  //

  SlotNumber.u.AsULONG = Slot;

  if ( SlotNumber.u.bits.DeviceNumber >= ucPCIMaxDeviceNumber )
    return (0);

  //
  // Synchronize access to the PCI bus.
  //

  EnterCriticalSection(&csPCIConfig);

  Length = PCIWriteBusData(BusNumber,
			   SlotNumber,
			   Buffer,
			   Offset,
			   Length);  

  LeaveCriticalSection(&csPCIConfig);
  
  return (Length);
}

#endif // PCI_PHYS_ADDR


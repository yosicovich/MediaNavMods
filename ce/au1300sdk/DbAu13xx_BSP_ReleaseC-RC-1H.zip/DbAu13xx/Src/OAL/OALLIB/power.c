/*++
    Copyright (c) 2001-2005  BSQUARE Corporation.  All rights reserved.

Module Name:

    power.c

Abstract:


Author:

--*/

#include "bsp.h"
#include "platform.h"
#include "Halether.h"
#include <ldrarg.h>
#include <bldver.h>

extern EDBG_ADAPTER Adapter;

#ifdef DMA0_PHYS_ADDR
static AU1X00_DMA   *Dma       = (AU1X00_DMA *)(DMA0_PHYS_ADDR + KSEG1_OFFSET);

// Storage holder for DMA across sleep
//
static struct _DMAState {
    unsigned long mode;
    unsigned long peraddr;
    unsigned long buf0addr;
    unsigned long buf0size;
    unsigned long buf1addr;
    unsigned long buf1size;
} DMAState[NUM_DMA_CHANNELS];
#endif

#ifdef DDMA_PHYS_ADDR
static AU1X00_DDMA *DDMARegs = (AU1X00_DDMA*)(DDMA_PHYS_ADDR + KSEG1_OFFSET);

static struct _DDMAState {
	struct {
		ULONG cfg;
		ULONG des_ptr;
	} channel[DDMA_NUM_CHANNELS];
	ULONG config;
	ULONG throttle;
	ULONG inten;
} DDMAState;
#endif

#ifdef GPIO2_PHYS_ADDR
static AU1X00_GPIO2 *GPIO2Regs = (AU1X00_GPIO2 *)(GPIO2_PHYS_ADDR + KSEG1_OFFSET);

static struct {
    ULONG dir;
    ULONG output;
    ULONG pinstate;
    ULONG inten;
} Gpio2State;
#endif

#ifdef PLATFORM_POWER_EXT_ISR_DATA
	PLATFORM_POWER_EXT_ISR_DATA;
#endif


//
// Storage holder for GPIO register set across sleep.
//
static struct _GpioState {
    ULONG ulPinFunc;
    ULONG ulOutputRd;
	ULONG triState;
} GpioState;

//
// Storage holder for the system control registers across sleep.
// Most registers are preserved by the hardware, but unfortunately
// we come through the bootloader's reset path which modifies them.
//
static struct _SystemState {
    ULONG freqctrl0;
    ULONG freqctrl1;
    ULONG clksrc;
	ULONG auxpll;
	ULONG auxpll2;
} SystemState;


//
extern void OEMCacheRangeFlush(LPVOID pAddr, DWORD dwLength, DWORD dwFlags);
extern VOID StoreIntrRegState(VOID);
extern VOID RestoreIntrState(VOID);


VOID
StoreGPIOState(
    VOID
    )
{
#if !defined(SOC_AU13XX)
    GpioState.ulPinFunc = Sys->pinfunc;
    GpioState.ulOutputRd = Sys->outputrd;
	GpioState.triState = Sys->trioutrd;

#ifdef GPIO2_PHYS_ADDR
    Gpio2State.dir = GPIO2Regs->dir;
    Gpio2State.output = GPIO2Regs->output;
    Gpio2State.pinstate = GPIO2Regs->pinstate;
    Gpio2State.inten = GPIO2Regs->inten;
#endif
#endif
}



VOID
RestoreGPIOState(
    VOID
    )
{
#if !defined(SOC_AU13XX)
// NOTE: All GPIO setup is done in reset_X.s file!!!
    Sys->pinfunc = GpioState.ulPinFunc;
    Sys->outputset = GpioState.ulOutputRd & GpioState.triState;
	Sys->pininputen = 0;

#ifdef GPIO2_PHYS_ADDR
    GPIO2Regs->dir = Gpio2State.dir;
    GPIO2Regs->output = Gpio2State.output << 16 || Gpio2State.output ;
    GPIO2Regs->inten = Gpio2State.inten;
#endif
#endif
}

VOID
StoreSystemState(VOID)
{
    SystemState.freqctrl0 = Sys->freqctrl0;
    SystemState.clksrc    = Sys->clksrc;
	SystemState.auxpll    = Sys->auxpll;
	SystemState.auxpll2    = Sys->auxpll2;
	SystemState.freqctrl1	= Sys->freqctrl1;
}

VOID
RestoreSystemState(VOID)
{
	Sys->clksrc = SystemState.clksrc;
	Sys->freqctrl0 = SystemState.freqctrl0;

	Sys->auxpll	= SystemState.auxpll;
	Sys->auxpll2 = SystemState.auxpll2;
	Sys->freqctrl1 = SystemState.freqctrl1;

    Sys->wakesrc = 0;
}


VOID
StoreDMAState(VOID)
{
#ifdef DMA0_PHYS_ADDR
    ULONG i;
    ULONG Timeout;

    for (i=0;i<NUM_DMA_CHANNELS;i++) {

        //
        // Halt the DMA (it should already be halted by now)
        //
        Dma[i].modeclr = DMA_MODE_G;
        Timeout = 10000;
        while (Timeout-- && 0 == (Dma[i].moderead & DMA_MODE_H));


        DMAState[i].mode        = Dma[i].moderead;
        DMAState[i].peraddr     = Dma[i].peraddr;
        DMAState[i].buf0addr    = Dma[i].buf0addr;
        DMAState[i].buf0size    = Dma[i].buf0size;
        DMAState[i].buf1addr    = Dma[i].buf1addr;
        DMAState[i].buf1size    = Dma[i].buf1size;
    }
#endif
#ifdef DDMA_PHYS_ADDR
	ULONG i;

	for (i=0;i<DDMA_NUM_CHANNELS;i++) {
		// Store state
		DDMAState.channel[i].cfg     = DDMARegs->channel[i].cfg;
		DDMAState.channel[i].des_ptr = DDMARegs->channel[i].des_ptr;

		// Stop DDMA
		DDMARegs->channel[i].cfg &= ~DDMA_CHANCFG_EN;
		// Wait for halt bit
		while(!(DDMARegs->channel[i].stat & DDMA_CHANSTATUS_H)) {
			;
		}
	}
	DDMAState.config   = DDMARegs->config;
	DDMAState.throttle = DDMARegs->throttle;
	DDMAState.inten    = DDMARegs->inten;
#endif
}

VOID
RestoreDMAState(VOID)
{
#ifdef DMA0_PHYS_ADDR
    ULONG i;

    for (i=0;i<NUM_DMA_CHANNELS;i++) {
        Dma[i].modeset = DMAState[i].mode;
        Dma[i].peraddr =  DMAState[i].peraddr;
        Dma[i].buf0addr = DMAState[i].buf0addr;
        Dma[i].buf0size = DMAState[i].buf0size;
        Dma[i].buf1addr = DMAState[i].buf1addr;
        Dma[i].buf1size = DMAState[i].buf1size;
   }
#endif
#ifdef DDMA_PHYS_ADDR
	ULONG i;

	for (i=0;i<DDMA_NUM_CHANNELS;i++) {
		// Restore state
		DDMARegs->channel[i].cfg     = DDMAState.channel[i].cfg;
		DDMARegs->channel[i].des_ptr = DDMAState.channel[i].des_ptr;
	}

	DDMARegs->config   = DDMAState.config;
	DDMARegs->throttle = DDMAState.throttle;
	DDMARegs->inten    = DDMAState.inten;
#endif
}

/*++

Routine Description:

    This routine is called when the kernel is requesting that the system
    be powered down.  Any OAL specific powerdown should be performed and
    then the system should be brought to a power down state.

Arguments:

    None.

Return Value:

    None.

--*/
extern void DoResume(void);
VOID
OEMPowerOff(
    VOID
    )
{
    DWORD dwPriorInterruptState=0;
    DWORD tmp=0;

#if (0)		// temporary debug code
    OEMWriteDebugString(L"OemPowerOff: Skipping power off to see if we come back up...\r\n");
    return;
#endif

    OEMWriteDebugString(L"OemPowerOff: \r\n");
    //
    // Resume address goes into scratch1
    //

    Sys->scratch1 = (ULONG)DoResume;

	bootupType = HAL_SUSPENDRESUME_BOOT;

	//
    // Take care of the current DMA state
    //
    StoreDMAState();

    //
    // The GPIO Pin functionality is set to a default state after
    // awakening from sleep. Preserve it before sleeping so it can be restored.
    //
    StoreGPIOState();

    //
    // The interrupt controllers must be preserved as well.
    //
    StoreIntrRegState();

	// Provide a hook for saving state of external interrupt controller
	// PlatSpecificTemp is available for this purpose
#ifdef PLATFORM_POWER_EXT_ISR_SAVE_CODE
	PLATFORM_POWER_EXT_ISR_SAVE_CODE
#endif

    //
    // Some system registers (though preserved by sleep) are modified by
    // the bootloader path.
    //
    StoreSystemState();

	//
    // sys_gpinputen is a 32 bit write only register. GPIOs cannot be
    // used as inputs (interrupt source) until this register is written as 0.
    //
    Sys->pininputen = 0;

    //
    // Notify scratch0 that the system is going from on-to-suspend state.
    //
    Sys->scratch0 = HAL_SUSPENDRESUME_BOOT;

    //
    // Save all registers, TLB, flush caches and go to SLEEP.
    //
    OEMCPUPowerOff();

    dwPriorInterruptState = DISABLE_INTERRUPTS();

	OEMCacheRangeFlush(NULL, 0, CACHE_SYNC_WRITEBACK|CACHE_SYNC_INSTRUCTIONS);

	Sys->scratch0 = 0;

    //
    // We're awake.
    //
    OEMInitDebugSerial();
    OEMWriteDebugString(L"\r\nOemPowerOff: Awakened!\r\n");


    RestoreSystemState();

    //
    // Clear the wakeup cause register.
    //
    Sys->wakesrc = 0;
    Sys->scratch0 = HAL_COLD_BOOT;

	// Provide a hook for restoring state of external interrupt controller
	// PlatSpecificTemp is available for this purpose
#ifdef PLATFORM_POWER_EXT_ISR_RESTORE_CODE
	PLATFORM_POWER_EXT_ISR_RESTORE_CODE
#endif

    //
    // Restore the interrupt controller registers.
    // Mask off interrupts for this operation.
    // Restore the other controllers too
    //

    RestoreGPIOState();
    RestoreIntrState();
	RestoreDMAState();

    RESTORE_INTERRUPTS(dwPriorInterruptState);

    OEMWriteDebugString(L"\r\nOemPowerOff: Awakened!\r\n");
}


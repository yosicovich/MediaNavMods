/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
#include <windows.h>
#include "bceddk.h"
#include "bsp.h"

#include "oemioctl.h"
#include "ioctl_cfg.h"
#include <oal_ioctl.h>
#include <oal_intr.h>
#include <oal_cache.h>
#include "pci.h"

#include "platform.h"
#include <ldrarg.h>

#include "ethdbg.h"

#include <oal_io.h>
#include <oal_log.h>

#define ZONE_IOCTL 1

//////////////////implement IOCTL_HAL_REBOOT//////////////
static BOOT_ARGS *pBootArgs = (BOOT_ARGS*)(BOOT_ARG_PTR + KSEG1_OFFSET);
typedef void (*PFI)(void);
static PFI Reboot = (PFI)0xBFC00000;
extern void StartUp(void);
/////////////////////////////////////////////////////////

/* Timers.c IOCTL support routines */
extern BOOL OALIoCtlConnectTimer(UINT32, VOID*, UINT32, VOID*, UINT32, UINT32*);
extern BOOL OALIoCtlDisconnectTimer(UINT32, VOID*, UINT32, VOID*, UINT32, UINT32*);
extern BOOL OALIoCtlStartTimer(UINT32, VOID*, UINT32, VOID*, UINT32, UINT32*);
extern BOOL OALIoCtlStopTimer(UINT32, VOID*, UINT32, VOID*, UINT32, UINT32*);


static DWORD g_dwEventBuffer[IOCTL_EVENT_BUFFER_SIZE];
static int g_iEventBufferIndex;

//------------------------------------------------------------------------------
//
//  Global: g_oalIoctlPlatformType/OEM
//
//  Platform Type/OEM
//
LPCWSTR g_oalIoCtlPlatformType = IOCTL_PLATFORM_TYPE;
LPCWSTR g_oalIoCtlPlatformOEM  = IOCTL_PLATFORM_OEM;

//------------------------------------------------------------------------------
//
//  Global: g_oalIoctlProcessorVendor/Name/Core
//
//  Processor information
//
LPCWSTR g_oalIoCtlProcessorVendor = IOCTL_PROCESSOR_VENDOR;
LPCWSTR g_oalIoCtlProcessorName   = IOCTL_PROCESSOR_NAME;
LPCWSTR g_oalIoCtlProcessorCore   = IOCTL_PROCESSOR_CORE;

//------------------------------------------------------------------------------
//
//  Global: g_oalIoctlInstructionSet
//
//  Processor instruction set identifier
//
UINT32 g_oalIoCtlInstructionSet = IOCTL_PROCESSOR_INSTRUCTION_SET;
UINT32 g_oalIoCtlClockSpeed = IOCTL_PROCESSOR_CLOCK_SPEED;

//------------------------------------------------------------------------------
//
//  Global:  g_ioctlState;
//
//  This state variable contains critical section used to serialize IOCTL
//  calls.
//
static struct {
    BOOL postInit;
    CRITICAL_SECTION cs;
} g_ioctlState = { FALSE };


//------------------------------------------------------------------------------
//
//  Function:  OEMIoControl
//
//  The function is called by kernel a device driver or application calls
//  KernelIoControl. The system is fully preemtible when this function is
//  called. The kernel does no processing of this API. It is provided to
//  allow an OEM device driver to communicate with kernel mode code.
//
BOOL OEMIoControl(
    DWORD code, VOID *pInBuffer, DWORD inSize, VOID *pOutBuffer, DWORD outSize,
    DWORD *pOutSize
) {
    BOOL rc = FALSE;
    UINT32 i;

    OALMSG(OAL_IOCTL&&OAL_FUNC, (
        L"+OEMIoControl(0x%x, 0x%x, %d, 0x%x, %d, 0x%x)\r\n",
        code, pInBuffer, inSize, pOutBuffer, outSize, pOutSize
    ));

    //Initialize g_ioctlState.cs when IOCTL_HAL_POSTINIT is called. By this time,
    //the kernel is up and ready to handle the critical section initialization.
    if (!g_ioctlState.postInit && code == IOCTL_HAL_POSTINIT) {
        // Initialize critical section
        InitializeCriticalSection(&g_ioctlState.cs);
        g_ioctlState.postInit = TRUE;
    }

    // Search the IOCTL table for the requested code.
    for (i = 0; g_oalIoCtlTable[i].pfnHandler != NULL; i++) {
        if (g_oalIoCtlTable[i].code == code) break;
    }

    // Indicate unsupported code
    if (g_oalIoCtlTable[i].pfnHandler == NULL) {
        NKSetLastError(ERROR_NOT_SUPPORTED);
        OALMSG(OAL_IOCTL, (
            L"OEMIoControl: Unsupported Code 0x%x - device 0x%04x func %d\r\n",
            code, code >> 16, (code >> 2)&0x0FFF
        ));
        goto cleanUp;
    }

    // Take critical section if required (after postinit & no flag)
    if (
        g_ioctlState.postInit &&
        (g_oalIoCtlTable[i].flags & OAL_IOCTL_FLAG_NOCS) == 0
    ) {
        // Take critical section
        EnterCriticalSection(&g_ioctlState.cs);
    }

    // Execute the handler
    rc = g_oalIoCtlTable[i].pfnHandler(
        code, pInBuffer, inSize, pOutBuffer, outSize, pOutSize
    );

    // Release critical section if it was taken above
    if (
        g_ioctlState.postInit &&
        (g_oalIoCtlTable[i].flags & OAL_IOCTL_FLAG_NOCS) == 0
    ) {
        // Release critical section
        LeaveCriticalSection(&g_ioctlState.cs);
    }

cleanUp:
    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"-OEMIoControl(rc = %d)\r\n", rc ));
    return rc;
}



//------------------------------------------------------------------------------
//
//  Function:  OALIoCtlHalInitRTC
//
//  This function is called by WinCE OS to initialize the time after boot.
//  Input buffer contains SYSTEMTIME structure with default time value.
//  If hardware has persistent real time clock it will ignore this value
//  (or all call).
//
BOOL OALIoCtlHalInitRTC(
    UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    BOOL rc = FALSE;
    SYSTEMTIME *pTime = (SYSTEMTIME*)pInpBuffer;

    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"+OALIoCtlHalInitRTC(...)\r\n"));

    if(pOutSize) {
        *pOutSize = 0;
    }

    // Validate inputs
    if (pInpBuffer == NULL || inpSize < sizeof(SYSTEMTIME)) {
        OALMSG(OAL_ERROR, (
            L"ERROR: OALIoCtlHalInitRTC: INVALID PARAMETER\r\n"
        ));
        goto cleanUp;
    }

    rc = OEMInitRealTime(pTime);

cleanUp:
    OALMSG(OAL_IOCTL&&OAL_FUNC, (L"-OALIoCtlHalInitRTC(rc = %d)\r\n", rc));
    return rc;
}

//------------------------------------------------------------------------------
//
//  Function:  OALIoCtlHalPresuspend
//
BOOL OALIoCtlHalPresuspend(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {

    NKSetLastError( ERROR_NOT_SUPPORTED );
    return FALSE;
}

//------------------------------------------------------------------------------
//
//  Function:  OALIoCtlHalEnableWake
//
BOOL OALIoCtlHalEnableWake(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    NKSetLastError( ERROR_NOT_SUPPORTED );
    return FALSE;
}

//------------------------------------------------------------------------------
//
//  Function:  OALIoCtlHalDisableWake
//
BOOL OALIoCtlHalDisableWake(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    NKSetLastError( ERROR_NOT_SUPPORTED );
    return FALSE;
}

//------------------------------------------------------------------------------
//
//  Function:  OALIoCtlHalDisableWake
//
BOOL OALIoCtlHalGetWakeSource(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    NKSetLastError( ERROR_NOT_SUPPORTED );
    return FALSE;
}

static BOOL
OALIoCtlHalReboot(
    UINT32 code, VOID *pInpBuffer, UINT32 inpSize, VOID *pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
)
{
	RETAILMSG(1,(TEXT("OALIoCtlHalReboot\r\n")));
	// If bootarg signature is correct then jump to the loader,
	// otherwise restart CE

	// If KITL is not in the image then surely

	Sys->scratch0 = HAL_WARM_BOOT;

	if (BOOTARG_SIG == pBootArgs->dwSig && pBootArgs->dwLaunchAddr) {
		Reboot = (PFI)StartUp; // Jump into CE
#if 0
	    if (!gKITLIsPresent) {
	        // did not request to start KITL
	        NKDbgPrintfW(L"KitlTransport not requested - calling OEMStartup\r\n");
	        Reboot = (PFI)StartUp; // Jump into CE
	    } else {

	        Sys->scratch1 = pBootArgs->dwLaunchAddr;

	        RETAILMSG(1,(L"Eboot Reset\r\n"));
	        // Jump into eboot
	        Reboot = (PFI)0xBFC00000;
	    }
#endif
	} else {
	    Sys->scratch1 = (ULONG)StartUp;
	    Reboot = (PFI)StartUp; // Jump into CE
	    RETAILMSG(1,(L"Soft Reset\r\n"));
	}

	// reboot the system.. jump to boot base of the flash 0xBFC00000
	Reboot();

	// will never reach here
	return TRUE;
}


BOOL OALIoCtlHalPostInit(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    OALMSG(OAL_FUNC, (L"+OALIoCtlHalPostInit\r\n"));

    OALMSG(OAL_FUNC, (L"-OALIoCtlHalPostInit\r\n"));
    return TRUE;
}

BOOL OALIoCtlOemGetPeripheralInfo(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize )
{
	BOOL return_value = TRUE;
	UINT32	*pValue = (UINT32 *) pOutBuffer;
	UINT32	*pRegisterCode = (UINT32 *) pInpBuffer;
//	volatile UINT32	*pRegisterAddress;

	*pOutSize = sizeof(UINT32);

	if ( (NULL != pValue) && (NULL != pRegisterCode) )
	{
		switch (*pRegisterCode)
		{
		case GET_PERIPHERAL_INFO_3D_GP_ID:
			//pRegisterAddress = (UINT32 *)(MALI_GP2_PHYS_ADDR + MALI_GP2_ID_OFFSET + KSEG1_OFFSET);
			//*pValue = *pRegisterAddress;
			*pValue = PERIPHERAL_INFO_3D_GP_ID;
			break;
		case GET_PERIPHERAL_INFO_3D_PP_ID:
			//pRegisterAddress = (UINT32 *)(MALI_PP_PHYS_ADDR + MALI_PP_ID_OFFSET + KSEG1_OFFSET );
			//*pValue = *pRegisterAddress;
			*pValue = PERIPHERAL_INFO_3D_PP_ID;
			break;
		case GET_PERIPHERAL_INFO_OTG_ID:
			//pRegisterAddress = (UINT32 *)(OTG_PHYS_ADDR + OTG_ID_OFFSET + KSEG1_OFFSET);
			//*pValue = *pRegisterAddress;
			*pValue = PERIPHERAL_INFO_OTG_ID;
			break;
		case GET_PERIPHERAL_INFO_OTG_CONFIG1:
			//pRegisterAddress = (UINT32 *)(OTG_PHYS_ADDR + OTG_CONFIG1_OFFSET + KSEG1_OFFSET);
			//*pValue = *pRegisterAddress;
			*pValue = PERIPHERAL_INFO_OTG_CONFIG1;
			break;
		case GET_PERIPHERAL_INFO_OTG_CONFIG2:
			//pRegisterAddress = (UINT32 *)(OTG_PHYS_ADDR + OTG_CONFIG2_OFFSET + KSEG1_OFFSET);
			//*pValue = *pRegisterAddress;
			*pValue = PERIPHERAL_INFO_OTG_CONFIG2;
			break;
		case GET_PERIPHERAL_INFO_OTG_CONFIG3:
			//pRegisterAddress = (UINT32 *)(OTG_PHYS_ADDR + OTG_CONFIG3_OFFSET + KSEG1_OFFSET);
			//*pValue = *pRegisterAddress;
			*pValue = PERIPHERAL_INFO_OTG_CONFIG3;
			break;
		case GET_PERIPHERAL_INFO_OTG_CONFIG4:
			//pRegisterAddress = (UINT32 *)(OTG_PHYS_ADDR + OTG_CONFIG4_OFFSET + KSEG1_OFFSET);
			//*pValue = *pRegisterAddress;
			*pValue = PERIPHERAL_INFO_OTG_CONFIG4;
			break;
		case GET_PERIPHERAL_INFO_CP0_CONFIG1:
			*pValue = PERIPHERAL_INFO_CP0_CONFIG1;
			break;
		default:
			*pOutSize = 0;
			return_value = FALSE;
			break;
		}
	}

	return return_value;
}

BOOL OALIoCtlOemGetSystemID(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize )
{
	OTP		 *otp = (OTP*)(OTP_PHYS_ADDR + KSEG1_OFFSET);
	SYSTEMID *id=(PSYSTEMID)pOutBuffer;
	BCSR     *brd=(BCSR*)BCSR_KSEG1_ADDR;
	int value;
	unsigned int * pGUID;

	if (id && (outSize >= sizeof(SYSTEMID)))
	{
		/* Return the CP0 scratch in Reserved0 */
	    __asm("mfc0 t1, $22\n");
	    __asm("sw t1, 0(%0)\n", &value);
		id->reserved0 = value;

	    __asm("mfc0 t1, $15\n");
	    __asm("sw t1, 0(%0)\n", &value);
		id->prid = value;

		id->brdid = brd->whoami;

		// Fill in the GUID for the processor
		// Zero it out first
		memset(id->guid, 0x00, sizeof(id->guid));
		pGUID = (unsigned int*)&(id->guid[0]);
		*(pGUID++)	= otp->config0;
		*(pGUID++)	= otp->ChipIDLo;
		*pGUID		= otp->ChipIDHi;

		*pOutSize = sizeof(SYSTEMID);
	}
	else
		*pOutSize = 0;

    return TRUE;
}

/*****************************************************************************
						Frequency Releated IOCTL
******************************************************************************/
BOOL OALIoCtlOemGetCPUFrequency(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize )
{
	*((ULONG*)pOutBuffer) = OEMGetCpuFrequency();
	*pOutSize = sizeof(ULONG);

	return TRUE;
}

BOOL OALIoCtlOemGetPBUSFrequency(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize )
{
	*((ULONG*)pOutBuffer) = OEMGetPBUSFrequency();
	*pOutSize = sizeof(ULONG);
	return TRUE;
}

/*****************************************************************************
						TLB/MEMORY Releated IOCTL
******************************************************************************/
BOOL OALIoCtlOemAddWiredTLB(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize )
{
	extern int CP0AddWiredTLB(ULONG EntryHi, ULONG EntryLo0, ULONG EntryLo1, ULONG PageMask);
	ULONG IntrState;
	int wired;

	ADD_WIRED_TLB_IOCTL_PARAM *Param;
	Param = (ADD_WIRED_TLB_IOCTL_PARAM*)pInpBuffer;

	IntrState=DISABLE_INTERRUPTS();

	wired = CP0AddWiredTLB(Param->EntryHi,
		Param->EntryLo0,
		Param->EntryLo1,
		Param->PageMask);

	RESTORE_INTERRUPTS(IntrState);

	*(PULONG)pOutBuffer = (ULONG)wired;
	*pOutSize = sizeof(ULONG);
	return TRUE;
}


/*****************************************************************************
						VSS(Power) Control IOCTL
******************************************************************************/
BOOL OALIoCtlOemVSS(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize )
{
	if (pInpBuffer && (inpSize >= sizeof(GPINTRREQ)))
	{
		AU13XX_VSS_BLOCK *pVSS;
		VSSREQ *pReq = (VSSREQ*)pInpBuffer;
		ULONG IntrState;

		DEBUGMSG(1,(TEXT("OALIoCtlOemVSS: block:%d enable:%d\r\n"),
			pReq->block, pReq->enable ));

		IntrState=DISABLE_INTERRUPTS();

		/* Make sure our pVSS pointer is operating on the
		 * desired block
		 */
		pVSS = (AU13XX_VSS_BLOCK*) \
			(VSS_PHYS_ADDR +
			 sizeof(AU13XX_VSS_BLOCK) * pReq->block +
			 KSEG1_OFFSET );

	    if ( pReq->enable )
		{
			pVSS->clkrst = 3;
			WBSYNC();

			pVSS->gate = 0x01fffffe;
			pVSS->ftr = 1;
			pVSS->ftr = 3;
			pVSS->ftr = 7;
			pVSS->ftr = 0xf;
			WBSYNC();

			pVSS->gate = 0x01fffffF;
			WBSYNC();

			pVSS->clkrst = 2;
			WBSYNC();

			pVSS->ftr = 0x1f;
			WBSYNC();
		}
		else {
			pVSS->ftr 	 = 0xF;
			WBSYNC();
			pVSS->gate 	 = 0;
			WBSYNC();
			pVSS->clkrst = 2;
			WBSYNC();
			pVSS->clkrst = 1;
			WBSYNC();
			pVSS->ftr    = 0;
			WBSYNC();
		}

		RESTORE_INTERRUPTS(IntrState);
	}

	if ( pOutSize )
		*pOutSize = 0;
	return TRUE;
}

// Basic logging routines - no error checking

extern BOOL OEMQueryPerformanceCounter(LARGE_INTEGER *);

BOOL OALIoCtlMarkEv(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize )
{
	LARGE_INTEGER t1, t2;
	OEMQueryPerformanceCounter( &t1 );
	OEMQueryPerformanceCounter( &t2 );

	if (t1.QuadPart < t2.QuadPart)
	{
		g_dwEventBuffer[g_iEventBufferIndex++] = t2.u.LowPart;
		g_dwEventBuffer[g_iEventBufferIndex++] = t2.u.HighPart;
	}
	else
	{
		g_dwEventBuffer[g_iEventBufferIndex++] = t1.u.LowPart;
		g_dwEventBuffer[g_iEventBufferIndex++] = t1.u.HighPart;
	}

	g_dwEventBuffer[g_iEventBufferIndex++] = * (DWORD *) pInpBuffer;
	g_dwEventBuffer[g_iEventBufferIndex++] = (DWORD) GetCurrentThreadId();
	if (g_iEventBufferIndex >= IOCTL_EVENT_BUFFER_SIZE)
		g_iEventBufferIndex = 0;
	return TRUE;
}
BOOL OALIoCtlReadEv(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize )
{
	RETAILMSG(1,(TEXT("OALIoCtlReadEv: Set index\r\n")));
	*pOutSize = g_iEventBufferIndex;
	RETAILMSG(1,(TEXT("OALIoCtlReadEv: Copy\r\n")));
	memcpy(pOutBuffer,g_dwEventBuffer,sizeof(DWORD)*IOCTL_EVENT_BUFFER_SIZE);
	return TRUE;
}

//------------------------------------------------------------------------------
//
//  Global:      g_oalIoCtlTable[]
//
//  IOCTL handler table. This table includes the IOCTL code/handler pairs
//  defined in the IOCTL configuration file. This global array is exported
//  via oal_ioctl.h and is used by the OAL IOCTL component.
//
const OAL_IOCTL_HANDLER g_oalIoCtlTable[] = {
{ IOCTL_HAL_POSTINIT,                  0,  OALIoCtlHalPostInit   },
{ IOCTL_OEM_GET_PERIPHERAL_INFO,	   0,  OALIoCtlOemGetPeripheralInfo },
{ IOCTL_OEM_GET_SYSTEMID,			   0,  OALIoCtlOemGetSystemID },
#if defined(SOC_AU13XX)
{ IOCTL_OEM_GPINTR_REQ,                0,  OALIoCtlOemGpintrReq },
#endif
{ IOCTL_HAL_QUERY_CORE_SPEED,          0,  OALIoCtlOemGetCPUFrequency },
{ IOCTL_HAL_QUERY_PBUS_SPEED,          0,  OALIoCtlOemGetPBUSFrequency },
{ IOCTL_HAL_ADD_WIRED_TLB,             0,  OALIoCtlOemAddWiredTLB },
{ IOCTL_HAL_VSS,             		   0,  OALIoCtlOemVSS },
{ IOCTL_HAL_MARKEV,             	   0,  OALIoCtlMarkEv },
{ IOCTL_HAL_INTR_CONNECT_TIMER,    	   0,  OALIoCtlConnectTimer },
{ IOCTL_HAL_INTR_DISCONNECT_TIMER,     0,  OALIoCtlDisconnectTimer },
{ IOCTL_HAL_INTR_START_TIMER,    	   0,  OALIoCtlStartTimer },
{ IOCTL_HAL_INTR_STOP_TIMER,    	   0,  OALIoCtlStopTimer },
{ IOCTL_HAL_READEV,             	   0,  OALIoCtlReadEv },
//{ IOCTL_OAL_DDK,					   0,  OALIoCtlDDK },
#include <oal_ioctl_tab.h>

// Required Termination
{ 0,                                        0,  NULL                        }
};



/*++
Copyright (c) 2001,2005  BSQUARE Corporation.  All rights reserved.

Module Name:  profiler.c

Abstract:
 This file implements the platform specific profiler support

Functions:


Notes:

--*/

#include "windows.h"
#include "nkintr.h"
#include "bsp.h"

extern void ProfileTimerStart(DWORD);
extern void ProfileTimerStop(void);

extern VOID Cp0CountHandler (VOID);

extern DWORD ProfileHitCount;

extern DWORD dwPerfTimerAtTick;
extern LARGE_INTEGER CurTicks;
extern DWORD dwReschedIncrement;
extern DWORD ProfilerInterval;

DWORD dwProfileHitsPerSystemTick;
DWORD dwProfileHitCount;

// These are implemented in the kernel
VOID ProfilerHit(UINT32 epc);


// We'll write this ISR in C so we can call
// ProfilerHit nice and easily.
UINT32 ProfilerCP0ISR()
{
	UINT32 SysIntr = SYSINTR_NOP;
	UINT32 CP0Compare, CP0Count;

	// Handle system ticks here if we're using CP0 for
	// both system and profiler ticks
#ifdef USE_CP0_TIMER
	ProfileHitCount++;

	if (ProfileHitCount==dwProfileHitsPerSystemTick) {
		ULONG oldPerfLow;

		ProfileHitCount = 0;

		// Indicate timer tick
		SysIntr = SYSINTR_RESCHED;

		// Store the CP0 count register for OEMQueryPerformanceCounter()
		dwPerfTimerAtTick = Cp0RdCount();

		// Update CurMSec
		(*(PULONG)AddrCurMSec)++;

		// Update the high performance counter
		oldPerfLow = CurTicks.LowPart;
		CurTicks.LowPart += dwReschedIncrement;

		// handle overflow
		if (CurTicks.LowPart < oldPerfLow) {
			CurTicks.HighPart++;
		}
	}
#endif

    // First call profiler
    ProfilerHit(GetEPC());

	// Set Compare for our next profile interrupt
	CP0Compare = Cp0RdCompare();
	CP0Count = Cp0RdCount();

	CP0Compare += ProfilerInterval;

	// Make sure we haven't missed an interrupt or something
	if (CP0Compare <= CP0Count) {
		CP0Compare = CP0Count + ProfilerInterval;
	}

	Cp0WrCompare(CP0Compare);

	return SysIntr;
}


void
OEMProfileTimerEnable(
    DWORD dwUSec
    )
{
    DWORD CPUMHz = 0;
    DWORD TicksPeruS = 0;
    DWORD Period = 0;

    // convert uS to Ticks
    CPUMHz = OEMGetCpuFrequency();
    TicksPeruS = CPUMHz / 1000000;
    Period = dwUSec * TicksPeruS;


	// If using CP0 for both system tick and profiler we'll
	// need to signal a SYSINTR_RESCHED every x profiler hits,
	// let's work out what x is and make sure it's an integer
#ifdef USE_CP0_TIMER
	// Check that we can support the dwUSec period while
	// still generating a 1ms tick

	dwProfileHitsPerSystemTick = dwReschedIncrement / Period;

	RETAILMSG(1,(TEXT("dwReschedIncrement %d Period %d dwProfileHitsPerSystemTick %d\r\n"),
		dwReschedIncrement, Period, dwProfileHitsPerSystemTick));

	// Check that dwProfileHitsPerSystemTick is an integer
	if ((dwProfileHitsPerSystemTick*Period) != dwReschedIncrement) {
		RETAILMSG(1,(TEXT("Profiler period %dus does not divide exactly into 1ms system tick.\r\n"),dwUSec));
		RETAILMSG(1,(TEXT("The BSP does not currently support this, profiling will not be enabled.\r\n")));
		return;
	}
#endif

	// Unhook the old handler, hook the profile handler
	UnhookInterrupt(5,(PVOID)Cp0CountHandler);
	HookInterrupt(5,ProfilerCP0ISR);

	ProfileHitCount = 0;

    ProfileTimerStart(Period);
}

void OEMProfileTimerDisable(void)
{
	RETAILMSG(1,(TEXT("+OEMProfileTimerDisable: hit count = %d\r\n"),ProfileHitCount));

	UnhookInterrupt(5,ProfilerCP0ISR);

	// We need to rehook the CP0 tick timer,
	HookInterrupt(5,(PVOID)Cp0CountHandler);
}


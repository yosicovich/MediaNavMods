/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include <windows.h>
#include "platform.h"
#include "bsp.h"

#include <oal_intr.h>
#include <oal_log.h>

#include <nkexport.h>
#include <gpintr.h>



#if defined(INTR_AU13XX_GPINT)

// #define TLBPROF
#ifdef TLBPROF
// From mipskpg.h in Wince600\private\...
volatile	ULONG * pTLBMissCnt = (ULONG*)(0xffffc000 + 0x1998);
volatile  	unsigned long TlbMisses=0;
#endif

/************************************************************************
							Macros/Defines
************************************************************************/
#define INTR_MAX_IRQ_SHARE_COUNT 6

#define InterruptEnable(x)	\
	gpint->int_mask[GPINT_BANK_FROM_INT(x)] = GPINT_BIT_FROM_INT(GPINT_BANK_FROM_INT(x),x);

#define InterruptDisable(x)	\
	gpint->int_maskclr[GPINT_BANK_FROM_INT(x)] = GPINT_BIT_FROM_INT(GPINT_BANK_FROM_INT(x),x); \
	gpint->int_pend[GPINT_BANK_FROM_INT(x)] = GPINT_BIT_FROM_INT(GPINT_BANK_FROM_INT(x),x);

/************************************************************************
							Structures/Datatypes
************************************************************************/

// Used as the quick way to get the Sysintr associated with this bit
typedef struct
{
    ULONG	SysIntr;	// Ths sysintr using this HW intr
    ULONG	Shared;		// Count of the number of Sysintr's sharing the IRQ
} HARDWARE_INTR_TABLE;


typedef struct
{
    ULONG	HwIntr;     // The hardware irq # associated with this sysintr
	/* some SYSINTRs can have multiple Hw intrs.
	 * we'll store the mask for each of the 4 "banks"
	 * so we can just blast the apprpriate masks
	 * at interrupt time.
	 */
	ULONG   GpintRequest[GPINT_NUM_BANKS];
	ULONG   GpintMask[GPINT_NUM_BANKS];
    ULONG	DdmaRequest;// Bits in ddma_intstat upon interrupt
    ULONG	DdmaMask;	// Mask to apply to DDMA upon interrupt
	ULONG   ExtRequest;	// Bits in ext IRQ logic upon interrupt
	ULONG   ExtMask;	// Mask to apply to ext IRQ upon interrupt
    USHORT	Shared;     // True if this is a shared device
    USHORT	InUse;      // TRUE is used
} SYSINTR_ALLOC_TABLE;

typedef struct
{
    UCHAR	Count;		// How many SysIntrs are in the array > 1
    UCHAR	Remaining;	// The next Sysintr to return (0xff = done)
    UCHAR	SysIntr[INTR_MAX_IRQ_SHARE_COUNT];
}SHARED_INTR_TABLE, *PSHARED_INTR_TABLE;


/************************************************************************
        					Prototypes
************************************************************************/
ULONG OEMTickHandler( VOID );

/************************************************************************
							Globals
************************************************************************/

// imports from timer.c
extern volatile DWORD dwReschedIncrement;
extern volatile DWORD dwPerfTimerAtTick;
extern volatile UINT64 CurTicks;

AU1X00_DDMA * ddma =
	(AU1X00_DDMA *)(DDMA_PHYS_ADDR + KSEG1_OFFSET);

AU13XX_GPINT * gpint =
	(AU13XX_GPINT *)(GPINT_PHYS_ADDR + KSEG1_OFFSET);

BCSR * bcsr = (BCSR*)(BCSR_PHYSADDR + KSEG1_OFFSET);

typedef struct
{
	DWORD cfg[HWINTR_INTERNAL_MAX];
	DWORD devsel[GPINT_NUM_BANKS];
	DWORD intmask[GPINT_NUM_BANKS];
	DWORD dmasel;
} _POWER_STATE;

_POWER_STATE PowerSaveState;

#if defined(PLATFORM_DB13XX)
PLATFORM_GPINTR_CONFIG GPINTR_PlatformConfig[] = {
/*    PIN   	 			DESC			 Enable				VALUE */
	{  PLATFORM_WAKESRC,	L"Wake",		   0,			 GPINT_PINCTL_GPIOINPUT },
	/* Timer */
#if defined(HAVE_32KHZ_OSC)
	{  HWINTR_RTCTICK,		L"Tick",		   1,			 irqRE_NOWAKE | GPINT_PINCTL_DEVICE | CPU_INT3},
	{  HWINTR_RTCMATCH0,	L"RTCMatch0",	   1,			 irqRE | WAKE_ENABLE | GPINT_PINCTL_DEVICE },
	{  HWINTR_RTCMATCH1,	L"RTCMatch1",	   0,			 irqRE | WAKE_ENABLE | GPINT_PINCTL_DEVICE },
#endif
	/* Shared Interrupts */
	{  HWINTR_DDMA,			L"DDMA",		   1,			 irqHL | GPINT_PINCTL_DEVICE  },
#ifdef HWINTR_EXT_BASE_HOOK
	{  HWINTR_EXT_BASE_HOOK,L"External IRQ",   1,			 irqHL | GPINT_PINCTL_GPIOINPUT },
#endif
	/* MAE2 Config */
	{  HWINTR_BSA,			L"BSA", 		   0,			 irqHL | GPIO_IS_DEVICE },
	{  HWINTR_MPE,			L"MPE", 		   0,			 irqRE | GPIO_IS_DEVICE },
	{  HWINTR_SCF,			L"SCF", 		   0,			 irqHL | GPIO_IS_DEVICE },
	/* 3d Config */
	{  HWINTR_MGP,			L"MGP", 		   0,			 irqHL | GPIO_IS_DEVICE },
	{  HWINTR_GPU,			L"GPU", 		   0,			 irqHL | GPIO_IS_DEVICE },
	/* NAND */
	{  HWINTR_NAND,			L"NAND", 		   0,			 irqRE | GPIO_IS_DEVICE },
	/* CF */
	/* The spec lists 62 as part of CF but it is also the NAND interrupt.  CF
	 * appears to function correctly with that pin assigned as the NAND
	 * interrupt */
	{  63,					L"CF", 		   	   0,			 GPIO_IS_DEVICE },
	{  64,					L"CF", 		   	   0,			 GPIO_IS_DEVICE },
	{  65,					L"CF", 		   	   0,			 GPIO_IS_DEVICE },
	{  66,					L"CF", 		   	   0,			 GPIO_IS_DEVICE },
	{  67,					L"CF", 		   	   0,			 GPIO_IS_DEVICE },
	{  68,					L"CF", 		   	   0,			 GPIO_IS_DEVICE },
	{  69,					L"CF", 		   	   0,			 GPIO_IS_DEVICE },
	{  70,					L"CF", 		   	   0,			 GPIO_IS_DEVICE },
	/* SD0 */
	{  6, 					L"SD0",			   0,            GPIO_IS_DEVICE },
	{  7, 					L"SD0",			   0,            GPIO_IS_DEVICE },
	{  8, 					L"SD0",			   0,            GPIO_IS_DEVICE },
	{  9, 					L"SD0",			   0,            GPIO_IS_DEVICE },
	{  HWINTR_SD0,			L"SD0 IRQ",		   0,            irqHL | GPIO_IS_DEVICE },
	/* SD1 */
	{  33, 					L"SD1",			   0,            GPIO_IS_DEVICE },
	{  34, 					L"SD1",			   0,            GPIO_IS_DEVICE },
	{  35, 					L"SD1",			   0,            GPIO_IS_DEVICE },
	{  36, 					L"SD1",			   0,            GPIO_IS_DEVICE },
	{  37, 					L"SD1",			   0,            GPIO_IS_DEVICE },
	{  HWINTR_SD1,			L"SD1 IRQ",		   0,            irqHL | GPIO_IS_DEVICE },
	/* SD2 */
	{  39, 					L"SD2",			   0,            GPIO_IS_DEVICE },
	{  40, 					L"SD2",			   0,            GPIO_IS_DEVICE },
	{  41, 					L"SD2",			   0,            GPIO_IS_DEVICE },
	{  42, 					L"SD2",			   0,            GPIO_IS_DEVICE },
	{  43, 					L"SD2",			   0,            GPIO_IS_DEVICE },
	{  HWINTR_SD2,			L"SD2 IRQ",		   0,            irqHL | GPIO_IS_DEVICE },
	/* PSC0 (SPI) */
	{  44, 					L"PSC0 CLK",	   0,            GPIO_IS_DEVICE },
	{  46, 					L"PSC0 SYC0",	   0,            GPIO_IS_DEVICE },
	{  47, 					L"PSC0 SYC1",	   0,            GPIO_IS_DEVICE },
	{  HWINTR_PSC0,  		L"PSC0 IRQ/DAT0",  0,            irqHL | GPIO_IS_DEVICE },
	{  49, 					L"PSC0 DAT1",	   0,            GPIO_IS_DEVICE },
	/* PSC1 (AC97) */
	{  45, 					L"PSC1 CLK",	   0,            GPIO_IS_DEVICE },
	{  50, 					L"PSC1 SYC0",	   0,            GPIO_IS_DEVICE },
	{  51, 					L"PSC1 SYC1",	   0,            GPIO_IS_DEVICE },
	{  HWINTR_PSC1,  		L"PSC1 IRQ/DAT0",  0,            irqHL | GPIO_IS_DEVICE },
	{  53, 					L"PSC1 DAT1",	   0,            GPIO_IS_DEVICE },
	/* PSC2 (I2S) */
	{  73, 					L"PSC2 CLK",	   0,            GPIO_IS_DEVICE },
	{  54, 					L"PSC2 SYC0",	   0,            GPIO_IS_DEVICE },
	{  55, 					L"PSC2 SYC1",	   0,            GPIO_IS_DEVICE },
	{  HWINTR_PSC2,  		L"PSC2 IRQ/DAT0",  0,            irqHL | GPIO_IS_DEVICE },
	{  57, 					L"PSC2 DAT1",	   0,            GPIO_IS_DEVICE },
	/* PSC3 (SMB) */
	{  74, 					L"PSC3 CLK",	   0,            GPIO_IS_DEVICE },
	{  HWINTR_PSC3,  		L"PSC3 IRQ/DAT0",  0,            irqHL | GPIO_IS_DEVICE },
	{  61, 					L"PSC3 DAT1",	   0,            GPIO_IS_DEVICE },
	{  HWINTR_USB,			L"USB IRQ",	       0,            irqHL | GPIO_IS_DEVICE },
	{  30, 					L"LCD PWM1",       0,            GPIO_IS_DEVICE },
	{  71,          		L"CIM LS",         0,			 GPIO_IS_DEVICE },
	{  72,          		L"CIM FS",         0,			 GPIO_IS_DEVICE },
	{  HWINTR_CIM,          L"CIM IRQ",        0,			 irqHL | GPIO_IS_DEVICE },
	{  HWINTR_UART3,        L"U3RXD/IRQ",      0,            irqHL | GPIO_IS_DEVICE },
	{  28,                  L"U3TXD",          0,            GPIO_IS_DEVICE },
	{  HWINTR_LCD,          L"LCD IRQ",        0,            irqHL | GPIO_IS_DEVICE },
	{  31,                  L"LCD CLKIN",      0,            GPINT_PINCTL_GPIOINPUT },

// only used if doing loopback via switches
//	{  58, 					L"PSC3 SYC0",	   0,            GPIO_IS_DEVICE },
//	{  59, 					L"PSC3 SYC1",	   0,            GPIO_IS_DEVICE },
	{  59, 					L"GPIO LED",	   0,            GPINT_PINCTL_GPIOOUT_0 },
	{  25,                  L"U2RXD",          0,            GPIO_IS_DEVICE },
	{  26,                  L"U2TXD",          0,            GPIO_IS_DEVICE },

	{  -1,					NULL,			   0,            0, }
};
#else
	#error "Missing Platform GPINTR Configuration Table!"
#endif

/*

The IntrPriority table is used by the CE kernel to determine which interrupt
to service. When an interrupt exception occurs, the CE kernel uses the 6-bit
field from Cause[15:10] as an index into this 64-entry array. The array then
returns the interrupt vector of 0..5 to call out.

The IntrMask table is used to mask out lower priority interrupts. Thus these
two tables work hand-in-hand to enforce the priority scheme.

*/
unsigned char IntrPriority[]=
{
	-4, 		// 0000 00 spurious
	0*4,		// 0000 01 Cause[10] 0
	1*4,		// 0000 10 Cause[11] 1
	0*4,		// 0000 11 Cause[10] 0
	2*4,		// 0001 00 Cause[12] 2
	0*4,		// 0001 01 Cause[10] 0
	1*4,		// 0001 10 Cause[11] 1
	0*4,		// 0001 11 Cause[10] 0
	3*4,		// 0010 00 Cause[13] 3
	0*4,		// 0010 01 Cause[10] 0
	1*4,		// 0010 10 Cause[11] 1
	0*4,		// 0010 11 Cause[10] 0
	2*4,		// 0011 00 Cause[12] 2
	0*4,		// 0011 01 Cause[10] 0
	1*4,		// 0011 10 Cause[11] 1
	0*4,		// 0011 11 Cause[10] 0
	4*4,		// 0100 00 Cause[14] 4
	0*4,		// 0100 01 Cause[10] 0
	1*4,		// 0100 10 Cause[11] 1
	0*4,		// 0100 11 Cause[10] 0
	2*4,		// 0101 00 Cause[12] 2
	0*4,		// 0101 01 Cause[10] 0
	1*4,		// 0101 10 Cause[11] 1
	0*4,		// 0101 11 Cause[10] 0
	3*4,		// 0110 00 Cause[13] 3
	0*4,		// 0110 01 Cause[10] 0
	1*4,		// 0110 10 Cause[11] 1
	0*4,		// 0110 11 Cause[10] 0
	2*4,		// 0111 00 Cause[12] 2
	0*4,		// 0111 01 Cause[10] 0
	1*4,		// 0111 10 Cause[11] 1
	0*4,		// 0111 11 Cause[10] 0
	5*4, 		// 1000 00 Cause[15] 5
	5*4,		// 1000 01 Cause[15] 5
	5*4,		// 1000 10 Cause[15] 5
	5*4,		// 1000 11 Cause[15] 5
	5*4,		// 1001 00 Cause[15] 5
	5*4,		// 1001 01 Cause[15] 5
	5*4,		// 1001 10 Cause[15] 5
	5*4,		// 1001 11 Cause[15] 5
	5*4,		// 1010 00 Cause[15] 5
	5*4,		// 1010 01 Cause[15] 5
	5*4,		// 1010 10 Cause[15] 5
	5*4,		// 1010 11 Cause[15] 5
	5*4,		// 1011 00 Cause[15] 5
	5*4,		// 1011 01 Cause[15] 5
	5*4,		// 1011 10 Cause[15] 5
	5*4,		// 1011 11 Cause[15] 5
	5*4,		// 1100 00 Cause[15] 5
	5*4,		// 1100 01 Cause[15] 5
	5*4,		// 1100 10 Cause[15] 5
	5*4,		// 1100 11 Cause[15] 5
	5*4,		// 1101 00 Cause[15] 5
	5*4,		// 1101 01 Cause[15] 5
	5*4,		// 1101 10 Cause[15] 5
	5*4,		// 1101 11 Cause[15] 5
	5*4,		// 1110 00 Cause[15] 5
	5*4,		// 1110 01 Cause[15] 5
	5*4,		// 1110 10 Cause[15] 5
	5*4,		// 1110 11 Cause[15] 5
	5*4,		// 1111 00 Cause[15] 5
	5*4,		// 1111 01 Cause[15] 5
	5*4,		// 1111 10 Cause[15] 5
	5*4			// 1111 11 Cause[15] 5
};

// CE kernel inverts mask before applying
unsigned char IntrMask[]=
{
	0x00,	// 0000 00 spurious interrupt
	0x1F,	// 0000 01 Status[14:10] masked, Status[15] enabled
	0x1E,	// 0000 10 Status[14:11] masked, Status[15,10] enabled
	0x1C,	// 0001 00 Status[14:12] masked, Status[15,11:10] enabled
	0x18,	// 0010 00 Status[14:13] masked, Status[15,12:10] enabled
	0x10,	// 0100 00 Status[14:14] masked, Status[15,13:10] enabled
	0x3F,	// 1000 00 Status[15:10] masked, none enabled
	0x00	// padding
};

unsigned long TickCount = 0;
unsigned long IRQCount = 0;
unsigned long RTCTickCount = 0;

//
// The interrupt allocation is tracked using 2 tables
// One table is in HARDWARE interrupt order. This allows fast lookup of sysintr
// Next is in SysIntr order and holds the main information to handle the interrupt
//
// This table takes the SysIntr as the array index
static SYSINTR_ALLOC_TABLE LocalSysIntrMap[SYSINTR_MAXIMUM+1];

//
// this table takes the hardware interrupt as the array index
// It is used here and externally in isr.s
// Why +1? The last hardware interrupt is numbered HWINTR_MAXIMUM,
// the first is 0.
//
static HARDWARE_INTR_TABLE HwIntrMap[HWINTR_MAXIMUM+1];

static SHARED_INTR_TABLE   SharedIntrMap[HWINTR_MAXIMUM+1];

/*
 *   Function   :   ConfigureInterrupt
 *
 *      Configures interrupt
 *
 *   Parameters :
 *      u32Interrupt        Interrupt Number from 0-127
 *		u32Mode				Value of the gp_intX register
 *
 *     Returns :
 *      TRUE		Configured
 *      FALSE		ERROR
 *
 */
BOOL	ConfigureInterrupt( ULONG HwIntr, ULONG u32Mode )
{
	if ( HwIntr <= HWINTR_INTERNAL_MAX )
		gpint->gp_int[HwIntr] = u32Mode;

	return TRUE;
}

/*
 *   Function   :   InterruptQuery
 *
 *      Queries for interrupt value
 *
 *   Parameters :
 *      u32Interrupt        Interrupt Number from 0-127
 *
 *     Returns :
 *		 Value of interrupt
 *
 */
unsigned long	InterruptQuery( ULONG HwIntr )
{
	ULONG ret;
	ULONG	bank, bit;

#pragma message(__LOC__"TODO -- Comeback and fix this to take snapshots in IntrHandler, and return here")
	if ((HwIntr >= HWINTR_DDMA_BASE) && (HwIntr <= HWINTR_DDMA_MAX))
		HwIntr = HWINTR_DDMA;
#if defined(HWINTR_EXT_BASE_HOOK)
	else if (HwIntr >= HWINTR_EXT_BASE && HwIntr <= HWINTR_EXT_MAX )
		HwIntr = HWINTR_EXT_BASE_HOOK;
#endif

	bank = GPINT_BANK_FROM_INT(HwIntr);
	bit = GPINT_BIT_FROM_INT(bank,HwIntr);

	ret = gpint->pin_val[bank] & bit;
	return(ret);
}

/*
 *	There is only one interrupt that can invoke this handler... that is
 *  the timer tick HWINTR_RTCTICK.
 */
ULONG OEMTickHandler( VOID )
{
	ULONG	SysIntr = SYSINTR_NOP;

	dwPerfTimerAtTick = Cp0RdCount();

#if defined(HAVE_32KHZ_OSC)
	/* We know the timer tick is in bank 2 -- forget the others */
	gpint->int_pend[2] = LocalSysIntrMap[SYSINTR_RESCHED].GpintMask[2];
	WBSYNC();

	/* The RTCTICK occurs every 32 ticks of a 32768Hz clock. This provides a
	   clock that is ~976.5us, 23.5us fast. If left
	   unaccounted, then every 42.666 RTCTICK interrupts the system
	   erroneously advances an extra millisecond; let's not let that happen
	   NOTE: RTCTickCount is a local variable used to track tick counts,
	   it is NOT part of the CE timer system.
	*/
	if(++RTCTickCount == 43)
	{
		RTCTickCount=0;
	}
	else
#endif
	{

		CurMSec++;
		CurTicks += (UINT64) dwReschedIncrement;

#ifdef TLBPROF
		// These are wired TLB entries in kpage
		TlbMisses += *pTLBMissCnt;
		*pTLBMissCnt = 0;

		// Keep track of total vs. total used to calculate avg after Reset
		if ( !(CurMSec%5000) )
		{
			RETAILMSG(1,(TEXT("TLBMisses Tot:%d %04d/ms \r\n"),
				TlbMisses, TlbMisses/CurMSec ));
		}
#endif

#ifdef PLATFORM_ISR_TICK_DEBUG_CODE
	PLATFORM_ISR_TICK_DEBUG_CODE
#endif
		SysIntr = SYSINTR_RESCHED;
	}



	return SysIntr;
}

/*
 *   Function   :   xxxnHandler
 *
 *      Low level handlers for CPU visible interrupts
 *
 *   Parameters :
 *
 *     Returns :
 *
 */
ULONG Cp0CountHandler( VOID )
{
	ULONG	cmp;

	 cmp = Cp0RdCompare();
#if defined(USE_CP0_TIMER)

//     OEMWriteDebugString(L"#");
	 Cp0WrCompare(cmp+dwReschedIncrement);
	 OEMTickHandler();

	 return SYSINTR_RESCHED;
#else
	 Cp0WrCompare(cmp);
	return SYSINTR_NOP;
#endif
}


ULONG OEMInterruptHandler( VOID );

#pragma message(__LOC__"TODO -- implement some real priority handlers... for now share the same handler.")
ULONG OEMInterruptHandler0( VOID )
{
	return OEMInterruptHandler();
}

ULONG OEMInterruptHandler1( VOID )
{
	return OEMInterruptHandler();
}

ULONG OEMInterruptHandler2( VOID )
{
	return OEMInterruptHandler();
}

ULONG OEMInterruptHandler3( VOID )
{
	return OEMInterruptHandler();
}

ULONG OEMInterruptHandler( VOID )
{
	ULONG	SysIntr = SYSINTR_NOP, HwIntr;
	ULONG d0=0;  // DDMA intstat

	HwIntr = gpint->pri_enc;

	if ( HwIntr == 127  )
		RETAILMSG(1,(TEXT("SPURIOUS INRQ\r\n")));


	/* Print message if wake source is triggered */
	if ( HwIntr == PLATFORM_WAKESRC )
	{
		ULONG bank,bit;

		RETAILMSG(1,(TEXT("PLATFORM_WAKESRC\r\n")));

		bank = GPINT_BANK_FROM_INT(HwIntr);
		bit = GPINT_BIT_FROM_INT(bank,HwIntr);
		gpint->int_pend[bank] = bit;
	}

    /* its possible the timer tick will occur before we enter this routine */
	if ( HwIntr == HWINTR_RTCTICK )
		return OEMTickHandler();

#if defined(HWINTR_EXT_BASE_HOOK_CODE)
	HWINTR_EXT_BASE_HOOK_CODE
#endif

	if ( HWINTR_DDMA == HwIntr )
	{
		ULONG channel;

		d0 = ddma->intstat;
		// We need channel number in order to clear interrupt
		channel = getMSB(d0);
		ddma->channel[channel].irq = 0;

		// Channel + DDMA_BASE is our hw interrupt
		HwIntr = channel+HWINTR_DDMA_BASE;
	}

	SysIntr = HwIntrMap[HwIntr].SysIntr;

	++IRQCount;
#ifdef PLATFORM_ISR_DEBUG_CODE
	PLATFORM_ISR_DEBUG_CODE
#endif

	// disable and ack interrupts
	gpint->int_maskclr[0] = LocalSysIntrMap[SysIntr].GpintMask[0];
	gpint->int_maskclr[1] = LocalSysIntrMap[SysIntr].GpintMask[1];
	gpint->int_maskclr[2] = LocalSysIntrMap[SysIntr].GpintMask[2];
	gpint->int_maskclr[3] = LocalSysIntrMap[SysIntr].GpintMask[3];
	WBSYNC();
	gpint->int_pend[0] = LocalSysIntrMap[SysIntr].GpintMask[0];
	gpint->int_pend[1] = LocalSysIntrMap[SysIntr].GpintMask[1];
	gpint->int_pend[2] = LocalSysIntrMap[SysIntr].GpintMask[2];
	gpint->int_pend[3] = LocalSysIntrMap[SysIntr].GpintMask[3];
	WBSYNC();

	ddma->inten &= ~LocalSysIntrMap[SysIntr].DdmaMask;

	SysIntr = NKCallIntChain((BYTE)HwIntr);

	// If this is chained interrupt then return sysintr back
    if (SYSINTR_CHAIN == SysIntr)
		SysIntr = HwIntrMap[HwIntr].SysIntr;

	return SysIntr;

}

/********************************************************************/

static ULONG
GetFreeSysIntr (VOID)
{
	ULONG SysIntr = SYSINTR_NOP;
	int index;

	for (index = SYSINTR_FIRMWARE; index <= SYSINTR_MAXIMUM; index++)
	{
		if (!LocalSysIntrMap[index].InUse)
		{
			SysIntr = index;
			break;
		}
	}

	return SysIntr;
}

/********************************************************************/

/*
 * This function is called by the OEMInit to bring up the Interrupt system.
 */
VOID
OEMInterruptInit(VOID)
{
    UINT i;
    BOOL Status = TRUE;
	PLATFORM_GPINTR_CONFIG * pPlatCfg;

    OEMWriteDebugString(L"+OEMInterruptInit\r\n");

    // Initialize the tables
    memset((char*)LocalSysIntrMap, 0, sizeof(LocalSysIntrMap));
    for (i = 0; i <= HWINTR_MAXIMUM; i++)
    {
		HwIntrMap[i].SysIntr = SYSINTR_NOP;
		HwIntrMap[i].Shared = 0;
		SharedIntrMap[i].Count = 0;
    }
	// Reserve required kernel interrupts
#define RESERVE_INTR(sysintr,hwintr) \
	HwIntrMap[hwintr].SysIntr = sysintr; \
	LocalSysIntrMap[sysintr].HwIntr = hwintr; \
	LocalSysIntrMap[sysintr].GpintMask[GPINT_BANK_FROM_INT(hwintr)] = \
		GPINT_BIT_FROM_INT(GPINT_BANK_FROM_INT(hwintr),hwintr); \
	LocalSysIntrMap[sysintr].InUse = TRUE;

	RESERVE_INTR(SYSINTR_RESCHED, HWINTR_RTCTICK);
	RESERVE_INTR(SYSINTR_IDLEWAKEUP, HWINTR_RTCMATCH0);
	RESERVE_INTR(SYSINTR_RTC_ALARM, HWINTR_TOYMATCH2);
	RESERVE_INTR(SYSINTR_TIMING, HWINTR_RTCTICK);
	//RESERVE_INTR(SYSINTR_PROFILE, HWINTR_???);
#undef RESERVE_INTR

	// Install low-level interrupt service routines.
	// Au1x has 4 inputs from GPINT
	// Au1x also has 1 performance counter interrupt
	//      and 1 Count/Compare interrupt.
	//
    if (!HookInterrupt(0, (PVOID)OEMInterruptHandler0)) goto ErrorReturn;
    if (!HookInterrupt(1, (PVOID)OEMInterruptHandler1)) goto ErrorReturn;
    if (!HookInterrupt(2, (PVOID)OEMInterruptHandler2)) goto ErrorReturn;
    if (!HookInterrupt(3, (PVOID)OEMInterruptHandler3)) goto ErrorReturn;
    if (!HookInterrupt(5, (PVOID)Cp0CountHandler)) goto ErrorReturn;
    // Halt system if interrupts do not map
ErrorReturn:
    if (!Status) {
        OEMWriteDebugString(L"FATALERROR!! Cannot hook interrupts. Halting.\r\n");
        goto ErrorReturn;
    }

    OEMWriteDebugString(L"+OEMInterruptInit Disable All...\r\n");

	/*
	 * Make sure all interrupts are disabled
	 */
	gpint->int_maskclr[0] = ~0;
	gpint->int_maskclr[1] = ~0;
	gpint->int_maskclr[2] = ~0;
	gpint->int_maskclr[3] = ~0;

#ifdef PLATFORM_DMA1_REQ
	gpint->dma_sel = GPINT_DMASEL_DMA1_N(PLATFORM_DMA1_REQ);
	gpint->dma_sel = GPINT_DMASEL_DMA0_N(PLATFORM_DMA1_REQ);
#endif
#ifdef PLATFORM_DMA0_REQ
	gpint->dma_sel = GPINT_DMASEL_DMA0_N(PLATFORM_DMA0_REQ);
#endif

	/*
	 * Now initialize any external interrupt controllers
	 */
#ifdef PLATFORM_INTR_EXTERNAL_INIT_CODE
	PLATFORM_INTR_EXTERNAL_INIT_CODE
#endif

    OEMWriteDebugString(L"+OEMInterruptInit Parsing Platform GPINT Configuration table...");
	for( pPlatCfg = GPINTR_PlatformConfig; pPlatCfg->pin != -1; pPlatCfg++ )
	{
#ifdef DEBUG
		OEMWriteDebugString(L"\r\n     "); OEMWriteDebugString(pPlatCfg->desc);
#endif
		ConfigureInterrupt(pPlatCfg->pin, pPlatCfg->cfg);
		if (pPlatCfg->enable)
		{
			InterruptEnable(pPlatCfg->pin);
#ifdef DEBUG
			OEMWriteDebugString(L":enabled");
#endif
		}
	}

#ifdef TLBPROF
	*pTLBMissCnt = 0;
#endif
    OEMWriteDebugString(L"\r\nDONE\r\n");

    OEMWriteDebugString(L"-OEMInterruptInit\r\n");


}

/********************************************************************/

//
// Windows CE required linkages. See on-line help for details.
//

BOOL
OEMInterruptEnable(
      IN DWORD SysIntr,
      IN LPVOID Data,
      IN DWORD DataLength
      )
{
	BOOL	bVal = TRUE;

	/*
	 * This function is called by the kernel when a device driver calls
	 * InterruptInitialize.  This function is called with interrupts on.
	 * This routine only handles the Au1x00 side of the setup.
	 * All interrupt sources have already been configured, just enable it
	 */
	if (SysIntr <= SYSINTR_MAXIMUM)
	{
		// Handle any external controllers
#ifdef PLATFORM_INTR_EXTERNAL_ENABLE_CODE
		PLATFORM_INTR_EXTERNAL_ENABLE_CODE
#endif

		if (LocalSysIntrMap[SysIntr].DdmaMask != 0)
		{
		    ULONG IntrState, Mask;

		    IntrState = DISABLE_INTERRUPTS();
			Mask = ddma->inten;
			Mask |= LocalSysIntrMap[SysIntr].DdmaMask;
			ddma->inten = Mask;
		    RESTORE_INTERRUPTS(IntrState);
		}

		gpint->int_mask[0] = LocalSysIntrMap[SysIntr].GpintMask[0];
		gpint->int_mask[1] = LocalSysIntrMap[SysIntr].GpintMask[1];
		gpint->int_mask[2] = LocalSysIntrMap[SysIntr].GpintMask[2];
		gpint->int_mask[3] = LocalSysIntrMap[SysIntr].GpintMask[3];
		WBSYNC();
    }
	else
	{
		RETAILMSG(1,(TEXT("OEMInterruptEnable::Invalid SYSINTR\r\n")));
		bVal = FALSE;
	}

	return bVal;
}


//------------------------------------------------------------------------------
//
//  Function:  OEMInterruptMask (DWORD sysIntr, BOOL fDisable)
//
//  This function disables the IRQ given its corresponding SysIntr value.
//
//
VOID OEMInterruptMask (DWORD sysIntr, BOOL fDisable)
{
    if (fDisable) {
        OEMInterruptDisable (sysIntr);
    } else {
        OEMInterruptEnable (sysIntr, NULL, 0);
    }
}


/********************************************************************/

VOID
OEMInterruptDisable(IN DWORD SysIntr)
{
	/*
	 * Disables a hardware interrupt.  This routine is called by the
	 * kernel when a device driver calls InterruptDisable.  The system
	 * is preemtible when this function is called.
	 */
	if (SysIntr <= SYSINTR_MAXIMUM)
	{
		// Handle any external controllers
#ifdef PLATFORM_INTR_EXTERNAL_DISABLE_CODE
		PLATFORM_INTR_EXTERNAL_DISABLE_CODE
#endif

		if (LocalSysIntrMap[SysIntr].DdmaMask != 0)
		{
		    ULONG IntrState, Mask;

			RETAILMSG(1,(TEXT("OEMInterruptDisable:: DDMA:mask%x, inten:%x\r\n"),
				LocalSysIntrMap[SysIntr].DdmaMask,ddma->inten));

		    IntrState = DISABLE_INTERRUPTS();
			Mask = ddma->inten;
			Mask &= ~LocalSysIntrMap[SysIntr].DdmaMask;
			ddma->inten = Mask;
		    RESTORE_INTERRUPTS(IntrState);
		}

		gpint->int_maskclr[0] = LocalSysIntrMap[SysIntr].GpintMask[0];
		gpint->int_maskclr[1] = LocalSysIntrMap[SysIntr].GpintMask[1];
		gpint->int_maskclr[2] = LocalSysIntrMap[SysIntr].GpintMask[2];
		gpint->int_maskclr[3] = LocalSysIntrMap[SysIntr].GpintMask[3];

    }
}

/********************************************************************/

VOID
OEMInterruptDone(IN DWORD SysIntr)
{
	/*
	 * Signals completion of interrupt processing.  OEMInterruptDone
	 * is called by the kernel when a device driver calls InterruptDone.
	 * The system is preemtible when this function is called.
	 */
	if (SysIntr <= SYSINTR_MAXIMUM)
	{
		// Handle any external controllers
#ifdef PLATFORM_INTR_EXTERNAL_ENABLE_CODE
		PLATFORM_INTR_EXTERNAL_ENABLE_CODE
#endif

		if (LocalSysIntrMap[SysIntr].DdmaMask != 0)
		{
		    ULONG IntrState, Mask;
		    IntrState = DISABLE_INTERRUPTS();
			Mask = ddma->inten;
			Mask |= LocalSysIntrMap[SysIntr].DdmaMask;
			ddma->inten = Mask;
		    RESTORE_INTERRUPTS(IntrState);
		}

		RETAILMSG(0,(TEXT("OEMInterruptDone:: SYSINTR:0x%X ExtMask:%x G[3210]Mask %08x:%08x:%08x:%08x\r\n"),
			SysIntr,
			LocalSysIntrMap[SysIntr].ExtMask,
			LocalSysIntrMap[SysIntr].GpintMask[3],
			LocalSysIntrMap[SysIntr].GpintMask[2],
			LocalSysIntrMap[SysIntr].GpintMask[1],
			LocalSysIntrMap[SysIntr].GpintMask[0] ));


		gpint->int_mask[0] = LocalSysIntrMap[SysIntr].GpintMask[0];
		gpint->int_mask[1] = LocalSysIntrMap[SysIntr].GpintMask[1];
		gpint->int_mask[2] = LocalSysIntrMap[SysIntr].GpintMask[2];
		gpint->int_mask[3] = LocalSysIntrMap[SysIntr].GpintMask[3];
    }
}

ULONG
OEMInterruptConnect(
    IN INTERFACE_TYPE InterfaceType,
    IN ULONG BusNumber,
    IN ULONG BusInterrupt,
    IN ULONG InterruptMode
    )
{
    ULONG SysIntr = SYSINTR_NOP;
    ULONG IntrState;
	BOOL  inuse = FALSE;
	ULONG HwIntr, IntrMode;
	int index, numHwIntrs = 0;

#pragma message(__LOC__"TODO -- Remove Old Debug Code After 1st val")
				RETAILMSG(0,(TEXT("OEMInterruptConnect:: InterfaceType:0x%x BusNumber:0x%x BusInterrupt:%x InterruptMode:%08x\r\n"),
					InterfaceType,
					BusNumber,
					BusInterrupt,
					InterruptMode ));

    IntrState = DISABLE_INTERRUPTS();

	// Check to see if any of the HwIntrs are already in use
	for (index = 0; index < 4; ++index)
	{
		HwIntr = BusInterrupt >> (index * 8);
		HwIntr &= 0x000000FF;
		if ((HwIntr == 0) && (index > 0))
			continue;
		++numHwIntrs;
		if (HwIntrMap[HwIntr].SysIntr != SYSINTR_NOP)
			inuse = TRUE;
	}

	if ( !inuse )
	{
	    SysIntr = GetFreeSysIntr();
		if ( SYSINTR_NOP != SysIntr )
		{
			ULONG bank, bit;

            LocalSysIntrMap[SysIntr].Shared = 0;
			LocalSysIntrMap[SysIntr].HwIntr = BusInterrupt;

			for (index = 0; index < 4; ++index)
			{
				HwIntr = BusInterrupt >> (index * 8);
				HwIntr &= 0x000000FF;
				IntrMode = InterruptMode >> (index * 8);
				IntrMode &= 0x000000FF;

				if ((HwIntr == 0) && (index > 0))
					continue;

				// internal interrupts, followed by ddma, followed by external
				if (HwIntr <= HWINTR_INTERNAL_MAX)
				{
					bank = GPINT_BANK_FROM_INT(HwIntr);
					bit = GPINT_BIT_FROM_INT(bank,HwIntr);
					LocalSysIntrMap[SysIntr].GpintMask[bank] |= bit;
				}
				else if ((HwIntr >= HWINTR_DDMA_BASE) && (HwIntr <= HWINTR_DDMA_MAX))
					LocalSysIntrMap[SysIntr].DdmaMask |= (1 << (HwIntr - HWINTR_DDMA_BASE));
#if defined(HWINTR_EXT_BASE_HOOK)
				else if ((HwIntr >= HWINTR_EXT_BASE) && (HwIntr <= HWINTR_EXT_MAX))
					LocalSysIntrMap[SysIntr].ExtMask |= (1 << (HwIntr - HWINTR_EXT_BASE));
#endif

#pragma message(__LOC__"TODO -- Remove Old Debug Code After 1st val")
				RETAILMSG(0,(TEXT("OEMInterruptConnect:: hwIntr:0x%x SysIntr:0x%x ExtMask:%x GpintMask:%08x:%08x:%08x:%08x DmaMask:%x\r\n"),
					HwIntr,
					SysIntr,
					LocalSysIntrMap[SysIntr].ExtMask,
					LocalSysIntrMap[SysIntr].GpintMask[3],
					LocalSysIntrMap[SysIntr].GpintMask[2],
					LocalSysIntrMap[SysIntr].GpintMask[1],
					LocalSysIntrMap[SysIntr].GpintMask[0],
					LocalSysIntrMap[SysIntr].DdmaMask ));

				HwIntrMap[HwIntr].SysIntr = SysIntr;
				HwIntrMap[HwIntr].Shared = 0;

				// Allow INTR_MODE override
				if ( IntrMode != 0)
				{
					ConfigureInterrupt(HwIntr, InterruptMode);
				}
			}
			LocalSysIntrMap[SysIntr].InUse = TRUE;

		}
	}
	else // shared_irq
	{
		if (numHwIntrs == 1)
		{
			// NOTE: No check is performed to ensure that shared interrupts
			// are configured with the appropriate interrupt configuration;
			// ie level; this is to be done in the configuration of the
			// interrupt controller per platform.

			// NOTE: At this time, shared interrupts on GPIOs not supported.
			// Is there room for another share?

			HwIntr = BusInterrupt;

			if (INTR_MAX_IRQ_SHARE_COUNT > HwIntrMap[BusInterrupt].Shared)
			{
				SysIntr = GetFreeSysIntr();

				// was there a free sysintr?
				if (SYSINTR_NOP != SysIntr)
				{
					HwIntrMap[BusInterrupt].Shared++;

					if (HwIntr <= HWINTR_INTERNAL_MAX)
					{
						ULONG bank, bit;
						bank = GPINT_BANK_FROM_INT(HwIntr);
						bit = GPINT_BIT_FROM_INT(bank,HwIntr);
						LocalSysIntrMap[SysIntr].GpintMask[bank] |= bit;

						RETAILMSG(0,(TEXT("OEMInterruptConnect(Share):: ExtMask:%x GpintMask:%x bank:%d bit:%d\r\n"),
							LocalSysIntrMap[SysIntr].ExtMask,
							LocalSysIntrMap[SysIntr].GpintMask[bank],
							bank,
							bit ));
					}

					LocalSysIntrMap[SysIntr].HwIntr = BusInterrupt;
					// Signal ready to use
					LocalSysIntrMap[SysIntr].InUse = TRUE;

					SharedIntrMap[BusInterrupt].SysIntr[SharedIntrMap[BusInterrupt].Count] = (UCHAR)SysIntr;
					SharedIntrMap[BusInterrupt].Count++;
				}
			}
		}
	}
    RESTORE_INTERRUPTS(IntrState);

	return SysIntr;
}

VOID OEMInterruptDisconnect(IN DWORD SysIntr)
{
    ULONG IntrState, HwIntr, index;

	IntrState = DISABLE_INTERRUPTS();

	if ((SysIntr >= SYSINTR_FIRMWARE) &&
		(SysIntr <= SYSINTR_MAXIMUM) &&
		LocalSysIntrMap[SysIntr].InUse)
	{

		for (index = 0; index < 4; ++index)
		{
			HwIntr = LocalSysIntrMap[SysIntr].HwIntr >> (index * 8);
			HwIntr &= 0x000000FF;

			if ((HwIntr == 0) && (index > 0))
				continue;

			if ( HwIntrMap[HwIntr].Shared )
			{
				ULONG Last,i;

				// handle shared case
				HwIntrMap[HwIntr].Shared--;
				SharedIntrMap[HwIntr].Count--;
				Last = SharedIntrMap[HwIntr].SysIntr[SharedIntrMap[HwIntr].Count];

				//
				// Remove Sysintr from chain
				//
				if (HwIntrMap[HwIntr].Shared)
				{
					for (i=0;i<SharedIntrMap[HwIntr].Count;i++)
					{
						if (SharedIntrMap[HwIntr].SysIntr[i] == SysIntr)
						{
							SharedIntrMap[HwIntr].SysIntr[i] = (UCHAR)Last;
							break;
						}
					}
				}
				else
				{
					// Only 1 left therefore not shared anymore
					HwIntrMap[HwIntr].SysIntr = Last;
				}
			}
			else
			{
				OEMInterruptDisable(SysIntr);
				HwIntrMap[HwIntr].Shared = 0;
				HwIntrMap[HwIntr].SysIntr = SYSINTR_NOP;
			}
		}
		memset(&LocalSysIntrMap[SysIntr], 0, sizeof(LocalSysIntrMap[SysIntr]));
	}
    RESTORE_INTERRUPTS(IntrState);
}

VOID
StoreIntrRegState(VOID)
{
	ULONG i;

	PowerSaveState.devsel[0] = gpint->dev_sel[0];
	PowerSaveState.devsel[1] = gpint->dev_sel[1];
	PowerSaveState.devsel[2] = gpint->dev_sel[2];
	PowerSaveState.devsel[3] = gpint->dev_sel[3];

	PowerSaveState.intmask[0] = gpint->int_mask[0];
	PowerSaveState.intmask[1] = gpint->int_mask[1];
	PowerSaveState.intmask[2] = gpint->int_mask[2];
	PowerSaveState.intmask[3] = gpint->int_mask[3];

	PowerSaveState.dmasel = gpint->dma_sel;

	for(i=0;i<HWINTR_INTERNAL_MAX;i++)
		PowerSaveState.cfg[i] = gpint->gp_int[i];
}


VOID
RestoreIntrState(VOID)
{
	ULONG i;

	for(i=0;i<HWINTR_INTERNAL_MAX;i++)
		gpint->gp_int[i] = PowerSaveState.cfg[i];

	gpint->dev_sel[0] = PowerSaveState.devsel[0];
	gpint->dev_sel[1] = PowerSaveState.devsel[1];
	gpint->dev_sel[2] = PowerSaveState.devsel[2];
	gpint->dev_sel[3] = PowerSaveState.devsel[3];

	gpint->int_mask[0] = PowerSaveState.intmask[0];
	gpint->int_mask[1] = PowerSaveState.intmask[1];
	gpint->int_mask[2] = PowerSaveState.intmask[2];
	gpint->int_mask[3] = PowerSaveState.intmask[3];

	gpint->dma_sel = PowerSaveState.dmasel;

}


/********************************************************************/
BOOL OALIntrRequestIrqs(DEVICE_LOCATION *pDevLoc, UINT32 *pCount, UINT32 *pIrqs)
{
	DEBUGMSG(ZONE_INTR,(L"+-OALIntrRequestIrqs %x %x\r\n", pDevLoc->Pin ,pDevLoc->LogicalLoc));
	*pCount =1;
	pIrqs[0] = pDevLoc->Pin;
	return TRUE;
}

//------------------------------------------------------------------------------
//
//  Function:  OALIoCtlHalRequestSysIntr
//
//  This function return existing SysIntr for non-shareable IRQs and create
//  new Irq -> SysIntr mapping for shareable.
//
BOOL OALIoCtlHalRequestSysIntr(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    BOOL rc;
    UINT32 *pInpData = pInpBuffer, sysIntr;
    UINT32 inpElems = inpSize / sizeof (UINT32);

    OALMSG(OAL_INTR&&OAL_FUNC, (L"+OALIoCtlHalRequestSysIntr\r\n"));

    // We know output size already
    if (pOutSize != NULL) *pOutSize = sizeof(UINT32);

    // Check input parameters
    if ((pInpBuffer == NULL || inpElems < 1 || (inpSize % sizeof(UINT32) != 0)) ||
       (!pOutBuffer && pOutSize > 0)
    ) {
        NKSetLastError(ERROR_INVALID_PARAMETER);
        rc = FALSE;
        OALMSG(1, (L"WARN: IOCTL_HAL_REQUEST_SYSINTR invalid parameters %d\r\n",__LINE__));
        goto cleanUp;
    }

    if (pOutBuffer == NULL || outSize < sizeof(UINT32)
    ) {
        NKSetLastError(ERROR_INSUFFICIENT_BUFFER);
        rc = FALSE;
        OALMSG(1, (L"WARN: IOCTL_HAL_REQUEST_SYSINTR invalid parameters %d\r\n",__LINE__));
        goto cleanUp;
    }



    // Find if it is new or old call type
    if (inpElems > 1 && pInpData[0] == -1)
    {
        if (inpElems > 2 &&
            (pInpData[1] == OAL_INTR_TRANSLATE || pInpData[1] == OAL_INTR_DYNAMIC ||
             pInpData[1] == OAL_INTR_STATIC || pInpData[1] == OAL_INTR_FORCE_STATIC)
           ) {
            // Second UINT32 contains flags, third and subsequents IRQs
            sysIntr = OALIntrRequestSysIntr(inpElems - 2, &pInpData[2], pInpData[1]);
        } else {
            NKSetLastError(ERROR_INVALID_PARAMETER);
            rc = FALSE;
    	    OALMSG(1, (L"WARN: IOCTL_HAL_REQUEST_SYSINTR invalid parameters %d\r\n",__LINE__));
            goto cleanUp;
        }
    } else {
        if (inpElems == 1) {

            // This is legacy call, first UINT32 contains IRQ
            sysIntr = OALIntrRequestSysIntr(1, pInpData, 0);
        } else {
            NKSetLastError(ERROR_INVALID_PARAMETER);
            rc = FALSE;
	        OALMSG(1, (L"WARN: IOCTL_HAL_REQUEST_SYSINTR invalid parameters %d\r\n",__LINE__));
            goto cleanUp;
        }
    }

    // Store obtained SYSINTR
    *(UINT32*)pOutBuffer = sysIntr;
    rc = (sysIntr != SYSINTR_UNDEFINED);

cleanUp:
    OALMSG(OAL_INTR&&OAL_FUNC, (
        L"+OALIoCtlHalRequestSysIntr(rc = %d)\r\n", rc
    ));
    return rc;
}

//------------------------------------------------------------------------------
//
//  Function:  OEMReleaseSysIntr
//
//  This function releases a previously-requested SYSINTR.
//
BOOL OALIoCtlHalReleaseSysIntr(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    BOOL rc;

    OALMSG(OAL_INTR&&OAL_FUNC, (L"+OALIoCtlHalRequestSysIntr\r\n"));

    // We know output size
    if (pOutSize != NULL) *pOutSize = 0;

    // Check input parameters
    if (pInpBuffer == NULL || inpSize != sizeof(UINT32)) {
        OALMSG(OAL_WARN, (
            L"WARN: IOCTL_HAL_RELEASE_SYSINTR invalid parameters\r\n"
        ));
        NKSetLastError(ERROR_INVALID_PARAMETER);
        rc = FALSE;
        goto cleanUp;
    }

    // Call function itself
    rc = OALIntrReleaseSysIntr(*(UINT32*)pInpBuffer);

cleanUp:
    OALMSG(OAL_INTR&&OAL_FUNC, (
        L"+OALIoCtlHalRequestSysIntr(rc = %d)\r\n", rc
    ));
    return rc;
}

//------------------------------------------------------------------------------
//
//  Function: OALIoCtlHalRequestIrq
//
//  This function returns IRQ for device on given location.
//
BOOL OALIoCtlHalRequestIrq(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    BOOL rc = FALSE;
    DEVICE_LOCATION *pDevLoc, devLoc;
    UINT32 count;

    OALMSG(OAL_INTR&&OAL_FUNC, (L"+OALIoCtlHalRequestIrq\r\n"));

    // Check parameters
    if (
        pInpBuffer == NULL || inpSize != sizeof(DEVICE_LOCATION) ||
        pOutBuffer == NULL || outSize < sizeof(UINT32)
    ) {
        NKSetLastError(ERROR_INVALID_PARAMETER);
        OALMSG(OAL_WARN, (
            L"WARN: IOCTL_HAL_REQUEST_IRQ invalid parameters\r\n"
        ));
        goto cleanUp;
    }

    // Call function itself (we must first fix PCI bus device location...)
    pDevLoc = (DEVICE_LOCATION*)pInpBuffer;
    memcpy(&devLoc, pDevLoc, sizeof(devLoc));
    if (devLoc.IfcType == PCIBus) devLoc.BusNumber >>= 8;
    count = outSize/sizeof(UINT32);
    rc = OALIntrRequestIrqs(&devLoc, &count, pOutBuffer);
    if (pOutSize != NULL) *pOutSize = count * sizeof(UINT32);

cleanUp:
    OALMSG(OAL_INTR&&OAL_FUNC, (
        L"-OALIoCtlHalRequestSysIntr(rc = %d)\r\n", rc
    ));
    return rc;
}


//------------------------------------------------------------------------------
//
//  Function:  OALIntrRequestSysIntr
//
//  This function allocate new SYSINTR for given IRQ and it there isn't
//  static mapping for this IRQ it will create it.
//
UINT32 OALIntrRequestSysIntr(UINT32 count, const UINT32 *pIrqs, UINT32 flags)
{
    UINT32 sysIntr;

    OALMSG(OAL_INTR&&OAL_FUNC, (
        L"+OALIntrRequestSysIntr(%d, 0x%08x, 0x%08x irq:0x%08x)\r\n", count, pIrqs, flags, pIrqs[0]
    ));

	sysIntr = OEMInterruptConnect(Internal, 0, pIrqs[0], 0);

    OALMSG(OAL_INTR&&OAL_FUNC, (
        L"-OALIntrRequestSysIntr(sysIntr = %d)\r\n", sysIntr
    ));
    return sysIntr;
}


//------------------------------------------------------------------------------
//
//  Function:  OALIntrReleaseSysIntr
//
//  This function release given SYSINTR and remove static mapping if exists.
//
BOOL OALIntrReleaseSysIntr(UINT32 sysIntr)
{
    OALMSG(OAL_INTR&&OAL_FUNC, (L"+OALIntrReleaseSysIntr(%d)\r\n", sysIntr));
	OEMInterruptDisconnect(sysIntr);
    OALMSG(OAL_INTR&&OAL_FUNC, (L"-OALIntrReleaseSysIntr\r\n"));
    return TRUE;
}

//------------------------------------------------------------------------------
//
//  Function:  OALIoCtlOemGpintrReq
//
//  This function implements GPINT configuration and GPIO manipulation
//  from user space.
//
BOOL OALIoCtlOemGpintrReq(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize )
{
	GPINTRREQ *in  = (PGPINTRREQ)pInpBuffer;
	ULONG     *out = (PULONG)pOutBuffer;
	ULONG	   pin;

	DEBUGMSG(0,(TEXT("OALIoCtlOemGpintrReq: op:%x pin:%d cfg:%X\r\n"),
		in->op, in->gpintr, in->cfg ));

	if (in && (inpSize >= sizeof(GPINTRREQ)))
	{
		unsigned long bank,bit;
		pin = in->gpintr;
		bank = GPINT_BANK_FROM_INT(pin);
		bit = GPINT_BIT_FROM_INT(bank,pin);

		switch (in->op)
		{
			case GPINTR_REQ_READSTATE:
			    *out = gpint->pin_val[bank] & bit;
				*pOutSize = sizeof(ULONG);
				break;

			case GPINTR_REQ_OUTPUT_0:
				/* Bits are Write 1 to set */
				gpint->pin_valclr[bank] = bit;
				*pOutSize = 0;
				break;

			case GPINTR_REQ_OUTPUT_1:
				/* Bits are Write 1 to set */
				gpint->pin_val[bank] = bit;
				*pOutSize = 0;
				break;

			case GPINTR_REQ_GET_RSTVAL:
				/* Only valid for first 64 GPIOS */
			    *out = gpint->reset_val[bank] & bit;
				*pOutSize = sizeof(ULONG);
				break;

			case GPINTR_REQ_SET_CFG:
				gpint->gp_int[pin] = in->cfg;
				DEBUGMSG(0,(TEXT("OALIoCtlOemGpintrReq: %x gpint->gp_int[pin]:%x\r\n"),
					&gpint->gp_int[pin],gpint->gp_int[pin] ));
				*pOutSize = 0;
				break;

			case GPINTR_REQ_GET_CFG:
			default:
				*out = gpint->gp_int[pin];
				*pOutSize = sizeof(ULONG);
				break;
		}
	}

    return TRUE;
}

#endif  // #if defined(AU1300_GPINT)

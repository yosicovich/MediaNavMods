/*++
Copyright (c) 2001,2004  BSQUARE Corporation.  All rights reserved.

Module Name:

    flashreg.c

Module Description:

    This file contains the implementations of WriteRegistryToOEM/ReadRegistryFromOEM
                
Author:

    Anil Hashia 16-Aug-2001

Revision History:
    1st Sep 2001: Use Block writing for faster performance

    AnilH: 8th Oct,2001
    moved defines to \inc\flash.h so that common code is shared for persistent registry with loader \cli\common\perreg\perreg.c
    
    GJS - Rewritten for portability
    
                        
--*/

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include "bceddk.h"
#include "platform.h"  // platform specific header file
#include "flash.h"

// enable this with BSP_USE_PERSISTENT_REG environment variable
#ifdef USE_PERSISTENT_REG

// let's make sure we aren't going to overwrite the boot vector with
// persistent registry data, that's not good
#if ((REGISTRY_SIZE_IN_FLASH) > (BOOT_VECTOR_OFFSET))
#error PERSISTENT REGISTRY WILL OVERWRITE BOOT VECTOR
#endif

#define WRITE_BUFFER_SIZE	(2*SECTOR_SIZE_BYTES) // data written in flash-sector sized chunks, two devices

//
// globals
//
static FLASHREG_HDR FlashHeader;
static BYTE     *WriteBuffer;
static ULONG    WriteBufferPosition;
static ULONG    FlashBufferPosition;
static ULONG    ReadBufferPosition;


//
// functions for writing to flash implemented in savereg.c
//
extern BOOL  reg_WriteFlash(ULONG TargetOffset, PVOID Source, ULONG Size);
extern BOOL  reg_ReadFlash(PVOID Target, ULONG SourceOffset, ULONG Size);
extern BYTE  reg_ReadFlashByte(ULONG SourceOffset);
extern BOOL  reg_EraseFlash(ULONG AddressOffset, ULONG Size);
extern void  reg_LockFlash(ULONG AddressOffset, ULONG Size);
extern void  reg_UnlockFlash(ULONG AddressOffset, ULONG Size);


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*++
Routine Description:
    BOOL WriteRegistryToOEM (DWORD dwFlags,LPBYTE lpData,DWORD cbData )
    This function enables writing the registry file to persistent storage defined by the OEM.

Arguments:
        DWORD dwFlags  Read options specified by the system
        LPBYTE lpData  Pointer to a buffer allocated by the OS and filled with registry bytes
        DWORD cbData   The number of bytes in the buffer lpData passed in by the OS 
    
Return Value:
        TRUE indicates success; FALSE indicates failure
    
--*/

BOOL WriteRegistryToOEM (
    DWORD dwFlags,
    LPBYTE IncomingData,
    DWORD DataSize )
{
    BOOL  bRetValue = TRUE;            //   holds return value     
    ULONG BytesWritten=0;
    ULONG i;
    
	//RETAILMSG(1,(TEXT("WriteRegistryToOEM: flags=%08X DataSize=%d WritePos=%08X\r\n"),dwFlags,DataSize,WriteBufferPosition));

    //
    //  REG_WRITE_BYTES_START, which indicates the start of the new registry file. 
    //
    if(dwFlags & REG_WRITE_BYTES_START)  {
    
        DEBUGMSG(1, (TEXT("Start New Registry Write: Registry Flash Base=0x%X \r\n"),
                REGISTRY_FLASH_START_ADDRESS));

        //
        // Grab some memory
        //
        if (NULL == WriteBuffer) {
            WriteBuffer=malloc(WRITE_BUFFER_SIZE);
        }
        if (NULL == WriteBuffer) {
            bRetValue=FALSE;
            goto ErrorReturn;
        }

        //
        // Set starting condition
        //
        FlashHeader.dwLength = 0;
        FlashHeader.dwCheckSum = 1;
        WriteBufferPosition = 0;
		FlashBufferPosition = 0;
        
        //
        // Don't overwrite the header area
        //
        for (i=0; i<REGISTRY_FLASH_HEADER_SIZE;i++) {
            WriteBuffer[WriteBufferPosition++] = FLASH_ERASE_VALUE;
        }
    }

    //
    // if the registry flush is complete
    //
    if(0 == DataSize) {
        DWORD Checksum=1;
        
        //
        // enable the flash for block writing
        //
        reg_UnlockFlash(FlashBufferPosition, WriteBufferPosition);
        //
        // erase the persistent registry flash sectors
        //
        reg_EraseFlash(FlashBufferPosition, WriteBufferPosition);
        //
        // Write buffer to FLASH
        //
        
        bRetValue = reg_WriteFlash(
                    FlashBufferPosition, 
                    WriteBuffer, 
                    WriteBufferPosition);


        if (!bRetValue) {
            DEBUGMSG(1,(L"Last WriteFlash failed\r\n"));
            goto ErrorReturn;
        }
        
        //
        // Verify
        //
        for (i=0;i < WriteBufferPosition;i++) {
            if (WriteBuffer[i] != reg_ReadFlashByte(FlashBufferPosition+i)) {
                RETAILMSG(1,(L"REG: Verify fail at offset 0x%x (0x%02X != 0x%02X)\r\n", 
                        FlashBufferPosition+i,
                        WriteBuffer[i],
                        reg_ReadFlashByte(FlashBufferPosition+i)
                        ));
                bRetValue = FALSE;
            }
        }

		if(!bRetValue) goto ErrorReturn;
        
        DEBUGMSG(1,(L"Registry write verified\r\n"));

        for (i=0; i < FlashHeader.dwLength; i++) {
            Checksum += reg_ReadFlashByte(i+REGISTRY_FLASH_HEADER_SIZE);
        }
        
        
        
        if (FlashHeader.dwCheckSum != Checksum) {
            RETAILMSG(1,(L"REG: Flash incorrectly written\r\n"));
            bRetValue = FALSE;
            goto ErrorReturn;
        }
        

        //
        // Write the flash header
        //
        bRetValue = reg_WriteFlash(0,
                    (PVOID)&FlashHeader,
                    REGISTRY_FLASH_HEADER_SIZE);
        
        if (!bRetValue) {
            RETAILMSG(1,(L"Write flash header failed\r\n"));
            goto ErrorReturn;
        } else {
            DEBUGMSG(1,(L"Wrote flash header len=0x%x, cs=0x%x\r\n",
                FlashHeader.dwLength,
                FlashHeader.dwCheckSum));
        }
         
        //
        // close writing to flash
        //
        reg_LockFlash(0, REGISTRY_SIZE_MAX+REGISTRY_FLASH_HEADER_SIZE);


        //
        // Clean resources
        //
        if (WriteBuffer) {
            free(WriteBuffer);
            WriteBuffer=NULL;
        }
        
        DEBUGMSG(1, (TEXT("Registry Flush COMPLETE\r\n")));
        
    } else {
		//
		// store the data in the chunk
		//
		do {
			while((WriteBufferPosition < WRITE_BUFFER_SIZE) && 
					(BytesWritten < DataSize)) {
    
				WriteBuffer[WriteBufferPosition] = *IncomingData;
				FlashHeader.dwCheckSum += *IncomingData;
                
				WriteBufferPosition++;
				BytesWritten++;
				IncomingData++;
				FlashHeader.dwLength++;

			}


			//
			// If buffer is full
			//
			if( WRITE_BUFFER_SIZE == WriteBufferPosition ) {
                DEBUGMSG(1,(L"Reg: buf full, writing @ 0x%x\r\n",FlashBufferPosition));
                
				//
				// enable the flash for block writing
				//
				reg_UnlockFlash(0, FlashBufferPosition);
				//
				// erase the sector that this block goes into
				//
				reg_EraseFlash(FlashBufferPosition, WRITE_BUFFER_SIZE);
				//
				// Write buffer to FLASH
				//
                bRetValue = reg_WriteFlash(
                                FlashBufferPosition,
                                WriteBuffer,
                                WriteBufferPosition
                                );
                
                if(bRetValue==FALSE){
                    RETAILMSG(1, (TEXT("WriteRegistryToOEM: Failed-3\r\n")));
                    goto ErrorReturn;
                } else {
                    DEBUGMSG(1,(L"Reg: wrote block\r\n"));
                }
                
                
                //
                // Verify
                //
                for (i=0;i < WriteBufferPosition;i++) {
                    if (WriteBuffer[i] != reg_ReadFlashByte(FlashBufferPosition+i)) {
                        RETAILMSG(1,(L"REG: Verify fail at offset 0x%x\r\n", FlashBufferPosition+i));
                        bRetValue = FALSE;
                        goto ErrorReturn;
                    }
                }
                
                
                //
                // reset the buffer position
                // and update header
                //                
                FlashBufferPosition += WriteBufferPosition;
                WriteBufferPosition = 0;
                                
			}

		} while(BytesWritten < DataSize);
    }

ErrorReturn:

    if (!bRetValue && WriteBuffer) {
        free(WriteBuffer);
        WriteBuffer=NULL;
    }
    RETAILMSG(!bRetValue,(L"Reg write fail\r\n"));

    return bRetValue;
}

/*++
Routine Description:
    BOOL ReadRegistryFromOEM (DWORD dwFlags,LPBYTE lpData,DWORD cbData )
    This function reads into RAM a registry file from persistent storage defined by the OEM

Arguments:
        DWORD dwFlags  Read options specified by the system
        LPBYTE lpData  Pointer to a buffer allocated by the OS and filled with registry bytes
        DWORD cbData   Size in bytes of the buffer to which lpData points
    
Return Value:
            Returns the number of bytes added to lpData.
            If  0 is returned then the end-of-file (EOF) has been reached. 
            If -1 is returned, then read functionality has faulted and the OS should load the default registry.
    
--*/

DWORD ReadRegistryFromOEM(
    DWORD dwFlags,
    LPBYTE OutgoingData,
    DWORD OutgoingSize)
{
    DWORD BytesRead;
    ULONG i;
    ULONG CheckSum = 1;
    
    
    //
    // REG_READ_BYTES_START indicates reading must start from the beginning of the registry file. 
    //
    if(dwFlags & REG_READ_BYTES_START)
    {

        DEBUGMSG(1, (TEXT("ReadRegistryFromOEM::Start Registry ! \r\n")));
        
        //
        // read the flash header
        //
        reg_ReadFlash(&FlashHeader,
                0,
                sizeof(FLASHREG_HDR));
                
        // If it wasn't written completely last time
        if(FlashHeader.dwLength == ERASEFLASHLOCATIONVALUE || 
            FlashHeader.dwLength > REGISTRY_SIZE_MAX)
        {
            
            //
            // return failure
            //
            RETAILMSG(1, (TEXT("ReadRegistryFromOEM FAILED, bad data\r\n")));
            BytesRead = -1;
            goto ErrorReturn;
        }


        //
        // validate the checksum on the data
        //
        for (i=0; i < FlashHeader.dwLength; i++) {
            CheckSum += reg_ReadFlashByte(i+REGISTRY_FLASH_HEADER_SIZE);
        }
        
        if (CheckSum != FlashHeader.dwCheckSum) {
            
            //
            // return failure
            //
            RETAILMSG(1, (TEXT("ReadRegistryFromOEM failure - BAD Checksum 0x%x versus 0x%x\r\n"),
                    CheckSum,
                    FlashHeader.dwCheckSum));
            BytesRead = -1;
            goto ErrorReturn;
        }
        
        //
        // reset counters
        //
        ReadBufferPosition = 0;
    }

   
    //
    // How much shall be read?
    //
    BytesRead = min(OutgoingSize, (FlashHeader.dwLength - ReadBufferPosition));
    
    reg_ReadFlash(OutgoingData,
                    ReadBufferPosition+REGISTRY_FLASH_HEADER_SIZE,
                    BytesRead);
    
    ReadBufferPosition += BytesRead;
    


ErrorReturn:

    // return amount read
    return BytesRead;
}
#endif USE_PERSISTENT_REG


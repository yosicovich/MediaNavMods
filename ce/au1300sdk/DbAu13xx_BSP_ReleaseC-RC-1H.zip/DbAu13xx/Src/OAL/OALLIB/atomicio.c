/*++
Copyright (c) 2002-2004  BSQUARE Corporation.  All rights reserved.

Module Name:

    atomicio.c

Abstract:

	Implement atomic IO operations - called directly in kmode OR
    via IOCTLs in ddk_io.c

Author:

	GJS -  Winter 2002

Revision History:


--*/

#include "bsp.h"

/********************************************************************/

/*
 * FIX!!! NEED TO USE LL SC PRIMITIVES !!!
 */

BOOL
SC_AtomicRMW_UCHAR(
    PUCHAR   ptr,
    UCHAR AndMask,
    UCHAR OrMask,
    PUCHAR  pValue
)
{
	UCHAR Tmp;
	BOOL IntrState;

	if ((ULONG)ptr > 0x1fffffff)
	    return FALSE;

	IntrState = DISABLE_INTERRUPTS();

	*pValue =  *ptr;
	Tmp = *pValue & AndMask;
	Tmp |= OrMask;
	*ptr = Tmp;

	RESTORE_INTERRUPTS(IntrState);

	return TRUE;
}

/********************************************************************/

BOOL
SC_AtomicRMW_USHORT(
    PSHORT   ptr,
    USHORT AndMask,
    USHORT OrMask,
    PUSHORT  pValue
)
{
	USHORT Tmp;
	BOOL IntrState;

	if ((ULONG)ptr > 0x1ffffffe)
	    return FALSE;

	IntrState = DISABLE_INTERRUPTS();

	*pValue = *ptr;
	Tmp = *pValue & AndMask;
	Tmp |= OrMask;
	*ptr = Tmp;

	RESTORE_INTERRUPTS(IntrState);

	return TRUE;
}

/********************************************************************/

BOOL
SC_AtomicRMW_ULONG(
    PULONG   ptr,
    ULONG    AndMask,
    ULONG    OrMask,
    PULONG   pValue
)
{
	ULONG Tmp;
	BOOL IntrState;

	if ((ULONG)ptr > 0x1ffffffc)
	    return FALSE;

	IntrState = DISABLE_INTERRUPTS();

	*pValue = *ptr;
	Tmp = *pValue & AndMask;
	Tmp |= OrMask;
	*ptr = Tmp;

	RESTORE_INTERRUPTS(IntrState);

	return TRUE;
}

/********************************************************************/


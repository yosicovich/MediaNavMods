/*++
Copyright (c) 2001-2005  BSQUARE Corporation.  All rights reserved.

Module Name:

    timer.c

Abstract:

    This module implements the Windows CE Kernel callbacks for APIs related
    to the platforms time capabilities. This includes the system ticker,
	the real-time clock, and the performance counters.

	The Au1x00 has two timing sources; the MIPS CP0 Count/Compare mechanism
	and the TOY/RTC module. The CP0 Counter operates at the frequency of
	the Au1 core; however, it does not count during the WAIT/Idle modes.
	The TOY/RTC operates from an optional 32kHz external oscillator; both
	count during the WAIT/Idle modes, but only the TOY continues to
	count during the Sleep mode of the Au1x00.

	The different abilities of the timing sources lead to several possible
	configurations for building this time management code:

	1) Use CP0 Count/Compare as the ticker and source for real-time clock;
	   note this prevents the use of the WAIT instruction and its power savings.
	2) Use Cp0 Count/Compare as the ticker and RTC/TOY as the source for
	   the real-time clock (again, can not use the WAIT instruction).
	3) Use the TOY/RTC as the ticker source and also as the source for
	   the real-time clock. This mode permits the use of the WAIT
	   instruction and the Au1 core Idle modes for power savings.

	When the TOY/RTC is used to source the real-time clock, it is the TOY
	that is used, not the RTC. While this is definitely possibly confusing,
	keep in mind that the TOY is able to count during Sleep modes, and so
	it makes sense to maintain the real-time clock in the TOY so that an
	alarm based on date/time configured in the TOY match 2 register can
	be utilized to awake the Au1x00 system from sleep state.

	The choice of which time management code configuration to use is
	declared by the use of these #define's:

	  #define USE_CP0_TIMER: declares the use of Count/Compare as the
	                         system ticker source

      #define HAVE_32KHZ_OSC: declares the presence of the external
	                         32kHz oscillator

	The operational modes are then selected according to:

      if (HAVE_32KHZ_OSC && !USE_CP0_TIMER)
	    system ticker source = RTC @ ~1ms
	  else
	    system ticker source = CP0 @ 1ms

      if (HAVE_32KHZ_OSC)
	    real-time clock source = TOY @ 1Hz
	  else
	    real-time clock source = CP0 software fabricated 1Hz

NOTE: THE FULL SCHEME ABOVE HAS NOT YET BEEN IMPLEMENTED!!!!
NOTE: THE FULL SCHEME ABOVE HAS NOT YET BEEN IMPLEMENTED!!!!
NOTE: THE FULL SCHEME ABOVE HAS NOT YET BEEN IMPLEMENTED!!!!
NOTE: THE FULL SCHEME ABOVE HAS NOT YET BEEN IMPLEMENTED!!!!

	The performance counters use a software fabricated 64-bit value
	that is clocked by the CP0 Counter. These scheme works even if the
	WAIT instruction is in use because the tick handler in isr.s always
	correctly updates the 64-bit value (independent of ticker source);
	and the PerfCountSinceTick() routine is accurate too because so
	long as the Au1 core is running (and it will be if the application
	is running to request performance data), this routine provides
	accurate info too from the CP0 Count.

Author:

    GJS March 2001

Revision History:

	EJD July 2003 Overhauled

--*/

#include <windows.h>
#include "platform.h"
#include "bsp.h"

extern void FlushDCache(void);

// The initial reschedule period
#ifndef DEFAULT_TIMER_FREQ
#define DEFAULT_TIMER_FREQ 1000
#endif

#ifndef DEFAULT_RTC_FREQ
#define DEFAULT_RTC_FREQ 1
#endif

#ifndef DEFAULT_TIMER_PERIODMS
#define DEFAULT_TIMER_PERIODMS 1
#endif

#ifndef DEFAULT_RTC_PERIODMS
#define DEFAULT_RTC_PERIODMS 1000
#endif

// The 32kHz crystal
#define TICKER_SOURCE_CLOCK_FREQ     32768

#define RTC_YEAR_DATUM  1970
FILETIME  g_Ftime = { 3577643008, 27111902 };
ULONGLONG g_Ticks = 0;

/********************************************************************/

//
// Interrupt Latency timers vars
// Note ILT_TicksPerIrq is 1 less than the real count
//
volatile ULONG ILT_InUse = FALSE;
volatile ULONG ILT_TicksPerIrq = 0;
volatile ULONG ILT_TicksLeftB4Irq= 0;
volatile ULONG ILT_StartOfIsrTime=0;
volatile ULONG ILT_EndOfIsrTime;
volatile ULONG ILT_SPC;
volatile USHORT ILT_NumInterrupts=0;

// Obsolete but still required CE linkage
ULONG OEMClockFreq = 1;

// CurMSec, DiffMSec - kernel variables
// the pointers re used in the assembler ISR
DWORD   TickerPeriodmS = DEFAULT_TIMER_PERIODMS;

// Volatile qualifier for CurTicks is essential as assembly code manipulates this
volatile ULARGE_INTEGER CurTicks = { 0, 0 };
volatile ULARGE_INTEGER * pCurTicks = &CurTicks;

#define MAXSLEEPTIMEMILLSEC	  40000 // 40 seconds

DWORD dwReschedIncrement;
DWORD dwPerfTimerAtTick;			// CP0 Count register at tick for OEMQueryPerformanceCounter

AU1X00_SYS * const Sys = (AU1X00_SYS *)(SYS_PHYS_ADDR+KSEG1_OFFSET);

#define RESCHED_PERIOD  1      // SYSINTR_RESCHED interrupt interval (ms)

// Stored RTC bias value.
static ULONGLONG RealTimeBias;

//
// The list of timers
//
static  TIMER Timers[OS_TIMER_COUNT];
static TimersInited = FALSE;

//
// For use with measuring Idle time with USE_CP0_TIMER
// Set by isr.s, cleared in OEMIdle()
volatile DWORD fInterruptFlag = 0;
#ifdef PLATFORM_IDLEDATA_START_ADDRESS
DWORD *pdwIdleData = (DWORD *)PLATFORM_IDLEDATA_START_ADDRESS;
#endif

/********************************************************************/

/*
 * Return Number of counts since the last Tick IRQ
 */
DWORD
PerfCountSinceTick(void)
{
    ULONG dwCount = Cp0RdCount();

	if (dwCount < dwPerfTimerAtTick)
	{
		return (~dwPerfTimerAtTick + dwCount + 1);
	}
	else
	{
		return (dwCount - dwPerfTimerAtTick);
	}
}

/********************************************************************/

BOOL
OEMQueryPerformanceCounter(LARGE_INTEGER *lpliPerformanceCount)
{
	ULARGE_INTEGER liBase;
	DWORD diff;
	DWORD intrState;

	// Disable interrupts while we snapshot various timers and
	// values set by the tick ISR.
	intrState = DISABLE_INTERRUPTS();

	diff = PerfCountSinceTick();
	liBase = CurTicks;

	RESTORE_INTERRUPTS(intrState);

	lpliPerformanceCount->QuadPart = liBase.QuadPart + diff;

    return TRUE;
}

/********************************************************************/

BOOL
OEMQueryPerformanceFrequency(LARGE_INTEGER *lpliPerformanceFreq)
{
	/* Return CP0 Count frequency */
    lpliPerformanceFreq->LowPart  = OEMGetCpuFrequency();
    lpliPerformanceFreq->HighPart = 0;

    return TRUE;
}

/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/

/*
 * This routine is called by the kernel on power up or from a wake up.
 * It will enable the 32KHz if required.
 * Then the trim will be setup for PC1 and the ticker enabled.
 * NOTE: The interrupt defaults are setup in the interrupt init function
 */

VOID
HalTickerInit(VOID)
{
#ifdef HAVE_32KHZ_OSC
    ULONG RtcTrim, ToyTrim;
    ULONG Control;
    ULONG Count;
    ULONG StatusCheck;
	DWORD dwCurMSec;
#endif
	int i;

    // For the CP0Ticker and IL Timing
    OEMClockFreq = OEMGetCpuFrequency() ;
    dwReschedIncrement = DEFAULT_TIMER_PERIODMS * (OEMGetCpuFrequency() / 1000);

    // Reset/Set variables
    curridlehigh = curridlelow = 0;

	// Install performance counter
    g_pOemGlobal->pfnQueryPerfFreq 		= OEMQueryPerformanceFrequency;
    g_pOemGlobal->pfnQueryPerfCounter	= OEMQueryPerformanceCounter;

	if (TimersInited == FALSE)
	{
	    for (i = 0; i < OS_TIMER_COUNT; i++)
	    {
			Timers[i].SysIntr = SYSINTR_NOP;
	    }
	    Timers[0].SysIntr = SYSINTR_IDLEWAKEUP;
		TimersInited = TRUE;
	}

#ifdef HAVE_32KHZ_OSC
    // Start the 32kHz oscillator if it is not already running
    Control = Sys->cntrctrl;
    if (!(SYS_CNTRCTRL_32S & Control))
    {
        // Start the 32Khz clock
        Control = SYS_CNTRCTRL_EO;
        Sys->cntrctrl = Control;
		// Wait for it to start...NOTE: Can hang here if there is
		// a board problem with the 32kHz oscillator!!!
        while (!(Sys->cntrctrl & SYS_CNTRCTRL_32S));
    }

    //
    // The 32KHz is now running. Stop the counters
    //
    Control &= ~(SYS_CNTRCTRL_REN | SYS_CNTRCTRL_TEN);
    while (Sys->cntrctrl & (SYS_CNTRCTRL_ERS | SYS_CNTRCTRL_ETS)) ;

    Sys->cntrctrl = Control;

    //
    //  Calculate trim register for the desired reschedule period
    //  Set the ticker to tick at this period.
    //  This requires changing the trim register
    //

    RtcTrim = ((TickerPeriodmS*TICKER_SOURCE_CLOCK_FREQ)/1000) - 1;


    ToyTrim = TICKER_SOURCE_CLOCK_FREQ/DEFAULT_RTC_FREQ - 1;

    // Write trim and wait for complete
    while (Sys->cntrctrl & (SYS_CNTRCTRL_RTS|SYS_CNTRCTRL_TTS));
    Sys->rtctrim = RtcTrim;
    Sys->toytrim = ToyTrim;
    while (Sys->cntrctrl & (SYS_CNTRCTRL_RTS|SYS_CNTRCTRL_TTS));


    //
    // enable counters to run
    //
    Control |= (SYS_CNTRCTRL_REN|SYS_CNTRCTRL_TEN);
    while (Sys->cntrctrl & (SYS_CNTRCTRL_ERS|SYS_CNTRCTRL_ETS));
    Sys->cntrctrl = Control;

    // Initialize counter values and matches
	if (bootupType != HAL_SUSPENDRESUME_BOOT)
	{
       Count = 0;
       while (Sys->cntrctrl & SYS_CNTRCTRL_RS);
       Sys->rtcwrite = Count;
	}

    // wait until all written and matched
    StatusCheck = SYS_CNTRCTRL_RS | SYS_CNTRCTRL_ERS | SYS_CNTRCTRL_RTS;
    while (Sys->cntrctrl & StatusCheck);

    // wait until all written and matched
    StatusCheck = SYS_CNTRCTRL_TS | SYS_CNTRCTRL_ETS | SYS_CNTRCTRL_TTS;
    while (Sys->cntrctrl & StatusCheck);

	// RTCTICK and CurMSec are equivalent...
    dwCurMSec = Sys->rtcread;
    *(PULONG)AddrCurMSec = dwCurMSec;

#endif // HAVE_32KHZ_OSC

	// Initialize Count/Compare; valid even if not using CP0 as ticker
	Cp0WrCompare(Cp0RdCount() + dwReschedIncrement);

#ifdef USE_CP0_TIMER
    RETAILMSG(1,(L"Using CP0 tick source\r\n"));
#else
    RETAILMSG(1,(L"Using RTCTICK tick source\r\n"));
#endif
}

/********************************************************************/

/*
 * This routine is called by the kernel when the system is idle
 * (ie. there are no threads to schedule).  The system can be brought
 * to a state that minimizes power usage but still can wake up quickly.
 */

VOID
OEMIdle(DWORD dwIdleParam)
{
	extern volatile ULONG TickCount; // in isr.s
    DWORD dwIdleMSec;            // holds number of millisec the CPU should IDLE
    DWORD dwRTCMatch0;           // RTC match 0 for interrupt generation to cause wakeup from IDLE0
	ULONG tmp = 0;
	DWORD oldRTCTick = 0;
	ULONGLONG delta;

#ifdef USE_CP0_TIMER
	// Can not use WAIT if using CP0 Count as tick source since
	// CP0 Counter doesn't count during Idle mode...

#ifdef PLATFORM_COLLECT_IDLEDATA_EXPRESSION

	if (PLATFORM_COLLECT_IDLEDATA_EXPRESSION)
	{
		// Capture time into Idle
		*pdwIdleData++ = Cp0RdCount();

	   // This is a busy idle loop
	   fInterruptFlag = 0;
	   INTERRUPTS_ON();
	   while (0 == fInterruptFlag) ;
	   INTERRUPTS_OFF();

		// Capture time out of Idle
		*pdwIdleData++ = Cp0RdCount();
		if (pdwIdleData >= (DWORD *)PLATFORM_IDLEDATA_STOP_ADDRESS)
			pdwIdleData = (DWORD *)PLATFORM_IDLEDATA_START_ADDRESS;
	}
#endif
    return;
#endif

    //
    // Ensure the idle period did not elapse by now.
    //
    if (dwReschedTime <= *(PULONG)AddrCurMSec)
        return;

    //
    // Calculate the milliseconds we should put CPU into IDLE
    //
    dwIdleMSec = dwReschedTime - *(PULONG)AddrCurMSec;

    //
    // Limit the Maximum sleep time for 32-bit 1ms counter
    //
    if (dwIdleMSec > MAXSLEEPTIMEMILLSEC)
        dwIdleMSec = MAXSLEEPTIMEMILLSEC;

    //
    // Set the RTCMatch0 interrupt.
    // Interrupt HWINTR_RTCMATCH0 initialized in OEMInit.
	// Since the counter is free-running, it is possible to have
	// other matches while the CPU was busy (and not entering idle),
	// so must clear any previous interrupt before enabling the new
	// match value.
    //
#ifndef AU13XX
    OEMInterruptClearEdge(SYSINTR_IDLEWAKEUP);
#endif
    OEMInterruptDone(SYSINTR_IDLEWAKEUP);

    //
    // Wake CPU from Idle by using RTC Match2 interrupt.
    // Add Idle time (dwIdleMSec).
    //
    dwRTCMatch0 = Sys->rtcread + dwIdleMSec;
    Sys->rtcmatch0 = dwRTCMatch0;
	WBSYNC();

	// Platform specific debugging code
#ifdef PLATFORM_OEMIDLE_PREIDLE_DEBUG_CODE
	PLATFORM_OEMIDLE_PREIDLE_DEBUG_CODE
#endif

	oldRTCTick = Sys->rtcread;

    //
    // Allow interrupts by setting Status[IE] and enter Idle mode
    //
	Cp0WrStatus(dwIdleParam | 1);
    CPUEnterIdleState();

	//
	// Disable interrupts after waking
	//
	Cp0WrStatus(dwIdleParam);


	// after IDLE0, update CurMSec with delta ticks from RTC counter
	delta = (Sys->rtcread - oldRTCTick);
	// account for timer being fast - see comments in isr.s
	delta = (delta * 32000)/32768;
	*(PULONG)AddrCurMSec += (ULONG)delta;

	// Platform specific debugging code
#ifdef PLATFORM_OEMIDLE_POSTIDLE_DEBUG_CODE
	PLATFORM_OEMIDLE_POSTIDLE_DEBUG_CODE
#endif

    if ((curridlelow + delta) < curridlelow)
        curridlehigh++;

    curridlelow += (ULONG)delta;

    return;
}

/********************************************************************/

/*
 * This routine is the GetTickCount system call.  It returns the number
 * of milliseconds elapsed since the system was started.
 * The DWORD will wrap after approx  49.7 days (0xffffffff mS)
 */

DWORD
OEMGetTickCount(VOID)
{
	return *(PULONG)AddrCurMSec;
}

/********************************************************************/

//
// Private CPU dependent functions for accessing the RTC.
//

static ULONGLONG
HalQueryRtcFrequency(VOID)

/*++

Routine Description:

    Returns the system RTC frequency in Hz.

Arguments:

    None.

Return Value:

    Returns the system RTC frequency in Hz.

--*/

{
    return (ULONGLONG)1;
}

/********************************************************************/

static ULONGLONG
HalQueryRtcCount(VOID)

/*++

Routine Description:

    Reads the RTC and returns the read value.

Arguments:

    None.

Return Value:

    Returns the current tick count on the RTC.

--*/

{
    ULONG RtcCount;

#ifdef HAVE_32KHZ_OSC
    RtcCount = Sys->toyread;
#else
//#error what to do
	RtcCount = 0; // make compiler happy
#endif

    return (ULONGLONG)RtcCount;
}

/********************************************************************/

static VOID
HalSetRtcAlarmCount(ULONGLONG AlarmReg)

/*++

Routine Description:

    Sets the real time clock alarm.  Note that the Au1000 has a 32-bit
    RTC count, so only the low 32 bits of the argument are used.  This
    shouldn't be a problem as the  RTC count will take 2^32
    seconds (over a century) to wrap.

    Match register 2 on  PC0 is the only match capable of waking
    the device.

Arguments:

    AlarmReg - Time to set the RTC alarm for

Return Value:

    None.

--*/

{
#ifdef HAVE_32KHZ_OSC
    ULONG tmp;


    //
    // Clear any pending alarm intr
    //
#ifndef AU13XX
    OEMInterruptClearEdge(SYSINTR_RTC_ALARM);
#endif
    //
    // Set the new alarm time.
    //
    tmp = (ULONG)(AlarmReg & 0xFFFFFFFF);
    Sys->toymatch2 = tmp;

    //
    //
    //
    OEMInterruptDone(SYSINTR_RTC_ALARM);
#else
//#error what to do
#endif
}

/********************************************************************/

//
// Private functions to convert between RTC ticks and 100 Ns
//

static ULONGLONG
RtcCountToHNs(ULONGLONG RtcCount)

/*++

Routine Description:

    Converts the system wide RTC counter to a 100Ns value.

Arguments:

    RtcCount - The RTC value to convert.

Return Value:

    TRUE if successful, FALSE otherwise.

--*/

{
    ULONGLONG Frequency;

    //
    // Retrieve the frequency of the RTC clock.
    //

    Frequency = HalQueryRtcFrequency();

    //
    // Perform the conversion.
    //

    return ( (RtcCount * (ULONGLONG)10000000) / Frequency );
}

/********************************************************************/

static ULONGLONG
HNsToRtcCount(ULONGLONG HNs)

/*++

Routine Description:

    Converts a 100 ns unit based value to RTC ticks.

Arguments:

    Hns - 100 ns based value to convert.

Return Value:

    TRUE if successful, FALSE otherwise.

--*/

{

    ULONGLONG Frequency;

    //
    // Retrieve the frequency of the RTC clock.
    //

    Frequency = HalQueryRtcFrequency();

    //
    // Perform the conversion.
    //

    return ( (HNs * Frequency) / ((ULONGLONG)10000000) );
}

/********************************************************************/

//
// Stored bias value in hundred ns.
//

static ULONGLONG RealTimeBias = (ULONGLONG)0;


//
// Kernel linkage functions.
//


BOOL
OEMGetRealTime(OUT LPSYSTEMTIME SystemTime)

/*++

Routine Description:

    Gets the current system time and returns it in the
    LPSYSTEMTIME parameter.

Arguments:

    SystemTime      The current system time.

Return Value:

    TRUE if successful, FALSE otherwise.

--*/

{
    ULONGLONG RealTime;
    FILETIME FileTime;


	RealTime = (ULONGLONG)Sys->toyread;
	DEBUGMSG(0,(TEXT("OEMGetRealTime 0x%016I64X\r\n"),RealTime));
	RealTime = RtcCountToHNs(RealTime);

	/* Add our RTC Datum Ticks */
	RealTime += g_Ticks;

	FileTime.dwLowDateTime = (DWORD)(RealTime);
	FileTime.dwHighDateTime = (DWORD)(RealTime>>32);

	if ( NKFileTimeToSystemTime(&FileTime, SystemTime) ) {
		return TRUE;
	}

    return FALSE;
}

/********************************************************************/

BOOL
OEMSetRealTime(IN LPSYSTEMTIME SystemTime)

/*++

Routine Description:

    Sets the RTC to the time specified in the LPSYSTEMTIME parameter

Arguments:

    SystemTime      The new system time.

Return Value:

    TRUE if successful, FALSE otherwise

--*/


{
    BOOL Success = FALSE;
	FILETIME FileTime;
	ULONGLONG ticks;

    // Au1x00 TOY is 32bits wide tick count. from Jan 1, 1970 that would allow us to reach
    // 2038 before any problems. This is consistent with POSIX 32bit time_t
    if (SystemTime->wYear < RTC_YEAR_DATUM || (SystemTime->wYear - RTC_YEAR_DATUM) > 68) {
        RETAILMSG(1, (L"ERROR: OEMSetRealTime: "
            L"RTC cannot support a year greater than %d or less than %d "
            L"(value %d)\r\n", (RTC_YEAR_DATUM + 68), RTC_YEAR_DATUM,
            SystemTime->wYear
        ));
        goto cleanUp;
    }

    Success = NKSystemTimeToFileTime(SystemTime, &FileTime);

	if (Success) {
		/* Our TOY's trim was setup to count every 1 second
		   convert the 100ns intervals to seconds below
		 */
		ticks = (ULONGLONG) FileTime.dwHighDateTime << 32 | FileTime.dwLowDateTime;
		/* Subtract our RTC Datum Ticks */
		ticks -= g_Ticks;
		ticks = HNsToRtcCount(ticks);

		/* Wait for no pending write */
		while(Sys->cntrctrl & SYS_CNTRCTRL_TS )
			;;
	    Sys->toywrite = (DWORD)(ticks);
		WBSYNC();
//	    Sys->toywrite = (DWORD)(ticks);
//		WBSYNC();

		DEBUGMSG(0,(TEXT("OEMSetRealTime 0x%016I64X\r\n"),ticks));

	}
cleanUp:
    return Success;
}

/********************************************************************/

BOOL
OEMSetAlarmTime(IN LPSYSTEMTIME AlarmTime)

/*++

Routine Description:

    Will cause the OAL to return a SYSINTR_RTC_ALARM when the RTC reaches
    the time specified in the AlarmTime parameter.

Arguments:

    AlarmTime       The next alarm time.

Return Value:

    TRUE if successful, FALSE otherwise

--*/

{
    FILETIME FileTime;
    ULONGLONG RtcAlarmTime;
    BOOL Success;


    Success = NKSystemTimeToFileTime(AlarmTime, &FileTime);

    if (Success) {
        RtcAlarmTime = (ULONGLONG) FileTime.dwHighDateTime << 32;
        RtcAlarmTime |= FileTime.dwLowDateTime;
        RtcAlarmTime -= RealTimeBias;
        RtcAlarmTime = HNsToRtcCount(RtcAlarmTime);

        HalSetRtcAlarmCount(RtcAlarmTime);
    }

    return Success;
}

/********************************************************************/

BOOLEAN
OEMInitRealTime(IN LPSYSTEMTIME SuggestedTime)

/*++

Routine Description:

    This routine initializes the RTC.
    If the system was hard reset then apply this value

Arguments:

    SuggestedTime       The value that the system suggests that you set
                        the RTC to if this platform does not retain the
                        RTC on powerdown.

Return Value:

    TRUE - changed
    FALSE - not changed

--*/

{
	g_Ticks = (ULONGLONG)g_Ftime.dwHighDateTime<<32 | g_Ftime.dwLowDateTime;

	// Only use this if persistent RTC is not kept
#if 0
    OEMSetRealTime(SuggestedTime);
#endif
    return TRUE;
}

/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/

ULONG
OEMInterruptConnectTimer(VOID)

/*++

Routine Description:

    This routine connects an interrupt timer by allocating a SYSINTR
    for a free timer.

Arguments:

    None.

Return Value:

    A SYSINTR associated with the timer.
    SYSINTR_NOP indicates failure

--*/

{
#ifdef HAVE_32KHZ_OSC
    DWORD SysIntr = SYSINTR_NOP;
    ULONG i;
    ULONG IntrState;

    DEBUGMSG(ZONE_INTR,(L"+OEMInterruptConnectTimer()\r\n"));

    //
    // Is there a free timer?
    //
    IntrState=DISABLE_INTERRUPTS();

    for (i = 0; i < OS_TIMER_COUNT; i++)
    {
        if (SYSINTR_NOP == Timers[i].SysIntr)
        {
            // label timer as used
            Timers[i].SysIntr = SYSINTR_MAXIMUM;
            break;
        }
    }

    RESTORE_INTERRUPTS(IntrState);

    if (OS_TIMER_COUNT == i)
        goto ErrorReturn;

    //
    //  Is there an available SysIntr?
    //
    SysIntr = OEMInterruptConnect(Internal, 0, HWINTR_RTCMATCH0 + i, 0);

	// Enable the interrupt
	OEMInterruptDone(SysIntr);

    Timers[i].SysIntr = SysIntr;

ErrorReturn:

    RETAILMSG(ZONE_INTR,(L"-OEMInterruptConnectTimer() = %x(i::%d)\r\n",SysIntr,i));
    return SysIntr;
#else
	return SYSINTR_NOP;
#endif
}

/********************************************************************/

VOID
OEMInterruptDisconnectTimer(IN ULONG SysIntr)

/*++

Routine Description:

    This routine disconnects an interrupt timer.

Arguments:

    SysIntr     SYSINTR assigned by OEMInterruptConnectTimer().

Return Value:

    None.

--*/

{
#ifdef HAVE_32KHZ_OSC
    ULONG i;


    for (i = 0; i < OS_TIMER_COUNT; i++)
    {
        if (SysIntr == Timers[i].SysIntr)
            break;
    }

    if (OS_TIMER_COUNT != i)
    {
        OEMInterruptDisconnect(SysIntr);
        // free timer
        Timers[i].SysIntr = SYSINTR_NOP;
    }
#endif
}

/********************************************************************/

BOOLEAN
OEMInterruptStartTimer(
    IN ULONG SysIntr,
    IN ULONG PeriodHns
    )

/*++

Routine Description:

    This routine starts an allocated timer and sets it to interrupt at the
    specified period.

Arguments:

    SysIntr         SYSINTR associated with the timer (returned by
                    InterruptConnectTimer).

    PeriodHns       Period for the timer in 100 ns units.

Return Value:

    Returns TRUE if successful, FALSE otherwise.

--*/

{
#ifdef HAVE_32KHZ_OSC
    BOOLEAN Status = FALSE;
	ULONG StatusCheck;
    ULONG Periodms;
	ULONGLONG Ticks;
    ULONG Now;
    ULONG i;

    DEBUGMSG(ZONE_INTR,(L"+OEMInterruptStarTimer(%x,%x)\r\n", SysIntr,PeriodHns));

    //
    // Find the timer
    //
    for (i=0; i < OS_TIMER_COUNT;i++)
    {
        if (SysIntr == Timers[i].SysIntr)
            break;
    }

    if (OS_TIMER_COUNT == i)
        goto ErrorReturn;

    //
    // Convert period to mS
    //
    Periodms = PeriodHns / 10000;

    //
    // Convert to ticks
    //
    Ticks = Periodms / TickerPeriodmS;


	// Account for the timer running fast
	//  - see comments in isr.s
	Ticks = (Ticks * 32768) / 32000;

    //
    // Add 1 for round off errors
    //
    Ticks++;

    // wait until match register is writable
    StatusCheck = SYS_CNTRCTRL_RM0 << i;
    while (Sys->cntrctrl & StatusCheck);

    Now = Sys->rtcread;

    *(PULONG)((ULONG)&Sys->rtcmatch0+(4*i)) = Now + (ULONG)Ticks;

    // wait until write takes place
    StatusCheck = SYS_CNTRCTRL_RM0 << i;
    while (Sys->cntrctrl & StatusCheck);

	OEMInterruptDone(SysIntr);

    Timers[i].StartTime = Now;
    Timers[i].Duration = (ULONG)Ticks;

    Status = TRUE;

ErrorReturn:

    DEBUGMSG(ZONE_INTR,(L"-OEMInterruptStarTimer() = %x\r\n",SysIntr));

    return Status;
#else
	return FALSE;
#endif
}

/********************************************************************/

BOOLEAN
OEMInterruptStopTimer(IN ULONG SysIntr)

/*++

Routine Description:

    Stops the timer associated with the specified SYSINTR.

Arguments:

    SysIntr         SYSINTR corresponding to the timer to stop.

Return Value:

    TRUE for success, FALSE otherwise.

--*/

{
#ifdef HAVE_32KHZ_OSC
    BOOLEAN Status = FALSE;
    ULONG i;

    DEBUGMSG(ZONE_INTR,(L"+OEMInterruptStopTimer(%x)\r\n", SysIntr));

    //
    // Find the timer
    //
    for (i=0; i < OS_TIMER_COUNT;i++)
    {
        if (SysIntr == Timers[i].SysIntr)
            break;
    }

    if (OS_TIMER_COUNT != i)
    {
		OEMInterruptDisable(SysIntr);
        Status = TRUE;
    }

    return Status;
#else
	return FALSE;
#endif
}

/********************************************************************/

ULONGLONG
OEMInterruptQueryTimer(IN ULONG SysIntr)
/*++

Routine Description:

    Queries the timer associated with the specified SYSINTR.

Arguments:

    SysIntr         SYSINTR corresponding to the timer to stop.

Return Value:

    100nS units since the timer was started. Granularity is 1mS
    0xffffffffffffffff indicates error


--*/

{
#ifdef HAVE_32KHZ_OSC
    ULONG Now;
    ULONGLONG Elapsed = 0xffffffffffffffff;
    ULONG i;

    //
    // Find the timer
    //
    for (i=0; i < OS_TIMER_COUNT;i++)
    {
        if (SysIntr == Timers[i].SysIntr)
            break;
    }

    if (OS_TIMER_COUNT != i)
    {
        Now = Sys->rtcread;
        Elapsed = Now - Timers[i].StartTime;
        Elapsed *= TickerPeriodmS;
        Elapsed *= 10000;

		// Account for the RTC timer running fast
		Elapsed = (Elapsed * 32000) / 32768;
    }

	return Elapsed;
#else
	return 0;
#endif
}

BOOL OALIoCtlConnectTimer(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    ULONG SysintrResult = OEMInterruptConnectTimer();

    //
    // Fill in the returned SYSINTR.
    //
    *(PULONG)pOutBuffer = SysintrResult;

    //
    // Update size field for return data.
    //
    *pOutSize = sizeof(ULONG);

    return TRUE;
}


OALIoCtlDisconnectTimer(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
    ULONG Sysintr = *(PULONG)pInpBuffer;

    //
    // Call the timer disconnect routine.
    //
    OEMInterruptDisconnectTimer(Sysintr);

    return TRUE;
}

OALIoCtlStartTimer(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {

	INTR_START_TIMER_IOCTL_PARAM *StartTimerParam = (INTR_START_TIMER_IOCTL_PARAM*)pInpBuffer;

	//
	// Call the start timer routine.
	// Fill in returned result code.
	*(PBOOLEAN)pOutBuffer = OEMInterruptStartTimer(StartTimerParam->SysIntr,
	                                        StartTimerParam->PeriodHns);


	//
	// Update size field for return data.
	//
	*pOutSize = sizeof(BOOLEAN);

	return TRUE;
}

OALIoCtlStopTimer(
    UINT32 code, VOID* pInpBuffer, UINT32 inpSize, VOID* pOutBuffer,
    UINT32 outSize, UINT32 *pOutSize
) {
	ULONG Sysintr = *(PULONG)pInpBuffer;

	//
	// Call the stop timer routine.
	//
	*(PBOOLEAN)pOutBuffer = OEMInterruptStopTimer(Sysintr);

	//
	// Update size field for return data.
	//
	*pOutSize = sizeof(BOOLEAN);

	return TRUE;
}


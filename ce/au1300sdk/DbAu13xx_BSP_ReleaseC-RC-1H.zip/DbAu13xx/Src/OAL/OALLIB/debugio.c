/*++
Copyright (c) 2001-2004  BSQUARE Corporation.  All rights reserved.

Module:

     serial.c

Abstract:

     Implements the debugger port.


Author(s):
    GJS March 2001

Revision(s):

--*/

#include "bsp.h"
#include "platform.h"

/********************************************************************/

// select the debug port here
#ifndef DEBUG_UART_BASE
#define DEBUG_UART_BASE	(UART2_PHYS_ADDR+KSEG1_OFFSET)
#endif

#ifndef DEBUG_PORT_BAUDRATE
#define DEBUG_PORT_BAUDRATE 115200
#endif

/********************************************************************/

static AU1X00_UART *Uart = (AU1X00_UART *)DEBUG_UART_BASE;

static BOOL DebugEnableState=TRUE;

/********************************************************************/

BOOL
GetDebugEnabledState(void)
{
	return DebugEnableState;
}

/********************************************************************/

VOID
SetDebugEnabledState(BOOL State)
{
	DebugEnableState = State;
}

/********************************************************************/

static void
InitDebugSerial(ULONG BaudRate)
{
    ULONG BaudRateDivisor;

	// Enable the UART
	Uart->enable = 0;
	Uart->enable = UART_ENABLE_CE;
	Uart->enable = UART_ENABLE_CE|UART_ENABLE_E;
	Uart->fifoctrl = UART_FIFOCTRL_FE | UART_FIFOCTRL_TFT;
	Uart->linectrl = 3;
	Uart->mdmctrl = UART_MDMCTRL_DT | UART_MDMCTRL_RT;

	BaudRateDivisor = OEMGetPBUSFrequency() / (16 * BaudRate);

	Uart->clkdiv = BaudRateDivisor;
}

/********************************************************************/
#if 0
VOID
FlushDebugPort(void)
{
	ULONG tmp;
	ULONG Attempts; // don't wait forever!

	// read linestat
	Attempts = 100000;
	do {
		tmp = Uart->linestat;
		if (0 == Attempts--)
				break;

	} while(!(tmp & UART_LINESTAT_TE));

	return;
}
#endif

VOID
OEMInitDebugSerial(VOID)
{
	InitDebugSerial(DEBUG_PORT_BAUDRATE);
	OEMWriteDebugString(L"\r\n\r\n");
}

/********************************************************************/

VOID
OEMWriteDebugString(USHORT *Str)
{
	UCHAR Ch,prevCh=0;

	while (*Str)
	{
		Ch = (UCHAR)*Str & 0xff;
		if ( Ch == '\n' && prevCh != '\r' )
			OEMWriteDebugByte('\r');
		OEMWriteDebugByte(Ch);
		prevCh = Ch;
		Str++;
	}
}

/********************************************************************/

VOID
OEMWriteDebugByte(UCHAR Char)
{
	if (GetDebugEnabledState())
	{
		//	Is it ready for tx?
		while (!(Uart->linestat & UART_LINESTAT_TT))
		{
			; // spin on it....
		}

		Uart->txdata = Char;
	}
}

/********************************************************************/

int
OEMReadDebugByte(VOID)
{
	int RetVal = OEM_DEBUG_READ_NODATA;

	if (GetDebugEnabledState())
	{
		if (Uart->linestat & UART_LINESTAT_DR)
		{
			RetVal = Uart->rxdata & 0xFF;
		}
	}

	return RetVal;
}

/********************************************************************/

VOID
OEMClearDebugCommError(VOID)
{
	ULONG Tmp;
	if (GetDebugEnabledState())
	{
		Tmp = Uart->fifoctrl;
		Tmp |= UART_FIFOCTRL_RR;
		Uart->fifoctrl = Tmp;
		Tmp &= ~UART_FIFOCTRL_RR;
		Uart->fifoctrl = Tmp;
	}
}

/********************************************************************/

/*
 * Stub PPFS
 */
BOOL NoPPFS = TRUE;

int
OEMParallelPortInit(VOID)
{
	NoPPFS = TRUE;
	return FALSE;
}

int
OEMParallelPortGetByte(VOID)
{
	return 0;
}

VOID
OEMParallelPortSendByte(BYTE chData)
{
	return;
}

/********************************************************************/



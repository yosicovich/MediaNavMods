
//#define	SMSC_DIRECT_INTR	// GPIO Edge-Triggered Direct Interrupt (SMSC9118.IRQ --> GPIO, no intervening CPLD)

#define CACHE_LINE_BYTES        		32UL    //Cache size = 32bytes

#define RX_END_ALIGNMENT                (CACHE_LINE_BYTES)
#define TX_BURST_DMA_END_ALIGNMENT      (CACHE_LINE_BYTES)
#define INT_DEAS                        0x16000000UL


#define DmaInitialize(hMiniportAdapterContext) FALSE
#define DmaStartXfer(x) FALSE
#define DmaGetDwCnt(x, c) 0
#define DmaDisable(x, c)
#define DmaComplete(x, c)
#define BufferCacheFlush(a, c)

void PlatformInitialize(void);
void PlatformDisplayInfo(void);
void PlatformSetBusWidth(const DWORD dwBusWidth);
void PlatformSetBusTiming(const DWORD dwChipIdReg);
void PlatformEnableGpioInterrupt(void);
void GetMacAddress( DWORD *hi, DWORD *lo);
#include <windows.h>
#include <Pkfuncs.h>
#include "smsc9118.h"
#include <platform.h>
#include <macaddr.h>

static volatile PDWORD		pdwGpioCtrl;

extern DWORD	ReadCLKCFG(void);

void PlatformSetBusWidth(const DWORD dwBusWidth)
{
	// This is already setup by the bootloader
}

/* PlatformInitialize:
 *   perform any platform initialization necessary to make the Lan9118 visible.
 *   This function must be called before PlatformGetLanBase
 */
void PlatformInitialize()
{
	SMSC_TRACE0(DBG_INIT, "+PlatformInitialize()\r\n");
	// This is already setup by the bootloader
	SMSC_TRACE0(DBG_INIT, "+PlatformInitialize()\r\n");
}

void PlatformSetBusTiming(const DWORD dwChipIdReg)
{
	SMSC_TRACE0(DBG_INIT, "+PlatformSetBusTiming()\r\n");
	// This is already setup by the bootloader
	SMSC_TRACE0(DBG_INIT, "-PlatformSetBusTiming()\r\n");
}

/* PlatformDisplayInfo:
 *   Will display info specific to the platform, such as
 *   processor registers, or DMA configurations
 */
void PlatformDisplayInfo()
{
	SMSC_TRACE0(DBG_INIT, "+PlatformDisplayInfo()\r\n");
	// I don't care
	SMSC_TRACE0(DBG_INIT, "-PlatformDisplayInfo()\r\n");
}


void CleanCacheLine(DWORD dwAddr);
void DrainWriteBuffers(void);
ULONG GetPID(void);

void PlatformEnableGpioInterrupt(void)
{
	// Not supported
}

void EnableCPUInt(void)
{
	// Do we really need these?
}

void DisableCPUInt(void)
{
	// Do we really need these?
}

VOID GetMacAddress( ULONG *hi, ULONG *lo)
{
    MACADDR_IN_FLASH *pMif;
    pMif = (MACADDR_IN_FLASH*)(KSEG1_OFFSET + MAC_ADDR_BASE);

	*hi = pMif->u.AsLong.Mac0[1];
	*lo = pMif->u.AsLong.Mac0[0];
	RETAILMSG(1,(TEXT("GetMacAddress: HI:%X LO:%X\r\n"), *hi, *lo));
}

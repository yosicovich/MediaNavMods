/*++
Copyright (c) 2004  BSQUARE Corporation.  All rights reserved.

Module Name:

    psc_spi.c

Module Description:



Author:

    Ian Rae - July 2004


--*/

#include <windows.h>
#include <platform.h>
#include <bceddk.h>
#include <gpio.h>
#include <SPI.h>

#ifdef DEBUG

#define ZONE_INIT                DEBUGZONE(0)
#define ZONE_CLOCKS              DEBUGZONE(1)
#define ZONE_GPIOS               DEBUGZONE(2)
#define ZONE_IOCTL               DEBUGZONE(3)
#define ZONE_FUNC                DEBUGZONE(4)
#define ZONE_WARNING             DEBUGZONE(14)
#define ZONE_ERROR               DEBUGZONE(15)

DBGPARAM dpCurSettings = {
    TEXT("Ohcd"), {
        TEXT("Init"), TEXT("Clocks"), TEXT("Gpios"), TEXT("IOCTLs"),
        TEXT("-"), TEXT("-"), TEXT("-"), TEXT("-"),
        TEXT("-"), TEXT("-"), TEXT("-"),TEXT("-"),
        TEXT("Alloc"), TEXT(""),TEXT("Warnings"), TEXT("Errors")},
    0xffff};
#else
#if 0
#undef DEBUGMSG
#define DEBUGMSG(x,y) RETAILMSG(x,y)
#define ZONE_INIT                1
#define ZONE_CLOCKS              1
#define ZONE_GPIOS               1
#define ZONE_IOCTL               1
#define ZONE_FUNC                1
#define ZONE_WARNING             1
#define ZONE_ERROR               1
#endif
#endif
//
// IOCTLS used to access the driver
//
enum {
    IOCTL_SPI_TRANSFER = 0x80002000  // some arbirary base
};

#define TEST
#ifdef TEST
// This test routine reads temperature data from the TMP121
// chip on the Db1550 and Pb1200. BCSR Board Specific registers
// should be set in PLATFORM_SPI_PSC_INIT_CODE define to select
// the temperature sensor
DWORD TestThread(VOID)
{
	HANDLE hSPI;
	LONG value;
	SHORT temp;

	Sleep(4000);

	RETAILMSG(1,(TEXT("Test thread\r\n")));

	hSPI = SPI_Initialize(PSC_SPI_CFG_DE |
	                      PSC_SPI_CFG_BRG_N(4) |
						  PSC_SPI_CFG_LEN_N(15) |
						  PSC_SPI_CFG_DIV_N(1) |
						  PSC_SPI_CFG_LB |
						  PSC_SPI_CFG_MO);

	RETAILMSG(1,(TEXT("Opened SPI handle %X\r\n"),hSPI));

	while(1) {
		SPI_DoTransfer(hSPI,1,NULL,&value);

		temp = (SHORT)(value & ~0x7);
		temp = temp / 8;
		temp = ((temp*625) / 10000);

		RETAILMSG(1,(TEXT("Temp: %d C (0x%X)\r\n"),temp,(value&~0x7)));
		Sleep(1000);
	}

	return 0;
}

#endif

//
// Structure for storing device instance data.  There is one of these per
// instance of a device.  We could have 2 devices in the system, in which case
// there would be two of these structures.
//
typedef struct _DEVICE_INSTANCE {
    PSC_SPI *           pSPI;           // The PSC SPI controller area
	ULONG               SPIConfiguration;
	PDMA_CHANNEL_OBJECT TxDma;
	PDMA_CHANNEL_OBJECT RxDma;
	ULONG               DmaBufferSize;
	ULONG               SysIntr;
	HANDLE              hIsrEvent;
} DEVICE_INSTANCE, *PDEVICE_INSTANCE;

static BOOL InitializeRegisters(PDEVICE_INSTANCE DeviceInstance)
{
	PSC_SPI *pSPI = DeviceInstance->pSPI;
	ULONG SPIConfiguration = DeviceInstance->SPIConfiguration;
	BOOL status = TRUE;
	int timeout;

	// Configure the PSC for SPI
	WRITE_REGISTER_ULONG((PULONG)&pSPI->psc.sel, PSC_SEL_PS_SPI | PSC_SEL_CLK_TOY);
	// Enable the PSC
	WRITE_REGISTER_ULONG((PULONG)&pSPI->psc.ctl, PSC_CTL_CE |PSC_CTL_EN);

	timeout = 50;

	// wait for clock detect
	while (timeout && !((READ_REGISTER_ULONG((PULONG)&pSPI->sts)) & PSC_SPI_STS_SR)) {
		timeout--;
		StallExecution(1000);
	}

	if (!timeout) {
		status = FALSE;
		RETAILMSG(1,(TEXT("Timeout waiting for SR\r\n")));
		goto ErrorReturn;
	}

	// Configure the SPI controller
	WRITE_REGISTER_ULONG((PULONG)&pSPI->msk,0xffffffff);

	// Always use DMA
	SPIConfiguration &= ~PSC_SPI_CFG_DD;
	// Enable device
	SPIConfiguration &= ~PSC_SPI_CFG_DE;
	// Set FIFO thresholds to 8 byte each
	SPIConfiguration |= (PSC_SPI_CFG_TRD|PSC_SPI_CFG_RRD);

	WRITE_REGISTER_ULONG((PULONG)&pSPI->cfg, SPIConfiguration);
	WRITE_REGISTER_ULONG((PULONG)&pSPI->cfg, SPIConfiguration | PSC_SPI_CFG_DE);

	// wait unti the device is ready
	timeout = 50;
	while (timeout && !((READ_REGISTER_ULONG((PULONG)&pSPI->sts)) & PSC_SPI_STS_DR)) {
		StallExecution(1000);
		timeout--;
	}

	if (!timeout) {
		status = FALSE;
		RETAILMSG(1,(TEXT("Timeout waiting for DR\r\n")));
		goto ErrorReturn;
	}

ErrorReturn:
	return status;
}

static
BOOL DoTransfer( PDEVICE_INSTANCE DeviceInstance,
			     ULONG            Size,
				 PULONG           pInBuffer,
				 PULONG           pOutBuffer)
{
	PSC_SPI *pSPI = DeviceInstance->pSPI;
	PULONG pDmaBuffer;
	BOOL status = TRUE;
	ULONG intStat;

	WRITE_REGISTER_ULONG((PULONG)&pSPI->pcr,PSC_SPI_PCR_RC | PSC_SPI_PCR_TC);

	DEBUGMSG(ZONE_FUNC,(TEXT("+DoTransfer: %X %X (%d)\r\n"),pInBuffer,pOutBuffer,Size));

	// Get next TX DMA Buffer
	pDmaBuffer = HalGetNextDMABuffer(DeviceInstance->TxDma);

	// Copy TX Data, or zero out for Rx only transfer
	if (pInBuffer==NULL) {
		memset(pDmaBuffer, 0, Size*sizeof(ULONG));
	} else {
		memcpy(pDmaBuffer, pInBuffer, Size*sizeof(ULONG));
	}

	// Give buffer back to DMA
	HalActivateDMABuffer(DeviceInstance->TxDma,pDmaBuffer,Size*sizeof(ULONG));

	// Start Master xfer
	WRITE_REGISTER_ULONG((PULONG)&pSPI->pcr, PSC_SPI_PCR_MS);

	// Wait for interrupt
	WaitForSingleObject(DeviceInstance->hIsrEvent,INFINITE);

	// Copy out any Rx Data
	if (pOutBuffer!=NULL) {
		ULONG RxSize;

		pDmaBuffer = HalGetNextDMABuffer(DeviceInstance->RxDma);
		RxSize = HalGetDMABufferRxSize(DeviceInstance->RxDma,pDmaBuffer);

		memcpy(pOutBuffer,pDmaBuffer,Size*sizeof(ULONG));

		HalActivateDMABuffer(DeviceInstance->RxDma,pDmaBuffer,DeviceInstance->DmaBufferSize);
	}

	// Ack interrupt
	intStat = HalCheckForDMAInterrupt(DeviceInstance->TxDma);
	HalAckDMAInterrupt(DeviceInstance->TxDma,intStat);
	InterruptDone(DeviceInstance->SysIntr);

	return status;
}


//
// Exported Routines
//

BOOL
WINAPI
DllMain(
    IN HANDLE Instance,
    IN DWORD Reason,
    IN PVOID Reserved
    )

/*++

Routine Description:

    This is the standard DLL entry point for all DLLs.  Microsoft on-line
    documentation provides additional information.  In general, the routine
    is called for every time LoadLibrary or FreeLibrary are called, when
    threads are created and terminated, and when processes are created and
    destroyed.  For most drivers, the routine is never used.  The exception
    to this case is if the driver needs to allocate and track resources on
    a per process or per thread basis.

Arguments:

    Instance - Handle to the DLL.

    Reason - Specifies the reason why the routine was called.

    Reserved - Provides additional information about why the routine was
        called.

Return Value:

    TRUE if successful, FALSE otherwise.

--*/

{
    //
    // This routine doesn't do anything except print out the reason.  To
    // prevent getting flooded with prints, all of the debug messages are
    // disabled by default.  Changing a #define will enable the prints.
    //

    switch (Reason) {

    case DLL_PROCESS_ATTACH:
        DEBUGREGISTER(NULL);

        DEBUGMSG(0,(
                 TEXT("SPI: DLL_PROCESS_ATTACH.\r\n")));

        break;

    case DLL_PROCESS_DETACH:
        DEBUGMSG(0,(
                 TEXT("SPI: DLL_PROCESS_DETACH.\r\n")));

        break;

    case DLL_THREAD_DETACH:
        DEBUGMSG(0,(
                 TEXT("SPI: DLL_THREAD_DETACH.\r\n")));
        break;

    case DLL_THREAD_ATTACH:
        DEBUGMSG(0,(
                 TEXT("SPI: DLL_THREAD_ATTACH.\r\n")));
        break;

    default:
        DEBUGMSG(ZONE_ERROR, (
                 TEXT("SPI: DllEntry unknown reason.\r\n")));
        break;
    }

    //
    // Always return TRUE.  If FALSE is returned, processes that are starting
    // up will terminate with an error.
    //

    return TRUE;
}

BOOL
SPI_Deinit(
    IN OUT ULONG DeviceContext
    )

/*++

Routine Description:

    This routine is called to deinitialize the device driver.
    In general, this routine will never be called except under error
    conditions during initialization or if DeregisterDevice is called. If
    DeregisterDevice is called, it will be to unload the driver.

Arguments:

    DeviceContext - The value returned from SPI_Init.

Return Value:

    TRUE if successful, FALSE otherwise.

--*/

{
    PDEVICE_INSTANCE DeviceInstance;

    DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;

    DEBUGMSG(ZONE_INIT, (
             TEXT("SPI: SPI_Deinit(0x%x) entered.\r\n"),
             DeviceContext));

    //
    // If we've mapped the device's registers via a call to MmMapIoSpace, we
    // need to unmap the I/O range.
    //

    if (DeviceInstance->pSPI != NULL) {

        MmUnmapIoSpace((PVOID)DeviceInstance->pSPI,
                       sizeof(*(DeviceInstance->pSPI)));

    }

    //
    // Close DMA Channels.
    //

	HalFreeDMAChannel(DeviceInstance->TxDma);
	HalFreeDMAChannel(DeviceInstance->RxDma);

	CloseHandle(DeviceInstance->hIsrEvent);
	InterruptDisconnect(DeviceInstance->SysIntr);

    //
    // Finally, the device instance itself can be freed.
    //

    LocalFree(DeviceInstance);

    DEBUGMSG(ZONE_INIT, (
             TEXT("SPI: SPI_Deinit returning TRUE.\r\n")));

    return TRUE;
}


ULONG
SPI_Init(
    IN ULONG RegistryPath
    )

/*++

Routine Description:

    This routine is responsible for allocating resources and initializing
    hardware for this instance of the device.  Typical resources include
    memory for housekeeping, memory mapped I/O, a SYSINTR, an interrupt
    service thread, and resource locks.

    A single ULONG value is returned.  Assuming it is non-NULL, the value is
    used by the device manager to identify this instance of the device.  It is
    possible to have multiple devices in the system and have several different
    handles to those devices.  A serial port driver that implements (COM1:,
    COM2:, ...) is an example.  By returning a unique value (typically an
    address to some chunk of memory or an index into a table) per device
    instance information may be stored.  The value is subsequently passed into
    the SPI_Deinit, SPI_PowerUp, and SPI_PowerDown routines.  Contrast this
    device instance to the open instance.

    SPI_Init is called whenever RegisterDevice is called.  The device manager
    device.exe calls this routine when it processes our associated registry
    key HKLM\Drivers\Builtin\PIO.  By convention, device.exe passes in a
    pointer to a string that contains the registry path to the active key.
    This active key is created by device.exe.

    Although device.exe is usually the only caller of RegisterDevice, this is
    not always the case.  If a value named "Entry" is placed under our
    registry key (HKLM\Drivers\Builtin\Pio), device.exe will call the routine
    specified by the Entry value.  Such a routine would then need to call
    RegisterDevice if it wanted to register a streams interface driver for the
    system to use.  One of the parameters to RegisterDevice is dwInfo, which
    is user defined.  The registry key may be passed in (as is the convention
    with device.exe or some other value may be specified.

    This driver uses the conventional initialization method where device.exe
    calls RegisterDevice.

Arguments:

    RegistryPath - Path to the active key created by the device manager.  This
        path contains a key that contains a path to the driver's configuration
        data.

Return Value:

    The device context handle for this instance if successful or 0 for
    failure.

--*/

{
    BOOLEAN          RoutineSuccess = FALSE;
    PDEVICE_INSTANCE DeviceInstance;
    PHYSICAL_ADDRESS IoPhysicalAddress;
    PSC_SPI          *pSPI;
	HANDLE           hGPIO = NULL;
	ULONG            HwIntr;

    DEBUGMSG(ZONE_INIT, (
             TEXT("SPI: SPI_Init(0x%x) entered.\r\n"),
             RegistryPath));

    //
    // Allocate a structure to hold the state for this instance.  This value
    // is used as a handle and is returned by this routine.  When SPI_Open or
    // SPI_Close is called, this handle will be passed in as a parameter.
    //

    DeviceInstance = LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT,
                                sizeof(*DeviceInstance));

    if (DeviceInstance == NULL) {

        DEBUGMSG(ZONE_INIT|ZONE_ERROR, (
                 TEXT("SPI: Failed to allocate device instance.\r\n")));
        goto ErrorReturn;

    }

    //
    // Use MmMapIoSpace to map in the registers.
    //
#if (PLATFORM_SPI_PSC==0)
	IoPhysicalAddress.QuadPart = PSC0_PHYS_ADDR;
#elif (PLATFORM_SPI_PSC==1)
	IoPhysicalAddress.QuadPart = PSC1_PHYS_ADDR;
#elif (PLATFORM_SPI_PSC==2)
	IoPhysicalAddress.QuadPart = PSC2_PHYS_ADDR;
#elif (PLATFORM_SPI_PSC==3)
	IoPhysicalAddress.QuadPart = PSC3_PHYS_ADDR;
#else
#error PLATFORM_SPI_PSC must be defined in the range 0 to 3
#endif

	RETAILMSG(1,(L"Initializing PSC%d for SPI operation\r\n",PLATFORM_SPI_PSC));

    pSPI = MmMapIoSpace(IoPhysicalAddress,
                        sizeof(*pSPI),
                        FALSE);

    if (pSPI == NULL) {

        DEBUGMSG(ZONE_INIT|ZONE_ERROR, (
                 TEXT("SPI: MmMapIoSpace failed to map registers.\r\n")));
        goto ErrorReturn;

    }

    DeviceInstance->pSPI = pSPI;

#ifndef SOC_AU13XX
    hGPIO = GPIO_Init();
    if(hGPIO==INVALID_HANDLE_VALUE) {
        DEBUGMSG(ZONE_ERROR,(L"SPI: Can not open GPIO device\r\n"));
        goto ErrorReturn;
    }
#endif

#if defined(CPU_AU1550)
    if(!GPIO_SetPinFunction(hGPIO,SYS_PINFUNC_S0)) {
        DEBUGMSG(ZONE_ERROR,(L"SPI: Can not set pinfunc for SPI \r\n"));
        goto ErrorReturn;
    }
#elif defined(CPU_AU1200) && (PLATFORM_SPI_PSC==0)
    if(!GPIO_ClearPinFunction(hGPIO,SYS_PINFUNC_P0B | (1<<18))) {
        DEBUGMSG(ZONE_ERROR,(L"SPI: Can not set pinfunc for SPI \r\n"));
        goto ErrorReturn;
    }
    if(!GPIO_SetPinFunction(hGPIO,(1<<17))) {
        DEBUGMSG(ZONE_ERROR,(L"SPI: Can not set pinfunc for SPI \r\n"));
        goto ErrorReturn;
    }
#elif defined(CPU_AU1200) && (PLATFORM_SPI_PSC==1)
    if(!GPIO_ClearPinFunction(hGPIO,SYS_PINFUNC_P1A)) {
        DEBUGMSG(ZONE_ERROR,(L"SPI: Can not set pinfunc for SPI \r\n"));
        goto ErrorReturn;
    }
    if(!GPIO_SetPinFunction(hGPIO,SYS_PINFUNC_P1C)) {
        DEBUGMSG(ZONE_ERROR,(L"SPI: Can not set pinfunc for SPI \r\n"));
        goto ErrorReturn;
    }
#elif defined(CPU_AU13XX) && (PLATFORM_SPI_PSC==0)
// hack --
	{
	ULONG *p = (ULONG*)0xB1900024;
	*p |= 3<<12 | 3<<10;
	p = (ULONG*)0xb1900028;
	*p |= 0x01300000;
	}
#endif

	// Handle any platform specific initialization, GPIO handle available if needed
#if defined(PLATFORM_SPI_PSC_INIT_CODE)
	PLATFORM_SPI_PSC_INIT_CODE
#endif

	// we are done with GPIO now
	if (hGPIO)
		CloseHandle(hGPIO);

    DEBUGMSG(ZONE_INIT, (
             TEXT("SPI: SPI_Init finished hardware initialization.\r\n")));

	//
	// Setup DMA operations
	//
	DeviceInstance->DmaBufferSize = 512;

	DeviceInstance->TxDma = HalAllocateDMAChannel();
	DeviceInstance->RxDma = HalAllocateDMAChannel();

	if (DeviceInstance->TxDma==NULL || DeviceInstance->RxDma==NULL) {
		RETAILMSG(1,(TEXT("SPI: Unable to allocate DMA channels\r\n")));
		RoutineSuccess = FALSE;
	}

	HalInitDmaChannel(DeviceInstance->TxDma,
	                  DMA_SPI_TX,
					  DeviceInstance->DmaBufferSize,
					  TRUE);

	HalInitDmaChannel(DeviceInstance->RxDma,
	                  DMA_SPI_RX,
					  DeviceInstance->DmaBufferSize,
					  FALSE);

	HalSetDMAForReceive(DeviceInstance->RxDma);

	HalStartDMA(DeviceInstance->RxDma);
	HalStartDMA(DeviceInstance->TxDma);

	// Setup interrupt for Tx DMA completion
	HwIntr = HalGetDMAHwIntr(DeviceInstance->TxDma);

	DeviceInstance->SysIntr = InterruptConnect(Internal,0,HwIntr,0);

	if (DeviceInstance->SysIntr == SYSINTR_NOP) {
		RETAILMSG(1,(TEXT("SPI: Failed InterruptConnect\r\n")));
		goto ErrorReturn;
	}

	RETAILMSG(1,(TEXT("SPI: Mapped HwIntr %d to SysIntr %d\r\n"),HwIntr,DeviceInstance->SysIntr));

	DeviceInstance->hIsrEvent = CreateEvent(NULL,FALSE,FALSE,NULL);

	if (!InterruptInitialize(DeviceInstance->SysIntr,DeviceInstance->hIsrEvent,NULL,0)) {
		RETAILMSG(1,(TEXT("SPI: Failed InterruptInitialize\r\n")));
		goto ErrorReturn;
	}

	InterruptDone(DeviceInstance->SysIntr);

#ifdef TEST
    CreateThread( NULL, 0, (LPTHREAD_START_ROUTINE)TestThread, NULL, 0, NULL);
#endif

	RoutineSuccess = TRUE;

ErrorReturn:

    //
    // If the initialization failed, clean up and return a NULL to signal
    // failure.
    //

    if (RoutineSuccess == FALSE) {
        SPI_Deinit((ULONG)DeviceInstance);
        DeviceInstance = NULL;
    }

    DEBUGMSG((ZONE_INIT|ZONE_ERROR) && (DeviceInstance == NULL), (
             TEXT("SPI: SPI_Init failed.\r\n")));

    return (ULONG)DeviceInstance;
}


ULONG
SPI_Open(
    IN OUT ULONG DeviceContext,
    IN ULONG AccessCode,
    IN ULONG ShareMode
    )

/*++

Routine Description:

    This routine is called whenever a call to CreateFile is made and our
    device is specified.  Device.exe will fill in the device context parameter
    with the corresponding pointer to the device instance that was returned
    by SPI_Init.  With this information, SPI_Open is expected to allocate
    resources and return a handle that the caller can use for subsequent
    accesses.


Arguments:

    DeviceContext - Pointer to the device instance structure.

    AccessCode - Desired access type.  These flags are a straight pass through
        from the CreateFile call.

    ShareMode - Desired share mode.  These flags are a straight pass through
        from the CreateFile call.

Return Value:

    The open context handle for this instance if successful or 0 for failure.

--*/

{
    PDEVICE_INSTANCE DeviceInstance;
    DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;

    DEBUGMSG(ZONE_FUNC, (
             TEXT("SPI: SPI_Open(0x%x, 0x%x, 0x%x) entered.\r\n"),
             DeviceContext,
             AccessCode,
             ShareMode));

	DeviceInstance->SPIConfiguration = AccessCode;
	InitializeRegisters(DeviceInstance);


    DEBUGMSG(ZONE_FUNC, (
             TEXT("SPI: SPI_Open returning 0x%x.\r\n"),
             DeviceContext));

    return (ULONG)DeviceContext;
}


BOOL
SPI_Close(
    IN OUT ULONG DeviceContext
    )

/*++

Routine Description:

    Deallocates resources allocated by SPI_Open and while the handle was
    active.  The routine is called whenever CloseHandle is called on a handle
    that was returned by SPI_Open.

Arguments:

    OpenContext - Pointer to the open instance.  This is the value that was
        returned by SPI_Open.

Return Value:

    TRUE if successful, FALSE otherwise.

--*/

{
    PDEVICE_INSTANCE DeviceInstance;
    DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;

    DEBUGMSG(ZONE_FUNC, (
             TEXT("SPI: SPI_Close(0x%x) entered.\r\n"),
             DeviceInstance));

    DEBUGMSG(ZONE_FUNC, (TEXT("SPI: SPI_Close returning TRUE.\r\n")));

    return TRUE;
}


ULONG
SPI_Read(
    IN OUT ULONG DeviceContext,
    IN PUCHAR ReadBuffer,
    IN ULONG Count
    )

/*++

Routine Description:

    Does nothing here

Arguments:

    OpenContext - Pointer to the open instance.  This is the value that was
        returned by SPI_Open.

    ReadBuffer - Pointer to the buffer to receive the read data.

    Count - Number of bytes to be read (space available in ReadBuffer).

Return Value:

    If successful, the number of bytes read.  -1 in the case of failure.

--*/

{
    return 0;
}


ULONG
SPI_Write(
    IN OUT ULONG OpenContext,
    IN PUCHAR Source,
    IN ULONG Count
    )

/*++

Routine Description:

    Nothing to do

Arguments:

    OpenContext - Pointer to the open instance.  This is the value that was
        returned by SPI_Open.

    Source - Pointer to the source buffer.  This is the data to be written to
        the device.

    Count - Number of bytes to be written.

Return Value:

    If successful, the number of bytes written.  -1 in the case of failure.

--*/

{
    UNREFERENCED_PARAMETER(OpenContext);
    UNREFERENCED_PARAMETER(Source);
    UNREFERENCED_PARAMETER(Count);

    return 0;
}


ULONG
SPI_Seek(
    IN OUT ULONG OpenContext,
    IN LONG Amount,
    IN USHORT Type
    )

/*++

Routine Description:

    Performs a seek on the device.  It's called whenever SetFilePointer is
    called with a handle to our open instance.

    Note that this function is not supported in this implementation since it
    doesn't make sense for our imaginary device to perform a seek.

Arguments:

    OpenContext - Pointer to the open instance.  This is the value that was
        returned by SPI_Open.

    Amount - Amount to seek.  This is a pass through from the SetFilePointer
        call.

    Type - Type of seek.  This is a pass through from the SetFilePointer call.

Return Value:

    Returns the new data pointer if successful.  -1 is returned if an error
    occurs.

--*/

{
    UNREFERENCED_PARAMETER(OpenContext);
    UNREFERENCED_PARAMETER(Amount);
    UNREFERENCED_PARAMETER(Type);

    SetLastError(ERROR_CALL_NOT_IMPLEMENTED);

    return -1;
}


BOOL
SPI_IOControl(
    IN OUT ULONG DeviceContext,
    IN ULONG Code,
    IN PUCHAR InputBuffer,
    IN ULONG InputBufferLength,
    OUT PUCHAR OutputBuffer,
    IN ULONG OutputBufferLength,
    OUT PULONG ActualOutput
    )

/*++

Routine Description:

    This routine is called whenever DeviceIoControl (note the difference in
    capitalization for "IO" in DeviceIoControl and SPI_IOControl) is called
    with our open instance handle.

    The exported wrapper functions call these IOCONTROLS. Parameters
    In the calling process, Buffer is used as an input buffer to pass a
    pointer to Data.

        ULONG Buffer;
        ULONG Data;
        PULONG MappedPtr;

        MappedPtr = MapPtrToProcess(&Data,
                                    GetCurrentProcess());

        Buffer = (ULONG)MappedPtr;


Arguments:

    OpenContext - Pointer to the open instance.  This is the value that was
        returned by SPI_Open.

    Code - Device I/O control code.  This is a pass through from the
        DeviceIoControl call.

    InputBuffer - Pointer to the input buffer.  This is a pass through from
        the DeviceIoControl call (with the pointer correctly mapped by the
        device manager).

    InputBufferLength - Size of the input buffer in bytes.  This is a pass
        through from the DeviceIoControl call.

    OutputBuffer - Pointer to the output buffer.  This is a pass through from
        the DeviceIoControl call (with the pointer correctly mapped by the
        device manager).

    OutputBufferLength - Size of the output buffer in bytes.  This is a pass
        through from the DeviceIoControl call.

    ActualOutput - Pointer to a ULONG where the actual number of bytes
        returned via the OutputBuffer is to be written.  This is a pass through
        from the DeviceIoControl call (correctly mapped by the device manager).

Return Value:

    Returns the new data pointer if successful.  -1 is returned if an error
    occurs.

--*/

{
    PDEVICE_INSTANCE DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;
	BOOL Status = FALSE;

    DEBUGMSG(ZONE_IOCTL, (
             TEXT("SPI: SPI_IOControl(0x%x, 0x%x, 0x%x, %u, 0x%x,")
             TEXT(" %u, 0x%x) entered.\r\n"),
             DeviceContext,
             Code,
             InputBuffer,
             InputBufferLength,
             OutputBuffer,
             OutputBufferLength,
             ActualOutput
             ));

    switch  (Code) {
		case IOCTL_SPI_TRANSFER:
			Status = DoTransfer(DeviceInstance, InputBufferLength, (PULONG)InputBuffer, (PULONG)OutputBuffer);
			*ActualOutput=OutputBufferLength;
			break;

		default:
			SetLastError(ERROR_CALL_NOT_IMPLEMENTED);
			Status = FALSE;
			break;
    }

    if (!Status) {
		DEBUGMSG(ZONE_ERROR|ZONE_IOCTL, (
				 TEXT("SPI: SSO_IOControl returning FALSE.\r\n")));
	}
    return Status;
}


VOID
SPI_PowerDown(
    IN OUT ULONG DeviceContext
    )

/*++

Routine Description:

    Performs actions required to place the device into a powered down state
    before suspend is entered.  Usually device drivers will store state here
    so that the device may be restarted when the system resumes normal
    operation.  This routine is run when the system is in a non-preemptive
    state.  As a result, system calls are not permitted.  The means that
    debug prints are not allowed (makes debugging these routines particularly
    difficult).

Arguments:

    DeviceContext - Pointer to the device instance structure that was returned
        by SPI_Init.

Return Value:

    None.

--*/

{
    PDEVICE_INSTANCE DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;

	WRITE_REGISTER_ULONG((PULONG)&DeviceInstance->pSPI->psc.ctl, 0);
}


VOID
SPI_PowerUp(
    IN OUT ULONG DeviceContext
    )

/*++

Routine Description:

    Performs actions required to restore the device to its pre-powered down
    state.  In some cases, drivers may have to reset the entire device, and
    this can require some handling after the system is back up.  One trick
    to accomplish this is to call SetInterruptEvent here.  Although this
    routine is run when the system is in a non-preemptive state and system
    calls are generally not permitted, SetInterruptEvent is allowed.  By
    passing it the SYSINTR allocated in the IST, the kernel will set the
    corresponding event thereby allowing the IST to run.  In combination with
    some flags left by this routine, it is possible to perform all power up
    initialization for the device when the rest of the system is up (and
    system calls are allowed).

Arguments:

    DeviceContext - Pointer to the device instance structure that was returned
        by SPI_Init.

Return Value:

    None.

--*/

{
    PDEVICE_INSTANCE DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;

	InitializeRegisters(DeviceInstance);
}

//
// Exported user area functions
//


/*
    Description:
    ===========
      Write data to the specified SPI address


    Arguments
    =========
    handle - this is the handle return by the init function
    Address - address to read
	pData	- pointer to storage for read UCHAR
	Size    - number of bytes to write

    Return
    ======
    TRUE - success

*/
BOOL
SPI_DoTransfer( HANDLE Handle,
                ULONG  Size,
                PULONG pTxBuffer,
				PULONG pRxBuffer )
{
    ULONG Tmp;
    BOOL RetVal;

    RetVal = DeviceIoControl(
        Handle,
        IOCTL_SPI_TRANSFER,
        pTxBuffer,
        Size,
        pRxBuffer,
        Size,
        &Tmp,
        NULL);

    return RetVal;
}

HANDLE
SPI_Initialize(ULONG SPIConfiguration)
{
    HANDLE h;

	h = CreateFile(TEXT("SPI1:"),
				  SPIConfiguration,
				  0,
				  NULL,
				  CREATE_NEW,
				  FILE_ATTRIBUTE_NORMAL,
				  NULL);

    return h;
}

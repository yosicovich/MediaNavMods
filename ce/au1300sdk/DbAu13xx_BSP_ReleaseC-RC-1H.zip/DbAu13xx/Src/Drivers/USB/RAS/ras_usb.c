//******************************************************************************
//* Copyright (c) 2002  BSQUARE Corporation.  All rights reserved.
//* 
//* Module Name:
//* 
//*     ras_usb.c
//* 
//* Module Description:
//* 
//*     Builds a Remote Access Service (RAS) phonebook entry into the
//*      CE registry if default data has been defined.
//*     
//* Author:
//* 
//*     Thomas Satagaj      29-Jan-2002     Original
//* 
//* Revision History:
//* 
//* NOTES:
//*
//*     By adding this registry key to PLATFORM.REG, this routine (RAS_USB.EXE)
//*      will be called at system startup. 
//* 
//*      ; Create a default USB RAS entry at boot up.
//*      ;
//*      [HKEY_LOCAL_MACHINE\Init]
//*          "Launch80"="ras_usb.exe"
//*          "Depend80"=hex:14,00
//* 
//* 
//*      Notes:
//* 
//*       Launch80 will run this after touch-cal (if it's installed)
//*       Depend80 = 14 will run this after DEVICE.EXE.
//* 
//* 
//*     This routine will support the automatic creation of device connectoids
//*      in the CE registry.  Note that specific device configuration structures
//*      such as those that show up under the "DevConfig" variable in a
//*      Unimodem registry key are not created here.  This functionality is
//*      assumed to already have been defined.
//*     Altering this routine to seek and load specific device configuration
//*      parameters would be straightforward.
//* 
//******************************************************************************
#include <windows.h>
#include <ras.h>


//#undef  DEBUGMSG
//#define DEBUGMSG(cond, msg) RETAILMSG(cond,msg)

INT APIENTRY WinMain(HINSTANCE  hInstance,
                     HINSTANCE  hPrevInstance,
                     LPTSTR     lpCmdLine,
                     INT        nCmdShow) 
{
    #define     HKLM                        HKEY_LOCAL_MACHINE
    #define     HKCU                        HKEY_CURRENT_USER
    #define     KEY_CP_COMM                 TEXT("\\ControlPanel\\Comm")
    #define     KEY_RAS_INIT                TEXT("\\Comm\\Ras\\Init")
    #define     VAL_AUTOCNCT                TEXT("AutoCnct")
    #define     VAL_AUTOCNCTNAME            TEXT("Cnct")
    #define     VAL_dwfOptions              TEXT("dwfOptions")
    #define     VAL_dwCountryID             TEXT("dwCountryID")
    #define     VAL_dwCountryCode           TEXT("dwCountryCode")
    #define     VAL_szAreaCode              TEXT("szAreaCode")
    #define     VAL_szLocalPhoneNumber      TEXT("szLocalPhoneNumber")
    #define     VAL_dwAlternateOffset      TEXT("dwAlternateOffset")
    #define     VAL_ipaddr_a                TEXT("ipaddr_a")
    #define     VAL_ipaddr_b                TEXT("ipaddr_b")
    #define     VAL_ipaddr_c                TEXT("ipaddr_c")
    #define     VAL_ipaddr_d                TEXT("ipaddr_d")
    #define     VAL_ipaddrDns_a             TEXT("ipaddrDns_a")
    #define     VAL_ipaddrDns_b             TEXT("ipaddrDns_b")
    #define     VAL_ipaddrDns_c             TEXT("ipaddrDns_c")
    #define     VAL_ipaddrDns_d             TEXT("ipaddrDns_d")
    #define     VAL_ipaddrDnsAlt_a          TEXT("ipaddrDnsAlt_a")
    #define     VAL_ipaddrDnsAlt_b          TEXT("ipaddrDnsAlt_b")
    #define     VAL_ipaddrDnsAlt_c          TEXT("ipaddrDnsAlt_c")
    #define     VAL_ipaddrDnsAlt_d          TEXT("ipaddrDnsAlt_d")
    #define     VAL_ipaddrWins_a            TEXT("ipaddrWins_a")
    #define     VAL_ipaddrWins_b            TEXT("ipaddrWins_b")
    #define     VAL_ipaddrWins_c            TEXT("ipaddrWins_c")
    #define     VAL_ipaddrWins_d            TEXT("ipaddrWins_d")
    #define     VAL_ipaddrWinsAlt_a         TEXT("ipaddrWinsAlt_a")
    #define     VAL_ipaddrWinsAlt_b         TEXT("ipaddrWinsAlt_b")
    #define     VAL_ipaddrWinsAlt_c         TEXT("ipaddrWinsAlt_c")
    #define     VAL_ipaddrWinsAlt_d         TEXT("ipaddrWinsAlt_d")
    #define     VAL_dwFrameSize             TEXT("dwFrameSize")
    #define     VAL_dwfNetProtocols         TEXT("dwfNetProtocols")
    #define     VAL_dwFramingProtocol       TEXT("dwFramingProtocol")
    #define     VAL_szScript                TEXT("szScript")
    #define     VAL_szAutodialDll           TEXT("szAutodialDll")
    #define     VAL_szAutodialFunc          TEXT("szAutodialFunc")
    #define     VAL_szDeviceType            TEXT("szDeviceType")
    #define     VAL_szDeviceName            TEXT("szDeviceName")
    #define     VAL_szX25PadType            TEXT("szX25PadType")
    #define     VAL_szX25Address            TEXT("szX25Address")
    #define     VAL_szX25Facilities         TEXT("szX25Facilities")
    #define     VAL_szX25UserData           TEXT("szX25UserData")
    #define     VAL_dwChannels              TEXT("dwChannels")


    BOOL        bSetAutoCnct;               // Update AutoCnct keys flag
    DWORD       dwCurAutoCnct;              // Registry auto-connect key value
    DWORD       dwError;                    // Return code from the functions
    DWORD       dwKeyType;                  // Data type returnd from reg query
    DWORD       dwNewAutoCnct;              // Registry auto-connect key value
    DWORD       dwRasEntrySize;             // Size of the RASENTRY structure
    DWORD       dwNumEntries;               // Number of registry RAS entries.
    DWORD       dwTmp;                      // Temp used for RASENTRY members.
    DWORD       dwTmpSize;                  // Temp used for RASENTRY members.
    DWORD       i;                          // Loop variable.
    HKEY        hKey;
    RASENTRY    RasEntry;                   // RASENTRY structure
    TCHAR       szCurCnctName[100];         // Name for the auto connect key
    TCHAR       szNewCnctName[100];         // Name for the auto connect key
    TCHAR       szEntryKey[100];            // 'EntryX' string.
    TCHAR       szEntryName[10][100];       // Array of entry name user strings.
    TCHAR       szTmp[500];                 // Temp used for RASENTRY members.

    char        tmpString1[100] = "Entry ";
    char        tmpString2[100] = "\\Comm\\Ras\\Init\\RasEntry\\Entry ";

    //**************************************************************************
    //* These variables/structures would be used to support the initialization
    //*  of a device configuration for a specific connectoid.
    //* 
    //**************************************************************************

//  BYTE        DevConfigBuf[128];          // Buffer for device configuration
    DWORD       dwDevConfigSize = 0;        // Size of DevConfigBuf
//  LPVARSTRING lpDevConfig     = (LPVARSTRING)&DevConfigBuf;
//  PUCHAR      pDevConfig      = (LPVARSTRING)&DevConfigBuf;
    PUCHAR      pDevConfig      = NULL;


    //**************************************************************************
    //* 
    //* Look for registry keys of the following format:
    //* 
    //* [HKEY_LOCAL_MACHINE\Comm\Ras\Init]
    //*     "AutoCnct"=dword:1
    //*     "Cnct"="YourDefaultName"
    //*     "Entry1"="YourDefaultName"
    //*     "Entry2"="YourDefaultName2"
    //*     "Entry3"="YourDefaultName3"
    //*     "Entry4"="YourDefaultName4"
    //*     "Entry5"="YourDefaultName5"
    //*     "Entry6"="YourDefaultName6"
    //*     "Entry7"="YourDefaultName7"
    //*     "Entry8"="YourDefaultName8"
    //*     "Entry9"="YourDefaultName9"
    //* 
    //* 
    //* Notes:
    //* 
    //*  AutoCnct       = 0   Never override the current autoconnect setting.
    //*                 = 1   Always override the current autoconnect setting
    //*                        with our default entry.
    //*                 = 2   Override the current autoconnect setting if it
    //*                        is set to "`Desktop @ 19200`".  This will let us
    //*                        override the CE default setting but not trash it
    //*                        if the user has overwritten it.
    //*
    //*  Cnct                 The connection name is limited to a maximum of 20
    //*                        characters.
    //* 
    //*  Entry1               The name here corresponds to the RAS entry that
    //*                        will be defined in the next section.
    //*                       This entry is required.
    //*                       Note that if you enclose the entry name in Left
    //*                        apostrophe's, (0x60), then the connectoid will
    //*                        not be displayed in the 'Connections' window of
    //*                        the CE device.  This means that it can't be
    //*                        accidentally deleted or altered.
    //*                        Ex. "Entry1"="`Default USB Device`" is hidden.
    //*                            "Entry1"="Default USB Device" is viewable.
    //* 
    //*  EntryX               Subsequent entries can be put into the registry to
    //*                        create several RAS connectoids but are not
    //*                        required.
    //*                       Up to 9 entries are allowed.
    //*                       The first must be 'Entry1' and any subsequent 
    //*                        entries must be in sequential order.
    //* 
    //* ------------------------------------------------------------------------
    //* ------------------------------------------------------------------------
    //* ------------------------------------------------------------------------
    //* 
    //* Look for registry keys of the following format:
    //*  There must be one structure each "EntryN" key defined above.
    //* 
    //* [HKEY_LOCAL_MACHINE\Comm\Ras\Init\RasEntry\Entry1]
    //*     "dwfOptions"=hex:0
    //*     "dwCountryID"=dword:0
    //*     "dwCountryCode"=dword:0
    //*     "szAreaCode"=""
    //*     "szLocalPhoneNumber"=""
    //*     "dwAlternateOffset"=dword:0
    //*     "ipaddr_a"=""
    //*     "ipaddr_b"=""
    //*     "ipaddr_c"=""
    //*     "ipaddr_d"=""
    //*     "ipaddrDns_a"=""
    //*     "ipaddrDns_b"=""
    //*     "ipaddrDns_c"=""
    //*     "ipaddrDns_d"=""
    //*     "ipaddrDnsAlt_a"=""
    //*     "ipaddrDnsAlt_b"=""
    //*     "ipaddrDnsAlt_c"=""
    //*     "ipaddrDnsAlt_d"=""
    //*     "ipaddrWins_a"=""
    //*     "ipaddrWins_b"=""
    //*     "ipaddrWins_c"=""
    //*     "ipaddrWins_d"=""
    //*     "ipaddrWinsAlt_a"=""
    //*     "ipaddrWinsAlt_b"=""
    //*     "ipaddrWinsAlt_c"=""
    //*     "ipaddrWinsAlt_d"=""
    //*     "dwFrameSize"=dword:0
    //*     "dwfNetProtocols"=dword:0
    //*     "dwFramingProtocol"=dword:0
    //*     "szScript"=""
    //*     "szAutodialDll"=""
    //*     "szAutodialFunc"=""
    //*     "szDeviceType"=""
    //*     "szDeviceName"=""
    //*     "szX25PadType"=""
    //*     "szX25Address"=""
    //*     "szX25Facilities"=""
    //*     "szX25UserData"=""
    //*     "dwChannels"=dword:0
    //* 
    //* 
    //* Notes:
    //* 
    //*  dwfOptions         =   RASEO_xx flags are in ...\sdk\inc\RAS.H
    //*                         Ex. "dwfOptions"=hex:08,02 is
    //*                               RASEO_IpHeaderCompression |
    //*                               RASEO_SwCompression
    //*  dwCountryID        =
    //*  dwCountryCode      =   CTRY_xx codes are in ...\sdk\inc\WINNLS.H
    //*  szAreaCode         =   A null term unicode string.  Ex. "425"
    //*  szLocalPhoneNumber =   A null term unicode string.  Ex. "5867955"
    //*  dwAlternateOffset =
    //*  ipaddr_a           =   Each Ip address is entered as 4 separate
    //*                          values.
    //*                         Ex. To load     192.168.55.100
    //*                             Set  "ipaddr_a"=dword:64
    //*                                  "ipaddr_b"=dword:37
    //*                                  "ipaddr_c"=dword:A8
    //*                                  "ipaddr_d"=dword:C0
    //*  ipaddr_b           =
    //*  ipaddr_c           =
    //*  ipaddr_d           =
    //*  ipaddrDns_a        =
    //*  ipaddrDns_b        =
    //*  ipaddrDns_c        =
    //*  ipaddrDns_d        =
    //*  ipaddrDnsAlt_a     =
    //*  ipaddrDnsAlt_b     =
    //*  ipaddrDnsAlt_c     =
    //*  ipaddrDnsAlt_d     =
    //*  ipaddrWins_a       =
    //*  ipaddrWins_b       =
    //*  ipaddrWins_c       =
    //*  ipaddrWins_d       =
    //*  ipaddrWinsAlt_a    =
    //*  ipaddrWinsAlt_b    =
    //*  ipaddrWinsAlt_c    =
    //*  ipaddrWinsAlt_d    =
    //*  dwFrameSize        =
    //*  dwfNetProtocols    =   RASNP_xx flags are in ...\sdk\inc\RAS.H
    //*  dwFramingProtocol  =   RASFP_xx flags are in ...\sdk\inc\RAS.H
    //*  szScript           =
    //*  szAutodialDll      =
    //*  szAutodialFunc     =
    //*  szDeviceType       =   RASDT_xx strings are in ...\sdk\inc\RAS.H
    //*  szDeviceName       =   Matches a connections "FriendlyName" key.
    //*  szX25PadType       =
    //*  szX25Address       =
    //*  szX25Facilities    =
    //*  szX25UserData      =
    //*  dwChannels         =
    //* 
    //* 
    //**************************************************************************

    DEBUGMSG(1, (TEXT("RAS_USB: Build Default RAS entries.\r\n")));

    //**************************************************************************
    //* Open our custom initialization key.     [HKLM\Comm\Ras\Init]
    //* Retrieve the AutoCnct key.              "AutoCnct"
    //* Retrieve the AutoCnct name key.         "Cnct"
    //* 
    //**************************************************************************

    dwError     = RegOpenKeyEx(HKLM, KEY_RAS_INIT, 0, KEY_ALL_ACCESS, &hKey);
    if (dwError != ERROR_SUCCESS)                       goto RAS_USB_ERR_01;

    dwTmpSize   = sizeof(DWORD);
    dwError     = RegQueryValueEx(hKey, 
                                  VAL_AUTOCNCT,
                                  NULL,
                                  &dwKeyType,
                                  (PUCHAR)&dwNewAutoCnct,
                                  &dwTmpSize);
    if (dwError != ERROR_SUCCESS)                       goto RAS_USB_ERR_02;

    dwTmpSize   = sizeof(szNewCnctName);
    dwError     = RegQueryValueEx(hKey,
                                  VAL_AUTOCNCTNAME,
                                  NULL,
                                  &dwKeyType,
                                  (PUCHAR)szNewCnctName,
                                  &dwTmpSize);
    if (dwError != ERROR_SUCCESS)                       goto RAS_USB_ERR_03;

    //**************************************************************************
    //* Count how many RAS phonebook entries we will be creating.
    //*  Keep an array of the user defined entry names that will be used later
    //*  by   RasSetEntryProperties()   to create the individual connectoids.
    //* tmpString1[]  is predefined with a null terminated "Entry " string.
    //*  We just stick in an index. Ex We put the '1' to create  "Entry1"
    //* For each "EntryX" key found, store the connectoid name in the array.
    //* Close the custom initialization key.
    //* 
    //**************************************************************************

    for(i = 1; i < 10; i++)
    {
      tmpString1[5]     = '0' + (char)(i);
      wsprintf (szEntryKey, TEXT("%S"), tmpString1);
      dwTmpSize         = (sizeof(TCHAR) * (RAS_MaxEntryName + 1));
      dwError           = RegQueryValueEx(hKey,
                                          szEntryKey,
                                           NULL,
                                          &dwKeyType,
                                          (PUCHAR)&szEntryName[i][0],
                                          &dwTmpSize);
      if (dwError != ERROR_SUCCESS)                     break;
    } //for i=1 to 9
    dwNumEntries        = i - 1;
    RegCloseKey(hKey);


    //**************************************************************************
    //* Load   dwAutoCnct   with   [HKLM\Comm\Ras\Init\] "AutoCnct"=dword:N
    //* Based on the setting selectively update the kernel's AutoCnct key.
    //*  If dwAutoCnct = 0  Don't update.
    //*  If dwAutoCnct = 1  Always update.
    //*  If dwAutoCnct = 2  Update only if there is not a valid connectoid.
    //* 
    //* Open the existing current user key.
    //* Retrieve the current AutoCnct key.
    //* Retrieve the current AutoCnct name key.
    //* If our custom key is set to 1, always override the current AutoCnct key.
    //* If our custom key is set to 2,
    //*  Only override the current AutoCnct key if the current connectoid does
    //*  not already exist.
    //* In all other cases, don't override the current AutoCnct key or name.
    //* 
    //* Close the existing current user key.
    //* 
    //**************************************************************************

    dwError         = RegOpenKeyEx(HKCU, KEY_CP_COMM, 0, KEY_ALL_ACCESS, &hKey);
    if (dwError != ERROR_SUCCESS)                       goto RAS_USB_ERR_04;


    dwTmpSize       = sizeof(DWORD);
    dwError         = RegQueryValueEx(hKey, 
                                      VAL_AUTOCNCT,
                                      NULL,
                                      &dwKeyType,
                                      (PUCHAR)&dwCurAutoCnct,
                                      &dwTmpSize);
    if (dwError != ERROR_SUCCESS)                       goto RAS_USB_ERR_05;


    dwTmpSize       = sizeof(szCurCnctName);
    dwError         = RegQueryValueEx(hKey,
                                      VAL_AUTOCNCTNAME,
                                      NULL,
                                      &dwKeyType,
                                      (PUCHAR)szCurCnctName,
                                      &dwTmpSize);
    if (dwError != ERROR_SUCCESS)                       goto RAS_USB_ERR_06;


    bSetAutoCnct    = FALSE;
    if     (dwNewAutoCnct == 1)
    {
      bSetAutoCnct  = TRUE;
    }
    else if(dwNewAutoCnct == 2)
    {
      dwError       = RasValidateEntryName(NULL, szCurCnctName);
      if(dwError != ERROR_ALREADY_EXISTS)
      {
        bSetAutoCnct= TRUE;
      }
    } //dwnewautocnt = 2


    if(bSetAutoCnct)
    {
      dwNewAutoCnct = 1;
      dwError       = RegSetValueEx(hKey,
                                    VAL_AUTOCNCT,
                                    0,
                                    REG_DWORD,
                                    (PUCHAR)&dwNewAutoCnct,
                                    sizeof(DWORD));
      if (dwError != ERROR_SUCCESS)                     goto RAS_USB_ERR_07;

      dwError       = RegSetValueEx(hKey,
                                    VAL_AUTOCNCTNAME,
                                    0,
                                    REG_SZ,
                                    (PUCHAR)szNewCnctName,
                                    (sizeof(TCHAR)*(lstrlen(szNewCnctName)+1)));
      if (dwError != ERROR_SUCCESS)                     goto RAS_USB_ERR_08;
    }// bsetautocnct = true

    RegCloseKey(hKey);



    //**************************************************************************
    //* Loop through all   [HKLM\Comm\Ras\Init\RasEntry\EntryX]   entries.
    //* tmpString2[]  is predefined with a null terminated
    //*  "\\Comm\\Ras\\Init\\RasEntry\\Entry "   string.
    //*  We just stick in an index. Ex We put the '1' to create
    //*  "\\Comm\\Ras\\Init\\RasEntry\\Entry1"
    //* 
    //* Initialize a RasEntry structure.
    //* Open our custom initialization key. [HKLM\Comm\Ras\Init\RasEntry\EntryX]
    //* 
    //* One by one, retrieve all of the possible RasEntry keys.
    //*  For each successful key we read, update the RasEntry structure.
    //* 
    //**************************************************************************

    for(i = 1; i <= dwNumEntries; i++)
    {
      memset(&RasEntry, 0, sizeof(RasEntry));
      dwRasEntrySize    = sizeof(RasEntry);
      RasEntry.dwSize   = sizeof(RasEntry);
      tmpString2[29]    = '0' + (char)(i);
      wsprintf (szEntryKey, TEXT("%S"), tmpString2);

      dwError       = RegOpenKeyEx(HKLM, szEntryKey, 0, KEY_ALL_ACCESS, &hKey);
      if (dwError != ERROR_SUCCESS)                     goto RAS_USB_ERR_09;


      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_dwfOptions          , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.dwfOptions          = dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_dwCountryID         , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.dwCountryID         = dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_dwCountryCode       , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.dwCountryCode       = dwTmp;

      dwTmpSize     = sizeof(szTmp);
      dwError       = RegQueryValueEx(hKey, VAL_szAreaCode          , NULL, &dwKeyType, (PUCHAR)szTmp,  &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  memcpy(RasEntry.szAreaCode        , szTmp, dwTmpSize);

      dwTmpSize     = sizeof(szTmp);
      dwError       = RegQueryValueEx(hKey, VAL_szLocalPhoneNumber  , NULL, &dwKeyType, (PUCHAR)szTmp,  &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  memcpy(RasEntry.szLocalPhoneNumber, szTmp, dwTmpSize);

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_dwAlternateOffset  , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.dwAlternateOffset  = dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddr_a            , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddr.a            = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddr_b            , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddr.b            = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddr_c            , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddr.c            = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddr_d            , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddr.d            = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrDns_a         , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrDns.a         = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrDns_b         , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrDns.b         = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrDns_c         , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrDns.c         = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrDns_d         , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrDns.d         = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrDnsAlt_a      , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrDnsAlt.a      = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrDnsAlt_b      , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrDnsAlt.b      = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrDnsAlt_c      , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrDnsAlt.c      = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrDnsAlt_d      , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrDnsAlt.d      = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrWins_a        , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrWins.a        = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrWins_b        , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrWins.b        = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrWins_c        , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrWins.c        = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrWins_d        , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrWins.d        = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrWinsAlt_a     , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrWinsAlt.a     = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrWinsAlt_b     , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrWinsAlt.b     = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrWinsAlt_c     , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrWinsAlt.c     = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_ipaddrWinsAlt_d    , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.ipaddrWinsAlt.d     = (UCHAR)dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_dwFrameSize         , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.dwFrameSize         = dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_dwfNetProtocols     , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.dwfNetProtocols     = dwTmp;

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_dwFramingProtocol   , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.dwFramingProtocol   = dwTmp;

      dwTmpSize     = sizeof(szTmp);
      dwError       = RegQueryValueEx(hKey, VAL_szScript            , NULL, &dwKeyType, (PUCHAR)szTmp,  &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  memcpy(RasEntry.szScript         , szTmp, dwTmpSize);

      dwTmpSize     = sizeof(szTmp);
      dwError       = RegQueryValueEx(hKey, VAL_szAutodialDll       , NULL, &dwKeyType, (PUCHAR)szTmp,  &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  memcpy(RasEntry.szAutodialDll    , szTmp, dwTmpSize);

      dwTmpSize     = sizeof(szTmp);
      dwError       = RegQueryValueEx(hKey, VAL_szAutodialFunc      , NULL, &dwKeyType, (PUCHAR)szTmp,  &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  memcpy(RasEntry.szAutodialFunc   , szTmp, dwTmpSize);

      dwTmpSize     = sizeof(szTmp);
      dwError       = RegQueryValueEx(hKey, VAL_szDeviceType        , NULL, &dwKeyType, (PUCHAR)szTmp,  &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  memcpy(RasEntry.szDeviceType     , szTmp, dwTmpSize);

      dwTmpSize     = sizeof(szTmp);
      dwError       = RegQueryValueEx(hKey, VAL_szDeviceName        , NULL, &dwKeyType, (PUCHAR)szTmp,  &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  memcpy(RasEntry.szDeviceName     , szTmp, dwTmpSize);

      dwTmpSize     = sizeof(szTmp);
      dwError       = RegQueryValueEx(hKey, VAL_szX25PadType        , NULL, &dwKeyType, (PUCHAR)szTmp,  &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  memcpy(RasEntry.szX25PadType     , szTmp, dwTmpSize);

      dwTmpSize     = sizeof(szTmp);
      dwError       = RegQueryValueEx(hKey, VAL_szX25Address        , NULL, &dwKeyType, (PUCHAR)szTmp,  &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  memcpy(RasEntry.szX25Address     , szTmp, dwTmpSize);

      dwTmpSize     = sizeof(szTmp);
      dwError       = RegQueryValueEx(hKey, VAL_szX25Facilities     , NULL, &dwKeyType, (PUCHAR)szTmp,  &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  memcpy(RasEntry.szX25Facilities  , szTmp, dwTmpSize);

      dwTmpSize     = sizeof(szTmp);
      dwError       = RegQueryValueEx(hKey, VAL_szX25UserData       , NULL, &dwKeyType, (PUCHAR)szTmp,  &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  memcpy(RasEntry.szX25UserData    , szTmp, dwTmpSize);

      dwTmpSize     = sizeof(DWORD);
      dwError       = RegQueryValueEx(hKey, VAL_dwChannels          , NULL, &dwKeyType, (PUCHAR)&dwTmp, &dwTmpSize);
      if (dwError   == ERROR_SUCCESS)  RasEntry.dwChannels          = dwTmp;



    //**************************************************************************
    //* Create the RAS Entry.
    //*  Note that the device configuration buffer is dummied out.
    //* 
    //* Close this key, loop back around for the next entry.
    //* When we've completed all entries, jump to the end.
    //* 
    //**************************************************************************
      dwError       = RasSetEntryProperties(NULL, 
                                            &szEntryName[i][0], 
                                            &RasEntry,
                                            dwRasEntrySize, 
                                            pDevConfig, 
                                            dwDevConfigSize);
      if (dwError != ERROR_SUCCESS)                     goto RAS_USB_ERR_10;

      DEBUGMSG(1,
               (TEXT("RAS_USB : ")
                TEXT("Created RAS entry named: \"%s\".\r\n"), &szEntryName[i][0]));


      RegCloseKey(hKey);
    } // for i=1 to dwnumentries

    goto RAS_USB_ERR_NONE;




    //**************************************************************************
    //* Error messages
    //* 
    //**************************************************************************


RAS_USB_ERR_01:
    DEBUGMSG(1,
             (TEXT("RAS_USB: ")
              TEXT("Failed to open custom RAS init registry key, ")
              TEXT("errorcode = %d\r\n"), dwError));
    return FALSE;

RAS_USB_ERR_02:
    RegCloseKey(hKey);
    DEBUGMSG(1,
             (TEXT("RAS_USB: ")
              TEXT("Failed to retrieve AutoCnct registry key, ")
              TEXT("errorcode = %d\r\n"), dwError));
    return FALSE;

RAS_USB_ERR_03:
    RegCloseKey(hKey);
    DEBUGMSG(1,
             (TEXT("RAS_USB: ")
              TEXT("Failed to retrieve AutoCnct name registry key, ")
              TEXT("errorcode = %d\r\n"), dwError));
    return FALSE;

RAS_USB_ERR_04:
    DEBUGMSG(1,
             (TEXT("RAS_USB: ")
              TEXT("Failed to open control panel comm registry key, ")
              TEXT("errorcode = %d\r\n"), dwError));
    return FALSE;

RAS_USB_ERR_05:
    RegCloseKey(hKey);
    DEBUGMSG(1,
             (TEXT("RAS_USB: ")
              TEXT("Failed to retrieve AutoCnct registry key, ")
              TEXT("errorcode = %d\r\n"), dwError));
    return FALSE;

RAS_USB_ERR_06:
    RegCloseKey(hKey);
    DEBUGMSG(1,
             (TEXT("RAS_USB: ")
              TEXT("Failed to retrieve AutoCnct name registry key, ")
              TEXT("errorcode = %d\r\n"), dwError));
    return FALSE;

RAS_USB_ERR_07:
    RegCloseKey(hKey);
    DEBUGMSG(1,
             (TEXT("RAS_USB: ")
              TEXT("Failed to update AutoCnct registry key, ")
              TEXT("errorcode = %d\r\n"), dwError));
    return FALSE;

RAS_USB_ERR_08:
    RegCloseKey(hKey);
    DEBUGMSG(1,
             (TEXT("RAS_USB: ")
              TEXT("Failed to update AutoCnct name registry key, ")
              TEXT("errorcode = %d\r\n"), dwError));
    return FALSE;

RAS_USB_ERR_09:
    DEBUGMSG(1,
             (TEXT("RAS_USB: ")
              TEXT("Failed to open custom RAS init registry key,\r\n ")
              TEXT("%s, ")
              TEXT("errorcode = %d\r\n"), szEntryKey, dwError));
    return FALSE;

RAS_USB_ERR_10:
    RegCloseKey(hKey);
    DEBUGMSG(1,
             (TEXT("RAS_USB : ")
              TEXT("Unable to create %s RAS entry,")
              TEXT("errorcode = %d\r\n"), &szEntryName[i][0], dwError));
    return FALSE;


RAS_USB_ERR_NONE:
    DEBUGMSG(1, (TEXT("RAS_USB: Created %d RAS entries.\r\n"), dwNumEntries));
    return TRUE;
}



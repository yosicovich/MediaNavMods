//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:
    system.c

Abstract:
    Device dependent part of the USB Universal Host Controller Driver (EHCD).

Notes:
--*/
#include <windows.h>
#include <platform.h>
#include <nkintr.h>
#include <bceddk.h>
#include <platform.h>
#include <ddkreg.h>
#include <devload.h>
#include <giisr.h>
#include <hcdddsi.h>

//#undef DEBUGMSG
//#define DEBUGMSG(c,msg) RETAILMSG(1,msg)

// These come from the MDD. They are NOT exported by the def file;
// we just use the old functions in the new power management support.
extern void HCD_PowerUp(DWORD), HCD_PowerDown(DWORD);

#define ZONE_PDD 1


#define REG_PHYSICAL_PAGE_SIZE TEXT("PhysicalPageSize")
#define REG_USB_HOST_PORT TEXT("HostPort")
#define REG_USB_HOST_USE_2_PORTS TEXT("HostUses2Ports")
#define REG_USB_HOST_EHCD_REGISTRY_PATH TEXT("Drivers\\BuiltIn\\EHCD")

// Amount of memory to use for HCD buffer
#define gcTotalAvailablePhysicalMemory (0x20000) // 128K
#define gcHighPriorityPhysicalMemory (gcTotalAvailablePhysicalMemory/4)   // 1/4 as high priority


typedef struct _SEHCDPdd
{
    LPVOID 				lpvMemoryObject;
    LPVOID 				lpvEHCDMddObject;
    PVOID 				pvVirtualAddress;           // DMA buffers as seen by the CPU
    DWORD 				dwPhysicalMemSize;
    PHYSICAL_ADDRESS 	LogicalAddress;        		// DMA buffers as seen by the DMA controller and bus interfaces
    DMA_ADAPTER_OBJECT 	AdapterObject;
    TCHAR 				szDriverRegKey[MAX_PATH];
    PUCHAR 				ioPortBase;
    DWORD  				dwIoPortLength;
    DWORD 				dwSysIntr;
    CRITICAL_SECTION  	csPdd;                    	// serializes access to the PDD object
    HANDLE          	IsrHandle;
    HANDLE 				hParentBusHandle;
	DWORD				dwHostPort;					// TEO: port Host Controller enabled on.
	BOOL                bHostUses2Ports;            // TEO: TRUE:use both ports; FALSE:use only one port.
} SEHCDPdd;

#define UnusedParameter(x)  x = x

/* HcdPdd_DllMain
 *
 *  DLL Entry point.
 *
 * Return Value:
 */
extern BOOL HcdPdd_DllMain(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    UnusedParameter(hinstDLL);
    UnusedParameter(dwReason);
    UnusedParameter(lpvReserved);

    return TRUE;
}

static BOOL
GetRegistryPhysicalMemSize(
    LPCWSTR RegKeyPath,         // IN - driver registry key path
    DWORD * lpdwPhyscialMemSize)       // OUT - base address
{
    HKEY hKey;
    DWORD dwData;
    DWORD dwSize;
    DWORD dwType;
    BOOL  fRet=FALSE;
    DWORD dwRet;
    // Open key
    dwRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE,RegKeyPath,0,0,&hKey);
    if (dwRet != ERROR_SUCCESS) {
        DEBUGMSG(ZONE_ERROR,(TEXT("!EHCD:GetRegistryConfig RegOpenKeyEx(%s) failed %d\r\n"),
                             RegKeyPath, dwRet));
        return FALSE;
    }

    // Read base address, range from registry and determine IOSpace
    dwSize = sizeof(dwData);
    dwRet = RegQueryValueEx(hKey, REG_PHYSICAL_PAGE_SIZE, 0, &dwType, (PUCHAR)&dwData, &dwSize);
    if (dwRet == ERROR_SUCCESS) {
        if (lpdwPhyscialMemSize)
            *lpdwPhyscialMemSize = dwData;
        fRet=TRUE;
    }
    RegCloseKey(hKey);
    return fRet;
}

/* ConfigureEHCICard
 *
 */
BOOL
ConfigureEHCICard(
    SEHCDPdd * pPddObject, // IN - contains PDD reference pointer.
    PUCHAR *pioPortBase,   // IN - contains physical address of register base
                           // OUT- contains virtual address of register base
    DWORD dwAddrLen,
    DWORD dwIOSpace,
    INTERFACE_TYPE IfcType,
    DWORD dwBusNumber
    )
{
	ULONG               inIoSpace = dwIOSpace;
    ULONG               portBase;
    PHYSICAL_ADDRESS    ioPhysicalBase = {0, 0};
	AU13XX_USB * 		pUSB = (AU13XX_USB*)(USB_PHYS_ADDR|KSEG1_OFFSET);

	HKEY                hDevKey;
	DWORD               dwHostPort;
	DWORD               dwHostUses2Ports;
	DWORD               dwSize;


    portBase = (ULONG)*pioPortBase;
    ioPhysicalBase.LowPart = portBase;

    if (!BusTransBusAddrToVirtual(pPddObject->hParentBusHandle, IfcType, dwBusNumber, ioPhysicalBase, dwAddrLen, &inIoSpace, (PPVOID)pioPortBase)) {
        DEBUGMSG(ZONE_ERROR, (L"EHCD: Failed TransBusAddrToVirtual\r\n"));
        return FALSE;
    }

    DEBUGMSG(ZONE_INIT,
             (TEXT("EHCD: ioPhysicalBase 0x%X, IoSpace 0x%X\r\n"),
              ioPhysicalBase.LowPart, inIoSpace));
    DEBUGMSG(ZONE_INIT,
             (TEXT("EHCD: ioPortBase 0x%X, portBase 0x%X\r\n"),
              *pioPortBase, portBase));

	// TEO: Check registry for key indicating that host should be enabled
	// on port 0 (OTG port). This is the case if host and device
	// share the port, and autoswitching is enabled. Also check if host enabled
	// on both ports.
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,REG_USB_HOST_EHCD_REGISTRY_PATH,0,0,&hDevKey) != ERROR_SUCCESS)
	{
        // If we fail, just print a message, and continue without this check.
		RETAILMSG(1,(TEXT("InitializeEHCI:RegOpenKeyEx(%s) failed\r\n"),
                             pPddObject->szDriverRegKey));
    }
	else
	{
		dwSize = sizeof(dwHostUses2Ports);
		// look for key to determine if EHCI uses 1 port or both USB ports.
		if(RegQueryValueEx(hDevKey,
						REG_USB_HOST_USE_2_PORTS,
						NULL,
						NULL,
						(PUCHAR)&dwHostUses2Ports,
						&dwSize) == ERROR_SUCCESS)
		{
			if(dwHostUses2Ports == 1)
			{
				pPddObject->bHostUses2Ports = TRUE;
			}
		}
		else
		{
			// If we fail, just print a message, and continue without this check.
			RETAILMSG(1,(TEXT("ConfigureEHCICard:RegQueryValueEx(%s) failed for dwHostUses2Ports\r\n"),
								 REG_USB_HOST_USE_2_PORTS));
		}

		// If Host using only one port, check for registry subkey indicating
		// which port. If no subkey found, default is to use Usb Port 1, Host port.
		if(pPddObject->bHostUses2Ports == FALSE)
		{
		
			dwSize = sizeof(dwHostPort);

			// look for key to determine which port to enable host on.
			if(RegQueryValueEx(hDevKey,
							REG_USB_HOST_PORT,
							NULL,
							NULL,
							(PUCHAR)&dwHostPort,
							&dwSize) == ERROR_SUCCESS)
			{
				if(dwHostPort == 0)
				{
					pPddObject->dwHostPort = 0;
				}
			}
			else
			{
				// If we fail, just print a message, and continue without this check.
				RETAILMSG(1,(TEXT("ConfigureEHCICard:RegQueryValueEx(%s) failed for dwHostPort\r\n"),
									 REG_USB_HOST_PORT));
			}
		}

		if ( hDevKey!=NULL)
			RegCloseKey(hDevKey);
	}

	// If host enabled on both ports, enable power to both ports
	if(pPddObject->bHostUses2Ports) 
	{
#if defined(PLATFORM_USBHOST_POWER_ENABLE)
		PLATFORM_USBHOST_POWER_ENABLE;
#endif
#if defined(PLATFORM_USBOTG_POWER_ENABLE)
		PLATFORM_USBOTG_POWER_ENABLE;
#endif
	}
	else // Host using only one port, so enable power to that port.
	{
		// Enable power to the port.
		if(pPddObject->dwHostPort)
		{
#if defined(PLATFORM_USBHOST_POWER_ENABLE)
			PLATFORM_USBHOST_POWER_ENABLE;
#endif
		}
		else
		{
			// Disable power on port 1.
#if defined(PLATFORM_USBHOST_POWER_DISABLE)
			PLATFORM_USBHOST_POWER_DISABLE;
#endif
			// Enable power on port 0
#if defined(PLATFORM_USBOTG_POWER_ENABLE)
			PLATFORM_USBOTG_POWER_ENABLE;
#endif
		}
	} // else only one port

	// Check if host using USB port 0 (OTG port)
	if(pPddObject->bHostUses2Ports || (pPddObject->dwHostPort == 0))
	{
		// Give port ownership to the EHCI
		pUSB->dwc_ctrl4 |= USB_DWC_CTRL4_USB_MODE;
		Sleep(2);
		
		// Since we're in host mode, controller must drive VBUS
		// from internal source.
		pUSB->otg_status |= USB_OTG_STATUS_DRVVBUS;
	}

	// TEO: end code to check for host on port 0 (OTG port).

	/* Enable clocks to EHCI controller */
	pUSB->dwc_ctrl3 |= USB_DWC_CTRL3_EHC_CLKEN;

	/* Take host controller block out of reset */
	pUSB->dwc_ctrl1 |= USB_DWC_CTRL1_HSTRS;

	/* enable ALL USB phys */
	pUSB->dwc_ctrl2 |= USB_DWC_CTRL2_PHYRS | USB_DWC_CTRL2_PHY0RS | USB_DWC_CTRL2_PH1RS;

	/* enable ehci interrupt mask in USB block.
	 * **This is not the same as GPINTR mask for USB interrupt
	 */
	pUSB->intr_enable |= USB_INTR_EHCI;

    return TRUE;
}


/* InitializeEHCI
 *
 *  Configure and initialize EHCI card
 *
 * Return Value:
 *  Return TRUE if card could be located and configured, otherwise FALSE
 */
static BOOL
InitializeEHCI(
    SEHCDPdd * pPddObject,    // IN - Pointer to PDD structure
    LPCWSTR szDriverRegKey)   // IN - Pointer to active registry key string
{
    DWORD PhysAddr;
    PUCHAR ioPortBase = NULL;
    DWORD dwAddrLen;
    DWORD dwIOSpace;
    BOOL InstallIsr = FALSE;
    BOOL fResult = FALSE;
    LPVOID pobMem = NULL;
    LPVOID pobEHCD = NULL;
    DWORD dwHPPhysicalMemSize;
    HKEY    hKey;

    DDKWINDOWINFO dwi;
    DDKISRINFO dii;
   if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,szDriverRegKey,0,0,&hKey)!= ERROR_SUCCESS) {
        DEBUGMSG(ZONE_ERROR,(TEXT("InitializeEHCI:GetRegistryConfig RegOpenKeyEx(%s) failed\r\n"),
                             szDriverRegKey));
        return FALSE;
    }
    dwi.cbSize=sizeof(dwi);
    dii.cbSize=sizeof(dii);
    if ( DDKReg_GetWindowInfo(hKey, &dwi ) !=ERROR_SUCCESS || DDKReg_GetIsrInfo (hKey, &dii ) != ERROR_SUCCESS) {
        DEBUGMSG(ZONE_ERROR,(TEXT("InitializeEHCI:DDKReg_GetWindowInfo or  DDKReg_GetWindowInfo failed\r\n")));
        goto InitializeEHCI_Error;
    }

    if (dwi.dwNumMemWindows!=0) {
        PhysAddr = dwi.memWindows[0].dwBase;
        dwAddrLen= dwi.memWindows[0].dwLen;
        dwIOSpace = 0;
    }
    else if (dwi.dwNumIoWindows!=0) {
        PhysAddr= dwi.ioWindows[0].dwBase;
        dwAddrLen = dwi.ioWindows[0].dwLen;
        dwIOSpace = 1;
    }
    else
        goto InitializeEHCI_Error;

    DEBUGMSG(ZONE_INIT,(TEXT("EHCD: Read config from registry: Base Address: 0x%X, Length: 0x%X, ")
			TEXT("I/O Port: %s, SysIntr: 0x%X, Interface Type: %u, Bus Number: %u\r\n"),
                        PhysAddr, dwAddrLen, dwIOSpace ? L"YES" : L"NO",
			dii.dwSysintr,dwi.dwInterfaceType, dwi.dwBusNumber));

    ioPortBase = (PUCHAR)PhysAddr;

    {
	DEBUGMSG(ZONE_INIT, (L"EHCD: Connecting HWINTR_USB\r\n"));
	dii.dwSysintr = InterruptConnect(Internal, 0, HWINTR_USB, 0);
	if (!dii.dwSysintr) {
	    RETAILMSG(1, (L"EHCD: Could not connect interrupt.\r\n"));
	    return FALSE;
	}
    }

    DEBUGMSG(ZONE_INIT,(TEXT("EHCD: config: Base Address: 0x%X, Length: 0x%X, ")
			TEXT("I/O Port: %s, SysIntr: 0x%X, Interface Type: %u, Bus Number: %u\r\n"),
                        PhysAddr, dwAddrLen, dwIOSpace ? L"YES" : L"NO",
			dii.dwSysintr,dwi.dwInterfaceType, dwi.dwBusNumber));

    pPddObject->dwIoPortLength = dwAddrLen;

    if (!(fResult = ConfigureEHCICard(pPddObject, &ioPortBase, dwAddrLen, dwIOSpace, dwi.dwInterfaceType, dwi.dwBusNumber))) {
        goto InitializeEHCI_Error;
    }

    if (dii.szIsrDll[0] != 0 && dii.szIsrHandler[0]!=0 && dii.dwIrq<0xff && dii.dwIrq>0 ) {
        // Install ISR handler
        pPddObject->IsrHandle = LoadIntChainHandler(dii.szIsrDll, dii.szIsrHandler, (BYTE)dii.dwIrq);

        if (!pPddObject->IsrHandle) {
            DEBUGMSG(ZONE_ERROR, (L"EHCD: Couldn't install ISR handler\r\n"));
        } else {
            GIISR_INFO Info;
            PHYSICAL_ADDRESS PortAddress = {PhysAddr, 0};

            DEBUGMSG(ZONE_INIT, (L"EHCD: Installed ISR handler, Dll = '%s', Handler = '%s', Irq = %d\r\n",
                dii.szIsrDll, dii.szIsrHandler, dii.dwIrq));

            if (!BusTransBusAddrToStatic(pPddObject->hParentBusHandle,dwi.dwInterfaceType, dwi.dwBusNumber, PortAddress, dwAddrLen, &dwIOSpace, &(PVOID)PhysAddr)) {
                DEBUGMSG(ZONE_ERROR, (L"EHCD: Failed TransBusAddrToStatic\r\n"));
                return FALSE;
            }

            // Set up ISR handler
            // Port/Mask addresses are per the EHCI specification: PhysAddr (no longer phys since
            // it was translated to virt space just above here) points to HCCAPBASE, whose LSB
            // is an offset to the EHCI operational registers. +4 is USBSTS and +8 is USBINTR.
            Info.SysIntr = dii.dwSysintr;
            Info.CheckPort = TRUE;
            Info.PortIsIO = (dwIOSpace) ? TRUE : FALSE;
            Info.UseMaskReg = TRUE;
            Info.PortAddr = PhysAddr + (*ioPortBase & 0xff) + 0x4;
            Info.PortSize = sizeof(DWORD);
            Info.MaskAddr = PhysAddr + (*ioPortBase & 0xff) + 0x8;

            if (!KernelLibIoControl(pPddObject->IsrHandle, IOCTL_GIISR_INFO, &Info, sizeof(Info), NULL, 0, NULL)) {
                DEBUGMSG(ZONE_ERROR, (L"EHCD: KernelLibIoControl call failed.\r\n"));
            }
        }
    }

    // The PDD can supply a buffer of contiguous physical memory here, or can let the
    // MDD try to allocate the memory from system RAM.  We will use the HalAllocateCommonBuffer()
    // API to allocate the memory and bus controller physical addresses and pass this information
    // into the MDD.
    if (GetRegistryPhysicalMemSize(szDriverRegKey,&pPddObject->dwPhysicalMemSize)) {
        // A quarter for High priority Memory.
        dwHPPhysicalMemSize = pPddObject->dwPhysicalMemSize/4;
        // Align with page size.
        pPddObject->dwPhysicalMemSize = (pPddObject->dwPhysicalMemSize + PAGE_SIZE -1) & ~(PAGE_SIZE -1);
        dwHPPhysicalMemSize = ((dwHPPhysicalMemSize +  PAGE_SIZE -1) & ~(PAGE_SIZE -1));
    }
    else
        pPddObject->dwPhysicalMemSize=0;

    if (pPddObject->dwPhysicalMemSize<gcTotalAvailablePhysicalMemory) { // Setup Minimun requirement.
        pPddObject->dwPhysicalMemSize = gcTotalAvailablePhysicalMemory;
        dwHPPhysicalMemSize = gcHighPriorityPhysicalMemory;
    }

    pPddObject->AdapterObject.ObjectSize = sizeof(DMA_ADAPTER_OBJECT);
    pPddObject->AdapterObject.InterfaceType = dwi.dwInterfaceType;
    pPddObject->AdapterObject.BusNumber = dwi.dwBusNumber;
    if ((pPddObject->pvVirtualAddress = HalAllocateCommonBuffer(&pPddObject->AdapterObject, pPddObject->dwPhysicalMemSize, &pPddObject->LogicalAddress, FALSE)) == NULL) {
        goto InitializeEHCI_Error;
    }

    if (!(pobMem = HcdMdd_CreateMemoryObject(pPddObject->dwPhysicalMemSize, dwHPPhysicalMemSize, (PUCHAR) pPddObject->pvVirtualAddress, (PUCHAR) pPddObject->LogicalAddress.LowPart))) {
        goto InitializeEHCI_Error;
    }

    if (!(pobEHCD = HcdMdd_CreateHcdObject(pPddObject, pobMem, szDriverRegKey, ioPortBase, dii.dwSysintr))) {
        goto InitializeEHCI_Error;
    }

    pPddObject->lpvMemoryObject = pobMem;
    pPddObject->lpvEHCDMddObject = pobEHCD;
    _tcsncpy(pPddObject->szDriverRegKey, szDriverRegKey, MAX_PATH);
    pPddObject->ioPortBase = ioPortBase;
    pPddObject->dwSysIntr = dii.dwSysintr;

    if ( hKey!=NULL)  {
        DWORD dwCapability;
        DWORD dwType;
        DWORD dwLength = sizeof(DWORD);
        if (RegQueryValueEx(hKey, HCD_CAPABILITY_VALNAME, 0, &dwType, (PUCHAR)&dwCapability, &dwLength) == ERROR_SUCCESS)
            HcdMdd_SetCapability (pobEHCD,dwCapability);
        RegCloseKey(hKey);
    }

	return TRUE;

InitializeEHCI_Error:

    if (pPddObject->IsrHandle) {
        FreeIntChainHandler(pPddObject->IsrHandle);
        pPddObject->IsrHandle = NULL;
    }

    if (pobEHCD)
        HcdMdd_DestroyHcdObject(pobEHCD);
    if (pobMem)
        HcdMdd_DestroyMemoryObject(pobMem);
    if(pPddObject->pvVirtualAddress) {
        HalFreeCommonBuffer(&pPddObject->AdapterObject, pPddObject->dwPhysicalMemSize, pPddObject->LogicalAddress, pPddObject->pvVirtualAddress, FALSE);
    }

    if (pPddObject->ioPortBase) {
        MmUnmapIoSpace(pPddObject->ioPortBase,pPddObject->dwIoPortLength);
        pPddObject->ioPortBase = NULL;
    }

    pPddObject->lpvMemoryObject = NULL;
    pPddObject->lpvEHCDMddObject = NULL;
    pPddObject->pvVirtualAddress = NULL;
    if ( hKey!=NULL)
        RegCloseKey(hKey);

    {
        MEMORYSTATUS ms;
        ms.dwLength = sizeof(ms);

        GlobalMemoryStatus(&ms);

        RETAILMSG(1,(TEXT("EHCI: dwAvailPhys = %X dwAvailVirt = %X\r\n"),ms.dwAvailPhys,ms.dwAvailVirtual));
    }

    return FALSE;
}

/* HcdPdd_Init
 *
 *   PDD Entry point - called at system init to detect and configure EHCI card.
 *
 * Return Value:
 *   Return pointer to PDD specific data structure, or NULL if error.
 */
extern DWORD
HcdPdd_Init(
    DWORD dwContext)  // IN - Pointer to context value. For device.exe, this is a string
                      //      indicating our active registry key.
{

	SEHCDPdd *  pPddObject = malloc(sizeof(SEHCDPdd));
    BOOL        fRet = FALSE;
	AU13XX_USB * 	pUSB = (AU13XX_USB*)(USB_PHYS_ADDR|KSEG1_OFFSET);

	/* Power up analog blocks via SIDDQ bit */
	pUSB->dwc_ctrl5 &= ~USB_DWC_CTRL5_SIDDQ;

    if (pPddObject) {
        pPddObject->pvVirtualAddress = NULL;
        InitializeCriticalSection(&pPddObject->csPdd);
        pPddObject->IsrHandle = NULL;
        pPddObject->hParentBusHandle = CreateBusAccessHandle((LPCWSTR)g_dwContext);

		// TEO: Default Host port is 1, unless otherwise indicated in the registry.
		pPddObject->dwHostPort = 1;
		// TEO: Default is host uses only one port.
		pPddObject->bHostUses2Ports = FALSE;

        fRet = InitializeEHCI(pPddObject, (LPCWSTR)dwContext);

        if(!fRet)
        {

            if (pPddObject->hParentBusHandle)
                CloseBusAccessHandle(pPddObject->hParentBusHandle);

           DeleteCriticalSection(&pPddObject->csPdd);
          free(pPddObject);
            pPddObject = NULL;
        }
    }


    return (DWORD)pPddObject;
}

/* HcdPdd_CheckConfigPower
 *
 *    Check power required by specific device configuration and return whether it
 *    can be supported on this platform.  For CEPC, this is trivial, just limit to
 *    the 500mA requirement of USB.  For battery powered devices, this could be
 *    more sophisticated, taking into account current battery status or other info.
 *
 * Return Value:
 *    Return TRUE if configuration can be supported, FALSE if not.
 */
extern BOOL HcdPdd_CheckConfigPower(
    UCHAR bPort,         // IN - Port number
    DWORD dwCfgPower,    // IN - Power required by configuration
    DWORD dwTotalPower)  // IN - Total power currently in use on port
{
    return ((dwCfgPower + dwTotalPower) > 500) ? FALSE : TRUE;
}

extern void HcdPdd_PowerUp(DWORD hDeviceContext)
{
    SEHCDPdd * 		pPddObject = (SEHCDPdd *)hDeviceContext;
	AU13XX_USB * 	pUSB = (AU13XX_USB*)(USB_PHYS_ADDR|KSEG1_OFFSET);

#if defined(PLATFORM_USBHOST_POWER_ENABLE)
	PLATFORM_USBHOST_POWER_ENABLE;
#endif

	/* Enable clocks to EHCI controller */
	pUSB->dwc_ctrl3 |= USB_DWC_CTRL3_EHC_CLKEN;

	/* Take host controller block out of reset */
	pUSB->dwc_ctrl1 |= USB_DWC_CTRL1_HSTRS;

	/* enable ALL USB phys */
	pUSB->dwc_ctrl2 |= USB_DWC_CTRL2_PHYRS | USB_DWC_CTRL2_PHY0RS | USB_DWC_CTRL2_PH1RS;

	/* enable ehci interrupt mask in USB block.
	 * **This is not the same as GPINTR mask for USB interrupt
	 */
	pUSB->intr_enable |= USB_INTR_EHCI;

	/* Power up analog blocks via SIDDQ bit */
	pUSB->dwc_ctrl5 &= ~USB_DWC_CTRL5_SIDDQ;

    HcdMdd_PowerUp(pPddObject->lpvEHCDMddObject);

    return;
}

extern void HcdPdd_PowerDown(DWORD hDeviceContext)
{
    SEHCDPdd * 		pPddObject = (SEHCDPdd *)hDeviceContext;
	AU13XX_USB * 	pUSB = (AU13XX_USB*)(USB_PHYS_ADDR|KSEG1_OFFSET);
	CEDEVICE_POWER_STATE	pwrState=(CEDEVICE_POWER_STATE)0xFF;

	DEBUGMSG(1,(TEXT("+EHCI::HcdPdd_PowerDown\r\n")));
    HcdMdd_PowerDown(pPddObject->lpvEHCDMddObject);

	if ( ERROR_SUCCESS != GetDevicePower(L"UFN1:", POWER_NAME, &pwrState) )
		RETAILMSG(1,(TEXT("Error getting UFN1 power state.\r\n")));

	/*
	 *	If there are no USB devices connected to both HOST and DEVICE
	 *  we can disable the HIGH speed 480MHz PLL, disable clocks to
	 *  EHCI/OHCI/USBD controllers.
	 *
	 *  New data tells us we save more power by setting SIDDQ rather
	 *  than turning off blocks and PLL.
	 */
#if 0  // Turning off SIDDQ will cause a hang in OHCI power down
	if (pwrState != D0) {
		/* Power down analog blocks via SIDDQ bit */
		pUSB->dwc_ctrl5 |= USB_DWC_CTRL5_SIDDQ;
	}
#endif

	DEBUGMSG(1,(TEXT("-EHCI::HcdPdd_PowerDown\r\n")));

    return;
}


extern BOOL HcdPdd_Deinit(DWORD hDeviceContext)
{
    SEHCDPdd * pPddObject = (SEHCDPdd *)hDeviceContext;
	AU13XX_USB * pUSB = (AU13XX_USB*)(USB_PHYS_ADDR|KSEG1_OFFSET);

    if(pPddObject->lpvEHCDMddObject)
        HcdMdd_DestroyHcdObject(pPddObject->lpvEHCDMddObject);
    if(pPddObject->lpvMemoryObject)
        HcdMdd_DestroyMemoryObject(pPddObject->lpvMemoryObject);
    if(pPddObject->pvVirtualAddress)
        HalFreeCommonBuffer(&pPddObject->AdapterObject, pPddObject->dwPhysicalMemSize, pPddObject->LogicalAddress, pPddObject->pvVirtualAddress, FALSE);

    if (pPddObject->IsrHandle) {
        FreeIntChainHandler(pPddObject->IsrHandle);
        pPddObject->IsrHandle = NULL;
    }
    if (pPddObject->hParentBusHandle)
        CloseBusAccessHandle(pPddObject->hParentBusHandle);

    if (pPddObject->ioPortBase) {
        MmUnmapIoSpace(pPddObject->ioPortBase,pPddObject->dwIoPortLength);
        pPddObject->ioPortBase = NULL;
    }

    // Delete critical section resources
    DeleteCriticalSection(&pPddObject->csPdd);

	/* Disable ehci interrupt mask in USB block.
	 * This is not the same as GPINTR mask for USB interrupt
	 */
	pUSB->intr_enable &= ~USB_INTR_EHCI;

	/* Disable clocks to EHCI controller */
	pUSB->dwc_ctrl3 &= ~USB_DWC_CTRL3_EHC_CLKEN;

	// Free interrupt resources
	InterruptDisconnect(pPddObject->dwSysIntr);

	// TEO: If Phy interrupt is asserted, clear it.
	if(pUSB->intr_status & USB_INTR_PHY)
		pUSB->intr_status |= USB_INTR_PHY;

	// TEO: put the host controller into reset.
	pUSB->dwc_ctrl1 &= ~USB_DWC_CTRL1_HSTRS;
    Sleep(25);

	// TEO: Disable power to the port.
	if(pPddObject->bHostUses2Ports)
	{
#if defined(PLATFORM_USBHOST_POWER_DISABLE)
		PLATFORM_USBHOST_POWER_DISABLE;
#endif
#if defined(PLATFORM_USBOTG_POWER_DISABLE)
		PLATFORM_USBOTG_POWER_DISABLE;
#endif
	}
	else
	{
		if(pPddObject->dwHostPort)
		{
#if defined(PLATFORM_USBHOST_POWER_DISABLE)
			PLATFORM_USBHOST_POWER_DISABLE;
#endif
		}
		else
		{
#if defined(PLATFORM_USBOTG_POWER_DISABLE)
			PLATFORM_USBOTG_POWER_DISABLE;
#endif
		}
	}

    free(pPddObject);

    return TRUE;
}


extern DWORD HcdPdd_Open(DWORD hDeviceContext, DWORD AccessCode,
        DWORD ShareMode)
{
    UnusedParameter(hDeviceContext);
    UnusedParameter(AccessCode);
    UnusedParameter(ShareMode);

    return hDeviceContext; // we can be opened, but only once!
}


extern BOOL HcdPdd_Close(DWORD hOpenContext)
{
    UnusedParameter(hOpenContext);

    return TRUE;
}


extern DWORD HcdPdd_Read(DWORD hOpenContext, LPVOID pBuffer, DWORD Count)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(pBuffer);
    UnusedParameter(Count);

    return (DWORD)-1; // an error occured
}


extern DWORD HcdPdd_Write(DWORD hOpenContext, LPCVOID pSourceBytes,
        DWORD NumberOfBytes)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(pSourceBytes);
    UnusedParameter(NumberOfBytes);

    return (DWORD)-1;
}


extern DWORD HcdPdd_Seek(DWORD hOpenContext, LONG Amount, DWORD Type)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(Amount);
    UnusedParameter(Type);

    return (DWORD)-1;
}


extern BOOL HcdPdd_IOControl(DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn,
        DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
    DWORD dwRet = ERROR_INVALID_PARAMETER;

    UNREFERENCED_PARAMETER(hOpenContext);
    UNREFERENCED_PARAMETER(pBufIn);
    UNREFERENCED_PARAMETER(dwLenIn);

    DEBUGMSG(ZONE_PDD, (L"+eHcdPdd_IOControl() EHCD\r\n"));

    switch (dwCode) {
      case IOCTL_POWER_CAPABILITIES:
        if(pBufOut && sizeof(POWER_CAPABILITIES) <= dwLenOut)
        {
            POWER_CAPABILITIES* pCap = (POWER_CAPABILITIES*)(pBufOut);
            int i;
            memset(pBufOut, 0, sizeof(*pCap));  // zero the unused fields
            pCap->DeviceDx = DX_MASK(D0) | DX_MASK(D4);
            for (i=D0; i<=D4; ++i) {
                pCap->Power[i] = PwrDeviceUnspecified;
                pCap->Latency[i] = PwrDeviceUnspecified;
            }
            pCap->Latency[D4] = 40; // more or less.

            if (pdwActualOut) *pdwActualOut = sizeof(*pCap);
            dwRet = ERROR_SUCCESS;
        }
        break;

      case IOCTL_POWER_SET:
        if(pBufOut && sizeof(CEDEVICE_POWER_STATE) <= dwLenOut)
        {
            CEDEVICE_POWER_STATE *pLev = (CEDEVICE_POWER_STATE*)(pBufOut);
            DEBUGMSG(ZONE_PDD,(L"EHCD setting power state to D%d\r\n", *pLev));
            if (*pLev <= D2) {
                *pLev = D0;
            } else {
                *pLev = D4;
            }

            // Our open context == our device context. See HcdPdd_Open().
            if (*pLev == D0) HCD_PowerUp(hOpenContext);
            else HCD_PowerDown(hOpenContext);

            if (pdwActualOut) *pdwActualOut = sizeof(*pLev);
            dwRet = ERROR_SUCCESS;
        }
        break;
    }

    DEBUGMSG(ZONE_PDD, (L"-HcdPdd_IOControl() EHCD\r\n"));

    SetLastError(dwRet);
    return dwRet == ERROR_SUCCESS;
}


// Manage WinCE suspend/resume events

// This gets called by the MDD's IST when it detects a power resume.
// By default it has nothing to do.
extern void HcdPdd_InitiatePowerUp (DWORD hDeviceContext)
{
    return;
}

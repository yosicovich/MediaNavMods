// USBware.cpp : Defines the entry point for the DLL application.
//

#include <windows.h>

// TEO: Registry path and key to determine if stack should b
// be enabled by default.
#define REG_USB_DEVICE_STACK_ACTIVE TEXT("EnableStack")
#define REG_USB_DEVICE_REGISTRY_PATH TEXT("Drivers\\BuiltIn\\UWD")

extern "C" {
    int wince_usbware_entry(LPCTSTR context);
    void wince_usbware_exit(void);
    BOOL osk_close(DWORD hOpenContext);
    BOOL osk_ioctl(DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn,
        DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut);
    DWORD osk_read(DWORD hOpenContext, LPVOID pBuffer, DWORD Count);
    DWORD osk_write(DWORD hOpenContext, LPCVOID pBuffer, DWORD Count);
    DWORD osk_open(DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode);
}

BOOL APIENTRY DllMain(HANDLE hModule, DWORD dwReason, LPVOID lpReserved)
{
    NKDbgPrintfW(TEXT("USBware::DllMain: Started hModule 0x%08X, ")
        TEXT("dwReason %lu\r\n"), hModule, dwReason);

    switch (dwReason)
    {
    case DLL_PROCESS_ATTACH:
        NKDbgPrintfW(TEXT("USBware::DllMain: Attach called - ")
            TEXT("Current Process: 0x%08X, ID: 0x%08X\r\n"),
            GetCurrentProcess(), GetCurrentProcessId());

        DisableThreadLibraryCalls((HMODULE)hModule);

        break;

    case DLL_PROCESS_DETACH:
        NKDbgPrintfW(TEXT("USBware::DllMain: Detach called - ")
            TEXT("Current Process: 0x%08X, ID: 0x%08X\r\n"),
            GetCurrentProcess(), GetCurrentProcessId());

        break;

    default:
        break;
    }

    return TRUE;
}

DWORD UWD_Init(LPCTSTR pContext, DWORD dwBusContext)
{
	// TEO: Vars needed for checking registry info.
	HKEY hKey;
	DWORD dwDeviceActive;
	DWORD dwSize;
	
    NKDbgPrintfW(TEXT("USBware::UWD_Init: Starting pContext 0x%08X\r\n"),
        pContext);

	// TEO: check registry to determine if device stack should continue init,
	// or if host owns the port. If key can't be opened, just continue 
	// init without this check.
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, REG_USB_DEVICE_REGISTRY_PATH, 0, 0, &hKey) != ERROR_SUCCESS)
	{
        RETAILMSG(1,(TEXT("UWD_Init:RegOpenKeyEx(%s) failed\r\n"),
                             REG_USB_DEVICE_REGISTRY_PATH));
    }
	else
	{

		dwSize = sizeof(dwDeviceActive);

		// look for key to determine which port to enable host on.
		// If this key doesn't exist, just continue init as normal.
		if(RegQueryValueEx(hKey,
						REG_USB_DEVICE_STACK_ACTIVE,
						NULL,
						NULL,
						(PUCHAR)&dwDeviceActive,
						&dwSize) != ERROR_SUCCESS)
		{
			RETAILMSG(1,(TEXT("UWD_Init:RegQueryValueEx(%s) failed\r\n"),
								 REG_USB_DEVICE_STACK_ACTIVE));
		}
		else
		{
			// check if device stack should continue init, or if host 
			// owns the port.
			if(dwDeviceActive == 0)
			{
				RETAILMSG(1,(TEXT("UWD_Init:Registry Indicates that Device should NOT continue Init. Exiting.\r\n"),
								 REG_USB_DEVICE_STACK_ACTIVE));
				return 0;
			}
		}

		RegCloseKey(hKey);
	}
	// TEO: end added code.

    wince_usbware_entry(pContext);

	return (DWORD)pContext;
}

DWORD UWD_Deinit(DWORD hDeviceContext)
{
    NKDbgPrintfW(TEXT("USBware::UWD_Deinit: Started hDeviceContext 0x%08X\r\n"),
        hDeviceContext);
    wince_usbware_exit();
    return hDeviceContext;
}

DWORD UWD_Open(DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode)
{
    NKDbgPrintfW(TEXT("USBware::UWD_Open: Started\r\n"));

    return osk_open(hDeviceContext, AccessCode, ShareMode);
}

BOOL UWD_Close(DWORD hOpenContext)
{
    NKDbgPrintfW(TEXT("USBware::UWD_Close: Started\r\n"));

    return osk_close(hOpenContext);
}

DWORD UWD_Write(DWORD hOpenContext, LPCVOID pBuffer, DWORD Count)
{
    return osk_write(hOpenContext, pBuffer, Count);
}

DWORD UWD_Read(DWORD hOpenContext, LPVOID pBuffer, DWORD Count)
{
    return osk_read(hOpenContext, pBuffer, Count);
}

DWORD UWD_PowerUp(DWORD hDeviceContext)
{
    NKDbgPrintfW(TEXT("USBware::UWD_PowerUp: Started hDeviceContext 0x%08X\r\n"),
        hDeviceContext);

    return hDeviceContext;
}

DWORD UWD_PowerDown(DWORD hDeviceContext)
{
    NKDbgPrintfW(TEXT("USBware::UWD_PowerDown: Started hDeviceContext 0x%08X\r\n"),
        hDeviceContext);

    return hDeviceContext;
}

BOOL UWD_IOControl(DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn,
    DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
    return osk_ioctl(hOpenContext, dwCode, pBufIn, dwLenIn, pBufOut,
        dwLenOut, pdwActualOut);
}

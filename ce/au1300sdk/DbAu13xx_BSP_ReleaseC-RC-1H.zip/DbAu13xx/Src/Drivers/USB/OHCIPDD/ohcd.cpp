/*++

Copyright (c) 1998, 2002-2005 BSQUARE Corporation. All rights reserved.

Module Name:

    ohcd.c

Abstract:

    This file implements the OHCD PDD using the BSQUARE Platform Layer.

Author:

    Chao Chen


--*/

#include <windows.h>
#include <platform.h>
#include <bldver.h>

	// include the chw.hpp header from the common tree
	// so we can call some of the HCD object member functions on suspend/resume
	// _LINKLIST_H_ is defined to avoid conflicting definitions with
	// the linklist stuff defined by the common HCD header...
#define _LINKLIST_H_
#define _lss_H_

#include "bceddk.h"
#include <ddkreg.h>
#include <giisr.h>

#include <uhcdddsi.h>
#include <chw.hpp>

#include "platform.h"

extern "C" void HCD_PowerUp(DWORD), HCD_PowerDown(DWORD);

#define ZONE_PDD 1

//
// Amount of memory to use for OHCD buffer.
//
#define BUFFER_SIZE     (128 * 1024)
#define PRIORITY_SIZE   (16 * 1024)
#define OHCD_PORT_RANGE 0x70

#define SLEEPMODE_SLEEP		0
#define SLEEPMODE_IDLE1		1

// TEO: Registry keys used to enable/disable the OHCI controllers.
#define REG_USB_HOST_OHCD_OHCI0_ENABLE TEXT("OHCI0Enable")
#define REG_USB_HOST_OHCD_OHCI1_ENABLE TEXT("OHCI1Enable")
#define REG_USB_HOST_OHCD_OHCI0_KEY TEXT("Drivers\\BuiltIn\\OHCD\\CONTROLLER0")
#define REG_USB_HOST_OHCD_OHCI1_KEY TEXT("Drivers\\BuiltIn\\OHCD\\CONTROLLER1")
#define REG_USB_HOST_OHCD_MEMBASE TEXT("MemBase")

//
// OHCD device object.
//
typedef struct _SOhcdPdd {

    LPVOID lpvMemoryObject;
    LPVOID lpvOhcdMddObject;

    ULONG  BufferSize;
    LPVOID VBuffer;
    PHYSICAL_ADDRESS PBuffer;

    ULONG SysIntr;
    HANDLE IsrHandle;

    HANDLE hParentBusHandle;

    CRITICAL_SECTION csPdd;

    LPCWSTR szDriverRegKey;

	ULONG	SleepMode;		// Mode is read from registry - if using IDLE1 sleep then do not shutdown USB!

	// TEO: previously these were static vars, but to support both OHCI controllers,
	// need to pull thse into this object, so that they are specific to each controller.
	PULONG UsbHostEnable;
	PULONG pulHcControl;
	PUCHAR PortBase;
} SOhcdPdd;

typedef struct _OHCDPddInstanceType
{
	DWORD      dwEnableOHCI0;
	SOhcdPdd * pOHCIController0;
	DWORD      dwEnableOHCI1;
	SOhcdPdd * pOHCIController1;
} OHCDPddInstanceType;

//
// Bit assignments in the HcControl register:
//
static const unsigned __int32 HcControlCBSRmask      = 0x00000003;
static const unsigned __int32 HcControlCBSR1to1      = 0x00000000;
static const unsigned __int32 HcControlCBSR2to1      = 0x00000001;
static const unsigned __int32 HcControlCBSR3to1      = 0x00000002;
static const unsigned __int32 HcControlCBSR4to1      = 0x00000003;

static const unsigned __int32 HcControlPLEmask       = 0x00000004;
static const unsigned __int32 HcControlIEmask        = 0x00000008;
static const unsigned __int32 HcControlCLEmask       = 0x00000010;
static const unsigned __int32 HcControlBLEmask       = 0x00000020;

static const unsigned __int32 HcControlHCFSmask      = 0x000000C0;
static const unsigned __int32 HcControlFSReset       = 0x00000000;
static const unsigned __int32 HcControlFSResume      = 0x00000040;
static const unsigned __int32 HcControlFSOperational = 0x00000080;
static const unsigned __int32 HcControlFSSuspend     = 0x000000C0;

static const unsigned __int32 HcControlIRmask        = 0x00000100;
static const unsigned __int32 HcControlRWCmask       = 0x00000200;
static const unsigned __int32 HcControlRWEmask       = 0x00000400;
static const unsigned __int32 HcControlReservedmask  = 0xFFFFF800;

extern BOOL g_fPowerResuming;
extern BOOL g_fPowerUpFlag;

//
// Functions.
//

extern "C" {

BOOL
HcdPdd_DllMain(
    HANDLE hinstDLL,
    DWORD dwReason,
    LPVOID lpvReserved
    )

/*++

Routine Description:

    DLL entry point.

Arguments:

    hinstDLL - Handle to the DLL instance.

    dwReason - Reason the DLL was invoked.

    lpvReserved - Not used.

Return Value:

    TRUE if successful, FALSE otherwise.

--*/

{
    UNREFERENCED_PARAMETER(hinstDLL);
    UNREFERENCED_PARAMETER(dwReason);
    UNREFERENCED_PARAMETER(lpvReserved);
	return TRUE;
}


static ULONG
GetSleepMode(
	LPCWSTR RegKey
	)
{
	LONG RegRet;
	ULONG Value;
	ULONG BytesReturned;
	ULONG SleepMode = SLEEPMODE_SLEEP;
	HKEY ActiveKey;


    RegRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                          RegKey,
                          0,
                          0,
                          &ActiveKey);

    if (RegRet != ERROR_SUCCESS) {

        DEBUGMSG(ZONE_ERROR|ZONE_INIT, (
                 TEXT("OHCD: Assuming deep sleep\r\n")
                 ));

        goto ErrorReturn;

    }

    // Read the key
    RegRet = RegQueryValueEx(ActiveKey,
                             TEXT("SleepMode"),
                             0,
                             NULL,
                             (PUCHAR)&Value,
                             &BytesReturned);

    if (RegRet != ERROR_SUCCESS) {

        DEBUGMSG(ZONE_ERROR|ZONE_INIT, (
                 TEXT("GPIO: Failed to query registry key path.\r\n")));
        goto ErrorReturn;

    }

	// Verify mode
	if (SLEEPMODE_IDLE1 == Value) {
		SleepMode = SLEEPMODE_IDLE1;
        DEBUGMSG(ZONE_INIT, (
                 TEXT("OHCD: IDLE1 sleep mode set\r\n")
                 ));
	}

ErrorReturn:

    if (ActiveKey) {
        RegCloseKey(ActiveKey);
    }

	return SleepMode;
}

static ULONG
GetPhysicalBaseAddress(
	LPCWSTR RegKey
	)
{
	LONG RegRet;
	ULONG Value;
	ULONG BytesReturned;
	ULONG Type = REG_DWORD;
	ULONG PhysBase = 0;
	HKEY ActiveKey;

    RegRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                          RegKey,
                          0,
                          0,
                          &ActiveKey);

    if (RegRet != ERROR_SUCCESS) {

        RETAILMSG(ZONE_PDD, (L"InitializeOHCI(): Error opening key I/O ports.\r\n"));
        DEBUGMSG(ZONE_ERROR|ZONE_INIT, (
                 TEXT("OHCD: could not open registry key\r\n")
                 ));

        goto ErrorReturn;

    }

    // Read the key
    RegRet = RegQueryValueEx(ActiveKey,
                             REG_USB_HOST_OHCD_MEMBASE,
                             0,
                             &Type,
                             (PUCHAR)&Value,
                             &BytesReturned);

    if (RegRet != ERROR_SUCCESS) {

         RETAILMSG(ZONE_PDD, (L"InitializeOHCI(): Error querrying value I/O ports.\r\n"));
       DEBUGMSG(ZONE_ERROR|ZONE_INIT, (
                 TEXT("GPIO: Failed to query registry key path.\r\n")));
        goto ErrorReturn;

    }
	
	PhysBase = Value;

ErrorReturn:

    if (ActiveKey) {
        RegCloseKey(ActiveKey);
    }

	return PhysBase;
}


// Check if there's a variable to indicate whether or not to enable
// each OHCI controller.  if we found and opened the key, and 
// successfuly quierried the registry value, return 1. If
// key could not be found/opened or the registry value was not 
// successfully querried, return 0.
static ULONG
IsOHCIControllerEnabled(
	LPCWSTR RegKey,
	LPCWSTR lpValueName,
	DWORD * dwValue
	)
{
	LONG RegRet;
	ULONG Value;
	ULONG BytesReturned;
	ULONG RetValue = 0;
	HKEY ActiveKey;


    RegRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                          RegKey,
                          0,
                          0,
                          &ActiveKey);

    if (RegRet != ERROR_SUCCESS) {

        DEBUGMSG(ZONE_ERROR|ZONE_INIT, (
                 TEXT("OHCD: Could not open key\r\n")
                 ));

        goto ErrorReturn;

    }

    // Read the key
    RegRet = RegQueryValueEx(ActiveKey,
                             lpValueName,
                             0,
                             NULL,
                             (PUCHAR)&Value,
                             &BytesReturned);

    if (RegRet != ERROR_SUCCESS) {

        DEBUGMSG(ZONE_ERROR|ZONE_INIT, (
                 TEXT("GPIO: Failed to query registry key path.\r\n")));
        goto ErrorReturn;

    }

	*dwValue = Value;
	RetValue = 1;

ErrorReturn:

    if (ActiveKey) {
        RegCloseKey(ActiveKey);
    }

	return RetValue;
}

VOID InitializeAu13XXOHCI( VOID )
{

	AU13XX_USB * 	 pUSB = (AU13XX_USB*)(USB_PHYS_ADDR|KSEG1_OFFSET);
		
	// TEO: Since we might be switching from Device mode, we are not guaranteed 
	// to be in reset, so reset the host controller
	pUSB->dwc_ctrl1 &= ~USB_DWC_CTRL1_HSTRS;
    Sleep(25);
	
	/*
	 * Initialize the OHCI portion of the USB block
	 */
#if defined(PLATFORM_USBHOST_POWER_ENABLE)
	PLATFORM_USBHOST_POWER_ENABLE;
#endif

	/* Enable clocks to OHCI controllers */
	pUSB->dwc_ctrl3 |= USB_DWC_CTRL3_OHC1_CLKEN | USB_DWC_CTRL3_OHC0_CLKEN;
	pUSB->dwc_ctrl7 = USB_DWC_CTRL7_OHC_STARTCLK;

	/* Take host controller block out of reset */
	pUSB->dwc_ctrl1 |= USB_DWC_CTRL1_HSTRS;

	/* enable ALL USB phys */
	pUSB->dwc_ctrl2 |= USB_DWC_CTRL2_PHYRS | USB_DWC_CTRL2_PHY0RS | USB_DWC_CTRL2_PH1RS;

	/* enable ohci interrupts mask in USB block.
	 * **This is not the same as GPINTR mask for USB interrupt
	 */
	pUSB->intr_enable |= USB_INTR_OHCI1 | USB_INTR_OHCI0;

}

BOOL
InitializeOHCI(
    SOhcdPdd *pPddObject
    )

/*++

Routine Description:

     Find, initialize, and configure OHCD device.

Arguments:

    pPddObject - Pointer to PDD structure.

    szDriverRegKey - Pointer to active registry key string.

Return Value:

    TRUE if successful, FALSE otherwise.

--*/

{
    PHYSICAL_ADDRESS PhysicalBase;
    PHYSICAL_ADDRESS MaxPhysical;
    LPVOID           pobMem;
    LPVOID           pobOhcd;

    DEBUGMSG(ZONE_PDD, (L"+InitializeOHCI()\r\n"));

	//
    // Map the OHCI Registers
    //
    PhysicalBase.HighPart = 0;
	
	// TEO: instead of using a hard coded physical base address, get the
	// physical base from the registry. this allows init of boht
	// OHCI controllers.


	if((PhysicalBase.LowPart =
		GetPhysicalBaseAddress(pPddObject->szDriverRegKey)) == NULL)
	{
		RETAILMSG(ZONE_PDD, (L"InitializeOHCI(): ERROR retrieving Physical Base Address from registry.\r\n"));
        return FALSE;
	}
	
	pPddObject->PortBase = (PUCHAR)MmMapIoSpace(PhysicalBase, OHCD_PORT_RANGE, FALSE);

    if (pPddObject->PortBase == NULL) {
        RETAILMSG(ZONE_PDD, (L"InitializeOHCI(): Error mapping I/O ports.\r\n"));
        return FALSE;
    }

    // get the location of HcControl register
    pPddObject->pulHcControl = (PULONG)&pPddObject->PortBase[OHC_HcControl];

    //
    // Connect the interrupt.
    //
    pPddObject->SysIntr = InterruptConnect(Internal, 0, HWINTR_USB, 0);

    if (!pPddObject->SysIntr) {
        RETAILMSG(ZONE_PDD, (L"InitializeOHCI(): Could not connect interrupt.\r\n"));
        return FALSE;
    }

    // The interrupt is shared with the other USB components

    // Fill in a dii to avoid excessive change to the rest of this block
    DDKISRINFO dii = { sizeof(DDKISRINFO), HWINTR_USB, pPddObject->SysIntr,
                       L"giisr.dll", L"ISRHandler" };
    pPddObject->IsrHandle = LoadIntChainHandler(dii.szIsrDll, dii.szIsrHandler, (BYTE)dii.dwIrq);

    if (!pPddObject->IsrHandle) {
        DEBUGMSG(ZONE_ERROR, (L"OHCD: Couldn't install ISR handler\r\n"));
    } else {
        DEBUGMSG(ZONE_INIT, (L"OHCD: Installed ISR handler, Dll = '%s', Handler = '%s', Irq = %d\r\n",
                             dii.szIsrDll, dii.szIsrHandler, dii.dwIrq));

        DWORD dwIOSpace = FALSE;
        PUCHAR kmemPortBase;
        if (!BusTransBusAddrToStatic(pPddObject->hParentBusHandle, Internal, 0, PhysicalBase, OHCD_PORT_RANGE, &dwIOSpace, (PPVOID)&kmemPortBase)) {
            DEBUGMSG(ZONE_ERROR, (L"EHCD: Failed TransBusAddrToStatic\r\n"));
            return FALSE;
        }

        GIISR_INFO Info;
        Info.SysIntr = dii.dwSysintr;
        Info.CheckPort = TRUE;
        Info.PortIsIO = FALSE;
        Info.UseMaskReg = TRUE;
        Info.PortAddr = (DWORD) &kmemPortBase[OHC_HcInterruptStatus];
        Info.PortSize = sizeof(DWORD);
        Info.MaskAddr = (DWORD) &kmemPortBase[OHC_HcInterruptEnable];

        if (!KernelLibIoControl(pPddObject->IsrHandle, IOCTL_GIISR_INFO, &Info, sizeof(Info), NULL, 0, NULL)) {
            DEBUGMSG(ZONE_ERROR, (L"EHCD: KernelLibIoControl call failed.\r\n"));
        }
    }

    pPddObject->BufferSize = BUFFER_SIZE;

    //
    // Allocate a common buffer for data transfers.
    //
    MaxPhysical.QuadPart = 0xFFFFFFFF;

    pPddObject->VBuffer = AllocPhysMem(pPddObject->BufferSize,
                                       PAGE_NOCACHE|PAGE_READWRITE,
                                       4096,
                                       0,
                                       &pPddObject->PBuffer.LowPart );

    if (pPddObject->VBuffer == NULL) {
        RETAILMSG(ZONE_PDD, (L"InitializeOHCI(): Could not allocate common buffer.\r\n"));
        return FALSE;
    }

    //
    // Create the MDD data objects.
    //
    pobMem = HcdMdd_CreateMemoryObject(BUFFER_SIZE,
                                       PRIORITY_SIZE,
                                       (PUCHAR)pPddObject->VBuffer,
                                       (PUCHAR)pPddObject->PBuffer.LowPart
                                      );

    if (pobMem == NULL) {
        RETAILMSG(ZONE_PDD, (L"InitializeOHCI(): Failed to create memory object.\r\n"));
        return FALSE;
    }

    pobOhcd = HcdMdd_CreateHcdObject(pPddObject,
                                     pobMem,
                                     pPddObject->szDriverRegKey,
                                     pPddObject->PortBase,
                                     pPddObject->SysIntr);

    if (pobOhcd == NULL) {
        RETAILMSG(ZONE_PDD, (L"InitializeOHCI(): Failed to create HCD object.\r\n"));
        HcdMdd_DestroyMemoryObject(pobMem);
        return FALSE;
    }

    pPddObject->lpvMemoryObject = pobMem;
    pPddObject->lpvOhcdMddObject = pobOhcd;


	pPddObject->SleepMode = GetSleepMode(pPddObject->szDriverRegKey);
    InterruptDone(pPddObject->SysIntr);

    DEBUGMSG(ZONE_PDD, (L"-InitializeOHCI()\r\n"));

    return TRUE;
}

DWORD
InitializeController(DWORD dwContext)

/*++

Routine Description:

    OHCD PDD device detection, initialization, and configuration.

Arguments:

    dwContext - Pointer to a string context value.

Return Value:

    Returns pointer to PDD specific data structure or NULL if error.

--*/

{
	SOhcdPdd *pPddObject;

	//
	// Allocate and initialize the OHCD object.
	//
	pPddObject = (SOhcdPdd*)malloc(sizeof *pPddObject);

	if (pPddObject) {

		//
		// Clear the allocated object.
		//
		memset(pPddObject, 0, sizeof *pPddObject);

		pPddObject->szDriverRegKey = (LPCWSTR)dwContext;

		pPddObject->IsrHandle = NULL;
		pPddObject->hParentBusHandle = CreateBusAccessHandle((LPCWSTR)g_dwContext);

		//
		// Find, initialize, and configure the OHCD.
		//
		if (InitializeOHCI(pPddObject) == 0) {
			if (pPddObject->hParentBusHandle)
				CloseBusAccessHandle(pPddObject->hParentBusHandle);
			free(pPddObject);
			pPddObject = NULL;
		}
	}

	return (DWORD)pPddObject;
}

DWORD
HcdPdd_Init(
    DWORD dwContext
    )

/*++

Routine Description:

    OHCD PDD device detection, initialization, and configuration.

Arguments:

    dwContext - Pointer to a string context value.

Return Value:

    Returns pointer to PDD specific data structure or NULL if error.

--*/

{
	OHCDPddInstanceType * pInstance;
	DWORD dwReturn = 0;
	AU13XX_USB * 	 pUSB = (AU13XX_USB*)(USB_PHYS_ADDR|KSEG1_OFFSET);
	DWORD dwValue;

    DEBUGMSG(ZONE_PDD, (L"+HcdPdd_Init()\r\n"));

	pInstance = (OHCDPddInstanceType*)malloc(sizeof *pInstance);

	if(pInstance)
	{
		// Initialize some values for this OHCD driver instance.
		pInstance->dwEnableOHCI0 = 0;  // by default disable OHCI controller 0 
		pInstance->dwEnableOHCI1 = 1;  // by default enable OHCI controller 1
		pInstance->pOHCIController0 = NULL;
		pInstance->pOHCIController1 = NULL;

		/* Power up analog blocks via SIDDQ bit */
		pUSB->dwc_ctrl5 &= ~USB_DWC_CTRL5_SIDDQ;

 		// TEO: pulled this function call out of InitializeOHCI so that it 
		// won't potentially be called twice.
		InitializeAu13XXOHCI();

		// TEO: Check if there's a key to enable/disable OHCI controller 0
		if(IsOHCIControllerEnabled((LPCWSTR)dwContext, REG_USB_HOST_OHCD_OHCI0_ENABLE, &dwValue))
		{
			pInstance->dwEnableOHCI0 = dwValue;
		}

		// TEO: Check if there's a key to enable/disable OHCI controller 1
		if(IsOHCIControllerEnabled((LPCWSTR)dwContext, REG_USB_HOST_OHCD_OHCI1_ENABLE, &dwValue))
		{
			pInstance->dwEnableOHCI1 = dwValue;
		}

		// if OHCI controller 0 is enabled, then call init function.
		if(pInstance->dwEnableOHCI0)
		{
			pInstance->pOHCIController0 = (SOhcdPdd*)(InitializeController((DWORD)REG_USB_HOST_OHCD_OHCI0_KEY /* dwContext */));
		}

		// if OHCI controller 1 is enabled, then call init function.
		if(pInstance->dwEnableOHCI1)
		{
			pInstance->pOHCIController1 = (SOhcdPdd*)(InitializeController((DWORD)REG_USB_HOST_OHCD_OHCI1_KEY /*dwContext*/));
		}

		DEBUGMSG(ZONE_PDD, (L"-HcdPdd_Init()\r\n"));

		if(pInstance->pOHCIController1 || pInstance->pOHCIController0)
		{
			dwReturn = (DWORD)pInstance;
		}
		else
		{
			free(pInstance);
		}
	}

	return dwReturn;
}


BOOL
HcdPdd_CheckConfigPower(
    UCHAR bPort,
    DWORD dwCfgPower,
    DWORD dwTotalPower
    )

/*++

Routine Description:

    OHCD PDD device check power configuration requirements.

Arguments:

    bPort - USB port number.

    dwCfgPower - Power required by configuration.

    dwTotalPower - Total power currently in use on the port.

Return Value:

    TRUE if successful, FALSE otherwise.

--*/

{
	UNREFERENCED_PARAMETER(bPort);
    return ((dwCfgPower + dwTotalPower) > 500) ? FALSE : TRUE;
}


static DWORD WINAPI HcdPdd_ResumeThread(LPVOID lpvParam)
{
    SOhcdPdd *pPddObject = (SOhcdPdd *)lpvParam;


    DEBUGMSG(ZONE_PDD, (L"+HcdPdd_ResumeThread()\r\n"));

	// The USB MDD calls DisableInterrupt and does not make
	// a call to InterruptDone to re-enable the interrupt.
	// This is our only opportunity to call InterruptDone.
	// The PowerUp and PowerResuming flags are set by the MDD
	// to synchronize the MDD resume thread, we use these to
	// know when it is OK to reenable the interrupt.
	CHW *pobOhcd = (CHW*)pPddObject->lpvOhcdMddObject;

	while(pobOhcd->GetPowerUpFlag()) {
		Sleep(200);
	}
	while(pobOhcd->GetPowerResumingFlag()) {
		Sleep(200);
	}

    InterruptDone(pPddObject->SysIntr);

    DEBUGMSG(ZONE_PDD, (L"-HcdPdd_ResumeThread()\r\n"));

    return 0;
}

VOID
HcdPdd_PowerUp(
    DWORD hDeviceContext
    )

/*++

Routine Description:

    OHCD PDD device power up routine.

    *** NB ***
      Do not use NkDbgPrintfW as it requires a system call, and this routine
      executes from the scheduler (no reschedule possible at that time).
    *** NB ***

Arguments:

    hDeviceContext - Handle to the OHDC device context.

Return Value:

    None.

--*/

{
	OHCDPddInstanceType *pOHCDPddInstance = (OHCDPddInstanceType *)hDeviceContext;

    DEBUGMSG(ZONE_PDD, (L"+HcdPdd_PowerUp()\r\n"));

	if(pOHCDPddInstance == NULL)
		return;

    InitializeAu13XXOHCI();

	// If OHCI controller 0 is enabled and the controller data structure
	// is not NULL, then call the MDD power up function for this controller
	if(pOHCDPddInstance->dwEnableOHCI0 && pOHCDPddInstance->pOHCIController0)
	{
		HcdMdd_PowerUp(pOHCDPddInstance->pOHCIController0->lpvOhcdMddObject);
	}

	// If OHCI controller 1 is enabled and the controller data structure
	// is not NULL, then call the MDD power up function for this controller
	if(pOHCDPddInstance->dwEnableOHCI1 && pOHCDPddInstance->pOHCIController1)
	{
		HcdMdd_PowerUp(pOHCDPddInstance->pOHCIController1->lpvOhcdMddObject);
	}

    DEBUGMSG(ZONE_PDD, (L"-HcdPdd_PowerUp()\r\n"));

    return;
}


//
// Clean up the controller after a resume from suspend.
// This function is executed from an exception context, so a thread must
// be created to do the work to alleviate the restrictions.
//
VOID
HcdPdd_InitiatePowerUp(
    DWORD hDeviceContext
    )
{
    SOhcdPdd *pPddObject;
    HANDLE    htResume;

	pPddObject = (SOhcdPdd *)hDeviceContext;


	// If using IDLE1 for sleep allow USB to wake system.
	if (SLEEPMODE_IDLE1 == pPddObject->SleepMode)
		return;

    if (pPddObject)
    {
        //
        // Create a thread to clean up the controller.
        //
        htResume = CreateThread(NULL, 0, HcdPdd_ResumeThread, pPddObject, 0, NULL);
        if (htResume)
            CloseHandle(htResume);
    }

    return;
}

void HcdPowerDownController(SOhcdPdd *pPddObject)
{
    ULONG     ulValue;

	// If using IDLE1 for sleep allow USB to wake system.
	if (SLEEPMODE_IDLE1 == pPddObject->SleepMode)
		return;

    // Power down the device.
    HcdMdd_PowerDown(pPddObject->lpvOhcdMddObject);

    // Issue a reset to the HCFS bits in the HcControl register.
    ulValue = READ_REGISTER_ULONG(pPddObject->pulHcControl);
    ulValue &= ~HcControlHCFSmask;
    ulValue |= HcControlFSReset;	// Clear HcControl register HCFS bits
    WRITE_REGISTER_ULONG(pPddObject->pulHcControl, ulValue);
}

VOID
HcdPdd_PowerDown(
    DWORD hDeviceContext
    )

/*++

Routine Description:

    OHCD PDD device power down routine.

    *** NB ***
      Do not use NkDbgPrintfW as it requires a system call, and this routine
      executes from the scheduler (no reschedule possible at that time).
    *** NB ***

Arguments:

    hDeviceContext - Handle to the OHDC device context.

Errata: (Affected Step: DA, HA)

    13. USB host controller is not properly reset by the USB Host Enable
        register.
        Problem: Clearing the USB_HOST_ENABLE enable bit (usbh_enable[2]) does
        not reset all of the host controller logic. This may result in erroneous
        USB host controller memory accesses and communication to connected
        USB devices while the controller is expected to be in reset.
        Workaround: Software should additionally clear the HCFS bits of the HcControl
        register.
        The following "Shutdown of Running Controller" sequences should be followed:
        o Clear HcControl register HCFS bits
	o Clear usbh_enable register E bit (Enable)
	o Clear usbh_enable register CE bit (Clock Enable)

Return Value:

    None.

--*/

{
	OHCDPddInstanceType *pOHCDPddInstance = (OHCDPddInstanceType *)hDeviceContext;
	AU13XX_USB * 	 pUSB = (AU13XX_USB*)(USB_PHYS_ADDR|KSEG1_OFFSET);

    DEBUGMSG(ZONE_PDD, (L"+HcdPdd_PowerDown()\r\n"));

	if(pOHCDPddInstance == NULL)
		return;

	// If OHCI controller 0 is enabled and the controller data structure
	// is not NULL, then call the power down function for this controller
	if(pOHCDPddInstance->dwEnableOHCI0 && pOHCDPddInstance->pOHCIController0)
	{
		HcdPowerDownController(pOHCDPddInstance->pOHCIController0);
	}

	// If OHCI controller 1 is enabled and the controller data structure
	// is not NULL, then call the power down function for this controller
	if(pOHCDPddInstance->dwEnableOHCI1 && pOHCDPddInstance->pOHCIController1)
	{
		HcdPowerDownController(pOHCDPddInstance->pOHCIController1);
	}

	pUSB->dwc_ctrl7 = 0;

	DEBUGMSG(1,(TEXT("-OHCI::HcdPdd_PowerDown\r\n")));

	return;
}


void HcdDeinitController(SOhcdPdd *pPddObject)
{
	//
    // Free the MDD object.
    //
    if (pPddObject->lpvOhcdMddObject)
        HcdMdd_DestroyHcdObject(pPddObject->lpvOhcdMddObject);

    //
    // Free the memory object.
    //
    if (pPddObject->lpvMemoryObject)
        HcdMdd_DestroyMemoryObject(pPddObject->lpvMemoryObject);

    //
    // Free the buffer.
    //
    FreePhysMem(pPddObject->VBuffer);

    //
    // Disconnect the interrupt.
    //
    if (pPddObject->IsrHandle) {
        FreeIntChainHandler(pPddObject->IsrHandle);
        pPddObject->IsrHandle = NULL;
    }
    if (pPddObject->hParentBusHandle)
        CloseBusAccessHandle(pPddObject->hParentBusHandle);

    InterruptDisconnect(pPddObject->SysIntr);

    if (pPddObject->PortBase) {
        MmUnmapIoSpace(pPddObject->PortBase,OHCD_PORT_RANGE);
    }

    free(pPddObject);

    MEMORYSTATUS ms;
    ms.dwLength = sizeof(ms);

    GlobalMemoryStatus(&ms);
}

BOOL
HcdPdd_Deinit(
    DWORD hDeviceContext
    )

/*++

Routine Description:

    OHCD PDD de-initialize routine.

Arguments:

    hDeviceContext - Handle to the OHDC device context.

Return Value:

    TRUE if successful, FALSE otherwise.

--*/

{
	OHCDPddInstanceType *pOHCDPddInstance = (OHCDPddInstanceType *)hDeviceContext;
	AU13XX_USB * 	 pUSB = (AU13XX_USB*)(USB_PHYS_ADDR|KSEG1_OFFSET);

    DEBUGMSG(ZONE_PDD, (L"+HcdPdd_Deinit()\r\n"));

	if(pOHCDPddInstance == NULL)
		return TRUE;

	/* Disable ohci interrupts mask in USB block.
	 * **This is not the same as GPINTR mask for USB interrupt
	 */
	pUSB->intr_enable &= ~(USB_INTR_OHCI1 | USB_INTR_OHCI0);

	// If OHCI controller 0 is enabled and the controller data structure
	// is not NULL, then deinitizialize this controller
	if(pOHCDPddInstance->dwEnableOHCI0 && pOHCDPddInstance->pOHCIController0)
	{
		HcdDeinitController(pOHCDPddInstance->pOHCIController0);
	}

	// If OHCI controller 1 is enabled and the controller data structure
	// is not NULL, then deinitizialize this controller
	if(pOHCDPddInstance->dwEnableOHCI1 && pOHCDPddInstance->pOHCIController1)
	{
		HcdDeinitController(pOHCDPddInstance->pOHCIController1);
	}

	/* Disable clocks to OHCI controllers */
	pUSB->dwc_ctrl3 |= USB_DWC_CTRL3_OHC1_CLKEN | USB_DWC_CTRL3_OHC0_CLKEN;

	// Free the driver instance data structure.
	free(pOHCDPddInstance);

    DEBUGMSG(ZONE_PDD, (L"-HcdPdd_Deinit()\r\n"));

    return TRUE;
}

//
// These functions are not used.
//

DWORD
HcdPdd_Open(
    DWORD hDeviceContext,
    DWORD AccessCode,
    DWORD ShareMode
    )
{
    UNREFERENCED_PARAMETER(hDeviceContext);
    UNREFERENCED_PARAMETER(AccessCode);
    UNREFERENCED_PARAMETER(ShareMode);
    // used only for power management; no need to maintain
    // distinctions between multiple open contexts.
	return hDeviceContext;
}


BOOL
HcdPdd_Close(
    DWORD hOpenContext
    )
{
    UNREFERENCED_PARAMETER(hOpenContext);
    return TRUE;
}


DWORD
HcdPdd_Read(
    DWORD hOpenContext,
    LPVOID pBuffer,
    DWORD Count
    )
{
    UNREFERENCED_PARAMETER(hOpenContext);
    UNREFERENCED_PARAMETER(pBuffer);
    UNREFERENCED_PARAMETER(Count);
    return (DWORD)-1;
}


DWORD
HcdPdd_Write(
    DWORD hOpenContext,
    LPCVOID pSourceBytes,
    DWORD NumberOfBytes
    )
{
    UNREFERENCED_PARAMETER(hOpenContext);
    UNREFERENCED_PARAMETER(pSourceBytes);
    UNREFERENCED_PARAMETER(NumberOfBytes);
    return (DWORD)-1;
}


DWORD
HcdPdd_Seek(
    DWORD hOpenContext,
    LONG Amount,
    DWORD Type
    )
{
    UNREFERENCED_PARAMETER(hOpenContext);
    UNREFERENCED_PARAMETER(Amount);
    UNREFERENCED_PARAMETER(Type);
    return (DWORD)-1;
}


BOOL
HcdPdd_IOControl(
    DWORD hOpenContext,
    DWORD dwCode,
    PBYTE pBufIn,
    DWORD dwLenIn,
    PBYTE pBufOut,
    DWORD dwLenOut,
    PDWORD pdwActualOut
    )
{
    UNREFERENCED_PARAMETER(hOpenContext);
    UNREFERENCED_PARAMETER(pBufIn);
    UNREFERENCED_PARAMETER(dwLenIn);

    DWORD dwRet = ERROR_INVALID_PARAMETER;

    DEBUGMSG(ZONE_PDD, (L"+HcdPdd_IOControl()\r\n"));

    switch (dwCode) {
      case IOCTL_POWER_CAPABILITIES:
        if(pBufOut && sizeof(POWER_CAPABILITIES) <= dwLenOut)
        {
            POWER_CAPABILITIES* pCap =
                reinterpret_cast<POWER_CAPABILITIES*>(pBufOut);
            memset(pBufOut, 0, sizeof(*pCap));  // zero the unused fields
            pCap->DeviceDx = DX_MASK(D0) | DX_MASK(D4);
            for (int i=D0; i<=D4; ++i) {
                pCap->Power[i] = PwrDeviceUnspecified;
                pCap->Latency[i] = PwrDeviceUnspecified;
            }
            pCap->Latency[D4] = 40; // more or less.

            if (pdwActualOut) *pdwActualOut = sizeof(*pCap);
            dwRet = ERROR_SUCCESS;
        }
        break;

      case IOCTL_POWER_SET:
        if(pBufOut && sizeof(CEDEVICE_POWER_STATE) <= dwLenOut)
        {
            CEDEVICE_POWER_STATE *pLev =
                reinterpret_cast<CEDEVICE_POWER_STATE*>(pBufOut);
            DEBUGMSG(ZONE_PDD,(L"OHCD setting power state to D%d\r\n", *pLev));
            if (*pLev <= D2) {
                *pLev = D0;
            } else {
                *pLev = D4;
            }

            // Our open context == our device context. See HcdPdd_Open().
            if (*pLev == D0) HCD_PowerUp(hOpenContext);
            else HCD_PowerDown(hOpenContext);

            if (pdwActualOut) *pdwActualOut = sizeof(*pLev);
            dwRet = ERROR_SUCCESS;
        }
        break;
    }

    DEBUGMSG(ZONE_PDD, (L"-HcdPdd_IOControl()\r\n"));

    SetLastError(dwRet);
    return dwRet == ERROR_SUCCESS;
}

}

/*++
Copyright (c) 2004-2005  BSQUARE Corporation.  All rights reserved.

Module Name:

    platspecific.c

Module Description:

    This file contains platform specific functions for the PCMCIA PDD.

Author:

    Ian Rae 24-Dec-2003

Notes:

Revision History:

--*/

#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <bceddk.h>
#include <platform.h>
#include "platspecific.h"

#if !defined(INTR_AU13XX_GPINT)
 extern AU1X00_SYS   *g_pPcmGpio;
 extern AU1X00_GPIO2 *g_pPcmGpio2;
#endif

BCSR *g_pPcmBcsr;

UINT16 PowerSettings[NUM_POWER_ENTRIES][NUM_POWER_ENTRIES] = {
{   0,			//Vcc 0V, Vpp 0V
    GR_BAD_VPP,	//Vcc 0V, Vpp 3V
    GR_BAD_VCC,	//Vcc 0V, Vpp 5V
    GR_BAD_VCC	//Vcc 0V, Vpp 12V
},
{
    0x04,		//Vcc 3V, Vpp 0V
    0x05,		//Vcc 3V, Vpp 3V
    GR_BAD_VCC,	//Vcc 3V, Vpp 5V  12V
    0x06		//Vcc 3V, Vpp 12V HIZ
},
{
    0x08,		//Vcc 5V, Vpp 0V
    GR_BAD_VPP,	//Vcc 5V, Vpp 3V
    0x09,		//Vcc 5V, Vpp 5V
    0x0a		//Vcc 5V, Vpp 12V
},
{
    0x0C, //GR_BAD_VCC,	//Vcc 12V, Vpp 0V
    0x0D, //GR_BAD_VCC,	//Vcc 12V, Vpp 3V
    GR_BAD_VCC,	//Vcc 12V, Vpp 5V
    0x0F  //GR_BAD_VCC	//Vcc 12V, Vpp 12V
}
};

BOOL PlatCardInitServices()
{
    PHYSICAL_ADDRESS PhysAddr;

	PhysAddr.HighPart = 0;
	PhysAddr.LowPart = BCSR_PHYSADDR;
	g_pPcmBcsr = MmMapIoSpace(PhysAddr, 4096, FALSE);
	if(g_pPcmBcsr == NULL)
	{
		DEBUGMSG(1,(L"Can't map the PCMCIA BCSR block\r\n"));
		return FALSE;
	}

	// Initially prevent interrupts (see note below)
	g_pPcmBcsr->intclrenable = (BCSR_BIC_PC0 | BCSR_BIC_PC1); // disable
	return TRUE;
}

UINT32
PlatReadPowerRequirement(
    UINT32 uSocket
    )
{
#if !defined(PLATFORM_DB13XX)

    UINT32 vs;

	vs = READ_REGISTER_USHORT((PUSHORT)&g_pPcmBcsr->status);
	if (uSocket == 1)
		vs >>= 2;
	vs &= BCSR_PCMCIA_PC0VPP;

	return vs;
#else
	return 2;
#endif
}

BOOL PlatCardDetect(UINT32 uSocket)
{
	UINT32 DetectMask;

	DetectMask = BCSR_BIC_PC0INSERT << (uSocket*2);

	return (0 != (READ_REGISTER_USHORT((PUSHORT)&g_pPcmBcsr->sigstatus) & DetectMask));
}

/*
 NOTE!!!
 NOTE!!!
 NOTE!!!
 The PCMCIA MDD calls InterruptInitialize() very early on in its initialization,
 as a result, PCMCIA interrupts are enabled to the processor. However, when a
 card is inserted and power applied, the card initially indicates it is busy/
 Not Ready by driving READY/IRQ# low, which means the processor sees *lots* of
 false interrupts during the power-up time (hundreds of milliseconds). So the
 bandaid below prevents the interrupt from occuring (by changing the configuration)
 if the card isn't ready, and when it is, re-enables the interrupt. This routine
 is only called when a card is present in the socket.
 */
BOOL PlatCardReady(UINT32 uSocket)
{
	UINT32 bit, Ready;

	if (uSocket == 0)
		bit = BCSR_BIC_PC0;
	else
		bit = BCSR_BIC_PC1;

	// Register bit is inverted from signal
	Ready = !(READ_REGISTER_USHORT((PUSHORT)&g_pPcmBcsr->sigstatus) & bit);
	Ready = (Ready & PlatCardDetect(uSocket));

	if (Ready)
		g_pPcmBcsr->intsetenable = bit; // enable
	else
		g_pPcmBcsr->intclrenable = bit; // disable

	return Ready;
}

/*
 NOTE!!!
 NOTE!!!
 NOTE!!!
 There is some kind of hiccup in the PCMCIA MDD when certain 3V
 cards are inserted, a Vcc of 5V is temporarily requested which
 causes problems with the card and power supply, and usually for
 the board to turn off. So a dirty little bandaid simply prevents
 any voltage setting other than what the card initially requests.
*/
VOID PlatCardSetPower(UINT32 uSocket,UINT32 Power)
{
#if !defined(PLATFORM_DB13XX)
	UINT32 tmp;

	// This only power-down socket, thus only permiting Vs - bandaid
	if (Power == 0) // power off socket
	{
		tmp = READ_REGISTER_USHORT((PUSHORT)&g_pPcmBcsr->pcmcia);
		tmp &= ~(0xFF << (uSocket * 8));
		WRITE_REGISTER_USHORT((PUSHORT)&g_pPcmBcsr->pcmcia, (USHORT)tmp);
	}
#endif
}

VOID PlatCardResetSocket(UINT32 uSocket,UINT32 Power)
{
	UINT16 tmp;

	// Apply power, assert reset and turn on PCMCIA buffers
    tmp = READ_REGISTER_USHORT((PUSHORT)&g_pPcmBcsr->pcmcia);
	tmp &= ~(0xFF << (8 * uSocket));
#if !defined(PLATFORM_DB13XX)
	tmp |= (Power << (uSocket * 8));
#endif
    tmp |= (BCSR_PCMCIA_PC0DRVEN << (8 * uSocket));
    WRITE_REGISTER_USHORT((PUSHORT)&g_pPcmBcsr->pcmcia, (USHORT)tmp);
    Sleep(300);

	// De-assert RESET
    tmp |= (BCSR_PCMCIA_PC0RST << (8 * uSocket));
	WRITE_REGISTER_USHORT((PUSHORT)&g_pPcmBcsr->pcmcia, (USHORT)tmp);
    Sleep(30);
}



/*++
Copyright (c) 2001  BSQUARE Corporation.  All rights reserved.

Module Name:

    memory.c

Module Description:

    This file implements the PCMCIA platform dependent memory access function
    for the platform.

Author:

    Jun Li 14-June-2001

Notes:

Revision History:

--*/


#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <bceddk.h>
#include <nkintr.h>
#include <platform.h>
#include "platspecific.h"

#define ZONE_PDD 1
UINT8
PDCardReadAttrByte(
    PVOID pCardMem,     // @parm Pointer to PC card attribute memory obtained from <f CardMapMemory>
    UINT32 uOffset      // @parm Offset into card's attribute memory
    )
{
    UINT8 uByte;
    PUCHAR pAttr = (PUCHAR)pCardMem;

    pAttr += uOffset * 2;
    uByte = *pAttr;

//    DEBUGMSG(1,(L"---------AttrByte(0x%08X): 0x%02X\r\n",(ULONG)pAttr,uByte));
    return uByte;
}

VOID
PDCardWriteAttrByte(
    PVOID pCardMem,     // @parm Pointer to PC card attribute memory obtained from <f CardMapMemory>
    UINT32 uOffset,     // @parm Offset into card's attribute memory
    UINT8 uByte         // @parm Byte to write
    )
{
    PUCHAR pAttr = (PUCHAR)pCardMem;

    pAttr += uOffset * 2;
    *pAttr = uByte;
//    DEBUGMSG(1,(L"---------Write AttrByte(0x%08X): 0x%02X\r\n",(ULONG)pAttr,uByte));
}

UINT8
PDCardReadCmnByte(
    PVOID pCardMem,     // @parm Pointer to PC card common memory obtained from <f CardMapMemory>
    UINT32 uOffset
    )
{
    UINT8 uByte;
    PUCHAR pCmn = (PUCHAR)pCardMem;

    pCmn += uOffset;
    uByte = *pCmn;

    return uByte;
}

VOID
PDCardWriteCmnByte(
    PVOID pCardMem,     // @parm Pointer to PC card common memory obtained from <f CardMapMemory>
    UINT32 uOffset,     // @parm Offset into card's common memory
    UINT8 uByte         // @parm Byte to write
    )
{
    PUCHAR pCmn = (PUCHAR)pCardMem;

    pCmn += uOffset;
    *pCmn = uByte;
}

UINT8
PDCardReadIOByte(
    PVOID pCardMem,     // @parm Pointer to PC card I/O space obtained from <f CardMapMemory>
    UINT32 uOffset
    )
{
    UINT8 uByte;
    PUCHAR pIO = (PUCHAR)pCardMem;

    pIO += uOffset;
    uByte = *pIO;

    DEBUGMSG(ZONE_PDD, (TEXT("PDCardReadIOByte Address: %x \t Offset: %x \t Data: %x\r\n"),
			      pCardMem, uOffset, uByte));

    return uByte;
}


//
// PDCardWriteIOByte
//
// @func    VOID | PDCardWriteIOByte | Write a byte to the specified offset in a card's
//                                       I/O space.
//
// @comm    This function should be called within a try/except statement in case the
// card is removed and the memory access results in a fault.  Card services calls
// PDCardWriteIOByte within a try/except clause in its <f CardWriteIOByte> function.
//
// @xref <f PDCardReadAttrByte> <f PDCardWriteAttrByte> <f PDCardWriteCmnByte>
//       <f PDCardReadCmnByte> <f PDCardReadIOByte>
//
VOID
PDCardWriteIOByte(
    PVOID pCardMem,     // @parm Pointer to PC card I/O space obtained from <f CardMapMemory>
    UINT32 uOffset,     // @parm Offset into card's I/O space
    UINT8 uByte         // @parm Byte to write
    )
{
    PUCHAR pIO = (PUCHAR)pCardMem;

    DEBUGMSG(ZONE_PDD, (TEXT("PDCardWriteIOByte Address: %x \t Offset: %x \t Data: %x\r\n"),
			      pCardMem, uOffset, uByte));

    pIO += uOffset;
    *pIO = uByte;
}

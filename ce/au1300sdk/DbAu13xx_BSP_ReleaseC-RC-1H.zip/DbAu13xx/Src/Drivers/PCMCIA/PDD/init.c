/*++
Copyright (c) 2001-2004  BSQUARE Corporation.  All rights reserved.

Module Name:

    init.c

Module Description:

    This file implements the PCMCIA platform dependent initialize function
    for the platform.

Author:

Notes:

--*/

#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <bceddk.h>
#include <nkintr.h>
#include "platform.h"
#include "platspecific.h"
#include "gpintr.h"

// required by MDD
DWORD gIntrPcmciaState = SYSINTR_NOP;
DWORD gIntrPcmciaLevel = SYSINTR_NOP;

#if !defined(INTR_AU13XX_GPINT)
 AU1X00_SYS *g_pPcmGpio;
 AU1X00_GPIO2 *g_pPcmGpio2;
#endif

CRITICAL_SECTION gPddSocketCrit;
CRITICAL_SECTION gPddWindowCrit;
CRITICAL_SECTION gPddMemoryCrit;

STATUS
PDCardInitServices(DWORD dwInfo)
{
    PHYSICAL_ADDRESS PhysAddr;

	(void)PhysAddr;

    DEBUGMSG(1,(L"+PDCardInitServices\r\n"));

#if !defined(INTR_AU13XX_GPINT)
	// Most platforms will utilize either the primary or secondary GPIO
	// block for the PCMCIA interface, so as a courteousy, go ahead and
	// map both; it is a safe thing to do even if not used
	PhysAddr.QuadPart = SYS_PHYS_ADDR; /* Primary GPIO module */
	g_pPcmGpio = MmMapIoSpace(PhysAddr, sizeof(*g_pPcmGpio), FALSE);
	if (g_pPcmGpio == NULL)
	{
		DEBUGMSG(1,(L"Can't map the PCMCIA SYS block\r\n"));
		goto ErrorReturn;
	}
#endif

	// Not all AMD chips have the GPIO2 peripheral
#ifdef GPIO2_PHYS_ADDR
	PhysAddr.QuadPart = GPIO2_PHYS_ADDR; /* Secondary GPIO module */
	g_pPcmGpio2 = MmMapIoSpace(PhysAddr, sizeof(*g_pPcmGpio2), FALSE);
	if (g_pPcmGpio2 == NULL)
	{
		DEBUGMSG(1,(L"Can't map the PCMCIA GPIO2 block\r\n"));
		goto ErrorReturn;
	}
#endif

    // Force polling for the PCMCIA state change, by default
    gIntrPcmciaState = SYSINTR_NOP;

	// Setup interrupt for PCMCIA card I/O interrupts
    gIntrPcmciaLevel = InterruptConnect(Internal, 0, PLAT_LEVEL_HWINTR, 0);

	// Map any platform-specific support hardware
	if (!PlatCardInitServices()) {
		goto ErrorReturn;
	}
    //
    // Initialize critical sections.
    //
    InitializeCriticalSection(&gPddSocketCrit);
    InitializeCriticalSection(&gPddWindowCrit);
    InitializeCriticalSection(&gPddMemoryCrit);

    DEBUGMSG(1,(L"-PDCardInitServices\r\n"));
    return CERR_SUCCESS;

  ErrorReturn:

    return CERR_GENERAL_FAILURE;
}


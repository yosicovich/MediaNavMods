/*++
Copyright (c) 2001, 2003  BSQUARE Corporation.  All rights reserved.

Module Name:

    socket.c

Module Description:

    This file implements the PCMCIA platform dependent socket function
    for the platform.

Author:

    Jun Li 14-June-2001

Notes:

Revision History:

--*/

#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <bceddk.h>
#include <nkintr.h>
#include "platspecific.h"

#if !defined(INTR_AU13XX_GPINT)
 extern AU1X00_SYS *g_pPcmGpio;
 extern AU1X00_GPIO2 *g_pPcmGpio2;
#endif

#undef ZONE_PDD
#define ZONE_PDD 1

#define ZONE_VERBOSE 0


#define PCMCIA_RDY_POLL_INT       50
#define PCMCIA_MAX_RDY_WAIT_TIME  2000

extern CRITICAL_SECTION gPddSocketCrit;

extern CRITICAL_SECTION        gPddSocketCrit;
extern PDCARD_ADAPTER_INFO v_AdapterInfo;
extern PDCARD_POWER_ENTRY v_PowerEntries[NUM_POWER_ENTRIES];

PDCARD_ADAPTER_INFO v_AdapterInfo = {
    1,  // memory granularity (for production platforms, this should be 1)
    0,  // adapter capabilities
    4,  // cache line size in 32-bit words
    NUM_POWER_ENTRIES
};

PDCARD_POWER_ENTRY v_PowerEntries[NUM_POWER_ENTRIES] = {
{ 0,    PWR_SUPPLY_VCC | PWR_SUPPLY_VPP1 | PWR_SUPPLY_VPP2 },
{ 33,   PWR_SUPPLY_VCC | PWR_SUPPLY_VPP1 | PWR_SUPPLY_VPP2 },
{ 50,   PWR_SUPPLY_VCC | PWR_SUPPLY_VPP1 | PWR_SUPPLY_VPP2},
{ 120,  PWR_SUPPLY_VPP1 | PWR_SUPPLY_VPP2 },
};

// instantiated in platspecific.c
extern UINT16 PowerSettings[NUM_POWER_ENTRIES][NUM_POWER_ENTRIES];

#ifdef NUM_SOCKETS

#if NUM_SOCKETS == 1
PDCARD_ADAPTER_STATE v_AdapterState[NUM_SOCKETS] = {ADP_STATE_POWEROFF};
PDCARD_SOCKET_STATE v_SockState[NUM_SOCKETS] = {
{
    SOCK_CAP_IO,
#ifdef FORCE_POLLING
    EVENT_MASK_BATTERY_DEAD|EVENT_MASK_BATTERY_LOW|
#else
    EVENT_MASK_BATTERY_DEAD|EVENT_MASK_BATTERY_LOW|EVENT_MASK_CARD_DETECT|
#endif
    EVENT_MASK_WRITE_PROTECT,   // status change interrupt mask
    0,  // present socket state
    0,  // control and indicators
    0,  // interface type
    0,  // Vcc
    0,  // Vpp1
    0   // Vpp2
}
};

#else // NUM_SOCKETS == 2
PDCARD_ADAPTER_STATE v_AdapterState[NUM_SOCKETS] = {ADP_STATE_POWEROFF,ADP_STATE_POWEROFF};
PDCARD_SOCKET_STATE v_SockState[NUM_SOCKETS] = {
{
    SOCK_CAP_IO,
#ifdef FORCE_POLLING
    EVENT_MASK_BATTERY_DEAD|EVENT_MASK_BATTERY_LOW|
#else
    EVENT_MASK_BATTERY_DEAD|EVENT_MASK_BATTERY_LOW|EVENT_MASK_CARD_DETECT|
#endif
    EVENT_MASK_WRITE_PROTECT,   // status change interrupt mask
    0,  // present socket state
    0,  // control and indicators
    0,  // interface type
    0,  // Vcc
    0,  // Vpp1
    0   // Vpp2
},
{
    SOCK_CAP_IO,
#ifdef FORCE_POLLING
    EVENT_MASK_BATTERY_DEAD|EVENT_MASK_BATTERY_LOW|
#else
    EVENT_MASK_BATTERY_DEAD|EVENT_MASK_BATTERY_LOW|EVENT_MASK_CARD_DETECT|
#endif
    EVENT_MASK_WRITE_PROTECT,   // status change interrupt mask
    0,  // present socket state
    0,  // control and indicators
    0,  // interface type
    0,  // Vcc
    0,  // Vpp1
    0   // Vpp2
}
};

#endif
#endif // #ifdef NUM_SOCKETS


INT8
ReadPowerRequirement(
    UINT32 uSocket
    )
{
    UINT32 vs;

	vs = PlatReadPowerRequirement(uSocket);

	//DEBUGMSG(1,(L"PCMCIA: Power; Vs = %x\r\n", vs));
	switch(vs)
	{
		case 0:
		case 1:
		case 2:
			DEBUGMSG(ZONE_VERBOSE,(L"3V card\r\n"));
			return 1; // index into power settings table
		case 3:
			DEBUGMSG(ZONE_VERBOSE,(L"5V card\r\n"));
			return 2;
    default:
        DEBUGMSG(1,(L"invalid VCC pin\r\n"));
        return 0;
    }
}


STATUS
PDCardGetSocket(
    UINT32 uSocket,             // @parm Socket number (first socket is 0)
    PPDCARD_SOCKET_STATE pState // @parm Pointer to PDCARD_SOCKET_STATE structure
    )
{
    PPDCARD_SOCKET_STATE pPDDState;

    //DEBUGMSG(1,(L"+PDCardGetSocket\r\n"));

    if (uSocket >= NUM_SOCKETS)
        return CERR_BAD_SOCKET;

    EnterCriticalSection(&gPddSocketCrit);

    pPDDState = &v_SockState[uSocket];

    pPDDState->fNotifyEvents = 0;

    if(PlatCardDetect(uSocket)) {
        DEBUGMSG(ZONE_VERBOSE,(L"Card Detect\r\n"));
        pPDDState->fNotifyEvents |= EVENT_MASK_CARD_DETECT;
        pPDDState->fVcc=ReadPowerRequirement(uSocket);
        pPDDState->uVpp1 = v_SockState[uSocket].uVpp2 = 0;
    }
    else {
        pPDDState->fVcc = 0;
        pPDDState->uVpp1 = v_SockState[uSocket].uVpp2 = 0;
    }

    if(PlatCardReady(uSocket)) {
        DEBUGMSG(ZONE_VERBOSE,(L"Card Ready\r\n"));
        pPDDState->fNotifyEvents |= EVENT_MASK_CARD_READY;
    }

    memcpy(pState,pPDDState,sizeof(PDCARD_SOCKET_STATE));
    LeaveCriticalSection(&gPddSocketCrit);

    //DEBUGMSG(1,(L"-PDCardGetSocket\r\n"));
    return CERR_SUCCESS;
}


STATUS
PDCardSetSocket(
    UINT32 uSocket,             // @parm Socket number (first socket is 0)
    PPDCARD_SOCKET_STATE pState // @parm Pointer to PDCARD_SOCKET_STATE structure
    )
{
    STATUS ret;
    ULONG pwr, OriginalPwr;
    ULONG tmp = 0;

    DEBUGMSG(ZONE_PDD, (TEXT("PDCardSetSocket(%d) entered\r\n"), uSocket));
    EnterCriticalSection(&gPddSocketCrit);

    if (uSocket >= NUM_SOCKETS) {
        ret = CERR_BAD_SOCKET;
        goto pcss_fail;
    }

    //
    // Check socket power level indexes
    //
    if ((pState->fVcc & SOCK_VCC_LEVEL_MASK) >= NUM_POWER_ENTRIES ||
        !(v_PowerEntries[pState->fVcc & SOCK_VCC_LEVEL_MASK].fSupply & PWR_SUPPLY_VCC)) {
        ret = CERR_BAD_VCC;
        goto pcss_fail;
    }

    if(pState->uVpp1!=pState->uVpp2) {
        DEBUGMSG(ZONE_PDD,(L"Vpp1 has to be the same as Vpp2\r\n"));
        ret=CERR_BAD_VPP;
        goto pcss_fail;
    }

    if (pState->uVpp1 >= NUM_POWER_ENTRIES || pState->uVpp2 >= NUM_POWER_ENTRIES ||
        !(v_PowerEntries[pState->uVpp1].fSupply & PWR_SUPPLY_VPP1) ||
        !(v_PowerEntries[pState->uVpp2].fSupply & PWR_SUPPLY_VPP2)) {
        ret = CERR_BAD_VPP;
        goto pcss_fail;
    }

    pwr = (ULONG)PowerSettings[pState->fVcc][pState->uVpp1];

    OriginalPwr = pwr;
    DEBUGMSG(ZONE_PDD,(L"fVcc=%d,uVpp1=%d,Power=0x%08X\r\n",pState->fVcc,pState->uVpp1,pwr));

    if(pwr==GR_BAD_VCC||pwr==GR_BAD_VPP) {
        DEBUGMSG(ZONE_PDD,(L"fVcc=%d,uVpp1=%d,Power=0x%08X\r\n",pState->fVcc,pState->uVpp1,pwr));
        DEBUGMSG(ZONE_PDD,(L"Bad power setting!\r\n"));
        ret=(pwr==GR_BAD_VCC)?CERR_BAD_VCC:CERR_BAD_VPP;
        goto pcss_fail;
    }

	PlatCardSetPower(uSocket,pwr);

    if (pState->fIREQRouting & SOCK_IREQ_ENABLE) {
    } else {
        DEBUGMSG(ZONE_PDD,(L"Disable PCMCIA Interrupts\r\n"));
    }

    ret=CERR_SUCCESS;

pcss_fail:
    LeaveCriticalSection(&gPddSocketCrit);
    DEBUGMSG(ZONE_PDD, (TEXT("PDCardSetSocket(%d) returning %d\r\n"),
        uSocket, ret));
    return ret;
}

STATUS
PDCardResetSocket(
    UINT32 uSocket  // @parm Socket number (first socket is 0)
    )
{
    USHORT SockMask=0;
    ULONG t;
    STATUS ret;
    ULONG pwr;

    DEBUGMSG(ZONE_PDD,(L"PDCardResetSocket: Reset Socket %d\r\n",uSocket));
    EnterCriticalSection(&gPddSocketCrit);

	if (!PlatCardDetect(uSocket))
	{
        DEBUGMSG(ZONE_PDD,(L"PCMCIA: no card detected in socket %d\r\n",uSocket));
        return CERR_SUCCESS;
    }

    pwr=(ULONG)PowerSettings[ReadPowerRequirement(uSocket)][ReadPowerRequirement(uSocket)];
    DEBUGMSG(ZONE_PDD,(L"Power=0x%08X\r\n",pwr));
    if(pwr==GR_BAD_VCC||pwr==GR_BAD_VPP) {
        DEBUGMSG(ZONE_PDD,(L"Bad power setting!\r\n"));
        ret=(pwr==GR_BAD_VCC)?CERR_BAD_VCC:CERR_BAD_VPP;
        goto pcss_fail;
    }

	PlatCardResetSocket(uSocket,pwr);

	// Wait for Card Ready
    for (t=0; t < PCMCIA_MAX_RDY_WAIT_TIME; t+= PCMCIA_RDY_POLL_INT)
    {
#if !defined(INTR_AU13XX_GPINT)
		//tmp = READ_REGISTER_ULONG((PULONG)&g_pPcmGpio->pinstaterd);
#endif
		if (!PlatCardReady(uSocket))
		{
            DEBUGMSG(ZONE_VERBOSE,(L"Card not ready on %d\r\n", t));
            Sleep(PCMCIA_RDY_POLL_INT); // Still busy
        }
		else
        {
            DEBUGMSG(ZONE_VERBOSE,(L"Card RDY on %d\r\n", t));
            break;
        }
    }

    if (t >= PCMCIA_MAX_RDY_WAIT_TIME)
    {
        RETAILMSG(1,(L"Timed out waiting for card RDY\r\n"));
    }

    ret=CERR_SUCCESS;
pcss_fail:
    LeaveCriticalSection(&gPddSocketCrit);
    return ret;
}


STATUS
PDCardInquireAdapter(
    PPDCARD_ADAPTER_INFO pAdapterInfo   // @parm Pointer to PDCARD_ADAPTER_INFO structure.
    )
{
    STATUS Status = CERR_BAD_ARGS;
    DEBUGMSG(ZONE_PDD, (TEXT("+PDCardInquireAdapter\r\n")));

    if (pAdapterInfo != NULL) {

        if (pAdapterInfo->uPowerEntries < NUM_POWER_ENTRIES) {
            pAdapterInfo->uPowerEntries = NUM_POWER_ENTRIES;
            return CERR_BAD_ARG_LENGTH;
        }
        memcpy(pAdapterInfo,&v_AdapterInfo,sizeof(PDCARD_ADAPTER_INFO));

        pAdapterInfo = (PPDCARD_ADAPTER_INFO)(((UINT)pAdapterInfo) + sizeof(PDCARD_ADAPTER_INFO));

        // Copy the power entries at the end
        memcpy(pAdapterInfo, &v_PowerEntries, sizeof(v_PowerEntries));
        Status = CERR_SUCCESS;
    }
    DEBUGMSG(ZONE_PDD, (TEXT("-PDCardInquireAdapter\r\n")));

    return Status;
}

STATUS
PDCardGetAdapter(
    UINT32 uSocket,
    PPDCARD_ADAPTER_STATE pState
    )
{
    BOOL bUserMode;


    bUserMode = (*pState & ADP_STATE_KERNEL_MODE) ? FALSE : TRUE;
    if (uSocket >= NUM_SOCKETS) {
        return CERR_BAD_SOCKET;
    }

    if (pState == NULL) {
        return CERR_BAD_ARGS;
    }

    DEBUGMSG(bUserMode && ZONE_PDD, (TEXT("PDCardGetAdapter, socket %u: %x \r\n"),
                        uSocket,v_AdapterState[uSocket]));

    *pState = v_AdapterState[uSocket];

    return CERR_SUCCESS;
}

STATUS
PDCardSetAdapter(
    UINT32 uSocket,
    PPDCARD_ADAPTER_STATE pState
    )
{
    BOOL bUserMode;


    bUserMode = (*pState & ADP_STATE_KERNEL_MODE) ? FALSE : TRUE;
    DEBUGMSG(bUserMode && ZONE_PDD, (TEXT("PDCardSetAdapter, socket 0x%x: 0x%x \r\n"),
                        uSocket,*pState));

    v_AdapterState[uSocket]=*pState;
    return CERR_SUCCESS;
}


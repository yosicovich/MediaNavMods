/*++
Copyright (c) 2001-2004  BSQUARE Corporation.  All rights reserved.

Module Name:

    window.c

Module Description:

    This file implements the PCMCIA platform dependent memory access function
    for the platform.

Author:

    Jun Li 14-June-2001

Notes:

Revision History:

--*/

#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <bceddk.h>
#include <nkintr.h>
#include "platspecific.h"

#undef ZONE_PDD
#define ZONE_PDD 1

extern CRITICAL_SECTION gPddWindowCrit;

#define PCMCIA_ATTR_WIN_SIZE 0x2000000
#define PCMCIA_IO_WIN_SIZE 0x2000000
#define PCMCIA_CMN_WIN_SIZE 0x2000000

#define PCMCIA0_ATTR_WIN_PHYSBASE (PCMCIA_ATTR_PHYS_ADDR&0xffffffff)
#define PCMCIA0_IO_WIN_PHYSBASE (PCMCIA_IO_PHYS_ADDR&0xffffffff)
#define PCMCIA0_CMN_WIN_PHYSBASE (PCMCIA_MEM_PHYS_ADDR&0xffffffff)

PDCARD_WINDOW_STATE v_WinState[PCMCIA_NUM_WINDOWS] = {
{    // Window 0 - 8 bit attribute memory on socket 0
    0,                    // socket number
    WIN_STATE_ENABLED|WIN_STATE_ATTRIBUTE,    // state flags
    WIN_SPEED_EXP_1NS|WIN_SPEED_MANT_10|WIN_SPEED_USE_WAIT,
    PCMCIA_ATTR_WIN_SIZE,
    PCMCIA0_ATTR_WIN_PHYSBASE,
    0                     // card offset
},
{    // Window 1 - 8 bit common memory on socket 0
    0,                    // socket number
    WIN_STATE_ENABLED,    // state flags
    WIN_SPEED_EXP_1NS|WIN_SPEED_MANT_10|WIN_SPEED_USE_WAIT,
    PCMCIA_CMN_WIN_SIZE,
    PCMCIA0_CMN_WIN_PHYSBASE,
    0
},
{    // Window 2 - 8 bit  I/O on socket 0
    0,                    // socket number
    WIN_STATE_ENABLED|WIN_STATE_MAPS_IO,
    WIN_SPEED_EXP_1NS|WIN_SPEED_MANT_10|WIN_SPEED_USE_WAIT,
    PCMCIA_IO_WIN_SIZE,
    PCMCIA0_IO_WIN_PHYSBASE,
    0
},
#if defined(PCMCIA_PDD_DUAL_SLOT)
{    // Window 3 - 8 bit attribute memory on socket 0
    1,                    // socket number
    WIN_STATE_ENABLED|WIN_STATE_ATTRIBUTE,    // state flags
    WIN_SPEED_EXP_1NS|WIN_SPEED_MANT_10|WIN_SPEED_USE_WAIT,
    PCMCIA_ATTR_WIN_SIZE,
    PCMCIA0_ATTR_WIN_PHYSBASE+SOCKET1_OFFSET,
    0                     // card offset
},
{    // Window 4 - 8 bit common memory on socket 0
    1,                    // socket number
    WIN_STATE_ENABLED,    // state flags
    WIN_SPEED_EXP_1NS|WIN_SPEED_MANT_10|WIN_SPEED_USE_WAIT,
    PCMCIA_CMN_WIN_SIZE,
    PCMCIA0_CMN_WIN_PHYSBASE+SOCKET1_OFFSET,
    0
},
{    // Window 5 - 8 bit  I/O on socket 0
    1,                    // socket number
    WIN_STATE_ENABLED|WIN_STATE_MAPS_IO,
    WIN_SPEED_EXP_1NS|WIN_SPEED_MANT_10|WIN_SPEED_USE_WAIT,
    PCMCIA_IO_WIN_SIZE,
    PCMCIA0_IO_WIN_PHYSBASE+SOCKET1_OFFSET,
    0
},
#endif
};

//
// P2 memory and I/O window capabilities. Note that we don't have
// a 16 bit I/O window because some modem cards don't support
// 16 bit access, and the SH3 only has one area (A6) that can
// access I/O space.
//
PDCARD_WINDOW_INFO v_WinInfo[PCMCIA_NUM_WINDOWS] = {
{   // Capabilities of window 0
    1, // socket 0          <------- bitfield!!!!!!! bit 0 = socket 0 etc...
    WIN_CAP_ATTRIBUTE,
    MEM_CAP_8BIT | MEM_CAP_16BIT,    	// memory capabilities
    0,                  // I/O capabilities
    PCMCIA0_ATTR_WIN_PHYSBASE,
    PCMCIA0_ATTR_WIN_PHYSBASE + PCMCIA_ATTR_WIN_SIZE - 1,
    4096,               // min size of 1 page.
    PCMCIA_ATTR_WIN_SIZE, // max size
    4096,               // granularity of 1 page.
    0,                  // base address alignment
    0,                  // card offset alignment
    0,                  // I/O first byte
    0,                  // I/O last byte
    0,                  // I/O min size
    0,                  // I/O max size
    0,                  // I/O granularity
    0,                  // I/O address lines
    WIN_SPEED_EXP_100NS | WIN_SPEED_MANT_30| WIN_SPEED_USE_WAIT,    // mem slowest
    WIN_SPEED_EXP_100NS | WIN_SPEED_MANT_30| WIN_SPEED_USE_WAIT,    // mem fastest
},
{   // Capabilities of window 2
    1, // socket 0
    WIN_CAP_COMMON,
    MEM_CAP_8BIT | MEM_CAP_16BIT,    	// memory capabilities
    0,                  // I/O capabilities
    PCMCIA0_CMN_WIN_PHYSBASE,
    PCMCIA0_CMN_WIN_PHYSBASE + PCMCIA_CMN_WIN_SIZE - 1,
    4096,               // min size of 1 page.
    PCMCIA_CMN_WIN_SIZE, // max size
    4096,               // granularity of 1 page.
    0,                  // base address alignment
    0,                  // card offset alignment
    0,                  // I/O first byte
    0,                  // I/O last byte
    0,                  // I/O min size
    0,                  // I/O max size
    0,                  // I/O granularity
    0,                  // I/O address lines
    WIN_SPEED_EXP_100NS | WIN_SPEED_MANT_60| WIN_SPEED_USE_WAIT,    // mem slowest
    WIN_SPEED_EXP_100NS | WIN_SPEED_MANT_60| WIN_SPEED_USE_WAIT,    // mem fastest
},
{   // Capabilities of window 4
    1, // socket 0
    WIN_CAP_IO | WIN_CAP_WAIT,
    0,                          	// memory capabilities
    IO_CAP_8BIT | IO_CAP_16BIT, 	// I/O capabilities
    0,    // memory first byte
    0,    // memory last byte
    0,    // min size
    0,    // max size
    0,    // granularity of 1 page.
    0,    // base address alignment
    0,    // card offset alignment
    PCMCIA0_IO_WIN_PHYSBASE,      // I/O first byte
    PCMCIA0_IO_WIN_PHYSBASE+PCMCIA_IO_WIN_SIZE-1,    // I/O last byte
    4096,                // I/O min size
    PCMCIA_IO_WIN_SIZE,  // I/O max size
    4096,                // I/O granularity
    0,                   // I/O address lines
    0,    // mem slowest
    0,    // mem fastest
},
#if defined(PCMCIA_PDD_DUAL_SLOT)
{   // Capabilities of window 4
    2, // socket 1
    WIN_CAP_ATTRIBUTE,
    MEM_CAP_8BIT | MEM_CAP_16BIT,    	// memory capabilities
    0,                  // I/O capabilities
    PCMCIA0_ATTR_WIN_PHYSBASE+SOCKET1_OFFSET,
    PCMCIA0_ATTR_WIN_PHYSBASE + SOCKET1_OFFSET + PCMCIA_ATTR_WIN_SIZE - 1,
    4096,               // min size of 1 page.
    PCMCIA_ATTR_WIN_SIZE, // max size
    4096,               // granularity of 1 page.
    0,                  // base address alignment
    0,                  // card offset alignment
    0,                  // I/O first byte
    0,                  // I/O last byte
    0,                  // I/O min size
    0,                  // I/O max size
    0,                  // I/O granularity
    0,                  // I/O address lines
    WIN_SPEED_EXP_100NS | WIN_SPEED_MANT_30| WIN_SPEED_USE_WAIT,    // mem slowest
    WIN_SPEED_EXP_100NS | WIN_SPEED_MANT_30| WIN_SPEED_USE_WAIT,    // mem fastest
},
{   // Capabilities of window 5
    2, // socket 1
    WIN_CAP_COMMON,
    MEM_CAP_8BIT | MEM_CAP_16BIT,    	// memory capabilities
    0,                  // I/O capabilities
    PCMCIA0_CMN_WIN_PHYSBASE+SOCKET1_OFFSET,
    PCMCIA0_CMN_WIN_PHYSBASE + SOCKET1_OFFSET+PCMCIA_CMN_WIN_SIZE - 1,
    4096,               // min size of 1 page.
    PCMCIA_CMN_WIN_SIZE, // max size
    4096,               // granularity of 1 page.
    0,                  // base address alignment
    0,                  // card offset alignment
    0,                  // I/O first byte
    0,                  // I/O last byte
    0,                  // I/O min size
    0,                  // I/O max size
    0,                  // I/O granularity
    0,                  // I/O address lines
    WIN_SPEED_EXP_100NS | WIN_SPEED_MANT_60| WIN_SPEED_USE_WAIT,    // mem slowest
    WIN_SPEED_EXP_100NS | WIN_SPEED_MANT_60| WIN_SPEED_USE_WAIT,    // mem fastest
},
{   // Capabilities of window 6
    2, // socket 1
    WIN_CAP_IO | WIN_CAP_WAIT,
    0,                          	// memory capabilities
    IO_CAP_8BIT | IO_CAP_16BIT, 	// I/O capabilities
    0,    // memory first byte
    0,    // memory last byte
    0,    // min size
    0,    // max size
    0,    // granularity of 1 page.
    0,    // base address alignment
    0,    // card offset alignment
    PCMCIA0_IO_WIN_PHYSBASE+SOCKET1_OFFSET,      // I/O first byte
    PCMCIA0_IO_WIN_PHYSBASE+SOCKET1_OFFSET+PCMCIA_IO_WIN_SIZE-1,    // I/O last byte
    4096,                // I/O min size
    PCMCIA_IO_WIN_SIZE,  // I/O max size
    4096,                // I/O granularity
    0,                   // I/O address lines
    0,    // mem slowest
    0,    // mem fastest
},
#endif
};


STATUS
PDCardSetWindow(
    UINT32 uWindow,                     // @parm Window number (the first window is 0)
    PPDCARD_WINDOW_STATE pWindowState   // @parm Pointer to a PDCARD_WINDOW_STATE structure.
    )
{
    if (uWindow >= PCMCIA_NUM_WINDOWS) {
        return CERR_BAD_WINDOW;
    }

    DEBUGMSG(ZONE_PDD, (TEXT("PDCardSetWindow: %x\r\n"), uWindow));


    EnterCriticalSection(&gPddWindowCrit);
    v_WinState[uWindow].fState = pWindowState->fState;
    v_WinState[uWindow].fSpeed = pWindowState->fSpeed;
    v_WinState[uWindow].uSize = pWindowState->uSize;
    v_WinState[uWindow].uOffset = pWindowState->uOffset;

    LeaveCriticalSection(&gPddWindowCrit);
    return CERR_SUCCESS;
}

STATUS
PDCardInquireWindow(
    UINT32 uWindow,                     // @parm Window number (the first window is 0)
    PPDCARD_WINDOW_INFO pWinInfo        // @parm Pointer to a PDCARD_WINDOW_INFO structure.
    )
{
    if (uWindow >= PCMCIA_NUM_WINDOWS) {
        return CERR_BAD_WINDOW;
    }

    DEBUGMSG(ZONE_PDD, (TEXT("PDCardInquireWindow: %x\r\n"),uWindow));

    EnterCriticalSection(&gPddWindowCrit);
    memcpy(pWinInfo, &v_WinInfo[uWindow], sizeof(PDCARD_WINDOW_INFO));
    LeaveCriticalSection(&gPddWindowCrit);
    return CERR_SUCCESS;
}

STATUS
PDCardGetWindow(
    UINT32 uWindow,                     // @parm Window number (the first window is 0)
    PPDCARD_WINDOW_STATE pWindowState   // @parm Pointer to a PDCARD_WINDOW_STATE structure.
    )
{
    if (uWindow >= PCMCIA_NUM_WINDOWS) {
        return CERR_BAD_WINDOW;
    }

    DEBUGMSG(ZONE_PDD, (TEXT("PDCardGetWindow: %x\r\n"), uWindow));

    EnterCriticalSection(&gPddWindowCrit);
    memcpy(pWindowState, &(v_WinState[uWindow]), sizeof(PDCARD_WINDOW_STATE));
    LeaveCriticalSection(&gPddWindowCrit);
    return CERR_SUCCESS;
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////


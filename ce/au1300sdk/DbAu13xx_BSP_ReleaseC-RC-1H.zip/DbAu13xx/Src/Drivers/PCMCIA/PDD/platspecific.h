/*++
Copyright (c) 2004-2005  BSQUARE Corporation.  All rights reserved.

Module Name:

    platspecific.h

Module Description:

    This file contains platform specific definitions for the PCMCIA PDD.

Author:

    AMD

Notes:

Revision History:

--*/

#include <platform.h>

#if !defined(PLATFORM_DB13XX)
 #define PLAT_LEVEL_HWINTR	(HWINTR_EXT_PC0 | (HWINTR_EXT_PC1<<8))
#else
 #define PLAT_LEVEL_HWINTR	(BCSR_BIC_CF)
#endif

#define NUM_POWER_ENTRIES 4
#if !defined(PLATFORM_DB13XX)
 #define NUM_SOCKETS 2
#else
 #define NUM_SOCKETS 1
#endif
extern BCSR *g_pPcmBcsr;
#if !defined(SOC_AU13XX)
 #define PCMCIA_PDD_DUAL_SLOT
#endif
#define PCMCIA_NUM_WINDOWS 6
#define SOCKET1_OFFSET (1<<26) // address bit decoded externally for slot select
#define GR_BAD_VCC 0x0c0c
#define GR_BAD_VPP 0x0303

//
// Platform specific funtions defined in platspecific.c
//
extern BOOL PlatCardInitServices();
extern UINT32 PlatReadPowerRequirement(UINT32 uSocket);
extern BOOL PlatCardDetect(UINT32 uSocket);
extern BOOL PlatCardReady(UINT32 uSocket);
extern VOID PlatCardSetPower(UINT32 uSocket,UINT32 Power);
extern VOID PlatCardResetSocket(UINT32 uSocket, UINT32 Power);


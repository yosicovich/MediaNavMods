//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:  

    exclusiv.c

Abstract:  

    This file implements the PCMCIA model device driver socket aquisition
    functions.  This is provided as a sample to platform writers and is
    expected to be able to be used without modification on most (if not
    all) hardware platforms.

Functions:

    CardRequestExclusive()
    CardReleaseExclusive()

Notes:


--*/


#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <pcmcia.h>
#include <extern.h>

//
// CardRequestExclusive
//
// @doc DRIVERS
//
// @func    STATUS | CardRequestExclusive | Request exclusive access to a socket/function
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE, CERR_BAD_SOCKET or CERR_IN_USE.
//
// @comm    Attempt to grant exclusive access of a socket/function to the requesting
//          client.  This is done by querying all of the client drivers for approval
//          first.
//          Callbacks:
//               CE_EXCLUSIVE_REQUEST  to all client drivers to get approval.
//               CE_CARD_REMOVAL       to all client drivers indicating to them that
//                                     exclusive access was granted.
//               CE_CARD_INSERTION     to the requesting client
//               CE_EXCLUSIVE_COMPLETE to the requesting client to report status
//
STATUS
CardRequestExclusive(
    CARD_CLIENT_HANDLE hCardClient, // @parm Client handle from <f CardRegisterClient>
    CARD_SOCKET_HANDLE hSock        // @parm Socket/function specifier
    )
{
    PLOG_SOCKET pSock;
    PCLIENT_DRIVER pClient;
    STATUS status = CERR_SUCCESS;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardRequestExclusive entered\r\n")));

    //
    // Run this request through the parameter validation gauntlet.
    //
    if ((pClient = FindClient(hCardClient, TRUE, FALSE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto req_ex_end;
    }
    if (!IsCardInserted(hSock.uSocket)) {
        status = CERR_NO_CARD;
    } else if ((pSock = I_FindSocket(hSock)) == NULL) {
        status = CERR_BAD_SOCKET;
    } else if (pSock->hOwner == pClient) {
        goto req_ex_end;
    }


    if (status == CERR_SUCCESS) {
        CallbackAll(
            CE_EXCLUSIVE_REQUEST,
            CE_EXCLUSIVE_REQUEST,
            pClient,
            pSock->hSock,
            CALLBACK_FLAG_QUERY);
    }
    // CallbackThread will send the rest of the event messages

req_ex_end:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("CardRequestExclusive failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("CardRequestExclusive succeeded\r\n")));
    }
#endif
    return status;
}   // CardRequestExclusive


//
// CardReleaseExclusive
//
// @func    STATUS | CardReleaseExclusive | Release exclusive access to a socket/function
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE, CERR_BAD_SOCKET or CERR_IN_USE.
//
// @comm    Releases exclusive access of a socket/function for the requesting 
//          client and notifies all of the client drivers that the socket/function
//          is available again.
//          Callbacks:
//               CE_CARD_REMOVAL       to the requesting client followed by 
//               CE_CARD_INSERTION     to all client drivers
//
STATUS
CardReleaseExclusive(
    CARD_CLIENT_HANDLE hCardClient, // @parm Client handle from <f CardRegisterClient>
    CARD_SOCKET_HANDLE hSock        // @parm Socket/function specifier
    )
{
    PLOG_SOCKET pLsock;
    PCLIENT_DRIVER pClient;
    STATUS status = CERR_SUCCESS;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardReleaseExclusive entered\r\n")));

    if ((pClient = FindClient(hCardClient, TRUE, FALSE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto rel_ex_end;
    }

    //
    // This socket must already be owned by the client.
    //
    pLsock = I_FindSocket(hSock);
    if (pLsock == NULL) {
        status = CERR_BAD_SOCKET;
        goto rel_ex_end;
    }
    if (pLsock->hOwner != pClient) {
        status = CERR_IN_USE;
        goto rel_ex_end;
    }

    pLsock->fFlags &= ~OWNER_FLAG_EXCLUSIVE;
    if ((pLsock->fFlags & OWNER_FLAGS) == 0) {
        pLsock->hOwner = 0;    // remove exclusive access
    }

    //
    // Tell the client it is going away
    // 
    CallbackOne(
        CE_EXCLUSIVE_COMPLETE,  // This MajorEvent implies CardReleaseExclusive
        CE_CARD_REMOVAL,
        pClient,
        pLsock->hSock);
    // CallbackThread will send the rest of the event messages

rel_ex_end:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("CardReleaseExclusive failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("CardReleaseExclusive succeeded\r\n")));
    }
#endif
    return status;
}   // CardReleaseExclusive

//
// Copyright (c) Microsoft Corporation.  All rights reserved.
// Copyright (c) 2003 BSQUARE Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

    window.c

Abstract:

    This file implements the PCMCIA model device driver memory and I/O window
    functions.  This is provided as a sample to platform writers and is
    expected to be able to be used without modification on most (if not
    all) hardware platforms.

Functions:

    IsValidWindow()
    FindPhysWindow()
    CardRequestWindow()
    CardReleaseWindow()
    CardModifyWindow()
    CardMapWindow()
    CardReadAttrByte()
    CardReadCmnByte()
    CardWriteAttrByte()

Notes:


--*/


#include <windows.h>
#include <types.h>
#include <excpt.h>
#include <cardserv.h>
#include <sockserv.h>
#include <pcmcia.h>
#include <extern.h>
#include <resmgr.h>
#include <ceddk.h>

#ifdef INSTRUM_DEV
#include <instrumd.h>
#endif

DWORD g_IORM_ID[MAX_SOCKETS] = { RESMGR_IOSPACE, RESMGR_IOSPACE };

BOOL
IsValidWindow(
    PLOG_WINDOW pWin
    )
{
    PPHYS_WINDOW pPhys;
    PLOG_WINDOW pLog;

    //
    // Both the physical and logical windows must exist.
    //
    EnterCriticalSection(&v_WindowCrit);
    pPhys = v_pWinList;
    while (pPhys) {
        pLog = pPhys->pLog;
        while (pLog) {
            if (pWin == pLog) {
                LeaveCriticalSection(&v_WindowCrit);
                return TRUE;
            }
            pLog = pLog->Next;
        }
        pPhys = pPhys->Next;
    }
    LeaveCriticalSection(&v_WindowCrit);
    return FALSE;
}

//
// FindPhysWindow - Find a physical window that matches requested attributes
//
// If pPhys is NULL, then find any matching physical window.
// If pPhys is not NULL, then find a matching physical window with a
// programmable offset that is not being used (no attached logical windows).
//
// Returns NULL if no matching physical window was found
//
PPHYS_WINDOW
FindPhysWindow(
    UINT8 uSocket,
    UINT fAttributes,
    UINT uSize,
    PPHYS_WINDOW pPhys
    )
{
    PPHYS_WINDOW pWin;
    UINT16 fDesiredCaps;
    UINT16 fOtherCaps;

    //
    // Map the window attributes the client wants to the corresponding window
    // capabilities.
    //
    fDesiredCaps = WIN_CAP_COMMON;
    if (fAttributes & WIN_ATTR_IO_SPACE) {
        fDesiredCaps = WIN_CAP_IO;
    } else if (fAttributes & WIN_ATTR_ATTRIBUTE) {
        fDesiredCaps = WIN_CAP_ATTRIBUTE;
    }

    fOtherCaps = 0;
    if (fAttributes & WIN_ATTR_16BIT) {
        fOtherCaps |= MEM_CAP_16BIT;
    } else {
        fOtherCaps |= MEM_CAP_8BIT;
    }

    if (pPhys != NULL) {
        fOtherCaps |= MEM_CAP_PRG_BASE;
    }
    DEBUGMSG(ZONE_MEM, (TEXT("FindPhysWindow: Size=%d, socket=%d, desired caps=0x%x, other caps=0x%x\r\n"),
        uSize, uSocket, fDesiredCaps, fOtherCaps));

    //
    // Find a window that matches what the client wants.
    //
    EnterCriticalSection(&v_WindowCrit);
    pWin = v_pWinList;
    while (pWin) {
        if ((pWin->uMaxSize >= (uSize * v_pAdapterInfo->uMemGranularity)) &&
            (pWin->uSock == uSocket) &&
            ((pWin->fWindowCaps & fDesiredCaps) == fDesiredCaps) &&
            ((pWin->fOtherCaps & fOtherCaps) == fOtherCaps)) {
            //
            // CardRequestWindow doesn't need an unused physical window
            //
            if (pPhys == NULL) {
                break;
            }
            //
            // When CardMapWindow remaps, it needs an unused physical window
            //
            if (pWin->pLog == NULL) {
                break;
            }
        }
        pWin = pWin->Next;
    }
    LeaveCriticalSection(&v_WindowCrit);
    DEBUGMSG(ZONE_MEM, (TEXT("FindPhysWindow: returning 0x%x\r\n"), pWin));
    return pWin;
}   // FindPhysWindow


#ifdef DEBUG_TESTING
VOID DisplayAllWindows(VOID)
{
    PPHYS_WINDOW pPhys;
    PLOG_WINDOW pLog;

    //
    // Print out all the windows.
    //
    EnterCriticalSection(&v_WindowCrit);
    pPhys = v_pWinList;
    while (pPhys) {
        DEBUGMSG(1,(TEXT("Physical window %d at %x\r\n"), pPhys->uWindow, pPhys->uBase));
        pLog = pPhys->pLog;
        while (pLog) {
            DEBUGMSG(1,(TEXT("\tLogical window of %d at %x\r\n"), pLog->uReqSize, pLog->pVirtMem));
            pLog = pLog->Next;
        }
        pPhys = pPhys->Next;
    }
    LeaveCriticalSection(&v_WindowCrit);
}
#endif  // DEBUG_TESTING


//
// CardRequestWindow
//
// @doc DRIVERS
//
// @func    CARD_WINDOW_HANDLE | CardRequestWindow | Allocate a memory or I/O window with the desired attributes.
// @rdesc   Returns a CARD_WINDOW_HANDLE on success. On failure the return value is NULL and
//          GetLastError will return one of CERR_SUCCESS, CERR_BAD_ARGS, CERR_BAD_SOCKET or
//          CERR_OUT_OF_RESOURCE.
//
// @comm    Allocates a memory or I/O window that matches the characteristics specified in
//          the <t CARD_WINDOW_PARMS> structure.  The returned handle is used in subsequent calls
//          to <f CardMapWindow> and <f CardModifyWindow>.
// @xref     <f CardReleaseWindow>
//
CARD_WINDOW_HANDLE
CardRequestWindow(
    CARD_CLIENT_HANDLE hCardClient, // @parm Handle from <f CardRegisterClient>
    PCARD_WINDOW_PARMS pParms       // @parm Pointer to a <t CARD_WINDOW_PARMS> structure
    )
{
    PPHYS_WINDOW pWin;
    PLOG_WINDOW  pLog;
    PCLIENT_DRIVER pClient;
    STATUS status = CERR_SUCCESS;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardRequestWindow entered\r\n")));
    pLog = NULL;

    //
    // Perform some parameter checks first
    //
    if ((pClient = FindClient(hCardClient, TRUE, TRUE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto req_win_exit;
    }

    if (pParms == NULL) {
        status = CERR_BAD_ARGS;
        goto req_win_exit;
    }

    if (I_FindSocket(pParms->hSocket) == NULL) {
        status = CERR_BAD_SOCKET;
        goto req_win_exit;
    }

    pWin = FindPhysWindow(
                pParms->hSocket.uSocket,
                pParms->fAttributes,
                pParms->uWindowSize,
                NULL);
    if (pWin == NULL) {
        status = CERR_OUT_OF_RESOURCE;
        goto req_win_exit;
    }

    pLog = I_CreateLogicalWindow(pWin);
    if (pLog == NULL) {
        status = CERR_OUT_OF_RESOURCE;
    } else {
        pLog->hOwner = pClient;
        pLog->fAttributes = pParms->fAttributes;
        pLog->uReqSize = 0;
        pLog->uReqOffset = 0;
    }

    //DisplayAllWindows();

req_win_exit:
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("CardRequestWindow failed %d\r\n"), status));
        SetLastError(status);
        return NULL;
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("CardRequestWindow succeeded\r\n")));
        return (CARD_WINDOW_HANDLE)pLog;
    }
}   // CardRequestWindow



//
// CardReleaseWindow
//
// @func    STATUS | CardReleaseWindow | Release a memory or I/O window
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE, CERR_BAD_WINDOW or
//          CERR_CONFIGURATION_LOCKED.
//
// @comm    Releases a memory or I/O window previously allocated by <f CardRequestWindow>.
// @xref    <f CardReleaseConfiguration>
//
STATUS
CardReleaseWindow(
    CARD_WINDOW_HANDLE hWin // @parm Memory window handle from <f CardRequestWindow>
    )
{
    PLOG_WINDOW pWin = (PLOG_WINDOW)hWin;
    PCLIENT_DRIVER pClient;
    PLOG_SOCKET pLsock;
    STATUS status = CERR_SUCCESS;
#ifdef x86
    PDCARD_WINDOW_STATE WinState;
#endif
    DWORD uCardAddress, uSize;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardReleaseWindow entered\r\n")));

    //
    // Perform some parameter checks first
    //
    if (!IsValidWindow(pWin)) {
        status = CERR_BAD_WINDOW;
        goto rel_win_exit;
    }

    pClient = (PCLIENT_DRIVER)pWin->hOwner;
    if (!IsValidClient(pClient)) {
        status = CERR_BAD_HANDLE;
        goto rel_win_exit;
    }

    //
    // If it's an I/O window, then the client must call CardReleaseConfiguration
    // first.
    //
    if (pWin->pPhys->fWindowCaps & WIN_CAP_IO) {
        //
        // Check if this client owns the configuration for any function on this socket.
        //
        EnterCriticalSection(&v_SocketCrit);
        pLsock = v_Sockets[pWin->pPhys->uSock].pLsock;
        while (pLsock) {
            if ((pLsock->hOwner == pClient) &&
                (pLsock->fFlags & OWNER_FLAG_CONFIG)) {
                status = CERR_CONFIGURATION_LOCKED;
                LeaveCriticalSection(&v_SocketCrit);
                goto rel_win_exit;
            }
            pLsock = pLsock->Next;
        }
        LeaveCriticalSection(&v_SocketCrit);

#ifdef x86
        //
        // Disable this window so new map requests don't collide.
        //
        status = PDCardGetWindow(pWin->pPhys->uWindow, &WinState);
        if (status == CERR_SUCCESS) {
            pWin->pPhys->fFlags &= ~PHYS_WIN_FLAG_ENABLED;
            WinState.fState &= ~WIN_STATE_ENABLED;
            PDCardSetWindow(pWin->pPhys->uWindow, &WinState);
        }
#endif

        //
        // release the resources for non-PCMCIA devices.
        //
        uCardAddress = pWin->uReqOffset;
        uSize = pWin->uReqSize;
        if (uSize != 0 && g_IORM_ID[pWin->pPhys->uSock] != 0)
            ResourceRelease(g_IORM_ID[pWin->pPhys->uSock], uCardAddress, uSize);
    }

    //
    // Disassociate memory window from client and free the mapped region
    //
    I_DeleteLogicalWindow(pWin);

rel_win_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("CardReleaseWindow failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("CardReleaseWindow succeeded\r\n")));
    }
#endif

    return status;
}   // CardReleaseWindow


//
// CardModifyWindow
//
// @func STATUS | CardModifyWindow | Change the attributes of the specified memory window.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE, CERR_BAD_WINDOW or
//          CERR_BAD_ARGS.
//
// @comm    The window attributes that can be changed are:
//          1. Address either common or attribute space
//          2. Enable or disable window
//          3. Memory window speed
//          4. Choose 16 or 8 bit data path
// @xref    <t CARD_WINDOW_HANDLE> <f CardMapWindow>
//
STATUS
CardModifyWindow(
    CARD_WINDOW_HANDLE hWin,    // @parm Memory window handle from <f CardRequestWindow>
    UINT16 fAttributes,         // @parm Bit encoded window attributes (see cardserv.h)
    UINT8  fAccessSpeed         // @parm Bit encoded access speed (see cardserv.h)
    )
{
    PLOG_WINDOW pWin = (PLOG_WINDOW)hWin;
    PDCARD_WINDOW_STATE WinState;
    STATUS status = CERR_SUCCESS;
    unsigned int x;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardModifyWindow entered\r\n")));

    EnterCriticalSection(&v_WindowCrit);
    //
    // Perform some parameter checks first
    //
    if (!IsValidWindow(pWin)) {
        status = CERR_BAD_WINDOW;
        goto mod_win_exit;
    }
    if (!IsValidClient((PCLIENT_DRIVER)pWin->hOwner)) {
        status = CERR_BAD_HANDLE;
        goto mod_win_exit;
    }

    // Check if attribute flags are valid
    x = fAttributes & ~(WIN_ATTR_ATTRIBUTE | WIN_ATTR_ENABLED | WIN_ATTR_16BIT | WIN_ATTR_ACCESS_SPEED_VALID);
    if ((pWin->fAttributes & x) != x) {
        status = CERR_BAD_ARGS;
        goto mod_win_exit;
    }

    //
    // Must be only user (besides card services) of this physical window
    //
    if ((pWin->pPhys->pLog != pWin) || (pWin->Next != NULL)) {
        //
        // Check if card services is using this window and allow modification
        // if so.  Card services will be the first user of a window.
        // (note: first user means that it should be at the end!)
        //
        if ((pWin->pPhys->pLog != pWin) ||
            (pWin->Next->hOwner != CARDSERV_CLIENT_HANDLE) ||
            (pWin->Next->Next != NULL)) {
//        if ((pWin->pPhys->pLog->hOwner != CARDSERV_CLIENT_HANDLE) ||
//            (pWin->pPhys->pLog->Next != pWin) ||
//            (pWin->Next != NULL)) {
            status = CERR_IN_USE;
            goto mod_win_exit;
        }
    }

    status = PDCardGetWindow(pWin->pPhys->uWindow, &WinState);
    if (status) {
        goto mod_win_exit;
    }

    //
    // Change memory spaces (common or attribute) as appropriate
    //
    if (fAttributes & WIN_ATTR_ATTRIBUTE) {
        WinState.fState |= WIN_STATE_ATTRIBUTE;
        pWin->pPhys->fFlags |= PHYS_WIN_FLAG_ATTR_MODE;
    } else {
        WinState.fState &= ~WIN_STATE_ATTRIBUTE;
        pWin->pPhys->fFlags &= ~PHYS_WIN_FLAG_ATTR_MODE;
    }

    //
    // Enable or disable window
    //
    if (fAttributes & WIN_ATTR_ENABLED) {
        WinState.fState |= WIN_STATE_ENABLED;
        pWin->pPhys->fFlags |= PHYS_WIN_FLAG_ENABLED;
    } else {
        WinState.fState &= ~WIN_STATE_ENABLED;
        pWin->pPhys->fFlags &= ~PHYS_WIN_FLAG_ENABLED;
    }

    //
    // Change data path width
    //
    if (fAttributes & WIN_ATTR_16BIT) {
        WinState.fState |= WIN_STATE_16BIT;
        pWin->pPhys->fFlags |= PHYS_WIN_FLAG_16BIT_MODE;
    } else {
        WinState.fState &= ~WIN_STATE_16BIT;
        pWin->pPhys->fFlags &= ~PHYS_WIN_FLAG_16BIT_MODE;
    }

    //
    // See if user wants to change the window's access speed
    //
    if (fAttributes & WIN_ATTR_ACCESS_SPEED_VALID) {
        if (WinState.fSpeed != fAccessSpeed) {
            WinState.fSpeed = fAccessSpeed;
        }
    }

    pWin->fAttributes = fAttributes;
    status = PDCardSetWindow(pWin->pPhys->uWindow, &WinState);

mod_win_exit:
    LeaveCriticalSection(&v_WindowCrit);
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("CardModifyWindow failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("CardModifyWindow succeeded\r\n")));
    }
#endif

    return status;
}   // CardModifyWindow


//
// CardMapWindow
//
// @func PVOID | CardMapWindow | Map a memory or I/O window to virtual memory
//                                and return the pointer to virtual memory.
//
// @rdesc   Returns a PVOID pointer on success. On failure the return value is NULL and
//          GetLastError will return one of CERR_BAD_HANDLE, CERR_IN_USE,
//          CERR_OUT_OF_RESOURCE, CERR_BAD_SIZE or CERR_BAD_WINDOW.
//
// @comm    On failure, the previous virtual mapping for this window may be
//          invalid.
//
// Most of the current WinCE platforms use 3 fixed memory mapped ranges to
// access the 3 PC card address spaces (attribute, I/O and common memory).
// On these platforms, the address returned from CardMapWindow is a virtual
// address mapped to the physical address that corresponds to the caller's
// request.  Multiple clients are prevented from allocating overlapping ranges
// within each address space, though multiple allocations are allowed within
// each space.  A single client is allowed to map a range that overlaps its own
// previously allocated ranges.
// On platforms that support programmable windows via a standard socket
// controller, a combination of fixed memory mapped ranges and programmable
// ranges is used.  If the requested range cannot be mapped within one of the
// fixed regions, then one of the programmable regions may be used.  To avoid
// memory contention, the system ensures that only one mapped range exists
// within a programmable range.  The programmable ranges are not large (about
// 32k), but they can access anywhere within the 64Mb PC card address space.
//
// @xref <t CARD_WINDOW_HANDLE>
//
PVOID
CardMapWindow(
    CARD_WINDOW_HANDLE hWin,    // @parm Memory window handle from <f CardRequestWindow>
    UINT32 uCardAddress,        // @parm Starting address on the PC card to map
    UINT32 uSize,               // @parm Size of region to map to the PC card
    PUINT32 pGranularity        // @parm Memory granularity of mapped region
    )
{
    PLOG_WINDOW pWin = (PLOG_WINDOW)hWin;
    PLOG_WINDOW pTmp;
    PPHYS_WINDOW pPhys;
    UINT uStart;
    UINT uEnd;
    UINT uVirtSize;
    UINT uPhysAddr;
    UINT fAttributes;
    PDCARD_WINDOW_STATE WinState;
    STATUS status = CERR_SUCCESS;
    BOOL bSetSocket = FALSE;
    PVOID RetVal;

#ifdef x86
    ULONG  inIoSpace;
    PHYSICAL_ADDRESS ioPhysicalBase;
#endif // x86

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardMapWindow entered\r\n")));

    // handle possible NULL return value - might be possible to #ifdef x86 this
    SetLastError(CERR_SUCCESS);
    EnterCriticalSection(&v_WindowCrit);

    //
    // The granularity parameter harks back to the first Windows CE development
    // platform (Perp) which mapped the PCMCIA area such that a valid byte was
    // presented at each DWORD aligned address. One had to add 4 to the address
    // pointer to access the next byte. The granularity parameter allowed the
    // same driver to work on other platforms as well, as long as the driver
    // multiplied the desired offset by the granularity.
    //
    if (pGranularity) {
        *pGranularity = 1;
    }

    //
    // Perform some parameter checks first
    //
    if (!IsValidWindow(pWin)) {
        status = CERR_BAD_WINDOW;
        goto map_win_fail_norel;
    }
    if (!IsValidClient((PCLIENT_DRIVER)pWin->hOwner)) {
        status = CERR_BAD_HANDLE;
        goto map_win_fail_norel;
    }
    if (uSize == 0) {
        status = CERR_BAD_SIZE;
        goto map_win_fail_norel;
    }

    fAttributes = pWin->fAttributes; // remember requested window attributes.

    //
    // Check if this window can accommodate the request
    //
    if (((uCardAddress + uSize) > pWin->pPhys->uMaxSize) ||
        (pWin->pPhys->fOtherCaps & MEM_CAP_PRG_BASE)) {
        //
        // If this window's mapping is programmable and this is the only
        // logical window on this physical window, then remap it.
        //
        if ((pWin->pPhys->fOtherCaps & MEM_CAP_PRG_BASE) &&
            (pWin->pPhys->pLog == pWin) &&
            (pWin->Next == NULL)) {
            DEBUGMSG(ZONE_MEM, (TEXT("CardMapWindow need to remap.\r\n")));
        } else {
            DEBUGMSG(ZONE_MEM, (TEXT("CardMapWindow need to switch physical windows.\r\n")));
            //
            // See if there is an available physical window to support this request
            //
            pPhys = FindPhysWindow(
                            pWin->pPhys->uSock,
                            pWin->fAttributes,
                            uSize,
                            pWin->pPhys);
            if (pPhys == NULL) {
                status = CERR_OUT_OF_RESOURCE;
                goto map_win_fail_norel;
            }
            //
            // Link the caller's logical window to the available physical window
            //
            I_UnlinkLogicalWindow(pWin);
            I_LinkLogicalWindow(pPhys, pWin);
            //DisplayAllWindows();
        }
        bSetSocket = TRUE;
    }

    //
    // Make sure no existing windows collide
    //
    pTmp = pWin->pPhys->pLog;
    while (pTmp) {
        if (pTmp != pWin) {
            //
            // If someone besides card services owns this window, then see if it collides.
            // Also allow window overlap if both windows are owned by the same client.
            //
            if ((pTmp->hOwner != 0) &&
                (pTmp->hOwner != CARDSERV_CLIENT_HANDLE)) {
                if (pTmp->hOwner != pWin->hOwner) {
                    if ((uCardAddress+uSize) > pTmp->uReqOffset) {
                        if (uCardAddress < (pTmp->uReqOffset + pTmp->uReqSize)) {
                            status = CERR_IN_USE;
                            DEBUGMSG(ZONE_WARNING|ZONE_MEM,
                                (TEXT("CardMapWindow: window collision\r\n")));

                            goto map_win_fail_norel;
                        }
                    }
                }
            }
        }
        pTmp = pTmp->Next;
    }   // Window collision check

    //
    // Undo the old mapping
    //
    if (pWin->pVirtMem) {
        DEBUGMSG(ZONE_MEM, (TEXT("CardMapWindow calling VirtualFree(0x%x) for old mapping.\r\n"), pWin->pVirtMem));
        if (VirtualFree(pWin->pVirtMem, 0, MEM_RELEASE) == FALSE) {
            DEBUGMSG(ZONE_MEM|ZONE_ERROR, (TEXT("CarpMapWindow: VirtualFree(old) failed %d\r\n"), GetLastError()));
        }

#ifdef INSTRUM_DEV
        ics_deleteCardRange(pWin->pVirtMem);
#endif

        pWin->pVirtMem = NULL;
    }

    if ((pWin->pPhys->fWindowCaps & WIN_CAP_IO) && pWin->uReqSize != 0 &&
        g_IORM_ID[pWin->pPhys->uSock] != 0)
        ResourceRelease(g_IORM_ID[pWin->pPhys->uSock], pWin->uReqOffset, pWin->uReqSize);
    pWin->uReqOffset = 0;
    pWin->uReqSize = 0;
    if ((pWin->pPhys->fWindowCaps & WIN_CAP_IO) && g_IORM_ID[pWin->pPhys->uSock] != 0) {
        if (ResourceRequest(g_IORM_ID[pWin->pPhys->uSock], uCardAddress, uSize) != TRUE) {
            status = CERR_IN_USE;
            goto map_win_fail_norel;
        }
    }

    if (bSetSocket == TRUE) {
        DEBUGMSG(ZONE_MEM, (TEXT("CardMapWindow remapping window %d.\r\n"), pWin->pPhys->uWindow));
        //
        // Remap the physical window
        //
        status = PDCardGetWindow(pWin->pPhys->uWindow, &WinState);
        if (status) {
            goto map_win_fail;
        }
        WinState.uOffset = pWin->pPhys->uOffset = uCardAddress;
        WinState.uSize = pWin->pPhys->uSize = uSize;
        WinState.fState |= WIN_STATE_ENABLED;
        pWin->pPhys->fFlags |= PHYS_WIN_FLAG_ENABLED;
        if (fAttributes & WIN_ATTR_ATTRIBUTE) {
            WinState.fState |= WIN_STATE_ATTRIBUTE;
            pWin->pPhys->fFlags |= PHYS_WIN_FLAG_ATTR_MODE;
        } else {
            WinState.fState &= ~WIN_STATE_ATTRIBUTE;
            pWin->pPhys->fFlags &= ~PHYS_WIN_FLAG_ATTR_MODE;
        }
        status = PDCardSetWindow(pWin->pPhys->uWindow, &WinState);
        if (status) {
            goto map_win_fail;
        }
        uStart = ((pWin->pPhys->uBase + uCardAddress - WinState.uOffset) / v_PageSize) * v_PageSize;
        uEnd = ((uSize + (pWin->pPhys->uBase + uCardAddress - WinState.uOffset) + v_PageSize - 1) / v_PageSize) * v_PageSize;
        uVirtSize = uEnd - uStart;
    } else {
        //
        // Compute beginning and ending addresses of the mapping region (must be on page boundaries)
        //
        uStart = ((pWin->pPhys->uBase + uCardAddress) / v_PageSize) * v_PageSize;
        uEnd = ((pWin->pPhys->uBase + uCardAddress + uSize + v_PageSize - 1) / v_PageSize) * v_PageSize;
        uVirtSize = uEnd - uStart;

        if (uEnd > ((pWin->pPhys->uBase + pWin->pPhys->uMaxSize + v_PageSize - 1) / v_PageSize) * v_PageSize) {
            status = CERR_BAD_SIZE;
            goto map_win_fail;
        }
    }

#ifndef SH4
    //
    // Change the data path width if necessary
    //
    if (((fAttributes & WIN_ATTR_16BIT) && (!(pWin->pPhys->fFlags & PHYS_WIN_FLAG_16BIT_MODE))) ||
        ((!(fAttributes & WIN_ATTR_16BIT)) && (pWin->pPhys->fFlags & PHYS_WIN_FLAG_16BIT_MODE))) {
        DEBUGMSG(ZONE_MEM, (TEXT("CardMapWindow changing window %d data size.\r\n"), pWin->pPhys->uWindow));
        //
        // Caller must be the only one using this physical window (besides card
        // services).
        //
        pTmp = pWin->pPhys->pLog;
        while (pTmp) {
            if ((pTmp->hOwner != CARDSERV_CLIENT_HANDLE) &&
                (pTmp->hOwner != pWin->hOwner)) {
                status = CERR_OUT_OF_RESOURCE;
                goto map_win_fail;
            }
            pTmp = pTmp->Next;
        }
        status = PDCardGetWindow(pWin->pPhys->uWindow, &WinState);
        if (status) {
            goto map_win_fail;
        }
        if (pWin->fAttributes & WIN_ATTR_16BIT) {
            WinState.fState |= WIN_STATE_16BIT;
            pWin->pPhys->fFlags |= PHYS_WIN_FLAG_16BIT_MODE;
        } else {
            WinState.fState &= ~WIN_STATE_16BIT;
            pWin->pPhys->fFlags &= ~PHYS_WIN_FLAG_16BIT_MODE;
        }
        WinState.fState |= WIN_STATE_ENABLED;
        pWin->pPhys->fFlags |= PHYS_WIN_FLAG_ENABLED;
        status = PDCardSetWindow(pWin->pPhys->uWindow, &WinState);
        if (status) {
            goto map_win_fail;
        }
    }
#endif  // ~SH4

#ifdef x86
    if (fAttributes & WIN_ATTR_IO_SPACE) {
        inIoSpace = 1;
        ioPhysicalBase.LowPart = pWin->pPhys->uBase+uCardAddress;
        ioPhysicalBase.HighPart = 0;

        if (HalTranslateBusAddress(
                 Isa,
                 0,
                 ioPhysicalBase,
                 &inIoSpace,
                 &ioPhysicalBase)) {
            DEBUGMSG(ZONE_MEM,
                (TEXT("CardMapWindow : HalTranslateBusAddress - OK\r\n")));
            if (!inIoSpace) {
            DEBUGMSG(ZONE_MEM, (TEXT("CardMapWindow : ! IO Space\r\n")));
                if ((RetVal = (PVOID)MmMapIoSpace(
                                         ioPhysicalBase,
                                         uSize,
                                         FALSE)) == NULL) {
                    DEBUGMSG(ZONE_MEM, (TEXT("Error mapping I/O Ports\r\n")));
                    status = CERR_OUT_OF_RESOURCE;
                    goto map_win_fail;
                }
            } else {
                DEBUGMSG(ZONE_MEM, (TEXT("CardMapWindow : IO Space\r\n")));
                RetVal = (PVOID)ioPhysicalBase.LowPart;
            }
            if (RetVal == NULL) {
                DEBUGMSG(ZONE_MEM, (TEXT("HalTranslateBusAddress returned NULL.\r\n")));
                status = CERR_BAD_BASE;
                goto map_win_fail;
            }
        } else {
            DEBUGMSG(ZONE_MEM, (TEXT("Error translating I/O Ports.\r\n")));
            status = CERR_OUT_OF_RESOURCE;
            goto map_win_fail;
        }
        pWin->pVirtMem = RetVal;
        goto map_win_exit;

    } else {
#endif // x86
        //
        // Allocate some virtual pages.
        //
        pWin->pVirtMem = VirtualAlloc(
                              0,
                              uVirtSize,
                              MEM_RESERVE,
                              PAGE_NOACCESS);
        if (pWin->pVirtMem == NULL) {
            DEBUGMSG(ZONE_WARNING,
                (TEXT("CardMapWindow: VirtualAlloc failed %d\r\n"),
                GetLastError()));
            status = CERR_OUT_OF_RESOURCE;
            goto map_win_fail;
        }

        //
        // Map the memory.
        //
#ifdef DEBUG
        if (pWin->pPhys->uBase & 0xE0000000) {
            DEBUGMSG(ZONE_WARNING|ZONE_ERROR|ZONE_MEM,
              (TEXT("PCMCIA:CardMapWindow MAKE SURE THIS PLATFORM'S PCMCIA MEMORY AREAS ARE SPECIFIED AS ACTUAL PHYSICAL ADDRESSES\r\n")));
        }
#endif
        uPhysAddr = uStart;
        uPhysAddr >>= 8;
		uPhysAddr |= 0x0f000000;	// workaround for Au1x00 36 bit physical address
        if (!VirtualCopy(
                pWin->pVirtMem,
                (PVOID)uPhysAddr,
                uVirtSize,
                PAGE_READWRITE|PAGE_NOCACHE|PAGE_PHYSICAL)) {
            DEBUGMSG(ZONE_WARNING,
                (TEXT("CardMapWindow:VirtualCopy failed %d\r\n"), GetLastError()));
            status = CERR_OUT_OF_RESOURCE;
            goto map_win_fail1;
        }

#ifdef SH4
 {
    //
    // On SH4 we need to set some extra page table bits associated with PCMCIA
    // (the SH4 PCMCIA controller is integrated with the CPU's paging mechanism)
    //
    DWORD dwPageFlags;

    if (fAttributes & WIN_ATTR_IO_SPACE) {
        dwPageFlags = VSPF_VARIABLE;
    } else {
        if (fAttributes & WIN_ATTR_ATTRIBUTE) {
            dwPageFlags = VSPF_ATTRIBUTE;
        } else {
            dwPageFlags = VSPF_COMMON;
        }
        if (fAttributes & WIN_ATTR_16BIT) {
            dwPageFlags |= VSPF_16BIT;
        }
    }
    pWin->fAttributes = fAttributes;
    dwPageFlags |=(isSh4Area6(pWin->pPhys->uWindow)?VSPF_TC:0);

    if (!VirtualSetPageFlags(
             pWin->pVirtMem,
             uVirtSize,
             dwPageFlags,
             NULL)) {
        DEBUGMSG(ZONE_WARNING,
            (TEXT("I_MapWindow: VirtualSetPageFlags failed %d\r\n"),
            GetLastError()));
        I_DeleteLogicalWindow(pWin);
        return NULL;
    }
 }
#endif

#ifdef x86
    }
#endif // x86

#ifdef INSTRUM_DEV
    ics_addCardRange(0, pWin->pVirtMem, (PVOID)(uStart), uVirtSize, 0);
#endif

    //
    // Return a pointer to the card offset the user specified
    //
    if (bSetSocket == TRUE) {
        RetVal = (PVOID)((UINT)pWin->pVirtMem + ((pWin->pPhys->uBase + uCardAddress - WinState.uOffset) % v_PageSize));
    } else {
        RetVal = (PVOID)((UINT)pWin->pVirtMem + ((pWin->pPhys->uBase + uCardAddress) % v_PageSize));
    }

#ifdef x86
map_win_exit:
#endif // x86

    pWin->uReqSize = uSize;
    pWin->uReqOffset = uCardAddress;

    DEBUGMSG(ZONE_WARNING|ZONE_MEM,
        (TEXT("CardMapWindow:Window %d @ %x (phys = %x), size = %d, returning %x\r\n"),
        pWin->pPhys->uWindow,
        pWin->pVirtMem,
        pWin->pPhys->uBase+uStart,
        uVirtSize,
        (UINT)RetVal));

    LeaveCriticalSection(&v_WindowCrit);
    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardMapWindow succeeded\r\n")));
    return RetVal;

    //
    // Some error occurred, set last error and return NULL.
    //
map_win_fail1:
    DEBUGMSG(ZONE_MEM,
        (TEXT("CardMapWindow calling VirtualFree(0x%x) for failed mapping.\r\n"),
        pWin->pVirtMem));
    if (VirtualFree(pWin->pVirtMem, 0, MEM_RELEASE) == FALSE) {
        DEBUGMSG(ZONE_MEM|ZONE_ERROR,
            (TEXT("CarpMapWindow: VirtualFree(old) failed %d\r\n"),
            GetLastError()));
    }
    pWin->pVirtMem = NULL;
map_win_fail:
    if ((pWin->pPhys->fWindowCaps & WIN_CAP_IO) &&
        g_IORM_ID[pWin->pPhys->uSock] != 0)
        ResourceRelease(g_IORM_ID[pWin->pPhys->uSock], uCardAddress, uSize);
map_win_fail_norel:
    LeaveCriticalSection(&v_WindowCrit);
    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardMapWindow failed %d\r\n"), status));
    SetLastError(status);
    return NULL;
}   // CardMapWindow



//
// @topic PCMCIA Memory access functions| Functions to read and write the different
// PC card memory spaces on platforms that do not support PCMCIA memory and I/O
// windows.  System software must assert the REG line as appropriate to access the
// specified memory space.  Access to the REG line must be controlled with a critical
// section in order to be thread-safe.  Otherwise PC card drivers could easily end
// up unintentionally accessing the wrong memory space.
// On platforms that have separate memory regions for the three PCMCIA memory spaces
// (common, attribute and I/O) or that use memory and I/O windows on the socket controller,
// the drivers can access PC card memory directly.
//
// @xref <f CardReadAttrByte> <f CardWriteAttrByte> <f CardReadCmnByte>
//


//
// CardReadAttrByte
//
// @func STATUS | CardReadAttrByte | Read the byte at the specified offset in a PC card's
//                                   attribute memory space.
// @rdesc   Returns either CERR_SUCCESS or CERR_READ_FAILURE.
//
// @comm    The uOffset for attribute space is the virtual offset into attribute
//          space.  uOffset of 0 represents the first byte in attribute space,
//          uOffset of 1 is the next valid byte (although on the perp it is actually
//          at offset 8).
//          Since the parameters are not range checked and since the PC card may
//          be removed at any time, this API should be called within a try/except
//          construct to avoid locking up the system.
//
STATUS
CardReadAttrByte(
    PVOID   pAttr,      // @parm Pointer to PC card memory from <f CardMapWindow>
    UINT32  uOffset,    // @parm Offset into PC card's attribute memory space
    UINT8 * pByte       // @parm Pointer to return the read byte.
    )
{
    STATUS ret = CERR_SUCCESS;

    try {
        *pByte = PDCardReadAttrByte(pAttr, uOffset);
    } except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        DEBUGMSG(ZONE_ERROR|ZONE_MEM,
            (TEXT("CardReadAttrByte: returning error due to exception\r\n")));
        ret = CERR_READ_FAILURE;
    }
    return ret;
}


//
// CardReadCmnByte
//
// @func STATUS | CardReadCmnByte | Read the byte at the specified offset in a PC card's
//                                   common memory space.
// @rdesc   Returns either CERR_SUCCESS or CERR_READ_FAILURE.
//
// @comm    Since the parameters are not range checked and since the PC card may
//          be removed at any time, this API should be called within a try/except
//          construct to avoid locking up the system.
//
STATUS
CardReadCmnByte(
    PVOID   pCmn,       // @parm Pointer to PC card memory from <f CardMapWindow>
    UINT32  uOffset,    // @parm Offset into PC card's common memory space
    UINT8 * pByte       // @parm Pointer to return the read byte.
    )
{
    STATUS ret = CERR_SUCCESS;

    try {
        *pByte = PDCardReadCmnByte(pCmn, uOffset);
    } except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        DEBUGMSG(ZONE_ERROR|ZONE_MEM,
            (TEXT("CardReadCmnByte: returning error due to exception\r\n")));
        ret = CERR_READ_FAILURE;
    }
    return ret;
}


//
// CardWriteAttrByte
//
// @func STATUS | CardWriteAttrByte | Write a byte at the specified offset in a PC card's
//                                    attribute memory space.
// @rdesc   Returns CERR_SUCCESS or CERR_WRITE_FAILURE.
//
// @comm    The uOffset for attribute space is the virtual offset into attribute
//          space.  uOffset of 0 represents the first byte in attribute space,
//          uOffset of 1 is the next valid byte (although on the perp it is actually
//          at offset 8).
//          Since the parameters are not range checked and since the PC card may
//          be removed at any time, this API should be called within a try/except
//          construct to avoid locking up the system.
//
STATUS
CardWriteAttrByte(
    PVOID   pAttr,      // @parm Pointer to PC card memory from <f CardMapWindow>
    UINT32  uOffset,    // @parm Offset into PC card's attribute memory space
    UINT8  uByte        // @parm Byte to write
    )
{
    STATUS ret = CERR_SUCCESS;

    try {
        PDCardWriteAttrByte(pAttr, uOffset, uByte);
    } except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        DEBUGMSG(ZONE_ERROR|ZONE_MEM,
            (TEXT("CardWriteAttrByte: returning error due to exception\r\n")));
        ret = CERR_WRITE_FAILURE;
    }
    return ret;
}

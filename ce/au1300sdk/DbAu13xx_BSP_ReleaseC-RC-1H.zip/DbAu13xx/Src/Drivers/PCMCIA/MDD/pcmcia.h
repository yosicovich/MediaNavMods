//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

    pcmcia.h

Abstract:

    This file implements the PCMCIA model device driver internal structures
    and definitions.  This is provided as a sample to platform writers and is
    expected to be able to be used without modification on most (if not
    all) hardware platforms.

Functions:


Notes:


--*/


#ifdef MEMTRACKING
#define DO_MEMTRACKING 1
#endif
#ifdef MYMEMTRACKING
#define DO_MEMTRACKING 1
#endif

#define MAX_SOCKETS 4
#define MAX_FUNCTIONS 8
#define DEVID_LEN   128
#define MAX_TUPLE_MISSES 500
#define BUFFER_SIZE 300   // used by tuple parsing code

#define alloc(x)    LocalAlloc(LPTR, x)
#define free(x)     LocalFree(x)

#define INITIAL_SOCKET_EVENTS (EVENT_MASK_CARD_DETECT|EVENT_MASK_CARD_LOCK)
#define DETECTED_SOCKET_EVENTS (EVENT_MASK_CARD_DETECT|  \
                                EVENT_MASK_CARD_LOCK|    \
                                EVENT_MASK_BATTERY_LOW|  \
                                EVENT_MASK_BATTERY_DEAD| \
                                EVENT_MASK_WRITE_PROTECT)

//
// PHYS_WINDOW.fFlags
//
#define PHYS_WIN_FLAG_16BIT_MODE   0x00000001  // window is in 16 bit mode
#define PHYS_WIN_FLAG_ATTR_MODE    0x00000002  // window is in attribute mode
#define PHYS_WIN_FLAG_ENABLED      0x00000004  // window is enabled

typedef struct _CLIENT_DRIVER *PCLIENT_DRIVER;

//
// Structure to track physical memory and I/O windows
//
typedef struct _PHYS_WINDOW {
    struct _PHYS_WINDOW * Next;
    struct _LOG_WINDOW * pLog;    // First logical window of physical window.
    UINT32   uWindow;             // Window number.
    UINT32   uBase;               // Base physical address
    UINT32   uMaxSize;            // Max size this window can address
    UINT16   fWindowCaps;         // from PDCARD_WINDOW_INFO.fWindowCaps
    UINT16   fOtherCaps;          // from PDCARD_WINDOW_INFO.fMemoryCaps or fIOCaps
    INT      fFlags;
    UINT8    uSock;               // Socket this window is mapped to.
    UINT32   uSize;               // Size of window
    UINT32   uOffset;             // offset of window
} PHYS_WINDOW, * PPHYS_WINDOW;


//
// Structure representing an allocation within a physical window
// CardRequestWindow returns a handle to a LOG_WINDOW.
//
typedef struct _LOG_WINDOW {      // Logical window.
    struct _LOG_WINDOW * Next;    // Next logical window of physical window.
    PPHYS_WINDOW pPhys;           // Associated physical window
    PCLIENT_DRIVER hOwner;        // NULL or handle of owning client driver
    PVOID    pVirtMem;            // Where in virtual memory it is.
    UINT     uReqSize;            // Requested size
    UINT     uReqOffset;          // Requested card offset
    UINT     fAttributes;         // Requested window attributes
#ifdef MYMEMTRACKING
    UINT     uVirtSize;           // Size of VirtualAlloc
#endif
} LOG_WINDOW, * PLOG_WINDOW;

//
// Interrupt object - used to allow multiple interrupt owners on one
// logical socket.
//
typedef struct _IREQ_OBJ {
    struct _IREQ_OBJ * Next;
    PCLIENT_DRIVER hOwner;
    CARD_ISR           ISRFn;
    UINT32             uISRContext;
} IREQ_OBJ, * PIREQ_OBJ;

//
// LOG_SOCKET.fFlags
//
#define OWNER_FLAG_EXCLUSIVE    	1
#define OWNER_FLAG_CONFIG       	2
#define OWNER_FLAG_INTERRUPT    	4
#define OWNER_FLAGS (OWNER_FLAG_EXCLUSIVE|OWNER_FLAG_CONFIG|OWNER_FLAG_INTERRUPT)
#define	LOG_SOCK_FLAG_NO_INTR_ACK	8
#define	LOG_SOCK_FLAG_NO_SUSPEND_UNLOAD 0x10
#define	LOG_SOCK_FLAG_KEEP_POWERED      0x20
#define	LOG_SOCK_FLAG_IRQ_WAKEUP        0x40

//
// A Socket/Function pair is a logical socket
//
typedef struct _LOG_SOCKET {
    struct _LOG_SOCKET * Next;   // Points to next function on this socket
    CARD_SOCKET_HANDLE   hSock;  // socket/function pair this struct represents
    PCLIENT_DRIVER       hOwner; // Handle of exclusive client driver
    HANDLE               hDriver; // Handle of loaded device driver (or NULL if none)
    DWORD                hQueryDriver; // Handle of QueryDriversThread
    PIREQ_OBJ            IREQList;  // list of interrupt owners.
    UINT                 fFlags;
    UINT16               fChangedEvents;
    UINT16               fPrevEvents;
    PLOG_WINDOW          hRegWin;   // Window for accessing config registers
    PVOID                pRegWin;   // Virtual address of config registers
    UINT                 uRegOffset;// Location of function config registers
    UINT8                fRegisters;// Bit mask of which FCR registers are present.

    UINT8 fControlCaps;         // @field Control capabilities
    UINT8 fInterfaceType;       // @field Memory-only or memory and I/O
    UINT8 fVcc;                 // @field Vcc power entry index and status
    UINT8 uVpp1;                // @field Vpp1 power entry index
    UINT8 uVpp2;                // @field Vpp2 power entry index

    UINT16               fCfgRegisters; // Bit mask of registers configured with CardRequestConfiguration
    UINT8                COR_val;   // Value to use in config option register.
    UINT8                FCSR_val;  // Value to use in function and config status register.
    UINT8                PRR_val;   // Value to use in pin replacement register
    UINT8                SCR_val;   // Value to use in socket and copy register
    UINT8                ESR_val;   // Value to use in extended status register
    UINT8                IOB_val[4]; // Value to use in I/O Base registers
    UINT8                IOL_val;   // Value to use in I/O Limit register
} LOG_SOCKET, *PLOG_SOCKET;


//
// PHYS_SOCKET.fFlags
//
#define PHYS_SOCK_FLAG_POWER_ON     0x01000000  // allow power to this socket even though using batteries
#define PHYS_SOCK_FLAG_FROM_STANDBY 0x02000000  // powering on from standby, so use previous value of the
                                                // PHYS_SOCK_FLAG_POWER_ON
#define PHYS_SOCK_FLAG_RESUMING     0x04000000  // processing a fake removal while powering on from stdby
#define PHYS_SOCK_FLAG_ACTIVE       0x08000000  // sockets is active - do not power off
#define PHYS_SOCK_FLAG_NOT_USER_ACCESS 0x10000000  // socket is non-user accessible
#define PHYS_SOCK_FLAG_RESETTING    0x20000000  // socket is being reset


//
// Structure to track a physical socket pairs
//
typedef struct _PHYS_SOCKET {
    LPTSTR       pDevId;    // PNP device id string + CRC
    PLOG_WINDOW  pAttrWin;  // Window for accessing CIS
    PLOG_WINDOW  pCmnWin;   // Window for accessing CIS in common memory
    UINT         fFlags;    // High byte defined above, cached socket options in lower 3 bytes.
                            // low byte is fControlCaps, next byte is fSocketCaps, next is fInterruptEvents
    PLOG_SOCKET  pLsock;    // List of logical sockets
    UINT         cFunctions;// number of functions on the inserted card.
    UINT         PowerState;// POWER_NORMAL, POWER_ON, POWER_OFF
    UINT         DetectState;//
    HANDLE       hLoad;     // Handle to a load thread or NULL
} PHYS_SOCKET, *PPHYS_SOCKET;


//
// Track client's per socket/function interest (mostly event masks)
//
typedef struct _CLIENT_SOCKET {
    struct _CLIENT_SOCKET * Next;
    PLOG_SOCKET  pLsock;
    UINT16       fEventMask;  // socket specific event mask
} CLIENT_SOCKET, *PCLIENT_SOCKET;


//
// Client device driver structure
//
typedef struct _CLIENT_DRIVER {
    LIST_ENTRY          List;
    CARD_CLIENT_HANDLE  hClient;
    CLIENT_CALLBACK     CallBackFn;
    CARD_REGISTER_PARMS Parms;
    PCLIENT_SOCKET      pCsock;         // List of socket/function pairs
    BOOL                fClosing;
} CLIENT_DRIVER, *PCLIENT_DRIVER;

#define CARDSERV_CLIENT_HANDLE ((PCLIENT_DRIVER)-1)

//
// Structure used to map callback events to eventmask bit and query flag.
//
typedef struct _EVENT_ATTRIBUTES {
    UINT16 EventCode;    // Actual event
    UINT16 EventMask;    // EventMask bit
} EVENT_ATTR, *PEVENT_ATTR;

//
// Define another eventmask bit for internal use to simplify processing
// (the other EVENT_MASK_* bits are defined in cardserv.h)
//
#define EVENT_MASK_EXCLUSIVE    0x8000


//
// Bit definitions of fFlags for tuple APIs (for internal use only)
//
#define TUPLE_FLAG_COMMON       0x0001    // Tuples are in common memory
#define TUPLE_FLAG_LINK_TO_A    0x0002    // Link to attribute memory
#define TUPLE_FLAG_LINK_TO_C    0x0004    // Link to common memory
#define TUPLE_FLAG_NO_LINK      0x0008
#define TUPLE_FLAG_IMPLIED_LINK 0x0010


//
//    Mode parameter for I_SetMemMode and I_TupleMemMode
//
#define USE_COMMON_MEM    FALSE
#define USE_ATTRIBUTE_MEM TRUE


//
// CALLBACK_STRUCT.fFlags
//
#define CALLBACK_FLAG_QUERY         1
#define CALLBACK_FLAG_LAST          2
#define CALLBACK_FLAG_ALL_FUNCTIONS 4

//
// Callback event structure
//
typedef struct _CALLBACK_STRUCT {
    struct _CALLBACK_STRUCT * Next;
    CARD_EVENT  MajorEvent;         // Major callback event code
    CARD_EVENT  SubEvent;           // Current event code in sequence
    CARD_CLIENT_HANDLE  pDestClient;// Client to be called back
    CARD_CLIENT_HANDLE  pReqClient; // Requesting client
    UINT            fFlags;
    CARD_SOCKET_HANDLE hSock;
} CALLBACK_STRUCT, *PCALLBACK_STRUCT;

//
// RemoveCallbacks event type
//
#define REMOVE_DEREGISTER 1
#define REMOVE_QUERY      2
#define REMOVE_PM_RESUME  3
#define REMOVE_INIT_MFC   4

//
// Callback events used internally to Card Services
//    (exported events are in ddk\inc\cardserv.h).
// Events are 32-bits wide but PCMCIA only uses 8-bit codes.
//
#define CE_CARDSERV_LOAD        0x10000
#define CE_CARDSERV_UNLOAD      0x10001  // unused; this is implied when the last REMOVAL notice is seen

//
// Power states
//
#define POWER_NORMAL 1
#define POWER_OFF    2
#define POWER_KEPT   3
#define POWER_ON     4
#define POWER_RESET  5

//
// Detect states
//
#define DETECT_NONE  0
#define DETECT_PROG  1
#define DETECT_REDO  2
#define DETECT_QUIT  3

typedef int (WINAPI *PFN_LoadStringW) (HINSTANCE hInstance, UINT uID, LPWSTR lpBuffer, int nBufferMax);
typedef int (WINAPI *PFN_MessageBoxW) (HWND hWnd , LPCWSTR lpText, LPCWSTR lpCaption, UINT uType);
typedef BOOL (WINAPI *PFN_GetSystemPowerStatusEx)(PSYSTEM_POWER_STATUS_EX pSystemPowerStatusEx, BOOL fUpdate);
typedef BOOL (WINAPI *PFN_PostThreadMessageW)(DWORD idThread, UINT Msg, WPARAM wParam, LPARAM lParam);


// These are declared in init.c and set up at Init time.
// Pointers may be null if functionality not present in the config
extern PFN_LoadStringW v_pfnLoadStringW;
extern PFN_MessageBoxW v_pfnMessageBoxW;
extern PFN_GetSystemPowerStatusEx v_pfnGetSystemPowerStatusEx;
extern PFN_PostThreadMessageW v_pfnPostThreadMessageW;


#ifdef DEBUG
//
// Debug zones
//
#define ZONE_ERROR      DEBUGZONE(0)
#define ZONE_WARNING    DEBUGZONE(1)
#define ZONE_FUNCTION   DEBUGZONE(2)
#define ZONE_CALLBACK   DEBUGZONE(3)
#define ZONE_STSCHG     DEBUGZONE(4)
#define ZONE_IREQ       DEBUGZONE(5)
#define ZONE_INIT       DEBUGZONE(6)
#define ZONE_MEM        DEBUGZONE(7)
#define ZONE_PDD        DEBUGZONE(8)
#define ZONE_POWER      DEBUGZONE(9)
#define ZONE_TUPLE      DEBUGZONE(10)

#endif  // DEBUG

//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

    callback.c

Abstract:

    This file implements the PCMCIA model device driver client callback
    functions.  This is provided as a sample to platform writers and is
    expected to be able to be used without modification on most (if not
    all) hardware platforms.

Functions:

    FindEventName()
    EnqueueEvent()
    DequeueEvent()
    ShouldCallback()
    CallbackOne()
    CallbackType()
    CallbackAll()
    CallbackSockets()
    CallClient()
    CallbackThread()

Notes:


--*/

#include <windows.h>
#include <types.h>
#include <excpt.h>
#include <cardserv.h>
#include <sockserv.h>
#include <linklist.h>
#include <pcmcia.h>
#include <extern.h>

UINT CallbackThread(UINT Nothing);

#ifdef DEBUG
//
// Debug data and function for callback thread
//
#define LAST_EVENT_CODE ((CARD_EVENT) -1)

typedef struct _EVENT_NAME_TBL {
    CARD_EVENT EventCode;
    LPTSTR    pEventName;
} EVENT_NAME_TBL, *PEVENT_NAME_TBL;

//
// Table of callback event codes and their names.
// NOTE: The names with ! at the end are not expected.
//
EVENT_NAME_TBL v_EventNames[] = {
    { CE_BATTERY_DEAD,          TEXT("CE_BATTERY_DEAD") },
    { CE_BATTERY_LOW,           TEXT("CE_BATTERY_LOW") },
    { CE_CARD_LOCK,             TEXT("CE_CARD_LOCK") },
    { CE_CARD_READY,            TEXT("CE_CARD_READY") },
    { CE_CARD_REMOVAL,          TEXT("CE_CARD_REMOVAL") },
    { CE_CARD_UNLOCK,           TEXT("CE_CARD_UNLOCK") },
    { CE_EJECTION_COMPLETE,     TEXT("CE_EJECTION_COMPLETE!") },
    { CE_EJECTION_REQUEST,      TEXT("CE_EJECTION_REQUEST!") },
    { CE_INSERTION_COMPLETE,    TEXT("CE_INSERTION_COMPLETE!") },
    { CE_INSERTION_REQUEST,     TEXT("CE_INSERTION_REQUEST!") },
    { CE_PM_RESUME,             TEXT("CE_PM_RESUME") },
    { CE_PM_SUSPEND,            TEXT("CE_PM_SUSPEND!") },
    { CE_EXCLUSIVE_COMPLETE,    TEXT("CE_EXCLUSIVE_COMPLETE") },
    { CE_EXCLUSIVE_REQUEST,     TEXT("CE_EXCLUSIVE_REQUEST") },
    { CE_RESET_PHYSICAL,        TEXT("CE_RESET_PHYSICAL") },
    { CE_RESET_REQUEST,         TEXT("CE_RESET_REQUEST") },
    { CE_CARD_RESET,            TEXT("CE_CARD_RESET") },
    { CE_MTD_REQUEST,           TEXT("CE_MTD_REQUEST!") },
    { CE_CLIENT_INFO,           TEXT("CE_CLIENT_INFO!") },
    { CE_TIMER_EXPIRED,         TEXT("CE_TIMER_EXPIRED!") },
    { CE_SS_UPDATED,            TEXT("CE_SS_UPDATED!") },
    { CE_WRITE_PROTECT,         TEXT("CE_WRITE_PROTECT") },
    { CE_CARD_INSERTION,        TEXT("CE_CARD_INSERTION") },
    { CE_RESET_COMPLETE,        TEXT("CE_RESET_COMPLETE") },
    { CE_ERASE_COMPLETE,        TEXT("CE_ERASE_COMPLETE!") },
    { CE_REGISTRATION_COMPLETE, TEXT("CE_REGISTRATION_COMPLETE") },
    { CE_STATUS_CHANGE_INTERRUPT, TEXT("CE_STATUS_CHANGE_INTERRUPT") },
    { CE_CARDSERV_LOAD,         TEXT("CE_CARDSERV_LOAD") },
    { CE_CARDSERV_UNLOAD,       TEXT("CE_CARDSERV_UNLOAD") },
    { LAST_EVENT_CODE,          TEXT("Unknown Event!") },
};

LPTSTR
FindEventName(
    CARD_EVENT EventCode
    )
{
    PEVENT_NAME_TBL pEvent = v_EventNames;

    while (pEvent->EventCode != LAST_EVENT_CODE) {
        if (pEvent->EventCode == EventCode) {
            return pEvent->pEventName;
        }
        pEvent++;
    }
    return pEvent->pEventName;
}

DWORD g_Reentry;  // used to debug CallbackThread
#endif // DEBUG

//
// StartCallbacks - function to invoke the CallbackThread
//
VOID StartCallbacks(VOID)
{
    DEBUGCHK(v_CallbackEvent != NULL);
    SetEvent(v_CallbackEvent);
}


//
// Put a CALLBACK_STRUCT at the end of the callback queue.
//
VOID
EnqueueEvent(
    PCALLBACK_STRUCT pEvent
    )
{
    EnterCriticalSection(&v_CallbackCrit);

    pEvent->Next = NULL;

    //
    // Link the event structure at the tail of the list
    //
    if (v_CallbackTail == NULL) {    // empty list?
        v_CallbackHead = pEvent;
        v_CallbackTail = pEvent;
    } else {
        v_CallbackTail->Next = pEvent;
        v_CallbackTail = pEvent;
    }
    DEBUGMSG(ZONE_CALLBACK,
        (TEXT("PCMCIA:Enqueued %s for client 0x%x, socket %d, function %d\r\n"),
        FindEventName(pEvent->MajorEvent), pEvent->pDestClient,
        pEvent->hSock.uSocket, pEvent->hSock.uFunction));

    EnterCriticalSection(&v_BatteryCrit);
    if (v_hBatteryThread[pEvent->hSock.uSocket] != 0) {
        if (v_hGwesEvent == NULL ||
            WaitForSingleObject(v_hGwesEvent, INFINITE) != WAIT_OBJECT_0 ||
            (NULL == v_pfnPostThreadMessageW) || !v_pfnPostThreadMessageW(
            v_hBatteryThread[pEvent->hSock.uSocket],
            WM_QUIT, 0, 0)) {
            DEBUGMSG(ZONE_WARNING|ZONE_CALLBACK|ZONE_INIT,
                (TEXT("PCMCIA:EnqueueEvent:PostThreadMessage Failed (%d)\r\n"),
                    GetLastError()));
        }
        v_fBattery[pEvent->hSock.uSocket] = FALSE;
        v_hBatteryThread[pEvent->hSock.uSocket] = 0;
    }
    LeaveCriticalSection(&v_BatteryCrit);

    LeaveCriticalSection(&v_CallbackCrit);
}   // EnqueueEvent


//
// Remove the first CALLBACK_STRUCT from the callback queue
//
PCALLBACK_STRUCT
DequeueEvent(VOID)
{
    PCALLBACK_STRUCT pEvent;
    DWORD dwStatus;

    // wait for an event to arrive
    do {
        EnterCriticalSection(&v_CallbackCrit);
        pEvent = v_CallbackHead;
        LeaveCriticalSection(&v_CallbackCrit);
        if(pEvent == NULL) {
            dwStatus = WaitForSingleObject(v_CallbackEvent, INFINITE);
            DEBUGCHK(dwStatus == WAIT_OBJECT_0);
            dwStatus = dwStatus;        // avoid compiler warning about unused variable
        }
    } while(pEvent == NULL);

    EnterCriticalSection(&v_CallbackCrit);

    pEvent = v_CallbackHead;
    if (pEvent) {
        v_CallbackHead = pEvent->Next;
        if (v_CallbackHead == NULL) {
            v_CallbackTail = NULL;
        }
        DEBUGMSG(ZONE_CALLBACK,
            (TEXT("PCMCIA:Dequeued %s for client 0x%x, socket %d, function %d\r\n"),
            FindEventName(pEvent->MajorEvent), pEvent->pDestClient,
            pEvent->hSock.uSocket, pEvent->hSock.uFunction));
    }
#ifdef DEBUG
    if (v_CallbackHead == NULL) {
       if (v_CallbackTail != NULL) {
            DEBUGMSG(1|ZONE_ERROR|ZONE_CALLBACK,
                (TEXT("PCMCIA:v_CallbackHead=0 but v_CallbackTail = 0x%x\r\n"),
                v_CallbackTail));
       }
    }
    if (v_CallbackTail == NULL) {
       if (v_CallbackHead != NULL) {
            DEBUGMSG(1|ZONE_ERROR|ZONE_CALLBACK,
                (TEXT("PCMCIA:v_CallbackTail=0 but v_CallbackHead = 0x%x\r\n"),
                v_CallbackHead));
       }
    }
#endif

    LeaveCriticalSection(&v_CallbackCrit);

    return pEvent;
}   // DequeueEvent


//
// Check if the specified client wants this type of event.
//
// Return: TRUE  => client wants this callback
//         FALSE => don't callback client for this event
BOOL
ShouldCallback(
    PCLIENT_DRIVER pClient,
    CARD_EVENT MajorEvent,
    CARD_EVENT EventCode,
    CARD_SOCKET_HANDLE hSock
    )
{
    UINT    EventMask;
    PEVENT_ATTR pAttr;
    PCLIENT_SOCKET pCsock;
    PCALLBACK_STRUCT pEvent;

    if (pClient == NULL) {
        // This is an internal operation and does not generate a true callback.
        return TRUE;
    }

    if (pClient->CallBackFn == NULL) {
        return FALSE;
    }

    pAttr = (PEVENT_ATTR)v_EventMap;
    EventMask = (UINT) -1;    // Default is that he gets it.

    //
    // Find the EventMask associated with this EventCode
    //
    while (pAttr->EventCode != (UINT16)-1) {
        if (pAttr->EventCode == EventCode) {
            EventMask = pAttr->EventMask;
            break;
        }
        pAttr++;
    }

    //
    // Check the socket specific eventmask
    //
    if ((pCsock = I_FindClientSocket(hSock, pClient)) != NULL) {

        //
        // Check the socket event mask - if we're dealing with a CE_PM_RESUME
        // (global event) try the global event mask as well
        //
        if (!(pCsock->fEventMask & EventMask) && EventCode != CE_PM_RESUME) {
            DEBUGMSG(ZONE_CALLBACK,
                (TEXT("PCMCIA:ShouldCallback - Client 0x%x doesn't want a %s event\r\n"),
                pClient->hClient, FindEventName(EventCode)));
            return FALSE;
        }
    }

    //
    // Check the global event mask
    //
    if (!(pClient->Parms.fEventMask & EventMask)) {
        DEBUGMSG(ZONE_CALLBACK,
            (TEXT("PCMCIA:ShouldCallback - Client 0x%x doesn't want a %s event\r\n"),
            pClient->hClient, FindEventName(EventCode)));
        return FALSE;
    }

    //
    // There should be at most only one CE_PM_RESUME per client.
    //
    EnterCriticalSection(&v_CallbackCrit);
    pEvent = v_CallbackHead;
    while (pEvent) {
        if ((EventCode == CE_PM_RESUME) &&
            (pEvent->MajorEvent == CE_PM_RESUME) &&
            (pEvent->pDestClient == pClient->hClient)) {
            LeaveCriticalSection(&v_CallbackCrit);
            DEBUGMSG(ZONE_CALLBACK,
              (TEXT("PCMCIA:ShouldCallback - Client already getting CE_PM_RESUME\r\n")));
            return FALSE;
        } else if ((pEvent->MajorEvent      == MajorEvent) &&
                   (pEvent->SubEvent        == EventCode) &&
                   (pEvent->hSock.uSocket   == hSock.uSocket) &&
                   (pEvent->hSock.uFunction == hSock.uFunction) &&
                   (pEvent->pReqClient      == ((pClient == NULL) ? NULL : pClient->hClient)) &&
                   (pEvent->pDestClient     == ((pClient == NULL) ? NULL : pClient->hClient))) {
            LeaveCriticalSection(&v_CallbackCrit);
            DEBUGMSG(ZONE_CALLBACK,
              (TEXT("PCMCIA:ShouldCallback - Stopped duplicate %s\r\n"),
              FindEventName(EventCode)));
            return FALSE;
        }
        pEvent = pEvent->Next;
    }
    LeaveCriticalSection(&v_CallbackCrit);

    return TRUE;
}   // ShouldCallback


//
// Allocate and queue a CALLBACK_STRUCT for the specified client.
//
PCALLBACK_STRUCT
CallbackOne(
    CARD_EVENT MajorEvent,
    CARD_EVENT SubEvent,
    PCLIENT_DRIVER pReqClient,
    CARD_SOCKET_HANDLE hSock
    )
{
    PCALLBACK_STRUCT pEvent;

    if (!ShouldCallback(pReqClient, MajorEvent, SubEvent, hSock)) {
        return NULL;
    }

    pEvent = alloc(sizeof(CALLBACK_STRUCT));
    if (pEvent) {
        pEvent->MajorEvent = MajorEvent;
        pEvent->SubEvent = SubEvent;
        pEvent->pDestClient = (pReqClient == NULL) ? NULL : pReqClient->hClient;
        pEvent->pReqClient = (pReqClient == NULL) ? NULL : pReqClient->hClient;
        pEvent->hSock = hSock;
        pEvent->fFlags = CALLBACK_FLAG_LAST;
        EnqueueEvent(pEvent);
        StartCallbacks();
        return pEvent;
    }
    return NULL;
}   // CallbackOne


//
// Callback all clients of the specified type.
//
// NOTE: The caller of this function must own v_CallbackCrit
//
PCALLBACK_STRUCT
CallbackType(
    CARD_EVENT MajorEvent,
    CARD_EVENT SubEvent,
    PCLIENT_DRIVER pReqClient,
    CARD_SOCKET_HANDLE hSock,
    UINT fFlags,
    UINT DriverType
    )
{
    PCLIENT_DRIVER pClient;
    PCALLBACK_STRUCT pLast;
    PCALLBACK_STRUCT pEvent;
    UINT8 StartFunction, EndFunction;

    pLast = NULL;

    //
    // Check if a notification is needed for all functions
    //
    if (fFlags & CALLBACK_FLAG_ALL_FUNCTIONS) {
        StartFunction = 0;
        EndFunction = v_Sockets[hSock.uSocket].cFunctions;
        //
        // If the user had previously disabled the PC card, we still want a
        // CE_CARD_REMOVAL message after standby.  This check covers that case.
        //
        if (EndFunction == 0) {
            EndFunction = 1;
        }
    } else {
        StartFunction = hSock.uFunction;
        EndFunction = hSock.uFunction + 1;
    }

    //
    // Callback all clients of the specified type.
    //
    EnterCriticalSection(&v_ClientCrit);
    pClient = (PCLIENT_DRIVER)v_ClientList.Flink;
    while (pClient != (PCLIENT_DRIVER)&v_ClientList) {
        if (pClient->Parms.fAttributes & DriverType) {
            for (hSock.uFunction = StartFunction;
                 hSock.uFunction < EndFunction;
                 hSock.uFunction++) {
                if (ShouldCallback(pClient, MajorEvent, SubEvent, hSock)) {
                    pEvent = alloc(sizeof(CALLBACK_STRUCT));
                    if (pEvent) {
                        pEvent->MajorEvent  = MajorEvent;
                        pEvent->SubEvent    = SubEvent;
                        pEvent->pReqClient  = (pReqClient == NULL) ? NULL : pReqClient->hClient;
                        pEvent->pDestClient = (pClient == NULL) ? NULL : pClient->hClient;
                        pEvent->hSock      = hSock;
                        pEvent->fFlags      = fFlags;
                        EnqueueEvent(pEvent);
                        pLast = pEvent;
                    }
                }
            }
        }
        pClient = (PCLIENT_DRIVER)pClient->List.Flink;
    }
    LeaveCriticalSection(&v_ClientCrit);
    return pLast;
}   // CallbackType


//
// Broadcast a card event message to all registered clients in the order
// specified by the PCMCIA standard.
//
STATUS
CallbackAll(
    CARD_EVENT MajorEvent,
    CARD_EVENT SubEvent,
    PCLIENT_DRIVER pReqClient,
    CARD_SOCKET_HANDLE hSock,
    UINT fFlags
    )
{
    UINT fDriverType;
    PCALLBACK_STRUCT pLast;
    PCALLBACK_STRUCT pCurr;

    pLast = NULL;

    //
    // The following for loop relies on the fact that CLIENT_ATTR_IO_DRIVER,
    // CLIENT_ATTR_MTD_DRIVER and CLIENT_ATTR_MEM_DRIVER are one right shift
    // different from each other.  This conveniently results in the PCMCIA
    // specified client type order for callbacks.
    //
    // NOTE: I/O driver clients were linked in reverse order by
    // CardRegisterClient
    //
    EnterCriticalSection(&v_CallbackCrit);
    for (fDriverType = CLIENT_ATTR_IO_DRIVER; fDriverType; fDriverType >>= 1) {
        if (pCurr = CallbackType(
                        MajorEvent,
                        SubEvent,
                        pReqClient,
                        hSock,
                        fFlags,
                        fDriverType)) {
            pLast = pCurr;
        }
    }
    if (pLast) {
        pLast->fFlags |= CALLBACK_FLAG_LAST;
    }
    LeaveCriticalSection(&v_CallbackCrit);
    if (pLast) {
        StartCallbacks();
    }
    return CERR_SUCCESS;
}   // CallbackAll


//
// Perform an insertion callback to a newly registered client
// for all sockets in the system.
//
STATUS
CallbackSockets(
    PCLIENT_DRIVER pClient
    )
{
    PLOG_SOCKET pLsock;
    PCALLBACK_STRUCT pEvent;
    PCALLBACK_STRUCT pLast;
    CARD_SOCKET_HANDLE hSock;
    int i;

    if (pClient->CallBackFn == NULL) {
        return CERR_SUCCESS;
    }

    pLast = NULL;

    //
    // If both of these options are clear, then don't send any callbacks.
    //
    if ((pClient->Parms.fAttributes &
        (CLIENT_ATTR_NOTIFY_SHARED|CLIENT_ATTR_NOTIFY_EXCLUSIVE)) == 0) {
        goto cbs_complete;
    }

    EnterCriticalSection(&v_CallbackCrit);
    //
    // See if this client wants any callbacks.  If so, then he gets a
    // CE_CARD_INSERTION for every socket/function available and then a
    // CE_REGISTRATION_COMPLETE.
    //
    EnterCriticalSection(&v_SocketCrit);
    for (i = 0; i < v_cSockets; i++) {
        if (IsCardInserted(i)) {
            for (pLsock = v_Sockets[i].pLsock; pLsock; pLsock = pLsock->Next) {
                pEvent = alloc(sizeof(CALLBACK_STRUCT));
                if (pEvent) {
                    pEvent->MajorEvent  = CE_REGISTRATION_COMPLETE;
                    pEvent->SubEvent    = CE_CARD_INSERTION;
                    pEvent->pDestClient = (pClient == NULL) ? NULL : pClient->hClient;
                    pEvent->pReqClient  = (pClient == NULL) ? NULL : pClient->hClient;
                    pEvent->hSock      = pLsock->hSock;
                    pEvent->fFlags      = 0;
                    EnqueueEvent(pEvent);
                    pLast = pEvent;
                }
            }
        }
    }
    LeaveCriticalSection(&v_SocketCrit);

    if (pLast) {
        pLast->fFlags |= CALLBACK_FLAG_LAST;
    }
    LeaveCriticalSection(&v_CallbackCrit);
    if (pLast) {
        StartCallbacks();
    }

cbs_complete:
    if (pLast == NULL) {
        hSock.uSocket = 0;
        hSock.uFunction = 0;
        //
        // If no insertion callbacks were made, then send CE_REGISTRATION_COMPLETE
        // otherwise CallbackThread will send a CE_REGISTRATION_COMPLETE after
        // the last CE_CARD_INSERTION message.
        //
        CallbackOne(
            CE_REGISTRATION_COMPLETE,
            CE_REGISTRATION_COMPLETE,
            pClient,
            hSock);
    }

    return CERR_SUCCESS;
}   // CallbackSockets


//
// Call client driver's status callback function in a protected manner.
//
// Returns the return code from the client driver.
// If an exception is taken, then CERR_SUCCESS is returned.
//
STATUS
CallClient(
    CLIENT_CALLBACK CallBackFn,
    CARD_EVENT Event,
    CARD_SOCKET_HANDLE hSock,
    PCARD_EVENT_PARMS pParms,
    PCLIENT_DRIVER pClient
    )
{
    STATUS status;

    DEBUGMSG(ZONE_CALLBACK, (TEXT("PCMCIA:CallClient entered\r\n")));

    status = CERR_SUCCESS;
    try {
        if (CallBackFn != NULL) {
            status = (CallBackFn)(Event, hSock, pParms);
        } else {
            DEBUGMSG(ZONE_CALLBACK, (TEXT("PCMCIA:CallClient - CallBackFn == NULL\r\n")));
        }
    } except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        DEBUGMSG(ZONE_CALLBACK|ZONE_WARNING,
            (TEXT("PCMCIA:CallClient: Client's callback hit an exception!\r\n")));
        if (IsValidClient(pClient))
            CardDeregisterClient(pClient->hClient);
    }
    DEBUGMSG(ZONE_CALLBACK, (TEXT("PCMCIA:CallClient done\r\n")));
    return status;
}   // CallClient

//
// Function to figure out whether to send a CE_PM_RESUME and send it when
// appropriate
//
void
CallbackPmResume(void)
{
    BOOL bPmResume;
    UINT uSocket;
    CARD_SOCKET_HANDLE hSock;

    bPmResume = TRUE;
    for (uSocket = 0; uSocket < (UINT8)v_cSockets; uSocket++) {
        if ((v_Sockets[uSocket].PowerState != POWER_ON) ||
            (v_Sockets[uSocket].fFlags & PHYS_SOCK_FLAG_RESUMING)) {
            bPmResume = FALSE;
            break;
        }
    }

    if (bPmResume) {
    //
    // At this point all the insertion notices have been queued for any
    // cards that were in the device after a resume. Now indicate a
    // CE_PM_RESUME which device.exe will use as a signal to notify the
    // filesystem that it's safe to do pc card I/O.
    //
        DEBUGMSG(ZONE_POWER, (TEXT("PCMCIA:CallbackPmResume sending CE_PM_RESUME\r\n")));
        hSock.uSocket = 0;
        hSock.uFunction = 0;
        CallbackAll(
            CE_PM_RESUME,
            CE_PM_RESUME,
            NULL,
            hSock,
            0);
    }
}   // CallbackPmResume


//
// CheckForUnload - look for a CE_CARDSERV_UNLOAD on socket
//

BOOL
CheckForUnload(
    UINT8 uSocket
    )
{
    BOOL bRet = FALSE;
    PCALLBACK_STRUCT pEvent, pPrev;

    EnterCriticalSection(&v_CallbackCrit);
    pPrev = NULL;
    for (pEvent = v_CallbackHead; pEvent != NULL; pEvent = pEvent->Next) {
        if (pEvent->MajorEvent == CE_CARDSERV_UNLOAD &&
            pEvent->hSock.uSocket == uSocket) {

            DEBUGMSG(ZONE_CALLBACK, (TEXT("CE_CARDSERV_LOAD/CE_CARDSERV_UNLOAD found on socket %d\r\n"), uSocket));

            // Dequeue and discard the CE_CARDSERV_UNLOAD
            if (pPrev != NULL) {
                pPrev->Next = pEvent->Next;
            } else {
                v_CallbackHead = pEvent->Next;
            }
            if (v_CallbackTail == pEvent) {
                v_CallbackTail = pPrev;
            }

            free(pEvent);

            // Signal that unload was found, so that CE_CARDSERV_LOAD can be aborted
            bRet = TRUE;
            break;
        }
        pPrev = pEvent;
    }
    LeaveCriticalSection(&v_CallbackCrit);

    return bRet;
}


//
// Callback Thread - pull CALLBACK_STRUCTs off the callback queue and callback
// the specified client.  Perform any special processing for multi-stage
// callback sequences.
//
UINT
CallbackThread(
    UINT Nothing
    )
{
    STATUS status;
    CARD_EVENT_PARMS Parms;
    PCALLBACK_STRUCT pEvent;
    BOOL fCallAll, bUnloadDriver;
    CARD_EVENT NextEvent;
    PDCARD_SOCKET_STATE State;
    PCLIENT_DRIVER pClient;
    PLOG_SOCKET pLsock;
    UINT i;

    
#ifdef DEBUG
    LPTSTR MajorName;
    LPTSTR SubName;
#endif

    DEBUGMSG(ZONE_CALLBACK,
        (TEXT("PCMCIA:CallbackThread: entered %d\r\n"), ++g_Reentry));

    while ((pEvent = DequeueEvent()) != NULL) {
        // Handle special operations (these don't involve real callbacks
        // but they need to be serialized on the callback thread).
        switch (pEvent->MajorEvent) {
            case CE_CARDSERV_LOAD:
                if (!(v_Sockets[pEvent->hSock.uSocket].fFlags & PHYS_SOCK_FLAG_RESETTING)) {
                    if (!CheckForUnload(pEvent->hSock.uSocket)) {
                        // allow PCMCIA CD signals to settle (and user time to fully insert card)
                        Sleep(750);
                        if (!CheckForUnload(pEvent->hSock.uSocket)) {
                            CardServLoadDriver(pEvent->hSock.uSocket);
                        }
                    }
                } else {
                    // Since CardServLoadDriver will not be doing insertion callbacks, do them here.
                    CallbackAll(CE_CARD_INSERTION, CE_CARD_INSERTION, NULL, pEvent->hSock, CALLBACK_FLAG_ALL_FUNCTIONS);
                }
                v_Sockets[pEvent->hSock.uSocket].fFlags &= ~PHYS_SOCK_FLAG_RESETTING;
                goto cbt_next1;
            case CE_CARDSERV_UNLOAD:
                bUnloadDriver = ((v_Sockets[pEvent->hSock.uSocket].pLsock == NULL) ||
                                 !(v_Sockets[pEvent->hSock.uSocket].fFlags & PHYS_SOCK_FLAG_RESUMING));

                // Check if all functions do not want to be unloaded
                if (!bUnloadDriver) {
                    for (pLsock = v_Sockets[pEvent->hSock.uSocket].pLsock; pLsock != NULL; pLsock = pLsock->Next) {
                        if (!(pLsock->fFlags & LOG_SOCK_FLAG_NO_SUSPEND_UNLOAD)) {
                            bUnloadDriver = TRUE;
                            break;
                        }
                   }
                }
#if 0
                // Check the PnP ID to determine if it's the same card
                // ...assuming that it is the same card, since either card is non-user accessible
                // or should have been woken on removal
                if (!bUnloadDriver) {
                    LPTSTR pch;

                    pch = v_Sockets[pEvent->hSock.uSocket].pDevId;
                    if (CreateDeviceID(pEvent->hSock.uSocket, FALSE) != CERR_SUCCESS) {
                        bUnloadDriver = TRUE;
                    } else {
                        bUnloadDriver = _tcscmp(v_Sockets[pEvent->hSock.uSocket].pDevId, pch);
                    }

                    if (v_Sockets[pEvent->hSock.uSocket].pDevId != NULL)
                        free(v_Sockets[pEvent->hSock.uSocket].pDevId);
                    v_Sockets[pEvent->hSock.uSocket].pDevId = pch;
                }
#endif

                // Reconfigure the sockets
                if (!bUnloadDriver) {
                    v_Sockets[pEvent->hSock.uSocket].PowerState = POWER_RESET;
                    v_Sockets[pEvent->hSock.uSocket].fFlags |= PHYS_SOCK_FLAG_RESETTING;
                    Sleep(750);   // sleep required
                    for (pLsock = v_Sockets[pEvent->hSock.uSocket].pLsock; pLsock != NULL; pLsock = pLsock->Next) {
                        if (ConfigureLogSock(pLsock) != CERR_SUCCESS) {
                            bUnloadDriver = TRUE;
                            PcmciaPowerOff(
                                pEvent->hSock.uSocket,
                                TRUE,
                                (CARD_CLIENT_HANDLE)CARDSERV_CLIENT_HANDLE);
                            break;
                        }
                    }
                }

                if (bUnloadDriver) {
                    v_Sockets[pEvent->hSock.uSocket].fFlags &= ~PHYS_SOCK_FLAG_RESETTING;
                    CardServFreeDriver(pEvent->hSock.uSocket);
                    DeleteFunctions(pEvent->hSock.uSocket);
                    PDCardGetSocket(pEvent->hSock.uSocket, &State);
                    State.fInterruptEvents = INITIAL_SOCKET_EVENTS;
                    PDCardSetSocket(pEvent->hSock.uSocket, &State);
                    //
                    // If this removal notice was due to a power on/off event,
                    // then change to the ON power state and signal the
                    // StatusChangeThread again causing insertion notices to
                    // be sent for any inserted cards.
                    //
                }

                if (v_Sockets[pEvent->hSock.uSocket].PowerState == POWER_OFF ||
                    v_Sockets[pEvent->hSock.uSocket].PowerState == POWER_KEPT) {
                    if (!(v_Sockets[pEvent->hSock.uSocket].fFlags & PHYS_SOCK_FLAG_RESETTING))
                        v_Sockets[pEvent->hSock.uSocket].PowerState = POWER_ON;
                    DEBUGMSG(ZONE_STSCHG,
                        (TEXT("PCMCIA:CE_CARD_REMOVAL signal StatusChangeThread PowerState for Socket %d changed to %x\r\n"),pEvent->hSock.uSocket,v_Sockets[pEvent->hSock.uSocket].PowerState));
                    // Signal IREQThread, so that interrupts can continue
                    // (Interrupts may have been disabled while PowerState was POWER_OFF)
                    SetEvent(v_StatusChangeEvent);
                    SetEvent(v_IREQEvent);
                } else if (v_Sockets[pEvent->hSock.uSocket].PowerState == POWER_RESET) {
                    v_Sockets[pEvent->hSock.uSocket].PowerState = POWER_ON;
                    DEBUGMSG(ZONE_STSCHG,
                        (TEXT("PCMCIA:CE_CARD_REMOVAL signal StatusChangeThread PowerState for Socket %d changed to %x\r\n"),pEvent->hSock.uSocket,v_Sockets[pEvent->hSock.uSocket].PowerState));
                    // Signal IREQThread, so that interrupts can continue
                    // (Interrupts may have been disabled while PowerState was POWER_OFF)
                    SetEvent(v_StatusChangeEvent);
                    SetEvent(v_IREQEvent);
                } else {
                    PcmciaPowerOff(
                        pEvent->hSock.uSocket,
                        TRUE,
                        (CARD_CLIENT_HANDLE)CARDSERV_CLIENT_HANDLE);
                }

                CallbackPmResume();
                goto cbt_next1;
        }
        
        if (!(pClient = FindClient(pEvent->pDestClient, TRUE, FALSE))) {
            DEBUGMSG(ZONE_CALLBACK|ZONE_WARNING,
                (TEXT("PCMCIA:CallbackThread: Invalid destination client!\r\n")));

            //
            // If this is the last event in a sequence, then there may be
            // more processing to do.
            //
            if (pEvent->fFlags & CALLBACK_FLAG_LAST) {
                goto cbt_process_last;
            } else {
                goto cbt_next1;
            }
        }

        Parms.uClientData = pClient->Parms.uClientData; // supply context

        //
        // Fill in parameters based on event code
        //
        switch (pEvent->SubEvent) {
        case CE_CARD_INSERTION:
            // If device ID is NULL, the card's been pulled.
            // Skip the callback, and do the insertion cleanup
            if (v_Sockets[pEvent->hSock.uSocket].pDevId == NULL) {
                goto cbt_end_insert;
            }

            Parms.Parm1 = (UINT)v_Sockets[pEvent->hSock.uSocket].pDevId;
            Parms.Parm2 = (UINT)pClient->hClient;
            break;

        case CE_REGISTRATION_COMPLETE:
            Parms.Parm1 = (UINT)pClient->hClient;
            Parms.Parm2 = 0;
            break;

        case CE_PM_RESUME:
            for (i = 0; i < (UINT8)v_cSockets; i++) {
                DEBUGMSG(ZONE_CALLBACK,
                         (TEXT("CE_PM_RESUME Socket %d PowerState = %x fFlags = %x\r\n"),i,v_Sockets[i].PowerState,v_Sockets[i].fFlags));
                v_Sockets[i].PowerState = POWER_NORMAL;
                v_Sockets[i].fFlags &= ~PHYS_SOCK_FLAG_FROM_STANDBY;
            }
            break;

        default:
            Parms.Parm1 = 0;
            Parms.Parm2 = 0;
            break;
        }

#ifdef DEBUG
MajorName = FindEventName(pEvent->MajorEvent);
SubName   = FindEventName(pEvent->SubEvent);
DEBUGMSG(ZONE_CALLBACK,
    (TEXT("PCMCIA:CallbackThread: %d:%d MajorEvent=%s, SubEvent=%s\r\n"),
     pEvent->hSock.uSocket, pEvent->hSock.uFunction, MajorName, SubName));

#endif // DEBUG

        //
        // Callback the client
        //
        status = CallClient(
                    pClient->CallBackFn,
                    pEvent->SubEvent,
                    pEvent->hSock,
                    &Parms,
                    pClient);

cbt_fail_query:
        if ((status) && (pEvent->fFlags & CALLBACK_FLAG_QUERY)) {
            //
            // One of the client drivers rejected a query request.  Remove
            // all events associated with the failing one.
            // If this is the last one in the current stage, then there is
            // nothing to clean up.
            //
            if (!(pEvent->fFlags & CALLBACK_FLAG_LAST)) {
                RemoveCallbacks(
                   FindClient(pEvent->pReqClient, TRUE, TRUE),
                   pEvent->hSock,
                   pEvent->MajorEvent,
                   REMOVE_QUERY);
            }

            //
            // Report to the requesting client that the request was denied
            //
            switch (pEvent->MajorEvent) {
            case CE_EXCLUSIVE_REQUEST:
                    NextEvent = CE_EXCLUSIVE_COMPLETE;
                    break;
/* These events are not implemented yet
            case CE_EJECTION_REQUEST:
                    NextEvent = CE_EJECTION_COMPLETE;
                    break;
            case CE_INSERTION_REQUEST:
                    NextEvent = CE_INSERTION_COMPLETE;
                    break;
*/
            default:
                    NextEvent = 0;
                    break;
            }

            if (NextEvent) {
                Parms.uClientData = FindClient(pEvent->pReqClient, TRUE, TRUE)->Parms.uClientData; // supply context
                Parms.Parm1 = status;
                CallClient(
                    FindClient(pEvent->pReqClient, TRUE, TRUE)->CallBackFn,
                    NextEvent,
                    pEvent->hSock,
                    &Parms,
                    FindClient(pEvent->pReqClient, TRUE, TRUE));
            }

            // end of callback request failure case
        } else {
            //
            // If this is the last event in the current stage then figure
            // out what to do next.
            //
            if (pEvent->fFlags & CALLBACK_FLAG_LAST) {
cbt_process_last:
                NextEvent = 0;      // assume nothing to do next
                fCallAll = FALSE;   // assume only one client

                switch (pEvent->MajorEvent) {

                //
                // Finish CardRegisterClient callback sequence
                //
                case CE_REGISTRATION_COMPLETE:
                    if (pEvent->SubEvent == CE_CARD_INSERTION) {
                        NextEvent = CE_REGISTRATION_COMPLETE;
                        //
                        // Shut down power to the PCMCIA interfaces if they
                        // are not in use.
                        //
                        for (i = 0; i < (UINT)v_cSockets; i++) {
                            PcmciaPowerOff(
                                i,
                                FALSE,
                                (CARD_CLIENT_HANDLE)CARDSERV_CLIENT_HANDLE);
                        }
                    }
                    break;

                //
                // Figure out the next stage of the callback sequence for
                // CardRequestExclusive
                //
                case CE_EXCLUSIVE_REQUEST:
                    switch (pEvent->SubEvent) {
                    //
                    // If all clients approved, then tell them the socket
                    // is going away and tell the requesting client that it
                    // is available.
                    //
                    case CE_EXCLUSIVE_REQUEST:
                        NextEvent = CE_CARD_REMOVAL;
                        fCallAll = TRUE;
                        break;

                    case CE_CARD_REMOVAL:
                        NextEvent = CE_CARD_INSERTION;
                        break;

                    case CE_CARD_INSERTION:
                        //
                        // Requesting client is now exclusive owner
                        //
                        pLsock = I_FindSocket(pEvent->hSock);
                        if (pLsock) {
                            //
                            // If the previous owner did not release the socket
                            // then the requesting client can't get it.
                            //
                            if (pLsock->hOwner != 0) {
                                status = CERR_IN_USE;
                                goto cbt_fail_query;
                            }
                            pLsock->fFlags |= OWNER_FLAG_EXCLUSIVE;
                            pLsock->hOwner = FindClient(pEvent->pReqClient, TRUE, TRUE);
                        }
                        NextEvent = CE_EXCLUSIVE_COMPLETE;
                        break;
                    }
                    break;

                //
                // Finish CardReleaseExclusive callback sequence
                //
                case CE_EXCLUSIVE_COMPLETE:
                    switch (pEvent->SubEvent) {
                    case CE_CARD_REMOVAL:
                        //
                        // Avoid giving invalid insertion notices
                        //
                        if (IsCardInserted(pEvent->hSock.uSocket)) {
                            NextEvent = CE_CARD_INSERTION;
                            fCallAll = TRUE;
                        }
                        break;
                    }
                    break;

                //
                // Real card insertion event
                //
cbt_end_insert:
                case CE_CARD_INSERTION:
                    pLsock = I_FindSocket(pEvent->hSock);
                    if (pLsock) {
                        if (!(pLsock->fFlags & OWNER_FLAG_INTERRUPT)) {
                            PDCardGetSocket(pEvent->hSock.uSocket, &State);
                            State.fInterruptEvents = DETECTED_SOCKET_EVENTS;
                            PDCardSetSocket(pEvent->hSock.uSocket, &State);
                        }
                        //
                        // If no clients are using this card, shut down power to
                        // the PCMCIA adapter, until a configuration is requested.
                        //
                        PcmciaPowerOff(
                            pEvent->hSock.uSocket,
                            FALSE,
                            (CARD_CLIENT_HANDLE)CARDSERV_CLIENT_HANDLE);

                        // This completes the off/on processing window.
                        v_Sockets[pEvent->hSock.uSocket].fFlags &= ~PHYS_SOCK_FLAG_RESUMING;
                    }
                    CallbackPmResume();
                    break;

                //
                // Real card removal event
                //
                case CE_CARD_REMOVAL:
                    //
                    // Deleting the LOG_SOCKETs had to be delayed to here
                    // so clients can release resources associated with
                    // this socket
                    //
                    DEBUGMSG(ZONE_STSCHG,
                        (TEXT("PCMCIA:CallbackThread processing last removal for Socket %d\r\n"),pEvent->hSock.uSocket));
                    break;

                }   // switch (MajorEvent)

                if (NextEvent) {
                    if (fCallAll) {
                        CallbackAll(
                            pEvent->MajorEvent,
                            NextEvent,
                            FindClient(pEvent->pReqClient, TRUE, TRUE),
                            pEvent->hSock,
                            //
                            // Clear CALLBACK_FLAG_LAST if it was set and
                            // retain CALLBACK_FLAG_QUERY
                            //
                            pEvent->fFlags & CALLBACK_FLAG_QUERY);
                    } else {
                        //
                        // Only one client, reuse this CALLBACK_STRUCT
                        //
                        if (IsValidClient(pClient)) {
                            pEvent->SubEvent = NextEvent;
                            pEvent->pDestClient = pEvent->pReqClient;
                            EnqueueEvent(pEvent);
                            StartCallbacks();
                            continue;       // avoid freeing pEvent
                        }
                    }
                }
            }   // if (last one in current stage)
        }
cbt_next1:
        free(pEvent);
    }   // while (callbacks to do)

    DEBUGMSG(ZONE_CALLBACK, (TEXT("PCMCIA:CallbackThread: done %d\r\n"), g_Reentry--));
    DEBUGCHK(FALSE);        // we should never get here
    return ERROR_SUCCESS;
}   // CallbackThread

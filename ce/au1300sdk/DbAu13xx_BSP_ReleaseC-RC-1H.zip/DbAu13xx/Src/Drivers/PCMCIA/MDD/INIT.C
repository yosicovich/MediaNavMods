//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

    init.c

Abstract:

    This file implements the PCMCIA model device driver initialization functions
    This is provided as a sample to platform writers and is
    expected to be able to be used without modification on most (if not
    all) hardware platforms.

Functions:

    CardSystemInit()
    InitAdapterInfo()
    InitSocketInfo()
    BitNumber()
    InitWindowInfo()
    DeInitCardSvc()
    InitCardSvc()
    DllEntry()

Notes:


--*/

#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <linklist.h>
#include <pcmcia.h>
#include <nkintr.h>
#include <extern.h>

#ifdef INSTRUM_DEV
#include <instrumd.h>
#endif

extern UINT StatusChangeThread(UINT Nothing);
extern UINT IREQThread(UINT Nothing);
extern UINT CallbackThread(UINT Nothing);
extern BOOL v_bSharedIntr;

#ifdef DEBUG

//
// These defines must match the ZONE_* defines in PCMCIA.H
//
#define DBG_ERROR      1
#define DBG_WARNING    2
#define DBG_FUNCTION   4
#define DBG_CALLBACK   8
#define DBG_STSCHG     16
#define DBG_IREQ       32
#define DBG_INIT       64
#define DBG_MEM        128
#define DBG_PDD        256
#define DBG_POWER      512
#define DBG_TUPLE      1024

DBGPARAM dpCurSettings = {
    TEXT("PCMCIA"), {
    TEXT("Errors"),TEXT("Warnings"),TEXT("Functions"),TEXT("Callbacks"),
    TEXT("STSCHG Int"),TEXT("IREQ Int"),TEXT("Init"),TEXT("Memory"),
    TEXT("PDD"),TEXT("Power"),TEXT("CIS Tuples"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined") },
    DBG_INIT
};
#endif  // DEBUG

HINSTANCE g_hPcmDll;
DWORD g_LoaderPrio;      // Thread priority of FindDriversThread
CARD_CLIENT_HANDLE v_hNextClient;

#define DEFAULT_IREQ_PRIO           105
#define CALLBACK_RELATIVE_PRIO      1
#define STATUSCHANGE_RELATIVE_PRIO  2

#define KEYNAME_PCMCIA_DRIVER   TEXT("\\Drivers\\PCMCIA")
#define VALNAME_THREAD_PRIO     TEXT("Priority256")
#define VALNAME_ACTIVITY_EVENT  TEXT("StatusChangeActivityEvent")

//
// GetPCMCIAThreadPriority - Read the PCMCIA thread priority from the registry
//
// Return: Priority read from registry OR the default priority if not in registry.
//
DWORD GetPCMCIAThreadPriority(void)
{
    HKEY hKey;
    DWORD dwType;
    DWORD dwVal;
    DWORD dwSize;
    DWORD dwStatus;

    dwStatus = RegOpenKeyEx(
                    HKEY_LOCAL_MACHINE,
                    KEYNAME_PCMCIA_DRIVER,
                    0,
                    0,
                    &hKey
                    );
    if (dwStatus) {
        DEBUGMSG(ZONE_INIT, (TEXT("PCMCIA:GetPCMCIAThreadPriority - RegOpenKeyEx(%s) failed %d\n"),
            KEYNAME_PCMCIA_DRIVER, dwStatus));
        return DEFAULT_IREQ_PRIO;
    }

    dwSize = sizeof(DWORD);
    dwStatus = RegQueryValueEx(
                    hKey,
                    VALNAME_THREAD_PRIO,
                    0,
                    &dwType,
                    (PUCHAR)&dwVal,
                    &dwSize
                    );
    if (dwStatus) {
        DEBUGMSG(ZONE_INIT, (TEXT("PCMCIA:GetPCMCIAThreadPriority - RegQueryValueEx(%s) failed %d\n"),
            VALNAME_THREAD_PRIO, dwStatus));
        dwVal = DEFAULT_IREQ_PRIO;
    }

    RegCloseKey(hKey);
    return dwVal;
}   // GetPCMCIAThreadPriority

void GetPCMCIAPowerManagerEvent(void)
{
    HKEY hKey;
    DWORD dwType;
    DWORD dwSize;
    DWORD dwStatus;
    TCHAR ActivityEvent[128];

    v_PowerManagerEvent = NULL;
    dwStatus = RegOpenKeyEx(
                    HKEY_LOCAL_MACHINE,
                    KEYNAME_PCMCIA_DRIVER,
                    0,
                    0,
                    &hKey
                    );
    if (dwStatus) {
        DEBUGMSG(ZONE_INIT, (TEXT("PCMCIA:GetPCMCIAPowerManagerEvent - RegOpenKeyEx(%s) failed %d\n"),
            KEYNAME_PCMCIA_DRIVER, dwStatus));
        return;
    }

    dwSize = sizeof(ActivityEvent);
    dwStatus = RegQueryValueEx(
                    hKey,
                    VALNAME_ACTIVITY_EVENT,
                    0,
                    &dwType,
                    (PUCHAR)&ActivityEvent[0],
                    &dwSize
                    );
    if (dwStatus) {
        DEBUGMSG(ZONE_INIT, (TEXT("PCMCIA:GetPCMCIAPowerManagerEvent - RegQueryValueEx(%s) failed %d\n"),
            VALNAME_THREAD_PRIO, dwStatus));
    } else {
        v_PowerManagerEvent = OpenEvent(EVENT_ALL_ACCESS, FALSE, ActivityEvent);
    }

    RegCloseKey(hKey);
    return;
}   // GetPCMCIAPowerManagerEvent

//
// CardSystemInit
//
// @func    STATUS | CardSystemInit | Indicate to card services that the
// operating system has initialized.
// @rdesc   Return CERR_SUCCESS
//
// @comm    There are system dependencies at initialization time that require
// card services to wait before detecting cards that were inserted before
// system boot.
//
STATUS
CardSystemInit(VOID)
{
    DEBUGMSG(ZONE_INIT|ZONE_FUNCTION,
        (TEXT("PCMCIA:CardSystemInit entered\r\n")));
    DEBUGMSG(ZONE_INIT|ZONE_FUNCTION,
        (TEXT("PCMCIA:CardSystemInit succeeded\r\n")));
    return CERR_SUCCESS;
}   // CardSystemInit

//
// Get adapter info using the PDCardInquireAdapter() PDD function.
//
BOOL InitAdapterInfo(void)
{
    STATUS ret;
    PDCARD_ADAPTER_INFO adpt;

    //
    // Call it twice. The first time is to get the size.
    //
    adpt.uPowerEntries = 0;
    ret = PDCardInquireAdapter(&adpt);
    if (!((ret == CERR_BAD_ARG_LENGTH) || (ret == CERR_SUCCESS))) {
        DEBUGMSG(ZONE_INIT|ZONE_WARNING,
            (TEXT("PCMCIA:InitAdapterInfo PDCardInquireAdapter returned %d\r\n"), ret));
        return FALSE;
    }

    v_pAdapterInfo = alloc(sizeof(PDCARD_ADAPTER_INFO) +
                           sizeof(PDCARD_POWER_ENTRY)*adpt.uPowerEntries);
    if (v_pAdapterInfo == NULL) {
        return FALSE;
    }
#ifdef MYMEMTRACKING
    v_TrackSocketInfo++;
#endif
#ifdef MEMTRACKING
    AddTrackedItem(v_TrackSocketInfo, v_pAdapterInfo, NULL, GetCurrentProcessId(),
        sizeof(PDCARD_ADAPTER_INFO) + sizeof(PDCARD_POWER_ENTRY)*adpt.uPowerEntries,
        0, 0);
#endif

    v_pAdapterInfo->uPowerEntries = adpt.uPowerEntries;
    ret = PDCardInquireAdapter(v_pAdapterInfo);
    if (ret != CERR_SUCCESS) {
        free(v_pAdapterInfo);
#ifdef MYMEMTRACKING
    v_TrackSocketInfo--;
#endif
#ifdef MEMTRACKING
    DeleteTrackedItem(v_TrackSocketInfo, v_pAdapterInfo);
#endif
        v_pAdapterInfo = NULL;
        return FALSE;
    }

    return TRUE;
}   // InitAdapterInfo


//
// Build list of available PCMCIA sockets.
//
BOOL InitSocketInfo(void)
{
    HKEY hKey;
    DWORD dwType;
    DWORD dwVal;
    DWORD dwSize;
    DWORD dwStatus;
    PDCARD_SOCKET_STATE SockState;
    PPHYS_SOCKET pSock;
    STATUS ret;
    TCHAR AccessName[10];

    v_cSockets = 0;
    pSock = v_Sockets;
    ret = CERR_SUCCESS;

    dwStatus = RegOpenKeyEx(
                    HKEY_LOCAL_MACHINE,
                    KEYNAME_PCMCIA_DRIVER,
                    0,
                    0,
                    &hKey
                    );
    if (dwStatus) {
        DEBUGMSG(ZONE_INIT, (TEXT("PCMCIA:InitSocketInfo - RegOpenKeyEx(%s) failed %d\n"),
            KEYNAME_PCMCIA_DRIVER, dwStatus));
        hKey = NULL;
    }

    while ((ret == CERR_SUCCESS) && (v_cSockets <= MAX_SOCKETS)) {
        ret = PDCardGetSocket(v_cSockets, &SockState);
        if (ret == CERR_SUCCESS) {
            pSock->pDevId = NULL;
            pSock->pLsock = NULL;
            pSock->pAttrWin = NULL;
            pSock->pCmnWin = NULL;
            pSock->cFunctions = 0;
            pSock->PowerState = POWER_NORMAL;
            pSock->DetectState = DETECT_NONE;
            pSock->fFlags = SockState.fInterruptEvents;
            pSock->fFlags |= (SockState.fSocketCaps  << 8);
            pSock->fFlags |= (SockState.fControlCaps << 16);

            if (hKey != NULL) {
                _tcsncpy(AccessName, L"NoAccess", 8);
                AccessName[8] = '0' + v_cSockets;
                AccessName[9] = 0;
                dwSize = sizeof(DWORD);
                dwStatus = RegQueryValueEx(
                                hKey,
                                AccessName,
                                0,
                                &dwType,
                                (PUCHAR)&dwVal,
                                &dwSize
                                );
                if (dwStatus == ERROR_SUCCESS && dwVal != 0) {
                    pSock->fFlags |= PHYS_SOCK_FLAG_NOT_USER_ACCESS;
                }
            }

            SockState.fInterruptEvents = INITIAL_SOCKET_EVENTS;
            SockState.fIREQRouting = 0;
            ret = PDCardSetSocket(v_cSockets, &SockState);
            if (ret != CERR_SUCCESS) {
                DEBUGMSG(ZONE_INIT|ZONE_WARNING,
                    (TEXT("PCMCIA:InitSocketInfo PDCardSetSocket returned %d\r\n"), ret));
            }
            v_cSockets++;
            pSock++;
        }
    }

    if (hKey != NULL)
        RegCloseKey(hKey);

    if (v_cSockets)
        return TRUE;

    DEBUGMSG(ZONE_INIT|ZONE_WARNING,
        (TEXT("PCMCIA: %d sockets in the system\r\n"), v_cSockets));
    return FALSE;
}   // InitSocketInfo


//
// Return number of first bit that is set in the mask.
//
UINT
BitNumber(
    UINT fBitMask
    )
{
    UINT i;

    for (i = 0; i < 32; i++) {
        if (fBitMask & 1) {
            return i;
        }
        fBitMask >>= 1;
    }
    // What should be returned if no bit is set?
    return i;
}   // BitNumber


//
// Build a list of available memory and I/O windows
//
BOOL
InitWindowInfo(void)
{
    UINT32 uWindow = 0;
    PDCARD_WINDOW_INFO WinInfo;
    PDCARD_WINDOW_STATE WinState;
    PPHYS_WINDOW pPhys;
    PPHYS_WINDOW pTmp;
    STATUS ret = CERR_SUCCESS;

#ifdef DEBUG
    WCHAR Output[128];
#endif

    v_cWindows = 0;
    v_pWinList = NULL;

    while (ret == CERR_SUCCESS) {
        ret = PDCardInquireWindow(uWindow, &WinInfo);
        if (ret == CERR_SUCCESS) {
            if ((pPhys = alloc(sizeof(PHYS_WINDOW))) == NULL) {
                goto iwi_done;
            }

#ifdef MYMEMTRACKING
    v_TrackPhysicalWindowInfo++;
#endif
#ifdef MEMTRACKING
    AddTrackedItem(v_TrackPhysicalWindowInfo, pPhys, NULL, GetCurrentProcessId(),
        sizeof(PHYS_WINDOW), 0, 0);
#endif

            pPhys->uWindow = uWindow;
            pPhys->uSock = (UINT8)BitNumber(WinInfo.fSockets);
            pPhys->fFlags = 0;
            pPhys->fWindowCaps = WinInfo.fWindowCaps;

            if (WinInfo.fWindowCaps & WIN_CAP_IO) {    // I/O window
                pPhys->uBase = WinInfo.uIOFirstByte;   // physical address
                pPhys->uMaxSize = WinInfo.uIOMaxSize;
                pPhys->fOtherCaps = WinInfo.fIOCaps;
            } else {                                   // memory window
                pPhys->uBase = WinInfo.uMemFirstByte;  // physical address
                pPhys->uMaxSize = WinInfo.uMemMaxSize;
                pPhys->fOtherCaps = WinInfo.fMemoryCaps;
            }
            if (PDCardGetWindow(uWindow, &WinState) == CERR_SUCCESS) {
                if (WinState.fState & WIN_STATE_16BIT) {
                    pPhys->fFlags |= PHYS_WIN_FLAG_16BIT_MODE;
                }
                if (WinState.fState & WIN_STATE_ATTRIBUTE) {
                    pPhys->fFlags |= PHYS_WIN_FLAG_ATTR_MODE;
                }
                if (WinState.fState & WIN_STATE_ENABLED) {
                    pPhys->fFlags |= PHYS_WIN_FLAG_ENABLED;
                }
                pPhys->uOffset = WinState.uOffset;
                pPhys->uSize = WinState.uSize;
            }
            pPhys->Next = NULL;
            pPhys->pLog = NULL;

            //
            // Keep the non-programmable windows at the front of the list
            //
            if ((pPhys->fOtherCaps & MEM_CAP_PRG_BASE) && (v_pWinList != NULL)) {
                pTmp = v_pWinList;
                while (pTmp) {
                    if (pTmp->Next == NULL) {
                        pTmp->Next = pPhys;
                        break;
                    }
                    if (pTmp->Next->fOtherCaps & MEM_CAP_PRG_BASE) {
                        pPhys->Next = pTmp->Next;
                        pTmp->Next = pPhys;
                        break;
                    }
                    pTmp = pTmp->Next;
                }
            } else {
                pPhys->Next = v_pWinList;   // non-programmable windows at the front
                v_pWinList = pPhys;
            }
#ifdef DEBUG
    Output[0] = 0;
    if ((pPhys->fOtherCaps & (MEM_CAP_8BIT|MEM_CAP_16BIT)) == (MEM_CAP_8BIT|MEM_CAP_16BIT)) {
        wcscat(Output, TEXT("16 and 8 bit "));
    } else {
        wcscat(Output, pPhys->fOtherCaps & MEM_CAP_8BIT ?
            TEXT("8 bit ") : TEXT("16 bit "));
    }
    if (WinInfo.fWindowCaps & WIN_CAP_IO) {
        wcscat(Output, TEXT("I/O "));
    }
    if (WinInfo.fWindowCaps & WIN_CAP_ATTRIBUTE) {
        wcscat(Output, TEXT("Attribute "));
    }
    if (WinInfo.fWindowCaps & WIN_CAP_COMMON) {
        wcscat(Output, TEXT("Common "));
    }
    DEBUGMSG(ZONE_INIT,
        (TEXT("PCMCIA:InitWindowInfo: Window %d (%s window on socket %d)\r\n"),
        uWindow, Output, pPhys->uSock));

#endif

            v_cWindows++;                  // Count it.
            uWindow++;
        }
    }

iwi_done:
    DEBUGMSG(ZONE_INIT|ZONE_WARNING,
        (TEXT("PCMCIA: %d memory windows in the system\r\n"), v_cWindows));
    if (v_cWindows) {
#ifdef DEBUG
        pTmp = v_pWinList;
        DEBUGMSG(ZONE_INIT, (TEXT("PCMCIA Windows: ")));
        while (pTmp) {
            DEBUGMSG(ZONE_INIT, (TEXT("%d "), pTmp->uWindow));
            pTmp = pTmp->Next;
        }
        DEBUGMSG(ZONE_INIT, (TEXT("\r\n")));
#endif
        return TRUE;
    }

    return FALSE;
}   // InitWindowInfo


VOID DeInitCardSvc(VOID)
{
    PPHYS_WINDOW pPhys;

    DEBUGMSG(ZONE_INIT|ZONE_WARNING,
        (TEXT("PCMCIA:DeInitCardSvc Unhooking SYSINTR_PCMCIA_STATE and SYSINTR_PCMCIA_LEVEL\r\n")));
    InterruptDisable(gIntrPcmciaState);
    InterruptDisable(gIntrPcmciaLevel);

    if (v_pAdapterInfo) {
        free(v_pAdapterInfo);
#ifdef MYMEMTRACKING
    v_TrackPhysicalWindowInfo--;
#endif
#ifdef MEMTRACKING
    DeleteTrackedItem(v_TrackSocketInfo, v_pAdapterInfo);
#endif
    }

    //
    // Free window list
    //
    while (v_pWinList) {
        pPhys = v_pWinList;
        v_pWinList = pPhys->Next;
        free(pPhys);
#ifdef MYMEMTRACKING
    v_TrackPhysicalWindowInfo--;
#endif
#ifdef MEMTRACKING
    DeleteTrackedItem(v_TrackPhysicalWindowInfo, pPhys);
#endif
    }

    if (v_StatusChangeEvent != NULL)
        CloseHandle(v_StatusChangeEvent);
    if (v_IREQEvent != NULL)
        CloseHandle(v_IREQEvent);
    if (v_CallbackEvent != NULL)
        CloseHandle(v_CallbackEvent);
}   // DeInitCardSvc


//
// Initialize the PCMCIA system
//
BOOL InitCardSvc(DWORD dwInfo)
{
    SYSTEM_INFO SysInfo;
    STATUS status;
    HANDLE hIREQThd;
    HANDLE hStatusChangeThd;
    HANDLE hCallbackThd;
    DWORD  dwIREQPrio;
    DWORD  dwCallbackPrio;
    int i;

    v_hNextClient = (CARD_CLIENT_HANDLE)0;

    GetSystemInfo(&SysInfo);
    v_PageSize = SysInfo.dwPageSize;

    if (status = PDCardInitServices(dwInfo)) {
        DEBUGMSG(ZONE_INIT|ZONE_WARNING,
            (TEXT("PCMCIA:InitCardSvc PDCardInitServices returned %d\r\n"),
            status));
        return FALSE;
    }

    if (InitAdapterInfo() == FALSE) {
        return FALSE;
    }

    hStatusChangeThd = NULL;
    hIREQThd = NULL;
    hCallbackThd = NULL;

    //
    // Create the event for the PCMCIA interrupt thread.
    // Then register them with the kernel and then start the thread.
    // (Create v_StatusChangeEvent as signalled to recognize cards inserted
    // before booting.)
    //
    v_IREQEvent = CreateEvent(NULL, FALSE, FALSE , NULL);
    v_StatusChangeEvent = CreateEvent(NULL, FALSE, TRUE, NULL);
    v_CallbackEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    if ((v_IREQEvent == NULL) ||
        (v_StatusChangeEvent == NULL) ||
        (v_CallbackEvent == NULL)) {
        DEBUGMSG(ZONE_INIT|ZONE_WARNING,
            (TEXT("PCMCIA:Unable to create one of the PCMCIA interrupt events (%d)\r\n"),
            GetLastError()));
        goto init_fail;
    }

    if (!InterruptInitialize(gIntrPcmciaLevel,v_IREQEvent,NULL,0)) {
        DEBUGMSG(ZONE_INIT|ZONE_WARNING,
            (TEXT("PCMCIA:Unable to initialize IREQ int %d (error %d)\r\n"),
            gIntrPcmciaLevel, GetLastError()));
            goto init_fail;
    }

    //
    // If we're unable to get an interrupt for status change events then we'll
    // force polling.
    //
    if (gIntrPcmciaState == 0 || !InterruptInitialize(gIntrPcmciaState, v_StatusChangeEvent,NULL,0)) {
        DEBUGMSG(ZONE_INIT|ZONE_WARNING,
            (TEXT("PCMCIA:Unable to initialize STSCHG int %d (error %d)\r\n"),
            gIntrPcmciaState, GetLastError()));
        if (gIntrPcmciaState == gIntrPcmciaLevel) {
            v_bSharedIntr = TRUE;
        } else {
            CloseHandle(v_StatusChangeEvent);
            v_StatusChangeEvent = NULL;
        }
    }

    if (InitSocketInfo() == FALSE) {
        goto init_fail;
    }

    if (InitWindowInfo() == FALSE) {
        goto init_fail;
    }

    InitializeListHead(&v_ClientList);
    InitializeCriticalSection(&v_PowerCrit);
    InitializeCriticalSection(&v_ClientCrit);
    InitializeCriticalSection(&v_CallbackCrit);
    InitializeCriticalSection(&v_SocketCrit);
    InitializeCriticalSection(&v_WindowCrit);
    v_CallbackHead = v_CallbackTail = NULL;

    InitializeCriticalSection(&v_BatteryCrit);
    InitializeCriticalSection(&v_DetectCrit);
    InitializeCriticalSection(&v_FindDriverCrit);
    for (i = 0; i < MAX_SOCKETS; i++) {
        v_fBattery[i] = FALSE;
        v_hBatteryThread[i] = 0;
    }

    dwIREQPrio = GetPCMCIAThreadPriority();
    GetPCMCIAPowerManagerEvent();
    g_LoaderPrio = dwIREQPrio;
    dwCallbackPrio = dwIREQPrio - CALLBACK_RELATIVE_PRIO;   // used in callback.c

    //
    // Start callback thread
    //
    hCallbackThd = CreateThread(NULL, 0,
                (LPTHREAD_START_ROUTINE)CallbackThread,
                NULL, 0, NULL);
    if (hCallbackThd == NULL) {
        DEBUGMSG(ZONE_INIT|ZONE_WARNING,
            (TEXT("PCMCIA:Unable to create the CallbackThread (%d)\r\n"),
            GetLastError()));
        goto init_fail;
    }
    
    //
    // Start interrupt thread
    //
    hIREQThd = CreateThread(NULL, 0,
                (LPTHREAD_START_ROUTINE)IREQThread,
                NULL, 0, NULL);
    if (hIREQThd == NULL) {
        DEBUGMSG(ZONE_INIT|ZONE_WARNING,
            (TEXT("PCMCIA:Unable to create the IREQThread (%d)\r\n"),
            GetLastError()));
        goto init_fail;
    }

    v_hGwesEvent = OpenEvent(EVENT_ALL_ACCESS, FALSE, (TEXT("SYSTEM/GweApiSetReady")));

    hStatusChangeThd = CreateThread(NULL, 0,
                (LPTHREAD_START_ROUTINE)StatusChangeThread,
                NULL, 0, NULL);
    if (hStatusChangeThd == NULL) {
        DEBUGMSG(ZONE_INIT|ZONE_WARNING,
            (TEXT("PCMCIA:Unable to create the StatusChangeThread (%d)\r\n"),
            GetLastError()));
        goto init_fail;
    }

    DEBUGMSG(ZONE_INIT, (TEXT("PCMCIA:StatusChangeThread = 0x%x, IREQThread = 0x%x, CallbackThread = 0x%x\r\n"), 
        hStatusChangeThd, hIREQThd, hCallbackThd));

    if (hIREQThd != NULL) {
        CeSetThreadPriority(hIREQThd, dwIREQPrio);
        CloseHandle(hIREQThd);
    }

    if (hStatusChangeThd != NULL) {
        CeSetThreadPriority(hStatusChangeThd, dwIREQPrio - STATUSCHANGE_RELATIVE_PRIO);
        CloseHandle(hStatusChangeThd);
    }

    if (hCallbackThd != NULL) {
        CeSetThreadPriority(hCallbackThd, dwCallbackPrio);
        CloseHandle(hCallbackThd);
    }

    return TRUE;


init_fail:
    DEBUGMSG(ZONE_INIT|ZONE_WARNING,(TEXT("PCMCIA init failed!\r\n")));

    if (hStatusChangeThd != NULL)
        CloseHandle(hStatusChangeThd);

    if (hIREQThd != NULL)
        CloseHandle(hIREQThd);

    if (hCallbackThd != NULL) {
        CloseHandle(hCallbackThd);
    }

    DeInitCardSvc();
    return FALSE;
}   // InitCardSvc


PFN_LoadStringW v_pfnLoadStringW;
PFN_MessageBoxW v_pfnMessageBoxW;
PFN_GetSystemPowerStatusEx v_pfnGetSystemPowerStatusEx;
PFN_PostThreadMessageW v_pfnPostThreadMessageW;

// Init() - called by RegisterDevice when we get loaded
//        NOTE: only one instance of PCMCIA.DLL is supported!
DWORD
Init (DWORD dwInfo)
{
    HMODULE hCoreDLL;
    
    // Look up some required function pointers.
    hCoreDLL = (HMODULE)LoadLibrary(TEXT("COREDLL.DLL"));
    if (NULL != hCoreDLL) {
        v_pfnLoadStringW = (PFN_LoadStringW)GetProcAddress(hCoreDLL,
            TEXT("LoadStringW"));
        v_pfnMessageBoxW = (PFN_MessageBoxW)GetProcAddress(hCoreDLL,
            TEXT("MessageBoxW"));
        v_pfnGetSystemPowerStatusEx = (PFN_GetSystemPowerStatusEx)GetProcAddress (hCoreDLL,
            TEXT("GetSystemPowerStatusEx"));
        v_pfnPostThreadMessageW = (PFN_PostThreadMessageW)GetProcAddress (hCoreDLL,
            TEXT("PostThreadMessageW"));

        // We can free the library since we are already linked to it.
        FreeLibrary (hCoreDLL);
    }
    
    return InitCardSvc(dwInfo) ? 1 : 0;
}

// Deinit() - called by DeregisterDevice if we get unloaded
//        NOTE: assumes there was only one instance!
void
Deinit (DWORD dwData)
{
    DeInitCardSvc();
}


BOOL WINAPI
DllEntry(HINSTANCE DllInstance, INT Reason, LPVOID Reserved)
{
    BOOL ret = TRUE;

    switch(Reason) {
        case DLL_PROCESS_ATTACH:
            g_hPcmDll = DllInstance;

            DEBUGREGISTER(DllInstance);
            DEBUGMSG(ZONE_INIT|ZONE_WARNING,(TEXT("PCMCIA.DLL DLL_PROCESS_ATTACH\r\n")));

#ifdef MYMEMTRACKING
    v_TrackCallbacks =
    v_TrackPNPId =
    v_TrackPNPIdBytes =
    v_TrackSocketInfo =
    v_TrackPhysicalWindowInfo =
    v_TrackClientDrivers =
    v_TrackClientSockets =
    v_TrackLogicalSockets =
    v_TrackLogicalMemoryWindows =
    v_TrackVirtualMemory =
    v_TrackVirtualMemoryBytes = 0;
#endif
#ifdef MEMTRACKING
    v_TrackCallbacks =  RegisterTrackedItem(TEXT("PCM Callback"));  // CALLBACK_STRUCT
    v_TrackPNPId =      RegisterTrackedItem(TEXT("PCM PNP Id"));    // TCHAR
    v_TrackSocketInfo = RegisterTrackedItem(TEXT("PCM Socket Info"));   // PDCARD_ADAPTER_INFO
    v_TrackPhysicalWindowInfo = RegisterTrackedItem(TEXT("PCM Mem Win Info")); // PHYS_WINDOW
    v_TrackClientDrivers = RegisterTrackedItem(TEXT("PCM Client")); // CLIENT_DRIVER
    v_TrackClientSockets = RegisterTrackedItem(TEXT("PCM Client Skt")); // CLIENT_SOCKET
    v_TrackLogicalSockets = RegisterTrackedItem(TEXT("PCM Logical Skt"));   // LOG_SOCKET
    v_TrackLogicalMemoryWindows = RegisterTrackedItem(TEXT("PCM Logical Mem")); // LOG_WINDOW
    v_TrackVirtualMemory = RegisterTrackedItem(TEXT("PCM Virtual Mem")); // mappings to physical pcmcia areas
#endif
#ifdef INSTRUM_DEV
            ics_init();
#endif
	    DisableThreadLibraryCalls((HMODULE) DllInstance);
            break;

        case DLL_PROCESS_DETACH:
            DEBUGMSG(ZONE_INIT|ZONE_WARNING,(TEXT("PCMCIA.DLL DLL_PROCESS_DETACH\r\n")));
            break;
    }
    return ret;
}

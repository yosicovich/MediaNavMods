//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

    config.c

Abstract:

    This file implements the PCMCIA model device driver socket configuration
    functions.  This is provided as a sample to platform writers and is
    expected to be able to be used without modification on most (if not
    all) hardware platforms.

Functions:

    FindPowerEntry()
    CardRequestConfiguration()
    CardReleaseConfiguration()
    PowerUp()
    PowerDown()
    PcmciaPowerOn()
    PcmciaPowerOff()
    CardAccessConfigurationRegister()

Notes:


--*/

#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <pcmcia.h>
#include <nkintr.h>
#include <extern.h>

#define BAD_VOLTAGE_INDEX 0xff
#define NUM_REGISTERS 5     // number of function configuration registers
#define NUM_EXT_REGISTERS 4 // number of additional function configuration registers

DWORD v_SysIntrWake = 0;    // SysIntr for wake on CD changes
DWORD v_FuncSysIntrWake = 0;// SysIntr for wake on functional interrupt

//
// Find the power entry index that matches the voltage and supply specified.
//
UINT8
FindPowerEntry(
    UINT fSupply,
    UINT8 uVoltage
    )
{
    UINT8 i;
    PPDCARD_POWER_ENTRY pPwr = (PPDCARD_POWER_ENTRY)(((PCHAR)v_pAdapterInfo) +
                                sizeof(PDCARD_ADAPTER_INFO));
    for (i = 0; i < v_pAdapterInfo->uPowerEntries; i++, pPwr++) {
        if ((pPwr->uPowerLevel == uVoltage) && (pPwr->fSupply & fSupply)) {
            return i;
        }
    }

    return BAD_VOLTAGE_INDEX;
}

// Use the stored information in the PHYS_WINDOW struct to restore the window state of a socket
STATUS
RestoreWindowState(
    UINT uSocket
    )
{
    STATUS status = CERR_SUCCESS;
    PPHYS_WINDOW pPhys;
    PDCARD_WINDOW_STATE WinState;

    for (pPhys = v_pWinList; pPhys != NULL; pPhys = pPhys->Next) {
        if (pPhys->uSock != uSocket) continue;
        if ((status = PDCardGetWindow(pPhys->uWindow, &WinState)) != CERR_SUCCESS)
            break;

        WinState.uSize = pPhys->uSize;
        WinState.uOffset = pPhys->uOffset;
        if (pPhys->fFlags & PHYS_WIN_FLAG_ENABLED) {
            WinState.fState |= WIN_STATE_ENABLED;
        } else {
            WinState.fState &= ~WIN_STATE_ENABLED;
        }
        if (pPhys->fFlags & PHYS_WIN_FLAG_ATTR_MODE) {
            WinState.fState |= WIN_STATE_ATTRIBUTE;
        } else {
            WinState.fState &= ~WIN_STATE_ATTRIBUTE;
        }
#ifndef SH4
        if (pPhys->fFlags & PHYS_WIN_FLAG_16BIT_MODE) {
            WinState.fState |= WIN_STATE_16BIT;
        } else {
            WinState.fState &= ~WIN_STATE_16BIT;
        }
#endif
        if ((status = PDCardSetWindow(pPhys->uWindow, &WinState)) != CERR_SUCCESS)
            break;
    }

    return status;
}

//
// Configure the logical socket
//
STATUS
ConfigureLogSock(
    PLOG_SOCKET pLsock
    )
{
    PDCARD_SOCKET_STATE State;
    STATUS status;
    PUINT8 pRegVal;
    UINT i;
    PLOG_SOCKET pTmp;
    BOOL bIRQ, bPwr;

    status = PDCardGetSocket(pLsock->hSock.uSocket, &State);
    if (status) {
        DEBUGMSG(ZONE_WARNING,
         (TEXT("PCMCIA:ConfigureLogSock PDCardGetSocket failed %d\r\n"),
         status));
        return status;
    }

    // Socket is non-powered
    if (pLsock->FCSR_val & FCR_FCSR_PWR_DOWN)
        return CERR_SUCCESS;

    bIRQ = bPwr = FALSE;
    EnterCriticalSection(&v_SocketCrit);
    for (pTmp = v_Sockets[pLsock->hSock.uSocket].pLsock; pTmp != NULL; pTmp = pTmp->Next) {
        if (pTmp->fFlags & LOG_SOCK_FLAG_KEEP_POWERED) {
            bPwr = TRUE;
            State.fSocketCaps |= SOCK_CAP_KEEP_POWERED;
        }

        if (pTmp->fFlags & LOG_SOCK_FLAG_IRQ_WAKEUP) {
            bIRQ = TRUE;
            State.fIREQRouting |= SOCK_IREQ_WAKEUP;
        }
    }
    LeaveCriticalSection(&v_SocketCrit);

    if (!bIRQ) State.fSocketCaps &= ~SOCK_CAP_KEEP_POWERED;
    if (!bPwr) State.fIREQRouting &= ~SOCK_IREQ_WAKEUP;

    State.fVcc = pLsock->fVcc;
    State.uVpp1 = pLsock->uVpp1;
    State.uVpp2 = pLsock->uVpp2;
    State.fInterfaceType = pLsock->fInterfaceType;
    State.fControlCaps |= pLsock->fControlCaps;

    status = PDCardSetSocket(pLsock->hSock.uSocket, &State);
    if (status) {
        DEBUGMSG(ZONE_WARNING,
         (TEXT("PCMCIA:CardRequestConfiguration PDCardSetSocket failed %d\r\n"),
          status));
        return status;
    }

    // Don't want to reset the socket
    pLsock->COR_val &= ~FCR_COR_SRESET;

    if (pLsock->pRegWin != NULL) {
        pRegVal = &(pLsock->COR_val);
        for (i = 0; i < (NUM_REGISTERS + NUM_EXT_REGISTERS); i++) {
            if (pLsock->fCfgRegisters & (1 << i)) {
                CardWriteAttrByte(pLsock->pRegWin, i, *pRegVal);
            }
            pRegVal++;
        }
    }

    return status;
}

void DisableCSCWake()
{
    int i;
    PLOG_SOCKET pLsock;

    // check if CSC is not a wake source
    if (v_SysIntrWake == 0) return;
    for (i = 0; i < v_cSockets; i++) {
        if (!(v_Sockets[i].fFlags & PHYS_SOCK_FLAG_NOT_USER_ACCESS)) {
            EnterCriticalSection(&v_SocketCrit);
            // Check for:
            // log sockets that don't want to unload on resume
            // non-powered down log sockets that want IRQ wakeup
            for (pLsock = v_Sockets[i].pLsock; pLsock != NULL; pLsock = pLsock->Next) {
                if ((pLsock->fFlags & LOG_SOCK_FLAG_NO_SUSPEND_UNLOAD) ||
                    ((pLsock->fFlags & LOG_SOCK_FLAG_IRQ_WAKEUP) &&
                     !(pLsock->FCSR_val & FCR_FCSR_PWR_DOWN)))
                    break;
            }
            LeaveCriticalSection(&v_SocketCrit);
            if (pLsock != NULL) break;
        }
    }

    // If no accessible sockets want NO_SUSPEND_UNLOAD or IRQ_WAKEUP
    // we can sleep on card insertion/removal
    if (i == v_cSockets) {
        if (v_SysIntrWake == v_FuncSysIntrWake ||
            KernelIoControl(IOCTL_HAL_DISABLE_WAKE, &v_SysIntrWake, sizeof(v_SysIntrWake), NULL, 0, NULL)) {
            v_SysIntrWake = 0;
        }
    }
}

void DisableIRQWake()
{
    int i;
    PLOG_SOCKET pLsock;

    // check if CSC is not a wake source
    if (v_FuncSysIntrWake == 0) return;
    EnterCriticalSection(&v_SocketCrit);
    for (i = 0; i < v_cSockets; i++) {
        // Check for non-powered down log socks that want IRQ wakeup
        for (pLsock = v_Sockets[i].pLsock; pLsock != NULL; pLsock = pLsock->Next) {
            if ((pLsock->fFlags & LOG_SOCK_FLAG_IRQ_WAKEUP) &&
                !(pLsock->FCSR_val & FCR_FCSR_PWR_DOWN))
                break;
        }
        if (pLsock != NULL) break;
    }
    LeaveCriticalSection(&v_SocketCrit);

    // If no sockets want IRQ_WAKEUP, we can sleep on functional interrupts
    if (i == v_cSockets) {
        if (v_SysIntrWake == v_FuncSysIntrWake ||
            KernelIoControl(IOCTL_HAL_DISABLE_WAKE, &v_FuncSysIntrWake, sizeof(v_FuncSysIntrWake), NULL, 0, NULL)) {
            v_FuncSysIntrWake = 0;
        }
    }
}

BOOL EnableCSCWake(UINT uSocket)
{
    if (v_SysIntrWake == 0 &&
        !(v_Sockets[uSocket].fFlags & PHYS_SOCK_FLAG_NOT_USER_ACCESS)) {
        if (gIntrPcmciaState != 0 && 
            KernelIoControl(IOCTL_HAL_ENABLE_WAKE, &gIntrPcmciaState, sizeof(gIntrPcmciaState), NULL, 0, NULL)) {
            v_SysIntrWake = gIntrPcmciaState;
        } else {
            return FALSE;
        }
    }
    return TRUE;
}

BOOL EnableIRQWake()
{
    if (v_FuncSysIntrWake == 0) {
        if (KernelIoControl(IOCTL_HAL_ENABLE_WAKE, &gIntrPcmciaLevel, sizeof(gIntrPcmciaLevel), NULL, 0, NULL)) {
            v_FuncSysIntrWake = gIntrPcmciaLevel;
        }
    }
    return (v_SysIntrWake != 0);
}

//
// CardModifyConfiguration
//
// @doc DRIVERS
//
// @func    STATUS | CardModifyConfiguration | Configure socket and PC card interface type and voltage.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE, CERR_BAD_SOCKET, CERR_IN_USE, CERR_BAD_ARGS
//
// @comm    Change the fAttributes bits on an already existing configuration
//          Currently can only change CFG_ATTR_IRQ_WAKEUP, CFG_ATTR_KEEP_POWERED, and
//          CFG_ATTR_NO_SUSPEND_UNLOAD
// @xref    <f CardRequestConfiguration> <f CardReleaseConfiguration>
//
STATUS
CardModifyConfiguration(
    CARD_CLIENT_HANDLE hCardClient, // @parm Handle from <f CardRegisterClient>
    CARD_SOCKET_HANDLE hSock,       // @parm Socket/function identifier
    PUINT16 fAttributes
    )
{
    PLOG_SOCKET pLsock, pTmp;
    STATUS status = CERR_SUCCESS;
    PCLIENT_DRIVER pClient;
    BOOL bCSC = FALSE, bIRQ = FALSE;
    PDCARD_SOCKET_STATE State;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("PCMCIA:CardModifyConfiguration entered\r\n")));

    pLsock = I_FindSocket(hSock);
    if (pLsock == NULL || !(pLsock->fFlags & OWNER_FLAG_CONFIG)) {
        status = CERR_BAD_SOCKET;
        goto mod_cfg_err_exit;
    }

    if (hCardClient == NULL ||
        (pClient = FindClient(hCardClient, TRUE, TRUE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto mod_cfg_err_exit;
    } else if (pLsock->hOwner != pClient) {
        status = CERR_IN_USE;
        goto mod_cfg_err_exit;
    }

    if (fAttributes == NULL) {
        status = CERR_BAD_ARGS;
        goto mod_cfg_err_exit;
    }

    //
    // Attempt to set functional interrupts as a wake source
    //
    if (*fAttributes & CFG_ATTR_IRQ_WAKEUP) {
        if (!(pLsock->fFlags & LOG_SOCK_FLAG_IRQ_WAKEUP)) {
            pLsock->fFlags |= LOG_SOCK_FLAG_IRQ_WAKEUP;

            // Try to make insertion/removal a wake source if it isn't already,
            bCSC = FALSE;
            if (!EnableCSCWake(hSock.uSocket)) {
                pLsock->fFlags &= ~LOG_SOCK_FLAG_IRQ_WAKEUP;
                *fAttributes &= ~CFG_ATTR_IRQ_WAKEUP;
                goto mod_cfg_irqw1;
            }

            // Try to make IRQs a wake source if it isn't already,
            if (!EnableIRQWake()) {
                pLsock->fFlags &= ~LOG_SOCK_FLAG_IRQ_WAKEUP;
                *fAttributes &= ~CFG_ATTR_IRQ_WAKEUP;
                bCSC = TRUE;
                goto mod_cfg_irqw1;
            }

            status = PDCardGetSocket(pLsock->hSock.uSocket, &State);
            if (status != CERR_SUCCESS) {
                DEBUGMSG(ZONE_WARNING,
                 (TEXT("PCMCIA:CardModifyConfiguration PDCardGetSocket failed %d\r\n"),
                 status));
                return status;
            }
            State.fIREQRouting |= SOCK_IREQ_WAKEUP;
            status = PDCardSetSocket(pLsock->hSock.uSocket, &State);
            if (status != CERR_SUCCESS) {
                DEBUGMSG(ZONE_WARNING,
                 (TEXT("PCMCIA:CardModifyConfiguration PDCardSetSocket failed %d\r\n"),
                 status));
                return status;
            }

            if (pLsock->FCSR_val & FCR_FCSR_PWR_DOWN)
                bCSC = bIRQ = TRUE;
        }
    } else {
        if (pLsock->fFlags & LOG_SOCK_FLAG_IRQ_WAKEUP) {
            bCSC = bIRQ = TRUE;
            pLsock->fFlags &= ~LOG_SOCK_FLAG_IRQ_WAKEUP;

            EnterCriticalSection(&v_SocketCrit);
            for (pTmp = v_Sockets[pLsock->hSock.uSocket].pLsock; pTmp != NULL; pTmp = pTmp->Next) {
                if (pTmp->fFlags & LOG_SOCK_FLAG_IRQ_WAKEUP)
                    break;
            }
            LeaveCriticalSection(&v_SocketCrit);
            if (pTmp == NULL) {
                status = PDCardGetSocket(pLsock->hSock.uSocket, &State);
                if (status != CERR_SUCCESS) {
                    DEBUGMSG(ZONE_WARNING,
                     (TEXT("PCMCIA:CardModifyConfiguration PDCardGetSocket failed %d\r\n"),
                     status));
                    return status;
                }
                State.fIREQRouting &= ~SOCK_IREQ_WAKEUP;
                status = PDCardSetSocket(pLsock->hSock.uSocket, &State);
                if (status != CERR_SUCCESS) {
                    DEBUGMSG(ZONE_WARNING,
                     (TEXT("PCMCIA:CardModifyConfiguration PDCardSetSocket failed %d\r\n"),
                     status));
                    return status;
                }
            }
        }
    }

mod_cfg_irqw1:
    //
    // Do not power down during suspend
    //
    if ((*fAttributes & CFG_ATTR_KEEP_POWERED) ||
        (pLsock->fFlags & LOG_SOCK_FLAG_IRQ_WAKEUP)) {
        if (!(pLsock->fFlags & LOG_SOCK_FLAG_KEEP_POWERED)) {
            status = PDCardGetSocket(pLsock->hSock.uSocket, &State);
            if (status != CERR_SUCCESS) {
                DEBUGMSG(ZONE_WARNING,
                 (TEXT("PCMCIA:CardModifyConfiguration PDCardGetSocket failed %d\r\n"),
                 status));
                return status;
            }
            State.fSocketCaps |= SOCK_CAP_KEEP_POWERED;
            status = PDCardSetSocket(pLsock->hSock.uSocket, &State);
            if (status != CERR_SUCCESS) {
                DEBUGMSG(ZONE_WARNING,
                 (TEXT("PCMCIA:CardModifyConfiguration PDCardSetSocket failed %d\r\n"),
                 status));
                return status;
            }
            pLsock->fFlags |= LOG_SOCK_FLAG_KEEP_POWERED;
        }
    } else {
        if (pLsock->fFlags & LOG_SOCK_FLAG_KEEP_POWERED) {
            pLsock->fFlags &= ~LOG_SOCK_FLAG_KEEP_POWERED;

            EnterCriticalSection(&v_SocketCrit);
            for (pTmp = v_Sockets[pLsock->hSock.uSocket].pLsock; pTmp != NULL; pTmp = pTmp->Next) {
                if (pTmp->fFlags & LOG_SOCK_FLAG_KEEP_POWERED)
                    break;
            }
            LeaveCriticalSection(&v_SocketCrit);
            if (pTmp == NULL) {
                status = PDCardGetSocket(pLsock->hSock.uSocket, &State);
                if (status != CERR_SUCCESS) {
                    DEBUGMSG(ZONE_WARNING,
                     (TEXT("PCMCIA:CardModifyConfiguration PDCardGetSocket failed %d\r\n"),
                     status));
                    return status;
                }
                State.fSocketCaps &= ~SOCK_CAP_KEEP_POWERED;
                status = PDCardSetSocket(pLsock->hSock.uSocket, &State);
                if (status != CERR_SUCCESS) {
                    DEBUGMSG(ZONE_WARNING,
                     (TEXT("PCMCIA:CardModifyConfiguration PDCardSetSocket failed %d\r\n"),
                     status));
                    return status;
                }
            }
        }
    }

    //
    // Use no unloading during suspend if requested
    //
    if (*fAttributes & CFG_ATTR_NO_SUSPEND_UNLOAD) {
        pLsock->fFlags |= LOG_SOCK_FLAG_NO_SUSPEND_UNLOAD;
        // Try to make insertion/removal a wake source if it isn't already,
        // and the socket is user accessible
        if (!EnableCSCWake(hSock.uSocket)) {
            pLsock->fFlags &= ~LOG_SOCK_FLAG_NO_SUSPEND_UNLOAD;
            *fAttributes &= ~CFG_ATTR_NO_SUSPEND_UNLOAD;
        }
    } else {
        if (pLsock->fFlags & LOG_SOCK_FLAG_NO_SUSPEND_UNLOAD) {
            bCSC = TRUE;
        }
        pLsock->fFlags &= ~LOG_SOCK_FLAG_NO_SUSPEND_UNLOAD;
    }

    // If CSC interrupts are a wake source, and the socket is user accessible
    // check if we need to maintain the wake source
    if (bCSC && !(v_Sockets[hSock.uSocket].fFlags & PHYS_SOCK_FLAG_NOT_USER_ACCESS)) {
        DisableCSCWake();
    }

    if (bIRQ) {
        DisableIRQWake();
    }

mod_cfg_err_exit:
    if (status != CERR_SUCCESS) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("PCMCIA:CardModifyConfiguration failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("PCMCIA:CardModifyConfiguration succeeded\r\n")));
    }
    return status;
}


//
// CardRequestConfiguration
//
// @doc DRIVERS
//
// @func    STATUS | CardRequestConfiguration | Configure socket and PC card interface type and voltage.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE, CERR_BAD_ARGS, CERR_BAD_SOCKET,
//          CERR_IN_USE, CERR_BAD_VCC, CERR_BAD_VPP or CERR_WRITE_FAILURE.
//
// @comm    Configure socket and PC card for interface type and voltage settings.
//          Power will be applied to the socket if it is currently off.  The values
//          specified in the parameter structure will be written to the card's
//          configuration registers.
// @xref    <t CARD_CONFIG_INFO> <f CardModifyConfiguration> <f CardReleaseConfiguration>
//
STATUS
CardRequestConfiguration(
    CARD_CLIENT_HANDLE hCardClient, // @parm Handle from <f CardRegisterClient>
    PCARD_CONFIG_INFO pParms        // @parm pointer to a <t CARD_CONFIG_INFO> structure.
    )
{
    PCLIENT_DRIVER pClient;
    PLOG_SOCKET pLsock;
    STATUS status;
    UINT8 uPIndex;
    PUINT8 pRegVal, pRegStr;
    UINT i;
    UINT8 uStatusReg;
    PPHYS_WINDOW pPhys;
    PLOG_WINDOW pLog;

    DEBUGMSG(ZONE_FUNCTION,
        (TEXT("PCMCIA:CardRequestConfiguration entered\r\n")));

    //
    // Perform some parameter checks first
    //
    if (pParms == NULL) {
        status = CERR_BAD_ARGS;
        goto req_cfg_exit;
    }

    if ((pClient = FindClient(hCardClient, TRUE, TRUE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto req_cfg_exit;
    }

    //
    // The socket being requested must already exist and not be in use by
    // someone else.
    //
    pLsock = I_FindSocket(pParms->hSocket);
    if (pLsock == NULL) {
        status = CERR_BAD_SOCKET;
        goto req_cfg_exit;
    }

    if ((pLsock->hOwner != 0) &&
        (pLsock->hOwner != pClient)) {
        status = CERR_IN_USE;
        goto req_cfg_exit;
    }

    pLsock->fCfgRegisters = 0;      // Clear configed registers
    pRegVal = &(pParms->uConfigReg);
    pRegStr = &(pLsock->COR_val);
    for (i = 0; i < NUM_REGISTERS; i++) {
        if (pParms->fRegisters & (1 << i)) {
            pLsock->fCfgRegisters |= (1 << i);
            *pRegStr = *pRegVal;
        }
        pRegStr++; pRegVal++;
    }

    pRegVal = &(pParms->IOBase[0]);
    if (pParms->fRegisters & CFG_REGISTER_EXREG) {
        for (i = 0; i < NUM_EXT_REGISTERS; i++) {
            if (pParms->fExtRegisters & (1 << i)) {
                pLsock->fCfgRegisters |= (1 << (i + NUM_REGISTERS));
                *pRegStr = *pRegVal;
            }
            pRegStr++; pRegVal++;
        }
    }

    // Power adapter back up
    PcmciaPowerOn(pParms->hSocket.uSocket);

#ifdef EDGE_INTR
    pLsock->COR_val = pParms->uConfigReg &= ~FCR_COR_LEVEL_IREQ;   // used by CardResetFunction
#else
    pLsock->COR_val = pParms->uConfigReg |= FCR_COR_LEVEL_IREQ;   // used by CardResetFunction
#endif
    uStatusReg = FCR_FCSR_INTR_ACK;    // used by ISR
    //
    // Set the FCR_FCSR_IO_IS_8 bit according to the data path width of this
    // client's windows.
    //
    EnterCriticalSection(&v_WindowCrit);
    pPhys = v_pWinList;
    while (pPhys) {
        if (pPhys->uSock == pParms->hSocket.uSocket) {
            pLog = pPhys->pLog;
            while (pLog) {
                if (pLog->hOwner == pClient) {
                    if (pPhys->fFlags & PHYS_WIN_FLAG_16BIT_MODE) {
        DEBUGMSG(ZONE_MEM,
           (TEXT("PCMCIA:CardRequestConfiguration - assuming 16 bit I/O\r\n")));
                        goto req_cfg_16bit;
                    }
                }
                pLog = pLog->Next;
            }
        }
        pPhys = pPhys->Next;
    }
    //
    // No 16 bit windows used by this client, assume using 8 bit.
    //
    if (!(pParms->fAttributes & CFG_ATTR_NO_IO_IS_8))
        uStatusReg |= FCR_FCSR_IO_IS_8;
    DEBUGMSG(ZONE_MEM,
        (TEXT("PCMCIA:CardRequestConfiguration - assuming 8 bit I/O\r\n")));

req_cfg_16bit:
    LeaveCriticalSection(&v_WindowCrit);

    pLsock->FCSR_val = pParms->uStatusReg |= uStatusReg;

    //
    // Map voltages to power entry indexes
    //
    uPIndex = FindPowerEntry(PWR_SUPPLY_VCC, pParms->uVcc);
    if (uPIndex == BAD_VOLTAGE_INDEX) {
        status = CERR_BAD_VCC;
        DEBUGMSG(ZONE_WARNING,
            (TEXT("PCMCIA:CardRequestConfiguration bad VCC specified\r\n")));
        goto req_cfg_exit;
    }
    pLsock->fVcc = uPIndex & SOCK_VCC_LEVEL_MASK;

    uPIndex = FindPowerEntry(PWR_SUPPLY_VPP1, pParms->uVpp1);
    if (uPIndex == BAD_VOLTAGE_INDEX) {
        status = CERR_BAD_VPP;
        DEBUGMSG(ZONE_WARNING,
            (TEXT("PCMCIA:CardRequestConfiguration bad VPP1 specified\r\n")));
        goto req_cfg_exit;
    }
    pLsock->uVpp1 = uPIndex;

    uPIndex = FindPowerEntry(PWR_SUPPLY_VPP2, pParms->uVpp2);
    if (uPIndex == BAD_VOLTAGE_INDEX) {
        status = CERR_BAD_VPP;
        DEBUGMSG(ZONE_WARNING,
            (TEXT("PCMCIA:CardRequestConfiguration bad VPP2 specified\r\n")));
        goto req_cfg_exit;
    }
    pLsock->uVpp2 = uPIndex;

    pLsock->fInterfaceType = pParms->fInterfaceType;

    //
    // Use the configuration register values that are present in the client's
    // config info to update the card.
    //
    if (pLsock->pRegWin == NULL) {
        DEBUGMSG(ZONE_WARNING,
         (TEXT("PCMCIA:CardRequestConfiguration no config register window\r\n")));
        if (pParms->fInterfaceType & CFG_IFACE_MEMORY_IO) {
            status = CERR_WRITE_FAILURE;
            goto req_cfg_exit;
//        } else {
//            goto req_cfg_no_reg;  // allow memory only to set state
        }
    }

//req_cfg_no_reg:
    
    //
    // Enable SPKR out on the socket controller if requested
    //
    pLsock->fControlCaps = 0;
    if ((pParms->fRegisters & CFG_REGISTER_STATUS) &&
        (pParms->uStatusReg & FCR_FCSR_AUDIO)) {
        pLsock->fControlCaps |= SOCK_ENABLE_SPEAKER;
    }

    pLsock->fFlags |= OWNER_FLAG_CONFIG;
    pLsock->hOwner = pClient;

    CardModifyConfiguration(hCardClient, pLsock->hSock, &pParms->fAttributes);

    status = ConfigureLogSock(pLsock);

    // Make sure to configure the socket first, else the IREQ thread may stomp on power settings
    if ((pParms->fAttributes & CFG_ATTR_IRQ_STEERING) &&
        (pLsock->fFlags & OWNER_FLAG_INTERRUPT)) {
        SetEvent(v_IREQEvent);
    }

    status = CardReadAttrByte(pLsock->pRegWin,1,&uPIndex);
    if (status == CERR_SUCCESS) {
        status = CardReadAttrByte(pLsock->pRegWin,0,&uPIndex);
    } if (status == CERR_SUCCESS) {

        DEBUGMSG(ZONE_WARNING,
            (TEXT("CardRequestConfiguration COR = 0x%x, expected 0x%x\r\n"),
            uPIndex, pParms->uConfigReg));
    }

    if (status != CERR_SUCCESS) {
        DEBUGMSG(ZONE_WARNING,
            (TEXT("CardRequestConfiguration CardReadAttrByte failed %d\r\n"),
            status));
    }

req_cfg_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("PCMCIA:CardRequestConfiguration failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("PCMCIA:CardRequestConfiguration succeeded\r\n")));
    }
#endif
    return status;
}   // CardRequestConfiguration


//
// CardReleaseConfiguration
//
// @func    STATUS | CardReleaseConfiguration | Place socket and PC card into memory only interface.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE, CERR_BAD_SOCKET, CERR_IN_USE
//          or CERR_WRITE_FAILURE.
//
// @comm    Configure socket and PC card for memory only and also remove power if no other
//          clients are currently using the card.
// @xref    <f CardModifyConfiguration> <f CardRequestConfiguration> <t CARD_SOCKET_HANDLE>
//
STATUS
CardReleaseConfiguration(
    CARD_CLIENT_HANDLE hCardClient, // @parm Handle from <f CardRegisterClient>
    CARD_SOCKET_HANDLE hSock        // @parm Socket/function identifier
    )
{
    PCLIENT_DRIVER pClient;
    PLOG_SOCKET pLsock, pTmp;
    PDCARD_SOCKET_STATE State;
    PDCARD_ADAPTER_STATE AdapterState;
    STATUS status;
    BYTE uReg;
    UINT16 fAttributes = 0;

    DEBUGMSG(ZONE_FUNCTION,
        (TEXT("PCMCIA:CardReleaseConfiguration entered\r\n")));

    //
    // Check the parameters
    //
    if ((pClient = FindClient(hCardClient, TRUE, TRUE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto rel_cfg_exit;
    }

    pLsock = I_FindSocket(hSock);
    if (pLsock == NULL) {
        status = CERR_BAD_SOCKET;
        goto rel_cfg_exit;
    }

    if (pLsock->hOwner != pClient) {
        status = CERR_IN_USE;
        goto rel_cfg_exit;
    }

    // Card is not configured, so we're done
    if (!(pLsock->fFlags & OWNER_FLAG_CONFIG)) {
        status = CERR_SUCCESS;
        goto rel_cfg_exit;
    }

    CardModifyConfiguration(hCardClient, pLsock->hSock, &fAttributes);

    pLsock->fFlags &= ~(OWNER_FLAG_CONFIG);
    if ((pLsock->fFlags & OWNER_FLAGS) == 0) {
        pLsock->hOwner = 0;
    }

    //
    // Turn off IREQ interrupts, if no other configured functions
    //
    EnterCriticalSection(&v_SocketCrit);
    for (pTmp = v_Sockets[pLsock->hSock.uSocket].pLsock; pTmp != NULL; pTmp = pTmp->Next) {
        if (pTmp->fFlags & OWNER_FLAG_CONFIG) break;
    }
    LeaveCriticalSection(&v_SocketCrit);
    if (pTmp == NULL) {
        status = PDCardGetSocket(hSock.uSocket, &State);
        if (status == CERR_SUCCESS) {
            State.fInterruptEvents = INITIAL_SOCKET_EVENTS;
            State.fInterfaceType = CFG_IFACE_MEMORY;
            State.fIREQRouting &= ~SOCK_IREQ_ENABLE;
            State.fControlCaps &= ~SOCK_ENABLE_SPEAKER;
            status = PDCardSetSocket(hSock.uSocket, &State);
        }
        if (status) {
            goto rel_cfg_poweroff;
        }
    }

    //
    // Avoid accessing PCMCIA space when the bus is not powered.
    //
    if (v_Sockets[hSock.uSocket].PowerState != POWER_NORMAL) {
        goto rel_cfg_poweroff;
    }

    AdapterState = 0;
    PDCardGetAdapter(hSock.uSocket, &AdapterState);
    if (AdapterState & (ADP_STATE_POWERDOWN|ADP_STATE_POWEROFF)) {
        goto rel_cfg_exit;
    }

    //
    // Set card to memory only interface (Use configuration 0)
    //
    if (pLsock->pRegWin == NULL) {
        status = CERR_WRITE_FAILURE;
        goto rel_cfg_poweroff;
    }

    //
    // Place card in power down mode
    //
    status = CardReadAttrByte(pLsock->pRegWin, FCR_OFFSET_FCSR, &uReg);
    if (status != CERR_SUCCESS) goto rel_cfg_poweroff;
    uReg |= FCR_FCSR_PWR_DOWN;
    status = CardWriteAttrByte(pLsock->pRegWin, FCR_OFFSET_FCSR, uReg);

rel_cfg_poweroff:
    //
    // Power off the adapter if this client is the only one with any windows on
    // this socket.
    //
    PcmciaPowerOff(hSock.uSocket, FALSE, hCardClient);

rel_cfg_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("PCMCIA:CardReleaseConfiguration failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("PCMCIA:CardReleaseConfiguration succeeded\r\n")));
    }
#endif
    return status;
}   // CardReleaseConfiguration


//
// This function gets called by the kernel (RegisterDevice installs it)
// and cannot block or yield or cause any kind of traps.
//
STATUS
PowerUp(
    DWORD dwData
    )
{
    PDCARD_ADAPTER_STATE AdapterState;
    PLOG_SOCKET pLsock;
    UINT i;

    for (i = 0; i < (UINT8)v_cSockets; i++) {
        AdapterState = ADP_STATE_KERNEL_MODE;
        PDCardGetAdapter(i, &AdapterState);

        //
        // Put the PCMCIA system in low power mode
        //
        AdapterState |= ADP_STATE_KERNEL_MODE;

        for (pLsock = v_Sockets[i].pLsock; pLsock != NULL; pLsock = pLsock->Next) {
            if (pLsock->fFlags & LOG_SOCK_FLAG_KEEP_POWERED)
                break;
        }
        if (pLsock == NULL || (AdapterState & ADP_STATE_POWEROFF)) {
            AdapterState |= ADP_STATE_POWERDOWN;
        }

        AdapterState &= ~(ADP_STATE_POWEROFF|ADP_STATE_NODETECT|ADP_STATE_NOIRQ);
        PDCardSetAdapter(i, &AdapterState);
    }

    //
    // Cause NK to signal our StatusChangeThread
    //
    SetInterruptEvent(gIntrPcmciaState);

    return CERR_SUCCESS;
}   // PowerUp

//
// This function gets called by the kernel (RegisterDevice installs it)
// and cannot block or yield or cause any kind of traps.
//
STATUS
PowerDown(
    DWORD dwData
    )
{
    PDCARD_ADAPTER_STATE AdapterState;
    UINT i;
    PLOG_SOCKET pLsock;

    for (i = 0; i < (UINT8)v_cSockets; i++) {
        AdapterState = ADP_STATE_KERNEL_MODE;
        PDCardGetAdapter(i, &AdapterState);

        AdapterState |= ADP_STATE_KERNEL_MODE;

        // If a log sock wants to keep powered and has not already been powered down
        // We won't need to set ADP_STATE_POWEROFF
        for (pLsock = v_Sockets[i].pLsock; pLsock != NULL; pLsock = pLsock->Next) {
            if ((pLsock->fFlags & LOG_SOCK_FLAG_KEEP_POWERED) &&
                !(pLsock->FCSR_val & FCR_FCSR_PWR_DOWN))
                break;
        }
        if (pLsock == NULL) {
            AdapterState |= ADP_STATE_POWEROFF;
            v_Sockets[i].PowerState = POWER_OFF;
        } else {
            v_Sockets[i].PowerState = POWER_KEPT;
        }

        // If socket does want to be unloaded and no IRQ wakeups
        // disable insertion/removal interrupts
        for (pLsock = v_Sockets[i].pLsock; pLsock != NULL; pLsock = pLsock->Next) {
            if ((pLsock->fFlags & LOG_SOCK_FLAG_NO_SUSPEND_UNLOAD) ||
                (pLsock->fFlags & LOG_SOCK_FLAG_IRQ_WAKEUP))
                break;
        }
        if (pLsock == NULL) {
            AdapterState |= ADP_STATE_NODETECT;
        }

        // disable IRQs if we don't want IRQ wakeups, or we're powered down
        for (pLsock = v_Sockets[i].pLsock; pLsock != NULL; pLsock = pLsock->Next) {
            if ((pLsock->fFlags & LOG_SOCK_FLAG_IRQ_WAKEUP) &&
                !(pLsock->FCSR_val & FCR_FCSR_PWR_DOWN))
                break;
        }
        if (pLsock == NULL) {
            AdapterState |= ADP_STATE_NOIRQ;
        }

        PDCardSetAdapter(i, &AdapterState);
    }

    return CERR_SUCCESS;
}   // PowerDown


//
// PcmciaPowerOn - cause PCMCIA system to be placed in full power mode to
// enable PC card access.
//
VOID
PcmciaPowerOn(UINT uSocket)
{
    PDCARD_ADAPTER_STATE AdapterState;
    DWORD status;
    DEBUGMSG(ZONE_FUNCTION|ZONE_POWER,
             (TEXT("PCMCIA:Entering PcmciaPowerOn (socket: %u)\n\r"),uSocket));

    //
    // Avoid powering an empty socket
    //
    if (!IsCardInserted(uSocket)) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_POWER,
            (TEXT("PCMCIA:Leaving PcmciaPowerOn (no pccard)\n\r")));
        return;
    }

    //
    // Fully power on the PCMCIA system
    //
    EnterCriticalSection(&v_PowerCrit);
    AdapterState = 0;
    PDCardGetAdapter(uSocket, &AdapterState);
    if (AdapterState & (ADP_STATE_POWERDOWN|ADP_STATE_POWEROFF)) {
        AdapterState &= ~(ADP_STATE_POWERDOWN|ADP_STATE_POWEROFF);
        if ((status = PDCardSetAdapter(uSocket, &AdapterState)) == CERR_SUCCESS)
            DEBUGMSG(ZONE_WARNING|ZONE_POWER,
                (TEXT("PCMCIA:PcmciaPowerOn: socket %u powered up\n\r"),
                uSocket));
        else
            DEBUGMSG(ZONE_WARNING|ZONE_ERROR|ZONE_POWER,
                (TEXT("PCMCIA:Error %d powering up PCMCIA socket %u\n\r"),
                status,uSocket));
        PDCardResetSocket(uSocket);
    }
    LeaveCriticalSection(&v_PowerCrit);

    DEBUGMSG(ZONE_FUNCTION|ZONE_POWER,
        (TEXT("PCMCIA:Leaving PcmciaPowerOn\n\r")));

}   // PcmciaPowerOn


//
// PcmciaPowerOff - Power off PCMCIA adapter.  Unless force parameter is
// set, only powerdown adapter if there are no active client windows. Use
// the ADP_STATE_POWERDOWN setting, so that card insertions/removals are
// still detected.
//
VOID
PcmciaPowerOff(
    UINT uSocket,
    BOOL Force,
    CARD_CLIENT_HANDLE hClient
    )
{
    PDCARD_ADAPTER_STATE AdapterState;
    PDCARD_SOCKET_STATE State;
    DWORD status;
    PLOG_SOCKET pLsock;
    PLOG_WINDOW pLog;
    PPHYS_WINDOW pPhys = v_pWinList;
    PCALLBACK_STRUCT pEvent;
    PCLIENT_DRIVER pClient;
    BOOL bFound;

    DEBUGMSG(ZONE_FUNCTION|ZONE_POWER,
        (TEXT("PCMCIA:Entering PcmciaPowerOff (sock: %u, force: %u)\n\r"),
        uSocket,Force));

    //
    // Unless we are forced, check to make sure no client windows are
    // present before we shut down.
    //
    EnterCriticalSection(&v_PowerCrit);
    if (Force == FALSE) {
        if (v_Sockets[uSocket].fFlags & PHYS_SOCK_FLAG_ACTIVE) {
            DEBUGMSG(ZONE_POWER|ZONE_WARNING,
                (TEXT("PCMCIA:PcmciaPowerOff(%u) -- socket is active, not powering down\n\r"),
                uSocket));
            LeaveCriticalSection(&v_PowerCrit);
            return;
        }

        EnterCriticalSection(&v_SocketCrit);
        EnterCriticalSection(&v_WindowCrit);
        pClient = FindClient(hClient, TRUE, TRUE);

        // Check if the client has any functions in the socket that are configured and not powered down
        if (pClient != CARDSERV_CLIENT_HANDLE) {
            for (pLsock = v_Sockets[uSocket].pLsock; pLsock != NULL; pLsock = pLsock->Next) {
                if (pLsock->hOwner == pClient &&
                    (pLsock->fFlags & OWNER_FLAG_CONFIG) &&
                    !(pLsock->FCSR_val & FCR_FCSR_PWR_DOWN)) {
                    pClient = CARDSERV_CLIENT_HANDLE;
                    break;
                }
            }
        }

        for (; pPhys != NULL; pPhys = pPhys->Next) {
            if (pPhys->uSock != (UINT8)uSocket) continue;
            pLog = pPhys->pLog;
            while (pLog) {
                if ((pLog->hOwner != CARDSERV_CLIENT_HANDLE) &&
                    (pLog->hOwner != pClient)) {

                    // Check if this window is owned by a client that has requested a configuration
                    // on this socket
                    // If it hasn't, then assume that the client is active and wants the socket powered
                    // If it has, check if any of the configurations are still active
                    // If they are, then keep the socket powered
                    bFound = FALSE;                   
                    for (pLsock = v_Sockets[pPhys->uSock].pLsock; pLsock != NULL; pLsock = pLsock->Next) {
                        if (!(pLsock->fFlags & OWNER_FLAG_CONFIG) || pLsock->hOwner != pLog->hOwner)
                            continue;
                        if (!(pLsock->FCSR_val & FCR_FCSR_PWR_DOWN)) break;
                        bFound = TRUE;
                    }

                    if (!bFound || pLsock != NULL) {
                        DEBUGMSG(ZONE_POWER|ZONE_WARNING,
                            (TEXT("PCMCIA:PcmciaPowerOff(%u) -- Client window present, not powering down\n\r"),
                            uSocket));
                        LeaveCriticalSection(&v_WindowCrit);
                        LeaveCriticalSection(&v_SocketCrit);
                        LeaveCriticalSection(&v_PowerCrit);
                        return;
                    }
                }

                pLog = pLog->Next;
            }
        }
        LeaveCriticalSection(&v_WindowCrit);
        LeaveCriticalSection(&v_SocketCrit);

        //
        // Also, don't power down the socket if there are any CE_CARD_INSERTION
        // notices for it.
        //
        EnterCriticalSection(&v_CallbackCrit);
        pEvent = v_CallbackHead;
        while (pEvent) {
            if ((pEvent->MajorEvent == CE_CARD_INSERTION) &&
                (pEvent->hSock.uSocket == uSocket)) {
                DEBUGMSG(ZONE_POWER|ZONE_WARNING,
                    (TEXT("PCMCIA:PcmciaPowerOff(%u) -- more CE_CARD_INSERTIONs, not powering down\n\r"),
                    uSocket));
                LeaveCriticalSection(&v_CallbackCrit);
                LeaveCriticalSection(&v_PowerCrit);
                return;
            }
            pEvent = pEvent->Next;
        }
        LeaveCriticalSection(&v_CallbackCrit);
    }

    //
    // Disable any interrupts except card detect/lock
    //
    if (PDCardGetSocket(uSocket, &State) == CERR_SUCCESS) {
        State.fInterruptEvents = INITIAL_SOCKET_EVENTS;
        PDCardSetSocket(uSocket, &State);
    }

    //
    // Power off the PCMCIA system
    //
    AdapterState = 0;
    PDCardGetAdapter(uSocket, &AdapterState);
    if (!(AdapterState & ADP_STATE_POWERDOWN)) {
          AdapterState &= ~ADP_STATE_POWEROFF;
        AdapterState |= ADP_STATE_POWERDOWN;
        if ((status = PDCardSetAdapter(uSocket, &AdapterState)) == CERR_SUCCESS)
            DEBUGMSG(ZONE_WARNING|ZONE_POWER,
                (TEXT("PCMCIA:PcmciaPowerOff: socket %u powered down\n\r"),
                uSocket));
        else
            DEBUGMSG(ZONE_WARNING|ZONE_ERROR,
                (TEXT("PCMCIA:Error %d powering down PCMCIA socket %u\n\r"),
                status,uSocket));
    }

    LeaveCriticalSection(&v_PowerCrit);
    DEBUGMSG(ZONE_FUNCTION,(TEXT("PCMCIA:Leaving PcmciaPowerOff\n\r")));

}   // PcmciaPowerOff


//
// CardAccessConfigurationRegister
//
// @func    STATUS | CardAccessConfigurationRegister | Access PCMCIA function configuration
//          registers.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE, CERR_BAD_SOCKET, CERR_IN_USE,
//          CERR_BAD_OFFSET, or CERR_WRITE_FAILURE or CERR_BAD_ARGS.
//
// @comm    Read or write value from/to PCMCIA function configuration registers.
//          This function may be called before or after card registration, so allow
//          a NULL param for the client handle.  Note that cards may not support all
//          of the FCRs (an unsupported register will return CERR_BAD_OFFSET).
// @xref    <t CARD_CLIENT_HANDLE> <t CARD_SOCKET_HANDLE>
//

STATUS
CardAccessConfigurationRegister(
    CARD_CLIENT_HANDLE hCardClient, // @parm Handle from <f CardRegisterClient> (may be NULL)
    CARD_SOCKET_HANDLE hSock,       // @parm Socket/function identifier
    UINT8 rw_flag,                  // @parm Read/Write flag
    UINT8 offset,                   // @parm Config register offset
    UINT8 *pValue                   // @parm Address of value to read/write
    )
{
    PLOG_SOCKET pLsock;
    STATUS status = CERR_SUCCESS;
    PCLIENT_DRIVER pClient;

    DEBUGMSG(ZONE_FUNCTION,
        (TEXT("PCMCIA:CardAccessConfigurationRegister entered, rw: %d reg: %d val: 0x%X\r\n"),
        rw_flag,offset,*pValue));

    //
    // Check the parameters
    //
    if (pValue == NULL) {
        status = CERR_BAD_ARGS;
        goto err_exit;
    }

    pLsock = I_FindSocket(hSock);
    if (pLsock == NULL) {
        status = CERR_BAD_SOCKET;
        goto err_exit;
    }

    if (pLsock->hOwner && (rw_flag == CARD_FCR_WRITE)) {
        if (hCardClient == NULL) {
            pClient = pLsock->hOwner;
        } else {
            if ((pClient = FindClient(hCardClient, TRUE, TRUE)) == NULL) {
                status = CERR_BAD_HANDLE;
                goto err_exit;
            } else if (pLsock->hOwner != pClient) {
                status = CERR_IN_USE;
                goto err_exit;
            }
        }
        if (!IsValidClient((PCLIENT_DRIVER)pClient)) {
            status = CERR_BAD_HANDLE;
            goto err_exit;
        }
    }

    // Make sure the card supports this register
#ifdef DEBUG
    if (!(pLsock->fRegisters & (1 << offset))) {
        // A very common use of this function is to get at registers
        // which are non-standard.  In that case, they won't be in fRegisters.
        // So don't fail here, jsut issue a warning.
        DEBUGMSG(ZONE_ERROR|ZONE_WARNING,
            (TEXT("PCMCIA:Unsupported register %d (mask 0x%X)\n\r"),
            offset,pLsock->fRegisters));
    }
#endif

    if (rw_flag == CARD_FCR_READ) {
        status = CardReadAttrByte(pLsock->pRegWin,offset,pValue);
    } else {
        // Save our shadowed registers
        if (offset >= 0 && offset < (NUM_REGISTERS + NUM_EXT_REGISTERS)) {
            *((&pLsock->COR_val) + offset) = *pValue;
        }
        status = CardWriteAttrByte(pLsock->pRegWin,offset,*pValue);
    }

err_exit:
    if (status != CERR_SUCCESS) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("PCMCIA:CardAccessConfigurationRegister failed %d\r\n"),
            status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("PCMCIA:CardAccessConfigurationRegister succeeded\r\n")));
    }
    return status;

}   // CardAccessConfigurationRegister

//
// CardPowerOn
//
// @doc DRIVERS
//
// @func    STATUS | CardPowerOn | Request that power be reapplied to a socket
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_SOCKET, CERR_BAD_HANDLE, or CERR_IN_USE
//
// @comm    A client that has already requested a configuration can ask that power be
//          reapplied to the socket.  If CardPowerOff has not been called and the FCR_FCSR_POWER_DWN
//          bit is not set, this function will do nothing.  Otherwise it will restore any windows
//          disabled during power down, and restore the configuration of the socket set by
//          CardRequestConfiguration
// @xref    <f CardPowerOff>
//
STATUS
CardPowerOn(
    CARD_CLIENT_HANDLE hCardClient, // @parm Handle from <f CardRegisterClient> (may be NULL)
    CARD_SOCKET_HANDLE hSock        // @parm Socket/function identifier
    )
{
    PLOG_SOCKET pLsock;
    STATUS status = CERR_SUCCESS;
    PCLIENT_DRIVER pClient;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("PCMCIA:CardPowerOn entered\r\n")));

    pLsock = I_FindSocket(hSock);
    if (pLsock == NULL || !(pLsock->fFlags & OWNER_FLAG_CONFIG)) {
        status = CERR_BAD_SOCKET;
        goto cpon_err_exit;
    }

    if (hCardClient == NULL ||
        (pClient = FindClient(hCardClient, TRUE, TRUE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto cpon_err_exit;
    } else if (pLsock->hOwner != pClient) {
        status = CERR_IN_USE;
        goto cpon_err_exit;
    }

    EnterCriticalSection(&v_PowerCrit);
    if (pLsock->FCSR_val & FCR_FCSR_PWR_DOWN) {
        pLsock->FCSR_val &= ~FCR_FCSR_PWR_DOWN;

        EnterCriticalSection(&v_WindowCrit);
        status = RestoreWindowState(hSock.uSocket);
        LeaveCriticalSection(&v_WindowCrit);

        if (status == CERR_SUCCESS) {
            PcmciaPowerOn(hSock.uSocket);
            ConfigureLogSock(pLsock);
            if (pLsock->fFlags & LOG_SOCK_FLAG_IRQ_WAKEUP) {
                if (!EnableCSCWake(hSock.uSocket) || !EnableIRQWake()) {
                    // We shouldn't get here, since both Enable() calls worked in CardModifyConfig
                    // ...but if we do, disable irq wakeup
                    pLsock->fFlags &= ~LOG_SOCK_FLAG_IRQ_WAKEUP;
                    DisableCSCWake();
                }
            }

            // Resignal the IREQThread to reenable interrupts
            if (pLsock->fFlags & OWNER_FLAG_INTERRUPT) {
                SetEvent(v_IREQEvent);
            }
        }
    }
    LeaveCriticalSection(&v_PowerCrit);

cpon_err_exit:
    if (status != CERR_SUCCESS) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("PCMCIA:CardPowerOn failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("PCMCIA:CardPowerOn succeeded\r\n")));
    }
    return status;
}

//
// CardPowerOff
//
// @doc DRIVERS
//
// @func    STATUS | CardPowerOff | Request that the socket be depowered
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_SOCKET, CERR_BAD_HANDLE, or CERR_IN_USE
//
// @comm    A client that has already requested a configuration can ask that a socket be
//          powered down.  The FCR_FCSR_POWER_DWN bit will be set, and the socket will be
//          powered down if no other drivers are using it.
// @xref    <f CardPowerOn>
//
STATUS
CardPowerOff(
    CARD_CLIENT_HANDLE hCardClient, // @parm Handle from <f CardRegisterClient> (may be NULL)
    CARD_SOCKET_HANDLE hSock        // @parm Socket/function identifier
    )
{
    PLOG_SOCKET pLsock;
    STATUS status = CERR_SUCCESS;
    PCLIENT_DRIVER pClient;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("PCMCIA:CardPowerOff entered\r\n")));

    pLsock = I_FindSocket(hSock);
    if (pLsock == NULL || !(pLsock->fFlags & OWNER_FLAG_CONFIG)) {
        status = CERR_BAD_SOCKET;
        goto cpoff_err_exit;
    }

    if (hCardClient == NULL ||
        (pClient = FindClient(hCardClient, TRUE, TRUE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto cpoff_err_exit;
    } else if (pLsock->hOwner != pClient) {
        status = CERR_IN_USE;
        goto cpoff_err_exit;
    }

    EnterCriticalSection(&v_PowerCrit);
    if (!(pLsock->FCSR_val & FCR_FCSR_PWR_DOWN)) {
        UINT8 uFSCR;

        pLsock->FCSR_val |= FCR_FCSR_PWR_DOWN;
        if (pLsock->pRegWin != NULL &&
            (pLsock->fRegisters & CFG_REGISTER_STATUS)) {
            CardReadAttrByte(
                pLsock->pRegWin,
                FCR_OFFSET_FCSR,
                &uFSCR);
            uFSCR |= FCR_FCSR_PWR_DOWN;
            CardWriteAttrByte(pLsock->pRegWin,FCR_OFFSET_FCSR, uFSCR);
        }
        PcmciaPowerOff(hSock.uSocket, FALSE, pClient);
        DisableCSCWake();
        DisableIRQWake();
    }
    LeaveCriticalSection(&v_PowerCrit);

cpoff_err_exit:
    if (status != CERR_SUCCESS) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("PCMCIA:CardPowerOff failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("PCMCIA:CardPowerOff succeeded\r\n")));
    }
    return status;
}


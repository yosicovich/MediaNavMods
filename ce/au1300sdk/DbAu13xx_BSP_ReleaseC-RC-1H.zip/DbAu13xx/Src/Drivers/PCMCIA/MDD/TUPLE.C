//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

    tuple.c

Abstract:

    This file implements the PCMCIA model device driver CIS tuple parsing
    functions.  This is provided as a sample to platform writers and is
    expected to be able to be used without modification on most (if not
    all) hardware platforms.

Functions:

    CheckTupleOffset
    I_ReadAttrByte()
    I_ReadAttrWord()
    I_TupleMapWindow()
    I_TupleGetWindow()
    I_ReadLink()
    I_CheckNextTuple()
    I_CheckNextLink()
    I_GetNextTuple()
    I_GetDesiredTuple()
    CardGetNextTuple()
    CardGetFirstTuple()
    CardGetTupleData()
    VarToFixed()
    ParseConfig()
    ConvertVoltage()
    ParseVoltageDescr()
    ParseCfTable()
    CardGetParsedTuple()

Notes:


--*/


#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <pcmcia.h>
#include <tuple.h>
#include <extern.h>

#define MAX_TUPLE_MISSES 500
#define LINK_TARGET_SIG ('C'+('I'<<8)+('S'<<16))
#define TUPLE_WINDOW_SIZE   8192
//#define TUPLE_WINDOW_SIZE   16384
#define TUPLE_OFFSET_LIMIT  65536

//
// Check if the tuple offset fits in the current window and try to remap
// the window if it doesn't.
//
STATUS
CheckTupleOffset(
    UINT Address,
    PCARD_TUPLE_PARMS pParms
    )
{
    PLOG_WINDOW  pWin;
    PPHYS_WINDOW pPhys;
    PDCARD_WINDOW_STATE WinState;
    STATUS status;
    UINT CardOffset;
    UINT8 attr;

    if (pParms->fFlags & TUPLE_FLAG_COMMON) {
        pWin = v_Sockets[pParms->hSocket.uSocket].pCmnWin;
        CardOffset = Address;
        attr = 0;
    } else {
        pWin = v_Sockets[pParms->hSocket.uSocket].pAttrWin;
        CardOffset = Address*2;
        attr = WIN_STATE_ATTRIBUTE;
    }
    pPhys = pWin->pPhys;

    //
    // If we can't change the window offset, then just do a static check
    //
    if (!(pPhys->fOtherCaps & MEM_CAP_PRG_BASE)) {
        if (CardOffset >= TUPLE_WINDOW_SIZE) {
            return CERR_READ_FAILURE;
        }
        return CERR_SUCCESS;
    }

    if ((CardOffset < (pWin->uReqOffset + pWin->uReqSize)) &&
        (CardOffset >= pWin->uReqOffset)) {
        return CERR_SUCCESS;
    }

    if (CardOffset > TUPLE_OFFSET_LIMIT) {
        return CERR_READ_FAILURE;
    }

DEBUGMSG(ZONE_PDD,
    (TEXT("CheckTupleOffset remapping for CardOffset = 0x%x\r\n"),
    CardOffset));

    //
    // We need to remap!
    //
    status = PDCardGetWindow(pPhys->uWindow, &WinState);
    if (status != CERR_SUCCESS) {
        return CERR_READ_FAILURE;
    }

    pWin->uReqOffset = CardOffset & ~(TUPLE_WINDOW_SIZE - 1);
    pPhys->uOffset = WinState.uOffset = pWin->uReqOffset;
    pPhys->uSize = WinState.uSize = TUPLE_WINDOW_SIZE;
    WinState.fState &= ~WIN_STATE_ATTRIBUTE;
    WinState.fState |= attr;
    if (attr) {
        pPhys->fFlags |= PHYS_WIN_FLAG_ATTR_MODE;
    } else {
        pPhys->fFlags &= ~PHYS_WIN_FLAG_ATTR_MODE;
    }
    status = PDCardSetWindow(pPhys->uWindow, &WinState);
    if (status != CERR_SUCCESS) {
        return CERR_READ_FAILURE;
    }
    return CERR_SUCCESS;
}


//
// Read next byte from CIS (may be either in common or attribute space).
//
STATUS
I_ReadAttrByte(
    PCHAR * pAttr,
    PCARD_TUPLE_PARMS pParms,
    UINT32 uOffset,
    UINT8 * pByte
    )
{
    PLOG_WINDOW  pWin;
    STATUS status;
    UINT Address = pParms->uCISOffset+uOffset;

    status = CheckTupleOffset(Address, pParms);
    if (status != CERR_SUCCESS) {
        DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,(
            TEXT("I_ReadAttrByte returning %d (offset = %d)\r\n"),
            status, Address));
        return status;
    }

    if (pParms->fFlags & TUPLE_FLAG_COMMON) {
        pWin = v_Sockets[pParms->hSocket.uSocket].pCmnWin;
        return CardReadCmnByte(*pAttr, Address - pWin->uReqOffset, pByte);
    } else {
        pWin = v_Sockets[pParms->hSocket.uSocket].pAttrWin;
        return CardReadAttrByte(*pAttr, Address - pWin->uReqOffset/2, pByte);
    }
}   // I_ReadAttrByte


//
// Read a 4 byte chunk of the CIS as a little endian word.
//
STATUS
I_ReadAttrWord(
    PCHAR *pAttr,
    PCARD_TUPLE_PARMS pParms,
    UINT32 uOffset,
    UINT * pWord
    )
{
    PLOG_WINDOW  pWin;
    UINT uTmp = 0;
    UINT i = pParms->uCISOffset+uOffset+3;    // start with high order byte
    UINT j = 4;
    STATUS status;
    UINT8 uByte;

    status = CheckTupleOffset(i, pParms);
    if (status != CERR_SUCCESS) {
        DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,(
            TEXT("I_ReadAttrWord returning %d (offset = %d)\r\n"), status, i));
        return status;
    }
    if (pParms->fFlags & TUPLE_FLAG_COMMON) {
        pWin = v_Sockets[pParms->hSocket.uSocket].pCmnWin;
        i -= pWin->uReqOffset;
    } else {
        pWin = v_Sockets[pParms->hSocket.uSocket].pAttrWin;
        i -= pWin->uReqOffset/2;
    }

    while (j) {
        uTmp <<= 8;
        if (pParms->fFlags & TUPLE_FLAG_COMMON) {
            status = CardReadCmnByte(*pAttr, i, &uByte);
        } else {
            status = CardReadAttrByte(*pAttr, i, &uByte);
        }
        if (status) {
            return status;
        }
        uTmp += (UINT)uByte;

        j--;
        i--;
    }
    *pWord = uTmp;

    return CERR_SUCCESS;
}   // I_ReadAttrWord


//
// I_TupleMapWindow maps a logical window associated with a socket to a
// virtual memory region.
//
PVOID
I_TupleMapWindow(
    PPHYS_WINDOW pPhys,
    PCARD_TUPLE_PARMS pParms
    )
{
    PDCARD_WINDOW_STATE WinState;
    PLOG_WINDOW pWin;
    STATUS status;
    UINT addr = 0;      // Beginning of attribute space.

    //
    // If we can't change the window offset, then just do a static check
    //
    if (pPhys->fOtherCaps & MEM_CAP_PRG_BASE) {
        DEBUGMSG(ZONE_PDD, (TEXT("I_TupleMapWindow remapping for CardOffset = 0x0\r\n")));

        //
        // We need to remap!
        //
        status = PDCardGetWindow(pPhys->uWindow, &WinState);
        if (status != CERR_SUCCESS) {
            return NULL;
        }

        //
        // We'll set the attribute bit later on if necessary
        //
        pPhys->uOffset = WinState.uOffset = 0;
        pPhys->uSize = WinState.uSize = TUPLE_WINDOW_SIZE;
        status = PDCardSetWindow(pPhys->uWindow, &WinState);
        if (status != CERR_SUCCESS) {
            return NULL;
        }
    }

    pWin = I_MapWindow(
                pPhys,
                &addr,
                (TUPLE_WINDOW_SIZE > pPhys->uMaxSize) ?
                    pPhys->uMaxSize : TUPLE_WINDOW_SIZE,
                (pParms->fFlags & TUPLE_FLAG_COMMON) ? FALSE : TRUE
                );
    if (pWin == NULL) {
        return NULL;
    }

    PDCardGetWindow(pPhys->uWindow, &WinState);
    if (pParms->fFlags & TUPLE_FLAG_COMMON) {
        v_Sockets[pPhys->uSock].pCmnWin = pWin;
        WinState.fState &= ~WIN_STATE_ATTRIBUTE;
        pPhys->fFlags &= ~PHYS_WIN_FLAG_ATTR_MODE;
    } else {
        v_Sockets[pPhys->uSock].pAttrWin = pWin;
        WinState.fState |= WIN_STATE_ATTRIBUTE;
        pPhys->fFlags |= PHYS_WIN_FLAG_ATTR_MODE;
    }
    PDCardSetWindow(pPhys->uWindow, &WinState);

    return pWin->pVirtMem;
}   // I_TupleMapWindow


//
// I_TupleGetWindow is called by CardGetFirstTuple to allocate a virtual memory
// window to access the specified socket.  If there is already a window, then
// that will be returned.
//
// hSock is the socket to access
// fFlag specifies whether the CIS is in attribute or common memory.
//
PVOID
I_TupleGetWindow(
    PCARD_TUPLE_PARMS pParms
    )
{
    PPHYS_WINDOW pPhys;
    PLOG_WINDOW  pWin;

    if (pParms->fFlags & TUPLE_FLAG_COMMON) {
        pWin = v_Sockets[pParms->hSocket.uSocket].pCmnWin;
    } else {
        pWin = v_Sockets[pParms->hSocket.uSocket].pAttrWin;
    }

    if (pWin != NULL) {
        if (pWin->pVirtMem == NULL) {
            DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,(
                TEXT("I_TupleGetWindow: Window allocated but not mapped!\r\n")));
        }
        return pWin->pVirtMem;
    }

    //
    // Find a physical memory window associated with this socket.
    //
    EnterCriticalSection(&v_WindowCrit);
    pPhys = v_pWinList;
    while (pPhys) {
        if (pPhys->uSock == pParms->hSocket.uSocket) {
            if ((((pParms->fFlags & TUPLE_FLAG_COMMON) == 0) && (pPhys->fWindowCaps & WIN_CAP_ATTRIBUTE)) ||
                 ((pParms->fFlags & TUPLE_FLAG_COMMON)  && (pPhys->fWindowCaps & WIN_CAP_COMMON))) {
                LeaveCriticalSection(&v_WindowCrit);
                return(I_TupleMapWindow(pPhys, pParms));
            }
        }
        pPhys = pPhys->Next;
    }
    LeaveCriticalSection(&v_WindowCrit);
    return NULL;
}   // I_TupleGetWindow


//
// Remember info from current link tuple.
//
STATUS
I_ReadLink(
    PCHAR * pAttr,
    PCARD_TUPLE_PARMS pParms
    )
{
    STATUS status;
    UINT8 byte;

    switch (pParms->uTupleCode) {
    case CISTPL_LONGLINK_A:
    case CISTPL_LONGLINK_C:
        status = I_ReadAttrWord(pAttr, pParms, 2, &(pParms->uLinkOffset));
        if (status != CERR_SUCCESS) {
            return status;
        }
        pParms->fFlags &= TUPLE_FLAG_COMMON;    // clear all but mem mode.

        if (pParms->uTupleCode == CISTPL_LONGLINK_A) {
            pParms->fFlags |= TUPLE_FLAG_LINK_TO_A;
            pParms->uLinkOffset *= 2;
        } else {
            pParms->fFlags |= TUPLE_FLAG_LINK_TO_C;
        }
        break;

    case CISTPL_LONGLINK_MFC:
        //
        // Make sure the requested function number exists
        //
        status = I_ReadAttrByte(pAttr, pParms, 2, &byte);
        if (status != CERR_SUCCESS) {
            return status;
        }
        if (byte <= pParms->hSocket.uFunction) {
            break;
        }

        //
        // Also verify that the link shows enough room for the requested function
        //
        status = I_ReadAttrByte(pAttr, pParms, 1, &byte);
        if (status != CERR_SUCCESS) {
            return status;
        }
        if (byte < (pParms->hSocket.uFunction * 5) + 1) {
            DEBUGMSG(ZONE_CALLBACK|ZONE_TUPLE,
                (TEXT("I_ReadLink: CISTPL_LONGLINK_MFC length=%d, expecting at least %d\r\n"),
                byte, pParms->hSocket.uFunction * 5 + 1));
            break;
        }

        status = I_ReadAttrWord(pAttr, pParms, (pParms->hSocket.uFunction * 5) + 4, &(pParms->uLinkOffset));
        if (status != CERR_SUCCESS) {
            return status;
        }

        //
        // Check which memory space the link goes to
        //
        status = I_ReadAttrByte(pAttr, pParms, (pParms->hSocket.uFunction * 5) + 3, &byte);
        if (status != CERR_SUCCESS) {
            return status;
        }
        if (byte == 0) {
            pParms->fFlags |= TUPLE_FLAG_LINK_TO_A;
            pParms->uLinkOffset *= 2;
        } else {
            pParms->fFlags |= TUPLE_FLAG_LINK_TO_C;
        }
        break;

    case CISTPL_NO_LINK:
        //
        // CISTPL_NO_LINK means that all long links in this chain
        // should be ignored.
        //
        pParms->fFlags &= TUPLE_FLAG_COMMON;    // clear all but mem mode.
        pParms->fFlags |= TUPLE_FLAG_NO_LINK;
        break;
    }
    return CERR_SUCCESS;
}   // I_ReadLink



//
// Examine the next tuple in the chain
//
STATUS
I_CheckNextTuple(
    PCHAR * pAttr,
    PCARD_TUPLE_PARMS pParms
    )
{
    UINT8 tuple;
    STATUS status;

    status = I_ReadAttrByte(pAttr, pParms, 0, &tuple);
    if (status != CERR_SUCCESS) {
        return status;
    }

    if (tuple == CISTPL_END) {
        return CERR_NO_MORE_ITEMS;
    }

    //
    // CISTPL_NULL is a one byte tuple with no info so it is skipped.
    //
    if (tuple == CISTPL_NULL) {
        pParms->uCISOffset += 1;          // skip to next tuple
    } else {
        status = I_ReadAttrByte(pAttr, pParms, 1, &tuple);
        if (status != CERR_SUCCESS) {
            return status;
        }
        if (tuple == CISTPL_END) {
            DEBUGMSG(ZONE_TUPLE, (TEXT("I_CheckNextTuple: TupleLink == CISTPL_END, assuming end\r\n")));
            return CERR_NO_MORE_ITEMS;
        }
        pParms->uCISOffset += tuple+2;    // skip to next tuple
    }
    return CERR_SUCCESS;
}   // I_CheckNextTuple


//
// Check and follow the link at the current CIS offset
//
// pAttr may get changed to a pointer to common memory if the CIS is in common
// memory.
//
STATUS
I_CheckNextLink(
    PCHAR * pAttr,
    PCARD_TUPLE_PARMS pParms
    )
{
    UINT uSig;    // link target signature.
    UINT8 tuple;
    STATUS status;

    if (pParms->fFlags & TUPLE_FLAG_LINK_TO_C) {
        //
        // Process a link to common memory.
        //
        pParms->fFlags |= TUPLE_FLAG_COMMON;
        DEBUGMSG(ZONE_TUPLE,
            (TEXT("I_CheckNextLink: processing CISTPL_LONGLINK_TO_C\r\n")));
    } else if (pParms->fFlags & TUPLE_FLAG_LINK_TO_A) {
        //
        // Process a link to attribute memory.
        //
        pParms->fFlags &= ~TUPLE_FLAG_COMMON;
        pParms->uLinkOffset /= 2;
        DEBUGMSG(ZONE_TUPLE,
            (TEXT("I_CheckNextLink: processing CISTPL_LONGLINK_TO_A\r\n")));
    } else {
        return CERR_NO_MORE_ITEMS;
    }
    pParms->fFlags &= ~(TUPLE_FLAG_LINK_TO_A|TUPLE_FLAG_LINK_TO_C);

    DEBUGMSG(ZONE_TUPLE,
        (TEXT("I_CheckNextLink: CISOffset changing from 0x%x to 0x%x\r\n"),
        pParms->uCISOffset, pParms->uLinkOffset));

    //
    // Point to correct memory space on PC card (attribute vs common)
    //
    DEBUGMSG(ZONE_TUPLE,
        (TEXT("I_CheckNextLink: *pAttr changing from 0x%x"), *pAttr));
    *pAttr = I_TupleGetWindow(pParms);
    DEBUGMSG(ZONE_TUPLE,(TEXT(" to 0x%x\r\n"), *pAttr));

    //
    // Check that the link destination looks correct.
    //
    pParms->uCISOffset = pParms->uLinkOffset;
    if (pParms->uCISOffset > TUPLE_WINDOW_SIZE/2) {
        DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
            (TEXT("I_CheckNextLink: Link target larger than window!\r\n")));
        return CERR_NO_MORE_ITEMS;
    }

    status = I_ReadAttrByte(pAttr, pParms, 0, &tuple);
    if (status != CERR_SUCCESS) {
        DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
            (TEXT("I_CheckNextLink: Read tuple code failed %d\r\n"), status));
        return status;
    }

    if (tuple != CISTPL_LINKTARGET) {
        DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
            (TEXT("I_CheckNextLink: Invalid link target tuple!(0x%x s/b 0x%x)\r\n"),
            tuple, CISTPL_LINKTARGET));
        return CERR_NO_MORE_ITEMS;
    }

    status = I_ReadAttrWord(pAttr, pParms, 1, &uSig);
    if (status != CERR_SUCCESS) {
        DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
            (TEXT("I_CheckNextLink: Read signature failed %d\r\n"), status));
        return status;
    }

    uSig >>= 8; // ignore the link byte.
    if (uSig != LINK_TARGET_SIG) {
        DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
            (TEXT("I_CheckNextLink: Invalid link target signature!(0x%x s/b 0x%x)\r\n"),
            uSig, LINK_TARGET_SIG));
        return CERR_NO_MORE_ITEMS;
    }

    pParms->fFlags &= TUPLE_FLAG_COMMON;    // Clear all but mem mode.
    return CERR_SUCCESS;
}   // I_CheckNextLink


//
// Get the next tuple's code and link info.
//
// pAttr may get changed to a pointer to common memory if the CIS is in common
// memory.
//
STATUS
I_GetNextTuple(
    PCHAR * pAttr,
    PCARD_TUPLE_PARMS pParms
    )
{
    STATUS status;

    if (I_CheckNextTuple(pAttr, pParms)) {
        status = I_CheckNextLink(pAttr, pParms);
        if (status) {
            return status;
        }
    }

    pParms->uTupleLink = 0;
    status = I_ReadAttrByte(pAttr, pParms, 0, &(pParms->uTupleCode));
    if ((status == CERR_SUCCESS) && (pParms->uTupleCode != CISTPL_END)) {
        status = I_ReadAttrByte(pAttr, pParms, 1, &(pParms->uTupleLink));
    }
    if (status != CERR_SUCCESS) {
        return status;
    }
    I_ReadLink(pAttr, pParms);    // Remember info from link tuples.
    return CERR_SUCCESS;
}   // I_GetNextTuple


//
// Find the next requested tuple
//
STATUS
I_GetDesiredTuple(
    PCHAR * pAttr,
    PCARD_TUPLE_PARMS pParms
    )
{
    STATUS status;
    int iMisses;

    //
    // Continue down this tuple chain until we find a match or hit the end.
    //
    for (iMisses = 0; iMisses < MAX_TUPLE_MISSES; iMisses++) {
        //
        // Only CISTPL_END and CISTPL_NO_LINK can have a 0 link field.
        //
        if (pParms->uTupleLink == 0) {
            if ((pParms->uTupleCode != CISTPL_END) &&
                (pParms->uTupleCode != CISTPL_NO_LINK)) {
                goto igdt_next;
            }
        }

        //
        // See if this tuple matches what the caller requested.
        //
        if ((pParms->uDesiredTuple == pParms->uTupleCode) ||
            (pParms->uDesiredTuple == 0xff)) {
            if (pParms->fAttributes & TUPLE_RETURN_LINKS) {
                return CERR_SUCCESS;
            }
            if ((pParms->uTupleCode != CISTPL_LONGLINK_A) &&
                (pParms->uTupleCode != CISTPL_LONGLINK_C) &&
                (pParms->uTupleCode != CISTPL_LONGLINK_MFC) &&
                (pParms->uTupleCode != CISTPL_LINKTARGET) &&
                (pParms->uTupleCode != CISTPL_NO_LINK)) {
                return CERR_SUCCESS;
            }
        }

igdt_next:
        status = I_GetNextTuple(pAttr, pParms);
        if (status) {
            return status;
        }
    }
    return CERR_NO_MORE_ITEMS;
}   // I_GetDesiredTuple


//
// CardGetNextTuple
//
// @doc DRIVERS
//
// @func    STATUS | CardGetNextTuple | Finds the next desired tuple in the CIS.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_ARGS, CERR_BAD_SOCKET, CERR_READ_FAILURE,
//          CERR_OUT_OF_RESOURCE or CERR_NO_MORE_ITEMS.
//
// @comm    Follows the CIS tuple chain specified by the uLinkOffset, uCISOffset and
//          fFlags fields of the <t CARD_TUPLE_PARMS> structure.  These fields were set
//          by a previous call to <f CardGetFirstTuple> or CardGetNextTuple.
//          The result fields, uTupleCode and uTupleLink, should be ignored when
//          the return code is not CERR_SUCCESS.
// @xref    <t CARD_DATA_PARMS>
//
STATUS
CardGetNextTuple(
    PCARD_TUPLE_PARMS pParms    // @parm Pointer to a <t CARD_TUPLE_PARMS> structure.
    )
{
    PLOG_SOCKET pSock;
    PCHAR pAttr;
    STATUS status;

    DEBUGMSG(ZONE_FUNCTION|ZONE_TUPLE,
        (TEXT("CardGetNextTuple entered\r\n")));

    if (pParms == NULL) {
        status = CERR_BAD_ARGS;
        goto next_exit;
    }

    pSock = I_FindSocket(pParms->hSocket);
    if (pSock == NULL) {
        status = CERR_BAD_SOCKET;
        goto next_exit;
    }

    if (!IsCardInserted(pParms->hSocket.uSocket)) {
        status = CERR_READ_FAILURE;
        goto next_exit;
    }

    pAttr = (PCHAR)I_TupleGetWindow(pParms);
    if (pAttr == NULL) {
        status = CERR_OUT_OF_RESOURCE;
        goto next_exit;
    }

    status = I_GetNextTuple(&pAttr, pParms);
    if (status) {
        goto next_exit;
    }

    status = I_GetDesiredTuple(&pAttr, pParms);

next_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR|ZONE_TUPLE,
            (TEXT("CardGetNextTuple failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION|ZONE_TUPLE,
            (TEXT("CardGetNextTuple succeeded\r\n")));
    }
#endif
    return status;
}   // CardGetNextTuple


//
// CardGetFirstTuple
//
// @func    STATUS | CardGetFirstTuple | Finds the desired tuple in the CIS.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_ARGS, CERR_BAD_SOCKET, CERR_READ_FAILURE,
//          CERR_OUT_OF_RESOURCE or CERR_NO_MORE_ITEMS.
//
// @comm    Follows the CIS tuple chain searching for the desired tuple.
//          On return, the uLinkOffset, uCISOffset and fFlags fields of the
//          <t CARD_TUPLE_PARMS> structure are set so that subsequent calls to
//          <f CardGetNextTuple> or <f CardGetTupleData> can follow the tuple chain.
//          The result fields, uTupleCode and uTupleLink, should be ignored when
//          the return code is not CERR_SUCCESS.
// @xref    <t CARD_DATA_PARMS>
//
STATUS
CardGetFirstTuple(
    PCARD_TUPLE_PARMS pParms    // @parm Pointer to a <t CARD_TUPLE_PARMS> structure.
    )
{
    PLOG_SOCKET pSock;
    PCHAR pAttr;
    UINT8 uByte;
    STATUS status;

    DEBUGMSG(ZONE_FUNCTION|ZONE_TUPLE,
        (TEXT("CardGetFirstTuple entered %d\r\n"), pParms->uDesiredTuple));

    if (pParms == NULL) {
        status = CERR_BAD_ARGS;
        goto first_exit;
    }

    pSock = I_FindSocket(pParms->hSocket);
    if (pSock == NULL) {
        status = CERR_BAD_SOCKET;
        goto first_exit;
    }

    if (!IsCardInserted(pParms->hSocket.uSocket)) {
        status = CERR_READ_FAILURE;
        goto first_exit;
    }

    //
    // Check if a window has already been mapped to attribute space on this
    // socket.  Map a window if not and set it to attribute space mode.
    //
    pParms->fFlags = 0;
    pAttr = (PCHAR)I_TupleGetWindow(pParms);
    if (pAttr == NULL) {
        status = CERR_OUT_OF_RESOURCE;
        goto first_exit;
    }

    PcmciaPowerOn(pParms->hSocket.uSocket);

    //
    // Fill in where to start the tuple search
    //
    pParms->uLinkOffset = 0;
    pParms->uCISOffset = 0;
    pParms->fFlags = 0;
    status = I_ReadAttrByte(&pAttr, pParms, 0, &uByte);
    if (status) {
        goto first_exit;
    }
    if (uByte == 0xFF) {
        DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
            (TEXT("CardGetFirstTuple: CIS is in common memory\r\n")));
        // The CIS is in common memory.
        pParms->fFlags = TUPLE_FLAG_COMMON;
        pAttr = (PCHAR)I_TupleGetWindow(pParms);
        if (pAttr == NULL) {
            status = CERR_OUT_OF_RESOURCE;
            goto first_exit;
        }
    }

    status = I_ReadAttrByte(&pAttr, pParms, 0, &(pParms->uTupleCode));
    if (status == CERR_SUCCESS) {
        status = I_ReadAttrByte(&pAttr, pParms, 1, &(pParms->uTupleLink));
    }
    if (status) {
        goto first_exit;
    }

    //
    // Find the requested tuple type
    //
    status = I_GetDesiredTuple(&pAttr, pParms);

first_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR|ZONE_TUPLE,
            (TEXT("CardGetFirstTuple failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION|ZONE_TUPLE,
            (TEXT("CardGetFirstTuple succeeded\r\n")));
    }
#endif
    return status;
}   // CardGetFirstTuple


//
// CardGetTupleData
//
// @func    STATUS | CardGetTupleData | Reads the data from the current tuple.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_ARGS, CERR_BAD_SOCKET, CERR_READ_FAILURE,
//          CERR_OUT_OF_RESOURCE, CERR_NO_MORE_ITEMS or CERR_BAD_ARG_LENGTH.
//
// @comm    Reads the CIS data from the specified PC card at the location specified by
//          the uCISOffset and uTupleOffset fields.  The uCISOffset field should be the
//          value set by a previous call to <f CardGetFirstTuple> or <f CardGetNextTuple>.
// @xref    <t CARD_TUPLE_PARMS>
//
STATUS
CardGetTupleData(
    PCARD_DATA_PARMS pData  // @parm Pointer to a <t CARD_DATA_PARMS> structure.
    )
{
    PLOG_SOCKET pSock;
    PCHAR pAttr;
    PCHAR pBuf;
    UINT uNumBytes, uOffset;
    STATUS status;
    UINT8 tuple;

    DEBUGMSG(ZONE_FUNCTION|ZONE_TUPLE,
        (TEXT("CardGetTupleData entered\r\n")));

    if (pData == NULL) {
        status = CERR_BAD_ARGS;
        goto data_exit;
    }

    pSock = I_FindSocket(pData->hSocket);
    if (pSock == NULL) {
        status = CERR_BAD_SOCKET;
        goto data_exit;
    }

    if (!IsCardInserted(pData->hSocket.uSocket)) {
        status = CERR_READ_FAILURE;
        goto data_exit;
    }

    pAttr = (PCHAR)I_TupleGetWindow((PCARD_TUPLE_PARMS)pData);
    if (pAttr == NULL) {
        status = CERR_OUT_OF_RESOURCE;
        goto data_exit;
    }

    DEBUGMSG(ZONE_TUPLE,
        (TEXT("CardGetTupleData: uCISOffset = 0x%x\r\n"), pData->uCISOffset));

    //
    // There is no data for CISTPL_END
    //
    pData->uDataLen = 0;
    status = I_ReadAttrByte(
                &pAttr,
                (PCARD_TUPLE_PARMS)pData,
                0,
                &tuple);
    if ((status != CERR_SUCCESS) || (tuple == CISTPL_END)) {
        goto data_exit;
    }

    //
    // Get length from link field.
    //
    status = I_ReadAttrByte(
                &pAttr,
                (PCARD_TUPLE_PARMS)pData,
                1,
                (PCHAR)(&(pData->uDataLen)));
    if (status) {
        goto data_exit;
    }

    //
    // Check if they want more than is there.
    //
    if (pData->uDataLen < pData->uTupleOffset) {
        status = CERR_NO_MORE_ITEMS;
        goto data_exit;
    }

    //
    // See if user buffer has enough room
    //
    pData->uDataLen -= pData->uTupleOffset;
    if (pData->uDataLen > pData->uBufLen) {
        status = CERR_BAD_ARG_LENGTH;
        goto data_exit;
    }

    pBuf = (PCHAR)pData;
    pBuf += sizeof(CARD_DATA_PARMS);    // point to user's buffer.
    uNumBytes = pData->uDataLen;
    uOffset = pData->uTupleOffset + 2;    // skip code and link

    while (uNumBytes) {
        status = I_ReadAttrByte(
                    &pAttr,
                    (PCARD_TUPLE_PARMS)pData,
                    uOffset,
                    pBuf);
        if (status != CERR_SUCCESS) {
            goto data_exit;
        }

        pBuf++;
        uNumBytes--;
        uOffset++;
    }

data_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR|ZONE_TUPLE,
            (TEXT("CardGetTupleData failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION|ZONE_TUPLE,
            (TEXT("CardGetTupleData succeeded\r\n")));
    }
#endif
    return status;
}   // CardGetTupleData


//
// VarToFixed - convert the bytes of a variable length field into a UINT32
//              and return fixed length value.
//
UINT32
VarToFixed(
    UINT32 VarSize,
    PUCHAR pBytes
    )
{
    UINT32 Fixed = 0;

    //
    // Parse the bytes starting from the MSB and shift them into place.
    //
    while (VarSize) {
        VarSize--;
        Fixed <<= 8;
        Fixed |= (UINT32) pBytes[VarSize];
    }
    return Fixed;
}


//
// ParseConfig - Read the CISTPL_CONFIG tuple from the CIS and format it into a
// PARSED_CONFIG structure.
//
STATUS
ParseConfig(
    CARD_SOCKET_HANDLE hSocket,
    PVOID   pBuf,
    PUINT   pnItems
    )
{
    STATUS status;
    PPARSED_CONFIG pCfg = (PPARSED_CONFIG)pBuf;
    UCHAR buf[BUFFER_SIZE + sizeof(CARD_DATA_PARMS)];
    PCARD_DATA_PARMS pData;
    PCARD_TUPLE_PARMS pTuple;
    PUCHAR pCIS;
    UINT   AddrSz;


    //
    // Find and read the second CISTPL_CONFIG tuple if possible.
    // (Some MFC cards contain a CISTPL_CONFIG in the CISTPL_LONGLINK_MFC chain)
    //
    pTuple = (PCARD_TUPLE_PARMS)buf;
    pTuple->hSocket = hSocket;
    pTuple->uDesiredTuple = CISTPL_CONFIG;
    pTuple->fAttributes = 0;         // Not interested in links
    status = CardGetFirstTuple(pTuple);
    if (status) {
        DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
        (TEXT("ParseConfig: CardGetFirstTuple returned %d\r\n"), status));
        *pnItems = 0;
        return status;
    }

    status = CardGetNextTuple(pTuple);
    if (status) {
        status = CardGetFirstTuple(pTuple);
        if (status) {
            DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
            (TEXT("ParseConfig: CardGetFirstTuple returned %d\r\n"), status));
            *pnItems = 0;
            return status;
        }
    }

    pData = (PCARD_DATA_PARMS)buf;
    pData->uBufLen = BUFFER_SIZE;
    pData->uTupleOffset = 0;
    status = CardGetTupleData(pData);
    if (status) {
        DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
        (TEXT("ParseConfig: CardGetTupleData returned %d\r\n"), status));
        *pnItems = 0;
        return status;
    }

    if (pBuf == NULL) {
        *pnItems = 1;
        return CERR_SUCCESS;
    }

    if (*pnItems == 0) {
        return CERR_BAD_ARG_LENGTH;
    }

    *pnItems = 1;
    pCfg->ConfigBase = 0;
    pCfg->RegMask = 0;

    pCIS = buf + sizeof(CARD_DATA_PARMS);
    AddrSz = (*pCIS & 0x03) + 1;
    pCIS++;
    pCfg->LastConfigIndex = *pCIS & 0x3f;
    pCIS++;

    //
    // Read the configuration register offset address and leave it in real
    // physical address units.
    //
    pCfg->ConfigBase = VarToFixed(
                            AddrSz,
                            pCIS);          // pointer

    //
    // Now get the register presence mask (only the first byte)
    //
    pCfg->RegMask = pCIS[AddrSz];

    DEBUGMSG(ZONE_TUPLE,
        (TEXT("ParseConfig: Last configuration index = 0x%x\r\n"), pCfg->LastConfigIndex));
    DEBUGMSG(ZONE_TUPLE,
        (TEXT("ParseConfig: Config registers base = 0x%x\r\n"), pCfg->ConfigBase));
    DEBUGMSG(ZONE_TUPLE,
        (TEXT("ParseConfig: Register presence mask = 0x%x\r\n"), pCfg->RegMask));

    return CERR_SUCCESS;
}   // ParseConfig

BOOL
ValidPowerEntry(
    UINT fSupply,
    UINT16 uVoltage
    )
{
    UINT8 i;
    PPDCARD_POWER_ENTRY pPwr = (PPDCARD_POWER_ENTRY)(((PCHAR)v_pAdapterInfo) +
                                sizeof(PDCARD_ADAPTER_INFO));
    for (i = 0; i < v_pAdapterInfo->uPowerEntries; i++, pPwr++) {
        if (((pPwr->uPowerLevel * 9 / 10) <= uVoltage) &&
            (pPwr->uPowerLevel >= uVoltage) &&
            (pPwr->fSupply & fSupply)) {
            return TRUE;
        }
    }

    return FALSE;
}

const USHORT VoltageConversionTable[16] = {
    10, 12, 13, 15, 20, 25, 30, 35,
    40, 45, 50, 55, 60, 70, 80, 90
};

//
// ConvertVoltage - normalize a single CISTPL_CFTABLE_ENTRY voltage entry and
//                  return its length in bytes
//
UINT
ConvertVoltage(
    PUCHAR pCIS,
    PUSHORT pDescr
    )
{
    UINT Length;
    SHORT power;
    USHORT value;
    UCHAR MantissaExponentByte;
    UCHAR ExtensionByte;

    Length = 1;
    power = 1;
    MantissaExponentByte = pCIS[0];
    ExtensionByte = pCIS[1];
    value = VoltageConversionTable[(MantissaExponentByte >> 3) & 0x0f];

    if ((MantissaExponentByte & TPCE_PD_EXT) &&
        (ExtensionByte < 100)) {
        value = (100 * value + (ExtensionByte & 0x7f));
        power += 2;
    }

    power = (MantissaExponentByte & 0x07) - 4 - power;

    while (power > 0) {
        value *= 10;
        power--;
    }

    while (power < 0) {
        value /= 10;
        power++;
    }

    *pDescr = value;

    //
    // Skip any subsequent extension bytes for now.
    //
    while (*pCIS & TPCE_PD_EXT) {
        Length++;
        pCIS++;
    }

    return Length;
}   // ConvertVoltage


//
// ParseVoltageDescr - convert the variable length power description structure
//                     from a CISTPL_CFTABLE_ENTRY to a POWER_DESCR structure
//                     and normalize the values.
// Returns the length of the variable length power description structure.
//
// A typical call would be:
//        if (pCfTable->VccDescr.ValidMask) {
//            pCIS += ParseVoltageDescr(pCIS, &pCfTable->VccDescr);
//        }
//
UINT
ParseVoltageDescr(
    PUCHAR pVolt,
    PPOWER_DESCR pDescr
    )
{
    UINT Length;
    UINT Mask;
    UINT i;
    PUSHORT pDVolt;

    Length = 1;
    Mask = pDescr->ValidMask = (UINT)*pVolt;
    pVolt++;
    pDVolt = &(pDescr->NominalV);

    while (Mask) {
        if (Mask & 1) {
            i = ConvertVoltage(pVolt, pDVolt);
            Length += i;
            pVolt += i;
        } else {
            *pDVolt = 0;
        }
        pDVolt++;
        Mask >>= 1;
    }

    return Length;
}   // ParseVoltageDescr

//
// ParseCfTable - Read the CISTPL_CFTABLE_ENTRY tuples from the CIS and format them into
// an array of PARSED_CFTABLE structures.
//
STATUS
ParseCfTable(
    CARD_SOCKET_HANDLE hSocket,
    PVOID   pBuf,
    PUINT   pnItems
    )
{
    STATUS status;
    UCHAR buf[BUFFER_SIZE + sizeof(CARD_DATA_PARMS)];
    PCARD_DATA_PARMS pData;
    PCARD_TUPLE_PARMS pTuple;
    PUCHAR  pCIS;
    PUCHAR  pTmp;
    PPARSED_CFTABLE pCfTable = (PPARSED_CFTABLE)pBuf;
    PPARSED_CFTABLE pCfDefault = NULL;
    BOOL    TimingPresent;  // This tuple contains a description of the card's timing
    BOOL    IOPresent;      // This tuple contains I/O descriptor bytes
    DWORD   bmPowerPresent; // This tuple has some power descriptors
    int     lastCFI = -1;   // Configuration Index of the previous CFTABLE_ENTRY tuple
    UINT    i;
    UINT    nItems;

    nItems = 0;

    //
    // Find the first CISTPL_CFTABLE_ENTRY tuple
    //
    pTuple = (PCARD_TUPLE_PARMS)buf;
    pTuple->hSocket = hSocket;
    pTuple->uDesiredTuple = CISTPL_CFTABLE_ENTRY;
    pTuple->fAttributes = 0;         // Not interested in links
    status = CardGetFirstTuple(pTuple);
    if (status) {
        DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
            (TEXT("ParseCfTable: CardGetFirstTuple returned %d\r\n"), status));
        goto pcft_exit;
    }

    if (pBuf != NULL) {
        if (*pnItems == 0) {
            status = CERR_BAD_ARG_LENGTH;
        } else {
            memset(pBuf, 0, *pnItems * sizeof(PARSED_CFTABLE));
        }
    }

    //
    // Parse all the CISTPL_CFTABLE_ENTRYs or as many as fit in the user's buffer
    //
    while (status == CERR_SUCCESS) {
        nItems++;
        if (pBuf == NULL) {
            goto pcft_next;
        }

        pData = (PCARD_DATA_PARMS)buf;
        pData->uBufLen = BUFFER_SIZE;
        pData->uTupleOffset = 0;
        status = CardGetTupleData(pData);
        if (status) {
            DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
            (TEXT("ParseCfTable: CardGetTupleData returned %d\r\n"), status));
            goto pcft_exit;
        }

        //
        // Parse this CISTPL_CFTABLE_ENTRY
        //
        pCIS = buf + sizeof(CARD_DATA_PARMS);

        // Default all the fields of the current parsed entry if necessary
        //
        // !! The ContainsDefaults field is now deprecated and should be
        // !! set to non-zero in every parsed entry.
        //
        pCfTable->ContainsDefaults = *pCIS & 0x40;
        pCfTable->ConfigIndex = *pCIS & 0x3F;
        if (pCfTable->ContainsDefaults)
            pCfDefault = pCfTable;
        else if (pCfTable->ConfigIndex == lastCFI) {
            ASSERT(pCfTable != pBuf && lastCFI >= 0);
            *pCfTable = *(pCfTable - 1);
            pCfTable->ContainsDefaults = TRUE;
        } else if (pCfDefault)
            *pCfTable = *pCfDefault;

        // Reset the ConfigIndex after defaulting
        pCfTable->ConfigIndex = *pCIS & 0x3F;
        lastCFI = pCfTable->ConfigIndex;
        // lastCFI is not used beyond this point

        //
        // Parse the interface type byte if present
        //
        if (*pCIS & 0x80) {
            pCIS++;
            pCfTable->IFacePresent = TRUE;
            pCfTable->IFaceType     = *pCIS & 0x0F;
            pCfTable->BVDActive     = *pCIS & 0x10;
            pCfTable->WPActive      = *pCIS & 0x20;
            pCfTable->ReadyActive   = *pCIS & 0x40;
            pCfTable->WaitRequired  = *pCIS & 0x80;
        } else {
            //pCfTable->IFacePresent = FALSE;
        }
        pCIS++;

        //
        // Parse the feature select byte
        //

        //
        // Power requirements present
        //
        bmPowerPresent = *pCIS & 0x03;

        //
        // Timing description present
        //
        TimingPresent = *pCIS & 0x04;

        //
        // I/O space descriptions present
        //
        IOPresent = *pCIS & 0x08;

        pCIS++;

        //
        // Parse the power description structures if present
        //
        if (bmPowerPresent >= 1) {
            pCfTable->VccDescr.ValidMask = 0xFF;
            pCIS += ParseVoltageDescr(pCIS, &pCfTable->VccDescr);
            for (i = 0; i < 3; i++) {
                if ((PWR_DESCR_NOMINALV << i) & pCfTable->VccDescr.ValidMask &&
                    ValidPowerEntry(PWR_SUPPLY_VCC, (&pCfTable->VccDescr.NominalV)[i]))
                    pCfTable->VccDescr.ValidMask |= (PWR_AVAIL_NOMINALV << i);
            }
        }
        if (bmPowerPresent >= 2) {
            pCfTable->Vpp1Descr.ValidMask = 0xFF;
            pCIS += ParseVoltageDescr(pCIS, &pCfTable->Vpp1Descr);
            for (i = 0; i < 3; i++) {
                if ((PWR_DESCR_NOMINALV << i) & pCfTable->Vpp1Descr.ValidMask &&
                    ValidPowerEntry(PWR_SUPPLY_VPP1, (&pCfTable->Vpp1Descr.NominalV)[i]))
                    pCfTable->Vpp1Descr.ValidMask |= (PWR_AVAIL_NOMINALV << i);
            }

            pCfTable->Vpp2Descr.ValidMask = 0xFF;
            if (bmPowerPresent == 3) {
                pCIS += ParseVoltageDescr(pCIS, &pCfTable->Vpp2Descr);
                for (i = 0; i < 3; i++) {
                    if ((PWR_DESCR_NOMINALV << i) & pCfTable->Vpp1Descr.ValidMask &&
                        ValidPowerEntry(PWR_SUPPLY_VPP2, (&pCfTable->Vpp1Descr.NominalV)[i]))
                        pCfTable->Vpp2Descr.ValidMask |= (PWR_AVAIL_NOMINALV << i);
                }
            } else
                pCfTable->Vpp2Descr = pCfTable->Vpp1Descr;
        }


        //
        // Skip the timing information
        //
        if ( TimingPresent ) {
            pTmp = pCIS;

            pCIS++;
            if ( (*pTmp & 0x03) != 0x03 ) {
                while ( *pCIS++ & TPCE_PD_EXT ) ;
            }
            if ( (*pTmp & 0x1C) != 0x1C ) {
                while ( *pCIS++ & TPCE_PD_EXT );
            }
        }


        //
        // Process the I/O address ranges (up to MAX_IO_RANGES)
        //
        if (IOPresent) {
            pCfTable->NumIOAddrLines = *pCIS & 0x1F;
            pCfTable->IOAccess = (*pCIS & 0x60) >> 5;   // type of access allowed
            if (*pCIS & 0x80) {  // range present bit
                UINT8   AddrSize, LengthSize;
                pCIS++;
                pCfTable->NumIOEntries = (*pCIS & 0x0F) + 1;
                if (pCfTable->NumIOEntries > MAX_IO_RANGES) {
                    DEBUGMSG(ZONE_TUPLE|ZONE_WARNING,
                             (TEXT("PCMCIA ParseCfTable: too many I/O ranges; ignoring some.\n")));
                    pCfTable->NumIOEntries = MAX_IO_RANGES;
                }
                AddrSize = (*pCIS & 0x30) >> 4;
                if (AddrSize == 3) {
                    AddrSize = 4;
                }
                LengthSize = (*pCIS & 0xC0) >> 6;
                if (LengthSize == 3) {
                    LengthSize = 4;
                }
                pCIS++;

                for (i = 0; i < pCfTable->NumIOEntries; i++) {
                    pCfTable->IOBase[i] = VarToFixed(AddrSize, pCIS);
                    pCIS += AddrSize;
                    pCfTable->IOLength[i] = VarToFixed(LengthSize, pCIS);
                    pCIS += LengthSize;
                }
            } else {
                // NumIOEntries is a misnomer; it's really the number of IO ranges.
                pCfTable->NumIOEntries = 0;
            }
        }
        // else it has already been either defaulted or memset to zeros.

        pCfTable++;

pcft_next:
        if ((pBuf != NULL) && (nItems == *pnItems)) {
            status = CERR_NO_MORE_ITEMS;    // no more room in caller's buffer
        } else {
            //
            // Get the next CISTPL_CFTABLE_ENTRY
            //
            status = CardGetNextTuple(pTuple);
        }
    }   // while (status == CERR_SUCCESS)

pcft_exit:
    *pnItems = nItems;

    //
    // If there were problems and no CFTABLE_ENTRYs found then return an error.
    //
    if (nItems) {
        return CERR_SUCCESS;
    }
    return status;

}   // ParseCfTable


//
// CardGetParsedTuple
//
// @func    STATUS | CardGetParsedTuple | Reads and parses the specified tuple.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_ARGS, CERR_BAD_SOCKET, CERR_READ_FAILURE,
//          CERR_OUT_OF_RESOURCE, CERR_NO_MORE_ITEMS or CERR_BAD_ARG_LENGTH.
//
// @comm    Reads the CIS data from the specified PC card of the specified tuple code and
//          formats the encoded data into an easily accessed structure.  CISTPL_CONFIG and
//          CISTPL_CFTABLE_ENTRY are currently the only tuples parsed.  When CardGetParsedTuple
//          is called with CISTPL_CONFIG, it returns a PARSED_CONFIG structure.  When it
//          is called with CISTPLE_CFTABLE_ENTRY, it returns a PARSED_CFTABLE structure.
//          On input, the value pointed to by pnItems is the number of items the buffer, pBuf
//          can contain.  On output, pnItems indicates the number items in pBuf.
//          If pBuf is NULL, then pnItems indicates how many of the requested tuples there are.
//
// @xref    <t PARSED_CONFIG> <t PARSED_CFTABLE> <t POWER_DESCR>
//
STATUS
CardGetParsedTuple(
    CARD_SOCKET_HANDLE hSocket, // @parm Socket/function identifier
    UINT8   DesiredTuple,       // @parm Desired tuple to parse (only CISTPL_CONFIG and CISTPL_CFTABLE_ENTRY for now)
    PVOID   pBuf,               // @parm Pointer to buffer to receive parsed data
    PUINT   pnItems             // @parm Pointer to number of items in pBuf.
    )
{
    STATUS status;

    DEBUGMSG(ZONE_FUNCTION|ZONE_TUPLE,
        (TEXT("CardGetParsedTuple entered %d\r\n"), DesiredTuple));

    if (pnItems == NULL) {
        status = CERR_BAD_ARGS;
        goto parsed_exit;
    }

    switch (DesiredTuple) {
    case CISTPL_CONFIG:
        status = ParseConfig(hSocket, pBuf, pnItems);
        break;

    case CISTPL_CFTABLE_ENTRY:
        status = ParseCfTable(hSocket, pBuf, pnItems);
        break;

    default:
        status = CERR_BAD_ARGS;
        break;
    }


parsed_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR|ZONE_TUPLE,
            (TEXT("CardGetParsedTuple failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION|ZONE_TUPLE,
            (TEXT("CardGetParsedTuple succeeded\r\n")));
    }
#endif
    return status;
}   // CardGetParsedTuple

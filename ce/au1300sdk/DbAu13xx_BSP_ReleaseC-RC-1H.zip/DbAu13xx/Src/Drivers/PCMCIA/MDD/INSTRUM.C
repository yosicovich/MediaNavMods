//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//

/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

    instrum.c

Abstract:

    Code to provide support for instrumented device.exe.

Functions:
    ics_init
    ics_addCardRange
    ics_deleteCardRange
    ics_unmapCardRanges
    ics_restoreCardRanges

Notes:
--*/

#ifdef INSTRUM_DEV

#include <windows.h>
#include <types.h>
#include <excpt.h>
#include <cardserv.h>
#include <sockserv.h>
#include <pcmcia.h>
#include <extern.h>
#include <instrumd.h>

// State of table slots.
#define EMPTY_STATE 0           // this table slot is empty
#define MAPPED_STATE 1          // a mapped memory range resides here
#define DAMAGED_STATE 2         // resident range temporarily unmapped by device.exe

// The table of mapped memory ranges.
typedef struct {
    int card;                   // which socket (zero or one)
    int state;                  // state
    LPVOID vaddr;               // saved VirtualCopy parm
    LPVOID paddr;               // saved VirtualCopy parm
    DWORD size;                 // saved VirtualCopy parm
    DWORD protect;              // saved VirtualCopy parm
} mapmem_t;
#define MAX_SLOTS 20            // number of slots in the table
static mapmem_t table[MAX_SLOTS];

// Critical section to guard the table.
static CRITICAL_SECTION critSect;

/*
State Transitions:
Initially, all table slots are empty (EMPTY_STATE). Whenever card services
map a memory range, the range is stored in a table slot and marked MAPPED_STATE.
At random time, device.exe decides to unmap all ranges for a card (simulating
pullout of the card). The state of such ranges changes to DAMAGED_STATE.
Independently, card services may unmap a range. If that happens, the state
of that range changes from mapped or damaged to empty.
With all card memory ranges unmapped, the device driver xxx_XXXXX function
will (sooner or later) suffer an exception, and should return an error. Once that
happens, the device.exe will restore all unmapped ranges (for a card). At this time,
the DAMAGED_STATE changes back to MAPPED_STATE.
*/

//-----------------------------------------------------------------------------

void ics_init()
{
    InitializeCriticalSection(&critSect);
}

//-----------------------------------------------------------------------------

void ics_addCardRange(int card, LPVOID vaddr, LPVOID paddr, DWORD size, DWORD protect)
{
    int i;
    NKDbgPrintfW(TEXT("cs added vaddr=%x paddr=%x size=%x\r\n"), vaddr, paddr, size);
    EnterCriticalSection(&critSect);

    // Just find empty table slot, and save the passed info there.
    for (i=0; i<MAX_SLOTS; i++) {
        if (table[i].state == EMPTY_STATE) {
            table[i].card = card;
            table[i].state = MAPPED_STATE;
            table[i].vaddr = vaddr;
            table[i].paddr = paddr;
            table[i].size = size;
            table[i].protect = protect;
            break;
        }
    }
    LeaveCriticalSection(&critSect);
}

//------------------------------------------------------------------------------

void ics_deleteCardRange(LPVOID vaddr)
{
    int i;
    NKDbgPrintfW(TEXT("cs freed vaddr=%x\r\n"), vaddr);
    EnterCriticalSection(&critSect);

    // Find affected range and change it to empty.
    for (i=0; i<MAX_SLOTS; i++) {
        if ((table[i].state == MAPPED_STATE || table[i].state == DAMAGED_STATE) &&
            table[i].vaddr == vaddr) {
            table[i].state = EMPTY_STATE;
        }
    }
    LeaveCriticalSection(&critSect);
}

//------------------------------------------------------------------------------

 void ics_unmapCardRanges(int card)
{
    int i;
    EnterCriticalSection(&critSect);

    // For affected ranges, change state to damaged, and do the unmapping.
    NKDbgPrintfW(TEXT("damaging\r\n"));
    for (i=0; i<MAX_SLOTS; i++) {
        if (table[i].card == card && table[i].state == MAPPED_STATE) {
            table[i].state = DAMAGED_STATE;
            VirtualFree(table[i].vaddr, table[i].size, MEM_DECOMMIT);
        }
    }
    LeaveCriticalSection(&critSect);
}

//------------------------------------------------------------------------------

void ics_restoreCardRanges(int card)
{
    int i;
    EnterCriticalSection(&critSect);

    // For affected ranges, restore state to mapped, and do the mapping.
    NKDbgPrintfW(TEXT("restoring\r\n"));
    for (i=0; i<MAX_SLOTS; i++) {
        if (table[i].card == card && table[i].state == DAMAGED_STATE) {
            table[i].state = MAPPED_STATE;
            VirtualCopy(table[i].vaddr, table[i].paddr, table[i].size, table[i].protect);
        }
    }
    LeaveCriticalSection(&critSect);
}

//------------------------------------------------------------------------------

#endif // INSTRUM_DEV


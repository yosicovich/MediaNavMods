//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:  

    reset.c

Abstract:  

    This file implements the PCMCIA model device driver reset function.
    This is provided as a sample to platform writers and is
    expected to be able to be used without modification on most (if not
    all) hardware platforms.

Functions:

    ResetFunction()
    CardResetFunction()

Notes:


--*/


#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <pcmcia.h>
#include <extern.h>


//
// Reset the specified function on the specified socket.
//
STATUS
ResetFunction(
    PLOG_SOCKET pSock
    )
{
    STATUS status;

    //
    // Pulse the SRESET bit in the function's configuration option register if
    // it's a multi-function I/O card or else call the socket services function.
    //
    if ((pSock->pRegWin) &&
        (v_Sockets[pSock->hSock.uSocket].pLsock->Next != NULL)) {

        if (!(pSock->fFlags & OWNER_FLAG_CONFIG))
            return CERR_SUCCESS;

        if (status = CardWriteAttrByte(
                            pSock->pRegWin,
                            FCR_OFFSET_COR,
                            (UINT8)(pSock->COR_val | FCR_COR_SRESET))) {
            return status;
        }
        
        Sleep(1);

        status = CardWriteAttrByte(pSock->pRegWin, FCR_OFFSET_COR, 0);
        Sleep(500);
        DEBUGMSG(ZONE_WARNING, (TEXT("ResetFunction toggled SRESET\r\n")));
    } else {
        status = PDCardResetSocket(pSock->hSock.uSocket);
        DEBUGMSG(ZONE_WARNING,
            (TEXT("ResetFunction called PDCardResetSocket\r\n")));
    }
    return status;
}


//
// CardResetFunction
//
// @doc DRIVERS
//
// @func    STATUS | CardResetFunction | Resets a function on a card.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE, CERR_BAD_SOCKET,
//          CERR_IN_USE, CERR_GENERAL_FAILURE or CERR_NO_CARD.
//
// @comm    If another client driver requested the configuration for this card
//          or owns exclusive access, then CERR_IN_USE is returned.  Otherwise
//          the card is reset by toggling the SRESET bit on the card's 
//          configuration option register if it is an I/O card or by using the
//          socket services reset function.
//
STATUS
CardResetFunction(
    CARD_CLIENT_HANDLE hCardClient, // @parm Handle from <f CardRegisterClient>
    CARD_SOCKET_HANDLE hSock        // @parm Socket/Function identifier
    )
{
    PLOG_SOCKET pSock;
    PCLIENT_DRIVER pClient;
    STATUS status = CERR_SUCCESS;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardResetFunction entered\r\n")));

    //
    // Run this request through the parameter validation gauntlet.
    //
    if ((pClient = FindClient(hCardClient, TRUE, TRUE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto reset_exit;
    }
    if (!IsCardInserted(hSock.uSocket)) {
        status = CERR_NO_CARD;
    } else if ((pSock = I_FindSocket(hSock)) == NULL) {
        status = CERR_BAD_SOCKET;
    }

    if (status == CERR_SUCCESS) {
        //
        // If no one owns the card or if the caller owns it,
        // then reset it immediately
        //
        if (((pSock->fFlags & OWNER_FLAGS) == 0) ||
            (pSock->hOwner == pClient)) {
            PcmciaPowerOn(hSock.uSocket);
            status = ResetFunction(pSock);
        } else {
            status = CERR_IN_USE;
        }
    }

reset_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("CardResetFunction failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION, (TEXT("CardResetFunction succeeded\r\n")));
    }
#endif
    return status;
}   // CardResetFunction

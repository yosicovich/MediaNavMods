//
// Copyright (c) Microsoft Corporation.  All rights reserved.
// Copyright (c) 2003 BSQUARE Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

    utils.c

Abstract:

    This file implements the PCMCIA model device driver internal functions.
    This is provided as a sample to platform writers and is
    expected to be able to be used without modification on most (if not
    all) hardware platforms.

Functions:

    I_FindSocket()
    I_FindClientSocket()
    I_AttachClientSocket()
    I_RemoveClientSocket()
    I_GetClientSocket()
    I_LinkLogicalWindow()
    I_UnlinkLogicalWindow()
    I_CreateLogicalWindow()
    I_DeleteLogicalWindow()
    I_MapWindow()
    IsCardInserted()
    IsValidClient()
    FindClient()
    CreateFunction()
    CreateFunctions()
    DeleteFunctions()
    RemoveCallbacks()

Notes:


--*/


#include <windows.h>
#include <types.h>
#include <tchar.h>
#include <cardserv.h>
#include <sockserv.h>
#include <linklist.h>
#include <pcmcia.h>
#include <tuple.h>
#include <extern.h>

#ifdef INSTRUM_DEV
#include <instrumd.h>
#endif

// Calculates start address of page containing address X
#define PAGE_START(X) (((UINT)(X) / v_PageSize) * v_PageSize)

//
// Return a pointer to the PLOG_SOCKET structure that represents the
// specified socket/function pair.  Return NULL if none found.
//
PLOG_SOCKET I_FindSocket(CARD_SOCKET_HANDLE hSock)
{
    PLOG_SOCKET pSock;

    if (hSock.uSocket >= v_cSockets) {
        return NULL;
    }

    EnterCriticalSection(&v_SocketCrit);
    pSock = v_Sockets[hSock.uSocket].pLsock;

    while (pSock) {
        if (pSock->hSock.uFunction == hSock.uFunction) {
            LeaveCriticalSection(&v_SocketCrit);
            return pSock;
        }
        pSock = pSock->Next;
    }
    LeaveCriticalSection(&v_SocketCrit);
    return NULL;
}


//
// Return a pointer to the PCLIENT_SOCKET structure that represents the
// specified logical socket/client pair.  Return NULL if none found.
//
PCLIENT_SOCKET
I_FindClientSocket(
    CARD_SOCKET_HANDLE hSock,
    PCLIENT_DRIVER pClient
    )
{
    PCLIENT_SOCKET pCsock;

    pCsock = pClient->pCsock;

    while (pCsock) {
        if ((pCsock->pLsock->hSock.uSocket == hSock.uSocket) &&
            (pCsock->pLsock->hSock.uFunction == hSock.uFunction)) {
            return pCsock;
        }
        pCsock = pCsock->Next;
    }
    return NULL;
}


//
// Link the PCLIENT_SOCKET structure to the client's list.
//
VOID
I_AttachClientSocket(
    PCLIENT_SOCKET pCsock,
    PCLIENT_DRIVER pClient
    )
{
    PCLIENT_SOCKET pCsockP;

    //
    // Link this socket to the client
    //
    if (pClient->pCsock == NULL) {
        pClient->pCsock = pCsock;
    } else {
        //
        // Link it at the end of the list.
        //
        pCsockP = pClient->pCsock;
        while (pCsockP->Next) {
            pCsockP = pCsockP->Next;
        }
        pCsockP->Next = pCsock;
    }
}


//
// Unlink the PCLIENT_SOCKET structure from the client's list and free it.
//
VOID
I_RemoveClientSocket(
    PCLIENT_SOCKET pCsock,
    PCLIENT_DRIVER pClient
    )
{
    PCLIENT_SOCKET pCsockP;

    if (pClient->pCsock == pCsock) {
        pClient->pCsock = pCsock->Next;     // unlink it
        goto freeit;
    } else {
        pCsockP = pClient->pCsock;
        while (pCsockP->Next) {
            if (pCsockP->Next == pCsock) {
                pCsockP->Next = pCsock->Next;   // unlink it
                goto freeit;
            }
            pCsockP = pCsockP->Next;
        }
    }
    DEBUGMSG(ZONE_WARNING, (TEXT("I_RemoveClientSocket: Something's wrong!\r\n")));
    return;

freeit:
    free(pCsock);
    return;
}   // I_RemoveClientSocket


//
// Either find the specified CLIENT_SOCKET or allocate one and link it in.
//
PCLIENT_SOCKET
I_GetClientSocket(
    PLOG_SOCKET pLsock,
    PCLIENT_DRIVER pClient
    )
{
    PCLIENT_SOCKET pCsock;

    pCsock = I_FindClientSocket(pLsock->hSock, pClient);
    if (pCsock == NULL) {
        pCsock = alloc(sizeof(CLIENT_SOCKET));
        if (pCsock == NULL) {
            return NULL;
        }
        pCsock->pLsock = pLsock;
        I_AttachClientSocket(pCsock, pClient);
    }
    return pCsock;
}   // I_GetClientSocket


//
// Attach a logical window structure to the specified physical window's list
//
VOID
I_LinkLogicalWindow(
    PPHYS_WINDOW pPhys,
    PLOG_WINDOW pWin
    )
{
    //
    // Link this new logical window to the physical window.
    //
    EnterCriticalSection(&v_WindowCrit);
    pWin->pPhys = pPhys;
    pWin->Next = pPhys->pLog;
    pPhys->pLog = pWin;
    LeaveCriticalSection(&v_WindowCrit);
}   // I_LinkLogicalWindow


//
// Unlink a logical window structure from the associated physical window
//
VOID
I_UnlinkLogicalWindow(
    PLOG_WINDOW pWin
    )
{
    PLOG_WINDOW pTmp;

    //
    // Unlink from list.
    //
    EnterCriticalSection(&v_WindowCrit);
    if (pWin->pPhys->pLog == pWin) {
        pWin->pPhys->pLog = pWin->Next;
    } else {
        pTmp = pWin->pPhys->pLog;
        while (pTmp) {
            if (pTmp->Next == pWin) {
                pTmp->Next = pWin->Next;
                pWin->Next = NULL;
                pWin->pPhys = NULL;
                break;
            }
            pTmp = pTmp->Next;
        }
    }
    LeaveCriticalSection(&v_WindowCrit);
}   // I_UnlinkLogicalWindow

//
// Create a logical window and link it to the physical window.
//
// Return NULL on failure or valid PLOG_WINDOW on success.
//
PLOG_WINDOW
I_CreateLogicalWindow(
    PPHYS_WINDOW pPhys
    )
{
    PLOG_WINDOW pWin;

    pWin = alloc(sizeof(LOG_WINDOW));

    if (pWin) {
        pWin->Next = NULL;
        pWin->hOwner = 0;
        pWin->pVirtMem = NULL;

        I_LinkLogicalWindow(pPhys, pWin);
    }

    return pWin;
}   // I_CreateLogicalWindow

//
// Unlink a logical window from the physical window and free its memory and
// the mapped memory.
//
VOID
I_DeleteLogicalWindow(
    PLOG_WINDOW pWin
    )
{

    //
    // Free the mapped memory.
    //
    if (pWin->pVirtMem) {
       DEBUGMSG(ZONE_MEM,
            (TEXT("I_DeleteLogicalWindow calling VirtualFree(0x%x).\r\n"),
            pWin->pVirtMem));
       if (VirtualFree( pWin->pVirtMem, 0, MEM_RELEASE) == FALSE) {
            DEBUGMSG(ZONE_MEM|ZONE_ERROR,
                (TEXT("I_DeleteLogicalWindow: VirtualFree failed %d\r\n"),
                GetLastError()));
        }
#ifdef INSTRUM_DEV
        ics_deleteCardRange(pWin->pVirtMem);
#endif

    }

    I_UnlinkLogicalWindow(pWin);
    free(pWin);

}   // I_DeleteLogicalWindow

//
// Map a physical memory window to a virtual/logical window
//
// Returns NULL on failure.
//
// On exit, pCardAddress points to the virtual address of the requested region.
//
PLOG_WINDOW
I_MapWindow(
    PPHYS_WINDOW pPhys,
    PUINT pCardAddress,
    UINT uSize,
    BOOL bAttribute
    )
{
    PLOG_WINDOW pWin;
    PDCARD_WINDOW_STATE WinState;
    UINT32 uStart;
    UINT32 uEnd;
    UINT32 uVirtSize;
    UINT32 uPhysAddr;
    UINT32 uWinOffset;

    pWin = I_CreateLogicalWindow(pPhys);
    if (pWin == NULL) {
        DEBUGMSG(ZONE_WARNING,
            (TEXT("I_MapWindow: I_CreateLogicalWindow failed\r\n")));
        return NULL;
    }

    //
    // Compute beginning and ending addresses of the mapping region (must be on page boundaries)
    //
    uStart = PAGE_START(*pCardAddress);
    uEnd = (((*pCardAddress + uSize) + v_PageSize - 1) / v_PageSize) * v_PageSize;
    uVirtSize = uEnd - uStart;

    DEBUGMSG(ZONE_MEM,
        (TEXT("I_MapWindow: pCardAddress = 0x%x, v_PageSize = 0x%x\n"),
         *pCardAddress, v_PageSize));

    pWin->uReqOffset = *pCardAddress;
    pWin->uReqSize = uSize;
    pWin->pVirtMem = VirtualAlloc(
                          0,
                          uVirtSize,
                          MEM_RESERVE,
                          PAGE_NOACCESS);
    if (pWin->pVirtMem == NULL) {
        DEBUGMSG(ZONE_WARNING,
            (TEXT("I_MapWindow: VirtualAlloc failed %d\r\n"), GetLastError()));
        I_DeleteLogicalWindow(pWin);
        return NULL;
    }

    // Map the memory.
#ifdef DEBUG
    if (pPhys->uBase & 0xE0000000) {
        DEBUGMSG(ZONE_WARNING|ZONE_ERROR|ZONE_MEM,
          (TEXT("PCMCIA:I_MapWindow MAKE SURE THIS PLATFORM'S PCMCIA MEMORY AREAS ARE SPECIFIED AS ACTUAL PHYSICAL ADDRESSES\r\n")));
    }
#endif

    // If window has programmable base address in hardware (PCIC), find out
    // the base of the memory window on the PC Card size (uWinOffset).  For
    // memory-mapped PCMCIA space, there is no mapping from uBase to uWinOffset,
    // so set it to 0.
    if (pWin->pPhys->fOtherCaps & MEM_CAP_PRG_BASE)
    {
        PDCardGetWindow(pPhys->uWindow, &WinState);
        uWinOffset = WinState.uOffset;
    }
    else
    {
        uWinOffset = 0;
    }

    // Physical address to be used is the base of the memory window (from host side) plus
    // the difference of the start of the page the CardAddress is in (uStart) and the
    // base of the memory window on the PC Card side.  The resulting address is page
    // adjusted.
    uPhysAddr = pPhys->uBase + uStart - uWinOffset;

    DEBUGMSG(ZONE_MEM,
        (TEXT("I_MapWindow: uBase = 0x%x, uStart = 0x%x, uWinOffset= 0x%x, uPhysAddr = 0x%x\n"),
         pPhys->uBase, uStart, uWinOffset, uPhysAddr));

    uPhysAddr >>= 8;
	uPhysAddr |= 0x0f000000;	// workaround for Au1x00 36 bit physical address
    if (!VirtualCopy(
             pWin->pVirtMem,
             (PVOID)uPhysAddr,
             uVirtSize,
             PAGE_READWRITE|PAGE_NOCACHE|PAGE_PHYSICAL)) {
        DEBUGMSG(ZONE_WARNING,
            (TEXT("I_MapWindow: VirtualCopy failed %d\r\n"), GetLastError()));
        I_DeleteLogicalWindow(pWin);
        return NULL;
    }

#ifdef SH4
    //
    // On SH4 we need to set some extra page table bits associated with PCMCIA
    // (the SH4 PCMCIA controller is integrated with the CPU's paging mechanism)
    //
    if (!VirtualSetPageFlags(
             pWin->pVirtMem,
             uVirtSize,
             (bAttribute ? VSPF_ATTRIBUTE : VSPF_COMMON) | (isSh4Area6(pPhys->uWindow)?VSPF_TC:0),
             NULL)) {
        DEBUGMSG(ZONE_WARNING,
            (TEXT("I_MapWindow: VirtualSetPageFlags failed %d\r\n"),
            GetLastError()));
        I_DeleteLogicalWindow(pWin);
        return NULL;
    }
#endif

#ifdef INSTRUM_DEV
    ics_addCardRange(0, pWin->pVirtMem, (PVOID)(pPhys->uBase+uStart), uVirtSize, 0);
#endif

    DEBUGMSG(ZONE_MEM,
        (TEXT("I_MapWindow: Window %d @ %x (phys = %x), size = %d\r\n"),
        pPhys->uWindow, pWin->pVirtMem, uPhysAddr << 8, pWin->uReqSize));

    pWin->hOwner = CARDSERV_CLIENT_HANDLE;
    *pCardAddress = (UINT)pWin->pVirtMem + *pCardAddress - uStart;

    return pWin;
}   // I_MapWindow


//
// Detect whether a card is inserted in the specified socket.
//
//    Return: TRUE => card is inserted
//            FALSE => card not inserted
//
BOOL
IsCardInserted(
    UINT uSocket
    )
{
     PDCARD_SOCKET_STATE State;

    if (PDCardGetSocket(uSocket, &State) != CERR_SUCCESS) {
        return FALSE;
    }

    if (State.fNotifyEvents & EVENT_MASK_CARD_DETECT) {
        return TRUE;
    }
    return FALSE;
}


//
// Determine whether the specified CARD_CLIENT_HANDLE is valid
// Caller must aquire the controlling critical section (v_ClientCrit)
//
// Return: TRUE => valid client handle
//            FALSE => not valid
//
BOOL
IsValidClient(
    PCLIENT_DRIVER pClient
    )
{
    PCLIENT_DRIVER pClient1;
    BOOL found = FALSE;
#ifdef DEBUG
    int i = 0;
#endif

    EnterCriticalSection(&v_ClientCrit);
    pClient1 = (PCLIENT_DRIVER)v_ClientList.Flink;

    //
    // Validate handle
    //
    while (pClient1 != (PCLIENT_DRIVER)&v_ClientList) {
        if (pClient1 == pClient) {
            found = TRUE;
            break;
        }
        pClient1 = (PCLIENT_DRIVER)pClient1->List.Flink;

#ifdef DEBUG
        i++;
        if (i > 500) {
            DEBUGMSG(ZONE_WARNING, (TEXT("PCMCIA.DLL: Problem in IsValidClient()!!!\r\n")));
            break;
        }
#endif
    }

    LeaveCriticalSection(&v_ClientCrit);

    return found;
}   // IsValidClient

PCLIENT_DRIVER
FindClient(
    CARD_CLIENT_HANDLE pClient,
    BOOL fCritSec,
    BOOL fCCH
    )
{
    PCLIENT_DRIVER pClient1;
#ifdef DEBUG
    int i = 0;
#endif

    if (fCCH && pClient == (PCLIENT_DRIVER)CARDSERV_CLIENT_HANDLE)
        return CARDSERV_CLIENT_HANDLE;

    if (fCritSec)
        EnterCriticalSection(&v_ClientCrit);
    pClient1 = (PCLIENT_DRIVER)v_ClientList.Flink;

    //
    // Validate handle
    //
    while (pClient1 != (PCLIENT_DRIVER)&v_ClientList) {
        if (pClient1->hClient == pClient)
            break;
        pClient1 = (PCLIENT_DRIVER)pClient1->List.Flink;

#ifdef DEBUG
        i++;
        if (i > 500) {
            DEBUGMSG(ZONE_WARNING, (TEXT("PCMCIA.DLL: Problem in IsValidClient()!!!\r\n")));
            break;
        }
#endif
    }

    if (pClient1 == (PCLIENT_DRIVER)&v_ClientList)
        pClient1 = NULL;

    if (fCritSec)
        LeaveCriticalSection(&v_ClientCrit);

    return pClient1;
}   // FindClient


//
// Create a LOG_SOCKET structure for the specified function of a newly inserted
// card, remember stuff about it and link it to the socket structure.
//
PLOG_SOCKET
CreateFunction(
    CARD_SOCKET_HANDLE hSock
    )
{
    PLOG_SOCKET pLsock;
    PARSED_CONFIG Cfg;
    UINT BufLen;
    STATUS status;
    UCHAR buf[1024];
    PPARSED_CFTABLE pCfTable = (PPARSED_CFTABLE) buf;
    UINT i;
    PPHYS_WINDOW pPhys;
    PDCARD_WINDOW_STATE WinState;
    UINT32 CardAddress;

    pLsock = alloc(sizeof(LOG_SOCKET));
    if (pLsock == NULL) {
        DEBUGMSG(ZONE_CALLBACK|ZONE_WARNING,
            (TEXT("CreateFunction: Couldn't allocate a logical socket for %d:%d!\r\n"),
            hSock.uSocket, hSock.uFunction));
        return NULL;
    }

    pLsock->Next = NULL;
    pLsock->hSock = hSock;
    pLsock->hOwner = 0;
    pLsock->IREQList = 0;
    pLsock->pRegWin = NULL;
    pLsock->fPrevEvents = 0;
    pLsock->fChangedEvents = 0;
    pLsock->hQueryDriver = 0;

    //
    // Link it to the socket structure
    //
    EnterCriticalSection(&v_SocketCrit);
    if (v_Sockets[hSock.uSocket].pLsock != NULL) {
        pLsock->Next = v_Sockets[hSock.uSocket].pLsock;
    }
    v_Sockets[hSock.uSocket].pLsock = pLsock;
    LeaveCriticalSection(&v_SocketCrit);

#ifdef FORCE_MODEM
    pLsock->fRegisters = 0xf;
    Cfg.ConfigBase = 0x100;
    Cfg.RegMask = 0xf;
#else
    //
    // Get the CISTPL_CONFIG tuple and remember the config reg address
    // and the register presence mask.
    //
    BufLen = 1;
    status = CardGetParsedTuple(
                hSock,
                CISTPL_CONFIG,
                &Cfg,
                &BufLen);
    if (status == CERR_SUCCESS) {
        pLsock->fRegisters = Cfg.RegMask;
    } else {
        DEBUGMSG(ZONE_CALLBACK|ZONE_WARNING,
            (TEXT("CreateFunction: CardGetParsedTuple(CISTPL_CONFIG) returned %d for %d:%d\r\n"),
            status, hSock.uSocket, hSock.uFunction));
        Cfg.ConfigBase = 0;
        Cfg.RegMask = 0;
    }
#endif

#ifndef FORCE_MODEM
    if ((Cfg.ConfigBase != 0) && (Cfg.RegMask != 0)) {
        //
        // Get the CISTPL_CFTABLE_ENTRY information to determine the card's interface type.
        // If it's an I/O card, then we need to map a window to attribute memory to
        // access the config registers.
        //
        BufLen = sizeof(buf)/sizeof(PARSED_CFTABLE);
        status = CardGetParsedTuple(
                    hSock,
                    CISTPL_CFTABLE_ENTRY,
                    pCfTable,
                    &BufLen);
        if (status == CERR_SUCCESS) {
            for (i = 0; i < BufLen; i++, pCfTable++) {
                if (pCfTable->IFacePresent) {
                    if (pCfTable->IFaceType != 1) {     // 1 == I/O card
                        continue;
                    }
#endif
                    //
                    // Find a physical memory window associated with this socket.
                    //
                    EnterCriticalSection(&v_WindowCrit);
                    CardAddress = Cfg.ConfigBase;

                    // Try first to use the existing attribute window used by Tuple parser
                    pPhys = v_Sockets[hSock.uSocket].pAttrWin->pPhys;
                    if (pPhys)
                    {
                        PDCardGetWindow(pPhys->uWindow, &WinState);
                        if ((WinState.uOffset <= CardAddress) &&
                            (CardAddress + 15 <= (WinState.uOffset + WinState.uSize)))
                        {
                            // Map window into attribute space
                            pLsock->hRegWin = I_MapWindow(pPhys, &CardAddress, 15, TRUE);
                            pLsock->pRegWin = (PVOID)CardAddress;

                            DEBUGMSG(ZONE_CALLBACK|ZONE_WARNING,
                                (TEXT("CreateFunction: Re-using Tuple attribute window, Config registers @ 0x%x for %d:%d\r\n"),
                                 CardAddress, hSock.uSocket, hSock.uFunction));

                            LeaveCriticalSection(&v_WindowCrit);
                            goto cf_done;
                        }
                    }

                    // Find another window, not used by Tuple parser
                    pPhys = v_pWinList;
                    while (pPhys) {
                        if (pPhys->uSock == hSock.uSocket) {
                            if (pPhys->fWindowCaps & WIN_CAP_ATTRIBUTE) {
                                // Don't use same physical window as the Tuple parser
                                if (pPhys == v_Sockets[pPhys->uSock].pAttrWin->pPhys)
                                {
                                    pPhys = pPhys->Next;
                                    continue;
                                }

                                // Set PCMCIA offset, which is simply the start address of the page
                                // containing CardAddress (in the PC Card address space)
                                PDCardGetWindow(pPhys->uWindow, &WinState);
                                pPhys->uOffset = WinState.uOffset = PAGE_START(CardAddress);
                                PDCardSetWindow(pPhys->uWindow, &WinState);

                                // Map window into attribute space
                                pLsock->hRegWin = I_MapWindow(pPhys, &CardAddress, 15, TRUE);
                                pLsock->pRegWin = (PVOID)CardAddress;

                                DEBUGMSG(ZONE_CALLBACK|ZONE_WARNING,
                                    (TEXT("CreateFunction: Config registers @ 0x%x for %d:%d\r\n"),
                                    CardAddress, hSock.uSocket, hSock.uFunction));

                                LeaveCriticalSection(&v_WindowCrit);
                                goto cf_done;
                            }
                        }
                        pPhys = pPhys->Next;
                    }
                    LeaveCriticalSection(&v_WindowCrit);

#ifndef FORCE_MODEM
                }
            }
        } else {
            DEBUGMSG(ZONE_CALLBACK|ZONE_WARNING,
                (TEXT("CreateFunction: CardGetParsedTuple(CISTPL_CFTABLE_ENTRY) returned %d for %d:%d\r\n"),
                status, hSock.uSocket, hSock.uFunction));
        }
    }
#endif

cf_done:
    pLsock->COR_val = 0;

    return pLsock;
}


//
// Create a LOG_SOCKET structure for each function of a newly inserted card.
//
// Returns the number of functions on the newly inserted card.
//
int CreateFunctions(UINT uSocket)
{
    CARD_SOCKET_HANDLE hSock;
    UINT8 numfn;
    UINT8 fn;
    UINT Created;
    PCARD_TUPLE_PARMS pTuple;
    PCARD_DATA_PARMS pData;
    UCHAR buf[BUFFER_SIZE + sizeof(CARD_DATA_PARMS)];
    STATUS status;

    DEBUGCHK(uSocket < (UINT)v_cSockets);

    hSock.uSocket = uSocket;
    hSock.uFunction = 0;
    Created = 1;

    //
    // Function 0 must be created in order to use the tuple APIs, so create the
    // first function now.
    //
    if (CreateFunction(hSock) == NULL) {
        return 0;
    }

    //
    // Read the CISTPL_LONGLINK_MFC tuple.  If one doesn't exist, then assume
    // the card has only one function.
    //
    pTuple = (PCARD_TUPLE_PARMS)buf;
    pTuple->hSocket = hSock;
    pTuple->fAttributes = TUPLE_RETURN_LINKS;
    pTuple->uDesiredTuple = CISTPL_LONGLINK_MFC;
    status = CardGetFirstTuple(pTuple);
    if (status == CERR_SUCCESS) {
        fn = pTuple->uTupleLink;    // tuple length
        pData = (PCARD_DATA_PARMS)buf;
        pData->uTupleOffset = 0;
        pData->uBufLen = BUFFER_SIZE;
        status = CardGetTupleData(pData);
        if (status == CERR_SUCCESS) {
            //
            // The first byte of a CISTPL_LONGLINK_MFC is the number of functions
            //
            numfn = buf[sizeof(CARD_DATA_PARMS)];
            //
            // If the tuple length exactly matches what it should be for the
            // number of functions reported, then trust it.
            //
            DEBUGMSG(ZONE_CALLBACK,
                (TEXT("PCMCIA:CreateFunctions - CISTPL_LONGLINK_MFC reports %d functions\r\n"),
                numfn));
            if ((numfn * 5 + 1) >= fn) {
                if (numfn <= MAX_FUNCTIONS) {
                    for (fn = 1; fn < numfn; fn++) {
                        hSock.uFunction = fn;
                        if (CreateFunction(hSock) != NULL) {
                            Created++;
                        }
                    }
                }
            } else {
                DEBUGMSG(ZONE_CALLBACK,
                    (TEXT("PCMCIA:CreateFunctions - CISTPL_LONGLINK_MFC length=%d should be %d\r\n"),
                    fn, numfn * 5 + 1));
            }
        }
    } else {
        DEBUGMSG(ZONE_CALLBACK|ZONE_WARNING,
            (TEXT("CreateFunctions: CardGetFirstTuple(CISTPL_LONGLINK_MFC) returned %d for %d:%d\r\n"),
            status, hSock.uSocket, hSock.uFunction));
    }

    DEBUGMSG(ZONE_CALLBACK,
        (TEXT("PCMCIA:CreateFunctions - Created %d functions\r\n"),
        Created));
    v_Sockets[uSocket].cFunctions = Created;
    return Created;
}   // CreateFunctions


//
// Delete the LOG_SOCKET structures for all functions of a removed card.
//
// This function is called after the last card removal callback has returned
// so all references can be safely removed.
//
STATUS DeleteFunctions(UINT uSocket)
{
    PLOG_SOCKET pLsock;
    PCLIENT_SOCKET pCsock;
    PCLIENT_DRIVER pClient;


    //
    // Walk the list of logical sockets and remove any outstanding references.
    //
    EnterCriticalSection(&v_FindDriverCrit);
    EnterCriticalSection(&v_SocketCrit);
    while (v_Sockets[uSocket].pLsock) {
        pLsock = v_Sockets[uSocket].pLsock;

        if (pLsock->hQueryDriver != 0) {
            if (v_hGwesEvent == NULL ||
                WaitForSingleObject(v_hGwesEvent, INFINITE) != WAIT_OBJECT_0 ||
                (NULL == v_pfnPostThreadMessageW) ||
                !v_pfnPostThreadMessageW(pLsock->hQueryDriver, WM_QUIT, 0, 0)) {
                DEBUGMSG(ZONE_ERROR, (TEXT("DeleteFunctions(%d.%d): v_pfnPostThreadMessage failed(%d)\r\n"),
                    uSocket, pLsock->hSock.uFunction, GetLastError()));
            }
            pLsock->hQueryDriver = 0;
        }

        //
        // Find and remove all client references to this logical socket.
        //
        EnterCriticalSection(&v_ClientCrit);
        pClient = (PCLIENT_DRIVER)v_ClientList.Flink;
        while (pClient != (PCLIENT_DRIVER)&v_ClientList) {
            if (pClient->pCsock) {
                pCsock = I_FindClientSocket(pLsock->hSock, pClient);
                if (pCsock) {
                    I_RemoveClientSocket(pCsock, pClient);
                }
            }
            pClient = (PCLIENT_DRIVER)pClient->List.Flink;
        }
        LeaveCriticalSection(&v_ClientCrit);

        v_Sockets[uSocket].pLsock = pLsock->Next;
        if (pLsock->hRegWin) {
            I_DeleteLogicalWindow(pLsock->hRegWin);
        }
        free(pLsock);
    }

    //
    // Free the memory mappings to the card's CIS
    //
    if (v_Sockets[uSocket].pAttrWin) {
        I_DeleteLogicalWindow(v_Sockets[uSocket].pAttrWin);
        v_Sockets[uSocket].pAttrWin = NULL;
    }
    if (v_Sockets[uSocket].pCmnWin) {
        I_DeleteLogicalWindow(v_Sockets[uSocket].pCmnWin);
        v_Sockets[uSocket].pCmnWin = NULL;
    }

    //
    // Free the device id string
    //
    if (v_Sockets[uSocket].pDevId) {
        free(v_Sockets[uSocket].pDevId);
        v_Sockets[uSocket].pDevId = NULL;
    }

    v_Sockets[uSocket].cFunctions = 0;
    LeaveCriticalSection(&v_SocketCrit);
    LeaveCriticalSection(&v_FindDriverCrit);
    return CERR_SUCCESS;
}   // DeleteFunctions

//
// RemoveCallbacks - remove all callbacks for a deregistering client or
// for an aborted multi-callback event or CE_PM_RESUMEs.
//
VOID
RemoveCallbacks(
    PCLIENT_DRIVER pClient,
    CARD_SOCKET_HANDLE hSock,
    CARD_EVENT MajorEvent,
    DWORD evType
    )
{
    PCALLBACK_STRUCT pCur, pPrev, pDel;
    BOOL bRemove;
    //
    // Callback events are removed for these 3 situations:
    // 1. One of the client drivers rejected a query request.  Remove
    // all events associated with the failing one.
    //
    // 2. A client driver is deregistering.  All callbacks associated
    // with this client are removed except those that are the last in a
    // callback sequence.
    //
    // 3. Remove all CE_PM_RESUMEs on power on to in case the sequence of
    // removals and inserts got interrupted by a power off.
    //

    switch (evType) {
    case REMOVE_QUERY:
    case REMOVE_DEREGISTER:
    case REMOVE_PM_RESUME:
    case REMOVE_INIT_MFC:
        break;
    default:
        return;
    }

    EnterCriticalSection(&v_CallbackCrit);
    pCur = pPrev = v_CallbackHead;

    while (pCur) {
        bRemove = FALSE;
        switch (evType) {
        case REMOVE_QUERY:
             if ((pCur->pReqClient == pClient) &&
                 (pCur->hSock.uSocket == hSock.uSocket) &&
                 (pCur->hSock.uFunction == hSock.uFunction)&&
                 (pCur->MajorEvent == MajorEvent)) {
                 bRemove = TRUE;
             }
             break;

        case REMOVE_DEREGISTER:
             if ((!(pCur->fFlags & CALLBACK_FLAG_LAST)) &&
                 ((pCur->pReqClient == pClient) ||
                  (pCur->pDestClient == pClient))) {
                 bRemove = TRUE;
             }
             break;

        case REMOVE_PM_RESUME:
             if (pCur->MajorEvent == CE_PM_RESUME) {
                 bRemove = TRUE;
             }
             break;

        case REMOVE_INIT_MFC:
             if ((pCur->hSock.uSocket == hSock.uSocket) &&
                 (pCur->hSock.uFunction == hSock.uFunction)&&
                 (pCur->MajorEvent == CE_CARD_INSERTION)) {
                 bRemove = TRUE;
             }
             break;
         }

        if (bRemove) {
            pDel = pCur;
            if (v_CallbackTail == pCur) {
                v_CallbackTail = pPrev;
            }
            if (pPrev == pCur) {
                v_CallbackHead = pCur->Next;
                if (v_CallbackHead == NULL) {
                    v_CallbackTail = NULL;
                }
                pPrev = pCur->Next;
                pCur = pPrev;
            } else {
                pPrev->Next = pCur->Next;
                pCur = pPrev->Next;
            }
            free(pDel);
        } else {
            pPrev = pCur;
            pCur = pCur->Next;
        }
    }
#ifdef DEBUG
    if (v_CallbackHead == NULL) {
       if (v_CallbackTail != NULL) {
            DEBUGMSG(1|ZONE_ERROR|ZONE_CALLBACK,
                (TEXT("RemoveCallbacks:v_CallbackHead=0 but v_CallbackTail = 0x%x\r\n"),
                v_CallbackTail));
       }
    }
    if (v_CallbackTail == NULL) {
       if (v_CallbackHead != NULL) {
            DEBUGMSG(1|ZONE_ERROR|ZONE_CALLBACK,
                (TEXT("RemoveCallbacks:v_CallbackTail=0 but v_CallbackHead = 0x%x\r\n"),
                v_CallbackHead));
       }
    }
#endif
    LeaveCriticalSection(&v_CallbackCrit);
}   // RemoveCallbacks


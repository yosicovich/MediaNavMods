//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

    intr.c

Abstract:

    This file implements the PCMCIA model device driver interrupt threads and
    apis.  This is provided as a sample to platform writers and is
    expected to be able to be used without modification on most (if not
    all) hardware platforms.

Functions:

    CardRequestIRQ()
    CardReleaseIRQ()
    ClearFCSRInterrupt()
    CallClientISR()
    CallClientISRs()
    IREQThread()
    DisplayBatteryMsg()
    BatteryCheck()
    StatusChangeThread()

Notes:


--*/


#include <windows.h>
#include <types.h>
#include <excpt.h>
#include <cardserv.h>    // ddk\inc
#include <sockserv.h>    // oak\inc
#include <pcmres.h>
#include <pcmcia.h>
#include <nkintr.h>
#include <windev.h>
#include <extern.h>
#include <celog.h>

#define REQUIRED_INTR_EVENTS    (EVENT_MASK_CARD_DETECT)
#define POLL_TIMEOUT        1000
#define INTR_POLL_TIMEOUT1       0x0100
#define INTR_POLL_TIMEOUT2       0x0300

HANDLE v_hGwesEvent;
UINT16 v_fPrevEvents[MAX_SOCKETS];
UINT16 v_fChangedEvents[MAX_SOCKETS];
BOOL v_fBattery[MAX_SOCKETS];
DWORD v_hBatteryThread[MAX_SOCKETS];
BOOL v_bSharedIntr = FALSE;
CRITICAL_SECTION v_BatteryCrit;
extern HINSTANCE g_hPcmDll;    // init.c

//
// CardRequestIRQ
//
// @doc DRIVERS
//
// @func    STATUS | CardRequestIRQ | Request interrupt notification for the specified socket/function
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_ARGS, CERR_BAD_HANDLE, CERR_BAD_SOCKET
//          or CERR_IN_USE.
//
// @comm    This function sets up the interrupt callback exclusively for the requesting client.
//          Interrupts will not be signalled until the PC card is configured for the I/O interface
//          via the <f CardRequestConfiguration> API.
//
STATUS
CardRequestIRQ(
    CARD_CLIENT_HANDLE hCardClient, // @parm Client handle from <f CardRegisterClient>
    CARD_SOCKET_HANDLE hSocket,     // @parm Socket/function identifier (logical socket)
    CARD_ISR ISRFunction,           // @parm Pointer to the interrupt callback function
    UINT32 uISRContextData          // @parm Context that will be passed to the ISRFunction
    )
{
    PCLIENT_DRIVER pClient;
    PLOG_SOCKET pLsock;
    PIREQ_OBJ pIREQ;
    STATUS status = CERR_SUCCESS;
    BOOL bSignalInt = FALSE;

    DEBUGMSG(ZONE_FUNCTION|ZONE_IREQ,
        (TEXT("PCMCIA:CardRequestIRQ entered\r\n")));

    //
    // Perform some parameter checks first
    //
    if (ISRFunction == NULL) {
        status = CERR_BAD_ARGS;
        goto req_irq_exit;
    }

    if ((pClient = FindClient(hCardClient, TRUE, TRUE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto req_irq_exit;
    }

    //
    // The socket must already exist.
    //
    pLsock = I_FindSocket(hSocket);
    if (pLsock == NULL) {
        status = CERR_BAD_SOCKET;
        goto req_irq_exit;
    }

    if ((pLsock->hOwner != 0) &&
        (pLsock->hOwner != pClient) &&
        (pLsock->fFlags & OWNER_FLAG_EXCLUSIVE)) {
        DEBUGMSG(ZONE_WARNING,
            (TEXT("PCMCIA:CardRequestIRQ: Exclusive owner is %x, caller is %x\r\n"),
                 pLsock->hOwner, hCardClient));
        status = CERR_IN_USE;
        goto req_irq_exit;
    }

    pIREQ = LocalAlloc(LPTR, sizeof(IREQ_OBJ));
    if (pIREQ == NULL) {
        status = CERR_OUT_OF_RESOURCE;
        goto req_irq_exit;
    }

    pLsock->fFlags |= OWNER_FLAG_INTERRUPT;
    if (pLsock->hOwner == 0) {
        pLsock->hOwner = pClient;
    }

    //
    // Enable the interrupt if this is the first interrupt owner for this card
    // and the card is in I/O mode.
    //
    if ((pLsock->IREQList == NULL) && (pLsock->fFlags & OWNER_FLAG_CONFIG)) {
        bSignalInt = TRUE;
    }

    pIREQ->Next = NULL;
    pIREQ->hOwner = pClient;
    pIREQ->ISRFn = ISRFunction;
    pIREQ->uISRContext = uISRContextData;
    EnterCriticalSection(&v_SocketCrit);
    pIREQ->Next = pLsock->IREQList;
    pLsock->IREQList = pIREQ;
    LeaveCriticalSection(&v_SocketCrit);

    if (bSignalInt) {
        DEBUGMSG(ZONE_IREQ, (TEXT("PCMCIA:CardRequestIRQ:Signalling IREQThread\r\n")));
        SetEvent(v_IREQEvent);
    }

req_irq_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR|ZONE_IREQ,
            (TEXT("PCMCIA:CardRequestIRQ failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION|ZONE_IREQ,
            (TEXT("PCMCIA:CardRequestIRQ succeeded\r\n")));
    }
#endif
    return status;
}   // CardRequestIRQ


//
// CardReleaseIRQ
//
// @func    STATUS | CardReleaseIRQ | Releases ownership of the interrupt for the specified
//                                    socket/function
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE, CERR_BAD_SOCKET,
//          CERR_CONFIGURATION_LOCKED or CERR_IN_USE.
//
// @comm    The PC card must first be configured for the memory-only interface via the
//          <f CardReleaseConfiguration> API.
//
STATUS
CardReleaseIRQ(
    CARD_CLIENT_HANDLE hCardClient, // @parm Client handle from <f CardRegisterClient>
    CARD_SOCKET_HANDLE hSocket      // @parm Socket/function identifier (logical socket)
    )
{
    PCLIENT_DRIVER pClient;
    PLOG_SOCKET pLsock;
    PDCARD_SOCKET_STATE State;
    PIREQ_OBJ pPrev;
    PIREQ_OBJ pCurr;
    STATUS status = CERR_SUCCESS;

    DEBUGMSG(ZONE_FUNCTION|ZONE_IREQ,
        (TEXT("PCMCIA:CardReleaseIRQ entered\r\n")));

    //
    // Perform some parameter checks first
    //
    if ((pClient = FindClient(hCardClient, TRUE, TRUE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto rel_irq_exit;
    }

    //
    // Find the socket
    //
    pLsock = I_FindSocket(hSocket);
    if (pLsock == NULL) {
        status = CERR_BAD_SOCKET;
        goto rel_irq_exit;
    }

    //
    // See if the caller is in our list.
    //
    if (pLsock->IREQList == NULL) {
        status = CERR_BAD_ARGS;
        goto rel_irq_exit;
    }

    EnterCriticalSection(&v_SocketCrit);
    pPrev = pCurr = pLsock->IREQList;
    while (pCurr) {
        if (pCurr->hOwner == pClient) {
            break;
        }
        pPrev = pCurr;
        pCurr = pCurr->Next;
    }
    if (pCurr == NULL) {
        status = CERR_BAD_ARGS;
        LeaveCriticalSection(&v_SocketCrit);
        goto rel_irq_exit;
    }

    //
    // Unlink this interrupt object
    //
    if (pCurr == pLsock->IREQList) {
        pLsock->IREQList = pCurr->Next;
    } else {
        pPrev->Next = pCurr->Next;
    }
    LeaveCriticalSection(&v_SocketCrit);
    LocalFree(pCurr);

    //
    // Turn off the IREQ interrupt on this socket if there are no more
    // interrupt requesters.
    //
    if (pLsock->IREQList == NULL) {
        pLsock->fFlags &= ~OWNER_FLAG_INTERRUPT;
        if (status = PDCardGetSocket(hSocket.uSocket, &State)) {
            goto rel_irq_exit;
        }

        State.fIREQRouting &= ~SOCK_IREQ_ENABLE;
        PDCardSetSocket(hSocket.uSocket, &State);
    }

    if (pLsock->hOwner == pClient) {
        if (pLsock->fFlags == 0) {
            pLsock->hOwner = NULL;
        } else if (pLsock->IREQList) {
            pLsock->hOwner = pLsock->IREQList->hOwner;
        }
    }

rel_irq_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR|ZONE_IREQ,
            (TEXT("PCMCIA:CardReleaseIRQ failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION|ZONE_IREQ,
            (TEXT("PCMCIA:CardReleaseIRQ succeeded\r\n")));
    }
#endif
    return status;
}   // CardReleaseIRQ


//
// Clear the INTR bit in the FCSR (function configuration and status register)
// to indicate that software has processed the interrupt.
//
void
ClearFCSRInterrupt(
    PLOG_SOCKET pLsock
    )
{
    UINT8 uFSCR;

    if (pLsock->fRegisters & CFG_REGISTER_STATUS) {
        CardReadAttrByte(
            pLsock->pRegWin,
            FCR_OFFSET_FCSR,
            &uFSCR);
        uFSCR &= ~FCR_FCSR_INTR;
        uFSCR |= FCR_FCSR_INTR_ACK;
        CardWriteAttrByte(pLsock->pRegWin,FCR_OFFSET_FCSR, uFSCR);
    }
}   // ClearFCSRInterrupt


//
// Call client driver's "ISR" in a protected manner.
//
// Return TRUE if client serviced the interrupt without problems.
//
BOOL
CallClientISR(
    CARD_ISR ISRFn,
    UINT32 uISRContext
    )
{
    BOOL ret = FALSE;

    if (ISRFn) {
        try {
            (ISRFn)(uISRContext);
            ret = TRUE;
            DEBUGMSG(ZONE_IREQ,
                (TEXT("PCMCIA:CallClientISR - returned from Client ISR\r\n")));
        } except (GetExceptionCode() == STATUS_ACCESS_VIOLATION ?
                EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
            DEBUGMSG(ZONE_IREQ,
                (TEXT("PCMCIA:CallClientISR - Client ISR caused an exception\r\n")));
        }
    }
    return ret;
}   // CallClientISR

//
// Function to notify all the interrupt owners of a logical socket.
//
// Return TRUE if at least one of the clients serviced the interrupt.
//
BOOL
CallClientISRs(
    PLOG_SOCKET pLsock
    )
{
    PIREQ_OBJ pIREQ;
    BOOL ret;

    //
    // If there are no interrupt owners, then bail.
    //
    if (!(pLsock->fFlags & OWNER_FLAG_INTERRUPT)) {
        return FALSE;
    }

    ret = FALSE;

    EnterCriticalSection(&v_SocketCrit);
    pIREQ = pLsock->IREQList;

    while (pIREQ) {
        if (CallClientISR(pIREQ->ISRFn, pIREQ->uISRContext)) {
            ret = TRUE;
        }
        pIREQ = pIREQ->Next;
    }
    LeaveCriticalSection(&v_SocketCrit);
    return ret;
}   // CallClientISRs

//
// Function to process PCMCIA "data" interrupts (IREQ).  When the the IREQ event
// gets signaled, this function will determine which socket and function caused
// the interrupt and will call the associated client's "ISR" (registered with
// CardRequestIRQ).
//
UINT IREQThread(UINT Nothing)
{
    PDCARD_SOCKET_STATE State;
    UINT8 uFSCR;
    UINT  uSocket;
    PLOG_SOCKET pLsock;
    PPHYS_SOCKET pPsock;
    BOOL bKeepIntEnabled;
    BOOL stat;
    BOOL bLoop;

    while (1) {
        stat = WaitForSingleObject(v_IREQEvent, INFINITE);
        if (v_bSharedIntr) SetEvent(v_StatusChangeEvent);
        do {
            bLoop = FALSE;
            for (uSocket = 0, pPsock = v_Sockets;
                 uSocket < (UINT8)v_cSockets;
                 uSocket++, pPsock++) {

                bKeepIntEnabled = FALSE;
                if (PDCardGetSocket(uSocket, &State) != CERR_SUCCESS) {
                    DEBUGMSG(ZONE_IREQ|ZONE_WARNING,
                     (TEXT("PCMCIA:IREQInt - Unable to get status of socket %d\r\n"),
                     uSocket));
                    continue;
                }

                //
                // If sharing interrupts, check for missed card insertion/removal
                //
                if (v_bSharedIntr &&
                    (State.fNotifyEvents & EVENT_MASK_CARD_DETECT) != (v_fPrevEvents[uSocket] & EVENT_MASK_CARD_DETECT)) {
                    DEBUGMSG(ZONE_IREQ,
                         (TEXT("PCMCIA:IREQInt Current CD does not match v_fPrevEvents CD\r\n")));
                    SetEvent(v_StatusChangeEvent);
                }

                //
                // Ignore if there is no card inserted.
                //
                if (!(State.fNotifyEvents & EVENT_MASK_CARD_DETECT) ||
                    v_Sockets[uSocket].PowerState == POWER_OFF ||
                    v_Sockets[uSocket].PowerState == POWER_RESET) {
                    if (State.fIREQRouting & SOCK_IREQ_ENABLE) {
                        DEBUGMSG(ZONE_IREQ,
                          (TEXT("PCMCIA:IREQInt clearing SOCK_IREQ_ENABLE for socket %d\r\n"),
                          uSocket));
                        State.fIREQRouting &= ~SOCK_IREQ_ENABLE;
                        PDCardSetSocket(uSocket, &State);
                    }
                    continue;
                }

                pLsock = pPsock->pLsock;
                if (pLsock == NULL) {
                    if (State.fIREQRouting & SOCK_IREQ_ENABLE) {
                        RETAILMSG(1,
                            (TEXT("PCMCIA:IREQInt: Got interrupt, but no IREQ owner!!!\r\n")));
                        State.fIREQRouting &= ~SOCK_IREQ_ENABLE;
                        PDCardSetSocket(uSocket, &State);
                    }
                    continue;
                }

                //
                // Turn on IREQ interrupt due to CardRequestIRQ or CardRequestConfiguration
                //
                if (!(State.fIREQRouting & SOCK_IREQ_ENABLE)) {
                    //
                    // Check each function for an interrupt owner
                    //
                    while (pLsock) {
                        if ((pLsock->fFlags & OWNER_FLAG_INTERRUPT) &&
                            (pLsock->fFlags & OWNER_FLAG_CONFIG)) {
                            break;  // found an owner, so enable interrupts
                        }
                        pLsock = pLsock->Next;
                    }
                    if (pLsock == NULL) {
                        continue;
                    }
                    DEBUGMSG(ZONE_IREQ,
                     (TEXT("PCMCIA:IREQInt setting SOCK_IREQ_ENABLE for socket %d\r\n"),
                      uSocket));
                    State.fIREQRouting |= SOCK_IREQ_ENABLE;
                    PDCardSetSocket(uSocket, &State);
                }

                //
                // Check each function to see if it interrupted
                //
                pLsock = pPsock->pLsock;
                while (pLsock) {
                    if (!(pLsock->FCSR_val & FCR_FCSR_PWR_DOWN)) {
                        if (!(pLsock->fFlags & LOG_SOCK_FLAG_NO_INTR_ACK) &&
                            pLsock->fRegisters & (1 << FCR_OFFSET_FCSR)) {                   
                            CardReadAttrByte(
                                pLsock->pRegWin,
                                FCR_OFFSET_FCSR,
                                &uFSCR);
                            if (!(uFSCR & FCR_FCSR_INTR)) {
                                pLsock = pLsock->Next;
                                bKeepIntEnabled |= TRUE;
                                continue;
                            }
                            ClearFCSRInterrupt(pLsock);
                            bKeepIntEnabled |= CallClientISRs(pLsock);
                            bLoop = TRUE;
                        } else {
                            bKeepIntEnabled |= CallClientISRs(pLsock);
                        }
                    }
                    pLsock = pLsock->Next;
                }
    
                //
                // If no clients are interested in interrupts for this socket, then disable them
                //
                if (bKeepIntEnabled == FALSE) {
                    DEBUGMSG(ZONE_IREQ, (TEXT("PCMCIA:IREQInt clearing SOCK_IREQ_ENABLE for socket %d\r\n"), uSocket));
                    State.fIREQRouting &= ~SOCK_IREQ_ENABLE;
                    PDCardSetSocket(uSocket, &State);
                }
            }   // for all sockets
        } while (bLoop);

        InterruptDone(gIntrPcmciaLevel);

    }
    return 0;
//    return bKeepIntEnabled;
}   // IREQThread


//
// Function to display the "using a PC card on battery power" message.
//
// Return TRUE if the user wants to use the PC card on battery power
//
DWORD WINAPI
DisplayBatteryMsg(
    LPVOID lpvarg
    )
{
#define MAX_TITLE 100
    BOOL bCallback = FALSE;
    CARD_SOCKET_HANDLE hSock;
    UINT uSocket = (int)lpvarg;
    LPCTSTR NewCardTitle;
    TCHAR TitleOut[MAX_TITLE] = TEXT("");
    LPCTSTR NewCardMsg;

    //
    // If gwes.exe is not running yet, then can't call its API functions
    //
    if (v_hGwesEvent == NULL) {
        v_Sockets[uSocket].fFlags |= PHYS_SOCK_FLAG_POWER_ON;
        return TRUE;
    }
    WaitForSingleObject(v_hGwesEvent, INFINITE);

    if ((v_pfnLoadStringW == NULL) || (v_pfnMessageBoxW == NULL)) {
        DEBUGMSG(ZONE_POWER|ZONE_STSCHG,
            (TEXT("PCMCIA:Can't find LoadString or MessageBox\r\n")));
        EnterCriticalSection(&v_BatteryCrit);
        if (GetCurrentThreadId() == v_hBatteryThread[uSocket]) {
            v_hBatteryThread[uSocket] = 0;
            v_fBattery[uSocket] = TRUE;
            bCallback = TRUE;
                        v_Sockets[uSocket].fFlags |= PHYS_SOCK_FLAG_POWER_ON;
        } else
                DEBUGMSG(ZONE_POWER|ZONE_WARNING,
                     (TEXT("PCMCIA:BatteryCheck: Thread already replaced\r\n")));
        LeaveCriticalSection(&v_BatteryCrit);
        if (bCallback) {
            hSock.uSocket = uSocket;
            hSock.uFunction = 0;
            CallbackOne(CE_CARDSERV_LOAD, 0, NULL, hSock);
        }
        return TRUE;
    }

    NewCardTitle = (LPCTSTR) v_pfnLoadStringW(g_hPcmDll,
                                IDS_PCMCIA_NEW_CARD_TITLE, NULL, 0);
    if (NewCardTitle == 0) {
        EnterCriticalSection(&v_BatteryCrit);
        if (GetCurrentThreadId() == v_hBatteryThread[uSocket]) {
            v_hBatteryThread[uSocket] = 0;
            v_fBattery[uSocket] = FALSE;
                        v_Sockets[uSocket].fFlags &= ~PHYS_SOCK_FLAG_POWER_ON;
        } else
                DEBUGMSG(ZONE_POWER|ZONE_WARNING,
                     (TEXT("PCMCIA:BatteryCheck: Thread already replaced\r\n")));
        LeaveCriticalSection(&v_BatteryCrit);
        return FALSE;
    }

    NewCardMsg = (LPCTSTR) v_pfnLoadStringW(g_hPcmDll,
                                IDS_PCMCIA_NEW_CARD_MSG, NULL, 0);
    if (NewCardMsg == 0) {
        EnterCriticalSection(&v_BatteryCrit);
        if (GetCurrentThreadId() == v_hBatteryThread[uSocket]) {
            v_hBatteryThread[uSocket] = 0;
            v_fBattery[uSocket] = FALSE;
                        v_Sockets[uSocket].fFlags &= ~PHYS_SOCK_FLAG_POWER_ON;
        } else
                DEBUGMSG(ZONE_POWER|ZONE_WARNING,
                     (TEXT("PCMCIA:BatteryCheck: Thread already replaced\r\n")));
        LeaveCriticalSection(&v_BatteryCrit);
        return FALSE;
    }

    if (_tcslen(NewCardTitle) < MAX_TITLE) {
        //
        // There's enough room to copy the formatted title, else use empty string.
        //
        wsprintf(TitleOut, NewCardTitle, uSocket+1);
    } else {
        DEBUGMSG(1, (TEXT("PCMCIA:Title string too long! (%a @ %d)\r\n"), __FILE__, __LINE__));
    }
    if (v_pfnMessageBoxW(NULL, NewCardMsg, TitleOut,
            MB_YESNO|MB_SETFOREGROUND|MB_TOPMOST|MB_DEFBUTTON2) != IDYES) {
        EnterCriticalSection(&v_BatteryCrit);
        if (GetCurrentThreadId() == v_hBatteryThread[uSocket]) {
            v_hBatteryThread[uSocket] = 0;
            v_fBattery[uSocket] = FALSE;
                        v_Sockets[uSocket].fFlags &= ~PHYS_SOCK_FLAG_POWER_ON;
        } else
                DEBUGMSG(ZONE_POWER|ZONE_WARNING,
                     (TEXT("PCMCIA:BatteryCheck: Thread already replaced\r\n")));
        LeaveCriticalSection(&v_BatteryCrit);
        return FALSE;
    }
    EnterCriticalSection(&v_BatteryCrit);
    if (GetCurrentThreadId() == v_hBatteryThread[uSocket]) {
        v_hBatteryThread[uSocket] = 0;
        v_fBattery[uSocket] = TRUE;
        bCallback = TRUE;
                v_Sockets[uSocket].fFlags |= PHYS_SOCK_FLAG_POWER_ON;
    } else
            DEBUGMSG(ZONE_POWER|ZONE_WARNING,
                 (TEXT("PCMCIA:BatteryCheck: Thread already replaced\r\n")));
    LeaveCriticalSection(&v_BatteryCrit);
    if (bCallback) {
        hSock.uSocket = uSocket;
        hSock.uFunction = 0;
        CallbackOne(CE_CARDSERV_LOAD, 0, NULL, hSock);
    }
    return TRUE;
}


//
// Function to query the user about using a PC card while on battery power.
//
// Return TRUE if the user wants to use the PC card on battery power or if the
// system is running on AC power.
//
BOOL
BatteryCheck(
    UINT8 uSocket
    )
{
    SYSTEM_POWER_STATUS_EX PowerStatus;
    DWORD   dwLen;
    DWORD   dwValue;

    dwValue = FALSE;    // Set default
    dwLen = sizeof(dwValue);
    RegQueryValueEx(HKEY_LOCAL_MACHINE, L"NoBatteryCheck",
                    (LPDWORD) L"Drivers\\Pcmcia", NULL,
                    (LPBYTE) &dwValue, &dwLen);

    if (dwValue) {
        DEBUGMSG (1, (TEXT("Ignoring battery check\r\n")));
                v_Sockets[uSocket].fFlags |= PHYS_SOCK_FLAG_POWER_ON;
        return TRUE;
    }

    //
    // If we are on battery power, prompt the user to see if he wants his
    // battery drained (PC cards are typically very power hungry).  Remember his
    // response in the physical socket structure so we don't have to re-prompt
    // everytime we come back from standby.  The user will have to remove and
    // reinsert the card with power on in order to get prompted again.
    //
    DEBUGMSG(ZONE_POWER, (TEXT("Before Battery Check fFlags for socket %d = %x\r\n"),uSocket,v_Sockets[uSocket].fFlags));
    if (v_Sockets[uSocket].fFlags & PHYS_SOCK_FLAG_FROM_STANDBY) {
        DEBUGMSG(ZONE_POWER|ZONE_STSCHG,
            (TEXT("PCMCIA:BatteryCheck returning %s.\r\n"),
            (v_Sockets[uSocket].fFlags & PHYS_SOCK_FLAG_POWER_ON) ?
                 TEXT("TRUE") : TEXT("FALSE")));
        return (v_Sockets[uSocket].fFlags & PHYS_SOCK_FLAG_POWER_ON) ? TRUE:FALSE;
    }

    if (NULL == v_pfnGetSystemPowerStatusEx) {
        DEBUGMSG(ZONE_POWER|ZONE_STSCHG,
            (TEXT("PCMCIA:Couldn't getprocaddr of GetSystemPowerStatusEx\r\n")));
        goto BatteryCheckExit;
    }

    if (v_pfnGetSystemPowerStatusEx(&PowerStatus, TRUE)) {
        DEBUGMSG(ZONE_POWER|ZONE_STSCHG,
            (TEXT("PCMCIA:BatteryCheck:ACLineStatus = %d\r\n"), PowerStatus.ACLineStatus));
        if (PowerStatus.ACLineStatus != AC_LINE_ONLINE && !v_fBattery[uSocket]) {
            HANDLE hThd;
            DWORD dSocket;

            if (v_hBatteryThread[uSocket] != 0) {
                DEBUGMSG(ZONE_POWER|ZONE_WARNING,
                     (TEXT("PCMCIA:BatteryCheck: Warning!  Battery Thread not NULL!\r\n")));
                v_Sockets[uSocket].fFlags &= ~PHYS_SOCK_FLAG_POWER_ON;
                return FALSE;
            }

            EnterCriticalSection(&v_BatteryCrit);

            dSocket = uSocket;
            hThd = CreateThread(NULL, 0,
                        (LPTHREAD_START_ROUTINE)DisplayBatteryMsg,
                        (LPVOID)dSocket,
                        0,
                        &v_hBatteryThread[uSocket]);
            if (hThd) {
                CloseHandle(hThd);
            } else {
                DEBUGMSG(ZONE_POWER,
                    (TEXT("PCMCIA:BatteryCheck: CreateThread failed %d\r\n"),
                    GetLastError()));
            }
            LeaveCriticalSection(&v_BatteryCrit);
            v_Sockets[uSocket].fFlags &= ~PHYS_SOCK_FLAG_POWER_ON;
            return FALSE;
/*
            if (DisplayBatteryMsg(uSocket) == FALSE) {
                v_Sockets[uSocket].fFlags &= ~PHYS_SOCK_FLAG_POWER_ON;
                DEBUGMSG(ZONE_POWER|ZONE_STSCHG,
                    (TEXT("PCMCIA:BatteryCheck returning FALSE\r\n")));
                return FALSE;
            }
*/
        }
    } else {
        DEBUGMSG(ZONE_POWER|ZONE_STSCHG,
            (TEXT("PCMCIA:BatteryCheck:GetSystemPowerStatusEx failed %d\r\n"),
            GetLastError()));
    }

BatteryCheckExit:
    v_Sockets[uSocket].fFlags |= PHYS_SOCK_FLAG_POWER_ON;
    DEBUGMSG(ZONE_POWER|ZONE_STSCHG, (TEXT("PCMCIA:BatteryCheck TRUE-fFlag for Socket %d is %x\r\n"),uSocket,v_Sockets[uSocket].fFlags));
    return TRUE;
}   // BatteryCheck


//
// Function to process PCMCIA status change interrupts.  When the status change
// event gets signaled, this thread will determine what caused the interrupt
// and then perform appropriate callbacks to the client drivers.
//
UINT
StatusChangeThread(
    UINT Nothing
    )
{
    UINT16 fChanged;
    UINT16 fChangeBack;
//    UINT16 fPRROn;
    UINT16 fCurr;
    UINT   uSocket;
    UINT   uFunction;
    UINT   ret;
    UINT   uTimeOut = INFINITE;
    PDCARD_SOCKET_STATE State;
    CARD_SOCKET_HANDLE hSock;
    CARD_EVENT EventCode;
//    UINT CallbackFlags;
    UINT8  fEvents[MAX_FUNCTIONS];
    UINT   bChanged;

    PPHYS_SOCKET pPsock;
    PLOG_SOCKET pLsock;
    UINT8 uPRR;
#ifdef DEBUG
    TCHAR OutBuf[128];
#endif
    //
    // Check if we need to poll card status
    //
    for (uSocket = 0; uSocket < (UINT8)v_cSockets; uSocket++) {
        v_fPrevEvents[uSocket] = 0;
        //
        // See if we need to poll for card detect and other events
        // (The interrupt events are in the low byte of the fFlags field)
        //
        if (!(v_Sockets[uSocket].fFlags & REQUIRED_INTR_EVENTS)) {
//            uTimeOut = POLL_TIMEOUT;
        }
    }

    //
    // We'll need to poll for status change if we were unable to get an interrupt
    //
    if (v_StatusChangeEvent == NULL) {
        v_StatusChangeEvent = CreateEvent(NULL, FALSE, FALSE , NULL);
        uTimeOut = POLL_TIMEOUT;
    }

#ifdef DEBUG
    if (uTimeOut == POLL_TIMEOUT) {
        DEBUGMSG(ZONE_INIT|ZONE_STSCHG|ZONE_WARNING,
            (TEXT("PCMCIA:StatusChangeThread - PCMCIA driver is resorting to polling for Status Change.\r\n")));
    }
#endif

    //
    // Wait for PCMCIA interrupts and process them
    //
    while (1) {
        ret = WaitForSingleObject(v_StatusChangeEvent, uTimeOut);
        DEBUGMSG(ZONE_STSCHG, (TEXT("PCMCIA:StatusChangeInt signalled\r\n")));

        for (uSocket = 0, pPsock = v_Sockets; uSocket < (UINT8)v_cSockets; uSocket++, pPsock++) {

            if (PDCardGetSocket(uSocket, &State) != CERR_SUCCESS) {
                DEBUGMSG(ZONE_STSCHG|ZONE_WARNING,
                 (TEXT("PCMCIA:StatusChangeInt - Unable to get status of socket %d\r\n"),
                  uSocket));
                continue;
            }
            hSock.uFunction = 0;

            DEBUGMSG(ZONE_STSCHG, (TEXT("PCMCIA:StatusChangeInt socket %d events = %x\r\n"),uSocket,State.fNotifyEvents));
            hSock.uSocket = uSocket;

            for (uFunction = 0; uFunction < MAX_FUNCTIONS; uFunction++)
                fEvents[uFunction] = 0;
            bChanged = FALSE;
//          fPRROn = 0;

            //
            // Check for events which may have been caused by STSCHG -- the PDD may report
            // these as battery low events, since the STSCHG pin is mapped to BVD1 in IO mode.
            //
            if ((State.fNotifyEvents & EVENT_MASK_CARD_DETECT) &&
                (State.fNotifyEvents &
                (EVENT_MASK_STATUS_CHANGE | EVENT_MASK_BATTERY_DEAD | EVENT_MASK_BATTERY_LOW))) {
                //
                // If card is in I/O mode, and supports a pin replacement
                // register, read status from PRR. Note -- won't work for multi function cards.
                //
                pLsock = pPsock->pLsock;
                if (pLsock == NULL) {
                    DEBUGMSG(ZONE_STSCHG|ZONE_WARNING,
                             (TEXT("PCMCIA:StatusChangeInt - Unable to get logical socket %d\r\n"),
                              uSocket));
                } else if (v_Sockets[uSocket].PowerState != POWER_OFF &&
                           v_Sockets[uSocket].PowerState != POWER_KEPT &&
                           v_Sockets[uSocket].PowerState != POWER_RESET) {
                    for (; pLsock != NULL; pLsock = pLsock->Next) {
                        uFunction = pLsock->hSock.uFunction;
                        if (uFunction < 0 || uFunction >= MAX_FUNCTIONS) {
                            DEBUGMSG((ZONE_STSCHG|ZONE_WARNING),
                                (TEXT("PCMCIA:StatusChangeThread: invalid function %d\n\r"),
                                    uFunction));
                            continue;
                        }
                         if ((!(pLsock->FCSR_val & FCR_FCSR_PWR_DOWN)) &&  // Not powered down
                             (pLsock->fFlags & OWNER_FLAG_CONFIG) &&       // IO mode
                             (pLsock->fRegisters & CFG_REGISTER_PIN)) {
                             // Using Pin Replacement Register, clear existing event mask
                            if (!bChanged)
                                State.fNotifyEvents &= ~(EVENT_MASK_STATUS_CHANGE |
                                                         EVENT_MASK_BATTERY_DEAD  |
                                                         EVENT_MASK_BATTERY_LOW);
                            bChanged = TRUE;
                            CardReadAttrByte(pLsock->pRegWin,FCR_OFFSET_PRR,&uPRR);
                            DEBUGMSG(ZONE_STSCHG,
                                (TEXT("PCMCIA:StatusChangeInt: Read value 0x%X from PRR on socket %d %d\n\r"),
                                uPRR, uSocket, uFunction));
                            if (uPRR & FCR_PRR_CBVD1) {
                                if (!(uPRR & FCR_PRR_RBVD1)) {
                                    fEvents[uFunction] |= (EVENT_MASK_BATTERY_DEAD & State.fInterruptEvents);
//                                    fPRROn |= EVENT_MASK_BATTERY_DEAD;
                                }
                                uPRR &= ~FCR_PRR_CBVD1;
                            }
                            if (uPRR & FCR_PRR_CBVD2) {
                                if (!(uPRR & FCR_PRR_RBVD2)) {
                                    fEvents[uFunction] |= (EVENT_MASK_BATTERY_LOW & State.fInterruptEvents);
//                                    fPRROn |= EVENT_MASK_BATTERY_LOW;
                                }
                                uPRR &= ~FCR_PRR_CBVD2;
                            }
                            if (uPRR & FCR_PRR_CRDY) {
                                if (uPRR & FCR_PRR_RREADY) {
                                     fEvents[uFunction] |= (EVENT_MASK_CARD_READY & State.fInterruptEvents);
//                                     fPRROn |= EVENT_MASK_CARD_READY;
                                }
                                uPRR &= ~FCR_PRR_CRDY;
                            }
                            if (uPRR & FCR_PRR_CWP) {
                                if (uPRR & FCR_PRR_RWP) {
                                    fEvents[uFunction] |= (EVENT_MASK_WRITE_PROTECT & State.fInterruptEvents);
//                                    fPRROn |= EVENT_MASK_WRITE_PROTECT;
                                }
                                uPRR &= ~FCR_PRR_CWP;
                            }
                            // Clear the PRR
                            CardWriteAttrByte(pLsock->pRegWin,FCR_OFFSET_PRR, uPRR);
                        } else {
                            if (!(pLsock->fRegisters & CFG_REGISTER_PIN)) {
                                DEBUGMSG(ZONE_WARNING,
                                    (TEXT("PCMCIA:Card doesn't support PRR (0x%X)\n\r"),
                                    pLsock->fRegisters));
                            } else {
                                DEBUGMSG(ZONE_WARNING,
                                    (TEXT("PCMCIA:Card not in I/O mode (fl 0x%X)\n\r"),
                                    pLsock->fFlags));
                            }
                        }
                    }
                }
            }

            //
            // Determine what changed.  The below XOR computes the
            // bits that have changed.  Then that result is ANDed with
            // the bitmask of what the socket is capable of reporting.
            //
            fChanged = (State.fInterruptEvents|EVENT_MASK_CARD_DETECT) &
                        (v_fPrevEvents[uSocket] ^ State.fNotifyEvents);
            fCurr = State.fNotifyEvents;
            v_fChangedEvents[uSocket] = fChanged;
            EventCode = 0;
//            CallbackFlags = 0;

            DEBUGMSG(ZONE_STSCHG,
                     (TEXT("fChanged = %x for Socket %d and fCurr = %x, PowerState = %x, fFlags = %x\r\n"),
                      fChanged, uSocket, fCurr, v_Sockets[uSocket].PowerState,
                      v_Sockets[uSocket].fFlags));

            if ((fCurr & EVENT_MASK_CARD_DETECT) &&
                (v_Sockets[uSocket].fFlags & PHYS_SOCK_FLAG_RESUMING)) {
               DEBUGMSG(ZONE_STSCHG, (TEXT("Clearing the RESUMING flag on socket %d.\r\n"), uSocket));
               v_Sockets[uSocket].fFlags &= ~PHYS_SOCK_FLAG_RESUMING;
               PcmciaPowerOff(uSocket, TRUE, (CARD_CLIENT_HANDLE)CARDSERV_CLIENT_HANDLE);
            }

            //
            // If this interrupt was due to a power off/on cycle, then notify
            // all client drivers by sending them a CE_CARD_REMOVAL and then a
            // CE_CARD_INSERTION (if a card is still inserted).  CardGetStatus
            // will indicate that no card is present until after the last removal
            // notice has been processed by CallbackThread.  When the last
            // removal notice has been sent, CallbackThread will signal this
            // thread which will then send card insertion notices for any cards
            // that are inserted.
            //
            if (v_Sockets[uSocket].PowerState == POWER_OFF ||
                v_Sockets[uSocket].PowerState == POWER_KEPT ||
                v_Sockets[uSocket].PowerState == POWER_RESET) {
               // Restore the windows to pre-suspend state
               if (v_Sockets[uSocket].PowerState != POWER_RESET) {
                   if (RestoreWindowState(uSocket) != CERR_SUCCESS) {
                       for (pLsock = pPsock->pLsock; pLsock != NULL; pLsock = pLsock->Next)
                           pLsock->fFlags &= ~LOG_SOCK_FLAG_NO_SUSPEND_UNLOAD;
                   } else if (State.fNotifyEvents & EVENT_MASK_CARD_DETECT) {
                       for (pLsock = pPsock->pLsock; pLsock != NULL; pLsock = pLsock->Next) {
                           if (!(pLsock->fFlags & OWNER_FLAG_CONFIG) ||
                               !(pLsock->FCSR_val & FCR_FCSR_PWR_DOWN))
                               break;
                       }
                       if (pLsock != NULL || pPsock->pLsock == NULL)
                           PcmciaPowerOn(uSocket);
                   }
               }

               if ((v_Sockets[uSocket].fFlags & PHYS_SOCK_FLAG_RESUMING) &&
                   (!(v_Sockets[uSocket].fFlags & PHYS_SOCK_FLAG_RESETTING) ||
                    v_Sockets[uSocket].PowerState == POWER_RESET)) {
                  DEBUGMSG(ZONE_STSCHG, (TEXT("PCMCIA:StatusChangeInt - back from standby incomplete\r\n")));
                  fChanged = 0;
               } else {
                   DEBUGMSG(ZONE_STSCHG,
                            (TEXT("PCMCIA:StatusChangeInt - back from standby and fFlags = %x for Socket %d\r\n"), v_Sockets[uSocket].fFlags, uSocket));

                // If there's still a card in the socket, mark the fact that we're expecting
                // some more work before the card is ready to be configured.
                if (fCurr & EVENT_MASK_CARD_DETECT) {
                   DEBUGMSG(ZONE_STSCHG, (TEXT("Marking socket %d as RESUMING.\r\n"), uSocket));
                   v_Sockets[uSocket].fFlags |= PHYS_SOCK_FLAG_RESUMING;
                }

                //
                // If a card was inserted before suspend, then remember whether
                // the user wants to use it on battery power.
                //
                DEBUGMSG(ZONE_STSCHG, (TEXT("v_fPrevEvents for Socket %d = %x \r\n"),uSocket,v_fPrevEvents[uSocket]));
                if (v_fPrevEvents[uSocket] & EVENT_MASK_CARD_DETECT) {
                    v_Sockets[uSocket].fFlags |= PHYS_SOCK_FLAG_FROM_STANDBY;
                    if ((fCurr & EVENT_MASK_CARD_DETECT) && v_PowerManagerEvent != NULL)
                        SetEvent(v_PowerManagerEvent);
                }

                v_fPrevEvents[uSocket] = 0;
                fChanged = EVENT_MASK_CARD_DETECT;
                fCurr = 0;
                v_fChangedEvents[uSocket] = 0;
                for (uFunction = 0; uFunction < MAX_FUNCTIONS; uFunction++)
                    fEvents[uFunction] = 0;
                bChanged = FALSE;

                //
                // Remove any existing CE_PM_RESUME callbacks so the file system
                // doesn't get confused in the case where a
                // removal/insert/resume sequence got interrupted by a power off
                //
                RemoveCallbacks(
                    NULL,
                    hSock,
                    CE_PM_RESUME,
                    REMOVE_PM_RESUME);

                CallbackAll(
                    CE_PM_SUSPEND,
                    CE_PM_SUSPEND,
                    NULL,
                    hSock,
                    0);
               }
            } else {
                v_fPrevEvents[uSocket] = fCurr;
                DEBUGMSG(ZONE_STSCHG, (TEXT("NOT back from Standby and v_fPrevEvents for Socket %d is set to %x \r\n"),uSocket,v_fPrevEvents[uSocket]));
            }

    #ifdef DEBUG
    if (fChanged && ZONE_STSCHG) {
        OutBuf[0] = 0;
        if (fChanged & EVENT_MASK_WRITE_PROTECT)
            _tcscat(OutBuf, TEXT("WRITE_PROTECT "));
        if (fChanged & EVENT_MASK_CARD_LOCK)
            _tcscat(OutBuf, TEXT("CARD_LOCK "));
        if (fChanged & EVENT_MASK_EJECT_REQ)
            _tcscat(OutBuf, TEXT("EJECT_REQ "));
        if (fChanged & EVENT_MASK_INSERT_REQ)
            _tcscat(OutBuf, TEXT("INSERT_REQ "));
        if (fChanged & EVENT_MASK_BATTERY_DEAD)
            _tcscat(OutBuf, TEXT("BATTERY_DEAD "));
        if (fChanged & EVENT_MASK_BATTERY_LOW)
            _tcscat(OutBuf, TEXT("BATTERY_LOW "));
        if (fChanged & EVENT_MASK_CARD_READY)
            _tcscat(OutBuf, TEXT("CARD_READY "));
        if (fChanged & EVENT_MASK_CARD_DETECT)
            _tcscat(OutBuf, TEXT("CARD_DETECT "));
        if (fChanged & EVENT_MASK_POWER_MGMT)
            _tcscat(OutBuf, TEXT("POWER_MGMT "));
        if (fChanged & EVENT_MASK_RESET)
            _tcscat(OutBuf, TEXT("RESET "));
        if (fChanged & EVENT_MASK_CARD_LOCK)
            _tcscat(OutBuf, TEXT("CARD_LOCK "));

        DEBUGMSG(ZONE_STSCHG,
            (TEXT("PCMCIA:StatusChangeInt: Changes on socket %d: %s and fFlags = %x\r\n"),
            uSocket, OutBuf, v_Sockets[uSocket].fFlags));
    }
    #endif

    #ifdef SINGLE_SOCKET_ONLY_STUFF
            //
            // Check if the card generated the status change interrupt
            //
            if ((fChanged == 0) &&
                (ret == WAIT_OBJECT_0) &&
                (fCurr & EVENT_MASK_CARD_DETECT)) {
                DEBUGMSG(ZONE_STSCHG,
                    (TEXT("PCMCIA:StatusChangeInt: Indicating CE_STATUS_CHANGE_INTERRUPT\r\n")));
                CallbackAll(
                    CE_STATUS_CHANGE_INTERRUPT,
                    CE_STATUS_CHANGE_INTERRUPT,
                    NULL,
                    hSock,
                    CALLBACK_FLAG_LAST);
            }
    #endif

//            CallbackFlags = CALLBACK_FLAG_ALL_FUNCTIONS;
            fChangeBack = ~fChanged;
            while (fChanged) {  // Signal all events that happened
                //
                // Notify unlocks before removals
                //
                if (fChanged & EVENT_MASK_CARD_LOCK) {
                    if (!(fCurr & EVENT_MASK_CARD_LOCK)) {
                        fChanged &= ~EVENT_MASK_CARD_LOCK;
//                        CallbackFlags = CALLBACK_FLAG_ALL_FUNCTIONS;
                        EventCode = CE_CARD_UNLOCK;
                        goto status_callback;
                    }
                }

                if (fChanged & EVENT_MASK_CARD_DETECT) {                    
                    fChanged &= ~EVENT_MASK_CARD_DETECT;
//                    CallbackFlags = CALLBACK_FLAG_ALL_FUNCTIONS;

                    if (fCurr & EVENT_MASK_CARD_DETECT) {
                        CeLogMsg(L"PCMCIA Load: %d", hSock.uSocket);
                        if (v_PowerManagerEvent != NULL)
                            SetEvent(v_PowerManagerEvent);
                        EventCode = CE_CARD_INSERTION;
                        EnterCriticalSection(&v_BatteryCrit);
                        if (v_hBatteryThread[hSock.uSocket] != 0) {
                            if (v_hGwesEvent == NULL ||
                                WaitForSingleObject(v_hGwesEvent, INFINITE) != WAIT_OBJECT_0 ||
                                (NULL == v_pfnPostThreadMessageW) || !v_pfnPostThreadMessageW(
                                v_hBatteryThread[hSock.uSocket],
                                WM_QUIT, 0, 0)) {
                                DEBUGMSG(ZONE_WARNING|ZONE_CALLBACK|ZONE_INIT,
                                        (TEXT("PCMCIA:EnqueueEvent:PostThreadMessage Failed (%d)\r\n"),
                                        GetLastError()));
                            }
                            v_hBatteryThread[hSock.uSocket] = 0;
                        }
                        v_fBattery[hSock.uSocket] = FALSE;
                        LeaveCriticalSection(&v_BatteryCrit);
                        CallbackOne(CE_CARDSERV_LOAD, 0, NULL, hSock);
                    } else {
                        CeLogMsg(L"PCMCIA Unload: %d", hSock.uSocket);
                        EnterCriticalSection(&v_DetectCrit);
                        if (v_Sockets[hSock.uSocket].DetectState != DETECT_NONE)
                            v_Sockets[hSock.uSocket].DetectState = DETECT_QUIT;
                        LeaveCriticalSection(&v_DetectCrit);
                        if (v_PowerManagerEvent != NULL &&
                            v_Sockets[uSocket].PowerState != POWER_KEPT &&
                            v_Sockets[uSocket].PowerState != POWER_OFF)
                            SetEvent(v_PowerManagerEvent);
                        CallbackAll(
                            CE_CARD_REMOVAL,
                            CE_CARD_REMOVAL,
                            NULL,
                            hSock,
                            CALLBACK_FLAG_ALL_FUNCTIONS);
                        CallbackOne(CE_CARDSERV_UNLOAD, 0, NULL, hSock);
                    }
                    continue;
                }

                //
                // Notify locks after insertions
                //
                if (fChanged & EVENT_MASK_CARD_LOCK) {
                    fChanged &= ~EVENT_MASK_CARD_LOCK;
                    if (fCurr & EVENT_MASK_CARD_LOCK) {
                        EventCode = CE_CARD_LOCK;
//                        CallbackFlags = CALLBACK_FLAG_ALL_FUNCTIONS;
                        goto status_callback;
                    }
                }

                //
                // The following are only valid when the card is inserted
                //
                if ((fCurr & EVENT_MASK_CARD_DETECT)) {
                    if (fChanged & EVENT_MASK_CARD_READY) {
                        fChanged &= ~EVENT_MASK_CARD_READY;
                        if (fCurr & EVENT_MASK_CARD_READY) {
                            EventCode = CE_CARD_READY;
                            goto status_callback;
                        }
                    }

                    if (fChanged & EVENT_MASK_BATTERY_LOW) {
                        fChanged &= ~EVENT_MASK_BATTERY_LOW;
                        if (fCurr & EVENT_MASK_BATTERY_LOW) {
                            EventCode = CE_BATTERY_LOW;
                            goto status_callback;
                        }
                    }

                    if (fChanged & EVENT_MASK_BATTERY_DEAD) {
                        fChanged &= ~EVENT_MASK_BATTERY_DEAD;
                        if (fCurr & EVENT_MASK_BATTERY_DEAD) {
                            EventCode = CE_BATTERY_DEAD;
                            goto status_callback;
                        }
                    }

                    if (fChanged & EVENT_MASK_WRITE_PROTECT) {
                        fChanged &= ~EVENT_MASK_WRITE_PROTECT;
                        if (fCurr & EVENT_MASK_WRITE_PROTECT) {
                            EventCode = CE_WRITE_PROTECT;
                            goto status_callback;
                        }
                    }
                } else {
                    //
                    // The card has been removed, so no other status need be reported.
                    //
                    fChanged = 0;
                }

                break;

    status_callback:
                if (EventCode) {
                    CallbackAll(
                        EventCode,
                        EventCode,
                        NULL,
                        hSock,
                        CALLBACK_FLAG_ALL_FUNCTIONS);
                }

            }   // while (fChanged)

            if ((fCurr & EVENT_MASK_CARD_DETECT) && bChanged) {
                for (uFunction = 0; uFunction < MAX_FUNCTIONS; uFunction++) {
                    hSock.uFunction = uFunction;
                    if (fEvents[uFunction] & EVENT_MASK_CARD_READY & fChangeBack)
                        CallbackAll(CE_CARD_READY, CE_CARD_READY, NULL, hSock, 0);
                    if (fEvents[uFunction] & EVENT_MASK_BATTERY_LOW & fChangeBack)
                        CallbackAll(CE_CARD_READY, CE_BATTERY_LOW, NULL, hSock, 0);
                    if (fEvents[uFunction] & EVENT_MASK_BATTERY_DEAD & fChangeBack)
                        CallbackAll(CE_CARD_READY, CE_BATTERY_DEAD, NULL, hSock, 0);
                    if (fEvents[uFunction] & EVENT_MASK_WRITE_PROTECT & fChangeBack)
                        CallbackAll(CE_CARD_READY, CE_WRITE_PROTECT, NULL, hSock, 0);
                }
            }

        }    // for all sockets

        if (ret == WAIT_OBJECT_0 && !v_bSharedIntr) {
            DEBUGMSG(ZONE_STSCHG, (TEXT("PCMCIA:StatusChangeInt - Calling InterruptDone\r\n")));
            InterruptDone(gIntrPcmciaState);
        }
    }

    return 0;
}   // StatusChangeThread


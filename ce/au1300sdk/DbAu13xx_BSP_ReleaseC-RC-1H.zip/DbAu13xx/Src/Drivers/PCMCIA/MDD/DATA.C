//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:  

    data.c

Abstract:  

    This file implements the PCMCIA model device driver data
    This is provided as a sample to platform writers and is
    expected to be able to be used without modification on most (if not
    all) hardware platforms.

Functions:


Notes:


--*/

#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <linklist.h>
#include <pcmcia.h>

PPDCARD_ADAPTER_INFO v_pAdapterInfo;

CRITICAL_SECTION v_PowerCrit;   // Critical section used by PcmciaPowerOn/Off

PHYS_SOCKET v_Sockets[MAX_SOCKETS];
int v_cSockets; // number of PCMCIA sockets in this system.
CRITICAL_SECTION v_SocketCrit;

PPHYS_WINDOW v_pWinList; // List of available memory and I/O windows
int v_cWindows;          // number of PCMCIA windows in this system.
CRITICAL_SECTION v_WindowCrit;

CRITICAL_SECTION v_ClientCrit;  // Critical section for manipulating list
LIST_ENTRY v_ClientList;        // List of registered client drivers.

HANDLE v_PowerManagerEvent;     // Used to signal to the Power Manager that a CSC event has occured
HANDLE v_StatusChangeEvent;     // Used to signal status change interrupt thread
HANDLE v_IREQEvent;             // Used to signal IREQ interrupt thread
UINT v_PageSize;                // System page size


HANDLE v_CallbackEvent;         // Signal CallbackThread
CRITICAL_SECTION v_CallbackCrit;// Control access to v_CallbackHead and v_CallbackTail
PCALLBACK_STRUCT v_CallbackHead;
PCALLBACK_STRUCT v_CallbackTail;

//
// Table to map callback event codes to the appropriate event mask bit
// Any event code not included here is assumed to go to all clients.
// (Try to order this table by frequency of use)
//
const EVENT_ATTR v_EventMap[] = {
{ CE_CARD_READY,        EVENT_MASK_CARD_READY },
{ CE_WRITE_PROTECT,     EVENT_MASK_WRITE_PROTECT },
{ CE_EXCLUSIVE_REQUEST, EVENT_MASK_EXCLUSIVE },
{ CE_RESET_REQUEST,     EVENT_MASK_RESET },
{ CE_RESET_PHYSICAL,    EVENT_MASK_RESET },
{ CE_CARD_LOCK,         EVENT_MASK_CARD_LOCK },
{ CE_CARD_UNLOCK,       EVENT_MASK_CARD_LOCK },
{ CE_EJECTION_REQUEST,  EVENT_MASK_EJECT_REQ },
{ CE_INSERTION_REQUEST, EVENT_MASK_INSERT_REQ },
{ CE_BATTERY_DEAD,      EVENT_MASK_BATTERY_DEAD },
{ CE_BATTERY_LOW,       EVENT_MASK_BATTERY_LOW },
{ CE_CARD_INSERTION,    EVENT_MASK_CARD_DETECT },
{ CE_CARD_REMOVAL,      EVENT_MASK_CARD_DETECT },
{ CE_PM_RESUME,         EVENT_MASK_POWER_MGMT },
{ CE_PM_SUSPEND,        EVENT_MASK_POWER_MGMT },
{ CE_STATUS_CHANGE_INTERRUPT, EVENT_MASK_STATUS_CHANGE },
{ (UINT16) -1,          (UINT16) -1 },
};

#ifdef DO_MEMTRACKING
DWORD v_TrackCallbacks;
DWORD v_TrackPNPId;
DWORD v_TrackPNPIdBytes;
DWORD v_TrackSocketInfo;
DWORD v_TrackPhysicalWindowInfo;
DWORD v_TrackClientDrivers;
DWORD v_TrackClientSockets;
DWORD v_TrackLogicalSockets;
DWORD v_TrackLogicalMemoryWindows;
DWORD v_TrackVirtualMemory;
DWORD v_TrackVirtualMemoryBytes;
#endif

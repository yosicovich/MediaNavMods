//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:  

    mask.c

Abstract:  

    This file implements the PCMCIA model device driver client event mask 
    functions and the CardGetStatus function.  This is provided as a sample
    to platform writers and is expected to be able to be used without
    modification on most (if not all) hardware platforms.

Functions:

    CardRequestSocketMask()
    CardReleaseSocketMask()
    CardGetEventMask()
    CardSetEventMask()
    CardGetStatus()

Notes:


--*/


#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <pcmcia.h>
#include <extern.h>

extern UINT16 v_fChangedEvents[MAX_SOCKETS];
extern PCLIENT_SOCKET I_GetClientSocket(PLOG_SOCKET pLsock, PCLIENT_DRIVER pClient);

//
// CardRequestSocketMask
//
// @doc DRIVERS
//
// @func    STATUS | CardRequestSocketMask | Set a client driver's event mask 
//                                           for a particular socket and function pair.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE, CERR_BAD_SOCKET or CERR_OUT_OF_RESOURCE.
//
// @comm    Sets the client driver's event mask for the specified socket/function.
//          Only those callbacks indicated by the event mask will be sent to the
//          client.  The socket event mask is associated with a particular socket
//          and function.  The client's global event mask is for all sockets.
// @xref    <f CardReleaseSocketMask>
//
STATUS
CardRequestSocketMask(
    CARD_CLIENT_HANDLE hCardClient, // @parm Handle from <f CardRegisterClient>
    CARD_SOCKET_HANDLE hSock,       // @parm Socket/Function identifier
    UINT16 fEventMask               // @parm Socket event mask
    )
{
    PCLIENT_SOCKET pCsock;
    PLOG_SOCKET pSock;
    STATUS status = CERR_SUCCESS;
    PCLIENT_DRIVER pClient;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardRequestSocketMask entered\r\n")));

    if ((pClient = FindClient(hCardClient, TRUE, FALSE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto req_mask_exit;
    }

    if ((pSock = I_FindSocket(hSock)) == NULL) {
        status = CERR_BAD_SOCKET;
        goto req_mask_exit;
    }

    //
    // Find or create the associated CLIENT_SOCKET
    //
    pCsock = I_GetClientSocket(pSock, pClient);
    if (pCsock == NULL) {
        status = CERR_OUT_OF_RESOURCE;
        goto req_mask_exit;
    }

    pCsock->fEventMask = fEventMask;

req_mask_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("CardRequestSocketMask failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("CardRequestSocketMask succeeded\r\n")));
    }
#endif
    return status;
}   // CardRequestSocketMask


//
// CardReleaseSocketMask
//
// @func    STATUS | CardReleaseSocketMask | Disables the association made by
//                  CardRequestSocketMask for a particular socket and function pair.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_HANDLE or CERR_BAD_SOCKET.
//
// @comm    The client driver's global event mask will be associated with the
//          specified socket and function.  If there was no previous association
//          made by CardRequestSocketMask, then CardReleaseSocketMask will return
//          CERR_BAD_SOCKET.
// @xref    <f CardRequestSocketMask>
//
STATUS
CardReleaseSocketMask(
    CARD_CLIENT_HANDLE hCardClient, // @parm Handle from <f CardRegisterClient>
    CARD_SOCKET_HANDLE hSock        // @parm Socket/Function identifier
    )
{
    PCLIENT_SOCKET pCsock;
    PCLIENT_DRIVER pClient;
    STATUS status = CERR_SUCCESS;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardReleaseSocketMask entered\r\n")));

    if ((pClient = FindClient(hCardClient, TRUE, FALSE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto rel_mask_exit;
    }

    pCsock = I_FindClientSocket(hSock, pClient);
    if (pCsock == NULL) {
        status = CERR_BAD_SOCKET;
        goto rel_mask_exit;
    }

    //
    // If this client doesn't have exclusive access to this socket, then
    // we can free the associated CLIENT_SOCKET
    //
    if (pCsock->pLsock->hOwner != pClient) {
        I_RemoveClientSocket(pCsock, pClient);
    } else {
        pCsock->fEventMask = ((PCLIENT_DRIVER)(hCardClient))->Parms.fEventMask;
    }
        
rel_mask_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("CardReleaseSocketMask failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("CardReleaseSocketMask succeeded\r\n")));
    }
#endif
    return status;
}   // CardReleaseSocketMask


//
// CardGetEventMask
//
// @func    STATUS | CardGetEventMask | Return either the client's global event mask
//                                      or the event mask for a particular socket and function
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_ARGS, CERR_BAD_HANDLE or CERR_BAD_SOCKET.
//
// @comm    Returns either the client driver's global event mask which was set
//          initially by <f CardRegisterClient> or the event mask for the specified
//          socket and function obtained from <f CardRequestSocketMask>.  If the global
//          event mask is requested, then the socket identifier in the CARD_EVENT_MASK_PARMS
//          structure is ignored.
// @xref    <t CARD_EVENT_MASK_PARMS> <f CardSetEventMask> <f CardRequestSocketMask>
//
STATUS
CardGetEventMask(
    CARD_CLIENT_HANDLE hCardClient,     // @parm Handle from <f CardRegisterClient>
    PCARD_EVENT_MASK_PARMS pMaskParms   // @parm Pointer to a <t CARD_EVENT_MASK_PARMS> structure
    )
{
    PCLIENT_SOCKET pCsock;
    PCLIENT_DRIVER pClient;
    STATUS status = CERR_SUCCESS;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardGetEventMask entered\r\n")));

    if (pMaskParms == NULL) {
        status = CERR_BAD_ARGS;
        goto get_mask_exit;
    }

    if ((pClient = FindClient(hCardClient, TRUE, FALSE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto get_mask_exit;
    }

    if (pMaskParms->fAttributes & EVENT_ATTR_SOCKET_ONLY) {
        //
        // Request for socket specific event mask.
        // 
        pCsock = I_FindClientSocket(pMaskParms->hSocket, pClient);
        if (pCsock == NULL) {
            status = CERR_BAD_SOCKET;
            goto get_mask_exit;
        }

        pMaskParms->fEventMask = pCsock->fEventMask;
        goto get_mask_exit;
    }

    //
    // Return client's global event mask.
    //
    pMaskParms->fEventMask = pClient->Parms.fEventMask;

get_mask_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("CardGetEventMask failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("CardGetEventMask succeeded\r\n")));
    }
#endif
    return status;
}   // CardGetEventMask


//
// CardSetEventMask
//
// @func    STATUS | CardSetEventMask | Set either the client's global event mask
//                                      or the event mask for a particular socket and function
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_ARGS, CERR_BAD_HANDLE or CERR_BAD_SOCKET.
//
// @comm    Sets either the client driver's global event mask which was set
//          initially by <f CardRegisterClient> or the event mask for the specified
//          socket and function obtained from <f CardRequestSocketMask>.  If the global
//          event mask is requested, then the socket identifier in the CARD_EVENT_MASK_PARMS
//          structure is ignored.
// @xref    <t CARD_EVENT_MASK_PARMS> <f CardGetEventMask> <f CardRequestSocketMask>
//
STATUS
CardSetEventMask(
    CARD_CLIENT_HANDLE hCardClient,     // @parm Handle from <f CardRegisterClient>
    PCARD_EVENT_MASK_PARMS pMaskParms   // @parm Pointer to a <t CARD_EVENT_MASK_PARMS> structure
    )
{
    PCLIENT_SOCKET pCsock;
    PCLIENT_DRIVER pClient;
    STATUS status = CERR_SUCCESS;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardSetEventMask entered\r\n")));

    if (pMaskParms == NULL) {
        status = CERR_BAD_ARGS;
        goto set_mask_exit;
    }

    if ((pClient = FindClient(hCardClient, TRUE, FALSE)) == NULL) {
        status = CERR_BAD_HANDLE;
        goto set_mask_exit;
    }

    if (pMaskParms->fAttributes & EVENT_ATTR_SOCKET_ONLY) {
        //
        // Set the socket specific event mask.
        // 
        pCsock = I_FindClientSocket(pMaskParms->hSocket, pClient);
        if (pCsock == NULL) {
            status = CERR_BAD_SOCKET;
            goto set_mask_exit;
        }

        pCsock->fEventMask = pMaskParms->fEventMask;
        goto set_mask_exit;
    }

    //
    // Set client's global event mask.
    //
    pClient->Parms.fEventMask = pMaskParms->fEventMask;

set_mask_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("CardSetEventMask failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("CardSetEventMask succeeded\r\n")));
    }
#endif
    return status;
}   // CardSetEventMask


//
// CardGetStatus
//
// @func    STATUS | CardGetStatus | Reports the change in state of the specified socket and 
//                                   the current state of the specified card in that socket.
// @rdesc   Returns one of CERR_SUCCESS, CERR_BAD_SOCKET or CERR_BAD_ARGS.
//
STATUS
CardGetStatus(
    PCARD_STATUS pStatus    // @parm pointer to the <t CARD_STATUS> structure to report status.
    )
{
    PDCARD_SOCKET_STATE State;
    STATUS status = CERR_SUCCESS;
    PLOG_SOCKET pLsock;

    DEBUGMSG(ZONE_FUNCTION, (TEXT("CardGetStatus entered\r\n")));


    if (pStatus == NULL) {
        status = CERR_BAD_ARGS;
        goto get_status_exit;
    }

    status = PDCardGetSocket(pStatus->hSocket.uSocket, &State);
    if (status == CERR_SUCCESS) {
        pLsock = I_FindSocket(pStatus->hSocket);
        pStatus->fCardState = State.fNotifyEvents;
        pStatus->fSocketState = v_fChangedEvents[pStatus->hSocket.uSocket];
        if (pLsock != NULL)
            pStatus->fSocketState |= pLsock->fChangedEvents;
    }

    //
    // During the power cycle, do not indicate an inserted card until all
    // client drivers have been sent a CE_CARD_REMOVAL.  This will cause the
    // the drivers to not treat it as an artificial removal notice.
    //
    if (v_Sockets[pStatus->hSocket.uSocket].PowerState == POWER_OFF ||
        v_Sockets[pStatus->hSocket.uSocket].PowerState == POWER_KEPT ||
        v_Sockets[pStatus->hSocket.uSocket].PowerState == POWER_RESET) {
        pStatus->fCardState &= ~EVENT_MASK_CARD_DETECT;
    }

get_status_exit:
#ifdef DEBUG
    if (status) {
        DEBUGMSG(ZONE_FUNCTION|ZONE_ERROR,
            (TEXT("CardGetStatus failed %d\r\n"), status));
    } else {
        DEBUGMSG(ZONE_FUNCTION,
            (TEXT("CardGetStatus succeeded\r\n")));
    }
#endif
    return status;
}   // CardGetStatus

/**********************************************************************
* Copyright 2007 RMI Corp. All Rights Reserved.
*
* Unless otherwise designated in writing, this software and any related
* documentation are the confidential proprietary information of RMI
* Corp.
*
* THESE MATERIALS ARE PROVIDED "AS IS" WITHOUT ANY
* UNLESS OTHERWISE NOTED IN WRITING, EXPRESS OR IMPLIED WARRANTY OF ANY
* KIND, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* NONINFRINGEMENT, TITLE, FITNESS FOR ANY PARTICULAR PURPOSE AND IN NO
* EVENT SHALL RMI COPR. OR ITS LICENSORS BE LIABLE FOR ANY DAMAGES
* WHATSOEVER.
*
* RMI Corp. does not assume any responsibility for any errors which may
* appear in the Materials nor any responsibility to support or update
* the Materials. RMI Corp. retains the right to modify the Materials
* at any time, without notice, and is not obligated to provide such
* modified Materials to you. RMI Corp. is not obligated to furnish,
* support, or make any further information available to you.
***********************************************************************/
//------------------------------------------------------------------------------
// File: mempool.c
//------------------------------------------------------------------------------

#include <windows.h>
#include <dbgapi.h>
#include "mempool.h"
#include "mem_ioctl.h"

// #define DEBUG 1

#if defined(DEBUG)
#undef DEBUGMSG
	#define DEBUGMSG(c,m) RETAILMSG(1,m)
#endif


#define MEMPOOL_REGKEY (TEXT("Drivers\\BuiltIn\\mempool"))
#define MEMPOOL_REGIONS_REGKEY (TEXT("Drivers\\BuiltIn\\mempool\\Regions"))

BOOL g_bRealTimeDebug = FALSE;

// Debug zone support
#define DTAG TEXT("MEMPOOL: ")
#define ZONE_ERROR      DEBUGZONE(0)
#define ZONE_INIT       DEBUGZONE(1)
#define ZONE_FUNC       DEBUGZONE(2)
#define ZONE_DRVCALLS   DEBUGZONE(3)
#define ZONE_INFO       DEBUGZONE(4)
#define ZONE_LIST       DEBUGZONE(5)
#define ZONE_EXENTRY    (ZONE_FUNC | ZONE_DRVCALLS)

DBGPARAM dpCurSettings =
{
  TEXT("mempool"),
  {
	TEXT("Errors"), TEXT("Init"), TEXT("Functions"),
	TEXT("DriverCalls"), TEXT("Info"), TEXT("List"),
	TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
	TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
	TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
	TEXT("Undefined")
  },
  0x0001
};

void CleanupMemory(PDRVCONTEXT pDrv);

VOID DumpList(PMEMDESC pList)
{
	PMEMDESC pCurrent = pList;
	DEBUGMSG(ZONE_LIST, (DTAG TEXT("Node List:\r\n")));

	while (pCurrent)
	{

		DEBUGMSG(ZONE_LIST, (DTAG TEXT("Node:%x size:%x inuse:%d next:%x prev:%x phys:%x virt: %x\r\n"),
									pCurrent, pCurrent->dwActualSize,
									pCurrent->inuse, pCurrent->next,
									pCurrent->prev, pCurrent->phys, pCurrent->virt));
		pCurrent=pCurrent->next;
	}
}

/*
 *   Function   :   alloc
 *
 *      Allocates memory from the specified region
 *
 *   Parameters :
 *      pList  		Pointer to the list of memory descriptors.
 *		dwSize       Size of memory to allocate
 *
 *     Returns :
 *      PMEMDESC	Pointer to the descriptor of the memory allocated
 *      NULL        Failure
 *
 */
PMEMDESC AllocateFromPool(PMEMDESC pList, DWORD dwSize )
{
	PMEMDESC pCurrent;
	PMEMDESC pNew;
	DWORD dwActualSize = dwSize;

	// Make sure memory is page aligned
	if (dwSize % MEMPOOL_PAGESIZE)
	{
		// We weren't aligned... round up to the nearest page.
		dwActualSize = (dwSize & (~MEMPOOL_PAGEMASK)) + MEMPOOL_PAGESIZE;
	}

	// find the first fit for the requested size
	for(pCurrent=pList; NULL!=pCurrent; pCurrent=pCurrent->next)
	{
		if( (!pCurrent->inuse) && (pCurrent->dwActualSize >= dwActualSize) )
			break;
	}

	if (NULL == pCurrent)
  {
    DEBUGMSG(ZONE_ERROR, (DTAG TEXT("Error: Out of memory\r\n")));
		return NULL;
  }
	/* 	If we get to this point -- pcurrent is a valid descriptor
	 *  First thing we need to do is create a new descriptor for the left over data
     *	and fill in the proper values. Only do this if we have left overs
     */
	if (pCurrent->dwActualSize != dwActualSize)
	{
		if (!(pNew = (PMEMDESC)LocalAlloc(LMEM_ZEROINIT, sizeof(MEMDESC))))
      return NULL;

		pNew->dwActualSize 	= pCurrent->dwActualSize - dwActualSize;
		pNew->inuse 	= FALSE;
		pNew->phys 		= (VOID*)((UINT32)pCurrent->phys + dwActualSize);
		pNew->kvirt 	= (VOID*)((UINT32)pCurrent->kvirt + dwActualSize);
		pNew->prev 		= pCurrent;
		pNew->next 		= pCurrent->next;

		pCurrent->next 	= pNew;
		pCurrent->dwActualSize = dwActualSize;
		pCurrent->dwSize = dwSize;
	}

	// element now in use
	pCurrent->inuse = TRUE;

	/* return a pointer to the actual data area */
	return pCurrent;
}

/*
 *   Function   :   FreeFromPool
 *
 *      Frees memory node from its region
 *
 *   Parameters :
 *      pNode   	Pointer to the memory descriptor
 *
 *     Returns :
 *      TRUE		SUCCESS
 *      FALSE       FAILURE
 *
 */
BOOL FreeFromPool(PMEMDESC pNode)
{
	PMEMDESC	pPrev, pNext, pNextNext;
	BOOL 		bRet = TRUE;
	BOOL 		bChanged = FALSE;

	// Check if Next node is free
	pPrev = pNode->prev;
	pNext = pNode->next;
	if ( pNext && (!pNext->inuse) )
	{
		pNode->dwActualSize 	+= pNext->dwActualSize;
		pNode->inuse 	= 0;
		pNode->next 	= pNext->next;
		pNextNext 		= pNext->next;
		if (pNextNext)
		  pNextNext->prev = pNode;

		LocalFree(pNext);

		bChanged = TRUE;
	}

	// Check if Previous node is free
	if ( pPrev && (!pPrev->inuse) )
	{
		// move pointers back one
		pNext = pNode;
		pNode = pNode->prev;
		// then redo the next node free logic
		pNode->dwActualSize += pNext->dwActualSize;
		pNode->inuse = 0;
		pNode->next = pNext->next;
		pNextNext = pNext->next;
		if (pNextNext)
		  pNextNext->prev = pNode;
		LocalFree(pNext);
		bChanged = TRUE;
	}

	// neither is free, turn the node into a free fragment
	if (!bChanged)
		pNode->inuse = 0;

	return bRet;
}


/*
 *   Function   :   FreeNode
 *
 *      Frees memory previouly allocated with AllocateNode
 *
 *   Parameters :
 *      pNode       pointer to the memory descriptor node to be freed
 *
 *     Returns :
 *      TRUE		Success
 *      FALSE		Failure
 *
 */
BOOL FreeNode(PMEMDESC pNode)
{
  BOOL bRet = FALSE;
  ULONG ulErrorCode;

	if (pNode->virt)
	{
    // unmap the memory first
    if (!(VirtualFreeEx((HANDLE)pNode->dwProcId, pNode->virt, 0, MEM_RELEASE)))
    {
      ulErrorCode = GetLastError();
      DEBUGMSG(ZONE_ERROR, (DTAG TEXT("FreeNode failed VirtualFreeEx:\r\n")));
      DEBUGMSG(ZONE_ERROR, (DTAG TEXT("id 0x%08x, phys 0x%08x, kvirt 0x%08x, virt 0x%08x, inuse %d\r\n"),
        pNode->dwProcId, pNode->phys, pNode->kvirt, pNode->virt, pNode->inuse));
      DEBUGMSG(ZONE_ERROR, (DTAG TEXT("cause %d (0x%08x)\r\n"), ulErrorCode, ulErrorCode));
//      return FALSE;
    }
    else
    {
      DEBUGMSG(ZONE_LIST, (DTAG TEXT("FreeNode OK:\r\n")));
      DEBUGMSG(ZONE_LIST, (DTAG TEXT("id 0x%08x, phys 0x%08x, kvirt 0x%08x, virt 0x%08x, inuse %d\r\n"),
        pNode->dwProcId, pNode->phys, pNode->kvirt, pNode->virt, pNode->inuse));
    }
    pNode->virt = NULL;
  }

	bRet = FreeFromPool(pNode);
  if (!bRet)
    DEBUGMSG(ZONE_ERROR, (DTAG TEXT("FreeNode failed FreeFromPool phys 0x%08x\r\n"),
      pNode->phys));

	return bRet;
}

/*
 *   Function   :   AllocateNode
 *
 *      Allocates a section of memory from the specified region.
 *
 *   Parameters :
 *      pRegion   	Pointer to the region descriptor from which hNode will be taken
 *      dwSize		Size of memory to take
 *      ppVirt      Pointer to Virtual memory pointer
 *      ppPhys      Pointer to Physical memory pointer
 *
 *     Returns :
 *      PMEMDESC	descriptor to newly allocated memory
 *      NULL        Failure
 *
 */
PMEMDESC AllocateNode(MEMPOOL_REGION *pRegion, DWORD dwSize, void ** ppVirt, void ** ppPhys, DWORD dwFlags )
{
	PMEMDESC pNode;
	DWORD dwProcId = GetCallerVMProcessId();

	// first get a free section of physical/kernel memory
	if (!(pNode = (PMEMDESC)AllocateFromPool(pRegion->pList, dwSize)))
	{
			DEBUGMSG(ZONE_ERROR, (DTAG TEXT("AllocateNode AllocateFromPool failed\r\n")));
			return NULL;
	}

	// map the kernel memory into caller's process
	// Unless the MEM_FLAG_NO_MAPVIRTUAL is set
	if ( !(dwFlags & MEM_FLAG_NO_MAPVIRTUAL) )
	{
		DWORD dwProtect = PAGE_READWRITE;

		if ( (dwFlags & MEM_FLAG_NO_CACHE) )
		{
			dwProtect |= PAGE_NOCACHE;
		}
		// map the kernel memory into caller's process
		if (!(pNode->virt = VirtualAllocCopyEx( GetCurrentProcess(),
		(HANDLE)dwProcId, (LPVOID)pNode->kvirt, dwSize, dwProtect)))
		{
			// since we cannot map the memory, free the node
			if (!FreeFromPool(pNode))
			{
				return NULL;
			}
		}
	}
	else
	{
	pNode->virt = 0;
	}
	*ppVirt = pNode->virt;
	*ppPhys = pNode->phys;
	pNode->dwProcId = dwProcId;

	DEBUGMSG(ZONE_INFO,(DTAG TEXT("Allocated size 0x%x at phys 0x%08x, virt 0x%08x (handle 0x%08x)\r\n"),
						pNode->dwSize, pNode->phys, pNode->virt, pNode));

	return pNode;
}

BOOL CreatePool(MEMPOOL_REGION *pRegion)
{

	/* Our first memory descriptor */
	pRegion->pList = (PMEMDESC)LocalAlloc(LMEM_ZEROINIT, sizeof(MEMDESC));

	/* The first data entry will never change */
	pRegion->pList->phys 	= pRegion->lpvPhysAddr;
	pRegion->pList->kvirt 	= pRegion->lpvKernelAddr;
	pRegion->pList->dwActualSize 	= pRegion->dwSize;
	pRegion->pList->inuse 	= FALSE;
	pRegion->pList->prev 	= NULL;
	pRegion->pList->next 	= NULL;

	return TRUE;
}


BOOL FreePool(MEMPOOL_REGION *pRegion)
{
	PMEMDESC 	pCur;
	BOOL		bRet=TRUE;

	for(pCur = pRegion->pList; pCur; pCur=pCur->next)
	{
		if(!FreeNode(pCur))
			bRet = FALSE;
	}

	return bRet;
}

BOOL MEM_IOControl(
                   DWORD dwContext,
                   DWORD dwIoControlCode,
                   PBYTE pInBuf,
                   DWORD dwInBufSize,
                   PBYTE pOutBuf,
                   DWORD dwOutBufSize,
                   PDWORD pdwBytesReturned
                   )
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	switch(dwIoControlCode)
	{
		case MEM_REQUEST_BLOCK:
			{
				PMEM_IOCTL 	pOut,pIn	=  (PMEM_IOCTL)pInBuf;

				/* Check our paramaeters. NULL output buf is okay, we'll just place
  				 * the output data back into input buffer, since they are the same.
				 */
				if (dwInBufSize != sizeof(MEM_IOCTL))
				{
					SetLastError(ERROR_INVALID_PARAMETER);
					return FALSE;
				}

				if ((NULL == pOutBuf) || (dwOutBufSize != sizeof(MEM_IOCTL)))
					pOut = pIn;
				else
					pOut = (PMEM_IOCTL)pOutBuf;

			    if (!pDrv->regions[pIn->dwRegion].lpvKernelAddr)
					RETAILMSG(1,(DTAG TEXT("Invalid Region Index(%d)!\r\n"),pIn->dwRegion));
				else
				{
				EnterCriticalSection(&(pDrv->CriticalSection));
					pOut->hMem = AllocateNode(&pDrv->regions[pIn->dwRegion], pIn->dwSize, &pOut->pVirtual, &pOut->pPhysical, pIn->dwFlags);
				LeaveCriticalSection(&(pDrv->CriticalSection));
				}

				if(pdwBytesReturned)
					*pdwBytesReturned = sizeof(MEM_IOCTL);

			}
			break;

		case MEM_FREE_BLOCK:
			{
				PMEM_IOCTL 	pIn	=  (PMEM_IOCTL)pInBuf;
				BOOL bRet = TRUE;

				if (dwInBufSize != sizeof(MEM_IOCTL))
				{
					SetLastError(ERROR_INVALID_PARAMETER);
					return FALSE;
				}

				EnterCriticalSection(&(pDrv->CriticalSection));
				FreeNode(pIn->hMem);
				LeaveCriticalSection(&(pDrv->CriticalSection));

				if(pdwBytesReturned)
					*pdwBytesReturned = sizeof(MEM_IOCTL);
			}
			break;

		case MEM_GET_REGION_SIZE:
			{
				PMEM_IOCTL 	pIn	=  (PMEM_IOCTL)pInBuf;
				DWORD *pOut = (DWORD *)pOutBuf;

				MEMPOOL_REGION *pRegion = &pDrv->regions[pIn->dwRegion];

				*pOut = pRegion->dwSize;
			}
			break;
		default:
			return FALSE;
	}

	return TRUE;
}

//======================================================================
// MEM_Init - Driver initialization function
//
DWORD MEM_Init(DWORD dwContext)
{
	PDRVCONTEXT pDrv;
	DWORD		i;

	// Allocate a device instance structure from the heap
	pDrv = (PDRVCONTEXT)LocalAlloc(LPTR, sizeof(DRVCONTEXT));
	if (pDrv)
	{
		memset((PBYTE)pDrv, 0, sizeof(DRVCONTEXT));
		pDrv->dwSize = sizeof(DRVCONTEXT);
		if (FALSE == GetConfigData(pDrv, dwContext) )
		{
			RETAILMSG(1,(DTAG TEXT("Failed to retrieve Region configuration from registry!\r\n")));
			return 0;
		}
	}
	else
	{
		return 0;
	}

	InitializeCriticalSection(&(pDrv->CriticalSection));

	for(i=0; i < MAX_REGIONS;i++)
	{
		// Only create pool for valid regions. NULL for physical mapping address
		// denotes invalid region
		if ( pDrv->regions[i].lpvKernelAddr )
		{
			if (!CreatePool(&pDrv->regions[i]))
			{
				RETAILMSG(1,(DTAG TEXT("Failed to create POOL for %s region!\r\n"), pDrv->regions[i].wcName));
				return 0;
			}
		}
	}

	return (DWORD)pDrv;
}

BOOL MEM_PreDeinit(DWORD dwContext)
{
  DEBUGMSG(ZONE_EXENTRY, (DTAG TEXT("+MEM_PreDeinit dwContext:0x%08x\r\n"), dwContext));
  return TRUE;
}

BOOL MEM_Deinit(DWORD dwContext)
{
	PDRVCONTEXT 	pDrv = (PDRVCONTEXT)dwContext;
	DWORD 	  	i;

	for(i=0; i < MAX_REGIONS;i++)
	{
		if (!FreePool(&pDrv->regions[i]))
			return FALSE;
	}
	DeleteCriticalSection(&(pDrv->CriticalSection));

	return TRUE;
}

DWORD MEM_Open(DWORD dwContext, DWORD dwAccess, DWORD dwShare)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	// Verify that the context handle is valid.
	if (pDrv && (pDrv->dwSize != sizeof (DRVCONTEXT))) {
		return 0;
	}

	// Count the number of opens.
	InterlockedIncrement ((long *)&pDrv->nNumOpens);

	return (DWORD)pDrv;
}

BOOL MEM_Close (DWORD dwOpen)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwOpen;

	if (pDrv && (pDrv->dwSize != sizeof (DRVCONTEXT))) {
		return FALSE;
	}

	if (pDrv->nNumOpens)
		InterlockedDecrement((long *)&pDrv->nNumOpens);

	return TRUE;
}


BOOL GetConfigData(PDRVCONTEXT pDrv, DWORD dwContext) {
	DWORD 		dwIndex=0;
	TCHAR 		szNewKey[MAX_PATH]; // name of "region" subkey
	DWORD 		dwNewKeySize;       // size of name of "region" subkey
	DWORD		dwType, dwLen; 		// type and length of key
	MEMPOOL_REGION *pRegion;
	HKEY		hKey, hActiveKey;

	// If ptr < 65K, it�s a value, not a pointer.
	if (dwContext < 0x10000)
	{
		DEBUGMSG (ZONE_ERROR, (DTAG TEXT("GetConfigData supplied no valid registry string\r\n")));
		return FALSE;
	} else
	{
		__try {
		  dwLen = lstrlen ((LPTSTR)dwContext);
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
		  dwLen = 0;
		}
	}
	if (!dwLen)
	{
		return FALSE;
	}

	RETAILMSG(1, (DTAG TEXT("Built on %s.%s\r\n"),TEXT(__DATE__),TEXT(__TIME__)));

	// Open the Active key for the driver.
	if (ERROR_SUCCESS != RegOpenKeyEx(HKEY_LOCAL_MACHINE, (LPTSTR)dwContext,0, 0, &hActiveKey) )
		return FALSE;

	// Read the key value.
	dwLen = sizeof(szNewKey) / sizeof(TCHAR);
	RegQueryValueEx (hActiveKey, TEXT("Key"), NULL, &dwType, (PBYTE)szNewKey, &dwLen);

	if ( ERROR_SUCCESS != RegOpenKeyEx(HKEY_LOCAL_MACHINE, MEMPOOL_REGIONS_REGKEY,0, 0, &hKey))
	{
		return FALSE;
	}

	dwNewKeySize = sizeof(szNewKey) / sizeof(TCHAR);
	while (
	    ERROR_SUCCESS == RegEnumKeyExW(
	        hKey,          //
	        dwIndex,       // index of the subkey to fetch
	        szNewKey,      // name of subkey (e.g., "Device0")
	        &dwNewKeySize, // size of name of subkey
	        NULL,          // lpReserved; set to NULL
	        NULL,          // lpClass; not required
	        NULL,          // lpcbClass; lpClass is NULL; hence, NULL
	        NULL           // lpftLastWriteTime; set to NULL
	)) {
		HKEY hSubKey;
		DWORD dwRegion;

        dwIndex += 1;
        dwNewKeySize = (sizeof(szNewKey) / sizeof(TCHAR));

		RegOpenKeyExW(hKey, szNewKey,0, 0, &hSubKey);

		dwType = REG_DWORD;
		dwLen = sizeof(dwRegion);
		RegQueryValueEx (hSubKey, TEXT("Index"), NULL,
						      &dwType, (LPBYTE)&(dwRegion), &dwLen);

		pRegion = &pDrv->regions[dwRegion];

		dwType = REG_SZ;
		dwLen = sizeof(pRegion->wcName);
		RegQueryValueEx (hSubKey, TEXT("FriendlyName"), NULL,
							  &dwType, (LPBYTE)&(pRegion->wcName), &dwLen);

		dwType = REG_DWORD;
		dwLen = sizeof(pRegion->lpvPhysAddr);
		RegQueryValueEx (hSubKey, TEXT("Base"), NULL,
						      &dwType, (LPBYTE)&(pRegion->lpvPhysAddr), &dwLen);

		dwType = REG_DWORD;
		dwLen = sizeof(pRegion->dwSize);
		RegQueryValueEx (hSubKey, TEXT("Size"), NULL,
							  &dwType, (LPBYTE)&(pRegion->dwSize), &dwLen);

		RegCloseKey( hSubKey );

		pRegion->lpvKernelAddr = VirtualAlloc(0, pRegion->dwSize, MEM_RESERVE, PAGE_NOACCESS);

		VirtualCopy( pRegion->lpvKernelAddr,
		            (PVOID)((UINT32)pRegion->lpvPhysAddr>>8),
		            pRegion->dwSize,
		            PAGE_PHYSICAL | PAGE_READWRITE );

		RETAILMSG(1,(DTAG TEXT("Found %8s Memory Region(%d). Phys:0x%08X Virt:0x%08X Size:0x%08X\r\n"),
			pRegion->wcName, dwRegion, pRegion->lpvPhysAddr, pRegion->lpvKernelAddr, pRegion->dwSize ));

	}

	RegCloseKey( hActiveKey );
	RegCloseKey( hKey );


  return TRUE;
}

BOOL WINAPI MEM_DllMain(HINSTANCE  hInstDLL,
                        DWORD      dwReason,
                        LPVOID     pReserved)
{
	switch (dwReason)
	{
		case DLL_PROCESS_ATTACH:
			DEBUGREGISTER(hInstDLL);
			DisableThreadLibraryCalls(hInstDLL);
			break;

		case DLL_PROCESS_DETACH:
			break;
	}
	return TRUE;
}



void CleanupMemory(PDRVCONTEXT pDrv)
{
	DWORD			dwProcId = GetCallerVMProcessId();
	MEMPOOL_REGION *pRegion;
	PMEMDESC		pCurrent;
	DWORD			i;

	for (i = 0; i < MAX_REGIONS; i++)
	{
		pRegion = &pDrv->regions[i];

		// find the first fit for the requested size
		for(pCurrent = pRegion->pList; NULL != pCurrent; pCurrent = pCurrent->next)
		{
			if( (pCurrent->inuse) && (pCurrent->dwProcId == dwProcId) )
			{
				FreeFromPool(pCurrent);
			}
		}
	}
}

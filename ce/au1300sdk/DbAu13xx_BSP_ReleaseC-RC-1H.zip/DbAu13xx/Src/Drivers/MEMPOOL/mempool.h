/**********************************************************************
* Copyright 2007 RMI Corp. All Rights Reserved.
*
* Unless otherwise designated in writing, this software and any related
* documentation are the confidential proprietary information of RMI
* Corp.
*
* THESE MATERIALS ARE PROVIDED "AS IS" WITHOUT ANY
* UNLESS OTHERWISE NOTED IN WRITING, EXPRESS OR IMPLIED WARRANTY OF ANY
* KIND, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* NONINFRINGEMENT, TITLE, FITNESS FOR ANY PARTICULAR PURPOSE AND IN NO
* EVENT SHALL RMI COPR. OR ITS LICENSORS BE LIABLE FOR ANY DAMAGES
* WHATSOEVER.
*
* RMI Corp. does not assume any responsibility for any errors which may
* appear in the Materials nor any responsibility to support or update
* the Materials. RMI Corp. retains the right to modify the Materials
* at any time, without notice, and is not obligated to provide such
* modified Materials to you. RMI Corp. is not obligated to furnish,
* support, or make any further information available to you.
***********************************************************************/
//------------------------------------------------------------------------------
// File: mempool.h
//------------------------------------------------------------------------------

#ifndef _MEMPOOL_H
#define _MEMPOOL_H

// 64kB pages as per MSDN: "If the memory is being reserved, the specified address 
// is rounded down to the next 64-KB boundary."
#define MEMPOOL_PAGESIZE 0x10000 
#define MEMPOOL_PAGEMASK 0x0FFFF
#define MAX_REGIONS		 10

typedef struct _MEMDESC
{
  DWORD 	dwProcId;	   	// ProcessID of memory requesting caller
  DWORD 	*kvirt;			// Virtual address pointed to by this descriptor(KERNEL)
  DWORD 	*phys;			// Physical address pointed to by this desciptor
  DWORD 	*virt;			// Virutal memory mapped to caller's process
  DWORD		dwSize;
  struct _MEMDESC *next;
  struct _MEMDESC *prev;
  BOOL  	inuse;
  DWORD		dwActualSize;
} MEMDESC, *PMEMDESC;

typedef struct
{
  WCHAR 	wcName[MAX_PATH];
  LPVOID 	lpvPhysAddr;
  LPVOID 	lpvKernelAddr;
  DWORD 	dwSize;
  PMEMDESC 	pList;
  DWORD     dwTiling;
  DWORD     dwReserved0;
} MEMPOOL_REGION, *PMEMPOOL_REGION;

typedef struct
{
  DWORD 			dwSize;
  INT 				nNumOpens;
  CRITICAL_SECTION  CriticalSection;
  MEMPOOL_REGION 	regions[MAX_REGIONS];
} DRVCONTEXT, *PDRVCONTEXT;

BOOL GetConfigData(PDRVCONTEXT, DWORD);

//
// Declare the external entry points here. Use declspec so we don’t
// need a .def file. Bracketed with extern C to avoid mangling in C++.
//
#ifdef __cplusplus
extern "C" {
#endif //__cplusplus
  __declspec(dllexport) DWORD MEM_Init(DWORD dwContext);
  __declspec(dllexport) BOOL  MEM_PreDeinit(DWORD dwContext);
  __declspec(dllexport) BOOL  MEM_Deinit(DWORD dwContext);
  __declspec(dllexport) DWORD MEM_Open(DWORD dwContext, DWORD dwAccess, DWORD dwShare);
  __declspec(dllexport) BOOL  MEM_PreClose(DWORD dwOpen);
  __declspec(dllexport) BOOL  MEM_Close (DWORD dwOpen);
  __declspec(dllexport) DWORD MEM_Read(DWORD dwOpen, LPVOID pBuffer, DWORD dwCount);
  __declspec(dllexport) DWORD MEM_Write(DWORD dwOpen, LPVOID pBuffer, DWORD dwCount);
  __declspec(dllexport) DWORD MEM_Seek(DWORD dwOpen, long lDelta, WORD wType);
  __declspec(dllexport) BOOL  MEM_IOControl(DWORD dwOpen, DWORD dwCode,
									       PBYTE pIn, DWORD dwIn,
                                           PBYTE pOut, DWORD dwOut,
                                           DWORD *pdwBytesWritten);
  __declspec(dllexport) void  MEM_PowerDown(DWORD dwContext);
  __declspec(dllexport) void  MEM_PowerUp(DWORD dwContext);
#ifdef __cplusplus
} // extern "C"
#endif //__cplusplus


#endif // _MEMPOOL_H

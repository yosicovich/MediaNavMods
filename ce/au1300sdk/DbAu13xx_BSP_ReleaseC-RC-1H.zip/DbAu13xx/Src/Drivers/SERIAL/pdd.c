//
// Copyright (c) Microsoft Corporation.  All rights reserved.
// Copyright (c) 2004 BSQUARE Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
#include <windows.h>
#include <bceddk.h>
#include <ddkreg.h>
#define USE_NEW_SERIAL_MODEL
#include <serhw.h>
#include <serdbg.h>
#include "platform.h"
#include "pdd.h"

//------------------------------------------------------------------------------

#define UART_INTEN_TX_OFF  (UART_INTEN_LIE|UART_INTEN_RIE|UART_INTEN_MIE)
#define UART_INTEN_TX_ON   (UART_INTEN_TX_OFF|UART_INTEN_TIE)

#define INP32(a)           ((UCHAR)READ_PORT_ULONG((ULONG*)(a)))
#define OUT32(a, v)        WRITE_PORT_ULONG((ULONG*)(a), (v))

//------------------------------------------------------------------------------

typedef struct {
	AU1X00_UART *pPortBase;             // Mapped virtual address of uart ports
	ULONG irq;                          // IRQ readed from registry
	ULONG sysIntr;                      // Assigned SYSINTR

	PVOID pMdd;                         // MDD context

	BOOL  open;                         // Is device open?
	DCB   dcb;                          // Serial port DCB

	ULONG commErrors;                   // How many errors occured
	ULONG overrunCount;                 // How many chars was missed

	ULONG txFifoLength;                 // TX FIFO length
	ULONG txFifoThresh;                 // TX FIFO threshold
	ULONG rxFifoLength;                 // RX FIFO length (not used...)
	ULONG rxFifoThresh;                 // RX FIFO threshold (not used...)

	BOOL  powerOff;                     // Are we power-off?
	UCHAR fifoCtrl;                     // fifoctrl register on power-off
	UCHAR lineCtrl;                     // linectrl register on power-off
	UCHAR mdmCtrl;                      // mdmctrl register on power-off
	UCHAR clkDiv;                       // clckdiv register on power-off

	BOOL  addTxIntr;                    // Should we add software TX interrupt?
	BOOL  flowOffCTS;                   // Is CTS down?
	BOOL  flowOffDSR;                   // Is DSR down?

	CRITICAL_SECTION hwCS;              // Guard access to HW registers
	CRITICAL_SECTION txCS;              // Guard HWXmitComChar
	HANDLE txEvent;                     // Signal TX interrupt for HWXmitComChar
} UARTPDD;

//------------------------------------------------------------------------------

static HW_VTBL g_pddVTbl = {
	HWInit, 
	HWPostInit,
	HWDeinit, 
	HWOpen, 
	HWClose, 
	HWGetInterruptType,
	HWRxIntr, 
	HWTxIntr, 
	HWModemIntr, 
	HWLineIntr, 
	HWGetRxBufferSize,
	HWPowerOff, 
	HWPowerOn, 
	HWClearDTR, 
	HWSetDTR, 
	HWClearRTS, 
	HWSetRTS,
	HWEnableIR, 
	HWDisableIR, 
	HWClearBreak, 
	HWSetBreak, 
	HWXmitComChar,
	HWGetStatus, 
	HWReset, 
	HWGetModemStatus, 
	HWGetCommProperties,
	HWPurgeComm, 
	HWSetDCB, 
	HWSetCommTimeouts, 
	HWIOCtl
};

//------------------------------------------------------------------------------
// Table used to convert "UnitIndex" from registry into physical addresses
// and IRQs. Au1x00.h only defines those UARTs that the CPU supports so we use
// that to manage available UARTs.
typedef struct {
	ULONG UartPhysAddr;
	ULONG UartIrq;
} UART_CONFIG;

static UART_CONFIG UartConfig[] = {

#ifdef UART0_PHYS_ADDR
	{ UART0_PHYS_ADDR, HWINTR_UART0 },
#else
	{ 0, 0 },
#endif

#ifdef UART1_PHYS_ADDR
	{ UART1_PHYS_ADDR, HWINTR_UART1 },
#else
	{ 0, 0 },
#endif

#ifdef UART2_PHYS_ADDR
	{ UART2_PHYS_ADDR, HWINTR_UART2 },
#else
	{ 0, 0 },
#endif

#ifdef UART3_PHYS_ADDR
	{ UART3_PHYS_ADDR, HWINTR_UART3 },
#else
	{ 0, 0 },
#endif

};

#define UART_CONFIG_SIZE (sizeof(UartConfig)/sizeof(UART_CONFIG))

//------------------------------------------------------------------------------
//
// Function:     ReadLineStat
//
// Description:  This function reads line status register and it calls back
//               MDD if line event occurs. This must be done in this way
//               because register bits are cleared on read.
//

static UCHAR ReadLineStat(UARTPDD *pPdd)
{
	UCHAR lineStat;
	ULONG events;

	// Nothing happen yet...   
	events = 0;

	// Read line status register (it clear most bits)
	lineStat = INP32(&pPdd->pPortBase->linestat);

	// Check for errors
	if ((lineStat&(UART_LINESTAT_OE|UART_LINESTAT_PE|UART_LINESTAT_FE)) != 0) {
		if ((lineStat & UART_LINESTAT_OE) != 0) {
			pPdd->overrunCount++;
			pPdd->commErrors |= CE_OVERRUN;
		}
		if ((lineStat & UART_LINESTAT_PE) != 0) pPdd->commErrors |= CE_RXPARITY;
		if ((lineStat & UART_LINESTAT_FE) != 0) pPdd->commErrors |= CE_FRAME;
		events |= EV_ERR;
	}

	// And for break
	if ((lineStat&UART_LINESTAT_BI) != 0) events |= EV_BREAK;

	// Let MDD know if something happen
	if (events != 0) EvaluateEventFlag(pPdd->pMdd, events);

	return lineStat;
}

//------------------------------------------------------------------------------
//
// Function:     ReadModemStat
//
// Description:  This function reads modem status register and it calls back
//               MDD if modem event occurs. This must be done in this way
//               because register bits are cleared on read.
//

static UCHAR ReadModemStat(UARTPDD *pPdd)
{
	UCHAR modemStat = 0;
	ULONG events;

	// Nothing happen yet...   
	events = 0;

	modemStat = INP32(&pPdd->pPortBase->mdmstat);

	// For changes, we use callback to evaluate the event
	if ((modemStat & UART_MDMSTAT_DC) != 0)  events |= EV_CTS;
	if ((modemStat & UART_MDMSTAT_DR) != 0)  events |= EV_DSR;
	if ((modemStat & UART_MDMSTAT_TRI) != 0) events |= EV_RING;
	if ((modemStat & UART_MDMSTAT_DD) != 0)  events |= EV_RLSD;

	// Let MDD know if something happen
	if (events != 0) EvaluateEventFlag(pPdd->pMdd, events);

	return modemStat;
}


//------------------------------------------------------------------------------
//
// Function:     SetBaudRate
//
// Description:  This function sets baud rate.
//

static BOOL SetBaudRate(UARTPDD *pPdd, ULONG baudRate)
{
	ULONG divider;
	BOOL ok = FALSE;

	// Check baud rate values
	if (baudRate < 110 || baudRate > 1546875) goto cleanUp;

	// Calculate divider
	divider = GetPBUSSpeed() / (16 * baudRate);

	EnterCriticalSection(&pPdd->hwCS);
	OUT32(&pPdd->pPortBase->clkdiv, divider);
	LeaveCriticalSection(&pPdd->hwCS);

	ok = TRUE;

cleanUp:
	return ok;
}

//------------------------------------------------------------------------------
//
// Function:     SetWordLength
//
// Description:  This function sets word length.
//

static BOOL SetWordLength(UARTPDD *pPdd, UCHAR wordLength)
{
	UCHAR lineCtrl;
	BOOL ok = FALSE;

	if (wordLength < 5 || wordLength > 8) goto cleanUp;

	EnterCriticalSection(&pPdd->hwCS);
	lineCtrl = INP32(&pPdd->pPortBase->linectrl);
	lineCtrl = (lineCtrl & 0x03)|(wordLength - 5);
	OUT32(&pPdd->pPortBase->linectrl, lineCtrl);
	LeaveCriticalSection(&pPdd->hwCS);

	ok = TRUE;

cleanUp:
	return ok;
}

//------------------------------------------------------------------------------
//
// Function:     SetParity
//
// Description:  This function sets parity.
//

static BOOL SetParity(UARTPDD *pPdd, UCHAR parity)
{
	UCHAR lineCtrl;
	BOOL ok = FALSE;
	UCHAR mask;

	switch (parity) {
	case NOPARITY:
		mask = 0;
		break;
	case ODDPARITY:
		mask = UART_LINECTRL_PE | (0 << 4);
		break;
	case EVENPARITY:
		mask = UART_LINECTRL_PE | (1 << 4);
		break;
	case MARKPARITY:
		mask = UART_LINECTRL_PE | (2 << 4);
		break;
	case SPACEPARITY:
		mask = UART_LINECTRL_PE | (3 << 4);
		break;
	default:
		goto cleanUp;
   }   

	EnterCriticalSection(&pPdd->hwCS);
	lineCtrl = INP32(&pPdd->pPortBase->linectrl);
	lineCtrl = (lineCtrl & ~UART_LINECTRL_ST)|mask;
	OUT32(&pPdd->pPortBase->linectrl, lineCtrl);
	LeaveCriticalSection(&pPdd->hwCS);

	ok = TRUE;

cleanUp:
	return ok;
}

//------------------------------------------------------------------------------
//
// Function:     SetStopBits
//
// Description:  This function sets word length.
//

static BOOL SetStopBits(UARTPDD *pPdd, UCHAR stopBits)
{
	UCHAR lineCtrl;
	BOOL ok = FALSE;
	UCHAR mask;

	switch (stopBits) {
	case ONESTOPBIT:
		mask = 0;
		break;
	case ONE5STOPBITS:
	case TWOSTOPBITS:
		mask = UART_LINECTRL_ST;
		break;
	default:
		goto cleanUp;
	}   

	EnterCriticalSection(&pPdd->hwCS);
	lineCtrl = INP32(&pPdd->pPortBase->linectrl);
	lineCtrl = (lineCtrl & ~UART_LINECTRL_ST)|mask;
	OUT32(&pPdd->pPortBase->linectrl, lineCtrl);
	LeaveCriticalSection(&pPdd->hwCS);

	ok = TRUE;

cleanUp:
	return ok;
}

//------------------------------------------------------------------------------
//
// Function:     GetSerialObject
//
// Description:  This function returns a pointer to a HWOBJ structure, which
//               contains the correct function pointers and parameters for
//               the relevant PDD layer's hardware interface functions.

PHWOBJ GetSerialObject(DWORD index)
{
	PHWOBJ pHWObj;

	// Allocate space for the HWOBJ.
	pHWObj = malloc(sizeof(HWOBJ));
	if (pHWObj == NULL) goto cleanUp;

	// Fill in the HWObj structure

	pHWObj->BindFlags = THREAD_AT_OPEN; // Have MDD create thread when device is first opened.
	pHWObj->dwIntID = 0;                // SysIntr is filled in at init time
	pHWObj->pFuncTbl = &g_pddVTbl;      // Return pointer to appropriate functions

cleanUp:
	return pHWObj;
}
 

//------------------------------------------------------------------------------
//
// Function:     HWInit
//
// Description:  This function initializes a serial device and it returns
//               information about device
//

static PVOID HWInit(ULONG context, PVOID pMdd, PHWOBJ pHWObj)
{
	BOOL ok = FALSE;
	UARTPDD *pPdd = NULL;
	PHYSICAL_ADDRESS phBase;
	HKEY hKey = NULL;
	ULONG UnitIndex;
	ULONG Size;

  
	DEBUGMSG(ZONE_OPEN, (L"+au1uart::HWInit %s 0x%08x 0x%08x\n", context, pMdd, pHWObj));

	// Allocate SER_INFO structure
	pPdd = malloc(sizeof(UARTPDD));
	if (pPdd == NULL) goto cleanUp;

	// Clear it
	memset(pPdd, 0, sizeof(UARTPDD));

	// Open registry 
	hKey = OpenDeviceKey((LPCTSTR)context);
	if (hKey == NULL) {
		DEBUGMSG(ZONE_ERROR, (L" au1uart::HWInit - Failed open registry key\n"));
		goto cleanUp;
	}

	// Read UnitIndex from the Registry
	Size = sizeof(UnitIndex);
	if (RegQueryValueEx(hKey, L"UnitIndex", NULL, NULL, (PUCHAR)&UnitIndex, &Size)) {
		RETAILMSG(1,(L" au1uart::HWInit - Failed open \"UnitIndex\" registry entry\n"));
		goto cleanUp;
	}

	// Check UnitIndex is valid and supported
	if (UnitIndex > UART_CONFIG_SIZE || UartConfig[UnitIndex].UartPhysAddr == 0) {
		RETAILMSG(1,(L" au1uart::HWInit - UnitIndex %d is invalid\n", UnitIndex));
		goto cleanUp;
	}

	// Map physical memory
	phBase.QuadPart = UartConfig[UnitIndex].UartPhysAddr;
	pPdd->pPortBase = (AU1X00_UART*)MmMapIoSpace(phBase, sizeof(AU1X00_UART), FALSE);
	if (pPdd->pPortBase == NULL) {
		DEBUGMSG(ZONE_ERROR, (L" au1uart::HWInit - Failed map physical memory 0x%x\n", phBase.LowPart));
		goto cleanUp;
	}

	// Save IRQ
	pPdd->irq = UartConfig[UnitIndex].UartIrq;

	pPdd->sysIntr = InterruptConnect(Internal,0,pPdd->irq,0);

	if (SYSINTR_NOP==pPdd->sysIntr) {
		DEBUGMSG(ZONE_ERROR, (L" au1uart::HWInit - Failed map IRQ %d\n", pPdd->irq));
		goto cleanUp;
	}

	
	// Save it to HW object
	pHWObj->dwIntID = pPdd->sysIntr;

	// Create sync objects
	InitializeCriticalSection(&pPdd->hwCS);
	InitializeCriticalSection(&pPdd->txCS);
	pPdd->txEvent = CreateEvent(0, FALSE, FALSE, NULL);
	if (pPdd->txEvent == NULL) {
		DEBUGMSG(ZONE_ERROR, (L" au1uart::HWInit - Failed create event\n"));
		goto cleanUp;
	}
   
	// Allow device
	OUT32(&pPdd->pPortBase->enable, 0);
	OUT32(&pPdd->pPortBase->enable, UART_ENABLE_CE);
	OUT32(&pPdd->pPortBase->enable, UART_ENABLE_CE|UART_ENABLE_E);

	// Disable all interrupts
	OUT32(&pPdd->pPortBase->inten, 0);

	// Save MDD context for callback
	pPdd->pMdd = pMdd;

	// Initialization succeeded
	ok = TRUE;

cleanUp:
	if (hKey != NULL) RegCloseKey(hKey);
	if (!ok && pPdd != NULL) {
		HWDeinit(pPdd);
		pPdd = NULL;
	}   
	DEBUGMSG(ZONE_OPEN, (L"-au1uart::HWInit 0x%08x\n", pPdd));
	return pPdd;
}


//------------------------------------------------------------------------------
//
// Function:     HWPostInit
//
// Description:  This function is called by the upper layer after hardware
//               independent initialization is done (at end of COM_Init).
//

static BOOL HWPostInit(PVOID pContext)
{
	return TRUE;
}

//------------------------------------------------------------------------------
//
// Function:     HWDeinit
//
// Description:  This function is called by the upper layer to de-initialize
//               the hardware when a device driver is unloaded.

static BOOL HWDeinit(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;

	DEBUGMSG(ZONE_CLOSE, (L"+au1uart::HWDeinit 0x%08x\n", pContext));

	// Disable device
	if (pPdd->pPortBase != NULL) {
		OUT32(&pPdd->pPortBase->enable, 0);
		MmUnmapIoSpace((PVOID)pPdd->pPortBase, 0x1000);
	}      

	// Disconnect the interrupt
	InterruptDisconnect(pPdd->sysIntr);

	// Delete sync objects
	DeleteCriticalSection(&pPdd->hwCS);
	DeleteCriticalSection(&pPdd->txCS);
	if (pPdd->txEvent != NULL) CloseHandle(pPdd->txEvent);

	// Free driver object
	free(pPdd);

	DEBUGMSG(ZONE_CLOSE, (L"-au1uart::HWDeinit\n"));
	return TRUE;
}

//------------------------------------------------------------------------------

static BOOL HWOpen(PVOID pContext)
{
	BOOL ok = FALSE;
	UARTPDD *pPdd = (UARTPDD*)pContext;
	UCHAR fifoCtrl;

	DEBUGMSG(ZONE_OPEN, (L"+au1uart::HWOpen 0x%x\n", pContext));

	if (pPdd->open) goto cleanUp;

	pPdd->commErrors = 0;
	pPdd->overrunCount = 0;
	pPdd->flowOffCTS = FALSE;
	pPdd->flowOffDSR = FALSE;
	pPdd->addTxIntr = FALSE;
	pPdd->powerOff = FALSE;
	pPdd->open = TRUE;

	// Initialize FIFO constant   
	pPdd->txFifoLength = 16;
	pPdd->txFifoThresh = 8;
	pPdd->rxFifoLength = 16;
	pPdd->rxFifoThresh = 1;

	EnterCriticalSection(&pPdd->hwCS);

	// Set line control register
	OUT32(&pPdd->pPortBase->linectrl, 0);
	SetBaudRate(pPdd, pPdd->dcb.BaudRate);
	SetWordLength(pPdd, pPdd->dcb.ByteSize);
	SetStopBits(pPdd, pPdd->dcb.StopBits);
	SetParity(pPdd, pPdd->dcb.Parity);

	// Set modem control register
	OUT32(&pPdd->pPortBase->mdmctrl, 0);

	// Set FIFO values & enable flags
	fifoCtrl = UART_FIFOCTRL_FE | UART_FIFOCTRL_MS | (0 << 6) | (2 << 4);

	// Set reset TX & RX flags
	fifoCtrl |= UART_FIFOCTRL_RR | UART_FIFOCTRL_TR;

	// Set fifo control register
	OUT32(&pPdd->pPortBase->fifoctrl, fifoCtrl);

	// Enable interrupts (no TX interrupt)
	OUT32(&pPdd->pPortBase->inten, UART_INTEN_TX_OFF);

	ReadLineStat(pPdd);
	ReadModemStat(pPdd);

	LeaveCriticalSection(&pPdd->hwCS);

	ok = TRUE;

cleanUp:
	DEBUGMSG(ZONE_OPEN, (L"-au1uart::HWOpen %s\n", ok ? L"TRUE" : L"FALSE"));
	return ok;
}

//------------------------------------------------------------------------------

static ULONG HWClose(PVOID pContext)
{
	ULONG rc = -1;
	UARTPDD *pPdd = (UARTPDD*)pContext;

	DEBUGMSG(ZONE_CLOSE, (L"+au1uart::HWClose 0x%x\n", pContext));

	if (!pPdd->open) goto cleanUp;

	EnterCriticalSection(&pPdd->hwCS);

	// Disable all interrupts and clear modem control register
	OUT32(&pPdd->pPortBase->inten, 0);
	OUT32(&pPdd->pPortBase->mdmctrl, 0);

	LeaveCriticalSection(&pPdd->hwCS);

	pPdd->open = FALSE;
   
cleanUp:
	DEBUGMSG(ZONE_CLOSE, (L"-au1uart::HWClose %d\n", rc));
	return rc;
}

//------------------------------------------------------------------------------
//
// Function:     HWGetInterruptType
//
// Description:  This function is called by the upper layer whenever an
//               interrupt occurs.  The return code is then checked by the MDD
//               to determine which of the four interrupt handling routines are
//               to be called.
// 

static INTERRUPT_TYPE HWGetInterruptType(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD *)pContext;
	INTERRUPT_TYPE type;
	UCHAR intCause;

	DEBUGMSG(ZONE_THREAD, (L"+au1uart::HWGetInterruptType 0x%x\n", pContext));

	intCause = INP32(&pPdd->pPortBase->intcause);
	if ((intCause & UART_INTCAUSE_IP) != 0) {
		type = INTR_NONE;
	} else {      
		switch (intCause & UART_INTCAUSE_IID) {
		case UART_INTCAUSE_IID_MS:
			type = INTR_MODEM;
			break;
		case UART_INTCAUSE_IID_TBA:
			type = INTR_TX;
			break;
		case UART_INTCAUSE_IID_RDA:
		case UART_INTCAUSE_IID_CTO:         
			type = INTR_RX;
			break;
		case UART_INTCAUSE_IID_RLS:
			type = INTR_LINE;
			break;
		default:
			type = INTR_NONE;
		}
	}

	// Add software TX interrupt to resume send
	if (pPdd->addTxIntr) {
		type |= INTR_TX;
		pPdd->addTxIntr = FALSE;
	}

	DEBUGMSG(ZONE_THREAD, (L"-au1uart::HWGetInterruptType %d %02x\n", type, intCause));

	return type;
}

//------------------------------------------------------------------------------
//
// Function:     HWRxIntr
//
// Description:  This function gets several characters from the hardware
//               receive buffer and puts them in a buffer provided via 
//               the second argument. It returns the number of bytes lost to
//               overrun.
//

static ULONG HWRxIntr(PVOID pContext, PUCHAR pRxBuffer, ULONG *pLength)
{
	UARTPDD *pPdd = (UARTPDD *)pContext;
	ULONG count = *pLength;
	UCHAR lineStat, rxChar;
	BOOL rxFlag, replaceParityError;

	DEBUGMSG(ZONE_THREAD, (L"+au1uart::HWRxIntr 0x%x 0x%x %d\n", pContext, pRxBuffer, *pLength));

	*pLength = 0;
	rxFlag = FALSE;
	replaceParityError = (pPdd->dcb.fErrorChar != '\0') && pPdd->dcb.fParity;
	while (count > 0) {

		// Get line status register
		lineStat = ReadLineStat(pPdd);

		// If there isn't more chars exit loop
		if ((lineStat & UART_LINESTAT_DR) == 0) break;

		// Get received char
		rxChar = INP32(&pPdd->pPortBase->rxdata);

		// Ignore char in DSR is low and we care about it
		if (
			pPdd->dcb.fDsrSensitivity &&
			(ReadModemStat(pPdd) & UART_MDMSTAT_DS) == 0
		) continue;

		// Ignore NUL char if requested
		if (rxChar == '\0' && pPdd->dcb.fNull) continue;

		// Replace char with parity error
		if (replaceParityError && (lineStat & UART_LINESTAT_PE) != 0) {
			rxChar = pPdd->dcb.ErrorChar;
		}         

		// See if we need to generate an EV_RXFLAG
		if (rxChar == pPdd->dcb.EvtChar) rxFlag = TRUE;

		// Store it to buffer
		*pRxBuffer++ = rxChar;
		(*pLength)++;
		count--;
	}

	// Send event to MDD
	if (rxFlag) EvaluateEventFlag(pPdd->pMdd, EV_RXFLAG);

	// Clear overrun counter and use this value as return code
	count = pPdd->overrunCount;
	pPdd->overrunCount = 0;

	// So we are done
	DEBUGMSG(ZONE_THREAD, (L"-au1uart::HWRxIntr %d (%d)\n", count, *pLength));
	return count;
}

//------------------------------------------------------------------------------
//
// Function:     HWTxIntr
//
// Description:  This function is called from the MDD whenever INTR_TX is
//               returned by HWGetInterruptType which indicate empty place in
//               transmitter FIFO.
// 

static VOID HWTxIntr(PVOID pContext, PUCHAR pTxBuffer, ULONG *pLength)
{
	UARTPDD *pPdd = (UARTPDD *)pContext;
	ULONG count;
	UCHAR lineStat, modemStat;

	DEBUGMSG(ZONE_THREAD, (L"+au1uart::HWTxIntr 0x%x 0x%x %d\n", pContext, pTxBuffer, *pLength));

	EnterCriticalSection(&pPdd->hwCS);

	// There can be nothing to send - then disable TX interrupt
	if (*pLength == 0) {
		OUT32(&pPdd->pPortBase->inten, UART_INTEN_TX_OFF);
		LeaveCriticalSection(&pPdd->hwCS);
		goto cleanUp;
	}

	// Set event to fire HWXmitComChar
	PulseEvent(pPdd->txEvent);

	// If CTS flow control is desired, check it. If clear, don't send,
	// but loop.  When CTS comes back on, the OtherInt routine will
	// detect this and re-enable TX interrupts (causing Flushdone).
	// For finest granularity, we would check this in the loop below,
	// but for speed, I check it here (up to 8 xmit characters before
	// we actually flow off.
	if (pPdd->dcb.fOutxCtsFlow) {
		modemStat = ReadModemStat(pPdd);   
		if ((modemStat & UART_MDMSTAT_CT) == 0) {
			// Set flag
			pPdd->flowOffCTS = TRUE;
			// Disable TX interrupt
			OUT32(&pPdd->pPortBase->inten, UART_INTEN_TX_OFF);
			LeaveCriticalSection(&pPdd->hwCS);
			*pLength = 0;
			goto cleanUp;
		}
	}
   
	// Same thing applies for DSR
	if (pPdd->dcb.fOutxDsrFlow) {
		modemStat = ReadModemStat(pPdd);   
		if ((modemStat & UART_MDMSTAT_DS) == 0) {
			// Set flag
			pPdd->flowOffDSR = TRUE;
			// Disable TX interrupt
			OUT32(&pPdd->pPortBase->inten, UART_INTEN_TX_OFF);
			LeaveCriticalSection(&pPdd->hwCS);
			*pLength = 0;
			goto cleanUp;
		}
	}
   
	LeaveCriticalSection(&pPdd->hwCS);

	// Give chance to HWXmitComChar there

	EnterCriticalSection(&pPdd->hwCS);

	// Read line status
	lineStat = ReadLineStat(pPdd);
	if ((lineStat&UART_LINESTAT_TE) != 0) {
		count = pPdd->txFifoLength;
	} else if ((lineStat&UART_LINESTAT_TT) != 0) {
		count = pPdd->txFifoLength - pPdd->txFifoThresh;
	} else {
		count = 0;
	}      

	// We can't send more data then avaiable
	if (count > *pLength) count = *pLength;

	// Ok, so send data
	*pLength = 0;
	while (count > 0) {
		OUT32(&pPdd->pPortBase->txdata, *pTxBuffer++);
		(*pLength)++;
		count--;
	}

	// Enable TX interrupt
	OUT32(&pPdd->pPortBase->inten, UART_INTEN_TX_ON);

	LeaveCriticalSection(&pPdd->hwCS);

cleanUp:
	DEBUGMSG(ZONE_THREAD, (L"-au1uart::HWTxIntr (%d)\n", *pLength));
}

//------------------------------------------------------------------------------
//
// Function:     HWModemIntr
//
// Description:  This function is called from the MDD whenever INTR_MODEM is
//               returned by HWGetInterruptType which indicate change in
//               modem registry.
//

static VOID HWModemIntr(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;
	UCHAR modemStat;

	DEBUGMSG(ZONE_THREAD, (L"+au1uart::HWModemIntr 0x%x\n", pContext));

	// Get actual modem status
	modemStat = ReadModemStat(pPdd);

	// If we are currently flowed off via CTS or DSR, then
	// we better signal the TX thread when one of them changes
	// so that TX can resume sending.

	EnterCriticalSection(&pPdd->hwCS);

	if (pPdd->flowOffDSR && (modemStat & UART_MDMSTAT_DS) != 0) {
		// Clear flag      
		pPdd->flowOffDSR = FALSE;
		// DSR is set, so go ahead and resume sending
		OUT32(&pPdd->pPortBase->inten, UART_INTEN_TX_ON);
		// Then simulate a TX intr to get things moving
		pPdd->addTxIntr = TRUE;
	}

	if (pPdd->flowOffCTS && (modemStat & UART_MDMSTAT_CT) != 0) {
		pPdd->flowOffCTS = FALSE;
		// CTS is set, so go ahead and resume sending
		OUT32(&pPdd->pPortBase->inten, UART_INTEN_TX_ON);
		// Then simulate a TX intr to get things moving
		pPdd->addTxIntr = TRUE;
	}

	LeaveCriticalSection(&pPdd->hwCS);
	DEBUGMSG(ZONE_THREAD, (L"-au1uart::HWModemIntr\n"));
}

//------------------------------------------------------------------------------
//
// Function:     HWLineIntr
//
// Description:  This function is called from the MDD whenever INTR_LINE is
//               returned by HWGetInterruptType which indicate change in
//               line status registry.
//

static VOID HWLineIntr(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD *)pContext;
	UCHAR fifoCtrl;

	DEBUGMSG(ZONE_THREAD, (L"+au1uart::HWLineIntr 0x%x\n", pContext));

	ReadLineStat(pPdd);

	EnterCriticalSection(&pPdd->hwCS);

	// Reset receiver 
	fifoCtrl = INP32(&pPdd->pPortBase->fifoctrl);
	OUT32(&pPdd->pPortBase->fifoctrl, fifoCtrl|UART_FIFOCTRL_RR);

	// Read all character in fifo
	while (ReadLineStat(pPdd) & UART_LINESTAT_DR) {
		INP32(&pPdd->pPortBase->rxdata);
	}

	LeaveCriticalSection(&pPdd->hwCS);
	DEBUGMSG(ZONE_THREAD, (L"-au1uart::HWLineIntr\n"));
}

//------------------------------------------------------------------------------
//
// Function:     HWGetRxBufferSize
//
// Description:  This function returns the size of the hardware buffer passed
//               to the interrupt initialize function.  It would be used only
//               for devices which share a buffer between the MDD/PDD and
//               an ISR. It always returns 0 for 16550 type UARTS.
// 

static ULONG HWGetRxBufferSize(PVOID pContext)
{
	return 0;
}

//------------------------------------------------------------------------------

static BOOL HWPowerOff(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD *)pContext;

	// Save registers to be able power on
	pPdd->fifoCtrl = INP32(&pPdd->pPortBase->fifoctrl);
	pPdd->lineCtrl = INP32(&pPdd->pPortBase->linectrl);
	pPdd->mdmCtrl  = INP32(&pPdd->pPortBase->mdmctrl);
	pPdd->clkDiv   = INP32(&pPdd->pPortBase->clkdiv);

	// Disable device and clock
	OUT32(&pPdd->pPortBase->enable, 0);

	// Set flag
	pPdd->powerOff = TRUE;

	// We are done 
	return TRUE;
}

//------------------------------------------------------------------------------

static BOOL HWPowerOn(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD *)pContext;

	// Do power-on only if there was power-off
	if (pPdd->powerOff) {

		// Allow device clock
		OUT32(&pPdd->pPortBase->enable, UART_ENABLE_CE);

		// Then device itself
		OUT32(&pPdd->pPortBase->enable, UART_ENABLE_CE|UART_ENABLE_E);

		// Restore any registers that we need
		OUT32(&pPdd->pPortBase->fifoctrl, pPdd->fifoCtrl);
		OUT32(&pPdd->pPortBase->linectrl, pPdd->lineCtrl);
		OUT32(&pPdd->pPortBase->mdmctrl,  pPdd->mdmCtrl);
		OUT32(&pPdd->pPortBase->clkdiv,   pPdd->clkDiv);

		// Reset flag   
		pPdd->powerOff = FALSE;
	}
	return TRUE;
}

//------------------------------------------------------------------------------
//
// Function:     HWClearDTR
//
// Description:  This function clears DTR.
//

static VOID HWClearDTR(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;
	UCHAR mdmCtrl;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWClearDTR 0x%x\n", pContext));

	EnterCriticalSection(&pPdd->hwCS);
	mdmCtrl = INP32(&pPdd->pPortBase->mdmctrl);
	OUT32(&pPdd->pPortBase->mdmctrl, mdmCtrl & ~UART_MDMCTRL_DT);
	LeaveCriticalSection(&pPdd->hwCS);

	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWClearDTR\n"));
}

//------------------------------------------------------------------------------
//
// Function:     HWSetDTR
//
// Description:  This function sets DTR.
//

static VOID HWSetDTR(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;
	UCHAR mdmCtrl;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWSetDTR 0x%x\n", pContext));

	EnterCriticalSection(&pPdd->hwCS);
	mdmCtrl = INP32(&pPdd->pPortBase->mdmctrl);
	OUT32(&pPdd->pPortBase->mdmctrl, mdmCtrl | UART_MDMCTRL_DT);
	LeaveCriticalSection(&pPdd->hwCS);

	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWSetDTR\n"));
}

//------------------------------------------------------------------------------
//
// Function:     HWClearRTS
//
// Description:  This function clears RTS.
//

static VOID HWClearRTS(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;
	UCHAR mdmCtrl;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWClearRTS 0x%x\n", pContext));

	EnterCriticalSection(&pPdd->hwCS);
	mdmCtrl = INP32(&pPdd->pPortBase->mdmctrl);
	OUT32(&pPdd->pPortBase->mdmctrl, mdmCtrl & ~UART_MDMCTRL_RT);
	LeaveCriticalSection(&pPdd->hwCS);

	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWClearRTS\n"));
}

//------------------------------------------------------------------------------
//
// Function:     HWSetRTS
//
// Description:  This function sets RTS.
//

static VOID HWSetRTS(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;
	UCHAR mdmCtrl;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWSetRTS 0x%x\n", pContext));

	EnterCriticalSection(&pPdd->hwCS);
	mdmCtrl = INP32(&pPdd->pPortBase->mdmctrl);
	OUT32(&pPdd->pPortBase->mdmctrl, mdmCtrl | UART_MDMCTRL_RT);
	LeaveCriticalSection(&pPdd->hwCS);

	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWSetRTS\n"));
}

//------------------------------------------------------------------------------

static BOOL HWEnableIR(PVOID pContext, ULONG baudRate)
{
	return TRUE;
}

//------------------------------------------------------------------------------

static BOOL HWDisableIR(PVOID pContext)
{
	return TRUE;
}

//------------------------------------------------------------------------------
//
// Function:     HWClearBreak
//
// Description:  This function clears break.
//

static VOID HWClearBreak(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;
	UCHAR lineCtrl;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWClearBreak 0x%x\n", pContext));

	EnterCriticalSection(&pPdd->hwCS);
	lineCtrl = INP32(&pPdd->pPortBase->linectrl);
	OUT32(&pPdd->pPortBase->linectrl, lineCtrl&~UART_LINECTRL_SB);
	LeaveCriticalSection(&pPdd->hwCS);

	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWClearBreak\n"));
}

//------------------------------------------------------------------------------
//
// Function:     HWSetBreak
//
// Description:  This function sets break.
//

static VOID HWSetBreak(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;
	UCHAR lineCtrl;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWSetBreak 0x%x\n", pContext));

	EnterCriticalSection(&pPdd->hwCS);
	lineCtrl = INP32(&pPdd->pPortBase->linectrl);
	OUT32(&pPdd->pPortBase->linectrl, lineCtrl|UART_LINECTRL_SB);
	LeaveCriticalSection(&pPdd->hwCS);

	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWSetBreak\n"));
}

//------------------------------------------------------------------------------
//
// Function:     HWReset
//
// Description:  This function performs any operations associated 
//               with a device reset.
//

static VOID HWReset(PVOID pContext)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWReset 0x%x\n", pContext));

	EnterCriticalSection(&pPdd->hwCS);
	// Enable interrupts
	OUT32(&pPdd->pPortBase->inten, UART_INTEN_TX_OFF);
	LeaveCriticalSection(&pPdd->hwCS);

	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWReset\n"));
}

//------------------------------------------------------------------------------
//
// Function:     HWGetModemStatus
//
// Description:  This function retrieves modem status.
//

static VOID HWGetModemStatus(PVOID pContext, ULONG *pModemStat)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;
	UCHAR modemStat;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWGetModemStatus 0x%x\n", pContext));

	modemStat = ReadModemStat(pPdd);

	*pModemStat = 0;
	if ((modemStat & UART_MDMSTAT_CT) != 0) *pModemStat |= MS_CTS_ON;
	if ((modemStat & UART_MDMSTAT_DS) != 0) *pModemStat |= MS_DSR_ON;
	if ((modemStat & UART_MDMSTAT_RI) != 0) *pModemStat |= MS_RING_ON;
	if ((modemStat & UART_MDMSTAT_CD) != 0) *pModemStat |= MS_RLSD_ON;

	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWGetModemStatus (0x%x)\n", *pModemStat));
}

//------------------------------------------------------------------------------
//
// Function:     HWXmitComChar
//
// Description:  This function transmits a char immediately
//

static BOOL HWXmitComChar(PVOID pContext, UCHAR ch)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWXmitComChar 0x%x %d\n", pContext, ch));

	EnterCriticalSection(&pPdd->txCS);

	while (TRUE) {  // We know THR will eventually empty

		EnterCriticalSection(&pPdd->hwCS);

		// Write the character if we can
		if ((ReadLineStat(pPdd) & UART_LINESTAT_TT) != 0) {
			// FIFO is empty, send this character
			OUT32(&pPdd->pPortBase->txdata, ch);
			// Enable TX interrupt
			OUT32(&pPdd->pPortBase->inten, UART_INTEN_TX_ON);
			LeaveCriticalSection(&pPdd->hwCS);
			break;
		}

		// If we couldn't write the data yet, then wait for a TX interrupt
		OUT32(&pPdd->pPortBase->inten, UART_INTEN_TX_ON);
		LeaveCriticalSection(&pPdd->hwCS);

		// Wait until the TX interrupt has signalled
		WaitForSingleObject(pPdd->txEvent, (ULONG)1000);
	}

	LeaveCriticalSection(&pPdd->txCS);

	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWXmitComChar\n"));
	return TRUE;
}

//------------------------------------------------------------------------------
//  
// Function:     HWGetStatus
//
// Description:  This function is called by the MDD to retrieve the contents
//               of a COMSTAT structure.
//

static ULONG HWGetStatus(PVOID pContext, COMSTAT *pComStat)
{
	ULONG rc = -1;
	UARTPDD *pPdd = (UARTPDD*)pContext;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWGetStatus 0x%x\n", pContext));

	if (pComStat == NULL) goto cleanUp;

	pComStat->fCtsHold = pPdd->flowOffCTS ? 1 : 0;
	pComStat->fDsrHold = pPdd->flowOffDSR ? 1 : 0;
	pComStat->cbInQue  = 0;
	pComStat->cbOutQue = 0;

	rc = pPdd->commErrors;
	pPdd->commErrors = 0;

cleanUp:
	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWGetStatus %d\n", rc));
	return rc;
}

//------------------------------------------------------------------------------

static VOID HWGetCommProperties(PVOID pContext, COMMPROP *pCommProp)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWGetCommProper 0x%x\n", pContext));

	memset(pCommProp, 0, sizeof(COMMPROP));
	pCommProp->wPacketLength = 0xffff;
	pCommProp->wPacketVersion = 0xffff;
	pCommProp->dwServiceMask = SP_SERIALCOMM;
	pCommProp->dwMaxTxQueue = 16;
	pCommProp->dwMaxRxQueue = 16;
	pCommProp->dwMaxBaud = BAUD_USER;
	pCommProp->dwProvSubType = PST_RS232;

	pCommProp->dwProvCapabilities = PCF_DTRDSR | PCF_INTTIMEOUTS | PCF_PARITY_CHECK | PCF_RLSD | 
	                                PCF_RTSCTS | PCF_SETXCHAR | PCF_SPECIALCHARS | 
	                                PCF_TOTALTIMEOUTS | PCF_XONXOFF;

	pCommProp->dwSettableParams = SP_BAUD | SP_DATABITS | SP_HANDSHAKING | SP_PARITY |
	                              SP_PARITY_CHECK | SP_RLSD | SP_STOPBITS;

	pCommProp->dwSettableBaud = BAUD_075 | BAUD_110 | BAUD_150 | BAUD_300 | BAUD_600 | BAUD_1200 | 
	                            BAUD_1800 | BAUD_2400 | BAUD_4800 | BAUD_7200 | BAUD_9600 | BAUD_14400 |
	                            BAUD_19200 | BAUD_38400 | BAUD_57600 | BAUD_115200;

	pCommProp->wSettableData = DATABITS_5 | DATABITS_6 | DATABITS_7 | DATABITS_8;

	pCommProp->wSettableStopParity = STOPBITS_10 | STOPBITS_20 |
	                                 PARITY_NONE | PARITY_ODD | PARITY_EVEN | PARITY_SPACE |
	                                 PARITY_MARK;

	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWGetCommProper\n"));
}

//------------------------------------------------------------------------------
//
// Function:     HWPurgeComm
//
// Description:  This function purges RX and/or TX
// 

static VOID HWPurgeComm(PVOID pContext, DWORD action)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;
	UCHAR fifoCtrl;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWPurgeComm 0x%x 0x%x\n", pContext, action));

	EnterCriticalSection(&pPdd->hwCS);
	fifoCtrl = INP32(&pPdd->pPortBase->fifoctrl);
	if ((action & PURGE_TXCLEAR) != 0) fifoCtrl |= UART_FIFOCTRL_TR;
	if ((action & PURGE_RXCLEAR) != 0) fifoCtrl |= UART_FIFOCTRL_RR;
	OUT32(&pPdd->pPortBase->fifoctrl, fifoCtrl);
	LeaveCriticalSection(&pPdd->hwCS);

	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWPurgeComm\n"));
}

//------------------------------------------------------------------------------
//
// Function:     HWSetDCB
//
// Description:  This function sets new values for DCB. It gets a DCB from
//               the MDD and compare it to the current DCB, and if any fields
//               have changed take appropriate action.
//

static BOOL HWSetDCB(PVOID pContext, DCB *pDCB)
{
	UARTPDD *pPdd = (UARTPDD*)pContext;
	BOOL ok = FALSE;

	DEBUGMSG(ZONE_FUNCTION, (L"+au1uart::HWSetDCB 0x%x\n", pContext));

	// If the device is open, scan for changes and do whatever
	// is needed for the changed fields.  if the device isn't
	// open yet, just save the DCB for later use by the open.
	if (pPdd->open) {

		if (pDCB->BaudRate != pPdd->dcb.BaudRate) {
			if (!SetBaudRate(pPdd, pDCB->BaudRate)) goto cleanUp;
		}

		if (pDCB->ByteSize != pPdd->dcb.ByteSize) {
			if (!SetWordLength(pPdd, pDCB->ByteSize)) goto cleanUp;
		}

		if (pDCB->Parity != pPdd->dcb.Parity) {
			if (!SetParity(pPdd, pDCB->Parity)) goto cleanUp;
		}

		if (pDCB->StopBits != pPdd->dcb.StopBits) {
			if (!SetStopBits(pPdd, pDCB->StopBits)) goto cleanUp;
		}
	}

	// Now that we have done the right thing, store this DCB
	pPdd->dcb = *pDCB;

	// All is fine
	ok = TRUE;

cleanUp:
	DEBUGMSG(ZONE_FUNCTION, (L"-au1uart::HWSetDCB %s\n", ok?L"TRUE":L"FALSE"));
	return ok;
}

//------------------------------------------------------------------------------
//
// Function:     HWSetCommTimeouts
//
// Description:  This function sets new values for the CommTimeouts structure.
//               For 16550 like chip there is nothing to do...
// 

static ULONG HWSetCommTimeouts(PVOID pContext, COMMTIMEOUTS *pCommTimeouts)
{
	return 0;
}

//------------------------------------------------------------------------------
//
// Function:     HWIOCtl
//
// Description:  This function process PDD IOCtl calls (none at moment)
//

static BOOL HWIOCtl(
	PVOID pContext, DWORD code, UCHAR *pInpBuffer, DWORD inpSize,
	UCHAR *pOutBuffer, DWORD outSize, DWORD *pOutSize
) {
	return FALSE;
}

//------------------------------------------------------------------------------


//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
#ifndef __PDD_H
#define __PDD_H

//------------------------------------------------------------------------------

static PVOID HWInit(ULONG context, PVOID pMdd, PHWOBJ pHWObj);
static BOOL  HWPostInit(PVOID pContext);
static BOOL  HWDeinit(PVOID pContext);
static BOOL  HWOpen(PVOID pContext);
static ULONG HWClose(PVOID pContext);
static INTERRUPT_TYPE HWGetInterruptType(PVOID pContext);
static ULONG HWRxIntr(PVOID pContext, PUCHAR pRxBuffer, ULONG *pLength);
static VOID  HWTxIntr(PVOID pContext, PUCHAR pTxBuffer, ULONG *pLength);
static VOID  HWModemIntr(PVOID pContext);
static VOID  HWLineIntr(PVOID pContext);
static ULONG HWGetRxBufferSize(PVOID pContext);
static BOOL  HWPowerOff(PVOID pContext);
static BOOL  HWPowerOn(PVOID pContext);
static VOID  HWClearDTR(PVOID pContext);
static VOID  HWSetDTR(PVOID pContext);
static VOID  HWClearRTS(PVOID pContext);
static VOID  HWSetRTS(PVOID pContext);
static BOOL  HWEnableIR(PVOID pContext, ULONG baudRate);
static BOOL  HWDisableIR(PVOID pContext);
static VOID  HWClearBreak(PVOID pContext);
static VOID  HWSetBreak(PVOID pContext);
static VOID  HWReset(PVOID pContext);
static VOID  HWGetModemStatus(PVOID pContext, ULONG *pModemStat);
static BOOL  HWXmitComChar(PVOID pContext, UCHAR ch);
static ULONG HWGetStatus(PVOID pContext, COMSTAT *pComStat);
static VOID  HWGetCommProperties(PVOID pContext, COMMPROP *pCommProp);
static VOID  HWPurgeComm(PVOID pContext, DWORD action);
static BOOL  HWSetDCB(PVOID pContext, DCB *pDCB);
static ULONG HWSetCommTimeouts(PVOID pContext, COMMTIMEOUTS *pCommTimeouts);
static BOOL HWIOCtl(
   PVOID pContext, DWORD code, UCHAR *pInpBuffer, DWORD inpSize,
   UCHAR *pOutBuffer, DWORD outSize, DWORD *pOutSize
);

#endif

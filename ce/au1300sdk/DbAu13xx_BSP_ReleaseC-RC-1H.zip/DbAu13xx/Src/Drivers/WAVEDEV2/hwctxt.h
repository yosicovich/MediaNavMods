//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
#pragma once
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.


Module Name:    HWCTXT.H

Abstract:               Platform dependent code for the mixing audio driver.

-*/


//#include <oalintr.h>
#include <ceddk.h>
#include <ddkreg.h>



#ifdef BSP_WAVEDEV2_AC97
#include "AC97.h"
typedef AC97_HW CODEC_HW;
#endif

#ifdef BSP_WAVEDEV2_I2S
#include "I2S.h"
typedef I2S_HW CODEC_HW;
#endif

// Sample rates
#define SAMPLERATE_8000HZ      8000
#define SAMPLERATE_11025HZ     11025
#define SAMPLERATE_16000HZ     16000
#define SAMPLERATE_22050HZ     22050
#define SAMPLERATE_32000HZ     32000
#define SAMPLERATE_44100HZ     44100
#define SAMPLERATE_48000HZ     48000
#define SAMPLERATE_88200HZ	   88200
#define SAMPLERATE_96000HZ     96000

#define OUTPUT_SAMPLERATE  (SAMPLERATE_48000HZ)
#define INPUT_SAMPLERATE   (SAMPLERATE_48000HZ)

#define DMA_RX 1
#define DMA_TX 2

// 4k single page size per buffer
#define AUDIO_DMA_BUFFER_SIZE   0x2000
#define AUDIO_DMA_NUMBER_PAGES  2

#define AUDIO_DMA_PAGE_SIZE (AUDIO_DMA_BUFFER_SIZE/AUDIO_DMA_NUMBER_PAGES)

class HardwareContext
{
public:
    static BOOL CreateHWContext(DWORD Index);
    HardwareContext();
    ~HardwareContext();

    void Lock()   {EnterCriticalSection(&m_Lock);}
    void Unlock() {LeaveCriticalSection(&m_Lock);}

    DWORD GetNumInputDevices()  {return 1;}
    DWORD GetNumOutputDevices() {return 1;}
    DWORD GetNumMixerDevices()  {return 1;}

    DeviceContext *GetInputDeviceContext(UINT DeviceId)
    {
        return &m_InputDeviceContext;
    }

    DeviceContext *GetOutputDeviceContext(UINT DeviceId)
    {
        return &m_OutputDeviceContext;
    }

    BOOL Init(DWORD Index);
    BOOL Deinit();

    void PowerUp();
    void PowerDown();

    BOOL StartInputDMA();
    BOOL StartOutputDMA();

    void StopInputDMA();
    void StopOutputDMA();

    void InterruptThread();

    DWORD ForceSpeaker (BOOL bSpeaker);

    BOOL PmControlMessage (
                      DWORD  dwCode,
                      PBYTE  pBufIn,
                      DWORD  dwLenIn,
                      PBYTE  pBufOut,
                      DWORD  dwLenOut,
                      PDWORD pdwActualOut);

	BOOL IsInputStreamOpen() { return m_InputDeviceContext.IsStreamOpen(); }
	BOOL IsOutputStreamOpen() { return m_OutputDeviceContext.IsStreamOpen(); }

protected:

    BOOL InitInterruptThread();

    ULONG TransferInputBuffer();
    ULONG TransferOutputBuffer();

    DWORD GetInterruptThreadPriority()
    {
        return GetDriverRegValue(TEXT("Priority256"),150);
    }

    DWORD m_DriverIndex;
    CRITICAL_SECTION m_Lock;

    BOOL m_Initialized;
    BOOL m_InPowerHandler;

    InputDeviceContext  m_InputDeviceContext;
    OutputDeviceContext m_OutputDeviceContext;

    // Which DMA channels are running
    BOOL m_InputDMARunning;
    BOOL m_OutputDMARunning;

    LONG m_NumForcedSpeaker;
    void SetSpeakerEnable(BOOL bEnable);
    void RecalcSpeakerEnable();

    CEDEVICE_POWER_STATE m_DxState;

// S/PDIF support
public:
	ULONG SetDACSampleRate(ULONG hertz);
	ULONG SetADCSampleRate(ULONG hertz);
    BOOL GetSpdifEnable() {return m_bEnableSpdif;}
    void SetSpdifEnable(BOOL bEnable)
    {
        if (bEnable!=m_bEnableSpdif)
        {
            m_bEnableSpdif=bEnable;
            SetDriverRegValue(TEXT("EnableSpdif"),(DWORD)bEnable);
        }
    }
protected:
    BOOL m_bEnableSpdif;

// WmaPro-over-S/PDIF support
public:
    BOOL GetSpdifEnableWmaPro() {return m_bEnableSpdifWmaPro;}
    void SetSpdifEnableWmaPro(BOOL bEnable)
    {
        m_bEnableSpdifWmaPro = bEnable;
        SetDriverRegValue(TEXT("EnableSpdifWmaPro"),(DWORD)bEnable);
    }
protected:
    BOOL m_bEnableSpdifWmaPro;

// Used to turn on/off SPDIF digital bit when we're playing back encoded data
public:
    void SetSPDIFCompression(BOOL bOn)
    {
        if (m_bSpdifCompression!=bOn)
        {
            m_bSpdifCompression = bOn;
        }
    }

protected:
    BOOL  m_bSpdifCompression;

public:
    DWORD GetDriverRegValue(LPWSTR ValueName, DWORD DefaultValue);
    void SetDriverRegValue(LPWSTR ValueName, DWORD Value);
	DWORD ReadMixerRegValue(LPWSTR ValueName, DWORD DefaultValue);

// Gain-related APIs
public:
    DWORD       GetOutputGain (void);
    MMRESULT    SetOutputGain (DWORD dwVolume);
    DWORD       GetInputGain (void);
    MMRESULT    SetInputGain (DWORD dwVolume);

    BOOL        GetOutputMute (void);
    MMRESULT    SetOutputMute (BOOL fMute);
    BOOL        GetInputMute (void);
    MMRESULT    SetInputMute (BOOL fMute);

protected:
    void UpdateOutputGain();
    void UpdateInputGain();
    DWORD m_dwOutputGain;
    DWORD m_dwInputGain;
    BOOL  m_fInputMute;
    BOOL  m_fOutputMute;

public:
    BOOL IsSupportedOutputFormat(LPWAVEFORMATEX lpFormat);

protected:
    DWORD m_IntrAudio;

    HANDLE m_IsrHandle;

    HANDLE m_hAudioInterrupt;          // Handle to Audio Interrupt event.
    HANDLE m_hAudioInterruptThread;    // Handle to thread which waits on an audio interrupt event.

    DWORD    m_dwBusNumber;
    INTERFACE_TYPE m_IfcType;

    ULONG m_nVolume;        // Current HW Playback Volume

    CODEC_HW m_Au1xAudio;
};

void CallInterruptThread(HardwareContext *pHWContext);

extern HardwareContext *g_pHWContext;



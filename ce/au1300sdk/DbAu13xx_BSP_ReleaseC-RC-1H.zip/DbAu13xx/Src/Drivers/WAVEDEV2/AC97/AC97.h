#ifndef _AC97_H_
#define _AC97_H_
#include <windows.h>
#include <wavedbg.h>
#include "platform.h"
#include "bceddk.h"

//
// Defines
//
#define AUDIO_REGKEY    (TEXT("Drivers\\BuiltIn\\WaveDev"))
#define AC97_DEFAULT_MICVOLUME      (0x8008)
#define DEFAULT_PCM_VOLUME 0


#define TIMEOUT     200

//
// AC97 Controller registers
// 
//
#define AC97_RESET                   	    0x00
#define AC97_MASTER_VOLUME           	    0x02
#define AC97_ALT_LINE_LEVEL_OUT_VOLUME      0x04
#define AC97_MASTER_VOLUME_MONO      	    0x06
#define AC97_PC_BEEP_VOLUME          	    0x0a
#define AC97_PHONE_VOLUME            	    0x0c
#define AC97_MIC_VOLUME              	    0x0e
#define AC97_LINE_IN_VOLUME          	    0x10
#define AC97_CD_VOLUME               	    0x12
#define AC97_VIDEO_VOLUME            	    0x14
#define AC97_AUX_VOLUME              	    0x16
#define AC97_PCM_OUT_VOLUME          	    0x18
#define AC97_RECORD_SELECT           	    0x1a
#define AC97_RECORD_GAIN             	    0x1c
#define AC97_GENERAL_PURPOSE         	    0x20
#define AC97_THREE_D_CONTROL         	    0x22
#define AC97_POWER_CONTROL           	    0x26
#define AC97_EXTENDED_AUDIO_ID           	0x28
#define AC97_EXTENDED_AUDIO_STATUS_CONTROL  0x2a
#define AC97_PCM_FRONT_DAC_RATE	            0x2c
#define AC97_PCM_ADC_RATE		            0x32
#define AC97_SERIAL_CONFIGURATION    	    0x74
#define AC97_MISC_CONTROL            	    0x76
#define AC97_SAMPLE_RATE_0           	    0x78
#define AC97_SAMPLE_RATE_1           	    0x7a
#define AC97_VENDOR_ID1              	    0x7c
#define AC97_VENDOR_ID2              	    0x7e

//
// Define the individual bits in the indexed control registers.  The full set is not
// defined here, only the ones which are of interest in this driver
//
//
// MASTER_VOLUME register bits
//

#define VOLUME_MUTE             0x8000  // 1 - mutes both channels
#define VOLUME_RIGHT_MASK       0x001f  // D4:0 are right volume control
#define VOLUME_RIGHT_SHIFT      0
#define VOLUME_LEFT_MASK        0x1f00  // D12:8 are left volume control
#define VOLUME_LEFT_SHIFT       8

//
//  General purpose reg
//
#define GP_LPBK                 0x0080
#define GP_MS                   0x0100
#define GP_MIX                  0x0200
#define GP_3D                   0x2000


///
// POWER_CONTROL/STATUS register bits.  These subsections reside upon the CODEC
// Generally, setting a 1 powers down the subsection, 0 powers it up.
//

#define ADC                     0x0001  // RO - ADC section ready to xmit data
#define DAC                     0x0002  // RO - DAC section ready to accept data
#define ANL                     0x0004  // RO - analog gainuators,attenuators, mixers ready
#define REF                     0x0008  // RO - voltage references, vref, vrefout OK
#define PR0                     0x0100  // WO - 1 powers down ADC; 0 powers up
#define PR1                     0x0200  // WO - 1 powers down DAC; 0 powers up
#define PR2                     0x0400  // WO - 1 powers down analog mixer (VREF on); 0 powers up
#define PR3                     0x0800  // WO - 1 powers down analog mixer (VREF off); 0 powers up
#define PR4                     0x1000  // WO - 1 powers down AC-Link; 0 powers up
#define PR5                     0x2000  // WO - 1 powers down digital clock; 0 powers up
#define PR6                     0x4000  // WO - 1 powers down headphone amp; 0 powers up

//
// SERIAL_CONFIGURATION register bits
//

#define DRRQ0                   0x0001  // master AC 97 codec DAC right request
#define DRRQ1                   0x0002  // slave 1 codec DAC right request
#define DRRQ2                   0x0004  // slave 2 codec DAC right request
#define DLRQ0                   0x0100  // master AC 97 codec DAC left request
#define DLRQ1                   0x0200  // slave 1 codec DAC left request
#define DLRQ2                   0x0400  // slave 2 codec DAC left request
#define DRQEN                   0x0800  // fills idle slots wit DAC read requests
#define REGM0                   0x1000  // master CODEC register mask
#define REGM1                   0x2000  // slave 1 codec register mask
#define REGM2                   0x4000  // slave 2 codec register mask
#define SLOT16                  0x8000  // enable 16-bit slots

//
// MISC_CONTROL register bits
//

#define ARSR                    0x0001  // ADC right sample generator select 0=SR0, 1=SR1
#define DRSR                    0x0004  // DAC right sample generator select 0=SR0, 1=SR1
#define SRX8D7                  0x0020  // multiply SR1 rate by 8/7
#define SRX10D7                 0x0040  // multiply SR1 rate by 10/7
#define MODEN                   0x0080  // modem filter enable
#define ALSR                    0x0100  // ADC left sample generator select 0=SR0, 1=SR1
#define DLSR                    0x0400  // DAC left sample generator select 0=SR0, 1=SR1
#define DACZ                    0x8000  // zero fill (vs. repeat sample) if DAC is starved

//
// Interrupt sources
//

#define AUDIO_IN_INTERRUPT 0x01
#define AUDIO_OUT_INTERRUPT 0x02

//
// Macros
//
#if (_WINCEOSVER < 600)
#define STALLEXECUTION(x) HalStallExecution(x)
#else
#define	STALLEXECUTION(x) OALStallExecution(x)
#endif

//
// Externs
//


//
// Data Structures
//


class AC97_HW
{
public:
	//
	// Function prototypes
	//
	BOOL InitializePlatform();
	BOOL DeInitializePlatform();
	DWORD FindMicVolume();
	BOOL InitializeRegisters(PSC_AC97 *pAC);
	BOOL InitializeIntr(DWORD *pIntrAudio);
	BOOL InitializeDMA();
	VOID StartDma(UCHAR ucDMAChannel);
	VOID StopDma(UCHAR ucDMAChannel);
	void SetDMABufferSize(DWORD BufferSize) {m_DmaBufferSize = BufferSize;}
	DWORD GetDMABufferSize() {return m_DmaBufferSize;}
	BOOL InitializeCodec();
	PBYTE GetNextDMABuffer(UCHAR ucDMAChannel);
	BOOL SendDMABuffer(UCHAR ucDMAChannel, PBYTE pBufferStart, ULONG BytesTransferred);
	UCHAR GetInterruptSrc();
	BOOL CodecPowerUp();
	BOOL CodecPowerDown();
	ULONG SetADCSampleRate(ULONG Hertz);
	ULONG SetDACSampleRate(ULONG Hertz);

	
	UINT32					m_MinDACSampleRate;
	UINT32					m_MinADCSampleRate;



private:	
	// 
	// Member variables
	//
	DWORD					m_MicVolume;
	PDMA_CHANNEL_OBJECT     m_DMAChannelInput;
	PDMA_CHANNEL_OBJECT     m_DMAChannelOutput;
	DWORD					m_DmaBufferSize;
};

//
//	Function prototypes
//
BOOL AC97SetPCMOutVolume(IN ULONG LVol, IN ULONG RVol);


#endif //_AC97_H_
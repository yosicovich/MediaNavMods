extern "C"
{
#include <windows.h>
#include <platform.h>
#include <bceddk.h>
#ifndef SOC_AU13XX
 #include <gpio.h>
#endif

}
#include "wavemain.h"
#include "AC97.h"
#include "aclink.h"



BOOL AC97_HW::InitializePlatform()
{
	BOOL             status = TRUE;

	// find a Mic Volume
	FindMicVolume();

	InitializeACLink(FALSE, DEV_AUDIO);

	DEBUGMSG(1, (TEXT("AC97: Configure ACLink\r\n")));
	ConfigureAC97Control();

	DEBUGMSG(ZONE_FUNCTION,(L"-Initialize Platform\r\n"));
    return status;
}

BOOL AC97_HW::DeInitializePlatform()
{
	BOOL             status = TRUE;
	
	DeInitializeACLink(FALSE, DEV_AUDIO);

	UnConfigureAC97Control();

	DEBUGMSG(ZONE_FUNCTION,(L"-DeInitialize Platform\r\n"));
    return status;
}


DWORD AC97_HW::FindMicVolume()
{
    HKEY    hkey;
    LONG	Status;
    DWORD	Size = sizeof(m_MicVolume);

	m_MicVolume = AC97_DEFAULT_MICVOLUME;

	// Examine Mic Volume in registry
    //
    Status = RegOpenKeyEx(
        HKEY_LOCAL_MACHINE,
        AUDIO_REGKEY,
        0,
        0,
        &hkey);


    if (ERROR_SUCCESS == Status) {
        Status = RegQueryValueEx(hkey,
                                (TEXT("MicVolume")),
                                NULL,
                                NULL,
                                (PUCHAR)&m_MicVolume,
                                &Size
                                );
    }

    if (hkey) {
        RegCloseKey(hkey);
    }

	return m_MicVolume;

}



BOOL AC97_HW::InitializeIntr(DWORD *pIntrAudio)
{
	ULONG HwIntr;

    DEBUGMSG(ZONE_FUNCTION,(L"+Initialize Interrupt\r\n"));

    HwIntr = HalGetDMAHwIntr(m_DMAChannelOutput);
	HwIntr |= HalGetDMAHwIntr(m_DMAChannelInput) << 8;

	*pIntrAudio = InterruptConnect(Internal, 0, HwIntr, 0);

    if (*pIntrAudio == SYSINTR_NOP)
    {
        RETAILMSG(1,(L"Can not allocate SYSINTR\r\n"));
        goto ErrorReturn;
    }

    DEBUGMSG(ZONE_FUNCTION,(L"-Initialize Interrupt\r\n"));
    return TRUE;
  ErrorReturn:
    DEBUGMSG(ZONE_FUNCTION,(L"-Initialize Interrupt failed\r\n"));
    return FALSE;
}



BOOL AC97_HW::InitializeDMA()
{
    DEBUGMSG(ZONE_FUNCTION,(L"+InitializeDMA\r\n"));

    m_DMAChannelOutput = HalAllocateDMAChannel();

    if(m_DMAChannelOutput==NULL) {
        DEBUGMSG(ZONE_ERROR,(L"Can not allocate output DMA Channel\r\n"));
        goto ErrorReturn;
    }
    else {
        DEBUGMSG(ZONE_MISC,(L"Using DMA channel for AC97 output\r\n"));
    }

    HalInitDmaChannel(m_DMAChannelOutput,
	                  DMA_AC97_TX,
	                  m_DmaBufferSize,
					  TRUE);

    m_DMAChannelInput = HalAllocateDMAChannel();

    if(m_DMAChannelInput==NULL) {
        DEBUGMSG(ZONE_ERROR,(L"Can not allocate input DMA Channel\r\n"));
        goto ErrorReturn;
    }
    else {
        DEBUGMSG(ZONE_MISC,(L"Using DMA channel for AC97 input\r\n"));
    }

    HalInitDmaChannel(m_DMAChannelInput,
	                  DMA_AC97_RX,
	                  m_DmaBufferSize,
					  TRUE);

    DEBUGMSG(ZONE_FUNCTION,(L"-InitializeDMA\r\n"));
    return TRUE;

ErrorReturn:

    DEBUGMSG(ZONE_FUNCTION,(L"-InitializeDMA failed\r\n"));
    return FALSE;
}


VOID
AC97_HW::StartDma(UCHAR ucDMAChannel)
{
    DEBUGMSG(ZONE_FUNCTION, (TEXT("+AC97_HW: StartDma ")));

	switch ( ucDMAChannel )
	{
		case DMA_RX:
			HalSetDMAForReceive(m_DMAChannelInput);
			StartAC97Rx();
			HalStartDMA(m_DMAChannelInput);
			break;
		case DMA_TX:
			StartAC97Tx();
			HalStartDMA(m_DMAChannelOutput);
			break;
		default:
			DEBUGMSG(ZONE_ERROR, (TEXT("AC97_HW: StartDma failed ")));
			return;
	}

    DEBUGMSG(ZONE_FUNCTION, (TEXT("-AC97_HW: StartDma ")));

	return;

}

VOID
AC97_HW::StopDma(UCHAR ucDMAChannel)
{
    DEBUGMSG(ZONE_FUNCTION, (TEXT("+AC97_HW: StopDma ")));



	switch ( ucDMAChannel )
	{
		case DMA_RX:
			HalStopDMA(m_DMAChannelInput);
			StopAC97Rx();
			break;
		case DMA_TX:
			HalStopDMA(m_DMAChannelOutput);
			StopAC97Tx();
			break;
		default:
			DEBUGMSG(ZONE_ERROR, (TEXT("AC97_HW: StopDma failed ")));
			return;
	}

    DEBUGMSG(ZONE_FUNCTION, (TEXT("-AC97_HW: StopDma ")));

	return;

}



BOOL AC97_HW::InitializeCodec()
{
    //
    // Set True Stereo Line Out as 0dB
    //
	if(WriteAC97(AC97_ALT_LINE_LEVEL_OUT_VOLUME, 0, DEV_AUDIO) == FALSE)
	{
		RETAILMSG(1, (TEXT("Wavedev2: Failed to set alt line level out volume\r\n")));
	}
	if(WriteAC97(AC97_RECORD_GAIN, 0x0f0f, DEV_AUDIO) == FALSE)
	{
		RETAILMSG(1, (TEXT("Wavedev2: Failed to set record gain\r\n")));
	}

	// Set Mic Volume
    //
	if(WriteAC97(AC97_MIC_VOLUME, (UINT16)m_MicVolume, DEV_AUDIO) == FALSE)
	{
		RETAILMSG(1, (TEXT("Wavedev2: Failed to set mic volume\r\n")));
	}

    //  Set PCM channel to default
    //
    AC97SetPCMOutVolume(DEFAULT_PCM_VOLUME,   DEFAULT_PCM_VOLUME);

    return TRUE;
}


PBYTE AC97_HW::GetNextDMABuffer(UCHAR ucDMAChannel)
{
    DEBUGMSG(ZONE_FUNCTION, (TEXT("+AC97_HW: GetNextDMABuffer ")));
	PVOID pNextDMABuffer;

	switch ( ucDMAChannel )
	{
		case DMA_RX:
			 pNextDMABuffer = HalGetNextDMABuffer(m_DMAChannelInput);
			break;
		case DMA_TX:
			 pNextDMABuffer = HalGetNextDMABuffer(m_DMAChannelOutput);
			break;
		default:
			DEBUGMSG(ZONE_ERROR, (TEXT("AC97_HW: GetNextDMABuffer failed.  Invalid Channel. ")));
			 pNextDMABuffer = NULL;
	}

    DEBUGMSG(ZONE_FUNCTION, (TEXT("-AC97_HW: GetNextDMABuffer ")));

	return (PBYTE)pNextDMABuffer;
}

BOOL AC97_HW::SendDMABuffer(UCHAR ucDMAChannel, PBYTE pBufferStart, ULONG BytesTransferred)
{
    DEBUGMSG(ZONE_FUNCTION, (TEXT("+AC97_HW: SendDMABuffer ")));
	BOOL retVal;

	switch ( ucDMAChannel )
	{
		case DMA_RX:
			 retVal = HalActivateDMABuffer(m_DMAChannelInput, pBufferStart, BytesTransferred);
			break;
		case DMA_TX:
			 retVal = HalActivateDMABuffer(m_DMAChannelOutput, pBufferStart, BytesTransferred);
			break;
		default:
			DEBUGMSG(ZONE_ERROR, (TEXT("AC97_HW: SendDMABuffer failed.  Invalid Channel. ")));
			 retVal = FALSE;
	}

    DEBUGMSG(ZONE_FUNCTION, (TEXT("-AC97_HW: SendDMABuffer ")));

	return retVal;
}


UCHAR AC97_HW::GetInterruptSrc()
{
	UCHAR src = 0;
	ULONG Mask;

	// Check the input channel for interrupts
	Mask = HalCheckForDMAInterrupt(m_DMAChannelInput);
	if( Mask )
	{
		// Got a DMA interrupt for audio in
		src |= AUDIO_IN_INTERRUPT;
		HalAckDMAInterrupt(m_DMAChannelInput,Mask);
	}

	// Check the output channel for interrupts
	Mask = HalCheckForDMAInterrupt(m_DMAChannelOutput);
	if( Mask )
	{
		// Got a DMA interrupt for audio out
		src |= AUDIO_OUT_INTERRUPT;
		HalAckDMAInterrupt(m_DMAChannelOutput,Mask);
	}

	return src;
}



BOOL AC97_HW::CodecPowerDown()
{
	BOOL Status = FALSE;
	UINT16 Value = 0;

	//
	// The Codec must be powered down with sequential writes
	// to the Powerdown Ctrl/Stat Register.

	// Power down ADC.
	Value = PR0;
	Status = WriteAC97(AC97_POWER_CONTROL, Value, DEV_AUDIO);
	if (!Status)
		goto ErrorReturn;

	// Power down DAC.
	Value |= PR1;
	Status = WriteAC97(AC97_POWER_CONTROL, Value, DEV_AUDIO);
	if (!Status)
		goto ErrorReturn;

	// Power down analog mixer (VREF on).
	Value |= PR2;
	Status = WriteAC97(AC97_POWER_CONTROL, Value, DEV_AUDIO);
	if (!Status)
		goto ErrorReturn;

	// Power down digital clk.
	Value |= PR5;
	Status = WriteAC97(AC97_POWER_CONTROL, Value, DEV_AUDIO);
	if (!Status)
		goto ErrorReturn;

	// Power down headphone amp.
	Value |= PR6;
	Status = WriteAC97(AC97_POWER_CONTROL, Value, DEV_AUDIO);
	if (!Status)
		goto ErrorReturn;

	UnConfigureAC97Control();

ErrorReturn:
	return Status;
}


BOOL AC97_HW::CodecPowerUp()
{
	BOOL Status = FALSE;

	DEBUGMSG(1, (TEXT("+PowerUp AC97\r\n")));

	DEBUGMSG(1, (TEXT("AC97: Configure ACLink\r\n")));
	ConfigureAC97Control();

	DEBUGMSG(1, (TEXT("AC97: Initialize Codec\r\n")));
	InitializeCodec();

	return Status;
}


ULONG AC97_HW::SetADCSampleRate(ULONG Rate)
{
    UINT16 CurrentRate = (UINT16)Rate;
    BOOL Status = FALSE;

	if ( g_pHWContext->IsInputStreamOpen() )
	{
		// There is either an input or output stream open, so we can't change the rate
		return 0;
	}

	if (m_MinADCSampleRate > Rate)
		Rate = m_MinADCSampleRate;

	switch (Rate)
	{
	case SAMPLERATE_8000HZ:      //8000
		RETAILMSG(1, (TEXT("SAMPLERATE_8000HZ \r\n")));
		break;
	case SAMPLERATE_11025HZ:     //11025
		RETAILMSG(1, (TEXT("SAMPLERATE_11025HZ \r\n")));
		break;
	case SAMPLERATE_16000HZ:     //16000
		RETAILMSG(1, (TEXT("SAMPLERATE_16000HZ \r\n")));
		break;
	case SAMPLERATE_22050HZ:     //22050
		RETAILMSG(1, (TEXT("SAMPLERATE_22050HZ \r\n")));
		break;
	case SAMPLERATE_32000HZ:     //32000
		RETAILMSG(1, (TEXT("SAMPLERATE_32000HZ \r\n")));
		break;
	case SAMPLERATE_44100HZ:     //44100
		RETAILMSG(1, (TEXT("SAMPLERATE_44100HZ \r\n")));
		break;
	case SAMPLERATE_48000HZ:     //48000
		RETAILMSG(1, (TEXT("SAMPLERATE_48000HZ \r\n")));
		break;
		break;
	default:
		DEBUGMSG(1,(L"CODEC: Rate not supported\r\n"));
		// Use the default rate
		CurrentRate = INPUT_SAMPLERATE;
		break;
	}

	Status = WriteAC97(AC97_EXTENDED_AUDIO_STATUS_CONTROL, 1, DEV_AUDIO);
   

    if (Status) {
		Status = WriteAC97(AC97_PCM_ADC_RATE, CurrentRate, DEV_AUDIO);
    }

    return CurrentRate;
}

ULONG AC97_HW::SetDACSampleRate(ULONG Rate)
{
    UINT16 CurrentRate = (UINT16)Rate;
    BOOL Status = FALSE;

	if ( g_pHWContext->IsOutputStreamOpen() )
	{
		// There is either an input or output stream open, so we can't change the rate
		return 0;
	}

	if (m_MinDACSampleRate > Rate)
	{
		Rate = m_MinDACSampleRate;
	}

	switch (Rate)
	{
	case SAMPLERATE_8000HZ:      //8000
	case SAMPLERATE_11025HZ:     //11025
	case SAMPLERATE_16000HZ:     //16000
	case SAMPLERATE_22050HZ:     //22050
	case SAMPLERATE_32000HZ:     //32000
	case SAMPLERATE_44100HZ:     //44100
	case SAMPLERATE_48000HZ:     //48000
		break;
	default:
		DEBUGMSG(1,(L"CODEC: Rate not supported\r\n"));
		// Use the default rate
		CurrentRate = OUTPUT_SAMPLERATE;
		break;
	}

	Status = WriteAC97(AC97_EXTENDED_AUDIO_STATUS_CONTROL, 1, DEV_AUDIO);

    if (Status) {
		Status = WriteAC97(AC97_PCM_FRONT_DAC_RATE, CurrentRate, DEV_AUDIO);
    }

    return CurrentRate;
}



///////////////////////////////////////////////////////////////////////////////
// Helper Functions
///////////////////////////////////////////////////////////////////////////////

//
//   Set master volume - will overwrite MUTE
//
BOOL
AC97SetPCMOutVolume(
    IN ULONG    LVol,
    IN ULONG    RVol

    )
{
    BOOL    Status;
    ULONG	Data;


    Data = ((LVol << VOLUME_LEFT_SHIFT) & VOLUME_LEFT_MASK) |
        ((RVol << VOLUME_RIGHT_SHIFT) & VOLUME_RIGHT_MASK);

	Status = WriteAC97(AC97_PCM_OUT_VOLUME, (UINT16)Data, DEV_AUDIO);

    return Status;
}

extern "C"
{
#include <windows.h>
#include <platform.h>
#include <bceddk.h>
#include <bceddk.h>
#ifndef SOC_AU13XX
 #include <gpio.h>
#endif
#include <smbus.h>
}

#include "I2S.h"
#include "wavemain.h"

BOOL
SMBusWriteReg(
    IN HANDLE hSMBus,
    IN UCHAR  Reg,
    IN USHORT Value
    )
{
	static SMBUS_TRANSFER Transfer;

	Transfer.Address = SMBUS_ADDR_WM8731;
	Transfer.Data[0] = (Reg << 1) | ((Value & 0x100) >> 8);
	Transfer.Data[1] = Value & 0xFF;
	Transfer.DataSize = 2;

	return SMBus_WriteData(hSMBus, &Transfer);
}


BOOL
I2S_HW::InitializePlatform()
{
	PHYSICAL_ADDRESS PhyAdd;
	HANDLE           hGPIO = NULL;

	RETAILMSG(1,(L"Initializing PSC%d for I2S operation\r\n",PLATFORM_I2S_PSC));

#if (PLATFORM_I2S_PSC==0)
	PhyAdd.QuadPart = PSC0_PHYS_ADDR;
#elif (PLATFORM_I2S_PSC==1)
	PhyAdd.QuadPart = PSC1_PHYS_ADDR;
#elif (PLATFORM_I2S_PSC==2)
	PhyAdd.QuadPart = PSC2_PHYS_ADDR;
#elif (PLATFORM_I2S_PSC==3)
	PhyAdd.QuadPart = PSC3_PHYS_ADDR;
#else
#error PLATFORM_I2S_PSC must be defined in the range 0 to 3
#endif

	m_I2SCtrl = (PSC_I2S *)MmMapIoSpace(PhyAdd,
								    sizeof(*m_I2SCtrl),
								    FALSE);
	if(m_I2SCtrl==NULL) {
		DEBUGMSG(ZONE_ERROR,(L"Can not map I2S Control registers\r\n"));
		goto ErrorReturn;
	}

#ifndef SOC_AU13XX
    hGPIO = GPIO_Init();
    if(hGPIO==INVALID_HANDLE_VALUE) {
        DEBUGMSG(ZONE_ERROR,(L"I2S: Can not open GPIO device\r\n"));
        goto ErrorReturn;
    }
#endif

	// CPU dependent GPIO pin functionality
#if defined(CPU_AU1200) && (PLATFORM_I2S_PSC==0)
    if(!GPIO_ClearPinFunction(hGPIO,SYS_PINFUNC_P0A | SYS_PINFUNC_P0B)) {
        DEBUGMSG(ZONE_ERROR,(L"I2S: Can not set pinfunc for I2S\r\n"));
        goto ErrorReturn;
    }
#elif defined(CPU_AU1200) && (PLATFORM_I2S_PSC==1)
    if(!GPIO_ClearPinFunction(hGPIO,SYS_PINFUNC_P1A | SYS_PINFUNC_P1B)) {
        DEBUGMSG(ZONE_ERROR,(L"I2S: Can not set pinfunc for I2S\r\n"));
        goto ErrorReturn;
    }
#endif

	// Handle any platform specific initialization, GPIO handle available if needed
#if defined(PLATFORM_I2S_PSC_INIT_CODE)
	PLATFORM_I2S_PSC_INIT_CODE
#endif

	// we are done with GPIO now
	if (hGPIO)
		CloseHandle(hGPIO);

	// Get a handle to the SMBus
	m_hSMBus = SMBus_Initialize();

	InitializeCodec();

	// Now configure the PSC for I2S
	if (!InitializeRegisters())
	{
		RETAILMSG(1, (TEXT("I2S: Failed to initialize registers\r\n")));
		goto ErrorReturn;
	}

	DEBUGMSG(ZONE_FUNCTION,(L"-Initialize Platform\r\n"));
    return TRUE;


ErrorReturn:
	if(m_I2SCtrl) {
		MmUnmapIoSpace((PVOID)m_I2SCtrl, sizeof(*m_I2SCtrl));
	}

	if(m_hSMBus) {
		CloseHandle(m_hSMBus);
	}

	if(hGPIO) {
		CloseHandle(hGPIO);
	}

	DEBUGMSG(ZONE_FUNCTION,(L"-Initialize Platform failed\r\n"));
	return FALSE;
}

BOOL
I2S_HW::DeInitializePlatform()
{
	return TRUE;	
}

BOOL
I2S_HW::InitializeRegisters()
{
	ULONG timeout;
	BOOL  status = TRUE;

	// Reset and configure the PSC for I2S
	WRITE_REGISTER_ULONG((PULONG)&m_I2SCtrl->psc.sel, PSC_SEL_PS_I2S | PSC_SEL_CLK_SERIAL);

	// Enable the PSC
	WRITE_REGISTER_ULONG((PULONG)&m_I2SCtrl->psc.ctl, PSC_CTL_CE |PSC_CTL_EN);

	// wait for clock detect
	timeout = 1000;
	while (timeout && !(READ_REGISTER_ULONG((PULONG)&m_I2SCtrl->sts) & PSC_I2S_STS_SR)) {
		STALLEXECUTION(1000);
		timeout--;
	}

	if (!timeout) {
		RETAILMSG(1,(TEXT("Failed waiting for SR\r\n")));
		status = FALSE;
		goto ErrorReturn;
	}

	// Configure the PSC for 16bit, Slave to the Codec Master
	WRITE_REGISTER_ULONG((PULONG)&m_I2SCtrl->cfg,
									         PSC_I2S_CFG_BI |
									         PSC_I2S_CFG_XM |
									         PSC_I2S_CFG_LEN_N(15) |
									         PSC_I2S_CFG_TBS_N(3) |
									         PSC_I2S_CFG_RBS_N(3) |
									         PSC_I2S_CFG_DE |
											 PSC_I2S_CFG_MS );

	// mask all interrupts
	WRITE_REGISTER_ULONG((PULONG)&m_I2SCtrl->msk,0xffffffff);

	// wait unti the device is ready
	timeout = 50;
	while (timeout && !(READ_REGISTER_ULONG((PULONG)&m_I2SCtrl->sts) & PSC_I2S_STS_DR)) {
		STALLEXECUTION(1000);
		timeout--;
	}

	if (!timeout) {
		RETAILMSG(1,(TEXT("Failed waiting for DR\r\n")));
		status = FALSE;
		goto ErrorReturn;
	}

ErrorReturn:
	return status;
}

BOOL
I2S_HW::InitializeIntr(DWORD *pIntrAudio)
{
	ULONG HwIntr;

    DEBUGMSG(ZONE_FUNCTION,(L"+Initialize Interrupt\r\n"));

    HwIntr = HalGetDMAHwIntr(m_DMAChannelOutput);
	HwIntr |= HalGetDMAHwIntr(m_DMAChannelInput) << 8;

	*pIntrAudio = InterruptConnect(Internal, 0, HwIntr, 0);

	if (*pIntrAudio == SYSINTR_NOP)
	{
		RETAILMSG(1,(L"Can not allocate SYSINTR\r\n"));
		goto ErrorReturn;
	}

	DEBUGMSG(ZONE_FUNCTION,(L"-Initialize Interrupt\r\n"));
	return TRUE;
ErrorReturn:
	DEBUGMSG(ZONE_FUNCTION,(L"-Initialize Interrupt failed\r\n"));
	return FALSE;
}


BOOL
I2S_HW::InitializeDMA()
{
    DEBUGMSG(ZONE_FUNCTION,(L"+InitializeDMA\r\n"));

    m_DMAChannelOutput = HalAllocateDMAChannel();

    if(m_DMAChannelOutput==NULL) {
        DEBUGMSG(ZONE_ERROR,(L"Can not allocate output DMA Channel\r\n"));
        goto ErrorReturn;
    } else {
        DEBUGMSG(1,(L"Using DMA channel for I2S output\r\n"));
    }

    HalInitDmaChannel(m_DMAChannelOutput,
	                  DMA_I2S_TX,
	                  m_DmaBufferSize,
					  TRUE);

    m_DMAChannelInput = HalAllocateDMAChannel();

    if(m_DMAChannelInput==NULL) {
        DEBUGMSG(ZONE_ERROR,(L"Can not allocate input DMA Channel\r\n"));
        goto ErrorReturn;
    } else {
        DEBUGMSG(1,(L"Using DMA channel for I2S input\r\n"));
    }

    HalInitDmaChannel(m_DMAChannelInput,
	                  DMA_I2S_RX,
	                  m_DmaBufferSize,
					  TRUE);

    DEBUGMSG(ZONE_FUNCTION,(L"-InitializeDMA\r\n"));
    return TRUE;

  ErrorReturn:

    DEBUGMSG(ZONE_FUNCTION,(L"-InitializeDMA failed\r\n"));
    return FALSE;
}

VOID
I2S_HW::StartDma(UCHAR ucDMAChannel)
{
    DEBUGMSG(ZONE_FUNCTION, (TEXT("+I2S_HW: StartDma ")));

	switch ( ucDMAChannel )
	{
		case DMA_RX:
			HalSetDMAForReceive(m_DMAChannelInput);
			WRITE_REGISTER_ULONG((PULONG)&m_I2SCtrl->pcr, PSC_I2S_PCR_RS);
			HalStartDMA(m_DMAChannelInput);
			break;
		case DMA_TX:
			WRITE_REGISTER_ULONG((PULONG)&m_I2SCtrl->pcr, PSC_I2S_PCR_TS);
			HalStartDMA(m_DMAChannelOutput);
			break;
		default:
			DEBUGMSG(ZONE_ERROR, (TEXT("I2S_HW: StartDma failed ")));
			return;
	}

    DEBUGMSG(ZONE_FUNCTION, (TEXT("-I2S: StartDma ")));

	return;
}

VOID
I2S_HW::StopDma(UCHAR ucDMAChannel)
{
    DEBUGMSG(ZONE_FUNCTION, (TEXT("+I2S_HW: StopDma ")));

	switch ( ucDMAChannel )
	{
		case DMA_RX:
			HalStopDMA(m_DMAChannelInput);
			WRITE_REGISTER_ULONG((PULONG)&m_I2SCtrl->pcr, PSC_I2S_PCR_RS);
			break;
		case DMA_TX:
			HalStopDMA(m_DMAChannelOutput);
			WRITE_REGISTER_ULONG((PULONG)&m_I2SCtrl->pcr, PSC_I2S_PCR_TS);
			break;
		default:
			DEBUGMSG(ZONE_ERROR, (TEXT("I2S_HW: StopDma failed ")));
			return;
	}

    DEBUGMSG(ZONE_FUNCTION, (TEXT("-I2S_HW: StopDma ")));

	return;

}

BOOL
I2S_HW::InitializeCodec()
{
	// Reset external codec
	SMBusWriteReg(m_hSMBus, WM8731_RR, RR_RESET);
	// Configure external codec
	//
	SMBusWriteReg(m_hSMBus, WM8731_DAPC, 0 );

	// Configure for 44.1 DAC and ADC
	SMBusWriteReg(m_hSMBus, WM8731_SC, SC_SR_N(8) |
	                                             SC_BOSR |
												 SC_USB );

	// I2S format, 16bit, Codec is Master
	SMBusWriteReg(m_hSMBus, WM8731_DAIF, DAIF_FORMAT_I2S |
	                                               DAIF_IWL_16 |
												   DAIF_MS |
	                                               DAIF_LRSWAP );

	// Get ourselves a little Mic boost
	SMBusWriteReg(m_hSMBus, WM8731_AAPC, AAPC_INSEL | AAPC_MICBOOST |
	                                               AAPC_DACSEL );

	// Power everything up
	SMBusWriteReg(m_hSMBus, WM8731_PDC, 0x00);

	// Finally activate the codec
	SMBusWriteReg(m_hSMBus, WM8731_AC, AC_ACTIVE);

	return TRUE;
}



PBYTE I2S_HW::GetNextDMABuffer(UCHAR ucDMAChannel)
{
    DEBUGMSG(ZONE_FUNCTION, (TEXT("+I2S_HW: GetNextDMABuffer ")));
	PVOID pNextDMABuffer;

	switch ( ucDMAChannel )
	{
		case DMA_RX:
			 pNextDMABuffer = HalGetNextDMABuffer(m_DMAChannelInput);
			break;
		case DMA_TX:
			 pNextDMABuffer = HalGetNextDMABuffer(m_DMAChannelOutput);
			break;
		default:
			DEBUGMSG(ZONE_ERROR, (TEXT("I2S_HW: GetNextDMABuffer failed.  Invalid Channel. ")));
			 pNextDMABuffer = NULL;
	}

    DEBUGMSG(ZONE_FUNCTION, (TEXT("-I2S_HW: GetNextDMABuffer ")));

	return (PBYTE)pNextDMABuffer;
}

BOOL I2S_HW::SendDMABuffer(UCHAR ucDMAChannel, PBYTE pBufferStart, ULONG BytesTransferred)
{
    DEBUGMSG(ZONE_FUNCTION, (TEXT("+I2S_HW: SendDMABuffer ")));
	BOOL retVal;

	switch ( ucDMAChannel )
	{
		case DMA_RX:
			 retVal = HalActivateDMABuffer(m_DMAChannelInput, pBufferStart, BytesTransferred);
			break;
		case DMA_TX:
			 retVal = HalActivateDMABuffer(m_DMAChannelOutput, pBufferStart, BytesTransferred);
			break;
		default:
			DEBUGMSG(ZONE_ERROR, (TEXT("I2S_HW: SendDMABuffer failed.  Invalid Channel. ")));
			 retVal = FALSE;
	}

    DEBUGMSG(ZONE_FUNCTION, (TEXT("-I2S_HW: SendDMABuffer ")));

	return retVal;
}

UCHAR I2S_HW::GetInterruptSrc()
{
	UCHAR src = 0;
	ULONG Mask;

	// Check the input channel for interrupts
	Mask = HalCheckForDMAInterrupt(m_DMAChannelInput);
	if( Mask )
	{
		// Got a DMA interrupt for audio in
		src |= AUDIO_IN_INTERRUPT;
		HalAckDMAInterrupt(m_DMAChannelInput,Mask);
	}

	// Check the output channel for interrupts
	Mask = HalCheckForDMAInterrupt(m_DMAChannelOutput);
	if( Mask )
	{
		// Got a DMA interrupt for audio out
		src |= AUDIO_OUT_INTERRUPT;
		HalAckDMAInterrupt(m_DMAChannelOutput,Mask);
	}

	return src;
}


BOOL
I2S_HW::CodecPowerDown()
{
	BOOL Status = TRUE;

	//
	// Add Codec-specific Power down code here.
	//
	SMBusWriteReg(m_hSMBus, WM8731_PDC, PDC_POWEROFF);

	return Status;
}


BOOL
I2S_HW::CodecPowerUp()
{
	BOOL Status = TRUE;

	//
	// Add Codec-specific Power up code here.
	//
	InitializePlatform();

	return Status;
}



ULONG
I2S_HW::SetDACSampleRate( ULONG rate)
{

	UINT32 cfg=0;
	UINT16 codec_cfg=0;

	if ( g_pHWContext->IsInputStreamOpen() || g_pHWContext->IsOutputStreamOpen() )
	{
		// There is either an input or output stream open, so we can't change the rate
		return 0;
	}

    // Deactivate codec
	SMBusWriteReg(m_hSMBus, WM8731_AC, 0x00);

	/*
	 *	If the PSC is master, then we need to disable PSC before
	 *  updating registers.
	 */
	cfg = READ_REGISTER_ULONG((PULONG)&m_I2SCtrl->cfg);

	// Disable I2S controller
	cfg &= ~PSC_I2S_CFG_DE;
	WRITE_REGISTER_ULONG((PULONG)&m_I2SCtrl->cfg,cfg);

	// Wait for device disabled
	while ( (READ_REGISTER_ULONG((PULONG)&m_I2SCtrl->sts) & PSC_I2S_STS_DR) == 1);

	// Clear WS and DIVIDER values
	cfg &= ~(PSC_I2S_CFG_WS_N(0xFF) | PSC_I2S_CFG_BDIV_N(0x3));

	if (m_MinDACSampleRate > rate)
		rate = m_MinDACSampleRate;

	switch(rate)
	{
		case SAMPLERATE_8000HZ:
			// for 8000 USB=1 BOSR=0(fs=250) sr[3:0]=0011(0x3)
			cfg |= PSC_I2S_CFG_WS_N(94);
			cfg |= PSC_I2S_CFG_DIV16;
			codec_cfg = SC_SR_8000 | SC_USB;
			break;
		case SAMPLERATE_32000HZ:
			// for 32000 USB=1 BOSR=0(fs=250) sr[3:0]=0110(0x6)
			cfg |= PSC_I2S_CFG_WS_N(94);
			cfg |= PSC_I2S_CFG_DIV4;
			codec_cfg = SC_SR_32000 | SC_USB;
			break;
		case SAMPLERATE_44100HZ:
			// for 44100 USB=1 BOSR=1(fs=272) sr[3:0]=1000(0x8)
			cfg |= PSC_I2S_CFG_WS_N(68);
			cfg |= PSC_I2S_CFG_DIV4;
			codec_cfg = SC_SR_44100 | SC_BOSR_272FS | SC_USB;
			break;

		default:
			rate = SAMPLERATE_48000HZ; // for the default case
			// Fall through...
		case SAMPLERATE_48000HZ:
			// for 48 USB=1 BOSR=0(fs=250)  sr[3:0]=0000(0x0)
			cfg |= PSC_I2S_CFG_WS_N(125);
			cfg |= PSC_I2S_CFG_DIV2;
			codec_cfg = SC_SR_48000 | SC_USB;
			break;
		case SAMPLERATE_88200HZ:
			// for 88200 USB=1 BOSR=1(fs=272) sr[3:0]=1111(0xf)
			cfg |= PSC_I2S_CFG_WS_N(68);
			cfg |= PSC_I2S_CFG_DIV2;
			codec_cfg = SC_SR_88200 | SC_BOSR_272FS | SC_USB;
			break;
		case SAMPLERATE_96000HZ:
			// for 96000 USB=1 BOSR=0(fs=250) sr[3:0]=0111(0x7)
			cfg |= PSC_I2S_CFG_WS_N(63);
			cfg |= PSC_I2S_CFG_DIV2;
			codec_cfg = SC_SR_96000 | SC_USB;
			break;
	}


	//  Reconfigure and enable
	WRITE_REGISTER_ULONG((PULONG)&m_I2SCtrl->cfg,cfg);
	WRITE_REGISTER_ULONG((PULONG)&m_I2SCtrl->cfg,cfg|PSC_I2S_CFG_DE);

	// Wait for device enabled
	while ( (READ_REGISTER_ULONG((PULONG)&m_I2SCtrl->sts) & PSC_I2S_STS_DR) == 0);



	// Configure Sampling control
	SMBusWriteReg(m_hSMBus, WM8731_SC, codec_cfg);

	// Finally activate the codec
	SMBusWriteReg(m_hSMBus, WM8731_AC, AC_ACTIVE);

	return rate;
}

ULONG
I2S_HW::SetADCSampleRate( ULONG rate)
{
	if (m_MinADCSampleRate > rate)
		rate = m_MinADCSampleRate;

	return SetDACSampleRate(rate);
}

#ifndef _I2S_H_
#define _I2S_H_
#include <windows.h>
#include <wavedbg.h>
#include "platform.h"
#include "bceddk.h"

//
// Defines
//
#define AUDIO_REGKEY    (TEXT("Drivers\\BuiltIn\\WaveDev"))
#define AC97_DEFAULT_MICVOLUME      (0x8008)
#define DEFAULT_PCM_VOLUME 0

// Sample rates
#define SAMPLERATE_8000HZ      8000
#define SAMPLERATE_11025HZ     11025
#define SAMPLERATE_22050HZ     22050
#define SAMPLERATE_44100HZ     44100
#define SAMPLERATE_48000HZ     48000

#define TIMEOUT     200

//
// Codec Controller registers
// 
//

#define WM8731_LLI	0x0	// Left Line In
#define WM8731_RLI	0x1	// Right Line In
#define WM8731_LHO	0x2	// Left Headphone Output
#define WM8731_RHO	0x3	// Right Headphone Output
#define WM8731_AAPC	0x4	// Analog Audio Path Control
#define WM8731_DAPC	0x5	// Digital Audio Path Control
#define WM8731_PDC	0x6	// Power Down Control
#define WM8731_DAIF	0x7	// Digital Audio Interface Control
#define WM8731_SC	0x8	// Sampling Control
#define WM8731_AC	0x9	// Active Control
#define WM8731_RR	0xF	// Reset Register


//
// Define the individual bits in the indexed control registers.  The full set is not
// defined here, only the ones which are of interest in this driver
//

#define LLI_LINVOL_N(x)		((x)&0x1F)
#define LLI_LINMUTE			0x0080
#define LLI_LRINBOTH			0x0100

#define RLI_RINVOL_N(x)		((x)&0x1F)
#define RLI_RINMUTE			0x0080
#define RLI_RLINBOTH			0x0100

#define LHO_LHPVOL_N(x)		((x)&0x7F)
#define LHO_LZCEN			0x0080
#define LHO_LRHPBOTH		0x0100

#define RHO_RHPVOL_N(x)		((x)&0x7F)
#define RHO_RZCEN			0x0080
#define RHO_RLHPBOTH		0x0100

#define AAPC_MICBOOST		0x0001
#define AAPC_MUTEMIC		0x0002
#define AAPC_INSEL			0x0004
#define AAPC_BYPASS			0x0008
#define AAPC_DACSEL			0x0010
#define AAPC_SIDETONE		0x0020
#define AAPC_SIDEATT_N(x)	(((x)&0x3)<<6)
#define AAPC_SIDEATT_15		AAPC_SIDEATT_N(3)
#define AAPC_SIDEATT_12		AAPC_SIDEATT_N(1)
#define AAPC_SIDEATT_19		AAPC_SIDEATT_N(1)
#define AAPC_SIDEATT_6		AAPC_SIDEATT_N(0)

#define DAPC_ADCHPD			0x0001
#define DAPC_DEEMP_N(x)		(((x)&0x3)<<1)
#define DAPC_DEEMP_48		DAPC_DEEMP_N(3)
#define DAPC_DEEMP_44		DAPC_DEEMP_N(2)
#define DAPC_DEEMP_32		DAPC_DEEMP_N(1)
#define DAPC_DEEMP_OFF		DAPC_DEEMP_N(0)
#define DAPC_DACMU			0x0008
#define DAPC_HPOR			0x0010

#define PDC_LINEINPD		0x0001
#define PDC_MICPD			0x0002
#define PDC_ADCPD			0x0004
#define PDC_DACPD			0x0008
#define PDC_OUTPD			0x0010
#define PDC_OSCPD			0x0020
#define PDC_CLKOUTPD		0x0040
#define PDC_POWEROFF		0x0080

#define DAIF_FORMAT_N(x)	(((x)&0x3)<<0)
#define DAIF_FORMAT_DSP		DAIF_FORMAT_N(3)
#define DAIF_FORMAT_I2S		DAIF_FORMAT_N(2)
#define DAIF_FORMAT_LJUST	DAIF_FORMAT_N(1)
#define DAIF_FORMAT_RJUST	DAIF_FORMAT_N(0)
#define DAIF_IWL_N(x)		(((x)&0x3)<<2)
#define DAIF_IWL_32			DAIF_IWL_N(3)
#define DAIF_IWL_24			DAIF_IWL_N(2)
#define DAIF_IWL_20			DAIF_IWL_N(1)
#define DAIF_IWL_16			DAIF_IWL_N(0)
#define DAIF_LRP			0x0010
#define DAIF_LRSWAP			0x0020
#define DAIF_MS				0x0040
#define DAIF_BCLKINV		0x0080

#define SC_USB				0x0001
#define SC_BOSR				0x0002
#define SC_SR_N(x)			(((x)&0xF)<<2)
#define SC_CLKIDIV2			0x0040
#define SC_CLKODIV2			0x0080

#define AC_ACTIVE			0x0001

#define RR_RESET			0x0000

#define SC_SR_96000			(0x7<<2)
#define SC_SR_88200			(0xF<<2)
#define SC_SR_48000			(0x0<<2)
#define SC_SR_44100			(0x8<<2)
#define SC_SR_32000			(0x6<<2)
#define SC_SR_8018			(0x9<<2)
#define SC_SR_8000			(0x3<<2)
#define SC_BOSR_250FS		(0<<1)
#define SC_BOSR_272FS		(1<<1)
#define SC_BOSR_256FS		(0<<1)
#define SC_BOSR_128FS		(0<<1)
#define SC_BOSR_384FS		(1<<1)
#define SC_BOSR_192FS		(1<<1)

//
// Interrupt sources
//

#define AUDIO_IN_INTERRUPT 0x01
#define AUDIO_OUT_INTERRUPT 0x02

//
// Macros
//
#if (_WINCEOSVER < 600)
#define STALLEXECUTION(x) HalStallExecution(x)
#else
#define	STALLEXECUTION(x) OALStallExecution(x)
#endif

//
// Externs
//


//
// Data Structures
//


class I2S_HW
{
public:
	//
	// Function prototypes
	//
	BOOL InitializePlatform();
	BOOL DeInitializePlatform();
	DWORD FindMicVolume();
	BOOL InitializeRegisters();
	BOOL InitializeIntr(DWORD *pIntrAudio);
	BOOL InitializeDMA();
	VOID StartDma(UCHAR ucDMAChannel);
	VOID StopDma(UCHAR ucDMAChannel);
	void SetDMABufferSize(DWORD BufferSize) {m_DmaBufferSize = BufferSize;}
	DWORD GetDMABufferSize() {return m_DmaBufferSize;}
	BOOL InitializeCodec();
	PBYTE GetNextDMABuffer(UCHAR ucDMAChannel);
	BOOL SendDMABuffer(UCHAR ucDMAChannel, PBYTE pBufferStart, ULONG BytesTransferred);
	UCHAR GetInterruptSrc();
	BOOL CodecPowerUp();
	BOOL CodecPowerDown();
	ULONG SetADCSampleRate(ULONG rate);
	ULONG SetDACSampleRate(ULONG rate);

	UINT32					m_MinDACSampleRate;
	UINT32					m_MinADCSampleRate;
	



private:	
	// 
	// Member variables
	//
	PSC_I2S*				m_I2SCtrl;
    HANDLE                  m_hSMBus;
	DWORD					m_MicVolume;
	PDMA_CHANNEL_OBJECT     m_DMAChannelInput;
	PDMA_CHANNEL_OBJECT     m_DMAChannelOutput;
	DWORD					m_DmaBufferSize;
};

//
//	Function prototypes
//


#endif //_I2S_H_

//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
/*
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:    HWCTXT.CPP

Abstract:               Platform dependent code for the mixing audio driver.

Notes:                  The following file contains all the hardware specific code
for the mixing audio driver.  This code's primary responsibilities
are:

* Initialize audio hardware (including codec chip)
* Schedule DMA operations (move data from/to buffers)
* Handle audio interrupts

All other tasks (mixing, volume control, etc.) are handled by the "upper"
layers of this driver.
*/

#include <windows.h>
#include <types.h>
#include <memory.h>
#include <excpt.h>
#include <wavepdd.h>
#include <waveddsi.h>
#include <wavedbg.h>
#include <nkintr.h>
#include <ceddk.h>
#include "wavemain.h"


HardwareContext *g_pHWContext=NULL;
//$$

BOOL HardwareContext::CreateHWContext(DWORD Index)
{
    if (g_pHWContext)
    {
        return TRUE;
    }

    g_pHWContext = new HardwareContext;
    if (!g_pHWContext)
    {
        return FALSE;
    }

    return g_pHWContext->Init(Index);
}

HardwareContext::HardwareContext():
m_InputDeviceContext(),
m_OutputDeviceContext(),
//m_Au1xAudio(),
m_bEnableSpdif(FALSE),
m_bEnableSpdifWmaPro(FALSE),
m_bSpdifCompression(FALSE)
{
    InitializeCriticalSection(&m_Lock);
    m_Initialized=FALSE;
}

HardwareContext::~HardwareContext()
{
    DeleteCriticalSection(&m_Lock);
}


BOOL HardwareContext::Init(DWORD Index)
{

    if (m_Initialized)
    {
        return FALSE;
    }

    //----- 1. Initialize the state/status variables -----
    m_DriverIndex       = Index;
    m_InPowerHandler    = FALSE;
    m_InputDMARunning   = FALSE;
    m_OutputDMARunning  = FALSE;
    m_NumForcedSpeaker  = 0;

    m_dwOutputGain = 0xFFFFFFFF;
    m_dwInputGain  = 0xFFFFFFFF;
    m_fInputMute  = FALSE;
    m_fOutputMute = FALSE;




    DWORD Irq = -1;

    FUNC_WPDD("PDD_AudioInitialize");

    m_dwBusNumber = 0;
    m_IfcType = PCIBus;


    // Calling InitializePlatform does the following:
	//		Maps the registers
	//		Initializes GPIOs
	//		Sets the initial volume
	//		Initializes Registers
	if(!m_Au1xAudio.InitializePlatform())
	{
        DEBUGMSG(1, (TEXT("PDD_AudioInitialize: Failed to initialize hardware \r\n")));
        return FALSE;
    }

	if(!m_Au1xAudio.InitializeCodec())
	{
        DEBUGMSG(1, (TEXT("PDD_AudioInitialize: Failed to initialize codec \r\n")));
        return FALSE;
    }

	// Read the registry for minimum samplerates
	m_Au1xAudio.m_MinDACSampleRate = ReadMixerRegValue(TEXT("MinDACSampleRate"), 0);
	m_Au1xAudio.m_MinADCSampleRate = ReadMixerRegValue(TEXT("MinADCSampleRate"), 0);

	if (m_Au1xAudio.m_MinDACSampleRate == 0)
		m_Au1xAudio.m_MinDACSampleRate = SAMPLERATE_8000HZ;

	if (m_Au1xAudio.m_MinADCSampleRate == 0)
		m_Au1xAudio.m_MinADCSampleRate = SAMPLERATE_8000HZ;

// set the sample rate - Also sets the HW sample rate so platform must initialize first
	m_InputDeviceContext.SetBaseSampleRate(INPUT_SAMPLERATE);
    m_OutputDeviceContext.SetBaseSampleRate(OUTPUT_SAMPLERATE);


    DMA_ADAPTER_OBJECT AdapterObject;

    AdapterObject.ObjectSize = sizeof(AdapterObject);
    AdapterObject.InterfaceType = m_IfcType;
    AdapterObject.BusNumber = m_dwBusNumber;

	m_Au1xAudio.SetDMABufferSize(AUDIO_DMA_PAGE_SIZE);
	m_Au1xAudio.InitializeDMA(); // 2 DMA Pages will be created here

	// Initialize Interrupts
    m_Au1xAudio.InitializeIntr(&m_IntrAudio);

    if (!InitInterruptThread())
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("WAVEDEV.DLL:HardwareContext::Init() - Failed to initialize interrupt thread.\r\n")));
        goto Exit;
    }

    BOOL bEnable;
    bEnable = (BOOL)GetDriverRegValue(TEXT("EnableSpdif"),FALSE);
    SetSpdifEnable(bEnable);

    bEnable = (BOOL)GetDriverRegValue(TEXT("EnableSpdifWmaPro"),FALSE);
    SetSpdifEnableWmaPro(bEnable);

    // Initialize the mixer controls in mixerdrv.cpp
    InitMixerControls();

    m_Initialized=TRUE;

    Exit:
    return m_Initialized;
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:               Deinit()

Description:    Deinitializest the hardware: disables DMA channel(s),
                                clears any pending interrupts, powers down the audio
                                codec chip, etc.

Returns:                Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::Deinit()
{
    DMA_ADAPTER_OBJECT AdapterObject;
    //
    // The driver is being unloaded. Deinitialize. Free up memory, etc.
    //

    if (m_IsrHandle)
    {
        FreeIntChainHandler(m_IsrHandle);
        m_IsrHandle = NULL;
    }

    AdapterObject.ObjectSize = sizeof(AdapterObject);
    AdapterObject.InterfaceType = m_IfcType;
    AdapterObject.BusNumber = m_dwBusNumber;

	if(!m_Au1xAudio.DeInitializePlatform())
	{
        DEBUGMSG(1, (TEXT("PDD_AudioInitialize: Failed to uninitialize hardware \r\n")));
        return FALSE;
    }

	// Cleanup for DMA

    return TRUE;
}

inline void HardwareContext::UpdateOutputGain()
{
    m_OutputDeviceContext.SetGain(m_fOutputMute ? 0 : m_dwOutputGain);
}

inline void HardwareContext::UpdateInputGain()
{
    m_InputDeviceContext.SetGain(m_fInputMute ? 0 : m_dwInputGain);
}

MMRESULT HardwareContext::SetOutputGain (DWORD dwGain)
{
    m_dwOutputGain = dwGain;
    UpdateOutputGain();

    return MMSYSERR_NOERROR;
}

MMRESULT HardwareContext::SetOutputMute (BOOL fMute)
{
    m_fOutputMute = fMute;
    UpdateOutputGain();

    return MMSYSERR_NOERROR;
}

DWORD HardwareContext::GetOutputGain (void)
{
    return m_dwOutputGain;
}

BOOL HardwareContext::GetOutputMute (void)
{
    return m_fOutputMute;
}

BOOL HardwareContext::GetInputMute (void)
{
    return m_fInputMute;
}

MMRESULT HardwareContext::SetInputMute (BOOL fMute)
{
    m_fInputMute = fMute;
    UpdateInputGain();
    return MMSYSERR_NOERROR;
}

DWORD HardwareContext::GetInputGain (void)
{
    return m_dwInputGain;
}

MMRESULT HardwareContext::SetInputGain (DWORD dwGain)
{
    m_dwInputGain = dwGain;
    UpdateInputGain();

    return MMSYSERR_NOERROR;
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:               StartOutputDMA()

Description:    Starts outputting the sound data to the audio codec
                                chip via DMA.

Notes:

Returns:                Boolean indicating success
-------------------------------------------------------------------*/

BOOL HardwareContext::StartOutputDMA()
{
    BOOL bRet = FALSE;

    if (!m_OutputDMARunning)
    {
        //----- 1. Initialize our buffer counters -----
        m_OutputDMARunning=TRUE;

        //----- 2. Prime both output buffers with as much sound data as possible -----
        ULONG OutputTransferred = TransferOutputBuffer();
        OutputTransferred += TransferOutputBuffer();

        //----- 3. If we did transfer any data to the DMA buffers, go ahead and enable DMA -----
        if (OutputTransferred)
        {
            //
            // Start the DMA channel
            //
            m_Au1xAudio.StartDma(DMA_TX);
        }
        else    // We didn't transfer any data, so DMA wasn't enabled
        {
            m_OutputDMARunning=FALSE;
        }
    }

    bRet = TRUE;

    // Exit:
    return bRet;
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:               StopOutputDMA()

Description:    Stops any DMA activity on the output channel.

Returns:                Boolean indicating success
-------------------------------------------------------------------*/
void HardwareContext::StopOutputDMA()
{
    if (m_OutputDMARunning)
    {
        //$$ Set SpeakerAmplifier muting and turn off/on mute bit in control register B.
        m_Au1xAudio.StopDma(DMA_TX);
        m_OutputDMARunning=FALSE;
    }

}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:               StartInputDMA()

Description:    Starts inputting the recorded sound data from the
                                audio codec chip via DMA.

Notes:

Returns:                Boolean indicating success
-------------------------------------------------------------------*/

BOOL HardwareContext::StartInputDMA()
{
    BOOL bRet=FALSE;

    if (!m_InputDMARunning)
    {
        m_InputDMARunning=TRUE;

        //
        // Start the DMA channel
        //
        m_Au1xAudio.StartDma(DMA_RX);

        // DEBUGMSG(1, (TEXT("Started intput DMA\r\n")));
    }

    bRet=TRUE;

    // Exit:
    return bRet;

}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:               StopInputDMA()

Description:    Stops any DMA activity on the input channel.

Notes:

Returns:                Boolean indicating success
-------------------------------------------------------------------*/
void HardwareContext::StopInputDMA()
{
    if ( m_InputDMARunning )
    {
        m_Au1xAudio.StopDma(DMA_RX);;
        m_InputDMARunning=FALSE;
    }
}

DWORD HardwareContext::GetDriverRegValue(LPWSTR ValueName, DWORD DefaultValue)
{
    HKEY DevKey = OpenDeviceKey((LPWSTR)m_DriverIndex);

    if (DevKey)
    {
        DWORD ValueLength = sizeof(DWORD);
        RegQueryValueEx(
                       DevKey,
                       ValueName,
                       NULL,
                       NULL,
                       (PUCHAR)&DefaultValue,
                       &ValueLength);

        RegCloseKey(DevKey);
    }

    return DefaultValue;
}

void HardwareContext::SetDriverRegValue(LPWSTR ValueName, DWORD Value)
{
    HKEY DevKey = OpenDeviceKey((LPWSTR)m_DriverIndex);

    if (DevKey)
    {
        RegSetValueEx(
                     DevKey,
                     ValueName,
                     NULL,
                     REG_DWORD,
                     (PUCHAR)&Value,
                     sizeof(DWORD)
                     );

        RegCloseKey(DevKey);
    }

    return;
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:               InitInterruptThread()

Description:    Initializes the IST for handling DMA interrupts.

Returns:                Boolean indicating success
-------------------------------------------------------------------*/
BOOL HardwareContext::InitInterruptThread()
{
    BOOL bSuccess;
    m_hAudioInterrupt = CreateEvent( NULL, FALSE, FALSE, NULL);
    if (!m_hAudioInterrupt)
    {
        return FALSE;
    }

    bSuccess = InterruptInitialize(m_IntrAudio, m_hAudioInterrupt, NULL, 0);

    m_hAudioInterruptThread  = CreateThread((LPSECURITY_ATTRIBUTES)NULL,
                                            0,
                                            (LPTHREAD_START_ROUTINE)CallInterruptThread,
                                            this,
                                            0,
                                            NULL);
    if (!m_hAudioInterruptThread)
    {
        return FALSE;
    }

    // Bump up the priority since the interrupt must be serviced immediately.
    CeSetThreadPriority(m_hAudioInterruptThread, GetInterruptThreadPriority());

    return TRUE;
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:               PowerUp()

Description:            Powers up the audio codec chip.

Returns:                Boolean indicating success
-------------------------------------------------------------------*/
void HardwareContext::PowerUp()
{
	m_Au1xAudio.CodecPowerUp();
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:               PowerDown()

Description:    Powers down the audio codec chip.

Notes:                  Even if the input/output channels are muted, this
                                function powers down the audio codec chip in order
                                to conserve battery power.

Returns:                Boolean indicating success
-------------------------------------------------------------------*/
void HardwareContext::PowerDown()
{
	m_Au1xAudio.CodecPowerDown();
}

//############################################ Helper Functions #############################################

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:               TransferOutputBuffer()

Description:    Retrieves the next "mixed" audio buffer of data to
                                DMA into the output channel.

Returns:                Number of bytes needing to be transferred.
-------------------------------------------------------------------*/
ULONG HardwareContext::TransferOutputBuffer()
{
	ULONG BytesTransferred = 0;
    PBYTE pBufferStart = m_Au1xAudio.GetNextDMABuffer(DMA_TX);// Get next DMA buffer
    PBYTE pBufferEnd = pBufferStart + AUDIO_DMA_PAGE_SIZE;
    PBYTE pBufferLast;

    TRANSFER_STATUS TransferStatus = {0};

    pBufferLast = m_OutputDeviceContext.TransferBuffer(pBufferStart, pBufferEnd,&TransferStatus);
    BytesTransferred = pBufferLast-pBufferStart;

	// Send DMA buffer if valid
	if ( BytesTransferred )
		m_Au1xAudio.SendDMABuffer(DMA_TX,  pBufferStart, BytesTransferred);

    return BytesTransferred;
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Function:               TransferInputBuffer()

Description:    Retrieves the chunk of recorded sound data and inputs
                                it into an audio buffer for potential "mixing".

Returns:                Number of bytes needing to be transferred.
-------------------------------------------------------------------*/
ULONG HardwareContext::TransferInputBuffer()
{
    ULONG BytesTransferred = 0;
    PBYTE pBufferStart = m_Au1xAudio.GetNextDMABuffer(DMA_RX);// Get next DMA buffer
    PBYTE pBufferEnd = pBufferStart + AUDIO_DMA_PAGE_SIZE;
    PBYTE pBufferLast;

    pBufferLast = m_InputDeviceContext.TransferBuffer(pBufferStart, pBufferEnd,NULL);

    BytesTransferred = pBufferLast-pBufferStart;

	// Send DMA buffer if valid
	if ( BytesTransferred )
		m_Au1xAudio.SendDMABuffer(DMA_RX,  pBufferStart, BytesTransferred);

    return BytesTransferred;
}

void HardwareContext::InterruptThread()
{

#if (_WINCEOSVER < 600)
    // Need to be able to access everyone else's address space during interrupt handler.
    SetProcPermissions((DWORD)-1);
#endif
	UCHAR intsrc;

    while (TRUE)
    {
		InterruptDone(m_IntrAudio);

		WaitForSingleObject(m_hAudioInterrupt, INFINITE);

        // Grab the lock
        Lock();

        // The the interrupt type (audio-in or audio-out)
		intsrc = m_Au1xAudio.GetInterruptSrc();


        // Which interrupt is the source?
        //
        if ( intsrc & AUDIO_OUT_INTERRUPT )
        {
            ULONG OutputTransferred;

            // Are there any outstanding DMA buffers?
            OutputTransferred = TransferOutputBuffer();

			// If this is 0 then no data was DMAed.  Shut it down.
            if ( OutputTransferred==0 )
            {
                StopOutputDMA();
            }
        }

		if ( intsrc & AUDIO_IN_INTERRUPT )
        {
            ULONG InputTransferred;

            // Are there any outstanding DMA buffers?
            InputTransferred = TransferInputBuffer( );

            // For input DMA, we can stop the DMA as soon as we have no data to transfer.
            if ( InputTransferred==0 )
            {
                StopInputDMA();
            }
        }

        Unlock();
    }  // while(TRUE)

}

void CallInterruptThread(HardwareContext *pHWContext)
{
    pHWContext->InterruptThread();
}

// Control the hardware speaker enable
void HardwareContext::SetSpeakerEnable(BOOL bEnable)
{
    // Code to turn speaker on/off here
    return;
}

/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8
// RecalcSpeakerEnable decides whether to enable the speaker or not.
// For now, it only looks at the m_bForceSpeaker variable, but it could
// also look at whether the headset is plugged in
// and/or whether we're in a voice call. Some mechanism would
// need to be implemented to inform the wave driver of changes in the state of
// these variables however.
/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8

void HardwareContext::RecalcSpeakerEnable()
{
    SetSpeakerEnable(m_NumForcedSpeaker);
}

/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8
// SetForceSpeaker is called from the device context to update the state of the
// m_bForceSpeaker variable.
/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8

DWORD HardwareContext::ForceSpeaker( BOOL bForceSpeaker )
{
    // If m_NumForcedSpeaker is non-zero, audio should be routed to an
    // external speaker (if hw permits).
    if (bForceSpeaker)
    {
        m_NumForcedSpeaker++;
        if (m_NumForcedSpeaker==1)
        {
            RecalcSpeakerEnable();
        }
    }
    else
    {
        m_NumForcedSpeaker--;
        if (m_NumForcedSpeaker==0)
        {
            RecalcSpeakerEnable();
        }
    }

    return MMSYSERR_NOERROR;
}

//------------------------------------------------------------------------------
//
//  Function: PmControlMessage
//
//  Power management routine.
//
/////////1/////////2/////////3/////////4/////////5/////////6/////////7/////////8

BOOL
HardwareContext::PmControlMessage (
                                  DWORD  dwCode,
                                  PBYTE  pBufIn,
                                  DWORD  dwLenIn,
                                  PBYTE  pBufOut,
                                  DWORD  dwLenOut,
                                  PDWORD pdwActualOut)
{
    BOOL bRetVal = FALSE;

    switch (dwCode)
    {
    // Return device specific power capabilities.
    case IOCTL_POWER_CAPABILITIES:
        {
            PPOWER_CAPABILITIES ppc = (PPOWER_CAPABILITIES) pBufOut;

            // Check arguments.
            if ( ppc && (dwLenOut >= sizeof(POWER_CAPABILITIES)) && pdwActualOut )
            {
                // Clear capabilities structure.
                memset( ppc, 0, sizeof(POWER_CAPABILITIES) );

                // Set power capabilities. Supports D0 and D4.
                ppc->DeviceDx = DX_MASK(D0)|DX_MASK(D4);

                DEBUGMSG(ZONE_FUNCTION, (TEXT("WAVE: IOCTL_POWER_CAPABILITIES = 0x%x\r\n"), ppc->DeviceDx));

                // Update returned data size.
                *pdwActualOut = sizeof(*ppc);
                bRetVal = TRUE;
            }
            else
            {
                DEBUGMSG(ZONE_ERROR, ( TEXT( "WAVE: Invalid parameter.\r\n" ) ) );
            }
            break;
        }

        // Indicate if the device is ready to enter a new device power state.
    case IOCTL_POWER_QUERY:
        {
            PCEDEVICE_POWER_STATE pDxState = (PCEDEVICE_POWER_STATE)pBufOut;

            // Check arguments.
            if (pDxState && (dwLenOut >= sizeof(CEDEVICE_POWER_STATE)) && pdwActualOut)
            {
                DEBUGMSG(ZONE_FUNCTION, (TEXT("WAVE: IOCTL_POWER_QUERY = %d\r\n"), *pDxState));

                // Check for any valid power state.
                if (VALID_DX (*pDxState))
                {
                    *pdwActualOut = sizeof(CEDEVICE_POWER_STATE);
                    bRetVal = TRUE;
                }
                else
                {
                    DEBUGMSG(ZONE_ERROR, ( TEXT( "WAVE: IOCTL_POWER_QUERY invalid power state.\r\n" ) ) );
                }
            }
            else
            {
                DEBUGMSG(ZONE_ERROR, ( TEXT( "WAVE: IOCTL_POWER_QUERY invalid parameter.\r\n" ) ) );
            }
            break;
        }

        // Request a change from one device power state to another.
    case IOCTL_POWER_SET:
        {
            PCEDEVICE_POWER_STATE pDxState = (PCEDEVICE_POWER_STATE)pBufOut;
            RETAILMSG(1, ( TEXT( "+WAVE: IOCTL_POWER_SET = %d.\r\n"), *pDxState));

            // Check arguments.
            if (pDxState && (dwLenOut >= sizeof(CEDEVICE_POWER_STATE)))
            {
                DEBUGMSG(ZONE_FUNCTION, ( TEXT( "WAVE: IOCTL_POWER_SET = %d.\r\n"), *pDxState));

                // Check for any valid power state.
                if (VALID_DX(*pDxState))
                {
                    Lock();

                    // Power off.
                    if ( *pDxState == D4 )
                    {
                        PowerDown();
                    }
                    // Power on.
                    else
                    {
                        PowerUp();
                    }

                    m_DxState = *pDxState;

                    Unlock();

                    bRetVal = TRUE;
                }
                else
                {
                    DEBUGMSG(ZONE_ERROR, ( TEXT( "WAVE: IOCTL_POWER_SET invalid power state.\r\n" ) ) );
                }
            }
            else
            {
                DEBUGMSG(ZONE_ERROR, ( TEXT( "WAVE: IOCTL_POWER_SET invalid parameter.\r\n" ) ) );
            }

            RETAILMSG(1, ( TEXT( "-WAVE: IOCTL_POWER_SET = %d.\r\n"), *pDxState));
            break;
        }

        // Return the current device power state.
    case IOCTL_POWER_GET:
        {
            DEBUGMSG(ZONE_FUNCTION, (TEXT("WAVE: IOCTL_POWER_GET -- not supported!\r\n")));
            break;
        }

    default:
        DEBUGMSG(ZONE_WARN, (TEXT("WAVE: Unknown IOCTL_xxx(0x%0.8X) \r\n"), dwCode));
        break;
    }

    return bRetVal;
}


BOOL HardwareContext::IsSupportedOutputFormat(LPWAVEFORMATEX lpFormat)
{
    BOOL bRet = FALSE;

    // Add custom output formats here

    return bRet;
}


ULONG HardwareContext::SetDACSampleRate(ULONG hertz)
{
	return m_Au1xAudio.SetDACSampleRate(hertz);
}

ULONG HardwareContext::SetADCSampleRate(ULONG hertz)
{
	return m_Au1xAudio.SetADCSampleRate(hertz);
}

DWORD HardwareContext::ReadMixerRegValue(LPWSTR ValueName, DWORD DefaultValue)
{
	ULONG RegRet;
	HKEY ActiveKey;
	DWORD ValueLength = sizeof(DWORD);
	DWORD Type;

	LPWSTR MixerRegistryPath = L"Audio\\SoftwareMixer";



	RegRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                          MixerRegistryPath,
                          0,
                          KEY_READ,
                          &ActiveKey);


	if (RegRet != ERROR_SUCCESS)
	{

        RETAILMSG(1, (TEXT("WAVEDEV2: Failed to open registry key HKLM\\%s.\r\n"), MixerRegistryPath));
		return DefaultValue;

    }

	RegRet = RegQueryValueEx(ActiveKey,
                             ValueName,
                             0,
                             &Type,
                             (LPBYTE)&DefaultValue,
                             &ValueLength);

	RegCloseKey(ActiveKey);


	return DefaultValue;
}

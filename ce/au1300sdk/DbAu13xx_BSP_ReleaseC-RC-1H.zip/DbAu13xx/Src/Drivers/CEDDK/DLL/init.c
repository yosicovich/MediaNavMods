/*++
    Copyright (c) 1998, 2001-2002 BSQUARE Corporation.  All rights reserved.

Module Name:

    init.c

Abstract:

    This module implements the initialization code for the BCEDDK DLL.
    It calls the common initialization as well as any platform specific
    initializations.

Author:

    Jason W. Murray 19-March-1998

Revision History:


--*/

#include <bceddk.h>


void
CalibrateStallCounter(void)
{
	// NOP on Alchemy platform
	return;
}

ULONG
GetCPUCoreSpeed(VOID)
{
    ULONG Result;
    ULONG ResultSize;

    KernelIoControl(
        IOCTL_HAL_QUERY_CORE_SPEED,
        NULL,
        0,
        &Result,
        sizeof(ULONG),
        &ResultSize
        );

    return Result;
}


ULONG
GetPBUSSpeed(VOID)
{
    ULONG Result;
    ULONG ResultSize;

    KernelIoControl(
        IOCTL_HAL_QUERY_PBUS_SPEED,
        NULL,
        0,
        &Result,
        sizeof(ULONG),
        &ResultSize
        );

    return Result;
}



BOOL
WINAPI
BCeDdkDllEntry(
    HANDLE  DllInstance,
    DWORD   Reason,
    LPVOID  Reserved
    )

{
    BOOL Success = TRUE;

    switch (Reason) {
    case DLL_PROCESS_ATTACH:

	    DisableThreadLibraryCalls((HMODULE)DllInstance);

        //
        // Private entry points.
        //
        BusEntry();
        OALStallExecutionEntry();


        break;
    }

    return Success;
}

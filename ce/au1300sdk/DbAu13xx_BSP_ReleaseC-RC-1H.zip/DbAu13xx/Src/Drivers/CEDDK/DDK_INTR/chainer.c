//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:  
    CEDDK\DDK_INTR\chainer.c
    
Abstract:  
    Common code for configuring shared interrupts.

Notes: 
--*/
#include <windows.h>
#include <nkintr.h>
#include <bceddk.h>
#include <ddkreg.h>
#include <giisr.h>

static void ReadRegDword (HKEY hk, LPCTSTR szVal, DWORD* p, DWORD def)
{
    DWORD z = sizeof(DWORD);
    if (RegQueryValueEx(hk, szVal, 0, NULL, (LPBYTE)p, &z) != ERROR_SUCCESS)
        *p = def;
}

struct InterruptData
{
    GIISR_INFO gi;
    BOOL isConnected;
    HANDLE hChain;
};

// InterruptConfigure should be called from XXX_Init.
// szRegPath is the activation key passed in from the device manager;
// We use it to locate the values we need to configure the interrupt.
// hwIntr is the hardware interrupt number of the interrupt of interest;
// it can be IRQ_UNSPECIFIED iff the registry is expected to specify it.
// pSysIntr is a value-result parameter; if it points to a value other than
// SYSINTR_NOP then that sysintr is used. Otherwise we check the registry
// for a sysintr and then ask the OS for one if necessary. The actual
// sysintr to be used is then written back. pSysIntr cannot be NULL.
//
// Returns a handle to be passed to InterruptUnconfigure, or
// NULL on error.
//
HANDLE InterruptConfigure (LPCWSTR szRegPath, DWORD hwIntr, DWORD* pSysIntr)
{
    struct InterruptData *ph;
    DWORD err;
    DDKISRINFO isrinfo;
    HKEY hKey = OpenDeviceKey(szRegPath);

    RETAILMSG(1,(TEXT("InterruptConfigure: %s %d %d\r\n"), szRegPath,hwIntr,*pSysIntr ));
            
    if (hKey == 0) {
        return 0;
    }

    ph = (struct InterruptData *) LocalAlloc(LPTR, sizeof(*ph));
    if (ph == 0) {
        RegCloseKey(hKey);
        return 0;
    }

    ReadRegDword(hKey, L"PortAddr", &ph->gi.PortAddr, 0);
    ReadRegDword(hKey, L"PortSize", &ph->gi.PortSize, 4);
    ph->gi.CheckPort = ph->gi.PortAddr ? TRUE : FALSE;
    ph->gi.PortIsIO = FALSE;
    ReadRegDword(hKey, L"MaskAddr", &ph->gi.MaskAddr, 0);
    ph->gi.UseMaskReg = ph->gi.MaskAddr ? TRUE : FALSE;
    ReadRegDword(hKey, L"Mask", &ph->gi.Mask, -1);

    isrinfo.cbSize = sizeof(isrinfo);
    err = DDKReg_GetIsrInfo(hKey, &isrinfo);

    RegCloseKey(hKey);

    if (err != ERROR_SUCCESS) {
        LocalFree(ph);
        SetLastError(err);
        return 0;
    }

    if (hwIntr != IRQ_UNSPECIFIED) {
        isrinfo.dwIrq = hwIntr;
    }
    if (*pSysIntr != SYSINTR_NOP) {
        isrinfo.dwSysintr = *pSysIntr;
    }
    if (isrinfo.dwSysintr == SYSINTR_NOP) {
        isrinfo.dwSysintr = InterruptConnect(Internal, 0, isrinfo.dwIrq, 0);
        ph->isConnected = TRUE;
    } else {
        ph->isConnected = FALSE;
    }
    if (isrinfo.dwSysintr == SYSINTR_NOP) {
        LocalFree(ph);
        return 0;
    }
    ph->gi.SysIntr = isrinfo.dwSysintr;

    ph->hChain = LoadIntChainHandler(isrinfo.szIsrDll, isrinfo.szIsrHandler, (BYTE) isrinfo.dwIrq);
    if (ph->hChain == 0) {
        LocalFree(ph);
        return 0;
    }

    if (!KernelLibIoControl(ph->hChain, IOCTL_GIISR_INFO, &ph->gi, sizeof(ph->gi), NULL, 0, NULL)) {
        FreeIntChainHandler(ph->hChain);
        LocalFree(ph);
        return 0;
    }

    *pSysIntr = ph->gi.SysIntr;
    return (HANDLE) ph;
}

void InterruptUnconfigure (HANDLE h)
{
    struct InterruptData *ph = (struct InterruptData *) h;
    FreeIntChainHandler(ph->hChain);
    if (ph->isConnected) {
        InterruptDisconnect(ph->gi.SysIntr);
    }
    LocalFree(ph);
}

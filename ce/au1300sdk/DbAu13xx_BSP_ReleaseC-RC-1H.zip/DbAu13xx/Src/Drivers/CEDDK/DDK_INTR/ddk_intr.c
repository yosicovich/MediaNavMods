/*++

Copyright:

    Copyright (c) 1998, 2002-2004 BSQUARE Corporation.  All rights reserved.

Module Name:

    intr.c

Abstract:

    This module implement interrupt hooking and connection routines for the
    context of the user space drivers.

Author:

    Jason W. Murray 24-Febuary-1998

Revision History:

    Richard Chinn   23-June-1998
        Port to Brutus.  Also wrote timer routines.
    GJS    May 2001
        Port to Pb1000 (changed the header)

--*/

#include "bceddk.h"
#include "platform.h"

ULONG
InterruptConnect(
    IN INTERFACE_TYPE InterfaceType,
    IN ULONG BusNumber,
    IN ULONG BusInterrupt,
    IN ULONG InterruptMode
    )
{
    ULONG Result;
    ULONG ResultSize;

    KernelIoControl(
        IOCTL_HAL_REQUEST_SYSINTR,
        &BusInterrupt,
        sizeof(BusInterrupt),
        &Result,
        sizeof(ULONG),
        &ResultSize
        );

    return Result;
}


VOID
InterruptDisconnect(
    IN ULONG Sysintr
    )
{
    KernelIoControl(
        IOCTL_HAL_RELEASE_SYSINTR,
        &Sysintr,
        sizeof(Sysintr),
        NULL,
        0,
        NULL);

    return;
}

ULONG
InterruptConnectTimer(
    VOID
    )
/*++

Routine Description:

    This routine allocates a new SYSINTR for a system timer.  It should
    be used to connect to timer interrupt sources instead of InterruptConnect
    as InterruptConnectTimer will handle timer allocation as well as provide
    access to APIs for controlling the allocated timer.

    If a timer is successfully allocated, it is disabled and cleared.  It will
    not generate interrupts.  The timer's counter is cleared.

    The returned SYSINTR must be associated with an event with
    InitializeInterrupt before attempting to use the timer.

Arguments:

    None.

Return Value:

    Returns a SYSINTR associated with the timer if successful.  If all
    timers have been allocated, all SYSINTRs have been allocated, or some
    other failure occurs, SYSINTR_NOP is returned.

--*/
{
    ULONG Result;
    ULONG ResultSize;

    KernelIoControl(
        IOCTL_HAL_INTR_CONNECT_TIMER,
        NULL,
        0,
        &Result,
        sizeof(ULONG),
        &ResultSize
        );

    return Result;
}



VOID
InterruptDisconnectTimer(
    ULONG SysIntr
    )
/*++

Routine Description:

    This routine disassociates the specified SYSINTR from its corresponding
    timer.  The SYSINTR and timer are then able to be reallocated.

    The programmer must call InterruptDisable on the SYSINTR before
    deallocating the SYSINTR with this routine.  The call to InterruptDisable
    will automatically disable the interrupt associated with the timer.

    It is only valid to call this routine on a SYSINTR that was allocated
    by InterruptConnectTimer. Calling InterruptDisconnectTimer on a SYSINTR
    that was not successfully allocated by calling InterruptConnectTimer
    does nothing.

Arguments:

    Sysintr     SYSINTR corresponding to the timer from which to disconnect.

Return Value:

    None.

--*/
{
    KernelIoControl(
        IOCTL_HAL_INTR_DISCONNECT_TIMER,
        (PVOID)&SysIntr,
        sizeof(ULONG),
        NULL,
        0,
        NULL
        );

    return;
}



BOOLEAN
InterruptStartTimer(
    IN ULONG SysIntr,
    IN ULONG PeriodHns
    )
/*++

Routine Description:

    Starts the timer associated with the specified SYSINTR.  The timer
    is set to cause an interrupt every (PeriodHns * 100 ns).  When the
    timer is running, its 100 ns counter counts up.
    
    Calling this routine on a running timer causes the timer to be reset to
    the new period.  The up counter is unaffected.
    
    It is only valid to call this routine on a SYSINTR that was allocated
    by InterruptConnectTimer.  Invalid SYSINTR's will return FALSE and do
    nothing.

    Calling this routine on a SYSINTR that hasn't been initialized with
    InterruptInitialize is undefined and will have unpredictable results.

    Specifying a period that is too small for the system to achieve will
    result in the timer being set to the minimum possible time to cause
    an interrupt, possible immediately.  This will likely crash the system.

Arguments:

    SysIntr     The SYSINTR associated with the timer to start.

    PeriodHns   Desired timer period in 100 ns intervals.

Return Value:

    Returns TRUE if successful, FALSE otherwise.

--*/
{
    INTR_START_TIMER_IOCTL_PARAM Args;
    BOOLEAN Result;
    ULONG ResultSize;

    Args.SysIntr   = SysIntr;
    Args.PeriodHns = PeriodHns;

    KernelIoControl(
        IOCTL_HAL_INTR_START_TIMER,
        (PVOID)&Args,
        sizeof(INTR_START_TIMER_IOCTL_PARAM),
        &Result,
        sizeof(BOOLEAN),
        &ResultSize
        );

    return Result;
}



BOOLEAN
InterruptStopTimer(
    IN ULONG SysIntr
    )
/*++

Routine Description:

    Stops the timer associated with the specified SYSINTR.  After being
    stopped, the timer ceases to generate interrupts, but all resources
    remain allocated.  The timer's up counter is also stopped.
    
    It is only valid to call InterruptStopTimer on a timer allocated with
    InterruptConnectTimer.  The routine will return FALSE and do nothing
    if an invalid SYSINTR value is specified.
  
    Calling the routine on a running timer stops the timer and halts the
    up counter.

    Calling the routine on a stopped timer does nothing.

Arguments:

    SysIntr     SYSINTR associated with the timer to stop.

Return Value:

    Returns TRUE if successful, FALSE otherwise.

--*/
{
    BOOLEAN Result;
    ULONG ResultSize;

    KernelIoControl(
        IOCTL_HAL_INTR_STOP_TIMER,
        (PVOID)&SysIntr,
        sizeof(ULONG),
        &Result,
        sizeof(BOOLEAN),
        &ResultSize
        );

    return Result;
}
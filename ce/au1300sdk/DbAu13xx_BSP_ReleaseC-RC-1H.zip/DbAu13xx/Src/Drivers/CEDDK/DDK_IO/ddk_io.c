//
// Copyright (c) Microsoft Corporation.  All rights reserved.
// Copyright (c) 2002,2004 BSQUARE Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:  

    ddk_io.c

Abstract:  

    WINCE device driver support routines.  This file supports
    a very minimal subset of the routines from ntddk.h

    
Functions:


Notes:

--*/
#include <windows.h>
#include <bldver.h>

static __inline void WBSYNC (VOID)
{
	__asm("sync");
}


//
//  I/O space read and write functions.
//
//  These are implemented as functions in ceddk.dll, since only the platform
//  architect knows for sure how the peripherals are mapped to the chip.  An
//  appropriate DLL must then be written for each platform if the default DLL
//  is not appropriate.
//
//  The READ/WRITE_REGISTER_* calls manipulate I/O registers in MEMORY space.
//  (Use x86 move instructions, with LOCK prefix to force correct behavior
//   w.r.t. caches and write buffers.)
//
//  The READ/WRITE_PORT_* calls manipulate I/O registers in PORT space.
//  (Use x86 in/out instructions.)
//

ULONG READ_REGISTER_ULONG(PULONG Register)
{
    return *(volatile unsigned long * const)Register;
}

VOID WRITE_REGISTER_ULONG(PULONG Register, ULONG value)
{
    
    WBSYNC();
    *(volatile unsigned long * const)Register = value;
    WBSYNC();
}


USHORT READ_REGISTER_USHORT(PUSHORT Register)
{
    return *(volatile unsigned short * const)Register;
}

VOID WRITE_REGISTER_USHORT(PUSHORT Register, USHORT value)
{
    WBSYNC();
    *(volatile unsigned short * const)Register = value;
    WBSYNC();
}

UCHAR READ_REGISTER_UCHAR(PUCHAR Register)
{
    return *(volatile unsigned char * const)Register;
}

VOID WRITE_REGISTER_UCHAR(PUCHAR Register, UCHAR value)
{
    WBSYNC();
    *(volatile unsigned char * const)Register = value;
    WBSYNC();
}

#pragma warning(disable: 4035)  // disable warning for "no return value"

#if CE_MAJOR_VER >= 5
// FIX!!! CE50 doesn't like the volatile
#define volatile
#endif

UCHAR
READ_PORT_UCHAR(
    PUCHAR  Port
    )
{
    return *(volatile PUCHAR const)Port;
}


USHORT
READ_PORT_USHORT(
    PUSHORT Port
    )
{
    return *(volatile PUSHORT const)Port;
}


ULONG
READ_PORT_ULONG(
    PULONG  Port
    )
{
    return *(volatile PULONG const)Port;
}
#pragma warning(default: 4035)  // restore the default setting

VOID
WRITE_PORT_UCHAR(
    PUCHAR  Port,
    UCHAR   Value
    )
{
    WBSYNC();
    *(volatile PUCHAR const)Port = Value;
    WBSYNC();
}


VOID
WRITE_PORT_USHORT(
    PUSHORT Port,
    USHORT  Value
    )
{
    WBSYNC();
    *(volatile PUSHORT const)Port = Value;
    WBSYNC();
}


VOID
WRITE_PORT_ULONG(
    PULONG  Port,
    ULONG   Value
    )
{
    WBSYNC();
    *(volatile PULONG const)Port = Value;
    WBSYNC();
}





VOID
READ_REGISTER_BUFFER_UCHAR(
    PUCHAR  Register,
    PUCHAR  Buffer,
    ULONG   Count
    )
{
    while( Count-- )
         *Buffer++ = *(volatile PUCHAR const)Register;
}


VOID
READ_REGISTER_BUFFER_USHORT(
    PUSHORT Register,
    PUSHORT Buffer,
    ULONG   Count
    )
{
    while( Count-- )
         *Buffer++ = *(volatile PUSHORT const)Register;
}


VOID
READ_REGISTER_BUFFER_ULONG(
    PULONG  Register,
    PULONG  Buffer,
    ULONG   Count
    )
{
    while( Count-- )
         *Buffer++ = *(volatile PULONG const)Register;
}





VOID
WRITE_REGISTER_BUFFER_UCHAR(
    PUCHAR  Register,
    PUCHAR  Buffer,
    ULONG   Count
    )
{
    while ( Count-- ) {
        WBSYNC();    
        *(volatile PUCHAR const)Register = *Buffer++;        
    }
    WBSYNC();
}


VOID
WRITE_REGISTER_BUFFER_USHORT(
    PUSHORT Register,
    PUSHORT Buffer,
    ULONG   Count
    )
{
    while ( Count-- ) {
        WBSYNC();        
        *(volatile PUSHORT const)Register = *Buffer++;
    }
    WBSYNC();
}


VOID
WRITE_REGISTER_BUFFER_ULONG(
    PULONG  Register,
    PULONG  Buffer,
    ULONG   Count
    )
{
    while ( Count-- ) {
        WBSYNC();    
        *(volatile PULONG const)Register = *Buffer++;
    }
    WBSYNC();
}



VOID
READ_PORT_BUFFER_UCHAR(
    PUCHAR  Port,
    PUCHAR  Buffer,
    ULONG   Count
    )
{
    while( Count-- )
        *Buffer++ = *(volatile PUCHAR const)Port;
}


VOID
READ_PORT_BUFFER_USHORT(
    PUSHORT Port,
    PUSHORT Buffer,
    ULONG   Count
    )
{
    while( Count-- )
        *Buffer++ = *(volatile PUSHORT const)Port;
}


VOID
READ_PORT_BUFFER_ULONG(
    PULONG  Port,
    PULONG  Buffer,
    ULONG   Count
    )
{
    while( Count-- )
        *Buffer++ = *(volatile PULONG const)Port;
}




VOID
WRITE_PORT_BUFFER_UCHAR(
    PUCHAR  Port,
    PUCHAR  Buffer,
    ULONG   Count
    )
{
    while ( Count-- ) {
        WBSYNC();
        *(volatile PUCHAR const)Port = *Buffer++;
    }
    WBSYNC();
}


VOID
WRITE_PORT_BUFFER_USHORT(
    PUSHORT Port,
    PUSHORT Buffer,
    ULONG   Count
    )
{
    while ( Count-- ) {
        WBSYNC();
        *(volatile PUSHORT const)Port = *Buffer++;
    }
    WBSYNC();
}


VOID
WRITE_PORT_BUFFER_ULONG(
    PULONG  Port,
    PULONG  Buffer,
    ULONG   Count
    )
{
    while ( Count-- ) {
        WBSYNC();
        *(volatile PULONG const)Port = *Buffer++;
    }
    WBSYNC();
}











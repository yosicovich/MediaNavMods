/*++
Copyright (c) 1998, 1999, 2003  BSQUARE Corporation.  All rights reserved.

Module Name:

    mmmap.c

Abstract:

    This module implements the physical memory mapping portion of the
	memory management for CE drivers.

Author:

    Jason W. Murray 6-March-1998

Revision History:

    7-Sept-1999 Richard Chinn

        Changed include to support precompiled headers.

--*/

#include "bceddk.h"


//
// Private members
//

static
ULONG
PageAlignPhysicalRange(
    IN OUT PPHYSICAL_ADDRESS PhysicalAddress,
    IN OUT PULONG NumberOfBytes
    )
{
    PHYSICAL_ADDRESS TempPhysicalAddress;
    ULONG Offset;

    // Use the page alignment macro to align the address
    TempPhysicalAddress.LowPart = (ULONG)PAGE_ALIGN(PhysicalAddress->LowPart);

    TempPhysicalAddress.HighPart = PhysicalAddress->HighPart;

    // Calculate the difference of this adjustment
    Offset = PhysicalAddress->LowPart - TempPhysicalAddress.LowPart;

    // Assign Adjust the user parameter
    PhysicalAddress->QuadPart = TempPhysicalAddress.QuadPart;

    // Adjust the number of bytes.
    *NumberOfBytes += Offset;

    // Round the Number of bytes up to a page aligned size
    *NumberOfBytes = ROUND_TO_PAGES(*NumberOfBytes);

    return Offset;
}

//
// Exported members
//


PVOID
MmMapIoSpace(
    IN PHYSICAL_ADDRESS PhysicalAddress,
    IN ULONG NumberOfBytes,
    IN BOOLEAN CacheEnable
    )
{
    PVOID BaseAddress;
    ULONG VirtualCopyFlags;
    BOOL Status;
    ULONG PageAlignDifferential;

    // Create a page aligned physical address and adjust the number
    // bytes we are allocating.  Also, determine the amount of bytes in the
    // differential from the page boundary to the actual address being
    // requested to map.
    PageAlignDifferential = PageAlignPhysicalRange(
        &PhysicalAddress,
        &NumberOfBytes
        );

    // Allocate space for the requested mapping by making a call to
    // VirtualAlloc with the MEM_RESERVE flag set.
    BaseAddress = VirtualAlloc(
        0,
        NumberOfBytes,
        MEM_RESERVE,
        PAGE_NOACCESS
        );

    // VirtualAlloc returns NULL on failure.
    if(BaseAddress == NULL) {
        goto ErrorReturn;
    }

    // Based on the cache enable flag determine the paramaters to
    // virtual copy.
    VirtualCopyFlags = PAGE_READWRITE | PAGE_PHYSICAL;

    if(CacheEnable == FALSE)
        VirtualCopyFlags |= PAGE_NOCACHE;

    // We want to create a mapping to the specified physical location so
    // use virtual copy to perform this mapping.
    Status = VirtualCopy(
        BaseAddress,
        (PVOID)(PhysicalAddress.QuadPart >> 8),
        NumberOfBytes,
        VirtualCopyFlags
        );


    // VirtualCopy returns FALSE if it fails.
    if(Status == FALSE) {

        VirtualFree(
            BaseAddress,
            0,
            MEM_RELEASE
            );

        BaseAddress = NULL;
        goto ErrorReturn;
    }


    ((PUCHAR)BaseAddress) += PageAlignDifferential;

ErrorReturn:

    return BaseAddress;
}


VOID
MmUnmapIoSpace(
    IN PVOID BaseAddress,
    IN ULONG NumberOfBytes
    )

{
    PVOID PageAlignedBaseAddress;

    // Adjust the virtual base address to a page aligned address.
    // Use the page alignment macro to align the address
    PageAlignedBaseAddress = (PVOID)PAGE_ALIGN(BaseAddress);

    // Free the memory
    VirtualFree(
        PageAlignedBaseAddress,
        0,
        MEM_RELEASE
        );

}




BOOL
TransBusAddrToVirtual(
    IN INTERFACE_TYPE InterfaceType,
    IN ULONG BusNumber,
    IN PHYSICAL_ADDRESS BusAddress,
    IN ULONG Length,
    IN OUT PULONG AddressSpace,
    OUT PPVOID MappedAddress
    )
{
    PHYSICAL_ADDRESS TranslatedAddr;
    BOOL Status = FALSE;

    if (HalTranslateBusAddress(InterfaceType, BusNumber, BusAddress, AddressSpace, &TranslatedAddr)) {


        // Memory-mapped I/O, get virtual address for translated physical address
        *MappedAddress = MmMapIoSpace(TranslatedAddr, Length, FALSE);

        if (NULL != (*MappedAddress)) {
            Status = TRUE;
        }
    }

    return Status;
}


/*
    TransBusAddrToStatic Creates a virtual address mapping that is usable
    by all processes.


*/
BOOL
TransBusAddrToStatic(
    IN INTERFACE_TYPE InterfaceType,
    IN ULONG BusNumber,
    IN PHYSICAL_ADDRESS BusAddress,
    IN ULONG Length,
    IN OUT PULONG AddressSpace,
    OUT PPVOID MappedAddress
    )
{
    PHYSICAL_ADDRESS TranslatedAddr;
    BOOL Status = FALSE;

    if (HalTranslateBusAddress(InterfaceType, BusNumber, BusAddress, AddressSpace, &TranslatedAddr))
    {
		/*
		 * In all CE versions to date, CreateStaticMapping does not work
		 * for anything but 32-bit physical addresses. See kernel code,
		 * mdsched.c, NKCreateStaticMapping() for full details.
		 *
		 * To combat this, the TranslatedAddr is examined to see if it
		 * is a 32-bit or 36-bit physical address. For 32-bit physical
		 * addresses, call the kernel version. For 36-bit physical
		 * addresses, invoke the HalCreateBlockMapping().
		 */
		if (TranslatedAddr.HighPart == 0)
		{
	        // Memory-mapped I/O, get statically-mapped virtual address for translated physical address
	        // Page align source and adjust size to compensate
	        ULONG AlignedAddr;
	        ULONG AlignedSize = Length + (TranslatedAddr.LowPart & (PAGE_SIZE - 1));

			RETAILMSG(1,(L"\r\nTransBusAddrToStatic  BA=%x%08x ", BusAddress.HighPart, BusAddress.LowPart));

	        AlignedAddr = (ULONG)((TranslatedAddr.QuadPart & ~(PAGE_SIZE - 1)) >> 8);

			RETAILMSG(1,(L"TA=%x%08x ",
	        TranslatedAddr.HighPart,TranslatedAddr.LowPart));

			RETAILMSG(1,(L"CreateStaticMapping(%x, %x) = ",  AlignedAddr, AlignedSize));

	        *MappedAddress = CreateStaticMapping((ULONG)AlignedAddr, AlignedSize);

	        // Adjust with offset from page
	        (DWORD)*MappedAddress += TranslatedAddr.LowPart & (PAGE_SIZE - 1);

			RETAILMSG(1,(L" %x\r\n", *MappedAddress ));
		}
		else
		{
			*MappedAddress = HalCreateBlockMapping(TranslatedAddr, Length, FALSE);
		}

        if (*MappedAddress != NULL)
            Status = TRUE;
    }
    return Status;
}


#define PAGEMASK_4KB	0x00000000
#define PAGEMASK_16KB	0x00006000
#define PAGEMASK_64KB	0x0001E000
#define PAGEMASK_256KB	0x0007E000
#define PAGEMASK_1MB	0x001FE000
#define PAGEMASK_4MB	0x007FE000
#define PAGEMASK_16MB	0x01FFE000

#define ENTRYLO_D		(1<<2)
#define ENTRYLO_V		(1<<1)
#define ENTRYLO_G		(1<<0)

/*
 * This routine will populate a Wired TLB entry (thus creating a
 * static mapping) with a globally visible virtual address. This
 * is useful for mapping large contiguous blocks > 4KB.
 */
PVOID
HalCreateBlockMapping(
    IN PHYSICAL_ADDRESS physAddr,
	IN ULONG size,
	IN ULONG cca
	)
{
	ULONG dwVA, dwPA0, dwPA1, dwPM, dwOffset;
	ULONG pageSize, alignSize;
	int i;

	RETAILMSG(1,(TEXT("HalCreateBlockMapping(%08X%08X,%08X,%d)\r\n"), physAddr.HighPart, physAddr.LowPart, size, cca));

	if (size == 0)
		return NULL;

	// Determine if physAddr + Length is covered by a SINGLE 4KB page
	pageSize = 4*1024;
	if ((physAddr.LowPart & ~(pageSize-1)) == ((physAddr.LowPart+size-1) & ~(pageSize-1)))
	{
		// Can use VirtualAlloc() and VirtualCopy() instead, no need to
		// consume a Wired TLB for this case (most common case, GIISR)
		// VirtualAlloc(2MB) is a bit wasteful, but hey its only virtual space
		dwVA = (ULONG)VirtualAlloc(
			/* lpAddress */ NULL,
			/* dwSize */	2*1024*1024, // global alloc
			/* flAllocationType */ MEM_RESERVE,
			/* flProtect */ PAGE_NOACCESS);

		if (dwVA != (ULONG)NULL)
		{
			// Compute offset
			dwOffset = physAddr.LowPart & (pageSize-1);
			dwPA0 = (ULONG)(physAddr.QuadPart >> 8);
			dwPA0 &= ~((pageSize-1)>>8);

			i = VirtualCopy(
				(PVOID)dwVA,
				(PVOID)dwPA0,
				pageSize, //2*1024*1024,
				PAGE_READWRITE | PAGE_PHYSICAL | PAGE_NOCACHE);

			if (i == TRUE)
				dwVA += dwOffset;
			else
			{
				VirtualFree((PVOID)dwVA, 0, MEM_RELEASE);
				dwVA = 0;
			}
		}

		return (PVOID)dwVA;
	}

	dwVA = dwPA0 = dwPA1 = dwPM = 0;

	for (i = 0; i < 8; ++i)
	{
		// Find smallest PageMask that can map requested space
		switch (i)
		{
		case 0: dwPM = PAGEMASK_4KB;	pageSize = 4*1024; break;
		case 1: dwPM = PAGEMASK_16KB;	pageSize = 16*1024; break;
		case 2: dwPM = PAGEMASK_64KB;	pageSize = 64*1024; break;
		case 3: dwPM = PAGEMASK_256KB;	pageSize = 256*1024; break;
		case 4: dwPM = PAGEMASK_1MB;	pageSize = 1*1024*1024; break;
		case 5: dwPM = PAGEMASK_4MB;	pageSize = 4*1024*1024; break;
		case 6: dwPM = PAGEMASK_16MB;	pageSize = 16*1024*1024; break;
		default:
			dwPM = 0; pageSize = 0; break;
		}

		// unable to find a valid set
		if (pageSize == 0)
			break;

		// Determine if physAddr + Length is covered by PageMask
		if ((physAddr.LowPart & ~(2*pageSize-1)) !=
			((physAddr.LowPart+size-1) & ~(2*pageSize-1)))
			continue;

		// Compute PA0, PA1 (PA0 and PA1 are adjacent addresses)
		dwPA0 = (ULONG)(physAddr.QuadPart >> 6);
		dwPA0 &= ~0x0000003F;
		dwPA1 = dwPA0 + (pageSize >> 6);

		// Compute offset
//		dwOffset = physAddr.LowPart & (2*pageSize-1);
		dwOffset = 0;

		// size to VirtualAlloc() must be >= 2MB for global alloc
		alignSize = 2*pageSize;
		if (alignSize < 2*1024*1024)
			alignSize = 2*1024*1024;

#if _WINCEOSVER < 600
		dwVA = (ULONG)VirtualAlloc(
			/* lpAddress */ NULL,
			/* dwSize */	2*alignSize, // guarantee aligned VA range within
			/* flAllocationType */ MEM_RESERVE,
			/* flProtect */ PAGE_NOACCESS);
#else
		dwVA = (ULONG)VirtualAllocEx(
			(HANDLE)GetDirectCallerProcessId(),
			/* lpAddress */ NULL,
			/* dwSize */	2*alignSize, // guarantee aligned VA range within
			/* flAllocationType */ MEM_RESERVE,
			/* flProtect */ PAGE_READWRITE);
#endif

		if (dwVA != (ULONG)NULL)
		{
			// Extract properly aligned VA for PageSize
			// NOTE: If pageSize < 1MB, not all VA actually populated
			dwVA += (2*pageSize - 1);
			dwVA &= ~(2*pageSize - 1);

			// Validate CCA setting
			if (cca == FALSE) cca = 2;
			if (cca == TRUE) cca = 3;
			cca &= 0x7;

			dwPA0 |= ((cca<<3) | ENTRYLO_D | ENTRYLO_V | ENTRYLO_G);
			dwPA1 |= ((cca<<3) | ENTRYLO_D | ENTRYLO_V | ENTRYLO_G);

			RETAILMSG(1,(TEXT(" HalCreateBlockMapping(): VA=%08X, PA0=%08X, PA1=%08X, PM=%08X\r\n"), dwVA, dwPA0, dwPA1, dwPM));

			HalAddWiredTLB(dwVA, dwPA0, dwPA1, dwPM);

//			dwVA += dwOffset;
		}
		else
			RETAILMSG(1,(TEXT("HalCreateBlockMapping() VirtualAlloc(%d bytes) failed\r\n"), 2*alignSize));

		break;
	}

	return (PVOID)dwVA;
}


int
HalAddWiredTLB
(
	IN ULONG EntryHi,
	IN ULONG EntryLo0,
	IN ULONG EntryLo1,
	IN ULONG PageMask
    )
{
    ADD_WIRED_TLB_IOCTL_PARAM Param;
    ULONG Result;
    ULONG ResultSize;

    Param.EntryHi = EntryHi;
    Param.EntryLo0 = EntryLo0;
    Param.EntryLo1 = EntryLo1;
    Param.PageMask = PageMask;

    KernelIoControl(
        IOCTL_HAL_ADD_WIRED_TLB,
        (PVOID)&Param,
        sizeof(ADD_WIRED_TLB_IOCTL_PARAM),
        &Result,
        sizeof(ULONG),
        &ResultSize
        );

    return Result;
}


/*++
Copyright (c) 1998,2005  BSQUARE Corporation.  All rights reserved.

Module Name:

    mmmdl.c

Abstract:

    This module implements the MDL support routines for BCEDDK.

Author:

    Richard Chinn   22-June-1998

Revision History:

    7-Sept-1999 Richard Chinn

        Changed include to support precompiled headers.

--*/

#include <bceddk.h>

VOID
MmMdlEntry(
    VOID
    )

/*++

Routine Description:

    This routine is called to perform any initialization for the MDL support
    routines.

Arguments:

    None.

Return Value:

    None.

--*/

{
    return;
}



PMDL
MmCreateMdl(
    IN PMDL MemoryDescriptorList,
    IN PVOID BaseVa,
    IN ULONG Length
    )

/*++

Routine Description:

    This allocates a new MDL (if necessary), initializes the header of
    the Memory Descriptor List (MDL), locks down the corresponding virtual
    buffer and writes into the MDL the corresponding physical pages for
    each virtual page in the buffer.

Arguments:

    MemoryDescriptorList - Pointer to the MDL to initialize.  If this
        parameter is NULL, a new MDL is allocated.

    BaseVa - Base virtual address to be mapped by the MDL.

    Length - Length in bytes of the buffer to be mapped by the MDL.

Return Value:

    The initialized MDL.

--*/

{
    ULONG  LockStartAddress;
    ULONG  LockEndAddress;
    ULONG  LockOffset;
    ULONG  LockLength;
    ULONG  NumberOfPages;
    PMDL   pNewMdl;
    PULONG pPFNs;
    BOOL   AllocatedMdlLocally;
    BOOL   bRet;
    ULONG  i;

    //
    // Calculate the boundaries and the number of pages the user wants locked.
    //
    LockStartAddress = (ULONG)PAGE_ALIGN(BaseVa);
    LockOffset       = (ULONG)BaseVa - LockStartAddress;
    LockEndAddress   = LockStartAddress + LockOffset + Length;
    LockLength       = LockEndAddress - LockStartAddress;
    NumberOfPages    = ADDRESS_AND_SIZE_TO_SPAN_PAGES(LockStartAddress,
                                                      LockLength);

//	RETAILMSG(1,(TEXT("CreateMDL: (0x%08X,%d) -> LockSA = 0x%08X, LockOffset = 0x%X, NumberOfPages %d LockLength 0x%X\r\n"),
//	                 BaseVa,Length,LockStartAddress,LockOffset,NumberOfPages,LockLength));

    //
    // If the MemoryDescriptorList parameter is NULL, we need to allocate
    // space for a new MDL.  Otherwise, MemoryDescriptorList points to the
    // space for the new MDL.
    //
    if (MemoryDescriptorList == NULL) {
        //
        // Allocate a new MDL
        //
        pNewMdl = LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT,
                             sizeof(MDL) + sizeof(PULONG) * NumberOfPages);

        //
        // Verify that we allocated the MDL.
        //
        if (pNewMdl == NULL) {
            return NULL;
        }

        AllocatedMdlLocally = TRUE;
    } else {
        //
        // The new MDL is already allocated by the caller.
        //
        pNewMdl = MemoryDescriptorList;
        AllocatedMdlLocally = FALSE;
    }

    //
    // Initialize the MDL header.
    //
    MmInitializeMdl(pNewMdl, BaseVa, Length);
	pNewMdl->ByteOffset = LockOffset;

    //
    // Keep track of how the MDL was allocated so MmFreeMdl will be able
    // to determine if the memory needs to be deallocated.
    //
    if (!AllocatedMdlLocally) {
        pNewMdl->MdlFlags |= MDL_ALLOCATED_FIXED_SIZE;
    }

    //
    // The physical addresses are placed right after the header of the MDL.
    // This pointer will be passed to LockPages which will write an array
    // of page frame numbers at this location.
    //
    pPFNs = (PULONG)(pNewMdl + 1);

    //
    // Lock down the pages in the specified range and get the list of page
    // frame numbers.
    //
    bRet = LockPages((PVOID)LockStartAddress,
                     LockLength,
                     pPFNs,
                     LOCKFLAG_READ);

    //
    // Verify that the lock down was successful.
    //
    if (bRet == FALSE) {
		RETAILMSG(1,(TEXT("MmCreateMdl: Failed to lock pages (Error Code %d)\r\n"),GetLastError()));
        if (AllocatedMdlLocally) {
            LocalFree(pNewMdl);
        }
        return NULL;
    }

    //
    // Translate the PFNs into physical addresses.
    //
    for (i = 0; i < NumberOfPages; i++) {
        pPFNs[i] <<= UserKInfo[KINX_PFN_SHIFT];
    }

    //
    // Return the initialized MDL.
    //
    return pNewMdl;
}


VOID
MmFreeMdl(
    IN PMDL MemoryDescriptorList
    )

/*++

Routine Description:

    This routine unlocks the locked down pages in the MDL.  After unlocking
    the pages, it checks how the MDL was allocated.  If the MDL was
    allocated statically, the MDL header is wiped with 0s.  If the MDL was
    allocated dynamically by MmCreateMdl, the MDL is deallocated.

Arguments:

    MemoryDescriptorList - MDL to be freed.

Return Value:

    None.

--*/

{
    PVOID UnlockAddress;
    ULONG UnlockLength;

    //
    // Do some simple error checking.
    //
    if (MemoryDescriptorList == NULL) {
        return;
    }


    //
    // Calculate the address and length parameters to be passed
    // to UnlockPages.
    //
    UnlockAddress = (PUCHAR)MemoryDescriptorList->StartVa - MemoryDescriptorList->ByteOffset;
    UnlockLength =  MemoryDescriptorList->ByteCount + MemoryDescriptorList->ByteOffset;

    //
    // Unlock the pages.
    //
    UnlockPages(UnlockAddress, UnlockLength);

    //
    // Free or wipe the MDL, depending how the MDL was allocated.
    //
    if (MemoryDescriptorList->MdlFlags & MDL_ALLOCATED_FIXED_SIZE) {
        //
        // MDL was allocated statically so just wipe the header.
        //
        MmInitializeMdl(MemoryDescriptorList, 0, 0);
    } else {
        //
        // MDL was allocated dynamically by MmCreateMdl so we need
        // to do a LocalFree.
        //
        LocalFree(MemoryDescriptorList);
    }

    return;
}

/*++
Copyright (c) 2004  BSQUARE Corporation.  All rights reserved.

Module Name:

    ddk_dma.c

Module Description:

    This file simply includes the appropriate dma implementation for the platform.
	I would have preferred this to be in the sources file but it seems that it
	doesn't get processed in there.

Author:

    Ian Rae   January 2004
--*/

#include <windows.h>
#include <platform.h>

#if defined(DDMA_PHYS_ADDR)
#include "ddma_au1x.c"
#else
#include "dma_au1x.c"
#endif

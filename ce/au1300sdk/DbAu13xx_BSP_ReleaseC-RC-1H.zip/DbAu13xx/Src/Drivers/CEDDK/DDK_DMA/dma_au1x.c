/*++
Copyright (c) 1998-2005  BSQUARE Corporation.  All rights reserved.

Module Name:

    dma_au1x.c

Module Description:

	Contains the DMA API implementation for the Au1x DMA

Author:

    Richard Chinn   8-July-1998

Revision History:

    12-Oct-1998     Richard Chinn
    Fixed GetNextMdlContiguousBlock routine determining CurrentVaPageIndex.

    April 2001      GJS
    Ported to MIPS Au1000 internal bus. Not much to do here.
    
--*/
#include "bceddk.h"
#include "au1x00.h"

#define MSGS	0

// buffers must be 32 byte aligned
#define DMA_ALIGNMENT_REQUIREMENT      32

// Strcuture to hold configuration information for each of the peripherals 
// the DMA controller can service.
typedef struct {
	BOOL  Valid;		// Flag to indicate this logical device is valid
	ULONG DmaMode;		// DDMA channel cfg
	ULONG FifoAddr;		// FIFO Address for peripheral
	BOOL  DevIsRead;	// Is this a read transaction ?
	WCHAR *Name;
} DMA_DEVICE_CONFIG;

static DMA_DEVICE_CONFIG DmaConfig[MAX_DMA_LOGICAL_DEVICES];
//
// CHANNEL_OBJECT structure definition.  A forward declaration for this
// structure is in bceddk.h.  This is the real definition.
//
struct _CHANNEL_OBJECT {
	// Au1x specific bits
    ULONG   DmaChannel;
    ULONG   FIFOAddress;
	ULONG   BufferSize;
	ULONG   DeviceWidth;
	BOOL    DeviceRead;
    HANDLE  hChannelMutex;

	ULONG   SavedMode;
	BOOL    InterruptsEnabled;
	DMA_LOGICAL_DEVICE	DeviceID;

    AU1X00_DMA* DmaRegPtr;

	PVOID   pBufferA;
	PVOID	pBufferB;
	PHYSICAL_ADDRESS BufferAPhys;
	PHYSICAL_ADDRESS BufferBPhys;
	WCHAR *Name;
};

typedef struct _CHANNEL_OBJECT CHANNEL_OBJECT, *PCHANNEL_OBJECT;

//
// Static Globals
//

//
// Table of mutex names for each DMA channel.  These are used to create
// named mutexes for allocating DMA channels.
//
static TCHAR* DmaChannelMutexNames[NUM_DMA_CHANNELS] = {
    TEXT("__DMA_CHANNEL_MUTEX_0__"),
    TEXT("__DMA_CHANNEL_MUTEX_1__"),
    TEXT("__DMA_CHANNEL_MUTEX_2__"),
    TEXT("__DMA_CHANNEL_MUTEX_3__"),
    TEXT("__DMA_CHANNEL_MUTEX_4__"),
    TEXT("__DMA_CHANNEL_MUTEX_5__"),
    TEXT("__DMA_CHANNEL_MUTEX_6__"),
    TEXT("__DMA_CHANNEL_MUTEX_7__")
};

//
// Table of pointers to each DMA channel.
//
static AU1X00_DMA* DmaChannel[NUM_DMA_CHANNELS];

//
// Private Routines
//

    
//
// Exported Routines
//
    
VOID
DmaEntry(
    VOID
    )

/*++

Routine Description:

    This routine is called when the BCEDDK loaded for each process.  It
    performs initialization to make the DMA portion of the BCEDDK usable.

Arguments:

    None.

Return Value:

    None.

--*/
{
    AU1X00_DMA *DmaControllerBase;    
    ULONG       i;
	HKEY        hKey;
	DWORD       reservedChannels = 0;

	// Open the registry to find out if there are any 
	// reserved DMA channels that we should not allocate
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,TEXT("Drivers\\BCEDDK"),0,0,&hKey) == ERROR_SUCCESS) {
		RegQueryValueEx(hKey,TEXT("ReservedDMAChannels"),0,NULL,(PUCHAR)&reservedChannels,&i);
		RegCloseKey(hKey);
	}

	// Create mutexes for any reserved channels so they appear to be in-use
	for (i = 0; i < NUM_DMA_CHANNELS; i++) {
		if (reservedChannels & (1<<i)) {
			CreateMutex(NULL,FALSE,DmaChannelMutexNames[i]);
		}
	}

	RETAILMSG(1,(TEXT("Reserved = %08X\r\n"),reservedChannels));

    DmaControllerBase = (AU1X00_DMA *)DMA0_PHYS_ADDR;

    for (i = 0; i < NUM_DMA_CHANNELS; i++) {
        DmaChannel[i] = DmaControllerBase++;
    }

	// Setup the configuration entries for the logical DMA devices we support
	// AC97 Transmit
	DmaConfig[DMA_AC97_TX].Valid     = TRUE;
	DmaConfig[DMA_AC97_TX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_AC97_TX) |
	                                   DMA_MODE_TS | DMA_MODE_DW_16 |
									   DMA_MODE_BE;
	DmaConfig[DMA_AC97_TX].FifoAddr  = AC97_PHYS_ADDR + AC97_DATA;
	DmaConfig[DMA_AC97_TX].DevIsRead = FALSE;
	DmaConfig[DMA_AC97_TX].Name      = TEXT("AC97  TX");

	// AC97 Receive
	DmaConfig[DMA_AC97_RX].Valid     = TRUE;
	DmaConfig[DMA_AC97_RX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_AC97_RX) |
	                                   DMA_MODE_TS | DMA_MODE_DW_16 |
									   DMA_MODE_BE | DMA_MODE_DR;
	DmaConfig[DMA_AC97_RX].FifoAddr  = AC97_PHYS_ADDR + AC97_DATA;
	DmaConfig[DMA_AC97_RX].DevIsRead = TRUE;
	DmaConfig[DMA_AC97_RX].Name      = TEXT("AC97  RX");

	// USB Device Endpoint 0 Transmit
	DmaConfig[DMA_USBD_EP0_TX].Valid     = TRUE;
	DmaConfig[DMA_USBD_EP0_TX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_USB_EP0_TX) |
	                                       DMA_MODE_DW_8;
	DmaConfig[DMA_USBD_EP0_TX].FifoAddr  = USBD_PHYS_ADDR + USBD_EP0WR;
	DmaConfig[DMA_USBD_EP0_TX].DevIsRead = FALSE;
	DmaConfig[DMA_USBD_EP0_TX].Name      = TEXT("USBD0 TX");

	// USB Device Endpoint 0 Receive
	DmaConfig[DMA_USBD_EP0_RX].Valid     = TRUE;
	DmaConfig[DMA_USBD_EP0_RX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_USB_EP0_RX) |
	                                       DMA_MODE_DW_8 | DMA_MODE_DR;
	DmaConfig[DMA_USBD_EP0_RX].FifoAddr  = USBD_PHYS_ADDR + USBD_EP0RD;
	DmaConfig[DMA_USBD_EP0_RX].DevIsRead = TRUE;
	DmaConfig[DMA_USBD_EP0_RX].Name      = TEXT("USBD0 RX");

	// USB Device Endpoint 1 Transmit
	DmaConfig[DMA_USBD_EP1_TX].Valid     = TRUE;
	DmaConfig[DMA_USBD_EP1_TX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_USB_EP1_TX) |
	                                       DMA_MODE_DW_8;
	DmaConfig[DMA_USBD_EP1_TX].FifoAddr  = USBD_PHYS_ADDR + USBD_EP1WR;
	DmaConfig[DMA_USBD_EP1_TX].DevIsRead = FALSE;
	DmaConfig[DMA_USBD_EP1_TX].Name      = TEXT("USBD1 TX");

	// USB Device Endpoint 2 Transmit
	DmaConfig[DMA_USBD_EP2_TX].Valid     = TRUE;
	DmaConfig[DMA_USBD_EP2_TX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_USB_EP2_TX) |
	                                       DMA_MODE_DW_8;
	DmaConfig[DMA_USBD_EP2_TX].FifoAddr  = USBD_PHYS_ADDR + USBD_EP2WR;
	DmaConfig[DMA_USBD_EP2_TX].DevIsRead = FALSE;
	DmaConfig[DMA_USBD_EP2_TX].Name      = TEXT("USBD2 TX");

	// USB Device Endpoint 3 Receive
	DmaConfig[DMA_USBD_EP3_RX].Valid     = TRUE;
	DmaConfig[DMA_USBD_EP3_RX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_USB_EP3_RX) |
	                                       DMA_MODE_DW_8 | DMA_MODE_DR;
	DmaConfig[DMA_USBD_EP3_RX].FifoAddr  = USBD_PHYS_ADDR + USBD_EP3RD;
	DmaConfig[DMA_USBD_EP3_RX].DevIsRead = TRUE;
	DmaConfig[DMA_USBD_EP3_RX].Name      = TEXT("USBD3 RX");

	// USB Device Endpoint 4 Receive
	DmaConfig[DMA_USBD_EP4_RX].Valid     = TRUE;
	DmaConfig[DMA_USBD_EP4_RX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_USB_EP4_RX) |
	                                       DMA_MODE_DW_8 | DMA_MODE_DR;
	DmaConfig[DMA_USBD_EP4_RX].FifoAddr  = USBD_PHYS_ADDR + USBD_EP4RD;
	DmaConfig[DMA_USBD_EP4_RX].DevIsRead = TRUE;
	DmaConfig[DMA_USBD_EP4_RX].Name      = TEXT("USBD4 RX");
#ifdef SD0_PHYS_ADDR
	// SD Slot 0 Transmit
	DmaConfig[DMA_SD0_TX].Valid     = TRUE;
	DmaConfig[DMA_SD0_TX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_SD0_TX) | DMA_MODE_DS;
	DmaConfig[DMA_SD0_TX].FifoAddr  = SD0_PHYS_ADDR + SD_TXPORT;
	DmaConfig[DMA_SD0_TX].DevIsRead = FALSE;
	DmaConfig[DMA_SD0_TX].Name      = TEXT("SDIO0 TX");

	// SD Slot 0 Receive
	DmaConfig[DMA_SD0_RX].Valid     = TRUE;
	DmaConfig[DMA_SD0_RX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_SD0_RX) | DMA_MODE_DS |
	                                   DMA_MODE_DR;
	DmaConfig[DMA_SD0_RX].FifoAddr  = SD0_PHYS_ADDR + SD_RXPORT;
	DmaConfig[DMA_SD0_RX].DevIsRead = TRUE;
	DmaConfig[DMA_SD0_RX].Name      = TEXT("SDIO0 RX");
#endif

#ifdef SD1_PHYS_ADDR
	// SD Slot 1 Transmit
	DmaConfig[DMA_SD1_TX].Valid     = TRUE;
	DmaConfig[DMA_SD1_TX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_SD1_TX) | DMA_MODE_DS;
	DmaConfig[DMA_SD1_TX].FifoAddr  = SD1_PHYS_ADDR + SD_TXPORT;
	DmaConfig[DMA_SD1_TX].DevIsRead = FALSE;
	DmaConfig[DMA_SD1_TX].Name      = TEXT("SDIO1 TX");

	// SD Slot 1 Receive
	DmaConfig[DMA_SD1_RX].Valid     = TRUE;
	DmaConfig[DMA_SD1_RX].DmaMode   = DMA_MODE_DID_N(DMA_MODE_DID_SD1_RX) | DMA_MODE_DS |
	                                   DMA_MODE_DR;
	DmaConfig[DMA_SD1_RX].FifoAddr  = SD1_PHYS_ADDR + SD_RXPORT;
	DmaConfig[DMA_SD1_RX].DevIsRead = TRUE;
	DmaConfig[DMA_SD1_RX].Name      = TEXT("SDIO1 RX");
#endif
}




//
// BCEDDK Routines
//

PDMA_CHANNEL_OBJECT HalAllocateDMAChannel()

/*++

Routine Description:

    This routine allocates a DMA channel.

Arguments:
	None.

Return Value:

    Pointer to a new DMA channel object. NULL on failure.

--*/

{
    PCHANNEL_OBJECT pNewChannel;
    PHYSICAL_ADDRESS pa;
	int i;
    
	// Allocate the object
	pNewChannel = LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT,
                             sizeof(*pNewChannel));

    if (pNewChannel == NULL) {
        goto ErrorReturn;
    }
    
	// Find a free channel
	for (i=0;i<NUM_DMA_CHANNELS;i++) {
		
		pNewChannel->hChannelMutex = CreateMutex(NULL,
		                                         FALSE,
		                                         DmaChannelMutexNames[i]);

		if (pNewChannel->hChannelMutex == NULL) {
			RETAILMSG(1,(L"Bailing here\r\n",i));
			goto ErrorReturn;
		}

		if(GetLastError()==ERROR_ALREADY_EXISTS) {
			CloseHandle(pNewChannel->hChannelMutex);
			
			if (i==NUM_DMA_CHANNELS-1) {
				RETAILMSG(1,(L"No DMA Channels available\r\n"));
				goto ErrorReturn;
			}
		}
		else {
			RETAILMSG(1,(L"DMA channel %d is not in use, create new Mutex\r\n",i));
			pNewChannel->DmaChannel = i;
			break;
		}
	}
	
    //
    // Wait for the channel to become available.
    //
    WaitForSingleObject(pNewChannel->hChannelMutex, INFINITE);

    //
    // Grab the DMA channel pointer
    //
    
    pa.LowPart= (ULONG)DmaChannel[pNewChannel->DmaChannel];
	RETAILMSG(1,(TEXT("Mapping DMA channel %d %08X\r\n"),pNewChannel->DmaChannel,pa.LowPart));
    pa.HighPart=0;
    pNewChannel->DmaRegPtr=(AU1X00_DMA*)MmMapIoSpace(pa,sizeof(AU1X00_DMA),FALSE);
    //
    // Ensure the channel is off.
    //

    WRITE_REGISTER_ULONG((PULONG)&pNewChannel->DmaRegPtr->modeclr, 0xffffffff);


    return pNewChannel;

ErrorReturn:
	// cleanup

	if (pNewChannel) {
		LocalFree(pNewChannel);
	}

	return NULL;
}



PVOID
HalAllocateCommonBuffer(
    IN PDMA_ADAPTER_OBJECT AdapterObject,
    IN ULONG Length,
    OUT PPHYSICAL_ADDRESS BusAddress,
    IN BOOLEAN CacheEnable
    )

/*++

Routine Description:

    This routine allocates memory and maps it so that it is simultaneously
    accessible from both the processor and a device for DMA operations.

Arguments:

    AdapterObject - Ignored.

    Length - Specifies the size of the common buffer in bytes.

    LogicalAddress - Points to the logical address the device can use to
        access the buffer.

    CacheEnable - Specifies whether the allocated memory can be cached.

Return Value:

    The virtual address of the allocated range of memory.  If the buffer
    cannot be allocated, NULL is returned.

--*/

{
    PHYSICAL_ADDRESS PhysicalAddress;
    PVOID MappedBuffer;
    ULONG AlignmentRequirement;

    AlignmentRequirement = DMA_ALIGNMENT_REQUIREMENT;
    PhysicalAddress.QuadPart = 0;

    //
    // Allocate contiguous physical buffer from the memory management
    // functionality. 
    //

    MappedBuffer = AllocPhysMem(Length,
                                PAGE_NOCACHE|PAGE_READWRITE,
                                DMA_ALIGNMENT_REQUIREMENT,
                                0,
                                &PhysicalAddress.LowPart);

    //
    // One to one mapping, give back the same address for the DMA hardware.
    //
    BusAddress->QuadPart = PhysicalAddress.QuadPart; 

    return MappedBuffer;
}

VOID HalFreeDMAChannel(PDMA_CHANNEL_OBJECT DmaChannelObject)

/*++

Routine Description:

    This routine releases a DMA channel.

	Note: THE MEMORY ALLOCATED FOR DmaChannelObject WILL BE FREED

Arguments:

    ChannelObject - Points to the channel object allocated by HalAllocateDMAChannel.

Return Value:

    None.

--*/

{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
    DWORD WaitReturn;
    
    //
    // Check the useful parameters.
    //
    if (ChannelObject == NULL) {
        return;
    }

    //
    // Check if we own the channel.
    //
    WaitReturn = WaitForSingleObject(ChannelObject->hChannelMutex, 0);

    if (WaitReturn != WAIT_OBJECT_0) {
        return;
    }

    //
    // Ensure the channel is off.
    //

    WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeclr, 0xffffffff);
    MmUnmapIoSpace((PULONG)ChannelObject->DmaRegPtr,sizeof(AU1X00_DMA));
    
	//
	// Free buffers
	//
	if (ChannelObject->pBufferA) {
		FreePhysMem(ChannelObject->pBufferA);
	}
	if (ChannelObject->pBufferB) {
		FreePhysMem(ChannelObject->pBufferB);
	}

	//
    // Release the mutex.
    //
    ReleaseMutex(ChannelObject->hChannelMutex);
    CloseHandle(ChannelObject->hChannelMutex);

	// Free the memory
	LocalFree(ChannelObject);

    return;
}


VOID
HalFreeCommonBuffer(
    IN PDMA_ADAPTER_OBJECT AdapterObject,
    IN ULONG Length,
    IN PHYSICAL_ADDRESS LogicalAddress,
    IN PVOID VirtualAddress,
    IN BOOLEAN CacheEnable
    )

/*++

Routine Description:

    This routine frees a common buffer and all the resources associated
    with it.

Arguments:

    AdapterObject - Ignored

    LogicalAddress - The logical address of the allocated region of memory.

    VirtualAddress - The virtual address of the allocated region of memory.

    CacheEnable - Whether the allocated memory is cached.

Return Value:

--*/

{
    //
    // For now, just free the memory.  Don't do any checking.  To be more
    // robust, we might want to keep a table of allocated common buffers and
    // verify that the parameters that are passed to this routine match one
    // of the entries in the table before performing the free.
    //

    FreePhysMem(VirtualAddress);
}


BOOL HalInitDmaChannel(PDMA_CHANNEL_OBJECT DmaChannelObject,
                       DMA_LOGICAL_DEVICE  Device,
                       ULONG               BufferSize,
					   BOOL                InterruptEnable)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	DMA_DEVICE_CONFIG *pDevCfg;
	ULONG DmaMode;
	
	// Check Device is in range
	if (Device >= MAX_DMA_LOGICAL_DEVICES) {
		RETAILMSG(1,(TEXT("HalInitDmaChannel: Device %d is out of range\r\n"),Device));
		goto errorReturn;
	}

	pDevCfg = &DmaConfig[Device];
	// Check Device has valid configuration
	if (!pDevCfg->Valid) {
		RETAILMSG(1,(TEXT("HalInitDmaChannel: Device %d does not have valid configuration\r\n"),Device));
		goto errorReturn;
	}

	ChannelObject->FIFOAddress = pDevCfg->FifoAddr;
	ChannelObject->BufferSize = BufferSize;
	ChannelObject->DeviceRead = pDevCfg->DevIsRead;
	ChannelObject->Name = pDevCfg->Name;
	ChannelObject->DeviceID = Device;

	// Allocate two buffers

    ChannelObject->BufferAPhys.QuadPart = 0;
    ChannelObject->BufferBPhys.QuadPart = 0;

    ChannelObject->pBufferA = AllocPhysMem(BufferSize*2,
                                           PAGE_NOCACHE|PAGE_READWRITE,
                                           DMA_ALIGNMENT_REQUIREMENT,
                                           0,
                                           &ChannelObject->BufferAPhys.LowPart);

	ChannelObject->pBufferB = (PUCHAR)(ChannelObject->pBufferA) + BufferSize;
	ChannelObject->BufferBPhys.LowPart = ChannelObject->BufferAPhys.LowPart + BufferSize;

	RETAILMSG(1,(TEXT("HalInitDmaChannel: Channel %d  Device (%s)\r\n"),ChannelObject->DmaChannel,ChannelObject->Name));

	// Setup the DMA registers
	DmaMode  = pDevCfg->DmaMode;

	if (InterruptEnable) {
		ChannelObject->InterruptsEnabled = TRUE;
		DmaMode |= DMA_MODE_IE;
	}

	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeclr,0xffffffff);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeset,DmaMode);

	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->peraddr,pDevCfg->FifoAddr);

	// Work out device width from DMA Mode
	if (DmaMode & DMA_MODE_DW_32) {
		ChannelObject->DeviceWidth = 32;
	} else if (DmaMode & DMA_MODE_DW_16) {
		ChannelObject->DeviceWidth = 16;
	} else {
		ChannelObject->DeviceWidth = 8;
	}

	RETAILMSG(1,(TEXT("HalInitDmaChannel(%s) DMA Mode = %08X\r\n"),ChannelObject->Name,DmaMode));
	RETAILMSG(1,(TEXT("HalInitDmaChannel(%s) Per Addr = %08X\r\n"),ChannelObject->Name,pDevCfg->FifoAddr));

    return TRUE;

errorReturn:
	// TODO Cleanup buffers etc..
	return FALSE;
}


PVOID HalGetNextDMABuffer(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	int nextBuffer;
	ULONG moderead, doneBits;

	// If using interrutps we need to use the DMA Mode saved at interrupt time. If not
	// we lose the D0 and D1 bits that will have been cleared in order to ack the interrupt.
	// First time round the SavedMode will not be valid so we don't use it.
	if (ChannelObject->InterruptsEnabled && ChannelObject->SavedMode) {
		moderead = ChannelObject->SavedMode;
	} else {
		moderead = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->moderead);
	}

	if (moderead & DMA_MODE_H) {
		if (moderead & DMA_MODE_AB) {
			nextBuffer = 1;
			if (moderead & DMA_MODE_BE1) {
				nextBuffer = 0;
			}
		} else {
			nextBuffer = 0;
			if (moderead & DMA_MODE_BE0) {
				nextBuffer = 1;
			}
		}
	} else if (ChannelObject->DeviceRead) {
		doneBits = moderead & (DMA_MODE_D0|DMA_MODE_D1);

		if (doneBits==DMA_MODE_D0) {
			// just D0 set, so return buffer 0				
			nextBuffer = 0;
		} else if (doneBits==DMA_MODE_D1) {
			// just D1 set, so return buffer 1
			nextBuffer = 1;
		} else {
			// either both buffer are done, or both are not done
			// in both cases we want to return the buffer currently in use...
			nextBuffer = (moderead&DMA_MODE_AB) ? 1:0;
		}
	} else {
		// Device is write
		if (moderead & DMA_MODE_AB) {
			if (moderead & (DMA_MODE_BE1|DMA_MODE_BE0)) {
				nextBuffer = 0;
			} else {
				nextBuffer = 1;
			}
		} else {
			if (moderead & (DMA_MODE_BE1|DMA_MODE_BE0)) {
				nextBuffer = 1;
			} else {
				nextBuffer = 0;
			}
		}
	}

	if (0==nextBuffer) {
		RETAILMSG(MSGS,(TEXT("HalGetNextDMABuffer(%s) A=0x%08X Mode=%08X\r\n"),ChannelObject->Name,ChannelObject->pBufferA,moderead));
		return ChannelObject->pBufferA;
	} else {
		RETAILMSG(MSGS,(TEXT("HalGetNextDMABuffer(%s) B=0x%08X Mode=%08X\r\n"),ChannelObject->Name,ChannelObject->pBufferB,moderead));
		return ChannelObject->pBufferB;
	}
}

BOOL HalActivateDMABuffer(PDMA_CHANNEL_OBJECT DmaChannelObject,
                          PVOID pBuffer,
                          ULONG              Size)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	BOOL status = TRUE;

	ULONG DatumsToSend = Size / (ChannelObject->DeviceWidth/8);

	if (pBuffer==ChannelObject->pBufferA) {
		RETAILMSG(MSGS,(TEXT("HalActivateDMABuffer(%s) A Size=%d\r\n"),ChannelObject->Name,Size));
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->buf0size,DatumsToSend);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->buf0addr,ChannelObject->BufferAPhys.LowPart);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeclr,DMA_MODE_D0);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeset,DMA_MODE_BE0);
		ChannelObject->SavedMode |= DMA_MODE_BE0;
		ChannelObject->SavedMode &= ~DMA_MODE_D0;
	} else if (pBuffer==ChannelObject->pBufferB) {
		RETAILMSG(MSGS,(TEXT("HalActivateDMABuffer(%s) B Size=%d\r\n"),ChannelObject->Name,Size));
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->buf1size,DatumsToSend);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->buf1addr,ChannelObject->BufferBPhys.LowPart);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeclr,DMA_MODE_D1);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeset,DMA_MODE_BE1);
		ChannelObject->SavedMode |= DMA_MODE_BE1;
		ChannelObject->SavedMode &= ~DMA_MODE_D1;
	} else {
		RETAILMSG(MSGS,(TEXT("HalActivateDMABuffer(%s) Invalid buffer address 0x%X\r\n"),ChannelObject->Name,(ULONG)pBuffer));
		status = FALSE;
	}

	return status;
}

BOOL HalStartDMA(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	RETAILMSG(MSGS,(TEXT("HalStartDMA(%s)\r\n"),ChannelObject->Name));
	
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeset, DMA_MODE_G);

	ChannelObject->SavedMode = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->moderead);

	return TRUE;
}


BOOL HalStopDMA(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	RETAILMSG(MSGS,(TEXT("HalStopDMA(%s)\r\n"),ChannelObject->Name));
	
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeclr, DMA_MODE_G);

	while(!(DMA_MODE_H & READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->moderead)))
		;

	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeclr, DMA_MODE_D0 | DMA_MODE_D1 | DMA_MODE_BE0 | DMA_MODE_BE1 );

	return TRUE;
}

ULONG HalCheckForDMAInterrupt(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	ULONG moderead, mask = 0;

	moderead = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->moderead);
	ChannelObject->SavedMode = moderead;

	if (moderead & DMA_MODE_H) {
		if (moderead & DMA_MODE_AB) {
			if (moderead & DMA_MODE_D1) {
				mask = DMA_MODE_D1;
			} else {
				mask = DMA_MODE_D0;
			}
		} else {
			if (moderead & DMA_MODE_D0) {
				mask = DMA_MODE_D0;
			} else {
				mask = DMA_MODE_D1;
			}
		}
	} else {
		if (moderead & DMA_MODE_AB) {
			if (moderead & DMA_MODE_D1) {
				mask = DMA_MODE_D1;
			} else {
				mask = DMA_MODE_D0;
			}
		} else {
			if (moderead & DMA_MODE_D0) {
				mask = DMA_MODE_D0;
			} else {
				mask = DMA_MODE_D1;
			}
		}
	}

	RETAILMSG(MSGS,(TEXT("Int(%s) %X (%X %X)\r\n"),ChannelObject->Name,(moderead & mask),moderead,mask));

	return (moderead & mask);
}

BOOL HalAckDMAInterrupt(PDMA_CHANNEL_OBJECT DmaChannelObject,
                        ULONG Mask)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeclr,Mask & (DMA_MODE_D1|DMA_MODE_D0));

	return TRUE;
}

BOOL HalSetDMAForReceive(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	RETAILMSG(MSGS,(TEXT("HalSetDMAForReceive(%s)\r\n"),ChannelObject->Name));

	HalActivateDMABuffer(DmaChannelObject,
                         ChannelObject->pBufferA,
                         ChannelObject->BufferSize);

	HalActivateDMABuffer(DmaChannelObject,
                         ChannelObject->pBufferB,
                         ChannelObject->BufferSize);

	return TRUE;
}

UCHAR HalGetDMAHwIntr(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	return (UCHAR)(HWINTR_DMA0 + ChannelObject->DmaChannel);
}

ULONG HalGetDMABufferRxSize(PDMA_CHANNEL_OBJECT DmaChannelObject,
                            PVOID pBuffer)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	ULONG size = 0;

	if (pBuffer==ChannelObject->pBufferA) {
		size = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->buf0size);
		size &= 0xFFFF;
		size = ChannelObject->BufferSize - size;
		RETAILMSG(MSGS,(TEXT("HalGetDMABufferRxSize(%s) Buffer A Rx Size %d\r\n"),ChannelObject->Name,size));
	} else if (pBuffer==ChannelObject->pBufferB) {
		size = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->buf1size);
		size &= 0xFFFF;
		size = ChannelObject->BufferSize - size;
		RETAILMSG(MSGS,(TEXT("HalGetDMABufferRxSize(%s) Buffer B Rx Size %d\r\n"),ChannelObject->Name,size));
	} else {
		RETAILMSG(MSGS,(TEXT("Invalid buffer address 0x%X\r\n"),(ULONG)pBuffer));
	}

	return size;
}

VOID HalWaitForDMA(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	ULONG moderead;

	RETAILMSG(MSGS,(TEXT("HalWaitForDMA(%s)\r\n"),ChannelObject->Name));

	while (1) {
		moderead = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->moderead);

		if (!(moderead & DMA_MODE_BE0) && !(moderead & DMA_MODE_BE1))
			break;

		Sleep(0);
	}
}

BOOL HalDMAIsUnderflowed(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	ULONG moderead;

	moderead = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->moderead);

	if (!(moderead & DMA_MODE_BE0) && !(moderead & DMA_MODE_BE1)) {
		return TRUE;
	} else {
		return FALSE;
	}
}

// Keep existing BufferSize and InteruptEnable
BOOL HalReconfigureDMA(PDMA_CHANNEL_OBJECT DmaChannelObject,
                       DMA_LOGICAL_DEVICE  Device)

{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	DMA_DEVICE_CONFIG *pDevCfg;
	ULONG DmaMode;
	
	if (ChannelObject->DeviceID == Device) {
		RETAILMSG(MSGS,(TEXT("HalReconfigureDMA: Channel already configured for %s\r\n"),ChannelObject->Name));
		return TRUE;
	}

	// Check Device is in range
	if (Device >= MAX_DMA_LOGICAL_DEVICES) {
		RETAILMSG(1,(TEXT("HalReconfigureDMA: Device %d is out of range\r\n"),Device));
		goto errorReturn;
	}

	pDevCfg = &DmaConfig[Device];
	// Check Device has valid configuration
	if (!pDevCfg->Valid) {
		RETAILMSG(1,(TEXT("HalReconfigureDMA: Device %d does not have valid configuration\r\n"),Device));
		goto errorReturn;
	}

	HalStopDMA(DmaChannelObject);

	ChannelObject->FIFOAddress = pDevCfg->FifoAddr;
	ChannelObject->DeviceRead = pDevCfg->DevIsRead;
	ChannelObject->Name = pDevCfg->Name;
	ChannelObject->DeviceID = Device;

	// Setup the DMA registers
	DmaMode  = pDevCfg->DmaMode;

	if (ChannelObject->InterruptsEnabled) { 
		ChannelObject->InterruptsEnabled = TRUE;
		DmaMode |= DMA_MODE_IE;
	}

	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeclr,0xffffffff);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->modeset,DmaMode);

	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->peraddr,pDevCfg->FifoAddr);

	// Work out device width from DMA Mode
	if (DmaMode & DMA_MODE_DW_32) {
		ChannelObject->DeviceWidth = 32;
	} else if (DmaMode & DMA_MODE_DW_16) {
		ChannelObject->DeviceWidth = 16;
	} else {
		ChannelObject->DeviceWidth = 8;
	}

    return TRUE;

errorReturn:
	// TODO Cleanup buffers etc..
	return FALSE;
}

//
// These MDL DMA routines are not currently supported on 
// the Au1x DMA controller.
//
BOOL HalSetupMdlDMA(PDMA_CHANNEL_OBJECT DmaChannelObject,
                    PMDL                pMDLHead,
					BOOL                ReadTransfer)
{
	return FALSE;
}

BOOL HalStartMdlDMA(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
	return FALSE;
}

BOOL HalCompleteMdlDMA(PDMA_CHANNEL_OBJECT DmaChannelObject, PMDL pMDLHead)
{
	return FALSE;
}



/*++
Copyright (c) 2004-2005  BSQUARE Corporation.  All rights reserved.

Module Name:

    ddma_au1x.c

Module Description:

    This module contains an API set for the Au1x DDMA controller.

Author:

    Ian Rae   January 2004
--*/

#include "bceddk.h"
#include "platform.h"

#define MSGS	0
#define DMA_ALIGNMENT_REQUIREMENT 32

// Strcuture to hold configuration information for each of the peripherals
// the DDMA controller can service.
typedef struct {
	BOOL  Valid;		// Flag to indicate this logical device is valid
	ULONG ChanCfg;		// DDMA channel cfg
	ULONG DescCmd;		// Descriptor cmd
	ULONG DescSrc1;		// Descriptor source1, striding / burst sizes etc.
	ULONG DescDest1;	// Descriptor dest1, striding / burst sizes etc.
	ULONG FifoAddr;		// FIFO Address for peripheral
	BOOL  DevIsRead;	// Is this a read transaction ?
	WCHAR *Name;        // Device name
} DDMA_DEVICE_CONFIG;

static DDMA_DEVICE_CONFIG DdmaConfig[MAX_DMA_LOGICAL_DEVICES];

typedef enum {
	BUFFER_OFF,
	BUFFER_VALID,
	BUFFER_DONE
} BUFFER_STATE;

//
// CHANNEL_OBJECT structure definition.  A forward declaration for this
// structure is in bceddk.h.  This is the real definition.
//
struct _CHANNEL_OBJECT {
    // These are the parts from ceddk.h
    USHORT ObjectSize;                  // Size of structure (versioning).
    INTERFACE_TYPE InterfaceType;       // Adapter bus interface.
    ULONG BusNumber;                    // Adapter bus number.

	// Au1550 specific bits
    ULONG   DmaChannel;
	ULONG   BufferSize;
    HANDLE  hChannelMutex;

	DDMA_DEVICE_CONFIG *pDevCfg;

	BOOL    InterruptsEnabled;

	DMA_LOGICAL_DEVICE	DeviceID;
    DDMA_CHANNEL* DmaRegPtr;

	PVOID   pBufferA;
	PVOID	pBufferB;
	PHYSICAL_ADDRESS BufferAPhys;
	PHYSICAL_ADDRESS BufferBPhys;

	DDMA_DESCRIPTOR_STD*   pDescA;
	DDMA_DESCRIPTOR_STD*   pDescB;
	PHYSICAL_ADDRESS DescAPhys;
	PHYSICAL_ADDRESS DescBPhys;

	BUFFER_STATE BufferStateA;
	BUFFER_STATE BufferStateB;

	WCHAR *Name;        // Device name

	// Entries for MDL DMA
	DDMA_DESCRIPTOR_STD *pDescriptors;
	PHYSICAL_ADDRESS     DescriptorsPhysAddr;
	ULONG AllocatedDescriptors;

	PVOID pAlignedBuffer;
	PHYSICAL_ADDRESS	AlignedPhysAddr;
	ULONG AlignedByteCount;
	ULONG NextDMABuffer; // The Next DMA Buffer to be serviced by interrupt

	// Added to remove hardware state dependencies
//	DWORD dwGet, dwPut, dwCur;

};

typedef struct _CHANNEL_OBJECT CHANNEL_OBJECT, *PCHANNEL_OBJECT;

static AU1X00_DDMA *pDDMAController;

//
// Static Globals
//

//
// Table of mutex names for each DMA channel.  These are used to create
// named mutexes for allocating DMA channels.
//
static TCHAR* DmaChannelMutexNames[DDMA_NUM_CHANNELS] = {
    TEXT("__DMA_CHANNEL_MUTEX_0__"),
    TEXT("__DMA_CHANNEL_MUTEX_1__"),
    TEXT("__DMA_CHANNEL_MUTEX_2__"),
    TEXT("__DMA_CHANNEL_MUTEX_3__"),
    TEXT("__DMA_CHANNEL_MUTEX_4__"),
    TEXT("__DMA_CHANNEL_MUTEX_5__"),
    TEXT("__DMA_CHANNEL_MUTEX_6__"),
    TEXT("__DMA_CHANNEL_MUTEX_7__"),
    TEXT("__DMA_CHANNEL_MUTEX_8__"),
    TEXT("__DMA_CHANNEL_MUTEX_9__"),
    TEXT("__DMA_CHANNEL_MUTEX_10_"),
    TEXT("__DMA_CHANNEL_MUTEX_11_"),
    TEXT("__DMA_CHANNEL_MUTEX_12_"),
    TEXT("__DMA_CHANNEL_MUTEX_13_"),
    TEXT("__DMA_CHANNEL_MUTEX_14_"),
    TEXT("__DMA_CHANNEL_MUTEX_15_")
};

//
// Table of pointers to each DDMA channel.
//
static DDMA_CHANNEL* DmaChannel[DDMA_NUM_CHANNELS];

//
// Private Routines
//


//
// Exported Routines
//

VOID
DmaEntry(
    VOID
    )

/*++

Routine Description:

    This routine is called when the BCEDDK loaded for each process.  It
    performs initialization to make the DMA portion of the BCEDDK usable.

Arguments:

    None.

Return Value:

    None.

--*/
{
	PHYSICAL_ADDRESS pa;
	int i;
//	HKEY        hKey;
	DWORD       reservedChannels = 0;

	// Create mutexes for any reserved channels so they appear to be in-use
	for (i = 0; i < DDMA_NUM_CHANNELS; i++) {
		if (reservedChannels & (1<<i)) {
			CreateMutex(NULL,FALSE,DmaChannelMutexNames[i]);
		}
	}

	pa.LowPart= DDMA_PHYS_ADDR;
    pa.HighPart=0;

	// Setup the configuration entries for the logical DMA devices we support

#if defined(PLATFORM_AC97_PSC)
	// AC97 (PSC1) Transmit
	DdmaConfig[DMA_AC97_TX].Valid     = TRUE;
	DdmaConfig[DMA_AC97_TX].Name      = TEXT("AC97 TX");
	DdmaConfig[DMA_AC97_TX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_AC97_TX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
	                                    DDMA_DESCCMD_DW_HWORD | DDMA_DESCCMD_SW_HWORD |
                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_AC97_TX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_1 | DDMA_DESCSRC_STRIDE_SAM_INC;
	DdmaConfig[DMA_AC97_TX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_STATIC;
	DdmaConfig[DMA_AC97_TX].DevIsRead = FALSE;
	// AC97 (PSC1) Receive
	DdmaConfig[DMA_AC97_RX].Valid     = TRUE;
	DdmaConfig[DMA_AC97_RX].Name      = TEXT("AC97 RX");
	DdmaConfig[DMA_AC97_RX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_AC97_RX].DescCmd   = DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
	                                    DDMA_DESCCMD_DW_HWORD | DDMA_DESCCMD_SW_HWORD |
                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_AC97_RX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_STATIC;
	DdmaConfig[DMA_AC97_RX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_1 | DDMA_DESCDST_STRIDE_DAM_INC;
	DdmaConfig[DMA_AC97_RX].DevIsRead = TRUE;

	// Platform specific options of PSC0-3 for AC97, to be defined in <platform>.h
#if (PLATFORM_AC97_PSC == PSC0_PHYS_ADDR)
	DdmaConfig[DMA_AC97_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC0_TX_ID);
	DdmaConfig[DMA_AC97_TX].FifoAddr  =	DDMA_PSC0_TX_ADDR;
	DdmaConfig[DMA_AC97_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC0_RX_ID);
	DdmaConfig[DMA_AC97_RX].FifoAddr  =	DDMA_PSC0_RX_ADDR;
#elif (PLATFORM_AC97_PSC == PSC1_PHYS_ADDR)
	DdmaConfig[DMA_AC97_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC1_TX_ID);
	DdmaConfig[DMA_AC97_TX].FifoAddr  =	DDMA_PSC1_TX_ADDR;
	DdmaConfig[DMA_AC97_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC1_RX_ID);
	DdmaConfig[DMA_AC97_RX].FifoAddr  =	DDMA_PSC1_RX_ADDR;
#elif (PLATFORM_AC97_PSC == PSC2_PHYS_ADDR)
	DdmaConfig[DMA_AC97_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC2_TX_ID);
	DdmaConfig[DMA_AC97_TX].FifoAddr  =	DDMA_PSC2_TX_ADDR;
	DdmaConfig[DMA_AC97_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC2_RX_ID);
	DdmaConfig[DMA_AC97_RX].FifoAddr  =	DDMA_PSC2_RX_ADDR;
#elif (PLATFORM_AC97_PSC == PSC3_PHYS_ADDR)
	DdmaConfig[DMA_AC97_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC3_TX_ID);
	DdmaConfig[DMA_AC97_TX].FifoAddr  =	DDMA_PSC3_TX_ADDR;
	DdmaConfig[DMA_AC97_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC3_RX_ID);
	DdmaConfig[DMA_AC97_RX].FifoAddr  =	DDMA_PSC3_RX_ADDR;
#else
#error PLATFORM_AC97_PSC must be defined in the range 0 to 3
#endif
#endif

#if defined(PLATFORM_I2S_PSC)
	// I2S Transmit
	DdmaConfig[DMA_I2S_TX].Valid     = TRUE;
	DdmaConfig[DMA_I2S_TX].Name      = TEXT("I2S TX");
	DdmaConfig[DMA_I2S_TX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_I2S_TX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
	                                    DDMA_DESCCMD_DW_HWORD | DDMA_DESCCMD_SW_HWORD |
                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_I2S_TX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_1 | DDMA_DESCSRC_STRIDE_SAM_INC;
	DdmaConfig[DMA_I2S_TX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_STATIC;
	DdmaConfig[DMA_I2S_TX].DevIsRead = FALSE;

	// I2S Receive
	DdmaConfig[DMA_I2S_RX].Valid     = TRUE;
	DdmaConfig[DMA_I2S_RX].Name      = TEXT("I2S RX");
	DdmaConfig[DMA_I2S_RX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_I2S_RX].DescCmd   = DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
	                                    DDMA_DESCCMD_DW_HWORD | DDMA_DESCCMD_SW_HWORD |
                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_I2S_RX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_STATIC;
	DdmaConfig[DMA_I2S_RX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_1 | DDMA_DESCDST_STRIDE_DAM_INC;
	DdmaConfig[DMA_I2S_RX].DevIsRead = TRUE;

	// Platform specific options of PSC0-3 for I2S Audio, to be defined in <platform>.h
#if (PLATFORM_I2S_PSC==0)
	DdmaConfig[DMA_I2S_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC0_TX_ID);
	DdmaConfig[DMA_I2S_TX].FifoAddr  = DDMA_PSC0_TX_ADDR;
	DdmaConfig[DMA_I2S_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC0_RX_ID);
	DdmaConfig[DMA_I2S_RX].FifoAddr  = DDMA_PSC0_RX_ADDR;
#elif (PLATFORM_I2S_PSC==1)
	DdmaConfig[DMA_I2S_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC1_TX_ID);
	DdmaConfig[DMA_I2S_TX].FifoAddr  = DDMA_PSC1_TX_ADDR;
	DdmaConfig[DMA_I2S_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC1_RX_ID);
	DdmaConfig[DMA_I2S_RX].FifoAddr  = DDMA_PSC1_RX_ADDR;
#elif (PLATFORM_I2S_PSC==2)
	DdmaConfig[DMA_I2S_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC2_TX_ID);
	DdmaConfig[DMA_I2S_TX].FifoAddr  = DDMA_PSC2_TX_ADDR;
	DdmaConfig[DMA_I2S_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC2_RX_ID);
	DdmaConfig[DMA_I2S_RX].FifoAddr  = DDMA_PSC2_RX_ADDR;
#elif (PLATFORM_I2S_PSC==3)
	DdmaConfig[DMA_I2S_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC3_TX_ID);
	DdmaConfig[DMA_I2S_TX].FifoAddr  = DDMA_PSC3_TX_ADDR;
	DdmaConfig[DMA_I2S_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC3_RX_ID);
	DdmaConfig[DMA_I2S_RX].FifoAddr  = DDMA_PSC3_RX_ADDR;
#else
#error PLATFORM_I2S_PSC must be defined in the range 0 to 3
#endif
#endif

#if defined(PLATFORM_SPI_PSC)
	// SPI (PSC0) Transmit
	DdmaConfig[DMA_SPI_TX].Valid     = TRUE;
	DdmaConfig[DMA_SPI_TX].Name      = TEXT("SPI TX");
	DdmaConfig[DMA_SPI_TX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_SPI_TX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
	                                    DDMA_DESCCMD_DW_HWORD | DDMA_DESCCMD_SW_WORD |
                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_SPI_TX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_1 | DDMA_DESCSRC_STRIDE_SAM_INC;
	DdmaConfig[DMA_SPI_TX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_STATIC;
	DdmaConfig[DMA_SPI_TX].DevIsRead = FALSE;

	// SPI (PSC0) Receive
	DdmaConfig[DMA_SPI_RX].Valid     = TRUE;
	DdmaConfig[DMA_SPI_RX].Name      = TEXT("SPI RX");
	DdmaConfig[DMA_SPI_RX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_SPI_RX].DescCmd   = DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
	                                    DDMA_DESCCMD_DW_WORD | DDMA_DESCCMD_SW_WORD |
                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_SPI_RX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_STATIC;
	DdmaConfig[DMA_SPI_RX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_1 | DDMA_DESCDST_STRIDE_DAM_INC;
	DdmaConfig[DMA_SPI_RX].DevIsRead = TRUE;

	// Platform specific options of PSC0-3 for SPI, to be defined in <platform>.h
#if (PLATFORM_SPI_PSC==0)
	DdmaConfig[DMA_SPI_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC0_TX_ID);
	DdmaConfig[DMA_SPI_TX].FifoAddr  = DDMA_PSC0_TX_ADDR;
	DdmaConfig[DMA_SPI_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC0_RX_ID);
	DdmaConfig[DMA_SPI_RX].FifoAddr  = DDMA_PSC0_RX_ADDR;
#elif (PLATFORM_SPI_PSC==1)
	DdmaConfig[DMA_SPI_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC1_TX_ID);
	DdmaConfig[DMA_SPI_TX].FifoAddr  = DDMA_PSC1_TX_ADDR;
	DdmaConfig[DMA_SPI_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC1_RX_ID);
	DdmaConfig[DMA_SPI_RX].FifoAddr  = DDMA_PSC1_RX_ADDR;
#elif (PLATFORM_SPI_PSC==2)
	DdmaConfig[DMA_SPI_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC2_TX_ID);
	DdmaConfig[DMA_SPI_TX].FifoAddr  = DDMA_PSC2_TX_ADDR;
	DdmaConfig[DMA_SPI_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC2_RX_ID);
	DdmaConfig[DMA_SPI_RX].FifoAddr  = DDMA_PSC2_RX_ADDR;
#elif (PLATFORM_SPI_PSC==3)
	DdmaConfig[DMA_SPI_TX].DescCmd  |= DDMA_DESCCMD_DID_N(DDMA_PSC3_TX_ID);
	DdmaConfig[DMA_SPI_TX].FifoAddr  = DDMA_PSC3_TX_ADDR;
	DdmaConfig[DMA_SPI_RX].DescCmd  |= DDMA_DESCCMD_SID_N(DDMA_PSC3_RX_ID);
	DdmaConfig[DMA_SPI_RX].FifoAddr  = DDMA_PSC3_RX_ADDR;
#else
#error PLATFORM_SPI_PSC must be defined in the range 0 to 3
#endif
#endif

#if defined(USBD_PHYS_ADDR)
	// USB Device Endpoint 0 Transmit
	DdmaConfig[DMA_USBD_EP0_TX].Valid     = TRUE;
	DdmaConfig[DMA_USBD_EP0_TX].Name      = TEXT("USBD0 TX");
	DdmaConfig[DMA_USBD_EP0_TX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_USBD_EP0_TX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DID_N(DDMA_USB_DEVICE_ENDPOINT_0_TX_ID) |
	                                        DDMA_DESCCMD_DW_BYTE | DDMA_DESCCMD_SW_BYTE |
	                                        DDMA_DESCCMD_DN;
	DdmaConfig[DMA_USBD_EP0_TX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_1 | DDMA_DESCSRC_STRIDE_SAM_INC;
	DdmaConfig[DMA_USBD_EP0_TX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_4 | DDMA_DESCDST_STRIDE_DAM_STATIC;
	DdmaConfig[DMA_USBD_EP0_TX].FifoAddr  =	DDMA_USB_DEVICE_ENDPOINT_0_TX_ADDR;
	DdmaConfig[DMA_USBD_EP0_TX].DevIsRead = FALSE;

	// USB Device Endpoint 0 Receive
	DdmaConfig[DMA_USBD_EP0_RX].Valid     = TRUE;
	DdmaConfig[DMA_USBD_EP0_RX].Name      = TEXT("USBD0 RX");
	DdmaConfig[DMA_USBD_EP0_RX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_USBD_EP0_RX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_USB_DEVICE_ENDPOINT_0_RX_ID) |
	                                        DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DW_BYTE | DDMA_DESCCMD_SW_BYTE |
	                                        DDMA_DESCCMD_SN;
	DdmaConfig[DMA_USBD_EP0_RX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_4 | DDMA_DESCSRC_STRIDE_SAM_STATIC;
	DdmaConfig[DMA_USBD_EP0_RX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_1 | DDMA_DESCDST_STRIDE_DAM_INC;
	DdmaConfig[DMA_USBD_EP0_RX].FifoAddr  =	DDMA_USB_DEVICE_ENDPOINT_0_RX_ADDR;
	DdmaConfig[DMA_USBD_EP0_RX].DevIsRead = TRUE;

	// USB Device Endpoint 1 Transmit
	DdmaConfig[DMA_USBD_EP1_TX].Valid     = TRUE;
	DdmaConfig[DMA_USBD_EP1_TX].Name      = TEXT("USBD1 TX");
	DdmaConfig[DMA_USBD_EP1_TX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_USBD_EP1_TX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DID_N(DDMA_USB_DEVICE_ENDPOINT_1_TX_ID) |
	                                        DDMA_DESCCMD_DW_BYTE | DDMA_DESCCMD_SW_BYTE |
	                                        DDMA_DESCCMD_DN;
	DdmaConfig[DMA_USBD_EP1_TX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_1 | DDMA_DESCSRC_STRIDE_SAM_INC;
	DdmaConfig[DMA_USBD_EP1_TX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_4 | DDMA_DESCDST_STRIDE_DAM_STATIC;
	DdmaConfig[DMA_USBD_EP1_TX].FifoAddr  =	DDMA_USB_DEVICE_ENDPOINT_1_TX_ADDR;
	DdmaConfig[DMA_USBD_EP1_TX].DevIsRead = FALSE;

	// USB Device Endpoint 2 Transmit
	DdmaConfig[DMA_USBD_EP2_TX].Valid     = TRUE;
	DdmaConfig[DMA_USBD_EP2_TX].Name      = TEXT("USBD2 TX");
	DdmaConfig[DMA_USBD_EP2_TX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_USBD_EP2_TX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DID_N(DDMA_USB_DEVICE_ENDPOINT_2_TX_ID) |
	                                        DDMA_DESCCMD_DW_BYTE | DDMA_DESCCMD_SW_BYTE |
	                                        DDMA_DESCCMD_DN;
	DdmaConfig[DMA_USBD_EP2_TX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_1 | DDMA_DESCSRC_STRIDE_SAM_INC;
	DdmaConfig[DMA_USBD_EP2_TX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_4 | DDMA_DESCDST_STRIDE_DAM_STATIC;
	DdmaConfig[DMA_USBD_EP2_TX].FifoAddr  =	DDMA_USB_DEVICE_ENDPOINT_2_TX_ADDR;
	DdmaConfig[DMA_USBD_EP2_TX].DevIsRead = FALSE;

	// USB Device Endpoint 3 Receive
	DdmaConfig[DMA_USBD_EP3_RX].Valid     = TRUE;
	DdmaConfig[DMA_USBD_EP3_RX].Name      = TEXT("USBD3 RX");
	DdmaConfig[DMA_USBD_EP3_RX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_USBD_EP3_RX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_USB_DEVICE_ENDPOINT_3_RX_ID) |
	                                        DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DW_BYTE | DDMA_DESCCMD_SW_BYTE |
	                                        DDMA_DESCCMD_SN;
	DdmaConfig[DMA_USBD_EP3_RX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_4 | DDMA_DESCSRC_STRIDE_SAM_STATIC;
	DdmaConfig[DMA_USBD_EP3_RX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_1 | DDMA_DESCDST_STRIDE_DAM_INC;
	DdmaConfig[DMA_USBD_EP3_RX].FifoAddr  =	DDMA_USB_DEVICE_ENDPOINT_3_RX_ADDR;
	DdmaConfig[DMA_USBD_EP3_RX].DevIsRead = TRUE;

	// USB Device Endpoint 4 Receive
	DdmaConfig[DMA_USBD_EP4_RX].Valid     = TRUE;
	DdmaConfig[DMA_USBD_EP4_RX].Name      = TEXT("USBD4 RX");
	DdmaConfig[DMA_USBD_EP4_RX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_USBD_EP4_RX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_USB_DEVICE_ENDPOINT_4_RX_ID) |
	                                        DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DW_BYTE | DDMA_DESCCMD_SW_BYTE |
	                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_USBD_EP4_RX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_4 | DDMA_DESCSRC_STRIDE_SAM_STATIC;
	DdmaConfig[DMA_USBD_EP4_RX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_1 | DDMA_DESCDST_STRIDE_DAM_INC;
	DdmaConfig[DMA_USBD_EP4_RX].FifoAddr  =	DDMA_USB_DEVICE_ENDPOINT_4_RX_ADDR;
	DdmaConfig[DMA_USBD_EP4_RX].DevIsRead = TRUE;
#endif

#if defined(SD0_PHYS_ADDR)
	DdmaConfig[DMA_SD0_TX].Valid     = TRUE;
	DdmaConfig[DMA_SD0_TX].Name      = TEXT("SDIO0 TX");
	DdmaConfig[DMA_SD0_TX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_SD0_TX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DID_N(DDMA_SDMS0_TX_ID) |
#if defined(SD_FIFO_32BITS)
	                                        DDMA_DESCCMD_DW_WORD | DDMA_DESCCMD_SW_WORD |
#else
	                                        DDMA_DESCCMD_DW_BYTE | DDMA_DESCCMD_SW_BYTE |
#endif
	                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_SD0_TX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_INC;
	DdmaConfig[DMA_SD0_TX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_STATIC;
	DdmaConfig[DMA_SD0_TX].FifoAddr  = SD0_PHYS_ADDR + SD_TXPORT;
	DdmaConfig[DMA_SD0_TX].DevIsRead = FALSE;

	DdmaConfig[DMA_SD0_RX].Valid     = TRUE;
	DdmaConfig[DMA_SD0_RX].Name      = TEXT("SDIO0 RX");
	DdmaConfig[DMA_SD0_RX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_SD0_RX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_SDMS0_RX_ID) |
	                                        DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
#if defined(SD_FIFO_32BITS)
	                                        DDMA_DESCCMD_DW_WORD | DDMA_DESCCMD_SW_WORD |
#else
	                                        DDMA_DESCCMD_DW_BYTE | DDMA_DESCCMD_SW_BYTE |
#endif
	                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_SD0_RX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_STATIC;
	DdmaConfig[DMA_SD0_RX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_INC;
	DdmaConfig[DMA_SD0_RX].FifoAddr  = SD0_PHYS_ADDR + SD_RXPORT;
	DdmaConfig[DMA_SD0_RX].DevIsRead = TRUE;
#endif

#if defined(SD1_PHYS_ADDR)
	DdmaConfig[DMA_SD1_TX].Valid     = TRUE;
	DdmaConfig[DMA_SD1_TX].Name      = TEXT("SDIO1 TX");
	DdmaConfig[DMA_SD1_TX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_SD1_TX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DID_N(DDMA_SDMS1_TX_ID) |
#if defined(SD_FIFO_32BITS)
	                                        DDMA_DESCCMD_DW_WORD | DDMA_DESCCMD_SW_WORD |
#else
	                                        DDMA_DESCCMD_DW_BYTE | DDMA_DESCCMD_SW_BYTE |
#endif
	                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_SD1_TX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_INC;
	DdmaConfig[DMA_SD1_TX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_STATIC;
	DdmaConfig[DMA_SD1_TX].FifoAddr  = SD1_PHYS_ADDR + SD_TXPORT;
	DdmaConfig[DMA_SD1_TX].DevIsRead = FALSE;

	DdmaConfig[DMA_SD1_RX].Valid     = TRUE;
	DdmaConfig[DMA_SD1_RX].Name      = TEXT("SDIO1 RX");
	DdmaConfig[DMA_SD1_RX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_SD1_RX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_SDMS1_RX_ID) |
	                                        DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
#if defined(SD_FIFO_32BITS)
	                                        DDMA_DESCCMD_DW_WORD | DDMA_DESCCMD_SW_WORD |
#else
	                                        DDMA_DESCCMD_DW_BYTE | DDMA_DESCCMD_SW_BYTE |
#endif
	                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_SD1_RX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_STATIC;
	DdmaConfig[DMA_SD1_RX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_INC;
	DdmaConfig[DMA_SD1_RX].FifoAddr  = SD1_PHYS_ADDR + SD_RXPORT;
	DdmaConfig[DMA_SD1_RX].DevIsRead = TRUE;
#endif

#if defined(IDE_PHYS_ADDR) && defined(IDE_DMA_REQ)
	DdmaConfig[DMA_IDE_TX].Valid     = TRUE;
	DdmaConfig[DMA_IDE_TX].Name      = TEXT("IDE TX");
	DdmaConfig[DMA_IDE_TX].ChanCfg   = DDMA_CHANCFG_DFN | DDMA_CHANCFG_SYNC;
	DdmaConfig[DMA_IDE_TX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DID_N(IDE_DMA_REQ) |
	                                        DDMA_DESCCMD_DW_WORD | DDMA_DESCCMD_SW_WORD |
	                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_IDE_TX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_INC;
	DdmaConfig[DMA_IDE_TX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_BURST;
	DdmaConfig[DMA_IDE_TX].FifoAddr  = IDE_PHYS_ADDR;
	DdmaConfig[DMA_IDE_TX].DevIsRead = FALSE;

	DdmaConfig[DMA_IDE_RX].Valid     = TRUE;
	DdmaConfig[DMA_IDE_RX].Name      = TEXT("IDE RX");
	DdmaConfig[DMA_IDE_RX].ChanCfg   = DDMA_CHANCFG_DFN  | DDMA_CHANCFG_SYNC;
	DdmaConfig[DMA_IDE_RX].DescCmd   = DDMA_DESCCMD_SID_N(IDE_DMA_REQ) |
	                                        DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DW_WORD | DDMA_DESCCMD_SW_WORD |
	                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_IDE_RX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_BURST;
	DdmaConfig[DMA_IDE_RX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_INC;
	DdmaConfig[DMA_IDE_RX].FifoAddr  = IDE_PHYS_ADDR;
	DdmaConfig[DMA_IDE_RX].DevIsRead = TRUE;
#endif

#if defined(CIM_PHYS_ADDR)
 #if defined(SOC_AU1200)
    // There are up to three DMA channels used by the CIM, depending upon
    // how the CIM is configured. The three logical channels have contiguous
    // values from FIFOA to FIFOC.
    {
        int i;
        for (i=0; i<3; ++i) {
            DdmaConfig[DMA_CIM_FIFOA+i].Valid     = TRUE;
            DdmaConfig[DMA_CIM_FIFOA+i].ChanCfg   = DDMA_CHANCFG_DFN | DDMA_CHANCFG_SBE;
            DdmaConfig[DMA_CIM_FIFOA+i].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_CIM_A_RX_ID+i) |
                                                    DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
                                                    DDMA_DESCCMD_SW_WORD | DDMA_DESCCMD_DW_BYTE |
                                                    DDMA_DESCCMD_ARB | DDMA_DESCCMD_SN;
            DdmaConfig[DMA_CIM_FIFOA+i].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 |
                                                    DDMA_DESCSRC_STRIDE_SAM_BURST;
            DdmaConfig[DMA_CIM_FIFOA+i].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 |
                                                    DDMA_DESCDST_STRIDE_DAM_INC;
            DdmaConfig[DMA_CIM_FIFOA+i].FifoAddr  = CIM_PHYS_ADDR + CIM_FIFOA + 0x20*i;
            DdmaConfig[DMA_CIM_FIFOA+i].DevIsRead = TRUE;
        }
        DdmaConfig[DMA_CIM_FIFOA+0].Name      = TEXT("CIM FIFO A");
        DdmaConfig[DMA_CIM_FIFOA+1].Name      = TEXT("CIM FIFO B");
        DdmaConfig[DMA_CIM_FIFOA+2].Name      = TEXT("CIM FIFO C");
    }
 #elif defined(SOC_AU13XX)
	#pragma message(__LOC__"TODO -- Add CIM DbDMA Config")
 #endif
#endif

#ifdef NAND_PHYS_ADDR
	DdmaConfig[DMA_NAND_TX].Valid     = TRUE;
	DdmaConfig[DMA_NAND_TX].Name      = TEXT("NAND TX");
	DdmaConfig[DMA_NAND_TX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_NAND_TX].DescCmd   = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DID_N(23) |
	                                        DDMA_DESCCMD_DW_WORD | DDMA_DESCCMD_SW_WORD |
	                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_NAND_TX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_INC;
	DdmaConfig[DMA_NAND_TX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_BURST;
	DdmaConfig[DMA_NAND_TX].FifoAddr  = NAND_PHYS_ADDR + 0x20;
	DdmaConfig[DMA_NAND_TX].DevIsRead = FALSE;

	DdmaConfig[DMA_NAND_RX].Valid     = TRUE;
	DdmaConfig[DMA_NAND_RX].Name      = TEXT("NAND RX");
	DdmaConfig[DMA_NAND_RX].ChanCfg   = DDMA_CHANCFG_DFN;
	DdmaConfig[DMA_NAND_RX].DescCmd   = DDMA_DESCCMD_SID_N(23) |
	                                        DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
	                                        DDMA_DESCCMD_DW_WORD | DDMA_DESCCMD_SW_WORD |
	                                        DDMA_DESCCMD_DN | DDMA_DESCCMD_SN;
	DdmaConfig[DMA_NAND_RX].DescSrc1  = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_BURST;
	DdmaConfig[DMA_NAND_RX].DescDest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_INC;
	DdmaConfig[DMA_NAND_RX].FifoAddr  = NAND_PHYS_ADDR;
	DdmaConfig[DMA_NAND_RX].DevIsRead = TRUE;

#endif

    pDDMAController=(AU1X00_DDMA*)MmMapIoSpace(pa,sizeof(AU1X00_DDMA),FALSE);

	pDDMAController->config = DDMA_CONFIG_AL | DDMA_CONFIG_AH | DDMA_CONFIG_AF;
}

void HalSetDMAConfig (DMA_LOGICAL_DEVICE Device,
                      DWORD chan, DWORD cmd, DWORD src1, DWORD dst1)
{
	DDMA_DEVICE_CONFIG *pDevCfg = &DdmaConfig[Device];

	// Check Device is in range
	if (Device >= MAX_DMA_LOGICAL_DEVICES) {
		RETAILMSG(1,(TEXT("HalSetDMAConfig: Device %d is out of range\r\n"),Device));
		return;
	}
	// Check Device has valid configuration
	if (!pDevCfg->Valid) {
		RETAILMSG(1,(TEXT("HalSetDMAConfig: Device %d does not have valid configuration\r\n"),Device));
		return;
	}

    DEBUGMSG(1,(TEXT("HalSetDMAConfig: resetting config for channel %s\r\n"), pDevCfg->Name));
    pDevCfg->ChanCfg = chan;
    pDevCfg->DescCmd = cmd;
    pDevCfg->DescSrc1 = src1;
    pDevCfg->DescDest1 = dst1;
}


//
// BCEDDK Routines
//

PDMA_CHANNEL_OBJECT HalAllocateDMAChannel()

/*++

Routine Description:

    This routine allocates a DMA channel.

Arguments:
	None.

Return Value:

    Pointer to a new DMA channel object. NULL on failure.

--*/

{
    PCHANNEL_OBJECT pNewChannel;
	int i;
    BOOL bIsInitialized=FALSE;

	if (!bIsInitialized)
	{
		bIsInitialized = TRUE;
	    DmaEntry();
	}

	// Allocate the object
	pNewChannel = LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT,
                             sizeof(*pNewChannel));

    if (pNewChannel == NULL) {
        goto ErrorReturn;
    }

	// Find a free channel
	for (i=0;i<DDMA_NUM_CHANNELS;i++) {

		pNewChannel->hChannelMutex = CreateMutex(NULL,
		                                           FALSE,
		                                           DmaChannelMutexNames[i]);

		if (pNewChannel->hChannelMutex == NULL) {
			goto ErrorReturn;
		}

		if(GetLastError()==ERROR_ALREADY_EXISTS) {
			CloseHandle(pNewChannel->hChannelMutex);
		}
		else {
			RETAILMSG(MSGS,(L"DDMA channel %d is not in use, create new Mutex\r\n",i));
			pNewChannel->DmaChannel = i;
			break;
		}
	}
    if (i==DDMA_NUM_CHANNELS) {
        RETAILMSG(1,(L"No DDMA Channels available\r\n"));
        goto ErrorReturn;
    }

    //
    // Wait for the channel to become available.
    //
    WaitForSingleObject(pNewChannel->hChannelMutex, INFINITE);

    //
    // Grab the DMA channel pointer
    //

	pNewChannel->DmaRegPtr = (DDMA_CHANNEL*)(0xB4002000 + (0x100*pNewChannel->DmaChannel));
    //
    // Ensure the channel is off.
    //

    WRITE_REGISTER_ULONG((PULONG)&pNewChannel->DmaRegPtr->cfg, 0);

    return (PDMA_CHANNEL_OBJECT)pNewChannel;

ErrorReturn:
	// cleanup

	if (pNewChannel) {
		LocalFree(pNewChannel);
	}

	return NULL;
}



PVOID
HalAllocateCommonBuffer(
    IN PDMA_ADAPTER_OBJECT DmaAdapterObject,
    IN ULONG Length,
    OUT PPHYSICAL_ADDRESS BusAddress,
    IN BOOLEAN CacheEnable
    )

/*++

Routine Description:

    This routine allocates memory and maps it so that it is simultaneously
    accessible from both the processor and a device for DMA operations.

Arguments:

    ChannelObject - Points to the adapter object representing the busmaster
        adapter or DMA controller channel.  Ignored for Alchemy DMA.

    Length - Specifies the size of the common buffer in bytes.

    LogicalAddress - Points to the logical address the device can use to
        access the buffer.

    CacheEnable - Specifies whether the allocated memory can be cached.

Return Value:

    The virtual address of the allocated range of memory.  If the buffer
    cannot be allocated, NULL is returned.

--*/

{
    PHYSICAL_ADDRESS PhysicalAddress;
    PVOID MappedBuffer;
    ULONG AlignmentRequirement;

    AlignmentRequirement = DMA_ALIGNMENT_REQUIREMENT;
    PhysicalAddress.QuadPart = 0;

    //
    // Allocate contiguous physical buffer from the memory management
    // functionality.
    //

    MappedBuffer = AllocPhysMem(Length,
                                PAGE_READWRITE | PAGE_NOCACHE,
                                DMA_ALIGNMENT_REQUIREMENT,
                                0,
                                &PhysicalAddress.LowPart);

    //
    // Convert the physically allocated buffer to a useable address
    // from the device. For us this is a 1-1 mapping
    //

    BusAddress->QuadPart = PhysicalAddress.QuadPart;

    return MappedBuffer;
}



VOID HalFreeDMAChannel(PDMA_CHANNEL_OBJECT DmaChannelObject)

/*++

Routine Description:

    This routine releases a DMA channel.

	Note: THE MEMORY ALLOCATED FOR DmaChannelObject WILL BE FREED

Arguments:

    ChannelObject - Points to the channel object allocated by HalAllocateDMAChannel.

Return Value:

    None.

--*/

{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
    DWORD WaitReturn;

    //
    // Check the useful parameters.
    //
    if (ChannelObject == NULL) {
        return;
    }

    //
    // Check if we own the channel.
    //
    WaitReturn = WaitForSingleObject(ChannelObject->hChannelMutex, 0);

    if (WaitReturn != WAIT_OBJECT_0) {
        return;
    }

    //
    // Ensure the channel is off.
    //

    WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->cfg, 0);


	//
	// Free buffers
	//
	if (ChannelObject->pBufferA) {
		FreePhysMem(ChannelObject->pBufferA);
	}
	if (ChannelObject->pBufferB) {
		FreePhysMem(ChannelObject->pBufferB);
	}

	//
    // Release the mutex.
    //
    ReleaseMutex(ChannelObject->hChannelMutex);
    CloseHandle(ChannelObject->hChannelMutex);

	// Free the memory
	LocalFree(ChannelObject);

    return;
}



VOID
HalFreeCommonBuffer(
    IN PDMA_ADAPTER_OBJECT DmaAdapterObject,
    IN ULONG Length,
    IN PHYSICAL_ADDRESS LogicalAddress,
    IN PVOID VirtualAddress,
    IN BOOLEAN CacheEnable
    )

/*++

Routine Description:

    This routine frees a common buffer and all the resources associated
    with it.

Arguments:

    DmaAdapterObject - Ignored.

    LogicalAddress - The logical address of the allocated region of memory.

    VirtualAddress - The virtual address of the allocated region of memory.

    CacheEnable - Whether the allocated memory is cached.

Return Value:

--*/

{
    //
    // For now, just free the memory.  Don't do any checking.  To be more
    // robust, we might want to keep a table of allocated common buffers and
    // verify that the parameters that are passed to this routine match one
    // of the entries in the table before performing the free.
    //

    FreePhysMem(VirtualAddress);
}

VOID DumpDescriptor(DDMA_DESCRIPTOR_STD *pDesc)
{
	RETAILMSG(1,(TEXT("Descriptor @ 0x%08X\r\n"),pDesc));
	RETAILMSG(1,(TEXT("cmd0    %08X\r\n"),pDesc->cmd0));
	RETAILMSG(1,(TEXT("cmd1    %08X\r\n"),pDesc->cmd1));
	RETAILMSG(1,(TEXT("source0 %08X\r\n"),pDesc->source0));
	RETAILMSG(1,(TEXT("source1 %08X\r\n"),pDesc->source1));
	RETAILMSG(1,(TEXT("dest0   %08X\r\n"),pDesc->dest0));
	RETAILMSG(1,(TEXT("dest1   %08X\r\n"),pDesc->dest1));
	RETAILMSG(1,(TEXT("stat    %08X\r\n"),pDesc->stat));
	RETAILMSG(1,(TEXT("nxt_ptr %08X (%08X)\r\n"),pDesc->nxt_ptr,pDesc->nxt_ptr<<5));
	RETAILMSG(1,(TEXT("================\r\n")));
}

VOID DumpDescriptorChain(DDMA_DESCRIPTOR_STD *pHead)
{
	while(pHead->cmd0 & DDMA_DESCCMD_V) {
		DumpDescriptor(pHead);
		pHead++;
	}
}


VOID DumpChannel(DDMA_CHANNEL *pChannel)
{
	RETAILMSG(1,(TEXT("DDMA Channel @ 0x%08X\r\n"),pChannel));
	RETAILMSG(1,(TEXT("cfg      %08X\r\n"),pChannel->cfg));
	RETAILMSG(1,(TEXT("des_ptr  %08X\r\n"),pChannel->des_ptr));
	RETAILMSG(1,(TEXT("stat_ptr %08X\r\n"),pChannel->stat_ptr));
	RETAILMSG(1,(TEXT("irq      %08X\r\n"),pChannel->irq));
	RETAILMSG(1,(TEXT("stat     %08X\r\n"),pChannel->stat));
	RETAILMSG(1,(TEXT("bytecnt  %08X\r\n"),pChannel->bytecnt));
	RETAILMSG(1,(TEXT("=================\r\n")));
}

VOID DumpAdapter(PCHANNEL_OBJECT ChannelObject)
{
	RETAILMSG(1,(TEXT("--------> DMA CHANNEL %d <----------\r\n"),ChannelObject->DmaChannel));
	RETAILMSG(1,(TEXT("DESCRIPTOR A %08X (phys=%08X)\r\n"),ChannelObject->pDescA,ChannelObject->DescAPhys.LowPart));
	RETAILMSG(1,(TEXT("DESCRIPTOR B %08X (phys=%08X)\r\n"),ChannelObject->pDescB,ChannelObject->DescBPhys.LowPart));
	RETAILMSG(1,(TEXT("Buffer A     %08X (phys=%08X)\r\n"),ChannelObject->pBufferA,ChannelObject->BufferAPhys.LowPart));
	RETAILMSG(1,(TEXT("buffer B     %08X (phys=%08X)\r\n"),ChannelObject->pBufferB,ChannelObject->BufferBPhys.LowPart));

	DumpChannel(ChannelObject->DmaRegPtr);
	DumpDescriptor(ChannelObject->pDescA);
	DumpDescriptor(ChannelObject->pDescB);
}


// Passing zero or NULL uses defaults for the channel, sometimes a default can't be used and a value is required.
BOOL HalInitDmaChannel(PDMA_CHANNEL_OBJECT DmaChannelObject,
                       DMA_LOGICAL_DEVICE  Device,
                       ULONG               BufferSize,
					   BOOL                InterruptEnable)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	DDMA_DEVICE_CONFIG *pDevCfg;
	ULONG descCmd;

	// Check Device is in range
	if (Device >= MAX_DMA_LOGICAL_DEVICES) {
		RETAILMSG(1,(TEXT("HalInitDmaChannel: Device %d is out of range\r\n"),Device));
		goto errorReturn;
	}

	pDevCfg = &DdmaConfig[Device];
	// Check Device has valid configuration
	if (!pDevCfg->Valid) {
		RETAILMSG(1,(TEXT("HalInitDmaChannel: Device %d does not have valid configuration\r\n"),Device));
		goto errorReturn;
	}

	ChannelObject->pDevCfg = pDevCfg;
	ChannelObject->BufferSize = BufferSize;
	ChannelObject->Name = pDevCfg->Name;
	ChannelObject->DeviceID = Device;

	// Allocate two buffers
    ChannelObject->BufferAPhys.QuadPart = 0;
    ChannelObject->BufferBPhys.QuadPart = 0;

    ChannelObject->pBufferA = AllocPhysMem(BufferSize*2,
                                           PAGE_READWRITE | PAGE_NOCACHE,
                                           DMA_ALIGNMENT_REQUIREMENT,
                                           0,
                                           &ChannelObject->BufferAPhys.LowPart);

	ChannelObject->pBufferB = (PUCHAR)(ChannelObject->pBufferA) + BufferSize;
	ChannelObject->BufferBPhys.LowPart = ChannelObject->BufferAPhys.LowPart + BufferSize;

	// Allocate two descriptors
	ChannelObject->DescAPhys.QuadPart = 0;
	ChannelObject->DescBPhys.QuadPart = 0;

	ChannelObject->pDescA = AllocPhysMem(sizeof(DDMA_DESCRIPTOR_STD) * 4, // IMR TEST
                                           PAGE_READWRITE | PAGE_NOCACHE,
                                           DMA_ALIGNMENT_REQUIREMENT,
                                           0,
                                           &ChannelObject->DescAPhys.LowPart);
	ChannelObject->pDescB = (PVOID)((PUCHAR)(ChannelObject->pDescA) + (2*sizeof(DDMA_DESCRIPTOR_STD)));
	ChannelObject->DescBPhys.LowPart = ChannelObject->DescAPhys.LowPart + (2*sizeof(DDMA_DESCRIPTOR_STD));

	// Setup the descriptors
	descCmd = pDevCfg->DescCmd;

	if (InterruptEnable) {
		ChannelObject->InterruptsEnabled = TRUE;
		descCmd |= DDMA_DESCCMD_IE;
	}

	descCmd |= DDMA_DESCCMD_CV;		// clear valid bit after descriptor completion

	if (pDevCfg->DevIsRead) {
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->source0, pDevCfg->FifoAddr);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->source0, pDevCfg->FifoAddr);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->dest0, ChannelObject->BufferAPhys.LowPart);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->dest0, ChannelObject->BufferBPhys.LowPart);
	} else {
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->dest0, pDevCfg->FifoAddr);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->dest0, pDevCfg->FifoAddr);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->source0, ChannelObject->BufferAPhys.LowPart);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->source0, ChannelObject->BufferBPhys.LowPart);
	}
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->source1, pDevCfg->DescSrc1);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->source1, pDevCfg->DescSrc1);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->dest1, pDevCfg->DescDest1);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->dest1, pDevCfg->DescDest1);

	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->cmd0, descCmd);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->cmd0, descCmd);

	// Setup the loop
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->nxt_ptr, ChannelObject->DescBPhys.LowPart >> 5);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->nxt_ptr, ChannelObject->DescAPhys.LowPart >> 5);

	// Setup channel config
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->cfg, pDevCfg->ChanCfg);

	// Setup descriptor pointer to A
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->des_ptr,ChannelObject->DescAPhys.LowPart);
	ChannelObject->NextDMABuffer = ChannelObject->DescAPhys.LowPart;

	RETAILMSG(1,(TEXT("HalInitDmaChannel: Channel %d initialized for %s\r\n"),ChannelObject->DmaChannel,ChannelObject->Name));

    return TRUE;

errorReturn:
	// TODO Cleanup buffers etc..
	return FALSE;
}


PVOID HalGetNextDMABuffer(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	int nextBuffer = 0;
	ULONG des_ptr;

	// TRANSMIT
	// Get current descriptor.
	// If valid bit is clear in other descriptor return the other descriptor


	// RECEIVE
	// Get current descriptor
	// If valid bit is clear in other descriptor return the other descriptor


	des_ptr = ChannelObject->NextDMABuffer; // READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->des_ptr);

	if (des_ptr == ChannelObject->DescAPhys.LowPart) {
		// check for halted...
		if (READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->stat) & DDMA_CHANSTATUS_H) {
			if (READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->cmd0) & DDMA_DESCCMD_V) {
				nextBuffer = 1;
			} else {
				nextBuffer = 0;
			}
		} else {
			if (ChannelObject->pDevCfg->DevIsRead && !(READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->cmd0) & DDMA_DESCCMD_V)) {
				nextBuffer = 1;
			} else if (!ChannelObject->pDevCfg->DevIsRead && (READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->cmd0) & DDMA_DESCCMD_V)) {
				nextBuffer = 1;
			} else {
				nextBuffer = 0;
			}
		}
	} else if (des_ptr == ChannelObject->DescBPhys.LowPart) {
		if (READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->stat) & DDMA_CHANSTATUS_H) {
			if (READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->cmd0) & DDMA_DESCCMD_V) {
				nextBuffer = 0;
			} else {
				nextBuffer = 1;
			}
		} else {
			if (ChannelObject->pDevCfg->DevIsRead && !(READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->cmd0) & DDMA_DESCCMD_V)) {
				nextBuffer = 0;
			} else if (!ChannelObject->pDevCfg->DevIsRead && (READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->cmd0) & DDMA_DESCCMD_V)) {
				nextBuffer = 0;
			} else {
				nextBuffer = 1;
			}
		}
	} else {
		RETAILMSG(1,(TEXT("HalGetNextDMABuffer(%s): Unknown descriptor in use 0x%08X\r\n"),ChannelObject->Name,des_ptr));
		DumpAdapter(ChannelObject);
	}

	if (0==nextBuffer) {
		RETAILMSG(MSGS,(TEXT("HalGetNextDMABuffer(%s) A 0x%08X\r\n"),ChannelObject->Name,ChannelObject->pBufferA));
		ChannelObject->BufferStateA = BUFFER_OFF;
		return ChannelObject->pBufferA;
	} else {
		RETAILMSG(MSGS,(TEXT("HalGetNextDMABuffer(%s) B 0x%08X\r\n"),ChannelObject->Name,ChannelObject->pBufferB));
		ChannelObject->BufferStateB = BUFFER_OFF;
		return ChannelObject->pBufferB;
	}
}

BOOL HalActivateDMABuffer(PDMA_CHANNEL_OBJECT DmaChannelObject,
                          PVOID               pBuffer,
                          ULONG               Size)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	DDMA_DESCRIPTOR_STD *pDesc;
	ULONG physAddr;
	ULONG cmd0;

//  Some testcode to make sure we are ping-ponging correctly...
//
	/*
	if (!(ChannelObject->pDescA->cmd0 & DDMA_DESCCMD_V) && !(ChannelObject->pDescB->cmd0 & DDMA_DESCCMD_V)) {
		RETAILMSG(1,(TEXT("%s - NO ACTIVE BUFFERS\r\n"),ChannelObject->Name));
	}
	*/

	if (pBuffer==ChannelObject->pBufferA) {
		RETAILMSG(MSGS,(TEXT("HalActivateDMABuffer(%s)                       A %d\r\n\n"),ChannelObject->Name,Size));
		pDesc = ChannelObject->pDescA;
		physAddr = ChannelObject->BufferAPhys.LowPart;
		ChannelObject->BufferStateA = BUFFER_VALID;
	} else if (pBuffer==ChannelObject->pBufferB) {
		RETAILMSG(MSGS,(TEXT("HalActivateDMABuffer(%s)                       B %d\r\n\n"),ChannelObject->Name,Size));
		pDesc = ChannelObject->pDescB;
		physAddr = ChannelObject->BufferBPhys.LowPart;
		ChannelObject->BufferStateB = BUFFER_VALID;
	} else {
		RETAILMSG(1,(TEXT("HalActivateDMABuffer(%s) Invalid buffer address 0x%X\r\n"),ChannelObject->Name,(ULONG)pBuffer));
		return FALSE;
	}

	WRITE_REGISTER_ULONG((PULONG)&pDesc->cmd1,Size);

	cmd0 = READ_REGISTER_ULONG((PULONG)&pDesc->cmd0);
	cmd0 |= DDMA_DESCCMD_V;
	WRITE_REGISTER_ULONG((PULONG)&pDesc->cmd0,cmd0);

	// ring the doorbell
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->dbell,1);

	return TRUE;
}

BOOL HalStartDMA(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	ULONG cfg;

	RETAILMSG(MSGS,(TEXT("HalStartDMA(%s)\r\n"),ChannelObject->Name));

	// clear interrupt status
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->irq,0);

	// Channel enable.... ring doorbell ?
	// Set enable bit
	cfg = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->cfg);
	cfg |= DDMA_CHANCFG_EN;
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->cfg,cfg);

	/*
	 * There is an errata on the Au1200/Au1550 parts that could result
	 * in "stale" data being DMA'd. It has to do with the snoop logic on
	 * the dcache eviction buffer.
	 * */
	CacheSync(CACHE_SYNC_WRITEBACK);

	// ring the doorbell
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->dbell,1);

	return TRUE;
}


BOOL HalStopDMA(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	ULONG cfg, cmd0;

	RETAILMSG(MSGS,(TEXT("HalStopDMA(%s)\r\n"),ChannelObject->Name));

	// Clear enable bit
	cfg = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->cfg);
	cfg &= ~DDMA_CHANCFG_EN;
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->cfg,cfg);

	// Wait for halt bit
	while (!READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->stat) & DDMA_CHANSTATUS_H)
		;

	// Clear valid bits
	cmd0 = READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->cmd0);
	cmd0 &= ~DDMA_DESCCMD_V;
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->cmd0,cmd0);
	ChannelObject->BufferStateA = BUFFER_OFF;

	cmd0 = READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->cmd0);
	cmd0 &= ~DDMA_DESCCMD_V;
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->cmd0,cmd0);
	ChannelObject->BufferStateB = BUFFER_OFF;

	// clear status bits
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->stat,DDMA_CHANSTATUS_V | DDMA_CHANSTATUS_DB);

	// clear interrupt status
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->irq,0);

	// Reset this just incase DMA stopped in the middle.  That might mess this up.
	ChannelObject->NextDMABuffer = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->des_ptr);

	return TRUE;
}

ULONG HalCheckForDMAInterrupt(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
	ULONG retVal = 0;
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	if (!(READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->stat) & DDMA_CHANSTATUS_H)) {

		// Check which buffer is next and only check to see if that buffer is done
//		if (ChannelObject->NextDMABuffer == ChannelObject->DescAPhys.LowPart)
		{
			if ((ChannelObject->BufferStateA == BUFFER_VALID) &&
				!(READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->cmd0) & DDMA_DESCCMD_V)) {
//				return 0x1;
				retVal |= 1;
			}
		}


//		if (ChannelObject->NextDMABuffer == ChannelObject->DescBPhys.LowPart)
		{
			if ((ChannelObject->BufferStateB == BUFFER_VALID) &&
				!(READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->cmd0) & DDMA_DESCCMD_V)) {
//				return 0x2;
				retVal |= 2;
			}
		}
	}

//	return 0;
	return retVal;
}

BOOL HalAckDMAInterrupt(PDMA_CHANNEL_OBJECT DmaChannelObject,
                        ULONG Mask)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	if (Mask == 0x1) {
		ChannelObject->BufferStateA = BUFFER_DONE;
		ChannelObject->NextDMABuffer = ChannelObject->DescBPhys.LowPart;
	}
	else if (Mask == 0x2) {
		ChannelObject->BufferStateB = BUFFER_DONE;
		ChannelObject->NextDMABuffer = ChannelObject->DescAPhys.LowPart;
	}
	else
	{
		// Attempt to Ping-Pong to avoid errors -- if possible
		if ( ChannelObject->NextDMABuffer == ChannelObject->DescAPhys.LowPart )
			ChannelObject->NextDMABuffer = ChannelObject->DescBPhys.LowPart;
		else
			ChannelObject->NextDMABuffer = ChannelObject->DescAPhys.LowPart;
	}


	return TRUE;
}

BOOL HalSetDMAForReceive(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	HalActivateDMABuffer(DmaChannelObject,
                         ChannelObject->pBufferA,
                         ChannelObject->BufferSize);

	HalActivateDMABuffer(DmaChannelObject,
                         ChannelObject->pBufferB,
                         ChannelObject->BufferSize);

	return TRUE;
}

UCHAR HalGetDMAHwIntr(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	return (UCHAR)(HWINTR_DDMA_BASE + ChannelObject->DmaChannel);
}

ULONG HalGetDMABufferRxSize(PDMA_CHANNEL_OBJECT DmaChannelObject,
                            PVOID pBuffer)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	ULONG size = 0;
	ULONG cmd0, cfg;
	ULONG nextDesPtr;

	// RECEIVE
	// Check descriptor, if V not set then return full buffer size
	// Else, halt DMA, return bytecnt reg
	if (pBuffer==ChannelObject->pBufferA) {
		cmd0 = READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->cmd0);
		nextDesPtr = ChannelObject->DescBPhys.LowPart;
	} else if (pBuffer==ChannelObject->pBufferB) {
		cmd0 = READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->cmd0);
		nextDesPtr = ChannelObject->DescAPhys.LowPart;
	} else {
		RETAILMSG(1,(TEXT("HalGetDMABufferRxSize(%s): Invalid buffer 0x%08X\r\n"),ChannelObject->Name,pBuffer));
		return 0;
	}

	if (cmd0 & DDMA_DESCCMD_V) {
		// Clear enable bit
		cfg = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->cfg);
		cfg &= ~DDMA_CHANCFG_EN;
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->cfg,cfg);

		// Wait for halt bit
		while (!READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->stat) & DDMA_CHANSTATUS_H)
			;

		size = ChannelObject->BufferSize - READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->bytecnt);
		// IMR - not sure about this.... move to next descriptor
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->stat,DDMA_CHANSTATUS_V|DDMA_CHANSTATUS_DB);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->des_ptr,nextDesPtr);
		HalStartDMA(DmaChannelObject);
	} else {
		size = ChannelObject->BufferSize;
	}

	RETAILMSG(MSGS,(TEXT("HalGetDMABufferRxSize(%s): %d\r\n"),ChannelObject->Name,size));

	return size;
}

VOID HalWaitForDMA(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	RETAILMSG(MSGS,(TEXT("+HalWaitForDMA(%s)\r\n"),ChannelObject->Name));

	while (1) {

		if (!(READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->cmd0) & DDMA_DESCCMD_V) &&
			!(READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->cmd0) & DDMA_DESCCMD_V)) {
			break;
		}

		Sleep(0);
	}
}

BOOL HalDMAIsUnderflowed(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	// If either descriptor A or B is Valid then we're not starving the DMA...

	if ((READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->cmd0) & DDMA_DESCCMD_V) ||
	    (READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->cmd0) & DDMA_DESCCMD_V)) {
		return FALSE;
	} else {
		return TRUE;
	}
}

// Keep existing BufferSize and InteruptEnable
BOOL HalReconfigureDMA(PDMA_CHANNEL_OBJECT DmaChannelObject,
                       DMA_LOGICAL_DEVICE  Device)

{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	DDMA_DEVICE_CONFIG *pDevCfg;
	ULONG descCmd;

	if (ChannelObject->DeviceID == Device) {
		RETAILMSG(MSGS,(TEXT("HalReconfigureDMA: Channel already configured for %s\r\n"),ChannelObject->Name));
		return TRUE;
	}

	// Check Device is in range
	if (Device >= MAX_DMA_LOGICAL_DEVICES) {
		RETAILMSG(1,(TEXT("HalReconfigureDMA: Device %d is out of range\r\n"),Device));
		goto errorReturn;
	}

	pDevCfg = &DdmaConfig[Device];
	// Check Device has valid configuration
	if (!pDevCfg->Valid) {
		RETAILMSG(1,(TEXT("HalReconfigureDMA: Device %d does not have valid configuration\r\n"),Device));
		goto errorReturn;
	}

	HalStopDMA(DmaChannelObject);

	ChannelObject->Name = pDevCfg->Name;
	ChannelObject->DeviceID = Device;
	ChannelObject->pDevCfg = pDevCfg;

	// Setup the descriptors
	descCmd = pDevCfg->DescCmd;

	if (ChannelObject->InterruptsEnabled) {
		descCmd |= DDMA_DESCCMD_IE;
	}

	descCmd |= DDMA_DESCCMD_CV;		// clear valid bit after descriptor completion

	if (pDevCfg->DevIsRead) {
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->source0, pDevCfg->FifoAddr);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->source0, pDevCfg->FifoAddr);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->dest0, ChannelObject->BufferAPhys.LowPart);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->dest0, ChannelObject->BufferBPhys.LowPart);
	} else {
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->dest0, pDevCfg->FifoAddr);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->dest0, pDevCfg->FifoAddr);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->source0, ChannelObject->BufferAPhys.LowPart);
		WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->source0, ChannelObject->BufferBPhys.LowPart);
	}

	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->source1, pDevCfg->DescSrc1);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->source1, pDevCfg->DescSrc1);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->dest1, pDevCfg->DescDest1);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->dest1, pDevCfg->DescDest1);

	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->cmd0, descCmd);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->cmd0, descCmd);

	// Setup the loop
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescA->nxt_ptr, ChannelObject->DescBPhys.LowPart >> 5);
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescB->nxt_ptr, ChannelObject->DescAPhys.LowPart >> 5);

	// Setup channel config
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->cfg, pDevCfg->ChanCfg);

	// Setup descriptor pointer to A
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->des_ptr,ChannelObject->DescAPhys.LowPart);

	RETAILMSG(MSGS,(TEXT("HalReconfigureDMA: Channel %d initialized for %s\r\n"),ChannelObject->DmaChannel,ChannelObject->Name));

    return TRUE;

errorReturn:
	// TODO Cleanup buffers etc..
	return FALSE;
}


BOOL HalSetupMdlDMA(PDMA_CHANNEL_OBJECT DmaChannelObject,
                    PMDL                pMDLHead,
					BOOL                ReadTransfer)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	DWORD totalNumPages = 0, numPages, i;
	PMDL pMDL;
	PULONG *pPFNs;
	DDMA_DESCRIPTOR_STD *pDesc;
	ULONG descPhysAddr;
	ULONG bytesRemaining, pageLength;

	// Get number of pages
	pMDL = pMDLHead;

	while (pMDL) {
		totalNumPages += ADDRESS_AND_SIZE_TO_SPAN_PAGES(pMDL->StartVa, pMDL->ByteCount);
		pMDL = pMDL->Next;
	}

	// Allocate more descriptors if necessary
	if ((totalNumPages+1) > ChannelObject->AllocatedDescriptors) {
		if (ChannelObject->pDescriptors) {
			FreePhysMem((PVOID)ChannelObject->pDescriptors);
		}

		ChannelObject->AllocatedDescriptors = (totalNumPages+1);
		ChannelObject->pDescriptors = AllocPhysMem(ChannelObject->AllocatedDescriptors * sizeof(*ChannelObject->pDescriptors),
		                                           PAGE_READWRITE | PAGE_NOCACHE,
		                                           DMA_ALIGNMENT_REQUIREMENT,
		                                           0,
		                                           &ChannelObject->DescriptorsPhysAddr.LowPart);
	}

	// Fill in descriptor entries
	pMDL = pMDLHead;
	pDesc = ChannelObject->pDescriptors;
	descPhysAddr = ChannelObject->DescriptorsPhysAddr.LowPart;

	// check for unaligned start address...
	if ( (ULONG)pMDL->StartVa & 31) {
		ULONG byteCount = 0;
		PUCHAR pTemp;

		// This is an unaligned buffer... we need to allocate our own aligned
		// buffer and then memcpy the data as required
		// For the sake of simplicity, allocate enough for all MDLs in the list...
		pMDL = pMDLHead;
		while (pMDL) {
			byteCount += pMDL->ByteCount;
			pMDL = pMDL->Next;
		}


		// allocate our own buffer and copy data
		ChannelObject->AlignedByteCount = byteCount;
		ChannelObject->pAlignedBuffer = AllocPhysMem(byteCount,
			                                         PAGE_READWRITE | PAGE_NOCACHE,
													 DMA_ALIGNMENT_REQUIREMENT,
													 0,
													 &ChannelObject->AlignedPhysAddr.LowPart);

		if (NULL==ChannelObject->pAlignedBuffer) {
			return FALSE;
		}

		// copy data to write buffer
		if (!ReadTransfer) {
			pTemp = ChannelObject->pAlignedBuffer;
			pMDL = pMDLHead;
			while (pMDL) {
				memcpy(pTemp,pMDL->StartVa,pMDL->ByteCount);
				pTemp += pMDL->ByteCount;
				pMDL = pMDL->Next;
			}
		}

		if (ReadTransfer) {
			pDesc->source0 = ChannelObject->pDevCfg->FifoAddr;
			pDesc->dest0   = ChannelObject->AlignedPhysAddr.LowPart;
		} else {
			pDesc->source0 = ChannelObject->AlignedPhysAddr.LowPart;
			pDesc->dest0   = ChannelObject->pDevCfg->FifoAddr;
		}

		pDesc->source1 = ChannelObject->pDevCfg->DescSrc1;
		pDesc->dest1   = ChannelObject->pDevCfg->DescDest1;
		pDesc->cmd0    = ChannelObject->pDevCfg->DescCmd | DDMA_DESCCMD_CV | DDMA_DESCCMD_V;
		pDesc->cmd1    = byteCount;
		pDesc->nxt_ptr = (descPhysAddr + sizeof(DDMA_DESCRIPTOR_STD)) >> 5;
		pDesc++;

	} else {

		while (pMDL) {
			numPages = ADDRESS_AND_SIZE_TO_SPAN_PAGES(pMDL->StartVa, pMDL->ByteCount);
			pPFNs = (PULONG*)(pMDL+1);
			bytesRemaining = pMDL->ByteCount;


			// Put each page into a new descriptor
			for (i=0;i<numPages;i++) {
				if (ReadTransfer) {
					pDesc->source0 = ChannelObject->pDevCfg->FifoAddr;
					pDesc->dest0   = (ULONG)pPFNs[i];
					if (i==0) pDesc->dest0   += pMDL->ByteOffset;
				} else {
					pDesc->source0 = (ULONG)pPFNs[i];
					pDesc->dest0   = ChannelObject->pDevCfg->FifoAddr;
					if (i==0) pDesc->source0 += pMDL->ByteOffset;
				}

				pDesc->source1 = ChannelObject->pDevCfg->DescSrc1;
				pDesc->dest1   = ChannelObject->pDevCfg->DescDest1;
				pDesc->cmd0    = ChannelObject->pDevCfg->DescCmd | DDMA_DESCCMD_CV | DDMA_DESCCMD_V;

				// special case for page 0, might need to use an offset
				if (i==0) {
					pageLength = PAGE_SIZE - pMDL->ByteOffset;
				} else {
					pageLength = PAGE_SIZE;
				}

				if (pageLength > bytesRemaining) {
					pageLength = bytesRemaining;
				}

				pDesc->cmd1    = pageLength;
				bytesRemaining -= pageLength;

				// Fill in next pointer
				pDesc->nxt_ptr = (descPhysAddr + sizeof(DDMA_DESCRIPTOR_STD)) >> 5;
				descPhysAddr += sizeof(DDMA_DESCRIPTOR_STD);
				pDesc++;
			}

			pMDL = pMDL->Next;
		}
	}

	// Terminate descriptor list by clearing valid bit
	pDesc->cmd0 &= ~DDMA_DESCCMD_V;
	// Unwind to the last valid descriptor and add interrupt generation
	pDesc--;
	pDesc->cmd0 |= DDMA_DESCCMD_IE;

	// Write start of descriptors
	ChannelObject->DmaRegPtr->des_ptr = ChannelObject->DescriptorsPhysAddr.LowPart;

//	DumpChannel(ChannelObject->DmaRegPtr);
//	DumpDescriptorChain(ChannelObject->pDescriptors);

	return TRUE;
}

BOOL HalStartMdlDMA(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	// Enable channel
	ChannelObject->DmaRegPtr->cfg |= DDMA_CHANCFG_EN;

	/*
	 * There is an errata on the Au1200/Au1550 parts that could result
	 * in "stale" data being DMA'd. It has to do with the snoop logic on
	 * the dcache eviction buffer.
	 * */
	CacheSync(CACHE_SYNC_WRITEBACK);

	// And off we go
	ChannelObject->DmaRegPtr->dbell = 1;

	return TRUE;
}

BOOL HalCompleteMdlDMA(PDMA_CHANNEL_OBJECT DmaChannelObject, PMDL pMDLHead)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	PMDL pMDL;
	PUCHAR pTemp = ChannelObject->pAlignedBuffer;

	// If we needed to allocate an aligned buffer
	// then copy the data out (for reads) and
	// free the buffer.
	if (ChannelObject->pAlignedBuffer) {
		if (ChannelObject->pDevCfg->DevIsRead) {
			pMDL = pMDLHead;
			while (pMDL) {
				memcpy(pMDL->StartVa,pTemp,pMDL->ByteCount);
				pTemp += pMDL->ByteCount;
				pMDL = pMDL->Next;
			}
		}
		FreePhysMem(ChannelObject->pAlignedBuffer);
		ChannelObject->pAlignedBuffer = NULL;
	}

	return TRUE;
}

BOOL HalStopMdlDMA(PDMA_CHANNEL_OBJECT DmaChannelObject, ULONG* pSize)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;
	ULONG cfg, cmd0;
    ULONG i;

	RETAILMSG(MSGS,(TEXT("HalStopMdlDMA(%s)\r\n"),ChannelObject->Name));

	// Clear enable bit
	cfg = READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->cfg);
	cfg &= ~DDMA_CHANCFG_EN;
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->cfg,cfg);

	// Wait for halt bit
	while (!READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->stat) & DDMA_CHANSTATUS_H)
		;

	// clear status bits
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->stat,
                         DDMA_CHANSTATUS_V | DDMA_CHANSTATUS_DB);

	// calculate the actual transfer size
    if (pSize) {
        *pSize = 0;
        for (i=0; i<ChannelObject->AllocatedDescriptors-1; ++i) {
            *pSize += READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescriptors[i].cmd1) & 0x003fffff;
            cmd0 = READ_REGISTER_ULONG((PULONG)&ChannelObject->pDescriptors[i].cmd0);
            if (cmd0 & DDMA_DESCCMD_V) {
                *pSize -= READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->bytecnt);
                break; // because no remaining descrs will have been processed
            }
            cmd0 &= ~DDMA_DESCCMD_V;
            WRITE_REGISTER_ULONG((PULONG)&ChannelObject->pDescriptors[i].cmd0,cmd0);
        }
    }

	// clear interrupt status
	WRITE_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->irq,0);

	return TRUE;
}

ULONG HalCheckForMdlDMAInterrupt(PDMA_CHANNEL_OBJECT DmaChannelObject)
{
    PCHANNEL_OBJECT ChannelObject = (PCHANNEL_OBJECT)DmaChannelObject;

	if (!(READ_REGISTER_ULONG((PULONG)&ChannelObject->DmaRegPtr->stat) & DDMA_CHANSTATUS_H)) {
        return 1;
	}

	return 0;
}

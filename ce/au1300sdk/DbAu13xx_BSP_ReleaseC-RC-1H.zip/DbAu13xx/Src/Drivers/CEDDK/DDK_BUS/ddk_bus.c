/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "bceddk.h"
#include "platform.h"

BOOLEAN
HalTranslateBusAddress(
    IN INTERFACE_TYPE InterfaceType,
    IN ULONG BusNumber,
    IN PHYSICAL_ADDRESS BusAddress,
    IN OUT PULONG AddressSpace,
    OUT PPHYSICAL_ADDRESS TranslatedAddress
    )
{
    BOOLEAN success = FALSE;

	// Warning this function performs no error checking for
	// valid address regions

	switch( InterfaceType )
	{
	case PCMCIABus:
		RETAILMSG(1,(TEXT("HalTranslateBusAddress::PCMCIA %X\r\n"),
			BusAddress.QuadPart + PCMCIA_IO_PHYS_ADDR));
        *AddressSpace = 0;
		TranslatedAddress->QuadPart = BusAddress.QuadPart + PCMCIA_IO_PHYS_ADDR;
		success = TRUE;
		break;

    case Internal:
        *AddressSpace = 0;
        TranslatedAddress->QuadPart = BusAddress.QuadPart;
        success = TRUE;
		break;

	// Unsupported bus types
	default:
		success = FALSE;
		break;
	}

	return success;
}


NTHALAPI
ULONG
HalGetBusDataByOffset(
    IN BUS_DATA_TYPE BusDataType,
    IN ULONG BusNumber,
    IN ULONG SlotNumber,
    IN PVOID Buffer,
    IN ULONG Offset,
    IN ULONG Length
    )
{
	return 0;
}

NTHALAPI
ULONG
HalSetBusDataByOffset(
    IN BUS_DATA_TYPE BusDataType,
    IN ULONG BusNumber,
    IN ULONG SlotNumber,
    IN PVOID Buffer,
    IN ULONG Offset,
    IN ULONG Length
    )
{

    return(0);
}

NTHALAPI
BOOLEAN
HalTranslateSystemAddress(
    IN  INTERFACE_TYPE    InterfaceType,
    IN  ULONG             BusNumber,
    IN  PHYSICAL_ADDRESS  SystemAddress,
    OUT PPHYSICAL_ADDRESS TranslatedAddress
    )
{

    // Valid arguments?
    //
    if (!TranslatedAddress)
        return(FALSE);

    // Default case.
    //
    TranslatedAddress->QuadPart = SystemAddress.QuadPart;

    return(TRUE);
}

ULONG ulExtension = 0;

VOID
BusEntry(
    VOID
    )

{
    return;
}



/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "backlight.h"

#define Backlight_DEBUG_MSG		0


VOID SetBacklightState(BOOL On)
{

	if(On){
		#ifdef PLATFORM_BACKLIGHT_POWERUP_CODE
		   PLATFORM_BACKLIGHT_POWERUP_CODE
		#endif
	}
	else{
		#ifdef PLATFORM_BACKLIGHT_POWERDOWN_CODE
		  PLATFORM_BACKLIGHT_POWERDOWN_CODE
		#endif
	}

}

DWORD GetBacklightState()
{
#ifdef PLATFORM_BACKLIGHT_STATUS_CODE
	PLATFORM_BACKLIGHT_STATUS_CODE
#else
	return D0;
#endif
}

BOOL BKL_Close(DWORD hOpenContext)
{
	return TRUE;
}

BOOL BKL_IOControl(DWORD Handle,
			DWORD dwIoControlCode,
			PDWORD pInBuf,
			DWORD nInBufSize,
                     PBYTE pOutBuf,
                     DWORD nOutBufSize,
                     PDWORD pBytesReturned)
{
	DWORD dwRet = FALSE;
	PPOWER_CAPABILITIES PowerCaps;
	CEDEVICE_POWER_STATE ReqDx;

   //RETAILMSG(Backlight_DEBUG_MSG, (TEXT("++BKL_IOControl: Handle = 0x%x, dwIoControlCode = 0x%x\r\n"), Handle, dwIoControlCode));

	switch (dwIoControlCode) {
		case IOCTL_POWER_CAPABILITIES:
			  RETAILMSG(Backlight_DEBUG_MSG, (TEXT("BKL_IOControl: IOCTL_POWER_CAPABILITIES:\r\n")));
			if (pOutBuf && nOutBufSize >=  sizeof(POWER_CAPABILITIES) && pBytesReturned ){
				PowerCaps = (PPOWER_CAPABILITIES)pOutBuf;
				memset(PowerCaps, 0, sizeof(PowerCaps));
				PowerCaps->DeviceDx = 0x1F;	//Supporting D0 to D4
				*pBytesReturned = sizeof(*PowerCaps);
				dwRet = TRUE;
			}
			 break;

		case IOCTL_POWER_QUERY:
			//RETAILMSG(Backlight_DEBUG_MSG, (TEXT("BKL_IOControl: IOCTL_POWER_QUERY:\r\n")));
			if (pOutBuf && nOutBufSize >= sizeof(CEDEVICE_POWER_STATE)){
				ReqDx = *(PCEDEVICE_POWER_STATE)pOutBuf;
				if(VALID_DX(ReqDx))
                    		{
                        		// this is a valid Dx state so return a good status
                        		dwRet = TRUE;
                    		}
                    		else
                    			dwRet = FALSE;
			}
			break;

		case IOCTL_POWER_GET:
			RETAILMSG(Backlight_DEBUG_MSG, (TEXT("BKL_IOControl: IOCTL_POWER_GET:\r\n")));
			if (pOutBuf != NULL  && nOutBufSize >= sizeof(CEDEVICE_POWER_STATE)){
				*((PCEDEVICE_POWER_STATE) pOutBuf) = GetBacklightState();
				dwRet = TRUE;
			}
			break;

		case IOCTL_POWER_SET:
			//RETAILMSG(Backlight_DEBUG_MSG, (TEXT("BKL_IOControl: IOCTL_POWER_SET:\r\n")));
			if (pOutBuf && nOutBufSize >= sizeof(CEDEVICE_POWER_STATE)){
				ReqDx = *(PCEDEVICE_POWER_STATE)pOutBuf;
				RETAILMSG(1, (TEXT("BKL_IOControl: IOCTL_POWER_SET to State %x\r\n"), ReqDx));
				if(ReqDx == D1 || ReqDx == D2 || ReqDx == D3){
					ReqDx = D4;
				}
				SetBacklightState(ReqDx == D0 ? TRUE : FALSE);
			}
			dwRet = TRUE;
			break;

		}
//RETAILMSG(Backlight_DEBUG_MSG, (TEXT("--BKL_IOControl \r\n")));
   return dwRet;
}

DWORD BKL_Open(DWORD    hDeviceContext,
               DWORD    AccessCode,
               DWORD    ShareMode)
{
	return hDeviceContext;
}

DWORD BKL_Read(DWORD    hOpenContext,
               LPVOID   pBuffer,
               DWORD    Count)
{
	return 0;
}

DWORD BKL_Seek(DWORD    hOpenContext,
               long     Amount,
               DWORD    Type)
{
	return 0;
}

DWORD BKL_Write(DWORD   hOpenContext,
                LPCVOID pBuffer,
                DWORD   Count)
{
	return 0;
}

VOID BKL_PowerDown(DWORD hDeviceContext)
{
}

VOID BKL_PowerUp(DWORD hDeviceContext)
{
}

BOOL BKL_Deinit(DWORD hContext)
{
	return TRUE;
}

DWORD BKL_Init(DWORD dwContext)
{
	RETAILMSG(1, (TEXT("Backlight: +BKL_Init\r\n")));

// SCB This code has been removed to ensure that the backlight power signals
// do not assert before the lcd power signals. This now executes in the LCD
// controller code lcdgpe.cpp SetRegisters. The CPLD requires this.
#if 0
	#ifdef PLATFORM_BACKLIGHT_POWERUP_CODE
       	PLATFORM_BACKLIGHT_POWERUP_CODE
	#endif
#endif

	RETAILMSG(Backlight_DEBUG_MSG, (TEXT("Backlight: -BKL_Init\r\n")));

	return TRUE;
}

BOOL WINAPI BKL_DllEntry(HINSTANCE  hInstance,
              DWORD      dwReason,
              LPVOID     pReserved)
{
   switch (dwReason) {
      case DLL_PROCESS_ATTACH:
         //RETAILMSG(Backlight_DEBUG_MSG, (TEXT("BKL_DllEntry: DLL_PROCESS_ATTACH\r\n")));
         break;

      case DLL_PROCESS_DETACH:
         //RETAILMSG(Backlight_DEBUG_MSG, (TEXT("BKL_DllEntry: DLL_PROCESS_DETACH\r\n")));
         break;
   }

   // return TRUE for success
   return TRUE;
}




/*++

Copyright:

    Copyright (c) 2002 BSQUARE Corporation.  All rights reserved.

Module Name:

    bklight.h

Abstract:


Author:

    Anand August 2005

Revision History:

--*/

#include <windows.h>
#include <Pm.h>
#include "platform.h"
#include "bceddk.h"



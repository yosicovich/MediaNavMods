/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2006-2007 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

#ifndef _MALI_GL2EXT_H_
#define _MALI_GL2EXT_H_


/*
 * This is the Mali gl wrapper, for use in driver development only
 *  all applications should be built with the stock gl2.h and gl2ext.h
 */

/* current khronos distributed gl.h, must be on include path */
#include <khronos/GLES2/gl2ext.h>

/* driver specific contents can be defined here */

/** ETC */
#define GL_OES_compressed_ETC1_RGB8_texture 1
#define GL_ETC1_RGB8_OES           0x8D64

#endif /* _MALI_GL2EXT_H_ */

This archive contains the Mali drivers for VG, GL ES 1.1, and GL ES 2.0 compiled for 
Windows CE.

Along with these drivers, there are 2 versions of EGL included.  The libEGLOverlay.dll 
will set up the system to render to the 1300's overlay.  The application is required 
to paint the color key in the window to see the 3D output.  Since the system is drawing 
the 3D output directly to the overlay and no data copies occur, this library gives 
the best 3D performance.

Under some circumstances using the overlay will not give the desired behavior.  
Some circumstances might be:

	* When the system needs to display more than 1 3D context.
	* The system needs to put content on top of the 3D content.

In this case, linking the application to the "libEGL.dll" library will set up 
the 3D rendering system such that it will composite the 3D content along with the 
rest of the GDI content.  In this configuration a copy of the 3D data 
occurs, so performance is negatively effected.

It is possible different applications to use the libEGLOverlay and libEGL 
libraries simultaneously. 

Is not possible to switch an application from using the overlay to using 
DirectDraw without recompiling.  Thus the decision can not be made at runtime.

It is possible to test your application with either library by following these steps:

1. Link the application to "libEGL.dll"
2. Place a copy of "libEGLOverlay.dll" in the same directory as the application
3. Rename "libEGLOverlay.dll" to "libEGL.dll"

************************************************************************


Build date :
Thu Dec 2 21:04:06 CST 2010
svn tag : 


VARIANT=
mali200-maligp2-udd-windowsce-gles11-gles20-vg-mmu-r0p4-noeglwait-drawmerge

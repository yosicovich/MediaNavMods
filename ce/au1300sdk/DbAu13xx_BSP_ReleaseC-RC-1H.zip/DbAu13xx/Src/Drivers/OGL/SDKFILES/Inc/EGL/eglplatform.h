/*
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 * (C) COPYRIGHT 2008 ARM Limited
 * ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 */

#ifndef __EGLPLATFORM_H__
#define __EGLPLATFORM_H__

/* Windows calling convention boilerplate */
#if defined(_WIN32) && !defined(APIENTRY) && !defined(__CYGWIN__) && !defined(__SCITECH_SNAP__)
#define WIN32_LEAN_AND_MEAN 1
#include <windows.h>
#endif

/* khronos egl.h uses int32_t for EGLint */
#ifndef int32_t
typedef int int32_t;
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __EGL_EXPORTS
#define EGLAPI __declspec(dllexport)
#else
#define EGLAPI __declspec(dllimport)
#endif
#define EGLAPIENTRY /* not needed */

#include <windows.h>
typedef HWND    NativeWindowType;
typedef HBITMAP NativePixmapType;
typedef HDC     NativeDisplayType;

#ifdef __cplusplus
}
#endif

/* EGL 1.2 types, renamed for consistency in EGL 1.3 */
typedef NativeDisplayType EGLNativeDisplayType;
typedef NativePixmapType EGLNativePixmapType;
typedef NativeWindowType EGLNativeWindowType;

#endif /* __EGLPLATFORM_H__ */


/*****************************************************************************
Copyright 2003-2007 Raza Microelectronics, Inc.(RMI). All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY Raza Microelectronics, Inc. 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*++
Copyright (c) 2004-2005  BSQUARE Corporation.  All rights reserved.
	Original Driver by Ian Rae 2004
++*/

#include <windows.h>
#include <platform.h>
#include <bceddk.h>
#include <smbus.h>
#include "gpio.h"

#define RW_WAIT_TIMEOUT 3000 // Number of ms for timeout in wait functions

#ifdef DEBUG

#define ZONE_INIT                DEBUGZONE(0)
#define ZONE_CLOCKS              DEBUGZONE(1)
#define ZONE_GPIOS               DEBUGZONE(2)
#define ZONE_IOCTL               DEBUGZONE(3)
#define ZONE_FUNC                DEBUGZONE(4)
#define ZONE_WARNING             DEBUGZONE(14)
#define ZONE_ERROR               DEBUGZONE(15)

DBGPARAM dpCurSettings = {
    TEXT("smbus"), {
        TEXT("Init"), TEXT("Clocks"), TEXT("Gpios"), TEXT("IOCTLs"),
        TEXT("-"), TEXT("-"), TEXT("-"), TEXT("-"),
        TEXT("-"), TEXT("-"), TEXT("-"),TEXT("-"),
        TEXT("Alloc"), TEXT(""),TEXT("Warnings"), TEXT("Errors")},
    0x0};
#else
#if 0
#undef DEBUGMSG
#define DEBUGMSG(x,y) RETAILMSG(x,y)
#define ZONE_INIT                1
#define ZONE_CLOCKS              1
#define ZONE_GPIOS               1
#define ZONE_IOCTL               1
#define ZONE_FUNC                1
#define ZONE_WARNING             1
#define ZONE_ERROR               1
#endif
#endif
//
// IOCTLS used to access the driver
//
enum {
    IOCTL_SMBUS_READDATA = 0x80002000,  // some arbirary base
    IOCTL_SMBUS_WRITEDATA
};

//
// Structure for storing device instance data.  There is one of these per
// instance of a device.  We could have 2 devices in the system, in which case
// there would be two of these structures.
//
typedef struct _DEVICE_INSTANCE {
    LONG               OpenCount;      // Number of open handles.
    PSC_SMB *          pSMB;           // The GPIO controller area
    CRITICAL_SECTION   ControlMutex;   // Access control
} DEVICE_INSTANCE, *PDEVICE_INSTANCE;

static BOOL InitializeRegisters(PSC_SMB *pSMB)
{
	BOOL status = TRUE;
	int timeout;

	// Configure the PSC for SMB
	WRITE_REGISTER_ULONG((PULONG)&pSMB->psc.sel, PSC_SEL_PS_SMB | PSC_SEL_CLK_TOY);
	WRITE_REGISTER_ULONG((PULONG)&pSMB->psc.ctl, PSC_CTL_CE |PSC_CTL_EN);

	timeout = 20;

	// wait for clock detect
	while (timeout && !((READ_REGISTER_ULONG((PULONG)&pSMB->sts)) & PSC_SMB_STS_SR)) {
		timeout--;
		StallExecution(100);
	}

	if (!timeout) {
		RETAILMSG(1,(TEXT("Failed waiting for SR\r\n")));
		status = FALSE;
		goto ErrorReturn;
	}

	// Set the SMBus Timer
	// Do nothing for now...

	// Configure the SMBus controller
	WRITE_REGISTER_ULONG((PULONG)&pSMB->msk,0xffffffff);
	WRITE_REGISTER_ULONG((PULONG)&pSMB->cfg, PSC_SMB_CFG_SDIV_N(3) | // div intclk by 16
	                                         PSC_SMB_CFG_TRD_N(0) |
									         PSC_SMB_CFG_RRD_N(0) |
									         PSC_SMB_CFG_DD |
									         PSC_SMB_CFG_DE);

	WRITE_REGISTER_ULONG((PULONG)&pSMB->tmr, 0x3FFFFFFF);

	// wait unti the device is ready
	timeout = 50;
	while (timeout && !((READ_REGISTER_ULONG((PULONG)&pSMB->sts)) & PSC_SMB_STS_DR)) {
		StallExecution(1000);
		timeout--;
	}

	if (!timeout) {
		RETAILMSG(1,(TEXT("Failed waiting for DR\r\n")));
		status = FALSE;
		goto ErrorReturn;
	}

ErrorReturn:
	return status;
}

static BOOL WaitForMasterDone(PSC_SMB *pSMB)
{
	// wait for master done
	ULONG StartTime = GetTickCount();
	ULONG LapsedTime = 0;


	while ((LapsedTime < RW_WAIT_TIMEOUT) && (!(READ_REGISTER_ULONG((PULONG)&pSMB->evnt) & PSC_SMB_EVNT_MD))) {
		LapsedTime = GetTickCount() - StartTime;
	}

	if (LapsedTime > RW_WAIT_TIMEOUT) {
		RETAILMSG(1,(TEXT("SMB:: sts:%08x evnt:%08x pcr:%08x\r\n"),
			pSMB->sts, pSMB->evnt, pSMB->pcr ));
		return FALSE;
	}

	// clear MD
	WRITE_REGISTER_ULONG((PULONG)&pSMB->evnt,PSC_SMB_EVNT_MD);

	return TRUE;
}

static BOOL WaitForFifoEmpty(PSC_SMB *pSMB)
{
	ULONG StartTime = GetTickCount();
	ULONG LapsedTime = 0;

	while ((LapsedTime < RW_WAIT_TIMEOUT) && (!(READ_REGISTER_ULONG((PULONG)&pSMB->sts) & PSC_SMB_STS_TE))) {
		LapsedTime = GetTickCount() - StartTime;
	}

	if (LapsedTime > RW_WAIT_TIMEOUT) {
		RETAILMSG(1,(TEXT("SMB:: sts:%08x evnt:%08x pcr:%08x\r\n"),
			pSMB->sts, pSMB->evnt, pSMB->pcr ));
		return FALSE;
	}

	return TRUE;
}


static BOOL TxFifoFull(PSC_SMB *pSMB)
{
	if ( READ_REGISTER_ULONG((PULONG)&pSMB->sts) & PSC_SMB_STS_TF )
		return TRUE;
	else
		return FALSE;
}


static
BOOL ReadData( PDEVICE_INSTANCE DeviceInstance,
			   SMBUS_TRANSFER   *pTransfer,
	           PUCHAR           pData )
{
	PSC_SMB *pSMB = DeviceInstance->pSMB;
	ULONG i;
	BOOL status = TRUE;

	DEBUGMSG(ZONE_FUNC,(TEXT("SMB ReadData: Addr:%02X\r\n"),pTransfer->Address));

    EnterCriticalSection(&DeviceInstance->ControlMutex);

	// Read the data
	WRITE_REGISTER_ULONG((PULONG)&pSMB->pcr, PSC_SMB_PCR_MS);
	WRITE_REGISTER_ULONG((PULONG)&pSMB->txrx, (pTransfer->Address << 1) | 0x1);
	while( TxFifoFull(pSMB) )
		;

	for (i=0; i<pTransfer->DataSize; i++) {
		if (i==(pTransfer->DataSize-1)) {
			WRITE_REGISTER_ULONG((PULONG)&pSMB->txrx,0 | PSC_SMB_TXRX_STP );
		} else {
			WRITE_REGISTER_ULONG((PULONG)&pSMB->txrx, 0 );
		}

		while( READ_REGISTER_ULONG((PULONG)&pSMB->sts) & PSC_SMB_STS_RE ) ;
		pData[i] = (UCHAR)READ_REGISTER_ULONG((PULONG)&pSMB->txrx);
	}
				// TODO, what about transfers that are too big...
				// need to wait for completion indication while still reading the FIFO

	if (!WaitForMasterDone(pSMB)) {
		RETAILMSG(1,(TEXT("SMB ReadData: Timeout waiting for MASTER DONE\r\n")));
		status = FALSE;
		goto ErrorReturn;
	}

ErrorReturn:
    LeaveCriticalSection(&DeviceInstance->ControlMutex);

	return status;
}

static
BOOL WriteData( PDEVICE_INSTANCE DeviceInstance,
			    SMBUS_TRANSFER   *pTransfer )
{
	PSC_SMB *pSMB = DeviceInstance->pSMB;
	ULONG i;
	BOOL status = FALSE;

    EnterCriticalSection(&DeviceInstance->ControlMutex);

	// Clear previous states
	pSMB->evnt = pSMB->evnt;

	// Write the address
	WRITE_REGISTER_ULONG((PULONG)&pSMB->txrx, (pTransfer->Address << 1) | 0x0);

	// Start Master xfer
	WRITE_REGISTER_ULONG((PULONG)&pSMB->pcr, PSC_SMB_PCR_MS);

	// write the data
	for (i=0; i<pTransfer->DataSize; i++) {

		// Wait for an entry in the fifo to become available
		while(TxFifoFull(pSMB))
			;

		// check for last byte condition
		if (i==(pTransfer->DataSize-1)) {
			WRITE_REGISTER_ULONG((PULONG)&pSMB->txrx, pTransfer->Data[i] | PSC_SMB_TXRX_STP );
		} else {
			WRITE_REGISTER_ULONG((PULONG)&pSMB->txrx, pTransfer->Data[i] );
		}

	}

	if (!WaitForMasterDone(pSMB)) {
		RETAILMSG(1,(TEXT("SMB WriteData: Timeout waiting for MASTER DONE\r\n")));
		goto ErrorReturn;
	}

	// Wait for Master to be not Busy
	while( READ_REGISTER_ULONG((PULONG)&pSMB->sts) & PSC_SMB_STS_MB )  ;

	status = TRUE;

ErrorReturn:
    LeaveCriticalSection(&DeviceInstance->ControlMutex);

	return status;
}


//
// Exported Routines
//

BOOL
WINAPI
DllMain(
    IN HANDLE Instance,
    IN DWORD Reason,
    IN PVOID Reserved
    )
{
    switch (Reason) {

    case DLL_PROCESS_ATTACH:
        DEBUGREGISTER(NULL);
        break;

    case DLL_PROCESS_DETACH:
        break;

    case DLL_THREAD_DETACH:
        break;

    case DLL_THREAD_ATTACH:
        break;

    default:
        break;
    }

    //
    // Always return TRUE.  If FALSE is returned, processes that are starting
    // up will terminate with an error.
    //

    return TRUE;
}

BOOL
SMB_Deinit(
    IN OUT ULONG DeviceContext
    )
{
    PDEVICE_INSTANCE DeviceInstance;

    DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;

    DEBUGMSG(ZONE_INIT, (
             TEXT("SMB: SMB_Deinit(0x%x) entered.\r\n"),
             DeviceContext));

    //
    // Depending on how things should be handled, we can look at the open
    // count and see if there are still open handles to the device before
    // shutting it down.  It is possible to wait until the handles are closed,
    // or just shut the device down.  In this case, we just print a debug
    // message if there are still open handles.
    //

    DEBUGMSG((ZONE_INIT|ZONE_ERROR) && (DeviceInstance->OpenCount != 0), (
             TEXT("SMB: Handles still open.  Shutting down anyway.\r\n")));


    //
    // If we've mapped the device's registers via a call to MmMapIoSpace, we
    // need to unmap the I/O range.
    //

    if (DeviceInstance->pSMB != NULL) {

        MmUnmapIoSpace((PVOID)DeviceInstance->pSMB,
                       sizeof(*(DeviceInstance->pSMB)));

    }

    //
    // Close the handle to the mutex protecting the device's control shadow.
    //

    DeleteCriticalSection(&DeviceInstance->ControlMutex);

    //
    // Finally, the device instance itself can be freed.
    //

    LocalFree(DeviceInstance);

    DEBUGMSG(ZONE_INIT, (
             TEXT("SMB: SMB_Deinit returning TRUE.\r\n")));

    return TRUE;
}


ULONG
SMB_Init(
    IN ULONG RegistryPath
    )
{
    BOOLEAN RoutineSuccess;
    PDEVICE_INSTANCE DeviceInstance;
    PHYSICAL_ADDRESS IoPhysicalAddress;
    PSC_SMB *pSMB;
	HANDLE           hGPIO = NULL;
    RoutineSuccess = FALSE;

    DEBUGMSG(ZONE_INIT, (
             TEXT("SMB: SMB_Init(0x%x) entered.\r\n"),
             RegistryPath));

    //
    // Allocate a structure to hold the state for this instance.  This value
    // is used as a handle and is returned by this routine.  When SMB_Open or
    // SMB_Close is called, this handle will be passed in as a parameter.
    //

    DeviceInstance = LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT,
                                sizeof(*DeviceInstance));

    if (DeviceInstance == NULL) {

        DEBUGMSG(ZONE_INIT|ZONE_ERROR, (
                 TEXT("SMB: Failed to allocate device instance.\r\n")));
        goto ErrorReturn;

    }

    //
    // Use MmMapIoSpace to map in the registers.
    //
#if (PLATFORM_SMBUS_PSC==0)
	IoPhysicalAddress.QuadPart = PSC0_PHYS_ADDR;
#elif (PLATFORM_SMBUS_PSC==1)
	IoPhysicalAddress.QuadPart = PSC1_PHYS_ADDR;
#elif (PLATFORM_SMBUS_PSC==2)
	IoPhysicalAddress.QuadPart = PSC2_PHYS_ADDR;
#elif (PLATFORM_SMBUS_PSC==3)
	IoPhysicalAddress.QuadPart = PSC3_PHYS_ADDR;
#else
#error PLATFORM_SMBUS_PSC must be defined in the range 0 to 3
#endif

	RETAILMSG(1,(L"Initializing PSC%d for SMBUS operation\r\n",PLATFORM_SMBUS_PSC));

    pSMB = MmMapIoSpace(IoPhysicalAddress,
                        sizeof(*pSMB),
                        FALSE);

    if (pSMB == NULL) {

        DEBUGMSG(ZONE_INIT|ZONE_ERROR, (
                 TEXT("SMB: MmMapIoSpace failed to map registers.\r\n")));
        goto ErrorReturn;

    }

    DeviceInstance->pSMB = pSMB;

#ifndef SOC_AU13XX
    hGPIO = GPIO_Init();
    if(hGPIO==INVALID_HANDLE_VALUE) {
        DEBUGMSG(ZONE_ERROR,(L"SMBUS: Can not open GPIO device\r\n"));
        goto ErrorReturn;
    }
#endif

#if defined(CPU_AU1200) && (PLATFORM_SMBUS_PSC==0)
    if(!GPIO_ClearPinFunction(hGPIO,SYS_PINFUNC_P0B)) {
        DEBUGMSG(ZONE_ERROR,(L"SMBUS: Can not set pinfunc for SMBUS \r\n"));
        goto ErrorReturn;
    }
#elif defined(CPU_AU1200) && (PLATFORM_SMBUS_PSC==1)
    if(!GPIO_ClearPinFunction(hGPIO,SYS_PINFUNC_P1A | (1<<22))) {
        DEBUGMSG(ZONE_ERROR,(L"SMBUS: Can not set pinfunc for SMBUS \r\n"));
        goto ErrorReturn;
    }
    if(!GPIO_SetPinFunction(hGPIO,(1<<21))) {
        DEBUGMSG(ZONE_ERROR,(L"SMBUS: Can not set pinfunc for SMBUS \r\n"));
        goto ErrorReturn;
    }
#elif defined(CPU_AU13XX) && (PLATFORM_SMBUS_PSC==3)
	// YAMON Defaults intclk to 48MHz
	// No need to change here. Divide down using baudrate
#endif

	// Handle any platform specific initialization, GPIO handle available if needed
#if defined(PLATFORM_SMBUS_PSC_INIT_CODE)
	PLATFORM_SMBUS_PSC_INIT_CODE
#endif

	// we are done with GPIO now
	if ( hGPIO )
		CloseHandle(hGPIO);

    //
    // Initialize the mutex to protect the device's Control register's shadow.
    //

    InitializeCriticalSection(&DeviceInstance->ControlMutex);

    //
    // Initialize the hardware registers.  We reset the device.
    //
    DEBUGMSG(ZONE_INIT|ZONE_ERROR, (
             TEXT("SMB: SMB_Init initializing SMB registers.\r\n")));


	RoutineSuccess = InitializeRegisters(pSMB);

    DEBUGMSG(ZONE_INIT, (
             TEXT("SMB: SMB_Init finished hardware initialization.\r\n")));

ErrorReturn:

    //
    // If the initialization failed, clean up and return a NULL to signal
    // failure.
    //

    if (RoutineSuccess == FALSE) {

        SMB_Deinit((ULONG)DeviceInstance);
        DeviceInstance = NULL;

    }


    DEBUGMSG((ZONE_INIT|ZONE_ERROR) && (DeviceInstance == NULL), (
             TEXT("SMB: SMB_Init failed.\r\n")));

    return (ULONG)DeviceInstance;
}


/*++

Routine Description:

    This routine is called whenever a call to CreateFile is made and our
    device is specified.  Device.exe will fill in the device context parameter
    with the corresponding pointer to the device instance that was returned
    by SMB_Init.  With this information, SMB_Open is expected to allocate
    resources and return a handle that the caller can use for subsequent
    accesses.


Arguments:

    DeviceContext - Pointer to the device instance structure.

    AccessCode - Desired access type.  These flags are a straight pass through
        from the CreateFile call.

    ShareMode - Desired share mode.  These flags are a straight pass through
        from the CreateFile call.

Return Value:

    The open context handle for this instance if successful or 0 for failure.

--*/
ULONG
SMB_Open(
    IN OUT ULONG DeviceContext,
    IN ULONG AccessCode,
    IN ULONG ShareMode
    )
{
    PDEVICE_INSTANCE DeviceInstance;
    DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;

    DEBUGMSG(ZONE_FUNC, (
             TEXT("SMB: SMB_Open(0x%x, 0x%x, 0x%x) entered.\r\n"),
             DeviceContext,
             AccessCode,
             ShareMode));

    DeviceInstance->OpenCount++;



    DEBUGMSG(ZONE_FUNC, (
             TEXT("SMB: SMB_Open returning 0x%x.\r\n"),
             DeviceContext));

    return (ULONG)DeviceContext;
}



/*++

Routine Description:

    Deallocates resources allocated by SMB_Open and while the handle was
    active.  The routine is called whenever CloseHandle is called on a handle
    that was returned by SMB_Open.

Arguments:

    OpenContext - Pointer to the open instance.  This is the value that was
        returned by SMB_Open.

Return Value:

    TRUE if successful, FALSE otherwise.

--*/BOOL
SMB_Close(
    IN OUT ULONG DeviceContext
    )
{
    PDEVICE_INSTANCE DeviceInstance;
    DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;

    DEBUGMSG(ZONE_FUNC, (
             TEXT("SMB: SMB_Close(0x%x) entered.\r\n"),
             DeviceInstance));

    //
    // Reset the open count that is stored in the device instance.  This
    // releases the device for others to call CreateFile on the stream.
    //

    DeviceInstance->OpenCount--;

    DEBUGMSG(ZONE_FUNC, (TEXT("SMB: SMB_Close returning TRUE.\r\n")));

    return TRUE;
}


/*++

Routine Description:

    Does nothing here

Arguments:

    OpenContext - Pointer to the open instance.  This is the value that was
        returned by SMB_Open.

    ReadBuffer - Pointer to the buffer to receive the read data.

    Count - Number of bytes to be read (space available in ReadBuffer).

Return Value:

    If successful, the number of bytes read.  -1 in the case of failure.

--*/
ULONG
SMB_Read(
    IN OUT ULONG DeviceContext,
    IN PUCHAR ReadBuffer,
    IN ULONG Count
    )
{
    return 0;
}


/*++

Routine Description:

    Nothing to do

Arguments:

    OpenContext - Pointer to the open instance.  This is the value that was
        returned by SMB_Open.

    Source - Pointer to the source buffer.  This is the data to be written to
        the device.

    Count - Number of bytes to be written.

Return Value:

    If successful, the number of bytes written.  -1 in the case of failure.

--*/
ULONG
SMB_Write(
    IN OUT ULONG OpenContext,
    IN PUCHAR Source,
    IN ULONG Count
    )
{
    UNREFERENCED_PARAMETER(OpenContext);
    UNREFERENCED_PARAMETER(Source);
    UNREFERENCED_PARAMETER(Count);

    return 0;
}


/*++

Routine Description:

    Performs a seek on the device.  It's called whenever SetFilePointer is
    called with a handle to our open instance.

    Note that this function is not supported in this implementation since it
    doesn't make sense for our imaginary device to perform a seek.

Arguments:

    OpenContext - Pointer to the open instance.  This is the value that was
        returned by SMB_Open.

    Amount - Amount to seek.  This is a pass through from the SetFilePointer
        call.

    Type - Type of seek.  This is a pass through from the SetFilePointer call.

Return Value:

    Returns the new data pointer if successful.  -1 is returned if an error
    occurs.

--*/ULONG
SMB_Seek(
    IN OUT ULONG OpenContext,
    IN LONG Amount,
    IN USHORT Type
    )
{
    UNREFERENCED_PARAMETER(OpenContext);
    UNREFERENCED_PARAMETER(Amount);
    UNREFERENCED_PARAMETER(Type);

    SetLastError(ERROR_CALL_NOT_IMPLEMENTED);

    return -1;
}


/*++

Routine Description:

    This routine is called whenever DeviceIoControl (note the difference in
    capitalization for "IO" in DeviceIoControl and SMB_IOControl) is called
    with our open instance handle.

    The exported wrapper functions call these IOCONTROLS. Parameters
    In the calling process, Buffer is used as an input buffer to pass a
    pointer to Data.

        ULONG Buffer;
        ULONG Data;
        PULONG MappedPtr;

        MappedPtr = MapPtrToProcess(&Data,
                                    GetCurrentProcess());

        Buffer = (ULONG)MappedPtr;


Arguments:

    OpenContext - Pointer to the open instance.  This is the value that was
        returned by SMB_Open.

    Code - Device I/O control code.  This is a pass through from the
        DeviceIoControl call.

    InputBuffer - Pointer to the input buffer.  This is a pass through from
        the DeviceIoControl call (with the pointer correctly mapped by the
        device manager).

    InputBufferLength - Size of the input buffer in bytes.  This is a pass
        through from the DeviceIoControl call.

    OutputBuffer - Pointer to the output buffer.  This is a pass through from
        the DeviceIoControl call (with the pointer correctly mapped by the
        device manager).

    OutputBufferLength - Size of the output buffer in bytes.  This is a pass
        through from the DeviceIoControl call.

    ActualOutput - Pointer to a ULONG where the actual number of bytes
        returned via the OutputBuffer is to be written.  This is a pass through
        from the DeviceIoControl call (correctly mapped by the device manager).

Return Value:

    Returns the new data pointer if successful.  -1 is returned if an error
    occurs.

--*/
BOOL
SMB_IOControl(
    IN OUT ULONG DeviceContext,
    IN ULONG Code,
    IN PUCHAR InputBuffer,
    IN ULONG InputBufferLength,
    OUT PUCHAR OutputBuffer,
    IN ULONG OutputBufferLength,
    OUT PULONG ActualOutput
    )
{
    PDEVICE_INSTANCE DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;
	BOOL Status = FALSE;
	SMBUS_TRANSFER *pTransfer = (SMBUS_TRANSFER*)InputBuffer;

    DEBUGMSG(ZONE_IOCTL, (
             TEXT("SMB: SMB_IOControl(0x%x, 0x%x, 0x%x, %u, 0x%x,")
             TEXT(" %u, 0x%x) entered.\r\n"),
             DeviceContext,
             Code,
             InputBuffer,
             InputBufferLength,
             OutputBuffer,
             OutputBufferLength,
             ActualOutput
             ));

    switch  (Code) {
		case IOCTL_SMBUS_READDATA:
			Status = ReadData(DeviceInstance, pTransfer, (PUCHAR)OutputBuffer);
			*ActualOutput=pTransfer->DataSize;
			break;

		case IOCTL_SMBUS_WRITEDATA:
			Status = WriteData(DeviceInstance, pTransfer);
			*ActualOutput=0;
			break;

		default:
			SetLastError(ERROR_CALL_NOT_IMPLEMENTED);
			Status = FALSE;
			break;
    }

    if (!Status) {
		DEBUGMSG(ZONE_ERROR|ZONE_IOCTL, (
				 TEXT("SMB: SSO_IOControl returning FALSE.\r\n")));
	}
    return Status;
}


VOID
SMB_PowerDown(
    IN OUT ULONG DeviceContext
    )
{
    PDEVICE_INSTANCE DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;

	WRITE_REGISTER_ULONG((PULONG)&DeviceInstance->pSMB->psc.ctl, 0);
}


VOID
SMB_PowerUp(
    IN OUT ULONG DeviceContext
    )
{
    PDEVICE_INSTANCE DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;

	InitializeRegisters(DeviceInstance->pSMB);
}

//
// Exported user area functions
//



/*
    Description:
    ===========
      Read bytes from specified SMB address


    Arguments
    =========
    handle - this is the handle return by the init function
    Address - address to read
	pData	- pointer to storage for read UCHAR
	Size    - number of bytes to read


    Return
    ======
    TRUE - success

*/
BOOL
SMBus_ReadData( HANDLE Handle,
                SMBUS_TRANSFER *pTransfer)
{
    ULONG Tmp;
    BOOL RetVal;

    RetVal = DeviceIoControl(
        Handle,
        IOCTL_SMBUS_READDATA,
        pTransfer,
        sizeof(SMBUS_TRANSFER),
        &pTransfer->Data[0],
        pTransfer->DataSize,
        &Tmp,
        NULL);

    return RetVal;
}

/*
    Description:
    ===========
      Write data to the specified SMB address


    Arguments
    =========
    handle - this is the handle return by the init function
    Address - address to read
	pData	- pointer to storage for read UCHAR
	Size    - number of bytes to write

    Return
    ======
    TRUE - success

*/
BOOL
SMBus_WriteData( HANDLE Handle,
                 SMBUS_TRANSFER *pTransfer)
{
    ULONG Tmp;
    BOOL RetVal;

    RetVal = DeviceIoControl(
        Handle,
        IOCTL_SMBUS_WRITEDATA,
        pTransfer,
        sizeof(SMBUS_TRANSFER) + pTransfer->DataSize - 1,
        NULL,
        0,
        &Tmp,
        NULL);

    return RetVal;
}

HANDLE
SMBus_Initialize(VOID)
{
    HANDLE h;

	h = CreateFile(TEXT("SMB1:"),
				  0,
				  0,
				  NULL,
				  OPEN_EXISTING,
				  FILE_ATTRIBUTE_NORMAL,
				  NULL);

    return h;
}

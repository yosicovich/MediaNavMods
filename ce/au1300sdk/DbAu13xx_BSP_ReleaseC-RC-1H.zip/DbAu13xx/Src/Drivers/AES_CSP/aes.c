/*********************************************************************
 *
 * Copyright:
 *        Advanced Micro Devices, AMD. All Rights Reserved.
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of AMD. This
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, AMD
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY
 *  ACCOMPANYING WRITTEN MATERIALS.
 *
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL AMD BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.
 *
 *  AMD assumes no responsibility for the maintenance and support
 *  of this software.
 ********************************************************************/
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
// Copyright (c) 2004 BSQUARE Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//

#include "aes_csp.h"

#define WAIT_FOR_STATUS(x) \
        while(!(AESBase->status & x))


BOOL HWInitialize(void)
{
    PHYSICAL_ADDRESS PhysicalBase;

    PhysicalBase.HighPart = 0;
    PhysicalBase.LowPart = AES_PHYS_ADDR;

	AESBase = (AU1200_AES *)MmMapIoSpace(PhysicalBase, sizeof(AU1200_AES), FALSE);
	if (AESBase == NULL)
	{
		DEBUGMSG(1,(TEXT("AESHWInitialize: HWInit Failed.\r\n")));
		return FALSE;
	}

	AESMutex = CreateMutex(0, FALSE, AES_MUTEX_NAME);

	if (AESMutex == NULL)
	{
		DEBUGMSG(1,(TEXT("AES_HWInitialize: CreateMutex failed %x\r\n"),GetLastError()));
		return FALSE;
	}

	return TRUE;
}


void HWClose(void)
{
	MmUnmapIoSpace((PVOID)AESBase, sizeof(AU1200_AES));
	CloseHandle(AESMutex);
	return;
}


inline ULONG AES_Swap32(ULONG input)
{
        ULONG output =  (input << 24 )& 0xff000000 |
                        (input <<  8) & 0x00ff0000 |
                        (input >>  8) & 0x0000ff00 |
                        (input >> 24) & 0x000000ff;
        return output;
}


BOOL ProviderInUse(WCHAR *ContainerName)
{
	//
	// HKEY_LOCAL_MACHINE registry path for our Container
	//

	WCHAR ContainerPath[] = L"Comm\\Security\\Crypto\\Defaults\\Provider\\" AES_PROVIDER_NAME L"\\ContainerName";
	HKEY RegKey;
	DWORD Error, Data;
	BOOL Result;

	//
	// Make sure no one else is trying to access the same registry key.
	//

	if (WaitForSingleObject(AESMutex, INFINITE) == WAIT_FAILED)
	{
		DEBUGMSG(1,(TEXT("AES_ProviderInUse: Waiting for mutex failed.\r\n"),GetLastError()));
		return TRUE;
	}

    if ((Error = RegCreateKeyEx(HKEY_LOCAL_MACHINE, ContainerPath, 0, 0, 
							    REG_OPTION_NON_VOLATILE, 0, 0, &RegKey, &Data)) != ERROR_SUCCESS)
    {
        DEBUGMSG(1,(TEXT("AES_ProviderInUse: Could not create/open registry key %x\r\n"), Error));
    }

	//
	// If the key was just created, the Provider is not in use.
	//

	Result = (Data == REG_CREATED_NEW_KEY) ? FALSE : TRUE;

	if ((Error = RegCloseKey(RegKey)) != ERROR_SUCCESS)
	{
		DEBUGMSG(1,(TEXT("AES_ProviderInUse: Could not close registry key %x\r\n"), Error));
	}

	if (!ReleaseMutex(AESMutex))
	{
		DEBUGMSG(1,(TEXT("AES_ProviderInUse: ReleaseMutex failed %x\r\n"),GetLastError()));
		Result = TRUE;
	}

	return Result;
}


BOOL ClearProviderInUse(void)
{
	//
	// HKEY_LOCAL_MACHINE registry path for our Container.
	//

	WCHAR ContainerPath[] = L"Comm\\Security\\Crypto\\Defaults\\Provider\\" AES_PROVIDER_NAME L"\\ContainerName";
	DWORD Error;

	//
	// Make sure no one else is trying to access the same registry key.
	//

	if (WaitForSingleObject(AESMutex, INFINITE) == WAIT_FAILED)
	{
		DEBUGMSG(1,(TEXT("AES_ProviderInUse: Waiting for mutex failed.\r\n"),GetLastError()));
	}

	//
	// The Provider is free to be used again.
	//

	if ((Error = RegDeleteKey(HKEY_LOCAL_MACHINE, ContainerPath)) != ERROR_SUCCESS)
	{
        DEBUGMSG(1,(TEXT("AES_ProviderInUse: Could not delete registry key %x\r\n"), Error));
		return FALSE;
	}

	if (!ReleaseMutex(AESMutex))
	{
		DEBUGMSG(1,(TEXT("AES_ProviderInUse: ReleaseMutex failed %x\r\n"),GetLastError()));
	}

	return TRUE;
}


BOOL PerformCryptography(AES_INPUT *InputData, size_t NumBlocks, AES_OUTPUT *OutputData)
{
	int i=0;
	long mode = 0;

	if (AESBase == NULL)
	{
		DEBUGMSG(1,(TEXT("AES_PerformCryptography: AESBase not set\r\n")));
		return FALSE;
	}

	/*** configuration sequence (CS, Configuration Reg)
	*************************************************/
	//AESBase->config = InputData->ctrl.AES_Config;
	WRITE_REGISTER_ULONG((PULONG)&AESBase->config, InputData->ctrl.AES_Config);

	/*** status sequence (SS, Status Reg)
	************************************************/
	/* Enc/Decryption Begin! */
	//AESBase->status = InputData->ctrl.AES_Status |= AES_STATUS_PS;
	InputData->ctrl.AES_Status |= AES_STATUS_PS;
	WRITE_REGISTER_ULONG((PULONG)&AESBase->status, InputData->ctrl.AES_Status);

	/*** block count sequence (BS, Rx Reg)
	************************************************/
	if(!(InputData->ctrl.AES_Config & AES_CONFIG_UC))  /* UC = 0 means defined block count */
		//AESBase->indata = NumBlocks;  /* 128bits per block */
		WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, NumBlocks);

    /*** key sequence (KS, Rx Reg )
	************************************************/
	if(!(InputData->ctrl.AES_Config & AES_CONFIG_RK)) /* supply the key if it is not reuse key */
	{
		if(InputData->swap)
		{
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*(ULONG *)InputData->key.key0));
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*(ULONG *)InputData->key.key1));
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*(ULONG *)InputData->key.key2));
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*(ULONG *)InputData->key.key3));
		}
		else
		{
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *(ULONG *)InputData->key.key0);
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *(ULONG *)InputData->key.key1);
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *(ULONG *)InputData->key.key2);
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *(ULONG *)InputData->key.key3);
		}
	}

	/*** Initialization Vector Sequence (IVS, Rx Reg )
	************************************************/
	mode = (InputData->ctrl.AES_Config)>>5 & 0x03;
	if(mode > 0 && mode < 4)   /* CBC, OFB, CFB mode */
	{
		if(InputData->swap)
		{
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*(ULONG *)InputData->IV.IV0));
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*(ULONG *)InputData->IV.IV1));
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*(ULONG *)InputData->IV.IV2));
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*(ULONG *)InputData->IV.IV3));

		}
		else
		{
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *(ULONG *)InputData->IV.IV0);
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *(ULONG *)InputData->IV.IV1);
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *(ULONG *)InputData->IV.IV2);
			WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *(ULONG *)InputData->IV.IV3);
		}
	}

	/*** Payload Sequence (PS,Rx Reg )
    *************************************************
  	The In/Out FIFOs are 32 bytes deep. First,
  	fill 16 bytes Input buffer, then alternate
  	16 bytes Input & Output buffer (as data being
  	enc/decrypted). Finally empty the last 16 bytes
  	Output buffer.

  	Here is an illustration of how it works:

    input (16 bytes)
    loop
    input (16 bytes)
    output (16 bytes)
    end loop
    output (16 bytes)

    This way, we are able to fill up the buffer before output
    data been taken out (not serializing the FIFO).

    Note: For multi thread and interrupt enabled environment
    a status check mechanism is implemented to ensure
    In data is ready to be written and out data is
    ready to be read.
 	*************************************************/
 	/* write block 0, first 16 of 32 bytes FIFO */
 	WAIT_FOR_STATUS(AES_STATUS_IN); /* Check if In-buffer is available */
 	if(InputData->swap)
 	{
		WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*((LONG *)(InputData->indata))++));
		WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*((LONG *)(InputData->indata))++));
		WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*((LONG *)(InputData->indata))++));
		WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*((LONG *)(InputData->indata))++));

	}
	else
	{
		WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *((LONG *)(InputData->indata))++);
		WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *((LONG *)(InputData->indata))++);
		WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *((LONG *)(InputData->indata))++);
		WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *((LONG *)(InputData->indata))++);
	}

	NumBlocks--;
	/* write block 1...N. */
	/* Note: supports only defined number of blocks */
	if(!(InputData->ctrl.AES_Config & AES_CONFIG_UC))
	{
		while( NumBlocks > 0)
		{
			/* Write data block (Rx Reg) */
			/* To fill up 32 bytes FIFO */
			if(InputData->swap)
			{
				WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*((LONG *)(InputData->indata))++));
				WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*((LONG *)(InputData->indata))++));
				WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*((LONG *)(InputData->indata))++));
				WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, AES_Swap32(*((LONG *)(InputData->indata))++));
			}
			else
			{
				WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *((LONG *)(InputData->indata))++);
				WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *((LONG *)(InputData->indata))++);
				WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *((LONG *)(InputData->indata))++);
				WRITE_REGISTER_ULONG((PULONG)&AESBase->indata, *((LONG *)(InputData->indata))++);
			}

			/* read enc/decrypted data block from the Out FIFO (Tx Reg) */
			WAIT_FOR_STATUS(AES_STATUS_OUT); /* Check if Out-buffer is available*/

			if(InputData->swap)
			{
				*((LONG *)(OutputData->outdata))++ = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
				*((LONG *)(OutputData->outdata))++ = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
				*((LONG *)(OutputData->outdata))++ = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
				*((LONG *)(OutputData->outdata))++ = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
			}
			else
			{
				*((LONG *)(OutputData->outdata))++ = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
				*((LONG *)(OutputData->outdata))++ = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
				*((LONG *)(OutputData->outdata))++ = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
				*((LONG *)(OutputData->outdata))++ = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
			}

			NumBlocks--;
		}
	}

	/* read the last enc/decrypted data block  (Tx Reg) */
	WAIT_FOR_STATUS(AES_STATUS_OUT); /* Out buffer is available*/
	if(InputData->swap)
	{
		*((LONG *)(OutputData->outdata))++ = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
		*((LONG *)(OutputData->outdata))++ = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
		*((LONG *)(OutputData->outdata))++ = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
		*((LONG *)(OutputData->outdata))++ = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
	}        
	else
	{
		*((LONG *)(OutputData->outdata))++ = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
		*((LONG *)(OutputData->outdata))++ = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
		*((LONG *)(OutputData->outdata))++ = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
		*((LONG *)(OutputData->outdata))++ = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
	}

	/*** key replay Sequence (KRS, Tx Reg)
	************************************************/
	if(InputData->ctrl.AES_Config & AES_CONFIG_RPK)
	{
		if(InputData->swap)
		{
			*(LONG *)(OutputData->RPK.RPK0) = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
			*(LONG *)(OutputData->RPK.RPK1) = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
			*(LONG *)(OutputData->RPK.RPK2) = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
			*(LONG *)(OutputData->RPK.RPK3) = AES_Swap32(READ_REGISTER_ULONG((PULONG)&AESBase->outdata));
		}
		else
		{
			*(LONG *)(OutputData->RPK.RPK0) = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
			*(LONG *)(OutputData->RPK.RPK1) = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
			*(LONG *)(OutputData->RPK.RPK2) = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
			*(LONG *)(OutputData->RPK.RPK3) = READ_REGISTER_ULONG((PULONG)&AESBase->outdata);
		}
	}

	return TRUE;
}

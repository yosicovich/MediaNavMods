/*********************************************************************
 *
 * Copyright:
 *	Advanced Micro Devices, AMD. All Rights Reserved.  
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of AMD. This 
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, AMD 
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING 
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE 
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY 
 *  ACCOMPANYING WRITTEN MATERIALS.
 * 
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL AMD BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING 
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS 
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.   
 * 
 *  AMD assumes no responsibility for the maintenance and support
 *  of this software.
 ********************************************************************/
//
// Copyright (c) 2004 BSQUARE Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//

#ifndef __AES_CSP_H
#define __AES_CSP_H
#endif

//------------------------------------------------------------------------------
#include <windows.h>
#include <wincrypt.h>
#include <bceddk.h>
#include "platform.h"

#define AES_PROVIDER_NAME	L"AMD AES CSP"
#define AES_MUTEX_NAME		L"AMD_AES_Mutex"
#define SIZE_OF_AES_BUFFER  256*1024
#define NUM_OF_BYTES        4

/*
 * This AES_INPUT/OUTPUT_Structure is created to service
 * Byte stream as input that is not in natural order as
 * the processor, in this case for MIPS, is little endian
 *
 * All data type are involved except AES_Config and
 * AES_Status cuz they are control registers that
 * configured by setting the bits.
 *
 */

typedef struct {
        uint32 AES_Config;
        uint32 AES_Status;
} AES_CONTROL;

typedef struct {
        UCHAR key0[NUM_OF_BYTES];
        UCHAR key1[NUM_OF_BYTES];
        UCHAR key2[NUM_OF_BYTES];
        UCHAR key3[NUM_OF_BYTES];
} AES_KEY;

typedef struct {
        UCHAR IV0[NUM_OF_BYTES];
        UCHAR IV1[NUM_OF_BYTES];
        UCHAR IV2[NUM_OF_BYTES];
        UCHAR IV3[NUM_OF_BYTES];
} AES_IV;

typedef struct {
        UCHAR RPK0[NUM_OF_BYTES];
        UCHAR RPK1[NUM_OF_BYTES];
        UCHAR RPK2[NUM_OF_BYTES];
        UCHAR RPK3[NUM_OF_BYTES];
} AES_RPK;

#define SIZE_OF_RPK_KEY              sizeof(AES_RPK) /* replay key (4x4 bytes) */
#define SIZE_OF_AES_CONTROL          sizeof(AES_RPK)

/*
 * This padding is used to ensure the AES_INPUT data type
 * size is similiar to AES_OUTPUT.
 *
 * The better approach is move the indata/outdata member
 * to the beginning of the structure. Unfortunately,
 * this break all the testcases for its assumption of
 * the previous layout.
 */

typedef struct {
        uint32 pad0;
        uint32 pad1;
        uint32 pad2;
        uint32 pad3;
        uint32 pad4;
        uint32 pad5;
        uint32 pad6;
} AES_Unused;

typedef struct _AES_INPUT
{
        AES_CONTROL ctrl;
        AES_KEY     key;
        AES_IV      IV;
        uint32      swap;
        UCHAR       *indata;

} AES_INPUT;

typedef struct _AES_OUTPUT
{

        AES_RPK    RPK;
        AES_Unused Unused;
        UCHAR      *outdata;

} AES_OUTPUT;

typedef struct _AES_KEYPARAM
{
	DWORD	Mode;
	AES_KEY	KeyVal;
	AES_IV	IV;
	uint32      swap;

} AES_KEYPARAM;

//
// Globals
//

AU1200_AES    *AESBase;
AES_KEYPARAM  AESKey;
HANDLE		  AESMutex;

//
// Function Declarations
//

BOOL HWInitialize(void);
void HWClose(void);
BOOL ProviderInUse(WCHAR *ContainerName);
BOOL ClearProviderInUse(void);
BOOL PerformCryptography(AES_INPUT *InputData, size_t NumBlocks, AES_OUTPUT *OutputData);



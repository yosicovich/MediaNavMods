/*********************************************************************
 *
 * Copyright:
 *        Advanced Micro Devices, AMD. All Rights Reserved.
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of AMD. This
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, AMD
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY
 *  ACCOMPANYING WRITTEN MATERIALS.
 *
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL AMD BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.
 *
 *  AMD assumes no responsibility for the maintenance and support
 *  of this software.
 ********************************************************************/
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
// Copyright (c) 2004 BSQUARE Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//

#include "aes_csp.h"


BOOL DllEntry(HANDLE hInstance, DWORD Reason, LPVOID pReserved)
{
	switch (Reason) {
		case DLL_PROCESS_ATTACH:
			DEBUGMSG(1, (TEXT (" AES_CSP: DLL_PROCESS_ATTACH\r\n")));
			DisableThreadLibraryCalls((HMODULE) hInstance);
			if (!HWInitialize())
				return FALSE;
			break;
		case DLL_PROCESS_DETACH:
			DEBUGMSG(1, (TEXT (" AES_CSP: DLL_PROCESS_DETACH\r\n")));
			HWClose();
			break;
	}

	return TRUE;
}


extern BOOL WINAPI CPAcquireContext(HCRYPTPROV *phProv,       // out
									WCHAR *pszContainer,      // in, out
									DWORD dwFlags,            // in
									PVTableProvStruc pVTable  // in
									)
{
	//
	// Only allow one user at a time.
	//

	if (ProviderInUse(pszContainer))
	{
		DEBUGMSG(1,(TEXT("CPAcquireContext: CSP already in use %x\r\n"),GetLastError()));
		return FALSE;
	}

	return TRUE;
}


extern BOOL WINAPI CPReleaseContext(HCRYPTPROV hProv,  // in
									DWORD dwFlags      // in
									)
{
	//
	// Let others know we're done.
	//

	if (!ClearProviderInUse())
		DEBUGMSG(1,(TEXT("CPReleaseContext: Could not clear provider.\r\n")));

	return TRUE;
}


extern BOOL WINAPI CPGetProvParam(HCRYPTPROV hProv,  // in
								  DWORD dwParam,     // in
								  BYTE *pbData,      // out
								  DWORD *pdwDataLen, // in, out
								  DWORD dwFlags      // in
								  )
{
	return TRUE;
}

extern BOOL WINAPI CPSetProvParam(HCRYPTPROV hProv,  // in
								  DWORD dwParam,     // in
								  BYTE *pbData,      // in
								  DWORD dwFlags      // in
								  )
{
	return TRUE;
}

/////////////////////////////////
// Hash Functions

extern BOOL WINAPI CPCreateHash(HCRYPTPROV hProv,    // in
								ALG_ID Algid,        // in
								HCRYPTKEY hKey,      // in
								DWORD dwFlags,       // in
								HCRYPTHASH *phHash   // out
								)
{
	return TRUE;
}

extern BOOL WINAPI CPDestroyHash(HCRYPTPROV hProv, // in
								 HCRYPTHASH hHash  // in
								 )
{
	return TRUE;
}

extern BOOL WINAPI CPDuplicateHash(HCRYPTPROV hProv,    // in
								   HCRYPTHASH hHash,    // in
								   DWORD *pdwReserved,  // in
								   DWORD dwFlags,       // in
								   HCRYPTHASH *phHash   // out
								   )
{
	return TRUE;
}

extern BOOL WINAPI CPGetHashParam(HCRYPTPROV hProv,     // in
								  HCRYPTHASH hHash,     // in
								  DWORD dwParam,        // in
								  BYTE *pbData,         // out
								  DWORD *pdwDataLen,    // in, out
								  DWORD dwFlags         // in
								  )
{
	return TRUE;
}

extern BOOL WINAPI CPHashData(HCRYPTPROV hProv,       // in
							  HCRYPTHASH hHash,       // in
							  CONST BYTE *pbData,     // in
							  DWORD dwDataLen,        // in
							  DWORD dwFlags           // in
							  )
{
	return TRUE;
}

extern BOOL WINAPI CPHashSessionKey(HCRYPTPROV hProv,      // in
									HCRYPTHASH hHash,      // in
									HCRYPTKEY hKey,        // in
									DWORD dwFlags          // in
									)
{
	return TRUE;
}

extern BOOL WINAPI CPSetHashParam(HCRYPTPROV hProv,     // in
								  HCRYPTHASH hHash,     // in
								  DWORD dwParam,        // in
								  BYTE *pbData,         // in
								  DWORD dwFlags         // in
								  )
{
	return TRUE;
}


/////////////////////////////////
// Encryption Functions
extern BOOL WINAPI CPEncrypt(HCRYPTPROV hProv,       // in
							 HCRYPTKEY hKey,         // in
							 HCRYPTHASH hHash,       // in
							 BOOL Final,             // in
							 DWORD dwFlags,          // in
							 BYTE *pbData,           // in, out
							 DWORD *pdwDataLen,      // in, out
							 DWORD dwBufLen          // in
							 )
{
	ULONG *data_blocks;
	AES_INPUT AES_input;
	AES_OUTPUT AES_output;
	INT i;

	DEBUGMSG(1,(TEXT("AES: CPEncrypt++\r\n")));

	if (*pdwDataLen != 0 || (*pdwDataLen <= dwBufLen))
	{
		//
		// The data must be in 16 byte blocks.
		//

		if ((*pdwDataLen % 16) != 0)
		{
			DEBUGMSG(1,(TEXT("Data needs to be padded with zeroes to fill the data block\r\n")));
			SetLastError(NTE_BAD_DATA);
			return FALSE;
		}

		data_blocks = malloc(*pdwDataLen);
		if (data_blocks == NULL)
		{
			DEBUGMSG(1,(TEXT("malloc failed %x\r\n"), GetLastError()));
			return FALSE;
		}
	}
	else
	{
		DEBUGMSG(1,(TEXT("Bad data length.\r\n")));
		SetLastError(NTE_BAD_LEN);
		return FALSE;
	}

	//
	// Reset the register values.
	//

	AES_input.ctrl.AES_Config = 0;
	AES_input.ctrl.AES_Status = 0;
	memcpy(&AES_input.swap, &AESKey.swap, sizeof(AESKey.swap));
	DEBUGMSG(1,(TEXT("CPEncrypt: swap: %x"),AES_input.swap));

	//
	// Initialize everything we need for encryption.
	//

	memcpy(data_blocks, pbData, *pdwDataLen);
	AES_input.indata = (PUCHAR)data_blocks;
	AES_output.outdata = (PUCHAR)data_blocks;

	memcpy(AES_input.key.key0, AESKey.KeyVal.key0, sizeof(AESKey.KeyVal));
	memcpy(AES_input.IV.IV0, AESKey.IV.IV0, sizeof(AESKey.IV));

	//
	// Mode (OPM) = CBC, Block Count (UC) is defined,
	// no reuse nor replay key (RK, RPK), no IKG.
	// Encryption (ED=0)
	//

	switch (AESKey.Mode)
	{
		case CRYPT_MODE_ECB:
			i = 0;
			break;
		case CRYPT_MODE_CBC:
		default:
			i = 1;
			break;
		case CRYPT_MODE_CFB:
			i = 2;
			break;
		case CRYPT_MODE_OFB:
			i = 3;
			break;
	}

	AES_input.ctrl.AES_Config |= AES_CONFIG_OP_N(i);

	//
	// Begin encryption.
	//
	
	if (!PerformCryptography( &AES_input, *pdwDataLen/16, &AES_output))
		DEBUGMSG(1,(TEXT("PerformCryptography failed\r\n")));

	//
	// Send the encrypted data back to the caller.
	//
	
	memcpy(pbData, data_blocks, *pdwDataLen);

	free(data_blocks);

	DEBUGMSG(1,(TEXT("AES: CPEncrypt--\r\n")));
	return TRUE;
}

extern BOOL WINAPI CPDecrypt(HCRYPTPROV hProv,      // in
							 HCRYPTKEY hKey,        // in
							 HCRYPTHASH hHash,      // in
							 BOOL Final,            // in
							 DWORD dwFlags,         // in
							 BYTE *pbData,          // in, out
							 DWORD *pdwDataLen      // in, out
)
{
	ULONG *data_blocks;
	AES_INPUT AES_input;
	AES_OUTPUT AES_output;
	INT i;

	DEBUGMSG(1,(TEXT("AES: CPDecrypt++\r\n")));

	if (*pdwDataLen != 0)
	{
		//
		// The data must be in 16 byte blocks.
		//

		if ((*pdwDataLen % 16) != 0)
		{
			DEBUGMSG(1,(TEXT("Data needs to be padded with zeroes to fill the data block\r\n")));
			SetLastError(NTE_BAD_DATA);
			return FALSE;
		}

		data_blocks = malloc(*pdwDataLen);
		if (data_blocks == NULL)
		{
			DEBUGMSG(1,(TEXT("malloc failed %x\r\n"), GetLastError()));
			return FALSE;
		}
	}
	else
	{
		DEBUGMSG(1,(TEXT("Bad data length.\r\n")));
		SetLastError(NTE_BAD_LEN);
		return FALSE;
	}

	//
	// Reset the register values.
	//

	AES_input.ctrl.AES_Config = 0;
	AES_input.ctrl.AES_Status = 0;
	memcpy(&AES_input.swap, &AESKey.swap, sizeof(AESKey.swap));
	DEBUGMSG(1,(TEXT("CPDecrypt: swap: %x"),AES_input.swap));

	//
	// Initialize everything we need for decryption.
	//

	memcpy(data_blocks, pbData, *pdwDataLen);
	AES_input.indata = (PUCHAR)data_blocks;
	AES_output.outdata = (PUCHAR)data_blocks;

	memcpy(AES_input.key.key0, AESKey.KeyVal.key0, sizeof(AESKey.KeyVal));
	memcpy(AES_input.IV.IV0, AESKey.IV.IV0, sizeof(AESKey.IV));

	//
	// Mode (OPM) = CBC, Block Count (UC) is defined,
	// no reuse nor replay key (RK, RPK), need IKG.
	// Decryption (ED = 1)
	//
	
	switch (AESKey.Mode)
	{
		case CRYPT_MODE_ECB:
			i = 0;
			break;
		case CRYPT_MODE_CBC:
		default:
			i = 1;
			break;
		case CRYPT_MODE_CFB:
			i = 2;
			break;
		case CRYPT_MODE_OFB:
			i = 3;
			break;
	}

	AES_input.ctrl.AES_Config |= AES_CONFIG_ED | AES_CONFIG_IKG | AES_CONFIG_OP_N(i);

	//
	// Begin decryption.
	//

	if (!PerformCryptography( &AES_input, *pdwDataLen/16, &AES_output))
		DEBUGMSG(1,(TEXT("PerfCryp failed\r\n")));

	//
	// Send the decrypted data back to the caller.
	//

	memcpy(pbData, data_blocks, *pdwDataLen);

	free(data_blocks);

	DEBUGMSG(1,(TEXT("AES: CPDecrypt--\r\n")));
	return TRUE;
}



/////////////////////////////////
// Signature Functions

extern BOOL WINAPI CPSignHash(HCRYPTPROV hProv,           // in
							  HCRYPTHASH hHash,           // in
							  DWORD dwKeySpec,            // in
							  LPCWSTR sDescription,       // in
							  DWORD dwFlags,              // in
							  BYTE *pbSignature,          // out
							  DWORD *pdwSigLen            // in, out
							  )
{
	return TRUE;
}

extern BOOL WINAPI CPVerifySignature(HCRYPTPROV hProv,         // in
									 HCRYPTHASH hHash,         // in
									 CONST BYTE *pbSignature,  // in
									 DWORD dwSigLen,           // in
									 HCRYPTKEY hPubKey,        // in
									 LPCWSTR sDescription,     // in
									 DWORD dwFlags             // in
									 )
{
	return TRUE;
}

/////////////////////////////////
// Key Functions

extern BOOL WINAPI CPDeriveKey(HCRYPTPROV  hProv,        // in
							   ALG_ID      Algid,        // in
							   HCRYPTHASH  hBaseData,    // in
							   DWORD       dwFlags,      // in
							   HCRYPTKEY   *phKey        // out
							   )
{
	return TRUE;
}

extern BOOL WINAPI CPDestroyKey(HCRYPTPROV hProv,  // in
								HCRYPTKEY  hKey    // in
								)
{
	return TRUE;
}

extern BOOL WINAPI CPDuplicateKey(HCRYPTPROV hProv,    // in
								  HCRYPTKEY hKey,      // in
								  DWORD *pdwReserved,  // in
								  DWORD dwFlags,       // in
								  HCRYPTKEY *phKey     // out
								  )
{
	return TRUE;
}

extern BOOL WINAPI CPImportKey(HCRYPTPROV hProv,       // in
							   BYTE *pbData,		   // in
							   DWORD  dwDataLen,       // in
							   HCRYPTKEY hPubKey,      // in
							   DWORD dwFlags,          // in
							   HCRYPTKEY *phKey        // out
							   )
{
	INT i;

	DEBUGMSG(1,(TEXT("AES: CPImportKey++\r\n")));

	//
	// Take the users input and map it to our internal key struct.
	//

	if (dwDataLen <= sizeof(AESKey))
	{
		if (dwDataLen == (sizeof(AESKey) - sizeof(AES_IV)))
		{
			//
			// No IV set, initialize to zero.
			//
		
			for (i=0; i<4; i++)
			{
				AESKey.IV.IV0[i] = 0;
				AESKey.IV.IV1[i] = 0;
				AESKey.IV.IV2[i] = 0;
				AESKey.IV.IV3[i] = 0;
			}
		}

		memcpy(&AESKey.Mode, pbData, sizeof(AESKey));
	}
	else
	{
		DEBUGMSG(1,(TEXT("CPImportKey: data length incorrect.\r\n")));
		SetLastError(ERROR_INVALID_PARAMETER);
		return FALSE;
	}

	DEBUGMSG(1,(TEXT("AES: CPImportKey--\r\n")));
	return TRUE;
}

extern BOOL WINAPI CPExportKey(HCRYPTPROV hProv,      // in
							   HCRYPTKEY hKey,        // in
							   HCRYPTKEY hPubKey,     // in
							   DWORD dwBlobType,      // in
							   DWORD dwFlags,         // in
							   BYTE *pbData,          // out
							   DWORD *pdwDataLen      // in, out
							   )
{
	DWORD KeySize;

	DEBUGMSG(1,(TEXT("AES: CPExportKey++\r\n")));

	KeySize = sizeof(AESKey);

	//
	// Check to make sure the return buffer is large enough.
	//

	if (*pdwDataLen < KeySize)
	{
		DEBUGMSG(1,(TEXT("Data Buffer needs to be at least %x bytes.\r\n"), KeySize));
		*pdwDataLen = KeySize;
		SetLastError(ERROR_MORE_DATA);
		return FALSE;
	}

	//
	// Send our internal key values to the user.
	//

	memcpy(pbData, &AESKey.Mode, KeySize);
	*pdwDataLen = KeySize;

	DEBUGMSG(1,(TEXT("AES: CPExportKey--\r\n")));
	return TRUE;
}

extern BOOL WINAPI CPGenKey(HCRYPTPROV hProv,     // in
							ALG_ID Algid,         // in
							DWORD dwFlags,        // in
							HCRYPTKEY *phKey      // out
							)
{
	int i;
	ULONG key_data[4];

	DEBUGMSG(1,(TEXT("AES: CPGenKey++\r\n")));

	//
	// Initialize the key data.
	//

	AESKey.Mode = CRYPT_MODE_CBC;

	for (i=0; i<4; i++)
	{
		AESKey.IV.IV0[i] = 0;
		AESKey.IV.IV1[i] = 0;
		AESKey.IV.IV2[i] = 0;
		AESKey.IV.IV3[i] = 0;
	}

	//
	// Generate a random key.
	//

	if (!CeGenRandom(16,(PBYTE)AESKey.KeyVal.key0))
	{
		DEBUGMSG(1,(TEXT("CeGenRandom failed %x\r\n"),GetLastError));
		return FALSE;
	}

	memcpy(key_data,AESKey.KeyVal.key0, sizeof(key_data));

	DEBUGMSG(1,(TEXT("CeGenRandom returned: ")));
	for(i=0; i<4; i++)
	{
		DEBUGMSG(1,(TEXT("Key[%i] = %x"),i,key_data[i]));
	}

	DEBUGMSG(1,(TEXT("AES: CPGenKey--\r\n")));

	return TRUE;
}

extern BOOL WINAPI CPGetKeyParam(HCRYPTPROV hProv,       // in
								 HCRYPTKEY hKey,         // in
								 DWORD dwParam,          // in
								 BYTE *pbData,           // out
								 DWORD *pdwDataLen,      // in, out
								 DWORD dwFlags           // in
								 )
{
	return TRUE;
}

extern BOOL WINAPI CPSetKeyParam(HCRYPTPROV hProv,        // in
								 HCRYPTKEY hKey,          // in
								 DWORD dwParam,           // in
								 BYTE *pbData,            // in
								 DWORD dwFlags            // in
								 )
{
	DEBUGMSG(1,(TEXT("AES: CPSetKeyParam++\r\n")));

	switch (dwParam)
	{
		case KP_MODE:
			AESKey.Mode = *pbData;
			break;
		case KP_IV:
			memcpy(&AESKey.IV, pbData, sizeof(AESKey.IV));
			break;
		default:
			DEBUGMSG(1,(TEXT("AES: CPSetKeyParam: Not supported\r\n")));
	}
	
	DEBUGMSG(1,(TEXT("AES: CPSetKeyParam--\r\n")));

	return TRUE;
}

extern BOOL WINAPI CPGetUserKey(HCRYPTPROV hProv,       // in
								DWORD dwKeySpec,        // in
								HCRYPTKEY *phUserKey    // out
								)
{
	return TRUE;
}

//////////////////////////
// Misc Functions
extern BOOL WINAPI CPGenRandom(HCRYPTPROV hProv,  // in
							   DWORD dwLen,       // in
							   BYTE *pbBuffer     // in, out
							   )
{
	return TRUE;
}

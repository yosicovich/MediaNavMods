/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef _TCHPDD_H_
#define _TCHPDD_H_


#define TIMEOUT     200

#define WM9712_MUTEX_NAME  TEXT("WM9712")

/*
 * Register content definitions
 */
#define AC97_CONFIG_RECVSLOTS		(0x3FF<<13)
#define AC97_CONFIG_XMITSLOTS		(0x3FF<<3)
#define AC97_CONFIG_SFT				(1<<2)
#define AC97_CONFIG_SN				(1<<1)
#define AC97_CONFIG_RS				(1<<0)

#define AC97_STATUS_XU				(1<<11)
#define AC97_STATUS_XO				(1<<10)
#define AC97_STATUS_RU				(1<<9)
#define AC97_STATUS_RO				(1<<8)
#define AC97_STATUS_RD				(1<<7)
#define AC97_STATUS_CP				(1<<6)
#define AC97_STATUS_TR				(1<<5)
#define AC97_STATUS_TE				(1<<4)
#define AC97_STATUS_TF				(1<<3)
#define AC97_STATUS_RR				(1<<2)
#define AC97_STATUS_RE				(1<<1)
#define AC97_STATUS_RF				(1<<0)

#define AC97_COMMAND_RW				(1<<25)

#define AC97_CONTROL_D				(1<<1)
#define AC97_CONTROL_CE				(1<<0)

#define AC97_DATA_SHIFT 16
#define AC97_DATA_MASK (0xffff<<AC97_DATA_SHIFT)
#define AC97_DATA_RESP  0xffff
#define AC97_ADDR_MASK 0x7f

#define TOUCH_PANEL_CALIBRATION_DATA_REGKEY    (TEXT("HARDWARE\\DEVICEMAP\\TOUCH"))


#endif _TCHPDD_H_

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/


/*****************************************************************************
 Include Files
******************************************************************************/
#include <windows.h>
#include <bceddk.h>
#include <tchddsi.h>
#include <gpio.h>
#include "platform.h"
#include "wm9705tchpdd.h"
#include "tchpdd.h"
#include "aclink.h"

/*****************************************************************************
 DEFINES
******************************************************************************/
#define MAX_TOUCH_VAL 4095

//#undef  DEBUGMSG
//#define DEBUGMSG(cond, msg) RETAILMSG(1,msg)

#define TOUCHPANEL_SAMPLE_RATE_LOW  100
#define TOUCHPANEL_SAMPLE_RATE_HIGH 100

// The interrupt timer we are using can be set at 100 microsecond intervals
// and we want to be able to set the Timeout in milliseconds


#define ONE_MILLISECOND	10000
#define TOUCH_POLL		10 * ONE_MILLISECOND // Poll every 10 milliseconds

/*****************************************************************************
 Local Variables
******************************************************************************/

static AU1X00_SYS *GpioRegs = NULL;
static volatile AC97_GLOBALS *g_pAc97Shared = NULL;
static BOOL g_InvertAxis = FALSE;

/*****************************************************************************
 Global Variables
******************************************************************************/

DWORD gIntrTouch		= SYSINTR_NOP;
DWORD gIntrTouchChanged	= SYSINTR_NOP;

static unsigned nextExpectedInterrupt = PEN_DOWN;

// The MDD requires a minimum of MIN_CAL_COUNT consecutive samples before
// it will return a calibration coordinate to GWE.  This value is defined
// in the PDD so that each OEM can control the behaviour of the touch
// panel and still use the Microsoft supplied MDD.  Note that the extern "C"
// is required so that the variable name doesn't get decorated, and
// since we have an initializer the 'extern' is actually ignored and
// space is allocated.
extern "C" const int MIN_CAL_COUNT = 25;

/*****************************************************************************
 INTERNAL FUNCTIONS
******************************************************************************/
static TOUCH_PANEL_SAMPLE_FLAGS SampleTouchScreen(INT *x,INT *y);
static USHORT getTouchCoordinate(UINT axis);
static BOOL sampleADC(USHORT *sample,UINT axis);
static INT evaluateSample(USHORT val0,USHORT val1,USHORT val2,int maxError,INT *sample);
static BOOL EnableTouchScreen(void);
static BOOL RegisteCalibrationData();

/*****************************************************************************
DdsiTouchPanelAttach
--------------------
This function is called when the MDD's DLL entry point gets a
DLL_PROCESS_ATTACH message.

Parameters
----------
None.

Return Values
-------------
Returns 1.

Remarks
-------
This routine no longer does anything.  All functionallity has been moved
from here into DdsiTouchPanelEnable to allow this code to be statically
linked with GWE rather than existing as a DLL.  Technically, when built
as a DLL we should keep an attach count and only allow touh.dll to be
loaded once.  But, since we are loaded at boot time by GWE, there is
no real concern about multiple loads (unless gwe has a bug!).
******************************************************************************/
LONG DdsiTouchPanelAttach (void)
{
    return(1);
}

/*****************************************************************************
DdsiTouchPanelDetach
--------------------
This function is called when the MDD's DLL entry point gets a
DLL_PROCESS_DETACH message.

Parameters
----------
None.

Return Values
-------------
Returns 0.

Remarks
-------
This routine no longer does anything.  All functionallity has been moved
from here into DdsiTouchPanelEnable to allow this code to be statically
linked with GWE rather than existing as a DLL.  Technically, when built
as a DLL we should keep an attach count and only allow touh.dll to be
loaded once.  But, since we are loaded at boot time by GWE, there is
no real concern about multiple loads (unless gwe has a bug!).
******************************************************************************/
LONG DdsiTouchPanelDetach(void)
{
    return(0);
}

/*****************************************************************************
DdsiTouchPanelDisable
---------------------
This function disables the touch screen device. Disabling a touch screen
prevents generation of any subsequent touch samples, and removes power from
the screen's hardware. The exact steps necessary depend on the specific
characteristics of the touch screen hardware.

Parameters
----------
None.

Return Values
-------------
None.

Remarks
-------
This function supports the implementation of the touch screen driver.
******************************************************************************/
VOID DdsiTouchPanelDisable(void)
{
	// Clean up any PDD-allocated resources and deinitialize the AC link.
    //
    DeInitializeACLink(FALSE, DEV_TOUCH);

	if(GpioRegs)
    {
        MmUnmapIoSpace((void *)GpioRegs,sizeof(AU1X00_SYS));
    }
}

/*****************************************************************************
DdsiTouchPanelEnable
--------------------
This function applies power to the touch screen device and initializes it for
operation.

Parameters
----------
None.

Return Values
-------------
TRUE indicates success. FALSE indicates failure.

Remarks
-------
This function supports the implementation of the touch screen driver.
******************************************************************************/
BOOL DdsiTouchPanelEnable(void)
{
    PHYSICAL_ADDRESS PhyAdd;
	BCSR *bcsr = (BCSR*)BCSR_KSEG1_ADDR;

	// Look at the board pacakge to determine if we
	// need to invert the touch panel x/y axis.
	// Any package greater than 0 currently
	// need to be inverted.
	if (bcsr->whoami & BCSR_WHOAMI_PACKAGE) 
	{
		g_InvertAxis = TRUE;
	}

	if(FALSE == RegisteCalibrationData())
		goto ErrorReturn;

	// Initialize the AC97 link.
    //
	if (!InitializeACLink(FALSE, DEV_TOUCH))
    {
		RETAILMSG(1, (TEXT("Touch: InitializeACLink() failed\r\n")));
        return(FALSE);
    }

    PhyAdd.QuadPart=SYS_PHYS_ADDR;
    GpioRegs = (AU1X00_SYS *)MmMapIoSpace(PhyAdd,sizeof(AU1X00_SYS),FALSE);

    if (GpioRegs == NULL)
	{
        DEBUGMSG(ZONE_ERROR,(TEXT("Can not map GPIO registers\r\n")));
        goto ErrorReturn;
    }

	gIntrTouch=InterruptConnectTimer();
	if(gIntrTouch==SYSINTR_NOP)
	{
		DEBUGMSG(ZONE_ERROR,(TEXT("Can not allocate Touch Timer SYSINTR\r\n")));
		goto ErrorReturn;
	}

	ConfigureAC97Control();

	if( EnableTouchScreen() == FALSE)
	{
        DEBUGMSG(ZONE_ERROR,(TEXT("Cannot initalise the touch screen codec\r\n")));
		goto ErrorReturn;
	}

	// start the timer
	InterruptStartTimer(gIntrTouch,TOUCH_POLL);

    return TRUE;

ErrorReturn:

	DdsiTouchPanelDisable();

    return FALSE;
}

/*****************************************************************************
TouchDriverCalibrationPointGet
--------------------
This function is called to get a single calibration point, in screen
coordinates, when the input system is calibrating the touch driver.  The input system
will then draw a target on the screen for the user to press on.

The driver may use the cDisplayX and cDisplayY to compute a coordinate.
It does not need to remember this computed value internally since it will
be passed back when the input system has collected all of the points and
calls <l TouchPanelSetCalibration.TouchPanelSetCalibration>.
******************************************************************************/
BOOL TouchDriverCalibrationPointGet(TPDC_CALIBRATION_POINT *pTCP)
{
	BOOL	retval = TRUE;

	INT32	cDisplayWidth = pTCP->cDisplayWidth;
	INT32	cDisplayHeight = pTCP->cDisplayHeight;

	int	CalibrationRadiusX = cDisplayWidth/10;
	int	CalibrationRadiusY = cDisplayHeight/10;

	DEBUGMSG(ZONE_FUNCTION,(TEXT("+TouchDriverCalibrationPointGet\r\n")));

	switch (pTCP->PointNumber)
	{
		case	0:	// Middle
			pTCP->CalibrationX = cDisplayWidth/2;
			pTCP->CalibrationY = cDisplayHeight/2;
			break;

		case	1:	// Upper Left
			pTCP->CalibrationX = CalibrationRadiusX*2;
			pTCP->CalibrationY = CalibrationRadiusY*2;
			break;

		case	2:  // Lower Left
			pTCP->CalibrationX = CalibrationRadiusX*2;
			pTCP->CalibrationY = cDisplayHeight - CalibrationRadiusY*2;
			break;

		case	3:  // Lower Right
			pTCP->CalibrationX = cDisplayWidth - CalibrationRadiusX*2;
			pTCP->CalibrationY = cDisplayHeight - CalibrationRadiusY*2;
			break;

		case	4:	// Upper Right
			pTCP->CalibrationX = cDisplayWidth - CalibrationRadiusX*2;
			pTCP->CalibrationY = CalibrationRadiusY*2;
			break;

		default:
			pTCP->CalibrationX = cDisplayWidth/2;
			pTCP->CalibrationY = cDisplayHeight/2;
			SetLastError(ERROR_INVALID_PARAMETER);
			retval = FALSE;
		}

	DEBUGMSG(ZONE_FUNCTION,(TEXT("-TouchDriverCalibrationPointGet\r\n")));

	return(retval);
}

/*****************************************************************************
DdsiTouchPanelGetDeviceCaps
---------------------------
This function queries capabilities of the touch screen device.

Parameters
----------
iIndex
[in] Specifies a capability to query. The following table shows the
capabilities you can specify. Value Description
TPDC_SAMPLE_RATE_ID Returns the sample rate.
TPDC_CALIBRATION_POINT_ID Returns the x and y coordinates of the required
calibration point. The index of the calibration point is set in
lpOutput->PointNumber.
TPDC_CALIBRATION_POINT_COUNT_ID Returns the number of calibration points
used to calibrate the touch screen.

lpOutput
[out] Pointer to one or more memory locations where the queried information
should be placed. The format of the memory referenced depends on the setting
of iIndex. The following table shows the iIndex values and corresponding
lpOutput descriptions. Value Description
TPDC_SAMPLE_RATE_ID Pointer to a TPDC_SAMPLE_RATE structure.
TPDC_CALIBRATION_POINT_ID Pointer to a TPDC_CALIBRATION_POINT structure.
TPDC_CALIBRATION_POINT_COUNT_ID Pointer to a TPDC_CALIBRATION_POINT_COUNT
structure.

Return Values
-------------
TRUE if successful, FALSE otherwise.

Remarks
-------
This function supports the implementation of the touch screen driver.
******************************************************************************/
BOOL DdsiTouchPanelGetDeviceCaps(INT iIndex,
                                 LPVOID lpOutput)
{
	if (lpOutput == NULL)
	{
		DEBUGMSG(ZONE_ERROR,(TEXT("DdsiTouchPanelGetDeviceCaps: invalid parameter.\r\n")));
		return FALSE;
	}

	switch	(iIndex)
	{
		case TPDC_SAMPLE_RATE_ID:
			{
			TPDC_SAMPLE_RATE	*pTSR = (TPDC_SAMPLE_RATE*)lpOutput;

			pTSR->SamplesPerSecondLow = TOUCHPANEL_SAMPLE_RATE_LOW;
			pTSR->SamplesPerSecondHigh = TOUCHPANEL_SAMPLE_RATE_HIGH;
			pTSR->CurrentSampleRateSetting = TOUCHPANEL_SAMPLE_RATE_LOW;
			}
			break;

		case TPDC_CALIBRATION_POINT_COUNT_ID:
			{
			TPDC_CALIBRATION_POINT_COUNT *pTCPC = (TPDC_CALIBRATION_POINT_COUNT*)lpOutput;
			pTCPC->flags = 0;
			pTCPC->cCalibrationPoints = 5;
			}
			break;

		case TPDC_CALIBRATION_POINT_ID:
			return(TouchDriverCalibrationPointGet((TPDC_CALIBRATION_POINT*)lpOutput));

		default:
			DEBUGMSG(ZONE_ERROR,(TEXT("TouchPanelGetDeviceCaps: invalid parameter.\r\n")));
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
	}
	return TRUE;
}

/*****************************************************************************
This function returns whether the pen is down or not

Parameters
----------
None.

Return Values
-------------
TRUE if pen down, FALSE if pen up.

Remarks
-------

******************************************************************************/
BOOL IsPenDown(void)
{
	unsigned long pinStatus;

	// Read register 7Ah bit 15 to see if pen is down
	ReadAC97(WM9712_GPIO_PIN_STATUS, (UINT16 *)(&pinStatus), DEV_TOUCH);

	return (pinStatus & (0x0001 << 13));

}

/*****************************************************************************
This function returns the most recently acquired point and its associated tip
state information.

Parameters
----------
pTipState
[out] Pointer to where the tip state information should be returned in
TOUCH_PANEL_SAMPLE_FLAGS.
pUnCalX
[out] Pointer to where the x-coordinate should be returned.
pUnCalY
[out] Pointer to where the y-coordinate should be returned.

Return Values
-------------
None.

Remarks
-------
This function supports the implementation of the touch screen driver.
******************************************************************************/
void DdsiTouchPanelGetPoint(P_TOUCH_PANEL_SAMPLE_FLAGS pTipState,
							INT *pUncalX,
							INT *pUncalY)
{
	volatile ULONG gpioState = 0;

    // Stop the Timer interrupt
	InterruptStopTimer(gIntrTouch);

	// Check state of pen by reading the GPIO
	gpioState = READ_REGISTER_ULONG((PULONG)&GpioRegs->pinstaterd);

	if(IsPenDown())
	{
		*pTipState = SampleTouchScreen(pUncalX,pUncalY);
		DEBUGMSG(ZONE_SAMPLES,(TEXT("TipState: %x ::Touch Point Coordiate: %d, %d \r\n"),*pTipState,*pUncalX,*pUncalY));
	}
	else
	{
		DEBUGMSG(ZONE_SAMPLES,(TEXT(".........Pen Up Event Detected %x \r\n"),gpioState));
		// Signal to the OS that the pen is up
	    *pTipState = TouchSampleValidFlag;
	}

	InterruptDone(gIntrTouch);
	// restart the polling timer
	InterruptStartTimer(gIntrTouch,TOUCH_POLL);
}

/*****************************************************************************
DdsiTouchPanelPowerHandler
--------------------------
This function indicates to the driver that the system is entering or leaving
the suspend state.

Parameters
----------
bOff
[in] TRUE indicates that the system is being turned off.
FALSE indicates that the system is being turned on.

Return Values
-------------
None.

Remarks
-------
As with all power-down handlers, this function cannot call functions in
other DLLs, memory allocators, debugging output functions, or do anything
that could cause a page fault. This routine is called by the MDD.
******************************************************************************/
VOID DdsiTouchPanelPowerHandler(BOOL bOff)
{
	if (bOff) 
	{
		RETAILMSG(1,(TEXT("TSC power off\r\n")));
		InterruptStopTimer(gIntrTouch);
		UnConfigureAC97Control();
	} else 
	{
		RETAILMSG(1,(TEXT("TSC power on\r\n")));
		ConfigureAC97Control();
		EnableTouchScreen();
		InterruptDone(gIntrTouch);
		InterruptStartTimer(gIntrTouch,TOUCH_POLL);
	}
}

/*****************************************************************************
DdsiTouchPanelSetMode
---------------------
This function sets information about the touch screen device.

Parameters
----------
iIndex
[in] Specifies the mode to set. The following table shows the modes you can set.
Value Description
TPSM_SAMPLERATE_HIGH_ID Sets the sample rate to the high rate.
TPSM_SAMPLERATE_LOW_ID Sets the sample rate to the low rate.

lpInput
[out] Pointer to one or more memory locations where the update information
resides. Points to one or more memory locations where the queried information
should be placed.

Return Values
-------------
TRUE indicates success. FALSE indicates failure.

Remarks
-------
This function supports the implementation of the touch screen driver.


******************************************************************************/
BOOL DdsiTouchPanelSetMode(INT iIndex,LPVOID  lpInput)
{
    BOOL  retval = FALSE;

    switch (iIndex)
	{
        case TPSM_SAMPLERATE_LOW_ID:
        case TPSM_SAMPLERATE_HIGH_ID:
            retval = TRUE;
            break;

    }
    return (retval);

}
/*****************************************************************************
SampleTouchScreen
-----------------

Parameters
----------
x
[out] Pointer to the x cordinate value.

y
[out] Pointer to the y cordinate value.

Return Values
-------------
The sample flags

Remarks
-------
This is a higher level function that will sample the touch screen both along
the X axis and the Y axis. It evaluates the samples and sets the status flags
correctly. This function will finally fill up X and Y parameters with the X
value and Y value.

******************************************************************************/

static TOUCH_PANEL_SAMPLE_FLAGS SampleTouchScreen(INT *x,INT *y)
{
	unsigned int i;
	TOUCHPANEL_POINT_SAMPLES rgPointSamples;
	TOUCH_PANEL_SAMPLE_FLAGS TmpStateFlags;
	INT TmpX = 0;
	INT TmpY = 0;

	DEBUGMSG(ZONE_FUNCTION,(TEXT("+SampleTouchScreen\r\n")));

		// Take a X and Y sample
	for(i=0;i<NUMBER_SAMPLES_PER_POINT;i++)
	{
		rgPointSamples[i].XSample = getTouchCoordinate(WM97_ADC_X);
		rgPointSamples[i].YSample = getTouchCoordinate(WM97_ADC_Y);
	}


	TmpStateFlags = TouchSampleDownFlag;
	if (evaluateSample(rgPointSamples[0].XSample,rgPointSamples[1].XSample,rgPointSamples[2].XSample,
		DELTA_X_COORD_VARIANCE,&TmpX) == TouchSampleIgnore)
	{
		TmpStateFlags |= TouchSampleIgnore;

		DEBUGMSG(ZONE_WARN,(TEXT("Invalid X sample\r\n")));
	}
	else
	{
		TmpStateFlags |= evaluateSample(rgPointSamples[0].YSample,rgPointSamples[1].YSample,rgPointSamples[2].YSample,
		DELTA_Y_COORD_VARIANCE,&TmpY);
	}

	DEBUGMSG(ZONE_SAMPLES,(TEXT("Filtered - SampleFlags: 0x%x X: 0x%x Y: 0x%x\r\n"),TmpStateFlags,TmpX,TmpY));
		// If this is a valid sample, remember it
	if ((TmpStateFlags & TouchSampleValidFlag))
	{
		*x = MAX_TOUCH_VAL - TmpY;
		*y = MAX_TOUCH_VAL - TmpX;
	}

	DEBUGMSG(ZONE_FUNCTION,(TEXT("-SampleTouchScreen\r\n")));

	return(TmpStateFlags);
}

/*****************************************************************************
getTouchCoordinate
-----------------

Parameters
----------
axis
[in] The axis that needs to be sampled.


Return Values
-------------
The coordinate data from the sample point

Remarks
-------
Generate a sample of touch point. It is simply call SampleADC at the moment,
in future, the logic of asserting touch point to see whether it is a qualified
point or not would be added. This will be achieved by measuring the touch
pressure.

******************************************************************************/

static USHORT getTouchCoordinate(UINT axis)
{
	USHORT sample=MAX_ADC_VAL;              // the maximum ADC output
	BOOL noError = FALSE;
	unsigned long adcDataReg;

	DEBUGMSG(ZONE_FUNCTION,(TEXT("+getTouchCoordinate\r\n")));

	ReadAC97(WM97_DIGITISER_DATA, (UINT16 *)(&adcDataReg), DEV_TOUCH);
	if(adcDataReg & WM97_DATA_PENDOWN)
	{
		noError = sampleADC(&sample,axis);
	}

	DEBUGMSG(ZONE_FUNCTION,(TEXT("-getTouchCoordinate\r\n")));

	if (g_InvertAxis == TRUE) sample = MAX_ADC_VAL - sample;

	return sample;
}

/*****************************************************************************
sampleADC
-----------------

Parameters
----------
sample
[out] pointer to the sample.

axis
[in] The axis on which to take the sample

Return Values
-------------
TRUE if successful.
FALSE if it fails

Remarks
-------
Generate sample of touch point.

******************************************************************************/

static BOOL sampleADC(USHORT *sample,UINT axis)
{
	BOOL noError =  FALSE;
	unsigned long adcControl1 = 0;
	unsigned long adcDataReg;

	DEBUGMSG(ZONE_FUNCTION,(TEXT("+sampleADC\r\n")));

	ReadAC97(WM97_DIGITISER_CONTROL1, (UINT16 *)(&adcControl1), DEV_TOUCH);

	adcControl1 &= ~WM97_TOUCHCTRL1_ADR_MASK;
	adcControl1 &= ~WM97_TOUCHCTRL1_DEL_MASK;

	adcControl1 |= ((axis == WM97_ADC_X ? WM97_TOUCHCTRL1_ADR_X : WM97_TOUCHCTRL1_ADR_Y)
		          | WM97_TOUCHCTRL1_POLL | WM97_TOUCHCTRL1_DEL_6);         //set polling mode, axis and delay

	if(WriteAC97(WM97_DIGITISER_CONTROL1, (UINT16)adcControl1, DEV_TOUCH))
	{
		// wait for sample completion, check polling bit to reset itself upon completion of the conversion
		do {
			ReadAC97(WM97_DIGITISER_CONTROL1, (UINT16 *)(&adcControl1), DEV_TOUCH);
			Sleep(0);
		} while(adcControl1 & WM97_TOUCHCTRL1_POLL);

		ReadAC97(WM97_DIGITISER_DATA, (UINT16 *)(&adcDataReg), DEV_TOUCH);
		if(adcDataReg & WM97_DATA_PENDOWN)
		{
			 *sample = (USHORT)(adcDataReg & WM97_DATA_VAL);   // lowest 12 bits
			 noError = TRUE;
		}
	}

	DEBUGMSG(ZONE_FUNCTION,(TEXT("-sampleADC\r\n")));
	return noError;
}

/*****************************************************************************
evaluateSample
-----------------

Parameters
----------
val0,val1,val2.
[in] The samples to be evaluated

maxError
[in] The maximum distance between to valid points

sample
[out] Pointer to the mean sample point

Return Values
-------------
The status of the sample point

Remarks
-------
This function will used only by the PDD. Each time on a pen down we collect
three samples from the ADC and choose the best sample. This function implements
algorithm for choosing the best sample. Given 3 samples we discard the sample
that is too way out and take a mean of the rest.

******************************************************************************/

static INT evaluateSample(USHORT val0,USHORT val1,USHORT val2,int maxError,INT *sample)
{
	LONG    diff0,diff1,diff2;
	INT		retval=TouchSampleIgnore;

	DEBUGMSG(ZONE_FUNCTION,(TEXT("+evaluateSample\r\n")));

	if ((val0 < MAX_ADC_VAL) && (val1 < MAX_ADC_VAL) && (val2 < MAX_ADC_VAL))
	{
		// Calculate the absolute value of the differences of the sample
		diff0 = val0 - val1;
		diff1 = val1 - val2;
		diff2 = val2 - val0;
		diff0 = diff0 > 0  ? diff0 : -diff0;
		diff1 = diff1 > 0  ? diff1 : -diff1;
		diff2 = diff2 > 0  ? diff2 : -diff2;

		if (diff0 < diff1)
			*sample=(ULONG)(val0 + ((diff2 < diff0) ? val2 : val1));
	    else
			*sample=(ULONG)(val2 + ((diff2 < diff1) ? val0 : val1));

		*sample>>=1;

		if ((diff0 < maxError) && (diff1 < maxError) && (diff2 < maxError))
			retval = TouchSampleValidFlag ;
	}

	DEBUGMSG(ZONE_FUNCTION,(TEXT("-evaluateSample\r\n")));

	return(retval);
}




/*****************************************************************************
EnableTouchScreen
-----------------

Parameters
----------
None.

Return Values
-------------
TRUE indicates success, FALSE indicates failure of read operation

Remarks
-------
Configures a Wolfson WM9705 or 9712 touch controller.
******************************************************************************/

static BOOL EnableTouchScreen(void)
{
	ULONG vendor1 = 0;
	ULONG adcControl2;
	ULONG gpioPinConfig=0;
	ULONG gpioPinShare=0;
	ULONG whatAmI = 0x0000;

	//Check to see if this is a wolfson touchscreen part
	if( ReadAC97(WM97_VENDOR_ID1, (UINT16 *)(&vendor1), DEV_TOUCH) == FALSE )
	{
		DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to read from device WM97_VENDOR_ID1\r\n")));
		goto ErrorReturn;
	}

	if( ReadAC97(WM97_VENDOR_ID2, (UINT16 *)(&whatAmI), DEV_TOUCH) == FALSE )
	{
		DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to read from device WM97_VENDOR_ID2\r\n")));
		goto ErrorReturn;
	}

	if(vendor1 == WOLFSON_MICRO)
	{
		DEBUGMSG(ZONE_INIT,(TEXT("EnableTouchScreen WOLFSON_MICRO, 0x%x)\r\n"), whatAmI));
		// Only 9705 & 9712 have touch functionality
		if( !(whatAmI == WM9705_CHIP || whatAmI == WM9712_CHIP) )
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Touch Screen Driver only works with WM9705 & 12\r\n")));
			goto ErrorReturn;
		}
	}
	else
	{
		DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen NOT WOLFSON, 0x%x)\r\n"), vendor1));
		// Only 9705 & 9712 have touch functionality
		goto ErrorReturn;
	}

	if(whatAmI == WM9705_CHIP)
	{
		if( ReadAC97(WM97_DIGITISER_CONTROL2, (UINT16 *)(&adcControl2), DEV_TOUCH) == FALSE )
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to read from device\r\n")));
			goto ErrorReturn;
		}

		adcControl2 |= WM97_TOUCHCTRL2_PRP_PDW_3;


		if(WriteAC97(WM97_DIGITISER_CONTROL2, (UINT16)adcControl2, DEV_TOUCH) == FALSE)
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to write to device\r\n")));
			goto ErrorReturn;
		}
	}
	if(whatAmI == WM9712_CHIP)
	{
		if( ReadAC97(WM97_DIGITISER_CONTROL2, (UINT16 *)(&adcControl2), DEV_TOUCH) == FALSE )
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to read from device\r\n")));
			goto ErrorReturn;
		}

		DEBUGMSG(ZONE_FUNCTION,(TEXT("EnableTouchScreen Happy\r\n")));
		adcControl2 |= WM97_TOUCHCTRL2_PRP_PDW_3;

		if(WriteAC97(WM97_DIGITISER_CONTROL2, (UINT16)adcControl2, DEV_TOUCH) == FALSE)
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to write to device\r\n")));
			goto ErrorReturn;
		}

		if( ReadAC97(WM97_DIGITISER_CONTROL2, (UINT16 *)(&adcControl2), DEV_TOUCH) == FALSE )
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to read from device\r\n")));
			goto ErrorReturn;
		}
		if( ReadAC97(WM9712_GPIO_PIN_CONFIG, (UINT16 *)(&gpioPinConfig), DEV_TOUCH) == FALSE )
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to read from device\r\n")));
			goto ErrorReturn;
		}

		gpioPinConfig &= ~PENDOWN_GPIO;

		if(WriteAC97(WM9712_GPIO_PIN_CONFIG, (UINT16)gpioPinConfig, DEV_TOUCH) == FALSE)
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to write to device\r\n")));
			goto ErrorReturn;
		}


		if( ReadAC97(WM9712_GPIO_PIN_CONFIG, (UINT16 *)(&gpioPinConfig), DEV_TOUCH) == FALSE )
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to read from device\r\n")));
			goto ErrorReturn;
		}
		if( ReadAC97(WM9712_GPIO_PIN_SHARING, (UINT16 *)(&gpioPinConfig), DEV_TOUCH) == FALSE )
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to read from device\r\n")));
			goto ErrorReturn;
		}

		gpioPinConfig &= ~PENDOWN_GPIO;

		if(WriteAC97(WM9712_GPIO_PIN_SHARING, (UINT16)gpioPinConfig, DEV_TOUCH) == FALSE)
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to write to device\r\n")));
			goto ErrorReturn;
		}

		if( ReadAC97(WM9712_GPIO_PIN_SHARING, (UINT16 *)(&gpioPinConfig), DEV_TOUCH) == FALSE )
		{
			DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchScreen : Failed to read from device\r\n")));
			goto ErrorReturn;
		}
	}

	DEBUGMSG(ZONE_FUNCTION,(TEXT("EnableTouchscreen PASSED\r\n")));
	return TRUE;

ErrorReturn :
	DEBUGMSG(ZONE_ERROR,(TEXT("EnableTouchscreen FAILED\r\n")));
	return FALSE;
}

static BOOL RegisteCalibrationData()
{
    HKEY    hkey;
    LONG Status;

	const TCHAR szCalibrationData[] =
//for Topply 240x320
//		(TEXT("2045,2074 933,3145 3149,3151 3144,1000 924,1038"));
//for PVI 640x480
//		(TEXT("2082,2038 3150,3183 978,3173 986,894 3163,896"));
//for PVI 640x480  argon 2
//		(TEXT("2062,2039 920,3121 928,943 3221,934 3218,3121"));
//for SAMSUNG 480x272  argon 3
		(TEXT("2066,2018 924,3122 884,938 3188,915 3219,3114"));

    Status = RegOpenKeyEx(
        HKEY_LOCAL_MACHINE,
        TOUCH_PANEL_CALIBRATION_DATA_REGKEY,
        0,
        0,
        &hkey);

    if (ERROR_SUCCESS == Status)
	{
      Status  = RegSetValueEx(hkey,
	  					(TEXT("CalibrationData")),
                        0,
                        REG_SZ,
                        (PUCHAR)szCalibrationData,
                        (sizeof(TCHAR)*(lstrlen(szCalibrationData)+1)));
    }
	else
		RETAILMSG(1,(TEXT("RegisteCalibrationData ERROR!\r\n")));

	RegCloseKey(hkey);

	return (ERROR_SUCCESS == Status)?TRUE:FALSE;
}

BOOL TouchReset()
{
	return (TRUE);
}
BOOL TouchRegisterWindow()
{
	return (TRUE);
}
BOOL TouchUnregisterWindow()
{
	return (TRUE);
}
BOOL TouchSetValue()
{
	return (TRUE);
}
BOOL TouchGetValue()
{
	return (TRUE);
}
BOOL TouchCreateEvent()
{
	return (TRUE);
}
BOOL TouchGetFocusWnd()
{
	return (TRUE);
}
BOOL TouchGetLastTouchFocusWnd()
{
	return (TRUE);
}
BOOL TouchGetQueuePtr()
{
	return (TRUE);
}

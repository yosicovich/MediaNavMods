///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2002-2004 BSQUARE Corporation.  All rights reserved.
//
// Module Name:
//
//    SDIOMain.c
//
// Abstract:
//
//   Driver entry points
//
// Notes:
//
///////////////////////////////////////////////////////////////////////////////

#include "sdcardddk.h"
#include "sdhcd.h"
#include "sdio.h"
//#include "nkintr.h"

//     ZONE_ENABLE_INIT | ZONE_ENABLE_ERROR | ZONE_ENABLE_WARN | SDIO_INTERRUPT_ZONE_ON |
//     SDIO_SEND_ZONE_ON | SDIO_RESPONSE_ZONE_ON | SDIO_TRANSMIT_ZONE_ON,

    // initialize debug zones
SD_DEBUG_INSTANTIATE_ZONES(
     TEXT("Au1100 SDIO Driver"), // module name
     ZONE_ENABLE_INIT | ZONE_ENABLE_ERROR | ZONE_ENABLE_WARN ,
     TEXT("Interrupts"),
     TEXT("Send Handler"),
     TEXT("Responses"),
     TEXT("Receive Data"),
     TEXT("Clock Control"),
     TEXT("Transmit Data"),
     TEXT("DMA"),
     TEXT(""),
     TEXT(""),
     TEXT(""),
     TEXT(""));

#define SDIO_REGISTRY_BASE_PATH TEXT("Drivers\\SDCARD\\HostControllers\\Au1100")

///////////////////////////////////////////////////////////////////////////////
//  DllEntry - the main dll entry point
//  Input:  hInstance - the instance that is attaching
//          Reason - the reason for attaching
//          pReserved - not much
//  Output:
//  Return: always TRUE
//  Notes:  this is only used to initialize the zones
///////////////////////////////////////////////////////////////////////////////
BOOL DllEntry(HINSTANCE  hInstance,
              ULONG      Reason,
              LPVOID     pReserved)
{
    BOOL fRet = TRUE;

    if (Reason == DLL_PROCESS_ATTACH) {
        DEBUGREGISTER(hInstance);
        DisableThreadLibraryCalls((HMODULE) hInstance);

        if (!SDInitializeCardLib()) {
            fRet = FALSE;
        }
        else if (!SD_API_SUCCESS(SDHCDInitializeHCLib())) {
            SDDeinitializeCardLib();
            fRet = FALSE;
        }
    }
    else if (Reason == DLL_PROCESS_DETACH) {
        SDHCDDeinitializeHCLib();
        SDDeinitializeCardLib();
    }

    return fRet;
}

///////////////////////////////////////////////////////////////////////////////
//  SDP_Deinit - the deinit entry point for the driver
//  Input:  hDeviceContext - the context returned from SDP_Init
//  Output:
//  Return: always returns TRUE.
//  Notes:
///////////////////////////////////////////////////////////////////////////////
BOOL SDP_Deinit(DWORD hDeviceContext)
{
    PSDCARD_HC_CONTEXT pHostContext;

    DbgPrintZo(SDCARD_ZONE_INIT, (TEXT("SDH: +SDH_Deinit\r\n")));

    pHostContext = (PSDCARD_HC_CONTEXT)hDeviceContext;

        // deregister the host controller
    SDHCDDeregisterHostController(pHostContext);

    if( pHostContext && pHostContext->pHCSpecificContext )
    {
        free( pHostContext->pHCSpecificContext );
    }

        // cleanup the context
    SDHCDDeleteContext((PSDCARD_HC_CONTEXT)hDeviceContext);

    return TRUE;}

///////////////////////////////////////////////////////////////////////////////
//  SDP_Init - the init entry point for the CE driver instance
//  Input:  dwContext - the context passed from device manager
//  Output:
//  Return: the new device instance, zero on failure
//  Notes:
///////////////////////////////////////////////////////////////////////////////
DWORD SDP_Init(DWORD dwContext)
{
    PSDCARD_HC_CONTEXT pHostContext;    // new HC context
    SD_API_STATUS      status;          // SD status
    PSDIO_HW_CONTEXT   pController;     // new instance
    DWORD              win32Status;     // win32 status
    HKEY               hKey;            // reg key
    DWORD              dataSize;        // size of key to get
	DWORD				dwIntr;

    DWORD              PIOMode = FALSE; // PIO mode flag
	DWORD				Disable8BitBus = FALSE; // disable 8 bit wide data bus flag

    DbgPrintZo(SDCARD_ZONE_INIT, (TEXT("SDIO +SDP_Init\r\n")));

    DbgPrintZo(SDCARD_ZONE_INIT, (TEXT("SDIO Active RegPath: %s \r\n"),(PTSTR)dwContext));

        // allocate the context
    status = SDHCDAllocateContext(SDIOPlatNumSlots(), &pHostContext);

    if (!SD_API_SUCCESS(status)) {
        DbgPrintZo(SDCARD_ZONE_ERROR, (TEXT("SDIO Failed to allocate context : 0x%08X \r\n"), status));
        return 0;
    }

        // allocate controller structure
    pController = malloc( sizeof(*pController) );
    if( pController == NULL ) {
        DbgPrintZo(SDCARD_ZONE_ERROR, (TEXT("SDH: Failed to allocate extension\r\n")));
        return 0;
    }
    memset( pController, 0, sizeof(*pController) );

    // Set our extension
    pHostContext->pHCSpecificContext = pController;
    pController = GetExtensionFromHCDContext(PSDIO_HW_CONTEXT, pHostContext);

        // extract the real reg path from the init context passed in
    win32Status = SDGetRegPathFromInitContext((PWCHAR)dwContext,
                                              pController->RegPath,
                                              sizeof(pController->RegPath));

    if (ERROR_SUCCESS != win32Status) {
        DbgPrintZo(SDCARD_ZONE_ERROR, (TEXT("SDIO Failed to get registry path (%d) \r\n"), win32Status));
        return 0;
    }

    DbgPrintZo(SDCARD_ZONE_INIT, (TEXT("SDIO Real RegPath: %s \r\n"),pController->RegPath));

	// by default disable 8 bit wide data bus for SD1 (slot 0),
	// and enable for SD0 (slot 1, eMMC)
    pController->Slots[0].MMC8BitBusSupport = FALSE;
    pController->Slots[1].MMC8BitBusSupport = TRUE;

#ifdef USE_DMA
        // default to DMA mode
    pController->Slots[0].UsingDma = TRUE;
    pController->Slots[1].UsingDma = TRUE;
#endif //#ifdef USE_DMA

    // look for controller registry keys
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                     pController->RegPath,
                     0,
                     KEY_ALL_ACCESS,
                     &hKey) == ERROR_SUCCESS)
	{
        // set the data size
        dataSize = sizeof(Disable8BitBus);

        // look for key
        RegQueryValueEx(hKey,
                       DISABLE_8_BIT_BUS_KEY,
                       NULL,
                       NULL,
                       (PUCHAR)&Disable8BitBus,
                       &dataSize);

        // If flag is set, disable the 8 bit wide data bus for the emmc slot
		if (Disable8BitBus)
		{
            pController->Slots[1].MMC8BitBusSupport = FALSE;
            DbgPrintZo(SDCARD_ZONE_INIT,(TEXT("SDIO: Disable 8 bit wide data bus for slot 1 (SD0, eMMC)\r\n")));
        }

#ifdef USE_DMA
			// set the data size
        dataSize = sizeof(PIOMode);

            // look for  key
        RegQueryValueEx(hKey,
                       PIO_MODE_KEY,
                       NULL,
                       NULL,
                       (PUCHAR)&PIOMode,
                       &dataSize);

        if (PIOMode)
		{
            pController->Slots[0].UsingDma = FALSE;
            pController->Slots[1].UsingDma = FALSE;

            DbgPrintZo(SDCARD_ZONE_INIT,(TEXT("SDIO: Using PIO mode\r\n")));
        }
#endif //#ifdef USE_DMA

        RegCloseKey(hKey);
    }

#ifdef PLATFORM_DB13XX
//	dwIntr = HWINTR_SD0<<16 | HWINTR_SD1<<8 | HWINTR_SD2;
	dwIntr = HWINTR_SD0<<8 | HWINTR_SD1;
//	dwIntr = HWINTR_SD1;
#else
	dwIntr = HWINTR_SD;
#endif
        // connect controller interrupt
    pController->SysIntr = InterruptConnect(Internal,
                                            0,
                                            dwIntr,
                                            0);

    if (SYSINTR_NOP==pController->SysIntr) {
        DbgPrintZo(SDCARD_ZONE_ERROR,(TEXT("InterruptConnect returned SYSINTR_NOP\r\n")));
        return 0;
    }

        // save off the host context
    pController->pHCContext = pHostContext;

        // set the host controller name
    SDHCDSetHCName(pHostContext, TEXT("Au1100 SDIO"));

        // set init handler
    SDHCDSetControllerInitHandler(pHostContext, SDIOInitialize);
        // set deinit handler
    SDHCDSetControllerDeinitHandler(pHostContext, SDIODeinitialize);
        // set the bus reqeust handler
    SDHCDSetBusRequestHandler(pHostContext, SDIOBusRequestHandler);
        // set the cancel I/O handler
    SDHCDSetCancelIOHandler(pHostContext, SDIOCancelIoHandler);
        // set the slot option handler
    SDHCDSetSlotOptionHandler(pHostContext, SDIOSlotOptionHandler);

        // now register the host controller
    status = SDHCDRegisterHostController(pHostContext);

    if (!SD_API_SUCCESS(status)) {
        SDHCDDeleteContext(pHostContext);
        DbgPrintZo(SDCARD_ZONE_ERROR, (TEXT("SDIO: Failed to register host controller: %0x08X \r\n"),status));
        return 0;
    }

    DbgPrintZo(SDCARD_ZONE_INIT, (TEXT("SDIO: -SDP_Init\r\n")));
        // return the Host Controller context
    return (DWORD)pHostContext;
}

///////////////////////////////////////////////////////////////////////////////
//  SDP_IOControl - the I/O control entry point for the driver
//  Input:  hOpenContext - the context returned from SDP_Open
//          dwCode - the ioctl code
//          pBufIn - the input buffer from the user
//          dwLenIn - the length of the input buffer
//          pBufOut - the output buffer from the user
//          dwLenOut - the length of the output buffer
//          pdwActualOut - the size of the transfer
//  Output:
//  Return: always FALSE
//  Notes:
///////////////////////////////////////////////////////////////////////////////
BOOL SDP_IOControl(DWORD   hOpenContext,
                   DWORD   dwCode,
                   PBYTE   pBufIn,
                   DWORD   dwLenIn,
                   PBYTE   pBufOut,
                   DWORD   dwLenOut,
                   PDWORD  pdwActualOut)
{
    DbgPrintZo(SDCARD_ZONE_FUNC, (TEXT("SDIO: +-SDP_IOControl \r\n")));
    return FALSE;;
}

///////////////////////////////////////////////////////////////////////////////
//  SDP_Open - the open entry point for the driver
//  Input:  hDeviceContext - the device context from SDP_Init
//          AccessCode - the desired access
//          ShareMode - the desired share mode
//  Output:
//  Return: Always zero
//  Notes:
///////////////////////////////////////////////////////////////////////////////
DWORD SDP_Open(DWORD    hDeviceContext,
               DWORD    AccessCode,
               DWORD    ShareMode)
{
    DbgPrintZo(SDCARD_ZONE_FUNC, (TEXT("SDIO: +-SDP_Open\r\n")));
    return 0;
}



///////////////////////////////////////////////////////////////////////////////
//  SDP_Close - the close entry point for the driver
//  Input:  hOpenContext - the context returned from SDP_Open
//  Output:
//  Return: always returns TRUE
//  Notes:
///////////////////////////////////////////////////////////////////////////////
BOOL SDP_Close(DWORD hOpenContext)
{
    DbgPrintZo(SDCARD_ZONE_FUNC, (TEXT("SDIO: +-SDP_Close\r\n")));
    return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//  SDP_PowerDown - the power down entry point for the driver
//  Input:  hDeviceContext - the device context from SDP_Init
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
void SDP_PowerDown(DWORD hDeviceContext)
{
    PSDIO_HW_CONTEXT pController;
	int i;

    pController = GetExtensionFromHCDContext(PSDIO_HW_CONTEXT,
                                            (PSDCARD_HC_CONTEXT)hDeviceContext);

	for (i=0;i<SDIOPlatNumSlots();i++) {
			// indicate power down , also indicating that power will be removed from the slot
		SDHCDPowerUpDown((PSDCARD_HC_CONTEXT)hDeviceContext, FALSE, FALSE, i);

            // remove power from slot
	    SDIOPlatPower(pController, FALSE, i);
    }

    return;
}

///////////////////////////////////////////////////////////////////////////////
//  SDP_PowerUp - the power up entry point for the driver
//  Input:  hDeviceContext - the device context from SDP_Init
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
void SDP_PowerUp(DWORD  hDeviceContext)
{
    PSDIO_HW_CONTEXT    pController;
	int i;

    pController = GetExtensionFromHCDContext(PSDIO_HW_CONTEXT,
                                            (PSDCARD_HC_CONTEXT)hDeviceContext);

	for (i=0;i<SDIOPlatNumSlots();i++) {
			// indicate power up
		SDHCDPowerUpDown((PSDCARD_HC_CONTEXT)hDeviceContext, TRUE, FALSE, i);

            // enable power to slot
	    SDIOPlatPower(pController, TRUE, i);

			// flag card detect thread to run through power up cycle
			// since there is a device present we issue a "fake" interrupt
			// so the card detection thread runs
		pController->Slots[i].CheckSlotOnStartUp  = TRUE;

			// wake up the card detect thread so that it can cycle device removal
			// to the bus driver
			// this is the only "safe" api to call
		SetInterruptEvent(pController->Slots[i].InsertionSysIntr);
	}

    return;
}

///////////////////////////////////////////////////////////////////////////////
//  SDP_Read - the read entry point for the driver (Unused)
//  Input:  hOpenContext - the context from SDP_Open
//          pBuffer - the user's buffer
//          Count - the size of the transfer
//  Output:
//  Return: always zero
//  Notes:
///////////////////////////////////////////////////////////////////////////////
DWORD SDP_Read(DWORD    hOpenContext,
               LPVOID   pBuffer,
               DWORD    Count)
{
    DbgPrintZo(SDCARD_ZONE_FUNC, (TEXT("SDIO: +-SDP_Read\r\n")));
    return 0;
}

///////////////////////////////////////////////////////////////////////////////
//  SDP_Seek - the seek entry point for the driver (Unused)
//  Input:  hOpenContext - the context from SDP_Open
//          Amount - the amount to seek
//          Type - the type of seek
//  Output:
//  Return: always zero
//  Notes:
///////////////////////////////////////////////////////////////////////////////
DWORD SDP_Seek(DWORD    hOpenContext,
               long     Amount,
               DWORD    Type)
{
    DbgPrintZo(SDCARD_ZONE_FUNC, (TEXT("SDIO: +-SDP_Seek\r\n")));
    return 0;
}

///////////////////////////////////////////////////////////////////////////////
//  SDP_Write - the write entry point for the driver (Unused)
//  Input:  hOpenContext - the context from SDP_Open
//          pBuffer - the user's buffer
//          Count - the size of the transfer
//  Output:
//  Return: always zero
//  Notes:
///////////////////////////////////////////////////////////////////////////////
DWORD SDP_Write(DWORD   hOpenContext,
                LPCVOID pBuffer,
                DWORD   Count)
{
    DbgPrintZo(SDCARD_ZONE_FUNC, (TEXT("SDIO: +-SDP_Write\r\n")));
    return 0;
}



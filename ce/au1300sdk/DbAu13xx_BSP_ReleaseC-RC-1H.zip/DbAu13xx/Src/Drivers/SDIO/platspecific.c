/*++
Copyright (c) 2005  BSQUARE Corporation.  All rights reserved.

Module Name:

    platspecific.c

Module Description:

    This file contains platform specific functions for the SD driver.

Author:

    Ian Rae 3-Feb-2005

Notes:

Revision History:

--*/

#include "sdcardddk.h"
#include "sdhcd.h"
#include "sdio.h"
#ifdef AU13XX
 #include <gpintr.h>
#else
 #include <gpio.h>
#endif



int SDIOPlatNumSlots()
{
#ifdef PLATFORM_DB13XX
// SD0 -- eMMC
// SD1 -- Slot
// SD2 -- Saturn Connector ( TBD )
	return 2;
//	return 1;
#else
	return 1;
#endif
}


// card insertion interrupts
// mapping BCSR etc
SD_API_STATUS SDIOPlatInit(PSDIO_HW_CONTEXT pController)
{
    SD_API_STATUS    status = SD_API_STATUS_SUCCESS;
    PHYSICAL_ADDRESS PhysAddr;

	PhysAddr.HighPart = 0;
	PhysAddr.LowPart = BCSR_PHYSADDR;

	pController->pPlatSpecificPtr = MmMapIoSpace(PhysAddr,
	                                             sizeof(BCSR),
												 FALSE);

	if (NULL==pController->pPlatSpecificPtr) {
		DbgPrintZo(SDCARD_ZONE_ERROR,(TEXT("SDIOPlatInit - failed to map BCSR\r\n")));
        status = SD_API_STATUS_INSUFFICIENT_RESOURCES;
		goto ErrorReturn;
	}

       // connect slot SD_REMOVABLE_SLOT insertion interrupt
    pController->Slots[SD_REMOVABLE_SLOT].InsertionSysIntr = InterruptConnect(Internal,
                                                              0,
                                                              (HWINTR_EXT_SD0INSERT << 8) | HWINTR_EXT_SD0EJECT,
                                                              0);

    if (SYSINTR_NOP==pController->Slots[SD_REMOVABLE_SLOT].InsertionSysIntr) {
        DbgPrintZo(SDCARD_ZONE_ERROR,(TEXT("InterruptConnect returned SYSINTR_NOP\r\n")));
        status = SD_API_STATUS_INSUFFICIENT_RESOURCES;
		goto ErrorReturn;
    }

#if !defined(PLATFORM_DB13XX)
	// Set Pinfunc for SD0
	GPIO_SetPinFunction(pController->hGPIO, SYS_PINFUNC_S0A|SYS_PINFUNC_S0B);
	GPIO_ClearPinFunction(pController->hGPIO, SYS_PINFUNC_S0C);
#endif // PLATFORM_DB13XX

ErrorReturn:

	return status;
}

// un-mapping BCSR etc
SD_API_STATUS SDIOPlatDeinit(PSDIO_HW_CONTEXT pController)
{
    SD_API_STATUS status = SD_API_STATUS_SUCCESS;

	if (NULL!=pController->pPlatSpecificPtr) {
		MmUnmapIoSpace(pController->pPlatSpecificPtr,sizeof(BCSR));
		pController->pPlatSpecificPtr = NULL;
	}

	return status;
}

SD_API_STATUS SDIOPlatPower(PSDIO_HW_CONTEXT pController, BOOL PowerOn, ULONG Slot)
{
	USHORT tmp=0;

#ifdef PLATFORM_DB13XX
	// Db13xx always applies power to SD0, SD1 and SD2
#endif //PLATFORM_DB13XX

#ifdef PLATFORM_DB1200
	pBCSR pbcsr = pController->pPlatSpecificPtr;

	tmp = READ_REGISTER_USHORT((PUSHORT)&pbcsr->specific);

	if (PowerOn) {
		tmp |= BCSR_SPECIFIC_SD0PWR;
	} else {
		tmp &= ~BCSR_SPECIFIC_SD0PWR;
	}

	WRITE_REGISTER_USHORT((PUSHORT)&pbcsr->specific,tmp);
#endif
	return SD_API_STATUS_SUCCESS;
}

BOOL SDIOPlatCardWriteProteced(PSDIO_HW_CONTEXT pController, ULONG Slot)
{
	PBCSR pbcsr = pController->pPlatSpecificPtr;

#ifdef PLATFORM_DB13XX
	// Only Slot 1 has the ability to write protect
	if ( Slot != SD_REMOVABLE_SLOT )
		return FALSE;
#endif

	if (BCSR_STATUS_SD0WP & READ_REGISTER_USHORT((PUSHORT)&pbcsr->status)) {
		return TRUE;
	} else {
		return FALSE;
	}
}

BOOL SDIOPlatCardInserted(PSDIO_HW_CONTEXT pController, ULONG Slot)
{
	PBCSR pbcsr = pController->pPlatSpecificPtr;

#ifdef PLATFORM_DB13XX
	// Only Slot 1 can be ejected. The others are soldered
	// to the board. eMMC and Saturn Connector
	if ( Slot != SD_REMOVABLE_SLOT )
		return TRUE;
#endif

	if (BCSR_BIC_SD0INSERT & READ_REGISTER_USHORT((PUSHORT)&pbcsr->sigstatus)) {
		// Disable insertion interrupt, enable ejection interrupt
		WRITE_REGISTER_USHORT((PUSHORT)&pbcsr->intclrenable,BCSR_BIC_SD0INSERT);
		WRITE_REGISTER_USHORT((PUSHORT)&pbcsr->intsetenable,BCSR_BIC_SD0EJECT);
		return TRUE;
	} else {
		// Disable ejection interrupt, enable insertion interrupt
		WRITE_REGISTER_USHORT((PUSHORT)&pbcsr->intsetenable,BCSR_BIC_SD0INSERT);
		WRITE_REGISTER_USHORT((PUSHORT)&pbcsr->intclrenable,BCSR_BIC_SD0EJECT);
		return FALSE;
	}
}

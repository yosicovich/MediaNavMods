///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2002,2004-2005 BSQUARE Corporation.  All rights reserved.
//
// Module Name:
//
//    SDIO.c
//
// Abstract:
//
//    Au1100 SDIO controller driver implementation
//
// Notes:
//
///////////////////////////////////////////////////////////////////////////////

#include <windows.h>	// For min() macro
#include <sdcardddk.h>
#include <sdhcd.h>
#include "sdio.h"
#include "gpio.h"

#define SD_SLOT_MMC_8BIT_CAPABLE (1<<31) // hijack this bit for eMMC capabilities
#define SDIO_MAX_CLOCK_RATE (52000000)
#define SDIO_MAX_DIV_VALUE  (511)

#undef DEBUGMSG
#define DEBUGMSG(c,m) RETAILMSG(c,m)

#ifndef DEBUG

	#undef SDCARD_ZONE_0
	#undef SDCARD_ZONE_1
	#undef SDCARD_ZONE_2
	#undef SDCARD_ZONE_3
	#undef SDCARD_ZONE_4
	#undef SDCARD_ZONE_5
	#undef SDCARD_ZONE_6
	#undef SDCARD_ZONE_7
	#undef SDCARD_ZONE_8
	#undef SDCARD_ZONE_9
	#undef SDCARD_ZONE_10
	#undef SDCARD_ZONE_FUNC
	#undef SDCARD_ZONE_INFO
	#undef SDCARD_ZONE_INIT
	#undef SDCARD_ZONE_WARN
	#undef SDCARD_ZONE_ERROR

	#define SDCARD_ZONE_0      		0
	#define SDCARD_ZONE_1      		0
	#define SDCARD_ZONE_2      		0
	#define SDCARD_ZONE_3      		0
	#define SDCARD_ZONE_4      		0
	#define SDCARD_ZONE_5      		0
	#define SDCARD_ZONE_6      		0
	#define SDCARD_ZONE_7      		0
	#define SDCARD_ZONE_8      		0
	#define SDCARD_ZONE_9      		0
	#define SDCARD_ZONE_10     		0
	#define SDCARD_ZONE_FUNC   		0
	#define SDCARD_ZONE_INFO   		0
	#define SDCARD_ZONE_INIT   		1
	#define SDCARD_ZONE_WARN   		0
	#define SDCARD_ZONE_ERROR  		0
#endif


typedef struct {
	ULONG	BlocksCopied;
	ULONG   BytesCopied;
	ULONG   BuffersOutstanding;
} HC_PARAMS, *PHC_PARAMS;

static HC_PARAMS HCParams[SDIO_NUM_SLOTS];

#define CARD_SLOT	0
#define EMMC		1
#define MOVINAND	2

// structure containing configuration information for each slot
typedef struct {
	ULONG SDPhysAddr;
	ULONG TxDmaDeviceId;
	ULONG RxDmaDeviceId;
	BOOL  bRemoveable;
	ULONG DeviceType;
} AUSDIO_CONFIG;

AUSDIO_CONFIG AuSdConfig[] = {
	{ SD1_PHYS_ADDR, DMA_SD1_TX, DMA_SD1_RX, TRUE,  CARD_SLOT },
	{ SD0_PHYS_ADDR, DMA_SD0_TX, DMA_SD0_RX, FALSE, EMMC },
    {0,0,0}
};



///////////////////////////////////////////////////////////////////////////////
//  ResetSlot - reset the slot to its initial state
//  Input:  pSlot -   slot context
//  Output:
//  Return:
///////////////////////////////////////////////////////////////////////////////
VOID ResetSlot(PSDIO_SLOT pSlot, BOOL IsInitPath)
{
	ULONG divisor = 0;
	ULONG config2 = 0;

	if (!IsInitPath)
    {
		config2 = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->config2);
		divisor = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->config);
		divisor &= SD_CONFIG_DIV;
	}
	else
	{
#if defined(SD_FIFO_32BITS)
		config2 |= SD_CONFIG2_DP;
#endif
	}

		// reset the controller
	WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->enable, 0);
	WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->enable, SD_ENABLE_CE);
	WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->enable, SD_ENABLE_R | SD_ENABLE_CE);

		// enable the state machines
	WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->config2, config2 | SD_CONFIG2_EN );
		// set the timeout to max
	WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->timeout, SD_TIMEOUT_MAX );

		// write clock
	WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->config, divisor | SD_CONFIG_DE);

		// Disable all interrupts
	SD_INTERRUPTS_DISABLE(pSlot,0xFFFFFFFF);
		// Clear interrupt status
	SD_INTERRUPTS_CLEAR(pSlot,0xFFFFFFFF);
		// Enable master inerrupt
	SD_INTERRUPTS_ENABLE(pSlot, SD_Int_Master );
}

///////////////////////////////////////////////////////////////////////////////
//  DumpSlot - dump the states of the slot
//  Input:  pSlot -   slot context
//  Output:
//  Return:
///////////////////////////////////////////////////////////////////////////////
VOID DumpSlot( PSDIO_SLOT pSlot )
{
    RETAILMSG(1,(TEXT("SDIO SLOT %d\r\n"),pSlot->SlotNumber));
    RETAILMSG(1,(TEXT("SD_CONFIG = 0x%08X\r\n"),READ_REGISTER_ULONG((PULONG)&pSlot->pSD->config)));
    RETAILMSG(1,(TEXT("SD_ENABLE = 0x%08X\r\n"),READ_REGISTER_ULONG((PULONG)&pSlot->pSD->enable)));
    RETAILMSG(1,(TEXT("SD_CONFIG2 = 0x%08X\r\n"),READ_REGISTER_ULONG((PULONG)&pSlot->pSD->config2)));
    RETAILMSG(1,(TEXT("SD_BLKSIZE = 0x%08X\r\n"),READ_REGISTER_ULONG((PULONG)&pSlot->pSD->blksize)));
    RETAILMSG(1,(TEXT("SD_STATUS = 0x%08X\r\n"),READ_REGISTER_ULONG((PULONG)&pSlot->pSD->status)));
    RETAILMSG(1,(TEXT("SD_DEBUG = 0x%08X\r\n"),READ_REGISTER_ULONG((PULONG)&pSlot->pSD->debug)));
    RETAILMSG(1,(TEXT("SD_CMD = 0x%08X\r\n"),READ_REGISTER_ULONG((PULONG)&pSlot->pSD->cmd)));
    RETAILMSG(1,(TEXT("SD_CMDARG = 0x%08X\r\n"),READ_REGISTER_ULONG((PULONG)&pSlot->pSD->cmdarg)));
    RETAILMSG(1,(TEXT("SD_TIMEOUT = 0x%08X\r\n"),READ_REGISTER_ULONG((PULONG)&pSlot->pSD->timeout)));

    if (NULL!=pSlot->pCurrentRequest) {
        RETAILMSG(1, (TEXT("pCurrentRequest->CommandCode = %d\r\n"),pSlot->pCurrentRequest->CommandCode));
        RETAILMSG(1, (TEXT("pCurrentRequest->NumBlocks = %d\r\n"),pSlot->pCurrentRequest->NumBlocks));
        RETAILMSG(1, (TEXT("pCurrentRequest->BlockSize = %d\r\n"),pSlot->pCurrentRequest->BlockSize));
        RETAILMSG(1, (TEXT("pCurrentRequest->HCParam = %d\r\n"),pSlot->pCurrentRequest->HCParam));
    }

    RETAILMSG(1,(TEXT("InterruptMask = 0x%08X\r\n"),pSlot->InterruptMask));
    RETAILMSG(1,(TEXT("CardPresent   = %d\r\n"),pSlot->CardPresent));
    RETAILMSG(1,(TEXT("CheckSlotOnStartUp = %d\r\n"),pSlot->CheckSlotOnStartUp));
    RETAILMSG(1,(TEXT("CardInitialised = %d\r\n"),pSlot->CardInitialised));
}

///////////////////////////////////////////////////////////////////////////////
//  DumpController - dump the states of the controller
//  Input:  pController -   controller context
//  Output:
//  Return:
///////////////////////////////////////////////////////////////////////////////
VOID DumpController( PSDIO_HW_CONTEXT pController )
{
	int i;

	for (i=0;i<SDIOPlatNumSlots();i++) {
		DumpSlot(&pController->Slots[i]);
	}
}

///////////////////////////////////////////////////////////////////////////////
//  SDIOClockOff - turn off the SD clock
//  Input:  pSlot -   slot context
//  Output:
//  Return:
//  Notes:  Currently simply leave the clock along for now.
///////////////////////////////////////////////////////////////////////////////
VOID SDIOClockOff(PSDIO_SLOT pSlot)
{
	ULONG tmp;

	    // turn off the clock
	tmp = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->enable);
	tmp &= ~SD_ENABLE_CE;
//	WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->enable,tmp);

    DEBUGMSG(SDIO_CLOCK_ZONE, (TEXT("SDIOClockOff - Clock is now off \r\n")));
}

///////////////////////////////////////////////////////////////////////////////
//  SDIOClockOn - turn on the MMC Clock
//  Input:  pSlot -   slot context
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
VOID SDIOClockOn(PSDIO_SLOT pSlot)
{
	ULONG tmp;

	    // turn on the clock
	tmp = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->enable);
	tmp |= SD_ENABLE_CE;
//	WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->enable,tmp);

    DEBUGMSG(SDIO_CLOCK_ZONE, (TEXT("SDIOClockOn  - Clock is now on \r\n")));
}

///////////////////////////////////////////////////////////////////////////////
//  SDIOSetRate - sets rate of SD Clock
//  Input:  pSlot -   slot context
//          pRate - desired clock rate in Hz
//  Output: pRate - the clock rate now in use
//  Return:
//  Notes:  Divisor could easily be calculated
///////////////////////////////////////////////////////////////////////////////
VOID SDIOSetRate(PSDIO_SLOT pSlot, PDWORD pRate)
{
	ULONG pbus;
	ULONG div;
	ULONG regValue;
	ULONG RateAttempted;

	if (*pRate > SDIO_MAX_CLOCK_RATE) *pRate = SDIO_MAX_CLOCK_RATE;
	if (*pRate < 1) *pRate = 1; // Just to make sure we don't have a div/0
		// Keep track of the rate we are trying 
		// to set.
	RateAttempted = *pRate;

	pbus = GetPBUSSpeed();
	div = pbus / (2 * (*pRate));
		// We need to subtract 1 to get the correct
		// div, but in some cases the above calculation
		// could return 0, like if pbus is 99Mhz and 50Mhz
		// is requested.  99 / 100 = .99 which result
		// in 0.
	if (div > 1) div = div -1;

	if (div > SDIO_MAX_DIV_VALUE) div = SDIO_MAX_DIV_VALUE;

		// return the actual frequency
	*pRate = pbus / (2 * (div + 1));

		// Never set the rate higher than requested, unless
	    // we can't set it any slower.
	if ((*pRate > RateAttempted) && (div < SDIO_MAX_DIV_VALUE))
	{
		div++;
		*pRate = pbus / (2 * (div + 1));
	}

		// update the divisor setting
	regValue = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->config );
        // clear old divisor
	regValue &= ~SD_CONFIG_DIV;
        // set new divisot
	regValue |= div;
	regValue |= SD_CONFIG_DE;
        // write new value back
	WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->config, regValue );
}

#ifdef USE_DMA
#if defined(DUMP_DMABUF)
VOID DumpDMABuffer( PVOID *Address, UINT32 Len )
{
    unsigned long  i, j, k;
    unsigned long Addr;

    Addr = (ULONG)Address;
    k=0;

    RETAILMSG(1,(TEXT("\r\nDMABuffer base:%X, Size %d"), Address, Len));

   	for (i=0;i<Len;i+=16) {
        RETAILMSG(1,(TEXT("\r\n%04X:"), k));
        for (j=Addr;j < (Addr + 16) ;j++) {
            if (j < (Len + (ULONG)Address)) {
                RETAILMSG(1,(TEXT("%02X "), *(PUCHAR)(j)));
                k++;
            }
        }

        Addr +=16;
    }
    RETAILMSG(1,(TEXT("\r\n")));
}
#endif

///////////////////////////////////////////////////////////////////////////////
//  CopyFromDmaBuffer - Copy data from a DMA buffer into a requests data buffer
//  Input:  pRequest   - the request that this data belongs to
//          pDmaBuffer - which buffer to copy from
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
VOID CopyFromDmaBuffer(PSD_BUS_REQUEST pRequest,
                       PULONG          pDmaBuffer)
{
	ULONG blocksToCopy;
	ULONG blocksRemaining;

	blocksRemaining = pRequest->NumBlocks - ((PHC_PARAMS)pRequest->HCParam)->BlocksCopied;

	if (blocksRemaining > (DMA_BUFFER_SIZE / pRequest->BlockSize)) {
		blocksToCopy = (DMA_BUFFER_SIZE / pRequest->BlockSize);
	} else {
		blocksToCopy = blocksRemaining;
	}

        // we are touching the block buffer, set the process permissions
    SD_SET_PROC_PERMISSIONS_FROM_REQUEST(pRequest) {
            // safe copy data into block buffer
        SDPerformSafeCopy(pRequest->pBlockBuffer+(((PHC_PARAMS)pRequest->HCParam)->BlocksCopied*pRequest->BlockSize),
                          pDmaBuffer,
                          pRequest->BlockSize * blocksToCopy);
    } SD_RESTORE_PROC_PERMISSIONS();

#if defined(DUMP_DMABUF)
	DumpDMABuffer((PVOID)pDmaBuffer, pRequest->BlockSize * blocksToCopy);
#endif
	((PHC_PARAMS)pRequest->HCParam)->BlocksCopied += blocksToCopy;
	((PHC_PARAMS)pRequest->HCParam)->BuffersOutstanding--;
}

///////////////////////////////////////////////////////////////////////////////
//  CopyToDmaBuffer - Copy data to a DMA buffer from a requests data buffer
//  Input:  pRequest   - the request that this data belongs to
//          pDmaBuffer - which buffer to copy to
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
ULONG CopyToDmaBuffer(PSD_BUS_REQUEST pRequest,
                      PULONG          pDmaBuffer)
{
	ULONG blocksToCopy;
	ULONG blocksRemaining;

	blocksRemaining = pRequest->NumBlocks - ((PHC_PARAMS)pRequest->HCParam)->BlocksCopied;

	if (blocksRemaining > (DMA_BUFFER_SIZE / pRequest->BlockSize)) {
		blocksToCopy = (DMA_BUFFER_SIZE / pRequest->BlockSize);
	} else {
		blocksToCopy = blocksRemaining;
	}

        // we are touching the block buffer, set the process permissions
    SD_SET_PROC_PERMISSIONS_FROM_REQUEST(pRequest) {
            // safe copy data into block buffer
        SDPerformSafeCopy(pDmaBuffer,
                          pRequest->pBlockBuffer+(((PHC_PARAMS)pRequest->HCParam)->BlocksCopied*pRequest->BlockSize),
                          pRequest->BlockSize * blocksToCopy);
    } SD_RESTORE_PROC_PERMISSIONS();

	((PHC_PARAMS)pRequest->HCParam)->BlocksCopied += blocksToCopy;

	// Incrementing count of outstanding blocks
	// IST will decrement this when a block has been transmitted
	((PHC_PARAMS)pRequest->HCParam)->BuffersOutstanding++;

	return (blocksToCopy*pRequest->BlockSize);
}

///////////////////////////////////////////////////////////////////////////////
//  SDIOInitializeDMA - Initialize DMA resources for an SD slot
//  Input:  pSlot        - slot context
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
BOOL SDIOInitializeDMA(PSDIO_SLOT pSlot)
{
    ULONG hwIntr;
    DWORD threadID;                         // thread ID

	// Allocate Tx DMA Channel
	pSlot->TxDmaChannel = HalAllocateDMAChannel();

	if (pSlot->TxDmaChannel==NULL) {
        DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO[%d]: Can't allocate Tx DMA Channel\r\r\n"),
                   pSlot->SlotNumber));
		goto ErrorReturn;
	}

	// Allocate Rx DMA Channel
	pSlot->RxDmaChannel = HalAllocateDMAChannel();

	if (pSlot->RxDmaChannel==NULL) {
        DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO[%d]: Can't allocate Rx DMA Channel\r\n"),
                   pSlot->SlotNumber));
		goto ErrorReturn;
	}

    pSlot->UsingDma = TRUE;

	// Initialize channels
	HalInitDmaChannel(pSlot->TxDmaChannel,
	                  AuSdConfig[pSlot->SlotNumber].TxDmaDeviceId,
	                  pSlot->DmaBufferSize,
					  TRUE);

	// Initialize channels
	HalInitDmaChannel(pSlot->RxDmaChannel,
	                  AuSdConfig[pSlot->SlotNumber].RxDmaDeviceId,
	                  pSlot->DmaBufferSize,
					  TRUE);

	HalSetDMAForReceive(pSlot->RxDmaChannel);

	// set up DMA interrupt
	hwIntr = HalGetDMAHwIntr(pSlot->TxDmaChannel);
	hwIntr |= (HalGetDMAHwIntr(pSlot->RxDmaChannel) << 8);

	DEBUGMSG(SDIO_DMA_ZONE,(TEXT("SDIO Hooking HWINTR %08X\r\n"),hwIntr));

    pSlot->DmaSysIntr = InterruptConnect(Internal, 0, hwIntr, 0);

    if (SYSINTR_NOP==pSlot->DmaSysIntr) {
        DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO[%d]: Can't allocate DMA SYSINTR\r\n"),
                   pSlot->SlotNumber));
        goto ErrorReturn;
    }

	DEBUGMSG(SDIO_DMA_ZONE,(TEXT("DmaSysIntr = %X\r\n"),pSlot->DmaSysIntr));

        // allocate the dma interrupt event
    pSlot->hDmaInterruptEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

    if (NULL == pSlot->hDmaInterruptEvent) {
        DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO[%d]: Can't create DMA interrupt event\r\n"),
                   pSlot->SlotNumber));
        goto ErrorReturn;
    }

    if (!InterruptInitialize(pSlot->DmaSysIntr,
                             pSlot->hDmaInterruptEvent,
                             NULL,
                             0)) {
        DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO[%d]: Call to InterruptInitialize failed\r\n"),
                   pSlot->SlotNumber));
    }

    pSlot->DmaIstThreadPriority = SDIO_CARD_CONTROLLER_IST_PRIORITY;

        // create the interrupt thread for controller interrupts
    pSlot->hDmaInterruptThread = CreateThread(NULL,
                                              0,
                                              (LPTHREAD_START_ROUTINE)SDIODmaIstThread,
                                              pSlot,
                                              0,
                                              &threadID);

    if (NULL == pSlot->hDmaInterruptThread) {
        DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO[%d]: Can't create DMA interrupt thread\r\n"),
                   pSlot->SlotNumber));
        goto ErrorReturn;
    }

    return TRUE;

        // post error clean-up from here on...
ErrorReturn:
    SDIODeinitializeDMA(pSlot);

    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////
//  SDIODeinitializeDMA - De-Initialize the DMA channel
//  Input:  pSlot - slot context
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
VOID SDIODeinitializeDMA(PSDIO_SLOT pSlot)
{
    InterruptDisable(pSlot->DmaSysIntr);

        // free the Tx Channel
    if (NULL!=pSlot->TxDmaChannel) {
        HalFreeDMAChannel(pSlot->TxDmaChannel);
        pSlot->TxDmaChannel = NULL;
    }

        // free the Rx Channel
    if (NULL!=pSlot->RxDmaChannel) {
        HalFreeDMAChannel(pSlot->RxDmaChannel);
        pSlot->RxDmaChannel = NULL;
    }

        // clean up DMA IST
    if (NULL != pSlot->hDmaInterruptThread) {
            // wake up the IST
        SetEvent(pSlot->hDmaInterruptEvent);
            // wait for the thread to exit
        WaitForSingleObject(pSlot->hDmaInterruptThread, INFINITE);
        CloseHandle(pSlot->hDmaInterruptThread);
        pSlot->hDmaInterruptThread = NULL;
    }

        // free DMA interrupt event
    if (NULL != pSlot->hDmaInterruptEvent) {
        CloseHandle(pSlot->hDmaInterruptEvent);
        pSlot->hDmaInterruptEvent = NULL;
    }
}

#endif // #ifdef USE_DMA

///////////////////////////////////////////////////////////////////////////////
//  SendStopTransmission - sends a CMD12 to terminate a write transaction
//  Input:  pSlot -   slot context
//  Output:
//  Return:
//  Notes:  This needs to be called in the event of a CRC failure during a
//          multiblock write. The Bus Driver will resend the write request
//          but the controller state machine needs to receive a CMD12 to
//          get it out of the data write state.
///////////////////////////////////////////////////////////////////////////////
VOID SendStopTransmission(PSDIO_SLOT pSlot)
{
	ULONG tmp;

        // check that data busy is active
    if (!(READ_REGISTER_ULONG((PULONG)&pSlot->pSD->status)&SD_STATUS_DB)) {
        return;
    }

    SD_INTERRUPTS_DISABLE(pSlot,SD_Int_Response_Done );

        // disable clock freezing
	tmp = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->config2);
	tmp |= SD_CONFIG2_DF;
	WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->config2,tmp);
        // write stop transmission command
    WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->cmd, 0x00810C71);
        // wait for response ready
    while(!(READ_REGISTER_ULONG((PULONG)&pSlot->pSD->cmd)&SD_CMD_RY)) {};
        // read response registers
    (void) READ_REGISTER_ULONG((PULONG)&pSlot->pSD->resp0);
    (void) READ_REGISTER_ULONG((PULONG)&pSlot->pSD->resp1);
    (void) READ_REGISTER_ULONG((PULONG)&pSlot->pSD->resp2);
    (void) READ_REGISTER_ULONG((PULONG)&pSlot->pSD->resp3);
}

///////////////////////////////////////////////////////////////////////////////
//  CompleteRequest - complete a bus reqeust
//  Input:  pSlot -   slot context
//          CompletionStatus - status of completing request
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
VOID CompleteRequest(PSDIO_SLOT    pSlot,
                     SD_API_STATUS CompletionStatus)
{
    PSD_BUS_REQUEST pRequest;   // the completed request

    pRequest = pSlot->pCurrentRequest;

    if (NULL==pRequest) {
        return;
    }

    pSlot->pCurrentRequest = NULL;
            // turn the clock off
    SDIOClockOff(pSlot);
        // complete the request
    SDHCDIndicateBusRequestComplete(pSlot->pController->pHCContext,
                                    pRequest,
                                    CompletionStatus);
}

///////////////////////////////////////////////////////////////////////////////
//  SDIOInitializeSlot - Initialize SD slot
//  Input:  pSlot - slot context
//  Output:
//  Return: SD_API_STATUS
//  Notes:
///////////////////////////////////////////////////////////////////////////////
SD_API_STATUS SDIOInitializeSlot(PSDIO_SLOT pSlot)
{
    SD_API_STATUS status = SD_API_STATUS_SUCCESS;   // intermediate status
    DWORD         threadID;                         // thread ID
	PHYSICAL_ADDRESS PhysAddr;

	DEBUGMSG(SDCARD_ZONE_INIT,(TEXT("SDIOInitializeSlot:: Slot:0x%x\r\n"), pSlot->SlotNumber ));

	// Save removeable flag for later use
	pSlot->Removeable = AuSdConfig[pSlot->SlotNumber].bRemoveable;

		// enable slot power
	SDIOPlatPower(pSlot->pController,
	              TRUE,
				  pSlot->SlotNumber);

	if ( pSlot->Removeable )
	{
	        // allocate the interrupt event for the slot
	    pSlot->hInsertionInterruptEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

	    if (NULL == pSlot->hInsertionInterruptEvent) {
	        status = SD_API_STATUS_INSUFFICIENT_RESOURCES;
	        goto exitInit;
	    }

	        // initialize the interrupt event for the slot
	    if (!InterruptInitialize (pSlot->InsertionSysIntr,
	                              pSlot->hInsertionInterruptEvent,
	                              NULL,
	                              0)) {
	        status = SD_API_STATUS_INSUFFICIENT_RESOURCES;
	        goto exitInit;
	    }

	    pSlot->InsertionIstThreadPriority = SDIO_CARD_CONTROLLER_IST_PRIORITY;

	        // create the interrupt thread for insertion interrupts
	    pSlot->hInsertionInterruptThread = CreateThread(NULL,
	                                                      0,
	                                                      (LPTHREAD_START_ROUTINE)SDIOInsertionIstThread,
	                                                      pSlot,
	                                                      0,
	                                                      &threadID);

	    if (NULL == pSlot->hInsertionInterruptThread) {
	        status = SD_API_STATUS_INSUFFICIENT_RESOURCES;
	        goto exitInit;
	    }
	}

	PhysAddr.HighPart = 0;
	PhysAddr.LowPart = AuSdConfig[pSlot->SlotNumber].SDPhysAddr;

        // map the controller registers
    pSlot->pSD = MmMapIoSpace(PhysAddr,
                              sizeof(*pSlot->pSD),
                              FALSE);

    if (NULL == pSlot->pSD) {
        DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIOInitialize - failed to map registers\r\n")));
        status = SD_API_STATUS_INSUFFICIENT_RESOURCES;
        goto exitInit;
    }

#ifdef USE_DMA
       // do the dma...
    if (pSlot->UsingDma) {
        pSlot->DmaBufferSize = DMA_BUFFER_SIZE;
        if (!SDIOInitializeDMA(pSlot)) {
			pSlot->UsingDma = FALSE;
		}
    }
#endif

	if ( pSlot->Removeable )
	{
	    // set the slot to its initial SW state
	    pSlot->CardPresent = FALSE;
	    pSlot->pCurrentRequest = NULL;
	}

    // reset the slot to its initial state
	ResetSlot(pSlot, TRUE);

exitInit:
	return status;
}

///////////////////////////////////////////////////////////////////////////////
//  SDIODeInitializeSlot - De-Initialize SD slot
//  Input:  pSlot - slot context
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
VOID SDIODeinitializeSlot(PSDIO_SLOT pSlot)
{
    InterruptDisable(pSlot->InsertionSysIntr);

        // check for cards in slots
    if (pSlot->CardPresent) {
        pSlot->CardPresent = FALSE;
            // handle remove device
        RemoveDevice(pSlot);
     }

        // clean up insertion IST
    if (NULL != pSlot->hInsertionInterruptThread) {
            // wake up the IST
        SetEvent(pSlot->hInsertionInterruptEvent);
            // wait for the thread to exit
        WaitForSingleObject(pSlot->hInsertionInterruptThread, INFINITE);
        CloseHandle(pSlot->hInsertionInterruptThread);
        pSlot->hInsertionInterruptThread = NULL;
    }

        // free insertion interrupt event
    if (NULL != pSlot->hInsertionInterruptEvent) {
        CloseHandle(pSlot->hInsertionInterruptEvent);
        pSlot->hInsertionInterruptEvent = NULL;
    }

        // unmap registers
    if (NULL != pSlot->pSD) {
        MmUnmapIoSpace((PVOID)pSlot->pSD, SD_CONTROL_REGISTERS_LENGTH);
        pSlot->pSD = NULL;
    }

#ifdef USE_DMA
        // deinitialize DMA stuff
    if (pSlot->UsingDma) {
        SDIODeinitializeDMA(pSlot);
    }
#endif
}

///////////////////////////////////////////////////////////////////////////////
//  SDIOInitialize - Initialize the controller
//  Input:  pHCContext -  host controller context
//  Output:
//  Return: SD_API_STATUS
//  Notes:
///////////////////////////////////////////////////////////////////////////////
SD_API_STATUS SDIOInitialize(PSDCARD_HC_CONTEXT pHCContext)
{
    SD_API_STATUS status = SD_API_STATUS_SUCCESS;   // intermediate status
    DWORD         threadID;                         // thread ID
    PSDIO_HW_CONTEXT pController;                   // hardware instance
	int           i;

    pController = GetExtensionFromHCDContext(PSDIO_HW_CONTEXT, pHCContext);

    pController->DriverShutdown = FALSE;

	for(i=0;i<SDIO_NUM_SLOTS;i++)
	{
	    pController->Slots[i].pController = pController;
	    pController->Slots[i].SlotNumber = i;
	}

    // initialize the critical section
    InitializeCriticalSection(&(pController->CriticalSection));

#ifndef SOC_AU13XX
        // initialize the GPIO driver
    pController->hGPIO = GPIO_Init();
#else
	pController->hGPIO = NULL;
#endif

    if (INVALID_HANDLE_VALUE == pController->hGPIO) {
        DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO: Unable to opne GPIO device\r\n")));
        status = SD_API_STATUS_INSUFFICIENT_RESOURCES;
        goto exitInit;
    }

	status = SDIOPlatInit(pController);

	if (SD_API_STATUS_SUCCESS != status) {
		goto exitInit;
	}

        // allocate the controller interrupt event
    pController->hControllerInterruptEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

    if (NULL == pController->hControllerInterruptEvent) {
        status = SD_API_STATUS_INSUFFICIENT_RESOURCES;
        goto exitInit;
    }

        // initialize the controller interrupt event
    if (!InterruptInitialize (pController->SysIntr,
                              pController->hControllerInterruptEvent,
                              NULL,
                              0)) {
        status = SD_API_STATUS_INSUFFICIENT_RESOURCES;
        goto exitInit;
    }

    pController->ControllerIstThreadPriority = SDIO_CARD_CONTROLLER_IST_PRIORITY;

        // create the interrupt thread for controller interrupts
    pController->hControllerInterruptThread = CreateThread(NULL,
                                                      0,
                                                      (LPTHREAD_START_ROUTINE)SDIOControllerIstThread,
                                                      pController,
                                                      0,
                                                      &threadID);

    if (NULL == pController->hControllerInterruptThread) {
        status = SD_API_STATUS_INSUFFICIENT_RESOURCES;
        goto exitInit;
    }

		// initialize the slots
	for (i=0;i<SDIOPlatNumSlots();i++) {
		status = SDIOInitializeSlot(&pController->Slots[i]);
		if (SD_API_STATUS_SUCCESS != status) {
			goto exitInit;
		}
	}

    pController->Initialized = TRUE;

        // wake up the interrupt thread to check the slot
    SetEvent(pController->hControllerInterruptEvent);

		// initialize the slots
	for (i=0;i<SDIOPlatNumSlots();i++) {
		// Force insertion event for non-removeable slots
		if (!pController->Slots[i].Removeable)
		{
		    DWORD initRate = 200000;
			// set clock to 100 kHz for card initialisation
			SDIOSetRate(&pController->Slots[i], &initRate);

			pController->Slots[i].CardPresent = TRUE;
			pController->Slots[i].CardInitialised = FALSE;

			// indicate device arrival
			SDHCDIndicateSlotStateChange(pController->Slots[i].pController->pHCContext,
			                         pController->Slots[i].SlotNumber,
			                         DeviceInserted );
		}
		else
			SetEvent(pController->Slots[i].hInsertionInterruptEvent);
	}

exitInit:

    if (!SD_API_SUCCESS(status)) {
            // just call the deinit handler directly to cleanup
        SDIODeinitialize(pHCContext);
    }

    return status;

}

///////////////////////////////////////////////////////////////////////////////
//  SDIODeInitialize - De-Initialize the SDIO Controller
//  Input:  pHCContext - HC context
//  Output:
//  Return: SD_API_STATUS
//  Notes:
///////////////////////////////////////////////////////////////////////////////
SD_API_STATUS SDIODeinitialize(PSDCARD_HC_CONTEXT pHCContext)
{
    PSDIO_HW_CONTEXT pController;    // the controller
	int i;

    pController = GetExtensionFromHCDContext(PSDIO_HW_CONTEXT, pHCContext);

#ifdef DEBUG
    DumpController(pController);
#endif
        // mark for shutdown
        // this will cause all IST to terminate when signalled
    pController->DriverShutdown = TRUE;

    if (pController->Initialized) {
            // disable interrupts
        InterruptDisable(pController->SysIntr);

            // clean up controller IST
        if (NULL != pController->hControllerInterruptThread) {
                // wake up the IST
            SetEvent(pController->hControllerInterruptEvent);
                // wait for the thread to exit
            WaitForSingleObject(pController->hControllerInterruptThread, INFINITE);
            CloseHandle(pController->hControllerInterruptThread);
            pController->hControllerInterruptThread = NULL;
        }

            // free controller interrupt event
        if (NULL != pController->hControllerInterruptEvent) {
            CloseHandle(pController->hControllerInterruptEvent);
            pController->hControllerInterruptEvent = NULL;
        }

            // close GPIO handle
        CloseHandle(pController->hGPIO);

            // delete the critical sections
        DeleteCriticalSection(&(pController->CriticalSection));

		SDIOPlatDeinit(pController);

            // deinitialize each slot
        for (i=0;i<SDIOPlatNumSlots();i++) {
			SDIODeinitializeSlot(&pController->Slots[i]);
		}
    }

    return SD_API_STATUS_SUCCESS;
}

///////////////////////////////////////////////////////////////////////////////
//  SDIOBusRequestHandler - bus request handler
//  Input:  pHostContext - host controller context
//          Slot - slot the request is going on
//          pRequest - the request
//  Output:
//  Return: SD_API_STATUS
//  Notes:  The request passed in is marked as uncancelable, this function
//          has the option of making the outstanding request cancelable
//          returns status pending if request submitted successfully
///////////////////////////////////////////////////////////////////////////////
SD_API_STATUS SDIOBusRequestHandler(PSDCARD_HC_CONTEXT pHCContext, DWORD Slot, PSD_BUS_REQUEST pRequest) {

    PSDIO_HW_CONTEXT pController;            // the controller
    PSDIO_SLOT       pSlot;                  // the slot
    ULONG            commandRegister;        // SD_CMD register control value
    ULONG            blkSizeRegister;        // SD_BLKSIZE register value
    BOOL             IOAbort = FALSE;        // request is an IO Abort
    static BOOL lastCmd53 = FALSE;
	ULONG            tmp;

        // check slot number is in range
    if (Slot >= (DWORD)SDIOPlatNumSlots()) {
        DEBUGMSG(SDCARD_ZONE_ERROR, (TEXT("SDIOSDSendHandler - Slot %d outside valid range 0-%d\r\n"),
                   Slot,
                   SDIOPlatNumSlots()));
        return SD_API_STATUS_INVALID_PARAMETER;
    }

	// For eMMC devices we always want bits 31:30 set to indicate device ready
	if ( (AuSdConfig[Slot].DeviceType == EMMC) &&
	     (pRequest->CommandCode == SD_CMD_MMC_SEND_OPCOND) )
	{
		pRequest->CommandArgument |= 0xC0000000;
	}
	DEBUGMSG(SDIO_SEND_ZONE,(TEXT("SDIOBusRequestHandler: Sending CMD%d (%d blocks) Size %d Arg=%08X Read=%d\r\n"),pRequest->CommandCode,pRequest->NumBlocks,pRequest->BlockSize,pRequest->CommandArgument,TRANSFER_IS_READ(pRequest)));

        // get our extension
    pController = GetExtensionFromHCDContext(PSDIO_HW_CONTEXT, pHCContext);
        // get pointer to slot context
    pSlot = &pController->Slots[Slot];
    pSlot->pCurrentRequest = pRequest;
        // set block/byte count to zero
	pRequest->HCParam = (DWORD)&HCParams[pSlot->SlotNumber];

	HCParams[pSlot->SlotNumber].BytesCopied = 0;
	HCParams[pSlot->SlotNumber].BlocksCopied = 0;
	HCParams[pSlot->SlotNumber].BuffersOutstanding = 0;

        // initialize command register with command code
    commandRegister = SD_CMD_CI_N(pRequest->CommandCode);
        // set GO bit
    commandRegister |= SD_CMD_GO;

        // setup for response type
    switch (pRequest->CommandResponse.ResponseType) {
        case NoResponse:  commandRegister |= SD_CMD_RT_NONE; break;
        case ResponseR1:  commandRegister |= SD_CMD_RT_R1;   break;
        case ResponseR1b: commandRegister |= SD_CMD_RT_R1b;  break;
        case ResponseR2:  commandRegister |= SD_CMD_RT_R2;   break;
        case ResponseR3:  commandRegister |= SD_CMD_RT_R3;   break;
        case ResponseR4:  commandRegister |= SD_CMD_RT_R4;   break;
        case ResponseR5:  commandRegister |= SD_CMD_RT_R5;   break;
        case ResponseR6:  commandRegister |= SD_CMD_RT_R6;   break;
        case ResponseR7:  commandRegister |= SD_CMD_RT_R1;   break;
        default: return SD_API_STATUS_INVALID_PARAMETER;
    }

		// set the command type field of the command register
	if (TRANSFER_HAS_DATA_PHASE(pRequest)) {
            // check for various flavours of IO_RW_EXTENDED
		if (SD_CMD_IO_RW_EXTENDED == pRequest->CommandCode) {
                // are we in block mode ?
            if (IO_RW_EXTENDED_BLOCK_MODE(pRequest->CommandArgument)) {
                    // is the block count infinite ?
                if (0 == IO_RW_EXTENDED_COUNT(pRequest->CommandArgument)) {
                    if (TRANSFER_IS_READ(pRequest)) {
                        commandRegister |= SD_CMD_CT_MBR;
                    } else {
                        commandRegister |= SD_CMD_CT_MBW;
                    }
                } else {
			        if (TRANSFER_IS_READ(pRequest)) {
				        commandRegister |= SD_CMD_CT_MBIOR;
			        } else {
				        commandRegister |= SD_CMD_CT_MBIOW;
			        }
                }
            } else {
                if (TRANSFER_IS_READ(pRequest)) {
                    commandRegister |= SD_CMD_CT_SBR;
                } else {
                    commandRegister |= SD_CMD_CT_SBW;
                }
            }
        } else {
            if (TRANSFER_IS_READ(pRequest)) {
                if (SD_CMD_READ_MULTIPLE_BLOCK == pRequest->CommandCode) {
                    commandRegister |= SD_CMD_CT_MBR;
                } else {
                    commandRegister |= SD_CMD_CT_SBR;
                }
            } else {
                if (SD_CMD_WRITE_MULTIPLE_BLOCK == pRequest->CommandCode) {
                    commandRegister |= SD_CMD_CT_MBW;
                } else {
                    commandRegister |= SD_CMD_CT_SBW;
                }
            }
		}
	    // check for Stop Transmission command
    } else if (SD_CMD_STOP_TRANSMISSION == pRequest->CommandCode) {
            // set for CMD12 stop transmission
        commandRegister |= SD_CMD_CT_TERM;
        // check for an IO Abort
    } else if ((SD_CMD_IO_RW_DIRECT == pRequest->CommandCode) &&
               (SD_IO_REG_IO_ABORT == IO_RW_DIRECT_ADDR_ARG(pRequest->CommandArgument))) {
        commandRegister |= SD_CMD_CT_TERMIO;
        IOAbort = TRUE;
    }

    if (!pSlot->CardInitialised) {
            // Send at least 80 clocks to the card before 1st command is sent
        Sleep(2);
        pSlot->CardInitialised = TRUE;
    }

        // wait for data busy bit to be clear, unless this
        // is a STOP TRANSMISSION or IO ABORT
    if (SD_CMD_STOP_TRANSMISSION != pRequest->CommandCode && !IOAbort) {
           // if the previous command is command 53 and the data busy bit is on,
	       // there is a chance that the clock may be frozen.  Set DF to 1 to get
           // the clock back.
		if (lastCmd53 && (READ_REGISTER_ULONG((PULONG)&pSlot->pSD->status) & SD_STATUS_DB )) {
			tmp = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->config2);
			tmp |= SD_CONFIG2_DF;
			WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->config2, tmp);
		}

        while( READ_REGISTER_ULONG((PULONG)&pSlot->pSD->status) & SD_STATUS_DB) {
            ; // do nothing
        }
    }

		// handle setting for data transfers
	if (TRANSFER_HAS_DATA_PHASE(pRequest)) {

		   // Ensure the block count & block size are both within the range.
		if (pRequest->NumBlocks > SD_MAX_BLOCK_COUNT ||
			pRequest->BlockSize > SD_MAX_BLOCK_SIZE) {
			return SD_API_STATUS_INVALID_PARAMETER;
		}

            // Set block size and count
        blkSizeRegister =  SD_BLKSIZE_BC_N(pRequest->NumBlocks);	// Macro does -1 for us
        blkSizeRegister |= SD_BLKSIZE_BS_N(pRequest->BlockSize);	// Macro does -1 for us
        WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->blksize, blkSizeRegister);

            // enable clock freezing
		tmp = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->config2);
		tmp &= ~SD_CONFIG2_DF;
		tmp |= SD_CONFIG2_FF;
		WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->config2, tmp);
    }

	// work out if we want to fall back to PIO rather than DMA
	// right now we can only handle DMA for transfer that are a multiple
	// of four bytes
	if (pSlot->UsingDma) {
#if defined(SD_FIFO_32BITS)
		if ( TRANSFER_HAS_DATA_PHASE(pRequest) && (pRequest->BlockSize & (DMA_MIN_XFER-1) )) {
#else
		if ( TRANSFER_HAS_DATA_PHASE(pRequest) && (pRequest->BlockSize & 0x3)) {
#endif
			pSlot->UsingDmaThisCmd = FALSE;
		} else {
			pSlot->UsingDmaThisCmd = TRUE;
		}
	} else {
		pSlot->UsingDmaThisCmd = FALSE;
	}

#ifdef USE_DMA
        // handle data phase transfer, we actually start the DMA
        // transfers in HandleResponseDone
    if (pSlot->UsingDmaThisCmd && TRANSFER_HAS_DATA_PHASE(pRequest)) {

        if (TRANSFER_IS_READ(pRequest)) {
			PULONG pDmaBuffer;
			ULONG  bufferSize;

			bufferSize = min((pRequest->NumBlocks*pRequest->BlockSize),pSlot->DmaBufferSize);

                // enable both buffers
			HalStopDMA(pSlot->RxDmaChannel);

			pDmaBuffer = HalGetNextDMABuffer(pSlot->RxDmaChannel);
			HalActivateDMABuffer(pSlot->RxDmaChannel,pDmaBuffer,bufferSize);

			pDmaBuffer = HalGetNextDMABuffer(pSlot->RxDmaChannel);
			HalActivateDMABuffer(pSlot->RxDmaChannel,pDmaBuffer,bufferSize);
        } else if (TRANSFER_IS_WRITE(pRequest)) {
			PULONG pDmaBuffer;
			ULONG  copySize;
			HalStopDMA(pSlot->TxDmaChannel);
                // fill next buffer
			pDmaBuffer = HalGetNextDMABuffer(pSlot->TxDmaChannel);
            copySize = CopyToDmaBuffer(pRequest,pDmaBuffer);
            HalActivateDMABuffer(pSlot->TxDmaChannel,pDmaBuffer,copySize);
                // fill other buffer if more than 1 block to write
            if (pRequest->NumBlocks > ((PHC_PARAMS)pRequest->HCParam)->BlocksCopied) {
				pDmaBuffer = HalGetNextDMABuffer(pSlot->TxDmaChannel);
				copySize = CopyToDmaBuffer(pRequest,pDmaBuffer);
				HalActivateDMABuffer(pSlot->TxDmaChannel,pDmaBuffer,copySize);
            }
        }
    }
#endif //#ifdef USE_DMA

        // turn on the clock
//    SDIOClockOn(pSlot);

    SD_INTERRUPTS_CLEAR(pSlot,SD_Int_CRC_Errors |
                              SD_Int_Response_Timeout |
                              SD_Int_Response_Done );

        // enable response done and response timeout interrupts
    SD_INTERRUPTS_ENABLE(pSlot, SD_Int_Response_Done | SD_Int_Response_Timeout );


        // for Stop Transmission and IO Abort disable clock freezing to
        // get the state machine running again to send command
	if ((SD_CMD_STOP_TRANSMISSION == pRequest->CommandCode) ||
        (SD_CMD_IO_RW_DIRECT == pRequest->CommandCode && SD_IO_REG_IO_ABORT == IO_RW_DIRECT_ADDR_ARG(pRequest->CommandArgument))) {
		tmp = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->config2);
		tmp |= SD_CONFIG2_DF;
		WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->config2, tmp);
    }

        // remember whether the last command is CMD53 or not.
    lastCmd53 = ( SD_CMD_IO_RW_EXTENDED == pRequest->CommandCode );

        // write the 32 bit command argument
    WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->cmdarg, pRequest->CommandArgument );
        // write the completed command register - this will issue the command
    WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->cmd, commandRegister );

    DEBUGMSG(SDIO_SEND_ZONE,(TEXT("Send Command - CMD register = 0x%08X\r\n"),commandRegister));

    return SD_API_STATUS_PENDING;
}

///////////////////////////////////////////////////////////////////////////////
//  SDIOSDCancelIoHandler - io cancel handler
//  Input:  pHostContext - host controller context
//          Slot - slot the request is going on
//          pRequest - the request to be cancelled
//  Output:
//  Return: TRUE if request cancelled
//  Notes:  the HC lock is taken before entering this cancel handler
///////////////////////////////////////////////////////////////////////////////
BOOLEAN SDIOCancelIoHandler(PSDCARD_HC_CONTEXT pHCContext, DWORD Slot, PSD_BUS_REQUEST pRequest)
{
    PSDIO_HW_CONTEXT    pController;     // the controller

        // for now, we should never get here because all requests are non-cancelable
        // the hardware supports timeouts so it is impossible for the controller to get stuck
    DEBUG_ASSERT(FALSE);

        // get our extension
    pController = GetExtensionFromHCDContext(PSDIO_HW_CONTEXT, pHCContext);

        // TODO --- Stop hardware, cancel the request!

        // release the lock before we complete the request
    SDHCDReleaseHCLock(pHCContext);

        // complete the request with a cancelled status
    SDHCDIndicateBusRequestComplete(pHCContext,
                                    pRequest,
                                    SD_API_STATUS_CANCELED);

    return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//  SDIOSlotOptionHandler - handler for slot option changes
//  Input:  pHostContext - host controller context
//          Slot         - the slot the change is being applied to
//          Option       - the option code
//          pData        - data associated with the option
//          OptionSize   - size of option data
//  Output:
//  Return: SD_API_STATUS
//  Notes:
///////////////////////////////////////////////////////////////////////////////
SD_API_STATUS SDIOSlotOptionHandler(PSDCARD_HC_CONTEXT    pHCContext,
                                    DWORD                 Slot,
                                    SD_SLOT_OPTION_CODE   Option,
                                    PVOID                 pData,
                                    ULONG                 OptionSize)
{
    SD_API_STATUS    status = SD_API_STATUS_SUCCESS; // status
    PSDIO_HW_CONTEXT pController;                    // the controller
	PSD_HOST_BLOCK_CAPABILITY  pBlockCaps;           // queried block capabilities
	ULONG tmp;

        // get our extension
    pController = GetExtensionFromHCDContext(PSDIO_HW_CONTEXT, pHCContext);

    switch (Option) {

        case SDHCDSetSlotPower:
                // can't set power so ignore this
            break;

        case SDHCDSetSlotInterface:
                // shut off clock first
            SDIOClockOff(&pController->Slots[Slot]);
            DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOSDSlotOptionHandler - called - SetSlotInterface : Clock Setting: %d \r\n"),
                                         ((PSD_CARD_INTERFACE)pData)->ClockRate));

            if (SD_INTERFACE_SD_MMC_1BIT == ((PSD_CARD_INTERFACE)pData)->InterfaceMode) {
                DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOSDSlotOptionHandler - called - SetSlotInterface : setting for 1 bit mode \r\n")));
				tmp = READ_REGISTER_ULONG((PULONG)&pController->Slots[Slot].pSD->config2);
				tmp &= ~SD_CONFIG2_WB;
				WRITE_REGISTER_ULONG((PULONG)&pController->Slots[Slot].pSD->config2,tmp);
            } else if (SD_INTERFACE_SD_4BIT == ((PSD_CARD_INTERFACE)pData)->InterfaceMode) {
				tmp = READ_REGISTER_ULONG((PULONG)&pController->Slots[Slot].pSD->config2);
				/* Force 8bit operations for eMMC devices on Slot0.
				 * Didn't want to modify PUBLIC/COMMON/xyz code to support
				 * 8bit capable slots, so I just hijacked it here
				 */
				if ( (AuSdConfig[Slot].DeviceType == EMMC) &&
					  (pController->Slots[Slot].MMC8BitBusSupport == TRUE) )
				{
	                DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOSDSlotOptionHandler - called - SetSlotInterface : setting for 8 bit mode \r\n")));
					tmp |= SD_CONFIG2_BB;
				} else {
	                DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOSDSlotOptionHandler - called - SetSlotInterface : setting for 4 bit mode \r\n")));
					tmp |= SD_CONFIG2_WB;
				}
				WRITE_REGISTER_ULONG((PULONG)&pController->Slots[Slot].pSD->config2,tmp);
            } else {
                DEBUG_ASSERT(FALSE);
            }
                // set rate
            SDIOSetRate(&pController->Slots[Slot], &((PSD_CARD_INTERFACE)pData)->ClockRate);
            break;

        case SDHCDEnableSDIOInterrupts:
                // enable SDIO interrupt detection
            DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOSDSlotOptionHandler - called - EnableSDIOInterrupts : on slot %d  \r\n"),Slot));
            SD_INTERRUPTS_ENABLE(&pController->Slots[Slot],SD_Int_SDIO_Interrupt);
            break;

        case SDHCDAckSDIOInterrupt:
                 // re-enable SDIO interrupt detection
            SD_INTERRUPTS_ENABLE(&pController->Slots[Slot],SD_Int_SDIO_Interrupt);
            break;

        case SDHCDDisableSDIOInterrupts:
                // disable SDIO interrupt detection
            DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOSDSlotOptionHandler - called - DisableSDIOInterrupts : on slot %d  \r\n"),Slot));
			SD_INTERRUPTS_DISABLE(&pController->Slots[Slot],SD_Int_SDIO_Interrupt);
            break;

        case SDHCDGetWriteProtectStatus:
				// get the write protect status
            DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOSDSlotOptionHandler - called - SDHCDGetWriteProtectStatus : on slot %d  \r\n"),Slot));
            if (SDIOPlatCardWriteProteced(pController,Slot)) {
                DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOSDSlotOptionHandler - Card is Write Protected\r\n")));
                ((PSD_CARD_INTERFACE)pData)->WriteProtected = TRUE;
            } else {
                DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOSDSlotOptionHandler - Card is NOT Write Protected\r\n")));
                ((PSD_CARD_INTERFACE)pData)->WriteProtected = FALSE;
            }
            break;

        case SDHCDQueryBlockCapability:
                // set the block capability
            DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOSDSlotOptionHandler - called - SDHCDQueryBlockCapability : on slot %d  \r\n"),Slot));
            pBlockCaps = (PSD_HOST_BLOCK_CAPABILITY)pData;

			DEBUGMSG(SDCARD_ZONE_INIT,
			(TEXT("SDIOSDSlotOptionHandler: Read Block Length: %d , Read Blocks: %d\r\n"),
				pBlockCaps->ReadBlockSize,
				pBlockCaps->ReadBlocks));
			DEBUGMSG(SDCARD_ZONE_INIT,
			(TEXT("SDIOSDSlotOptionHandler: Write Block Length: %d , Write Blocks: %d\r\n"),
				pBlockCaps->WriteBlockSize,
				pBlockCaps->WriteBlocks));

			// the Au1100 SD controller can only handle up to 2048 bytes for each block.
            if (pBlockCaps->ReadBlockSize > SD_MAX_BLOCK_SIZE) {

				RETAILMSG(1,
						(TEXT("SDIOSDSlotOptionHandler: Read Block Length: %d is out of the range!\r\n"),
						pBlockCaps->ReadBlockSize));
                pBlockCaps->ReadBlockSize = SD_MAX_BLOCK_SIZE;
            }
            if (pBlockCaps->WriteBlockSize > SD_MAX_BLOCK_SIZE) {

				RETAILMSG(1,
						(TEXT("SDIOSDSlotOptionHandler: Write Block Length: %d is out of the range!\r\n"),
						pBlockCaps->WriteBlockSize));
                pBlockCaps->WriteBlockSize = SD_MAX_BLOCK_SIZE;
            }

                // the Au1100 SD controller can only handle up to 511 blocks per transfer
            if (pBlockCaps->ReadBlocks > SD_MAX_BLOCK_COUNT ) {

				RETAILMSG(1,
						(TEXT("SDIOSDSlotOptionHandler: Read Block count: %d is out of the range!\r\n"),
						pBlockCaps->ReadBlocks));
                pBlockCaps->ReadBlocks = SD_MAX_BLOCK_COUNT;
            }
            if (pBlockCaps->WriteBlocks > SD_MAX_BLOCK_COUNT ) {

				RETAILMSG(1,
						(TEXT("SDIOSDSlotOptionHandler: Write Block count: %d is out of the range!\r\n"),
						pBlockCaps->WriteBlocks));
                pBlockCaps->WriteBlocks = SD_MAX_BLOCK_COUNT;
            }
            break;

		case SDHCDGetSlotInfo:
			{
				PSDCARD_HC_SLOT_INFO pSlotInfo = pData;
				ULONG tmp;

				// set the slot capabilities
				tmp = SD_SLOT_SD_4BIT_CAPABLE |
					  SD_SLOT_SD_1BIT_CAPABLE |
					  SD_SLOT_SDIO_CAPABLE    |
					  SD_SLOT_SDIO_INT_DETECT_4BIT_MULTI_BLOCK |
					  SD_SLOT_HIGH_SPEED_CAPABLE;

				if ( (AuSdConfig[Slot].DeviceType == EMMC) &&
					 (pController->Slots[Slot].MMC8BitBusSupport == TRUE) )
					tmp |= SD_SLOT_MMC_8BIT_CAPABLE;

				SDHCDSetSlotCapabilities(pSlotInfo, tmp);

					// set voltage window mask  +- 10%
//				SDHCDSetVoltageWindowMask(pSlotInfo, ( SD_VDD_WINDOW_3_1_TO_3_2 | SD_VDD_WINDOW_3_2_TO_3_3 | SD_VDD_WINDOW_3_3_TO_3_4));

				SDHCDSetVoltageWindowMask(pSlotInfo, 0x00FF8000 );

					// set optimal voltage
				SDHCDSetDesiredSlotVoltage(pSlotInfo, SD_VDD_WINDOW_3_2_TO_3_3 );
					// set max clock rate
#if defined(SOC_AU13XX)
				SDHCDSetMaxClockRate(pSlotInfo, 52000000);
					// set power up delay
				SDHCDSetPowerUpDelay(pSlotInfo, 2 );
#else
				SDHCDSetMaxClockRate(pSlotInfo, 25000000);
					// set power up delay
				SDHCDSetPowerUpDelay(pSlotInfo, 200 );
#endif
			}
			break;


        default:
           status = SD_API_STATUS_INVALID_PARAMETER;
    }

    return status;
}

///////////////////////////////////////////////////////////////////////////////
//  RemoveDevice - remove the device in the slot
//  Input:  pSlot - slot context
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
VOID RemoveDevice(PSDIO_SLOT pSlot)
{
    PSD_BUS_REQUEST pRequest; // request to cancel

        // indicate the slot change
    SDHCDIndicateSlotStateChange(pSlot->pController->pHCContext,
                                 pSlot->SlotNumber,
                                 DeviceEjected);

    DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("RemoveDevice: Card Removal Detected - \r\n")));

        // get the current request
    pRequest = pSlot->pCurrentRequest;

#ifdef DEBUG
    DumpSlot(pSlot);
#endif

    if (pRequest != NULL) {
        CompleteRequest(pSlot, SD_API_STATUS_DEVICE_REMOVED);
    }

    ResetSlot(pSlot, FALSE);
}

///////////////////////////////////////////////////////////////////////////////
//  HandleTransferErrors - Check for and handle transfer error conditions
//  Input:  pSlot        - slot context
//          pRequest     - the request
//  Output:
//  Return: TRUE if an error condition occurred and the request got completed
//  Notes:  If an error is detected the request will be completed.
///////////////////////////////////////////////////////////////////////////////
BOOL HandleTransferErrors(PSDIO_SLOT      pSlot,
                          PSD_BUS_REQUEST pRequest,
                          ULONG           CRCMask)
{
    ULONG status;

    status = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->status);
    SD_INTERRUPTS_CLEAR(pSlot,CRCMask|SD_Int_Data_Timeout|SD_Int_Response_Timeout);

    if (status & CRCMask) {
        ResetSlot(pSlot, FALSE);
        DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO[%d]: CRC Error %08X\r\n"),pSlot->SlotNumber,status));
        CompleteRequest(pSlot,SD_API_STATUS_CRC_ERROR);
        return TRUE;
    }

    if (status & SD_Int_Data_Timeout) {
        DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO[%d]: Data Timeout %08X\r\n"),pSlot->SlotNumber,status));
        CompleteRequest(pSlot,SD_API_STATUS_DATA_TIMEOUT);
        return TRUE;
    }

    if (status & SD_Int_Response_Timeout) {
        DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO[%d]: Response Timeout %08X\r\n"),pSlot->SlotNumber,status));
        CompleteRequest(pSlot,SD_API_STATUS_RESPONSE_TIMEOUT);
        return TRUE;
    }

    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////
//  HandleResponseTimeout - handle response timeout interrupt
//  Input:  pSlot  - slot context
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
VOID HandleResponseTimeout(PSDIO_SLOT pSlot)
{
        // this should never happen because we mark the request as un-cancelable
    if (NULL==pSlot->pCurrentRequest) {
        return;
    }

        // turn off response end / response timeout interrupts
    SD_INTERRUPTS_DISABLE(pSlot, SD_Int_Response_Done | SD_Int_Response_Timeout);
        // clear
    SD_INTERRUPTS_CLEAR(pSlot, SD_Int_Response_Done | SD_Int_Response_Timeout);

        // complete request with timeout indication
    CompleteRequest(pSlot, SD_API_STATUS_RESPONSE_TIMEOUT);
}

///////////////////////////////////////////////////////////////////////////////
//  HandleDataTimeout - handle data timeout interrupt
//  Input:  pSlot  - slot context
//  Output:
//  Return:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
VOID HandleDataTimeout(PSDIO_SLOT pSlot)
{
        // this should never happen because we mark the request as un-cancelable
    if (NULL==pSlot->pCurrentRequest) {
        return;
    }

        // turn off interrupts
    SD_INTERRUPTS_DISABLE(pSlot, ( SD_Int_Rx_FIFO_Not_Empty
                                 | SD_Int_Tx_Empty
                                 | SD_Int_Data_Timeout ));
        // clear interrupts
    SD_INTERRUPTS_CLEAR(pSlot, ( SD_Int_Rx_FIFO_Not_Empty
                               | SD_Int_Tx_Empty
                               | SD_Int_Data_Timeout ));

        // complete request with timeout indication
    CompleteRequest(pSlot, SD_API_STATUS_DATA_TIMEOUT);
}

///////////////////////////////////////////////////////////////////////////////
//  HandleResponseDone - handle response done interrupt
//  Input:  pSlot  - slot context
//  Output:
//  Return:
//  Notes:  Completes the following requests:
//             Requests with no data phase
//             Requests with a CRC/timeout error in command/response phase
///////////////////////////////////////////////////////////////////////////////
VOID HandleResponseDone(PSDIO_SLOT pSlot)
{
    PSD_BUS_REQUEST pRequest;       // current request
    ULONG           response[4];
#ifdef USE_DMA
	ULONG tmp;
#endif

    pRequest = pSlot->pCurrentRequest;

    if (NULL==pRequest) {
        return;
    }

        // Turn off response end interrupt
    SD_INTERRUPTS_DISABLE(pSlot, SD_Int_Response_Done);
        // Clear interrupt
    SD_INTERRUPTS_CLEAR(pSlot, SD_Int_Response_Done);

    response[0] = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->resp0);
    response[1] = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->resp1);
    response[2] = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->resp2);
    response[3] = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->resp3);

    DEBUGMSG(SDIO_RESPONSE_ZONE, (TEXT("HandleResponseDone SD_RESP0: 0x%08X \r\n"),response[0]));
    DEBUGMSG(SDIO_RESPONSE_ZONE, (TEXT("HandleResponseDone SD_RESP1: 0x%08X \r\n"),response[1]));
    DEBUGMSG(SDIO_RESPONSE_ZONE, (TEXT("HandleResponseDone SD_RESP2: 0x%08X \r\n"),response[2]));
    DEBUGMSG(SDIO_RESPONSE_ZONE, (TEXT("HandleResponseDone SD_RESP3: 0x%08X \r\n"),response[3]));

    if (NoResponse != pRequest->CommandResponse.ResponseType) {
            // Copy response over to request structure
        PUCHAR pResponseBuffer = &(pRequest->CommandResponse.ResponseBuffer[1]);
        int ii;

        for (ii=0; ii<4; ii++) {
            *pResponseBuffer++ = (UCHAR)(response[ii]);
            *pResponseBuffer++ = (UCHAR)(response[ii] >> 8);
            *pResponseBuffer++ = (UCHAR)(response[ii] >> 16);
            *pResponseBuffer++ = (UCHAR)(response[ii] >> 24);
        }
    }

        // check for command/response only
    if (SD_COMMAND == pRequest->TransferClass) {
            // check for and handle errors
        if (FALSE==HandleTransferErrors(pSlot,pRequest,SD_Int_Response_CRC_Error)) {
                // no errors, complete request with success
            CompleteRequest(pSlot, SD_API_STATUS_SUCCESS);
        }
    } else {

#ifdef USE_DMA
        if (!pSlot->UsingDmaThisCmd) {
#endif // #ifdef USE_DMA

                // handle data phase transfer
                // set blocks transferred to 0
            ((PHC_PARAMS)pRequest->HCParam)->BytesCopied = 0;

            if (TRANSFER_IS_READ(pRequest)) {
                    // Enable buffer read enable interrupt
                SD_INTERRUPTS_ENABLE(pSlot, SD_Int_Rx_FIFO_Not_Empty |
                                            SD_Int_Data_Timeout);
            } else {
                    // Enable buffer write enable interrupt
                SD_INTERRUPTS_ENABLE(pSlot, SD_Int_Tx_Empty |
                                            SD_Int_Data_Timeout);
            }
#ifdef USE_DMA
        } else {
            if (TRANSFER_IS_READ(pRequest)) {
					// Disable the Hardware Timeout Counter.
				tmp = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->config2);
				tmp |= SD_CONFIG2_DC;
				WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->config2,tmp);
		        HalStartDMA(pSlot->RxDmaChannel);

            } else {
		        HalStartDMA(pSlot->TxDmaChannel);
            }
        }
#endif // #ifdef USE_DMA
    }
}

///////////////////////////////////////////////////////////////////////////////
//  HandleRxFifoNotEmpty - handle Rx FIFO not empty interrupt
//  Input:  pSlot  - slot context
//  Output:
//  Return:
//  Notes:  Completes the following requests:
//             Requests with a CRC/timeout error in the read data phase
///////////////////////////////////////////////////////////////////////////////
VOID HandleRxFifoNotEmpty(PSDIO_SLOT pSlot)
{
    PSD_BUS_REQUEST pRequest;   // current request
    ULONG           regValue;   // reg value

	(void)regValue;

        // get the current request
    pRequest = pSlot->pCurrentRequest;

    if (NULL==pRequest) {
        return;
    }

    if (((PHC_PARAMS)pRequest->HCParam)->BytesCopied == (pRequest->BlockSize*pRequest->NumBlocks)) {
        return;
    }

        // we are touching the block buffer, we must set the process permissions
    SD_SET_PROC_PERMISSIONS_FROM_REQUEST(pRequest)
	{
		while( (READ_REGISTER_ULONG((PULONG)&pSlot->pSD->status) & SD_Int_Rx_FIFO_Not_Empty) &&
		       (((PHC_PARAMS)pRequest->HCParam)->BytesCopied < (pRequest->BlockSize*pRequest->NumBlocks)))
		{
#if defined(SD_FIFO_32BITS)
			ULONG  * pDst = (ULONG*)&pRequest->pBlockBuffer[((PHC_PARAMS)pRequest->HCParam)->BytesCopied];
			
			// If the buffer address is not 32 bit aligned, then we have to read the data into a 
			// temp buffer that is word aligned, and copy over to the passed in buffer.
			if((ULONG)pDst % 4)
			{
				regValue = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->rxport);
				pRequest->pBlockBuffer[((PHC_PARAMS)pRequest->HCParam)->BytesCopied] = (UCHAR)(regValue&0xFF);
				pRequest->pBlockBuffer[((PHC_PARAMS)pRequest->HCParam)->BytesCopied + 1] = (UCHAR)((regValue>>8)&0xFF);
				pRequest->pBlockBuffer[((PHC_PARAMS)pRequest->HCParam)->BytesCopied + 2] = (UCHAR)((regValue>>16)&0xFF);
				pRequest->pBlockBuffer[((PHC_PARAMS)pRequest->HCParam)->BytesCopied + 3] = (UCHAR)((regValue>>24)&0xFF);
				((PHC_PARAMS)pRequest->HCParam)->BytesCopied+=4;
			}
			else
			{
				*pDst++ = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->rxport);
				((PHC_PARAMS)pRequest->HCParam)->BytesCopied+=4;
			}
#else
				// Get byte from fifo
			regValue = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->rxport);
			pRequest->pBlockBuffer[((PHC_PARAMS)pRequest->HCParam)->BytesCopied] = (UCHAR)(regValue&0xFF);
			((PHC_PARAMS)pRequest->HCParam)->BytesCopied++;
#endif
		}
    } SD_RESTORE_PROC_PERMISSIONS();

    if (((PHC_PARAMS)pRequest->HCParam)->BytesCopied == (pRequest->BlockSize*pRequest->NumBlocks)) {
        SD_INTERRUPTS_DISABLE(pSlot,SD_Int_Rx_FIFO_Not_Empty);
        DEBUGMSG(SDIO_INTERRUPT_ZONE,(TEXT("SDIO: RxFifoNotEmpty completing request, HCParam=%d\r\n"),((PHC_PARAMS)pRequest->HCParam)->BytesCopied));
            // check for and handle errors
        if (FALSE==HandleTransferErrors(pSlot,pRequest,SD_Int_Read_CRC_Error)) {
                // no errors, complete request with success
            CompleteRequest(pSlot, SD_API_STATUS_SUCCESS);
        }
    }
}

///////////////////////////////////////////////////////////////////////////////
//  HandleTxEmpty - handle Tx empty interrupt
//  Input:  pSlot  - slot context
//  Output:
//  Return: TRUE if the request has been completed
//  Notes:  Completes the following requests:
//             Requests with a CRC/timeout error in the read data phase
///////////////////////////////////////////////////////////////////////////////
VOID HandleTxEmpty(PSDIO_SLOT pSlot)
{
    PSD_BUS_REQUEST pRequest;   // current request
    ULONG           dataValue;  // reg value

	(void)dataValue;
        // get the current request
    pRequest = pSlot->pCurrentRequest;

        // check the request hasn't already been completed
    if ((NULL==pRequest) || (((PHC_PARAMS)pRequest->HCParam)->BytesCopied == (pRequest->BlockSize*pRequest->NumBlocks))) {
        SD_INTERRUPTS_DISABLE(pSlot,SD_Int_Tx_Empty);
        return;
    }

        // we are touching the block buffer, we must set the process permissions
    SD_SET_PROC_PERMISSIONS_FROM_REQUEST(pRequest) {
		while( (READ_REGISTER_ULONG((PULONG)&pSlot->pSD->status) & SD_Int_Tx_Empty) &&
		       (((PHC_PARAMS)pRequest->HCParam)->BytesCopied < (pRequest->BlockSize*pRequest->NumBlocks)))	{
#if defined(SD_FIFO_32BITS)
			ULONG  * pSrc = (ULONG*)&pRequest->pBlockBuffer[((PHC_PARAMS)pRequest->HCParam)->BytesCopied];
			WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->txport,*pSrc++);
			((PHC_PARAMS)pRequest->HCParam)->BytesCopied+=4;
#else
            // Get byte from buffer
			dataValue = pRequest->pBlockBuffer[((PHC_PARAMS)pRequest->HCParam)->BytesCopied];
			WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->txport,dataValue);
			((PHC_PARAMS)pRequest->HCParam)->BytesCopied++;
#endif
		}
    } SD_RESTORE_PROC_PERMISSIONS();

    if (((PHC_PARAMS)pRequest->HCParam)->BytesCopied == (pRequest->BlockSize*pRequest->NumBlocks)) {
        SD_INTERRUPTS_DISABLE(pSlot,SD_Int_Tx_Empty);
            // check for and handle errors
            if (FALSE==HandleTransferErrors(pSlot,pRequest,SD_Int_Write_CRC_Error)) {
                    // no errors, complete request with success
                CompleteRequest(pSlot, SD_API_STATUS_SUCCESS);
            }
    }
}

///////////////////////////////////////////////////////////////////////////////
//  GetInterrupts - get current pending interrupts
//  Input:  pSlot - slot context
//  Output: pInterrupts - active, unmasked, controller interrupts
//  Return: TRUE if there is an active unmasked interrupt
//  Notes:
///////////////////////////////////////////////////////////////////////////////
BOOL GetInterrupts(PSDIO_SLOT pSlot,
                   PULONG     pInterrupts)
{
    ULONG  interrupts;      // controller interrupts

        // read interrupts from hardware
    interrupts = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->status);
        // the hardware masks interrupts sources from causing an interrupt,
        // but not from showing up in the status register. Mask them here.
    interrupts &= pSlot->InterruptMask;

    *pInterrupts = interrupts;

        // Return TRUE if any unmasked interrupts are active
    return (0 != interrupts);
}

///////////////////////////////////////////////////////////////////////////////
//  SDIOInsertionIstThread - IST thread for driver
//  Input:  pSlot - slot context
//  Output:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
DWORD SDIOInsertionIstThread(PSDIO_SLOT pSlot)
{
    DWORD waitStatus;       // wait status
    DWORD initRate = 200000;
    int   debounceCount;
    BOOL  cardInserted;

    if (!CeSetThreadPriority(GetCurrentThread(), pSlot->InsertionIstThreadPriority)) {
        DEBUGMSG(SDCARD_ZONE_WARN, (TEXT("SDIOInsertionIstThread[%d]: warning, failed to set CEThreadPriority \r\n"),pSlot->SlotNumber));
    }

    while(1) {

        waitStatus = WaitForSingleObject(pSlot->hInsertionInterruptEvent, INFINITE);

        if (WAIT_OBJECT_0 != waitStatus) {
            DEBUGMSG(SDCARD_ZONE_WARN, (TEXT("SDIOInsertionIstThread[%d]: Wait Failed! 0x%08X \r\n"),pSlot->SlotNumber, waitStatus));
                // bail out
            return 0;
        }

        if (pSlot->pController->DriverShutdown) {
            DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOInsertionIstThread[%d]: Thread Exiting\r\n"),pSlot->SlotNumber));
            return 0;
        }

            // check slot on startup for inserted cards
        if (pSlot->CheckSlotOnStartUp) {
            DEBUGMSG(SDIO_INTERRUPT_ZONE,(TEXT("SDIOInsertionIstThread[%d]: Removing device after powerdown\r\n"),pSlot->SlotNumber));
                // this case is hit when we suspend and resume while there is a
                // card in the slot, because we remove power we have
                // to indicate a device removal first
            RemoveDevice(pSlot);

				// Reset the slot
			ResetSlot(pSlot, FALSE);

#ifdef DEBUG
				// Dump the state of the slot
			DumpSlot(pSlot);
#endif

                // Now check to see if the card is still present, if so
                // handle as per device insertion

            if (SDIOPlatCardInserted(pSlot->pController,pSlot->SlotNumber)) {
                pSlot->CardPresent = TRUE;
				pSlot->CardInitialised = FALSE;

                    // indicate device arrival
                SDHCDIndicateSlotStateChange(pSlot->pController->pHCContext,
                                             pSlot->SlotNumber,
                                             DeviceInserted );
            } else {
                pSlot->CardPresent = FALSE;
            }
            pSlot->CheckSlotOnStartUp = FALSE;

            InterruptDone(pSlot->InsertionSysIntr);
            continue;
        }

        DEBUGMSG(SDIO_INTERRUPT_ZONE, (TEXT("SDIOInsertionIstThread[%d]: interrupt!\r\n"),pSlot->SlotNumber));

            // start debounce logic
        debounceCount = 0;
        cardInserted = FALSE;

            // stay in this loop until the insertion state has been the same for
            // ten consecutive debounce sampling intervals
        while(debounceCount < SDIO_DEBOUNCE_COUNT) {
            if (SDIOPlatCardInserted(pSlot->pController,pSlot->SlotNumber)) {
                if (cardInserted) {
                    debounceCount++;
                } else {
                    cardInserted = TRUE;
                    debounceCount = 0;
                }
            } else {
                if (cardInserted) {
                    cardInserted = FALSE;
                    debounceCount = 0;
                } else {
                    debounceCount++;
                }
            }
            Sleep(SDIO_DEBOUNCE_INTERVAL);
        }

        if (cardInserted && !pSlot->CardPresent) {
                // set clock to 100 kHz for card initialisation
			initRate = 200000;
            SDIOSetRate(pSlot, &initRate);

            pSlot->CardPresent = TRUE;
            pSlot->CardInitialised = FALSE;

            DEBUGMSG(SDIO_INTERRUPT_ZONE,(TEXT("SDIOInsertionIstThread[%d]: Card Insertion Interrupt\r\n"),pSlot->SlotNumber));
                // indicate device arrival
            SDHCDIndicateSlotStateChange(pSlot->pController->pHCContext,
                                         pSlot->SlotNumber,
                                         DeviceInserted );
        } else if (!cardInserted && pSlot->CardPresent) {
            DEBUGMSG(SDIO_INTERRUPT_ZONE,(TEXT("SDIOInsertionIstThread[%d]: Card Removal Interrupt\r\n"),pSlot->SlotNumber));
                // remove device
            RemoveDevice(pSlot);

            pSlot->CardPresent = FALSE;
        }

        InterruptDone(pSlot->InsertionSysIntr);
    }
}

///////////////////////////////////////////////////////////////////////////////
//  SDIOControllerIstThread - IST thread for driver
//  Input:  pController - controller context
//  Output:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
DWORD SDIOControllerIstThread(PSDIO_HW_CONTEXT pController)
{
    DWORD waitStatus;       // wait status
    ULONG interrupts;       // current interrupts
    UCHAR slot;             // slot number
    PSDIO_SLOT pSlot;       // the slot

    if (!CeSetThreadPriority(GetCurrentThread(), pController->ControllerIstThreadPriority)) {
        DEBUGMSG(SDCARD_ZONE_WARN, (TEXT("SDIOControllerIstThread: warning, failed to set CEThreadPriority \r\n")));
    }

    while(1) {

        waitStatus = WaitForSingleObject(pController->hControllerInterruptEvent, INFINITE);

        if (WAIT_OBJECT_0 != waitStatus) {
            DEBUGMSG(SDCARD_ZONE_WARN, (TEXT("SDIOControllerIstThread: Wait Failed! 0x%08X \r\n"), waitStatus));
                // bail out
            return 0;
        }

        if (pController->DriverShutdown) {
                // shut the thread down
            DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIOControllerIstThread: Thread Exiting\r\n")));
            return 0;
        }

            // check each slot in turn
        for (slot=0; slot<SDIOPlatNumSlots(); slot++) {
            pSlot = &pController->Slots[slot];
                // loop until all interrupts are serviced
            while (GetInterrupts(pSlot,&interrupts)) {

                DEBUGMSG(SDIO_INTERRUPT_ZONE,(TEXT("Int: %08X\r\n"),interrupts));

                if (interrupts & SD_Int_Response_Timeout) {
                        // clear the interrupt
                    SD_INTERRUPTS_CLEAR(pSlot, SD_Int_Response_Timeout);
                    DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO - Response Timeout Interrupt\r\n")));
                    HandleResponseTimeout(pSlot);
                }

                if (interrupts & SD_Int_Data_Timeout) {
                        // clear the interrupt
                    SD_INTERRUPTS_CLEAR(pSlot, SD_Int_Data_Timeout);
                    DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("SDIO - Data Transfer Timeout Interrupt\r\n")));
                    HandleDataTimeout(pSlot);
                }

                if (interrupts & SD_Int_Response_Done) {
                        // clear the interrupt
                    SD_INTERRUPTS_CLEAR(pSlot, SD_Int_Response_Done);
                    DEBUGMSG(SDIO_INTERRUPT_ZONE,(TEXT("SDIO - Response Done Interrupt\r\n")));
                    HandleResponseDone(pSlot);
                }

                if (interrupts & SD_Int_Rx_FIFO_Not_Empty) {
                        // clear the interrupt
                    SD_INTERRUPTS_CLEAR(pSlot, SD_Int_Rx_FIFO_Not_Empty);
                    HandleRxFifoNotEmpty(pSlot);
                }

                if (interrupts & SD_Int_Tx_Empty) {
                        // clear the interrupt
                    SD_INTERRUPTS_CLEAR(pSlot, SD_Int_Tx_Empty);
                    HandleTxEmpty(pSlot);
                }

                if (interrupts & SD_Int_SDIO_Interrupt) {
                        // disable the interrupt, the slot option handler will be called
                        // to re-enable it
                    SD_INTERRUPTS_DISABLE(pSlot, SD_Int_SDIO_Interrupt);
                    SD_INTERRUPTS_CLEAR(pSlot, SD_Int_SDIO_Interrupt);
                    DEBUGMSG(SDIO_INTERRUPT_ZONE,(TEXT("SDIO - SDIO Card Interrupt\r\n")));
                        // indicate that the card is interrupting
                    SDHCDIndicateSlotStateChange(pController->pHCContext,
                                                 slot,
                                                 DeviceInterrupting);
                }
            }
        }

        InterruptDone(pController->SysIntr);
    }
}

#ifdef USE_DMA
///////////////////////////////////////////////////////////////////////////////
//  SDIODmaIstThread - IST thread for DMA mode
//  Input:  pSlot - slot context
//  Output:
//  Notes:
///////////////////////////////////////////////////////////////////////////////
DWORD SDIODmaIstThread(PSDIO_SLOT pSlot)
{
    DWORD waitStatus;       // wait status
    ULONG dmaIntMask;      // DMA done mask
    PSD_BUS_REQUEST pRequest; // the request we are servicing
    BOOL  reenableBuffer = FALSE;
    PULONG pDmaBuffer;
	ULONG tmp;

    if (!CeSetThreadPriority(GetCurrentThread(), pSlot->DmaIstThreadPriority)) {
        DEBUGMSG(SDCARD_ZONE_WARN, (TEXT("SDIODmaIstThread[%d]: warning, failed to set CEThreadPriority \r\n"),pSlot->SlotNumber));
    }

    while(1) {

        waitStatus = WaitForSingleObject(pSlot->hDmaInterruptEvent, INFINITE);

        if (WAIT_OBJECT_0 != waitStatus) {
            DEBUGMSG(SDCARD_ZONE_WARN, (TEXT("SDIODmaIstThread[%d]: Wait Failed! 0x%08X \r\n"),pSlot->SlotNumber, waitStatus));
                // bail out
            return 0;
        }

        if (pSlot->pController->DriverShutdown) {
            DEBUGMSG(SDCARD_ZONE_INIT, (TEXT("SDIODmaIstThread[%d]: Thread Exiting\r\n"),pSlot->SlotNumber));
            return 0;
        }

		pRequest = pSlot->pCurrentRequest;

		if (pRequest!=NULL && TRANSFER_IS_READ(pRequest)) {
			// Process Rx
			dmaIntMask = HalCheckForDMAInterrupt(pSlot->RxDmaChannel);

			while (dmaIntMask) {
				HalAckDMAInterrupt(pSlot->RxDmaChannel,dmaIntMask);
					// empty the buffer if data still outstanding, HCParam is block count
				if (((PHC_PARAMS)pRequest->HCParam)->BlocksCopied < pRequest->NumBlocks) {
					pDmaBuffer = HalGetNextDMABuffer(pSlot->RxDmaChannel);
						// empty the buffer
					CopyFromDmaBuffer(pRequest, pDmaBuffer);
						// is the request complete ?
					if (((PHC_PARAMS)pRequest->HCParam)->BlocksCopied == pRequest->NumBlocks) {
						HalStopDMA(pSlot->RxDmaChannel);
						DEBUGMSG(SDIO_DMA_ZONE,(TEXT("SDIO[%d]: RDMA Completing Request (SD_STATUS=%08X)\r\n"),pSlot->SlotNumber,READ_REGISTER_ULONG((PULONG)&pSlot->pSD->status)));
						if (FALSE==HandleTransferErrors(pSlot,pRequest,SD_Int_Read_CRC_Error)) {							
								// Enable the Hardware Timeout Counter.
							tmp = READ_REGISTER_ULONG((PULONG)&pSlot->pSD->config2);
							tmp &= ~SD_CONFIG2_DC;
							WRITE_REGISTER_ULONG((PULONG)&pSlot->pSD->config2,tmp);
								// no errors, complete request with success
							CompleteRequest(pSlot, SD_API_STATUS_SUCCESS);
                            break;
						}
					} else {
						ULONG  bufferSize;
						bufferSize = min(((pRequest->NumBlocks-((PHC_PARAMS)pRequest->HCParam)->BlocksCopied)*pRequest->BlockSize),pSlot->DmaBufferSize);
						HalActivateDMABuffer(pSlot->RxDmaChannel,pDmaBuffer,bufferSize);
					}
				}

				dmaIntMask = HalCheckForDMAInterrupt(pSlot->RxDmaChannel);
			}
		} else if (pRequest!=NULL && TRANSFER_IS_WRITE(pRequest)) {
			ULONG copySize;
			// Process Tx
			dmaIntMask = HalCheckForDMAInterrupt(pSlot->TxDmaChannel);

			while (dmaIntMask) {
				HalAckDMAInterrupt(pSlot->TxDmaChannel,dmaIntMask);

				((PHC_PARAMS)pRequest->HCParam)->BuffersOutstanding--;

				if (((PHC_PARAMS)pRequest->HCParam)->BuffersOutstanding == 0) {
						// complete request
					HalStopDMA(pSlot->TxDmaChannel);
					DEBUGMSG(SDIO_DMA_ZONE,(TEXT("SDIO[%d]: TDMA Completing Request (SD_STATUS=%08X)\r\n"),pSlot->SlotNumber,READ_REGISTER_ULONG((PULONG)&pSlot->pSD->status)));
					if (FALSE==HandleTransferErrors(pSlot,pRequest,SD_Int_Write_CRC_Error)) {
							// no errors, complete request with success
						CompleteRequest(pSlot, SD_API_STATUS_SUCCESS);
                        break;
					}
				} else if (((PHC_PARAMS)pRequest->HCParam)->BlocksCopied < pRequest->NumBlocks) {
					pDmaBuffer = HalGetNextDMABuffer(pSlot->TxDmaChannel);
						// fill buffer if data remaining
					copySize = CopyToDmaBuffer(pRequest, pDmaBuffer);
					HalActivateDMABuffer(pSlot->TxDmaChannel,pDmaBuffer,copySize);
					DEBUGMSG(SDIO_DMA_ZONE,(TEXT("TDMA %d/%d\r\n"),((PHC_PARAMS)pRequest->HCParam)->BlocksCopied, pRequest->NumBlocks));
				}

				dmaIntMask = HalCheckForDMAInterrupt(pSlot->TxDmaChannel);
			}
		} else {
			// We got a spurious interrupt, best ack it as best we can
			dmaIntMask = HalCheckForDMAInterrupt(pSlot->TxDmaChannel);
			DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("Spurious Tx %d\r\n"),dmaIntMask));
			HalAckDMAInterrupt(pSlot->TxDmaChannel,dmaIntMask);

			dmaIntMask = HalCheckForDMAInterrupt(pSlot->RxDmaChannel);
			DEBUGMSG(SDCARD_ZONE_ERROR,(TEXT("Spurious Rx %d\r\n"),dmaIntMask));
			HalAckDMAInterrupt(pSlot->RxDmaChannel,dmaIntMask);
		}

        InterruptDone(pSlot->DmaSysIntr);
    }
}
#endif //#ifdef USE_DMA




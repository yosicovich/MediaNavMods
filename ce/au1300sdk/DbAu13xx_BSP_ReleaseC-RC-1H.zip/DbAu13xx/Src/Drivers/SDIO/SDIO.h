///////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2002-2004 BSQUARE Corporation.  All rights reserved.
//
// Module Name:
//
//    SDIO.h
//
// Abstract:
//
//    Au1100 SDIO driver definitions
//
// Notes:
//
///////////////////////////////////////////////////////////////////////////////

#ifndef _SDIO_H_DEFINED
#define _SDIO_H_DEFINED
#include <platform.h>
#include <bceddk.h>

#define DEFAULT_TAGS 4

#define SDIO_NUM_SLOTS	3

#define SD_REMOVABLE_SLOT 0
#define SD_EMMC_SLOT 1
#define SD_SATURN_SLOT 2

#define DMA_BUFFER_SIZE (32*512)

#if defined(SD_FIFO_32BITS)
 #define DMA_MIN_XFER 	32
#else
 #define DMA_MIN_XFER 	8
#endif

    // forward declaration
typedef struct _SDIO_HW_CONTEXT *PSDIO_HW_CONTEXT;

typedef struct _SDIO_SLOT {
    PSDIO_HW_CONTEXT    pController;                    // the parent controller
    AU1X00_SD           *pSD;                           // pointer to registers
    SD_CARD_INTERFACE   SDInterface;                    // current interface
    BOOL                CardPresent;                    // SD card present flag
    BOOL                CheckSlotOnStartUp;             // flag to force card detect on startup
    ULONG               InterruptMask;                  // mask for interrupts
    BOOL                CardInitialised;                // card initialized ?
    volatile PSD_BUS_REQUEST     pCurrentRequest;       // current request
    UCHAR               SlotNumber;                     // slot number
		// Au1100 specific
	BOOL				UsingDma;						// using DMA ?
	BOOL				UsingDmaThisCmd;						// using DMA ?
        // insertion interrupts
    HANDLE              hInsertionInterruptEvent;       // insertion interrupt event
    HANDLE              hInsertionInterruptThread;      // insertion interrupt thread
    int                 InsertionIstThreadPriority;     // insertion IST thread priority
    DWORD               InsertionSysIntr;
        // DMA resources - shared by both transmit and receive
	PDMA_CHANNEL_OBJECT TxDmaChannel;                   //
	PDMA_CHANNEL_OBJECT RxDmaChannel;                   //
    DWORD               DmaSysIntr;                     // sysintr for DMA interrupts
    HANDLE              hDmaInterruptEvent;             // DMA interrupt event
    HANDLE              hDmaInterruptThread;            // DMA interrupt thread
    int                 DmaIstThreadPriority;           // DMA IST thread priority
	ULONG               DmaBufferSize;
	BOOL				Removeable;
	BOOL				MMC8BitBusSupport;					// true if slot can support 8 bit
														// wide data bus.
}SDIO_SLOT, *PSDIO_SLOT;

  // Au1100 hardware specific context
typedef struct _SDIO_HW_CONTEXT {
    PSDCARD_HC_CONTEXT  pHCContext;                     // the host controller context
    SDIO_SLOT           Slots[SDIO_NUM_SLOTS];          // array of slot structures
    HANDLE              hControllerInterruptEvent;      // controller interrupt event
    HANDLE              hControllerInterruptThread;     // controller interrupt thread
    int                 ControllerIstThreadPriority;    // controller IST thread priority
    BOOL                Initialized;                    // controller initialized ?
    BOOL                DriverShutdown;                 // controller shutdown
    WCHAR               RegPath[256];                   // reg path
    DWORD               SysIntr;                        // System interrupt number
    HANDLE              hGPIO;                          // handle to GPIO driver
    CRITICAL_SECTION    CriticalSection;                // critical section for the controller
	PVOID               pPlatSpecificPtr;
}SDIO_HW_CONTEXT, *PSDIO_HW_CONTEXT;

    // prototypes for handlers
BOOLEAN SDIOCancelIoHandler(PSDCARD_HC_CONTEXT pHCContext,DWORD Slot, PSD_BUS_REQUEST pRequest);
SD_API_STATUS SDIOBusRequestHandler(PSDCARD_HC_CONTEXT pHCContext,DWORD Slot, PSD_BUS_REQUEST pRequest);
SD_API_STATUS SDIOSlotOptionHandler(PSDCARD_HC_CONTEXT    pHCContext,
                                     DWORD                 SlotNumber,
                                     SD_SLOT_OPTION_CODE   Option,
                                     PVOID                 pData,
                                     ULONG                 OptionSize);

    // other prototypes
SD_API_STATUS SDIODeinitialize(PSDCARD_HC_CONTEXT pHCContext);
SD_API_STATUS SDIOInitialize(PSDCARD_HC_CONTEXT pHCContext);

	// registry keys
#define PIO_MODE_KEY	        TEXT("PIOMode")
#define DISABLE_8_BIT_BUS_KEY   TEXT("Disable8BitBus")

    // debug zones
#define SDIO_INTERRUPT_ZONE    SDCARD_ZONE_0
#define SDIO_SEND_ZONE         SDCARD_ZONE_1
#define SDIO_RESPONSE_ZONE     SDCARD_ZONE_2
#define SDIO_RECEIVE_ZONE      SDCARD_ZONE_3
#define SDIO_CLOCK_ZONE        SDCARD_ZONE_4
#define SDIO_TRANSMIT_ZONE     SDCARD_ZONE_5
#define SDIO_DMA_ZONE          SDCARD_ZONE_6

#define SDIO_INTERRUPT_ZONE_ON ZONE_ENABLE_0
#define SDIO_SEND_ZONE_ON      ZONE_ENABLE_1
#define SDIO_RESPONSE_ZONE_ON  ZONE_ENABLE_2
#define SDIO_RECEIVE_ZONE_ON   ZONE_ENABLE_3
#define SDIO_CLOCK_ZONE_ON     ZONE_ENABLE_4
#define SDIO_TRANSMIT_ZONE_ON  ZONE_ENABLE_5
#define SDIO_DMA_ZONE_ON       ZONE_ENABLE_6

    // IST priority
#define SDIO_CARD_CONTROLLER_IST_PRIORITY 100

    // debounce control
#define SDIO_DEBOUNCE_COUNT     10
#define SDIO_DEBOUNCE_INTERVAL  20

    // Au1100 SD controller register definitions
#define SD_CONTROL_REGISTERS_LENGTH 0x40

    // SD Controller interrupts
    // Used in SD_CONFIG register to enable/disable interrupts
    // Used in SD_STATUS register to detect/clear interrupts
#define SD_Int_SDIO_Interrupt       0x80000000 // SI
#define SD_Int_Card_Detect          0x40000000 // CD
#define SD_Int_Rx_Full              0x20000000 // RF
#define SD_Int_Rx_Almost_Full       0x10000000 // RA
#define SD_Int_Rx_Half_Full         0x08000000 // RH
#define SD_Int_Tx_Almost_Empty      0x04000000 // TA
#define SD_Int_Tx_Empty             0x02000000 // TE
#define SD_Int_Tx_Half_Full         0x01000000 // TH
#define SD_Int_Write_CRC_Error      0x00400000 // WC
#define SD_Int_Read_CRC_Error       0x00200000 // RC
#define SD_Int_Response_CRC_Error   0x00100000 // SC
#define SD_Int_Data_Timeout         0x00080000 // DT
#define SD_Int_Data_Done            0x00040000 // DD
#define SD_Int_Response_Timeout     0x00020000 // RA
#define SD_Int_Response_Done        0x00010000 // CR
#define SD_Int_Master               0x00008000 // I
#define SD_Int_Rx_FIFO_Overrun      0x00004000 // RO
#define SD_Int_Rx_FIFO_Underrun     0x00002000 // RU
#define SD_Int_Tx_FIFO_Overrun      0x00001000 // TO
#define SD_Int_Tx_FIFO_Underrun     0x00000800 // TU
#define SD_Int_Rx_FIFO_Not_Empty    0x00000400 // NE

#define SD_Int_FIFO_Errors          (SD_Int_Rx_FIFO_Overrun |  \
                                     SD_Int_Rx_FIFO_Underrun | \
                                     SD_Int_Tx_FIFO_Overrun |  \
                                     SD_Int_Tx_FIFO_Underrun )

#define SD_Int_CRC_Errors           (SD_Int_Write_CRC_Error | \
                                     SD_Int_Read_CRC_Error | \
                                     SD_Int_Response_CRC_Error )

    // SD Block Size Register
#define SD_MAX_BLOCK_SIZE	0x0800
#define SD_MAX_BLOCK_COUNT  0x01FF

    // SD Status Register
#define SD_STATUS_CRC_OK(status)    (((status)&SD_STATUS_DCRCW)==SD_STATUS_DCRCW_NONE)

    // SD Timeout register
#define SD_TIMEOUT_MAX          0x001E0000  // maximum timeout value

    // macros to decode IO RW arguments
#define IO_RW_DIRECT_ADDR_ARG(Arg)  (((Arg)>>9)&0x1FFFF)
#define IO_RW_EXTENDED_BLOCK_MODE(Arg) (((Arg)>>27)&1)
#define IO_RW_EXTENDED_COUNT(Arg)      ((Arg)&0x1FF)

    // macros to identify request type
#define TRANSFER_IS_READ(pRequest)         (SD_READ == (pRequest)->TransferClass)
#define TRANSFER_IS_WRITE(pRequest)        (SD_WRITE == (pRequest)->TransferClass)
#define TRANSFER_HAS_DATA_PHASE(pRequest)  (SD_COMMAND != (pRequest)->TransferClass)

    // macro to acquire device lock via a critical section
#define ACQUIRE_DEVICE_LOCK(pHc) \
    EnterCriticalSection(&(pHc)->CriticalSection)

    // macro to release device lock via a critical section
#define RELEASE_DEVICE_LOCK(pHc) \
    LeaveCriticalSection(&(pHc)->CriticalSection)

    // macro to enable controller interrupts
#define SD_INTERRUPTS_ENABLE(pSlot, Mask)                     \
{                                                             \
	ULONG tmp;                                                \
    ACQUIRE_DEVICE_LOCK((pSlot)->pController);                \
	tmp = READ_REGISTER_ULONG((PULONG)&(pSlot)->pSD->config); \
	tmp |= (Mask);                                            \
	WRITE_REGISTER_ULONG((PULONG)&(pSlot)->pSD->config,tmp);  \
    (pSlot)->InterruptMask |= (Mask);                         \
    RELEASE_DEVICE_LOCK((pSlot)->pController);                \
}

    // macro to disable controller interrupts
#define SD_INTERRUPTS_DISABLE(pSlot, Mask)                    \
{                                                             \
	ULONG tmp;                                                \
    ACQUIRE_DEVICE_LOCK((pSlot)->pController);                \
	tmp = READ_REGISTER_ULONG((PULONG)&(pSlot)->pSD->config); \
	tmp &= ~(Mask);                                           \
	WRITE_REGISTER_ULONG((PULONG)&(pSlot)->pSD->config,tmp);  \
    (pSlot)->InterruptMask &= ~(Mask);                        \
    RELEASE_DEVICE_LOCK((pSlot)->pController);                \
}

    // macro to clear interrupt status bits. Write 1 to clear
#define SD_INTERRUPTS_CLEAR(pSlot,Mask) WRITE_REGISTER_ULONG((PULONG)&(pSlot)->pSD->status,(Mask))

    // controller IST
DWORD SDIOControllerIstThread(PSDIO_HW_CONTEXT pController);
    // insertion IST
DWORD SDIOInsertionIstThread(PSDIO_SLOT pSlot);
    // DMA IST
DWORD SDIODmaIstThread(PSDIO_SLOT pSlot);
    // Device removal handler
VOID RemoveDevice(PSDIO_SLOT pSlot);

VOID SDIODeinitializeDMA(PSDIO_SLOT pSlot);

	// Platform specific functions
int SDIOPlatNumSlots();
SD_API_STATUS SDIOPlatInit(PSDIO_HW_CONTEXT pController);
SD_API_STATUS SDIOPlatDeinit(PSDIO_HW_CONTEXT pController);
SD_API_STATUS SDIOPlatPower(PSDIO_HW_CONTEXT pController, BOOL PowerOn, ULONG Slot);
BOOL SDIOPlatCardWriteProteced(PSDIO_HW_CONTEXT pController, ULONG Slot);
BOOL SDIOPlatCardInserted(PSDIO_HW_CONTEXT pController, ULONG Slot);

#if _WINCEOSVER >= 600
// Compatibility macros
#define SD_SET_PROC_PERMISSIONS_FROM_REQUEST(x)
#define SD_RESTORE_PROC_PERMISSIONS()
#endif // _WINCEOSVER

#endif

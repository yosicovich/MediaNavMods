Copyright (c) 2003 BSQUARE Corporation.  All rights reserved.

SDIONow Host Controller Driver Supporting:

Alchemy DB1100 Evaluation Board


INSTALLING
==========

1.  Make sure you have installed SDIONow DDK and the DB1100 BSP.

2.  Import SDIONow DDK CEC file, SDCardDDK.cec, into Platform Builder. Note that SDCardDDK.cec
    only includes the bus driver and the sample driver for the SD and MMC memory devices.  
    CEC files for other sample client drivers can be found under %_WINCEROOT%\public\SDCardDDK.

3.  Copy all Au1100 SDIO files to %_TARGETPLATROOT%\Drivers\SDIO.

4.  Modify %_TARGETPLATROOT%\drivers\dirs to add "SDIO" to the driver list.

5.  Import the CEC file, Au1100-SDIO.cec, into Platform Builder.

6.  Create or open a DB1100 platform within Platform Builder.

7.  Add the SDIO host controller driver from the catalog into the current platform.

8.  Add the required SDIONow drivers from the catalog into the platform.  Other than the required 
    SD bus driver and the client drivers, FAT File System is a required feature for working with
    memory cards.  See SIDONow documentation for details.

10. If you are using an older Pb1x00 BSP it will be necessary to add the following defines to 

	%_WINCEROOT%\Platform\Pb1x00\inc\au1x00.s 

	#define SD0_OFFSET      (0x00600000)
	#define SD1_OFFSET      (0x00680000)
	#define SD0_PHYSADDR	(PBUS0_PHYSADDR+SD0_OFFSET)
	#define SD1_PHYSADDR	(PBUS0_PHYSADDR+SD1_OFFSET)
	// Device ID Select 1
	#define DMA_DID_SD0_TX	0
	#define DMA_DID_SD0_RX	1
	#define DMA_DID_SD1_TX	2
	#define DMA_DID_SD1_RX  3
	#define DMA_MODE_DS	(1 << 15)
	#define HWINTR_SD	2

	Newer versions of the BSP should already have these defines.

NOTES
=====

The SDIO driver controls both SD slots of the DB1100. The two slots share a main IST but have 
separate ISTs for insertion/removal interrupts and DMA interrupts.

Card insertion/removal is currently done using GPIO19 and GPIO20, this is DB1100 specific. 

The driver can operate in both DMA and PIO modes. Ideally the driver will default to using DMA 
mode unless there are no available DMA channels. It is possible for one slot to run DMA while the 
other uses PIO.  However, DMA mode is currently disabled as we have encountered some DMA issue with
the host controller.  DMA mode can be enabled by commenting the "PIOMode" line in SDIO.reg.

Minimum development testing has been done to ensure both SD/MMC memory card and SDIO Bluetooth card 
work as expected under the PIO mode.

KNOWN ISSUES
============

* DMA mode is not fully tested as we're still observing problems in handling the extended read/write 
  IO command, CMD53, with DMA enabled.

* SanDisk 64MB MMC card cannot be identified due to a failure in the card identification process.  
  The response for CMD1, which is used to query the valid voltage window during the identification 
  process, never occurs.  After 3 retries the SD bus driver declares the card to be an unknown device 
  instead of MMC device.  


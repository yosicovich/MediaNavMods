/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include <windows.h>
#include <platform.h>
#include <bceddk.h>

#ifdef DEBUG

#define ZONE_INIT                DEBUGZONE(0)
#define ZONE_CLOCKS              DEBUGZONE(1)
#define ZONE_GPIOS               DEBUGZONE(2)
#define ZONE_IOCTL               DEBUGZONE(3)
#define ZONE_FUNC                DEBUGZONE(4)
#define ZONE_WARNING             DEBUGZONE(14)
#define ZONE_ERROR               DEBUGZONE(15)

DBGPARAM dpCurSettings = {
    TEXT("Gpintr"), {
        TEXT("Init"), TEXT("Clocks"), TEXT("Gpios"), TEXT("IOCTLs"),
        TEXT("-"), TEXT("-"), TEXT("-"), TEXT("-"),
        TEXT("-"), TEXT("-"), TEXT("-"),TEXT("-"),
        TEXT("Alloc"), TEXT(""),TEXT("Warnings"), TEXT("Errors")},
    0xffff};
#endif

//
// Structure for storing device instance data.  There is one of these per
// instance of a device.  We could have 2 devices in the system, in which case
// there would be two of these structures.
//
// This structure contains members of different sizes.  It's good practice to
// place all the large members at the top of the structure and all the smaller
// ones at the end.  This helps with alignment issues.
//
typedef struct _DEVICE_INSTANCE {

    LONG                    OpenCount;      // Number of open handles.
    CRITICAL_SECTION        ControlMutex;   // Marshall accesses
} DEVICE_INSTANCE, *PDEVICE_INSTANCE;


//
// Exported Routines
//

BOOL
WINAPI
DllMain(
    IN HANDLE Instance,
    IN DWORD Reason,
    IN PVOID Reserved
    )
{
    //
    // This routine doesn't do anything except print out the reason.  To
    // prevent getting flooded with prints, all of the debug messages are
    // disabled by default.  Changing a #define will enable the prints.
    //

    switch (Reason) {

    case DLL_PROCESS_ATTACH:
        DEBUGREGISTER(Instance);
		DisableThreadLibraryCalls((HMODULE) Instance);
        break;

    case DLL_PROCESS_DETACH:
        break;

    case DLL_THREAD_DETACH:
        break;

    case DLL_THREAD_ATTACH:
        break;

    default:
        break;
    }

    //
    // Always return TRUE.  If FALSE is returned, processes that are starting
    // up will terminate with an error.
    //

    return TRUE;
}


BOOL
GPINTR_Deinit(
    IN OUT ULONG DeviceContext
    )
{
    PDEVICE_INSTANCE DeviceInstance;

    DeviceInstance = (PDEVICE_INSTANCE)DeviceContext;

    //
    // Close the handle to the mutex protecting the device's control shadow.
    //

    DeleteCriticalSection(&DeviceInstance->ControlMutex);

//
    // Finally, the device instance itself can be freed.
//

    LocalFree(DeviceInstance);

    return TRUE;
}


ULONG
GPINTR_Init(
    IN ULONG RegistryPath
             )
{
    PDEVICE_INSTANCE DeviceInstance = NULL;

    DeviceInstance = LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT,
                                sizeof(*DeviceInstance));
    if (DeviceInstance == NULL) {
        goto ErrorReturn;

}

    //
    // Initialize the mutex to protect the device's Control register's shadow.
    //

    InitializeCriticalSection(&DeviceInstance->ControlMutex);

ErrorReturn:

    return (ULONG)DeviceInstance;
}


ULONG
GPINTR_Open(
    IN OUT ULONG DeviceContext,
    IN ULONG AccessCode,
    IN ULONG ShareMode
             )
{
    return (ULONG)DeviceContext;
}


BOOL
GPINTR_Close(
    IN OUT ULONG DeviceContext
             )
{
    return 0;
}


ULONG
GPINTR_Read(
    IN OUT ULONG DeviceContext,
    IN PUCHAR ReadBuffer,
    IN ULONG Count
             )
{
    return 0;
}

ULONG
GPINTR_Write(
    IN OUT ULONG DeviceContext,
    IN PUCHAR Source,
    IN ULONG Count
    )
{
    return 0;
}

ULONG
GPINTR_Seek(
    IN OUT ULONG DeviceContext,
    IN LONG Amount,
    IN USHORT Type
             )
{
    return 0;
}


BOOL
GPINTR_IOControl(
    IN OUT ULONG DeviceContext,
    IN ULONG Code,
    IN PUCHAR InputBuffer,
    IN ULONG InputBufferLength,
    OUT PUCHAR OutputBuffer,
    IN ULONG OutputBufferLength,
    OUT PULONG ActualOutput
             )
{
    return FALSE;
}


VOID
GPINTR_PowerDown(
    IN OUT ULONG DeviceContext
             )
{
	/* This is handled in OEMPowerOff(); */
	return;
}


VOID
GPINTR_PowerUp(
    IN OUT ULONG DeviceContext
             )
{
	/* This is handled in OEMPowerOff(); */
	return;
}

BOOL
GPINTR_SetPinOutputState(
    ULONG pin,
	ULONG state )
{
    ULONG Tmp;
    BOOL RetVal;
	GPINTRREQ req;

	req.gpintr = pin;
	if ( state == TRUE )
		req.op = GPINTR_REQ_OUTPUT_1;
	else
		req.op = GPINTR_REQ_OUTPUT_0;

	RetVal = KernelIoControl(
		IOCTL_OEM_GPINTR_REQ,
		&req,
		sizeof(req),
        NULL,
        0,
		&Tmp );

    return RetVal;
}

BOOL
GPINTR_SetPinConfiguration(
    ULONG pin,
	ULONG cfg  )
{
    ULONG Tmp;
    BOOL RetVal;
	GPINTRREQ req;

	req.gpintr = pin;
	req.cfg = cfg;
	req.op = GPINTR_REQ_SET_CFG;

	RetVal = KernelIoControl(
		IOCTL_OEM_GPINTR_REQ,
		&req,
		sizeof(req),
        NULL,
        0,
		&Tmp );

    return RetVal;
}

BOOL
GPINTR_GetPinConfiguration(
    ULONG pin,
	ULONG *pcfg  )
{
    ULONG Tmp;
    BOOL RetVal;
	GPINTRREQ req;

	req.gpintr = pin;
	req.op = GPINTR_REQ_GET_CFG;

	RetVal = KernelIoControl(
		IOCTL_OEM_GPINTR_REQ,
		&req,
		sizeof(req),
		pcfg,
		sizeof(ULONG),
		&Tmp );

    return RetVal;
}

BOOL
GPINTR_GetPinState(
    ULONG pin,
	ULONG *pstate  )
{
    ULONG Tmp;
    BOOL RetVal;
	GPINTRREQ req;

	req.gpintr = pin;
	req.op = GPINTR_REQ_READSTATE;

	RetVal = KernelIoControl(
		IOCTL_OEM_GPINTR_REQ,
		&req,
		sizeof(req),
		pstate,
		sizeof(ULONG),
		&Tmp );

    return RetVal;
}

BOOL
GPINTR_GetPinResetValue(
    ULONG pin,
	ULONG *pval  )
{
    ULONG Tmp;
    BOOL RetVal;
	GPINTRREQ req;

	req.gpintr = pin;
	req.op = GPINTR_REQ_GET_RSTVAL;

	RetVal = KernelIoControl(
		IOCTL_OEM_GPINTR_REQ,
		&req,
		sizeof(req),
		pval,
		sizeof(ULONG),
		&Tmp );

    return RetVal;
}

//*****************************************************************************
// Copyright (c) 2009 RMI Corporation.  All rights reserved.
//
// Module Name:
//
//    normain.h
//
// Module Description:
//
//
//*****************************************************************************
#ifndef _NORMAIN_H_
#define _NORMAIN_H_

#include <windows.h>
#include <diskio.h>
#include <devload.h>
#include <pm.h>
#include <storemgr.h>

//----------------------------- Forward class references ----------------------
class FlashPddInterface;

//----------------------------- Debug zone information ------------------------
extern  DBGPARAM    dpCurSettings;

#define ZONE_INIT       DEBUGZONE(0)
#define ZONE_ERROR      DEBUGZONE(1)
#define ZONE_WRITE_OPS  DEBUGZONE(2)
#define ZONE_READ_OPS   DEBUGZONE(3)
#define ZONE_ERASE_OPS  DEBUGZONE(4)
#define ZONE_FUNCTION   DEBUGZONE(5)
#define ZONE_TEST       DEBUGZONE(6)

//-----------------------------------------------------------------------------
#include "FlashPdd.h"


//------------------------------- Public Interface ----------------------------
extern "C" 
{
DWORD NorPdd_Init(DWORD Context);
BOOL  NorPdd_Deinit(DWORD Context);
DWORD NorPdd_Open(DWORD Data, DWORD Access, DWORD ShareMode);
BOOL  NorPdd_Close(DWORD Handle);
DWORD NorPdd_Read(DWORD Handle, LPVOID pBuffer, DWORD NumBytes);
DWORD NorPdd_Write(DWORD Handle, LPCVOID pBuffer, DWORD InBytes);
DWORD NorPdd_Seek(DWORD Handle, long Distance, DWORD MoveMethod);
BOOL  NorPdd_IoControl(DWORD Handle, DWORD IoControlCode, PBYTE pInBuf,
						 DWORD InBufSize, PBYTE pOutBuf, DWORD OutBufSize,
						 PDWORD pBytesReturned);
VOID  NorPdd_PowerUp();
VOID  NorPdd_PowerDown();
}

//-----------------------------------------------------------------------------
#ifdef DEBUG

#define ReportError(Printf_exp) \
    DEBUGMSG(ZONE_ERROR,Printf_exp); \

#else

#define ReportError(Printf_exp) \
    RETAILMSG(ZONE_ERROR,(TEXT("Nor PDD Error: Function: %S,  Line: %d"), __FUNCTION__, __LINE__)); \

#endif

//-----------------------------------------------------------------------------

#endif _NORMAIN_H_



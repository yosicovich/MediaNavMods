//*****************************************************************************
// Copyright (c) 2009 RMI Corporation.  All rights reserved.
//
// Module Name:
//
//    norpdd.h
//
// Module Description:
//
//    NOR Flash implementation for RMI DbAu13xx boards
//
//*****************************************************************************
#include <bceddk.h>
#include <intsafe.h> // data conversion functions
#include <platform.h>
#include <db13xx.h>
#include <norflash.h>
#include <norpdd.h>
#include <fmd.h> // for SectorInfo definition

// For debugging purposes. 
// WARNING: enabling this test will cause the contents of the NOR Flash
// device to be erased completely.  All data stored on system Flash section
// of the NOR will be lost.
//#define FLASH_READ_WRITE_ERASE_TEST
#ifdef FLASH_READ_WRITE_ERASE_TEST
#define FLASH_READ_WRITE_ERASE_TEST_START_BLOCK 0x0
#define FLASH_READ_WRITE_ERASE_TEST_END_BLOCK DBAU13XX_SYSTEMFLASH_BLOCKCOUNT
#endif

//#undef DEBUGMSG
//#define DEBUGMSG(c,m) RETAILMSG(c,m)

UCHAR ucDataBuffer[TOTAL_SECTOR_SIZE_BYTES];

// Set up a pointer to the CPLD register so we can check
// the status of the FLASH_BUSY signal after writing/erasing
// the NOR flash.
BCSR * pCPLDRegs = (BCSR *)BCSR_KSEG1_ADDR;


NorFlashPdd::NorFlashPdd()
{
	ULONG ulBlockCount;

	memset ((void*)&m_RegionInfo, 0, sizeof(FLASH_REGION_INFO));

	// Set up the NOR Flash region flags.
	m_RegionInfo.FlashFlags = (FLASH_FLAG_NOR | FLASH_FLAG_SUPPORTS_LOCKING /*| FLASH_FLAG_SUPPORTS_XIP */);

	m_RegionInfo.StartBlock = 0;
    m_RegionInfo.BlockCount = (ULONGLONG)(0x00000000FFFFFFFF & DBAU13XX_SYSTEMFLASH_BLOCKCOUNT);    
	m_RegionInfo.SectorsPerBlock = 252;

	// Get the sector size
    m_RegionInfo.DataBytesPerSector = 512;
    
	m_RegionInfo.PageProgramLimit = 1;
    m_RegionInfo.BadBlockHundredthPercent = 100;

	// the OEM reserved field in the SectorInfo
	m_RegionInfo.SpareBytesPerSector = SIZE_OF_SECTOR_METADATA_BYTES - sizeof(NOR_PDD_SECTOR_INFO);

	ULongLongToULong(m_RegionInfo.BlockCount, &ulBlockCount);

	// print out some geometry information about this Flash device during initialization.
	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: Flash Size: 0x%x\r\n"), DBAU13XX_SYSTEMFLASH_SIZE));
	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: Flash Width: 0x%x\r\n"), FLASH_WIDTH));
	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: Flash Banks: 0x%x\r\n"), FLASH_BANKS));
	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: Flash Base Address (Physical): 0x%x\r\n"), DBAU13XX_SYSTEMFLASH_BASE));
	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: Flash Base Address (KSEG1): 0x%x\r\n"), FLASH_BASE_KSEG1));
	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: Flash Block Count: 0x%x \r\n"), ulBlockCount));
	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: Flash Block Size: 0x%x bytes\r\n"), DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES));
	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: Flash Sector Size (Data): 0x%x bytes\r\n"), m_RegionInfo.DataBytesPerSector));
	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: Flash Sector Size (Sector Info): 0x%x bytes\r\n"), m_RegionInfo.SpareBytesPerSector));
	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: Flash Sectors per Block: 0x%x\r\n"), m_RegionInfo.SectorsPerBlock));
}

// TEO: TODO: should query the device to determine block size and count,
// and to confirm the device ID. That could be done in init, or could be done
// in the class constructor.
LRESULT NorFlashPdd::Init(DWORD Context)
{
    LRESULT Result = ERROR_SUCCESS;
#ifdef FLASH_READ_WRITE_ERASE_TEST
	ULONG ulIndex;
#endif

    
    DEBUGMSG(ZONE_INIT,(TEXT("NOR Flash PDD: NorFlashPdd::Init()\r\n")));

    Result = GetRegionInfoTable (1, &m_RegionInfo);

#ifdef FLASH_READ_WRITE_ERASE_TEST
	// TEO: For low level debugging purposes, a simple test to check if
	// NOR Flash read/write/erase operations are successful.
	// Before releasing this code, remove these calls, and probably
	// the test function, too.
	// Test one sector on bank 0, and one sector on bank 1
	DEBUGMSG(ZONE_TEST,(TEXT("Sector Read/Write/Erase Test For Sectors 0x%x through 0x%x\r\n"),
		               FLASH_READ_WRITE_ERASE_TEST_START_BLOCK, FLASH_READ_WRITE_ERASE_TEST_END_BLOCK));
	for(ulIndex = 0;
		ulIndex < (FLASH_READ_WRITE_ERASE_TEST_END_BLOCK - FLASH_READ_WRITE_ERASE_TEST_START_BLOCK);
		ulIndex++)
	{
		BlockReadWriteEraseTest(ulIndex + FLASH_READ_WRITE_ERASE_TEST_START_BLOCK);
	}
	DEBUGMSG(ZONE_TEST,(TEXT("Sector Read/Write/Erase Test Complete\r\n")));
#endif

	// TEO: TODO: Create a table of reserved blocks which should be a member
	// of the norpdd class. This is initialized during init, and referenced
	// in calls to SetBlockStatus/GetBlockStatus.

    return Result;
}

LRESULT NorFlashPdd::Deinit()
{
    DEBUGMSG(ZONE_INIT,(TEXT("NOR Flash PDD: NorFlashPdd::Deinit()\r\n")));
    BOOL Result = ERROR_SUCCESS;   
    return BoolToWin32Result(Result);
}

LRESULT NorFlashPdd::GetRegionCount (
    OUT DWORD* pRegionCount)
{
    DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::GetRegionCount()\r\n")));

	*pRegionCount = 1;
    return ERROR_SUCCESS;
}


LRESULT NorFlashPdd::GetRegionInfoTable (
    IN DWORD RegionCount,
    OUT FLASH_REGION_INFO RegionInfoList[])
{
    LRESULT Result = ERROR_SUCCESS;

    DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::GetRegionInfoTable()\r\n")));

	if (RegionCount != 1)
    {
        Result = ERROR_INVALID_PARAMETER;
        goto exit;
    }

	memcpy(RegionInfoList, &m_RegionInfo, sizeof(FLASH_REGION_INFO));

exit:    
	return Result;
}
    
LRESULT NorFlashPdd::GetBlockStatus (
    IN BLOCK_RUN BlockRun, 
    IN BOOL IsInitialFlash,
    OUT ULONG BlockStatusList[])
{
    LRESULT Result = ERROR_SUCCESS;

	ULONG ulBlock;
	
	// For now just return that the block is good, not reserved, and not bad.
	// TEO:TODO: during initialization, a reserved block table should be set 
	// up as a member of the norpdd class.  Check this table to determine  
	// if the block is reserved.NOR blocks are never bad, so no need to
	// check for this.
	for(ulBlock = 0; ulBlock < BlockRun.BlockCount; ulBlock++)
	{
        BlockStatusList[ulBlock] = 0;
	}

    return Result;
}

LRESULT NorFlashPdd::SetBlockStatus (
    IN BLOCK_RUN BlockRun, 
    IN ULONG BlockStatus)
{
    LRESULT Result = ERROR_SUCCESS;

    DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::SetBlockStatus()\r\n")));

	// TODO: during initialization, a reserved block table should be set up as a member
	// of the norpdd class.  Set up an item in this table if the block is marked as reserved.
	// Block should never be marked as bad since this is a NOR device.
	return Result;
}

LRESULT NorFlashPdd::ReadPhysicalSectors (
    IN ULONG TransferCount, 
    IN OUT FLASH_PDD_TRANSFER ReadList[],
    OUT ULONG* pReadStatus)
{
    LRESULT Result = ERROR_SUCCESS;
	ULONG ulTxIndex;
	ULONG ulSector;
	ULONG ulStartSector;
	ULONG ulBaseAddress;
	BYTE * pDataBuffer;
	BYTE * pSpareBuffer;
	
    DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::ReadPhysicalSectors()\r\n")));
	DEBUGMSG(ZONE_READ_OPS,(TEXT("ReadPhysicalSectors(): Transfer Count: 0x%x\r\n"), TransferCount));

	for(ulTxIndex = 0; ulTxIndex < TransferCount; ulTxIndex++)
	{
		// Convert the Start sector for ULONGLONG to ULONG.
		ULongLongToULong(ReadList[ulTxIndex].SectorRun.StartSector, &ulStartSector);

		DEBUGMSG(ZONE_READ_OPS,(TEXT("ReadPhysicalSectors(): Sector Start: 0x%x, Sector Count:0x%x\r\n"),
			                       ulStartSector, ReadList[ulTxIndex].SectorRun.SectorCount));

		// Get a pointer to the data buffer for this transfer.
		pDataBuffer = ReadList[ulTxIndex].pData;
		pSpareBuffer = ReadList[ulTxIndex].pSpare;

		for(ulSector = 0;
			ulSector < ReadList[ulTxIndex].SectorRun.SectorCount;
			ulSector++)
		{			
			// Get the Sector base address
			ulBaseAddress = GetSectorAddress(ulSector + ulStartSector);

			DEBUGMSG(ZONE_READ_OPS,(TEXT("ReadPhysicalSectors(), Sector Addr: 0x%x\r\n"), ulBaseAddress));

			if(pDataBuffer)
			{
				// Read the Sector data
				if (!Nor_ReadFlash( (pDataBuffer + (ulSector * m_RegionInfo.DataBytesPerSector ) ),
								    ulBaseAddress,
								   m_RegionInfo.DataBytesPerSector ) ) 
					return ERROR_READ_FAULT;
			}

            if(pSpareBuffer)
			{
				// Update the address to read from.
				ulBaseAddress += m_RegionInfo.DataBytesPerSector + sizeof(NOR_PDD_SECTOR_INFO);

				// Read the sector info bytes
				if (!Nor_ReadFlash((pSpareBuffer + (ulSector * m_RegionInfo.SpareBytesPerSector)),
								   ulBaseAddress,
								   m_RegionInfo.SpareBytesPerSector)) 
					return ERROR_READ_FAULT;
			}
		}
	}

	// No ECC required for NOR, so set this to 0.
	//*pReadStatus = 0;

    return Result;    
}

LRESULT NorFlashPdd::WritePhysicalSectors (
    IN ULONG TransferCount, 
    IN FLASH_PDD_TRANSFER WriteList[],
    OUT ULONG* pWriteStatus)
{
    LRESULT Result = ERROR_SUCCESS;
   	ULONG ulTxIndex;
	ULONG ulSector;
	ULONG ulIndex;
	ULONG ulStartSector;
	ULONG ulBaseAddress;
	UCHAR * pucSpare;
	UCHAR * pucLocal;
	BYTE * pDataBuffer;
	BYTE * pSpareBuffer;
 
    DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::WritePhysicalSectors()\r\n")));
	DEBUGMSG(ZONE_WRITE_OPS,(TEXT("WritePhysicalSectors(): Transfer Count: 0x%x\r\n"), TransferCount));

	for(ulTxIndex = 0; ulTxIndex < TransferCount; ulTxIndex++)
	{
		// Convert the Start sector for ULONGLONG to ULONG.
		ULongLongToULong(WriteList[ulTxIndex].SectorRun.StartSector, &ulStartSector);

		DEBUGMSG(ZONE_WRITE_OPS,(TEXT("WritePhysicalSectors(): Sector Start: 0x%x, Sector Count:0x%x\r\n"),
	                    ulStartSector, WriteList[ulTxIndex].SectorRun.SectorCount));

		// Get a pointer to the data buffer for this transfer.
		pDataBuffer = WriteList[ulTxIndex].pData;
		pSpareBuffer = WriteList[ulTxIndex].pSpare;

		for(ulSector = 0;
			ulSector < WriteList[ulTxIndex].SectorRun.SectorCount;
			ulSector++)
		{
		    // Get the Sector base address
			ulBaseAddress = GetSectorAddress(ulSector + ulStartSector);

			DEBUGMSG(ZONE_WRITE_OPS,(TEXT("WritePhysicalSectors(), Sector Addr: 0x%x\r\n"), ulBaseAddress));

			if(pDataBuffer)
			{
				// Write the Sector data
				if (!Nor_WriteFlash(ulBaseAddress,
					                (pDataBuffer + (ulSector * m_RegionInfo.DataBytesPerSector)),
								    m_RegionInfo.DataBytesPerSector)) 
					return ERROR_WRITE_FAULT;
			}

			if(pSpareBuffer)
			{
				ulBaseAddress += m_RegionInfo.DataBytesPerSector;
				pucLocal = ucDataBuffer;
				pucSpare = (UCHAR*)(pSpareBuffer + (ulSector * m_RegionInfo.SpareBytesPerSector));

				// Read the sector info bytes into the local buffer
				for(ulIndex = 0; ulIndex < sizeof(NOR_PDD_SECTOR_INFO); ulIndex++)
				{
					*(pucLocal) = Nor_ReadFlashByte( ulBaseAddress + ulIndex );
					pucLocal++;
				}

				// copy the spare bytes into the local buffer
				for(ulIndex = 0; ulIndex < m_RegionInfo.SpareBytesPerSector; ulIndex++)
				{
					*(pucLocal) = *(pucSpare);
					pucLocal++;
					pucSpare++;
				}

				// Write the sector info bytes
				if (!Nor_WriteFlash(ulBaseAddress,
					                (ULONG*)(ucDataBuffer),
								    SIZE_OF_SECTOR_METADATA_BYTES)) 
					return ERROR_WRITE_FAULT;
			}
		}
	}

	// No ECC required for NOR, so set this to 0.
    //*pWriteStatus = 0;

	return Result;    
}

LRESULT NorFlashPdd::EraseBlocks (
    IN ULONG RunCount, 
    IN BLOCK_RUN BlockRunList[])
{
    LRESULT Result = ERROR_SUCCESS;
   	ULONG ulRunIndex;
	ULONG ulBlock;
	ULONG ulStartBlock;
	ULONG ulBaseAddress;
 
    DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::EraseBlocks()\r\n")));
	DEBUGMSG(ZONE_ERASE_OPS,(TEXT("EraseBlocks(): Erase Count: 0x%x\r\n"), RunCount));

	for(ulRunIndex = 0; ulRunIndex < RunCount; ulRunIndex++)
	{
		// Convert the Start block for ULONGLONG to ULONG.
		ULongLongToULong(BlockRunList[ulRunIndex].StartBlock, &ulStartBlock);

		DEBUGMSG(ZONE_ERASE_OPS,(TEXT("EraseBlocks(): Start Block: 0x%x, Count:0x%x\r\n"),
			                    ulStartBlock, BlockRunList[ulRunIndex].BlockCount));
		for(ulBlock = 0;
			ulBlock < BlockRunList[ulRunIndex].BlockCount;
			ulBlock++)
		{
			ulBaseAddress = (ulBlock * DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES) +
				            (ulStartBlock * DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES);
			DEBUGMSG(ZONE_ERASE_OPS,(TEXT("EraseBlocks(), Block Addr: 0x%x\r\n"), ulBaseAddress));

			// Erase the Block
			if (!Nor_EraseFlash(ulBaseAddress, DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES))
				return ERROR_WRITE_FAULT;
		}
	}

    return Result;    
}

LRESULT NorFlashPdd::CopyPhysicalSectors (
    IN ULONG TransferCount, 
    IN FLASH_PDD_COPY CopyList[])
{
    DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::CopyPhysicalSectors()\r\n")));

	return ERROR_NOT_SUPPORTED;
}

LRESULT NorFlashPdd::GetPhysicalSectorAddress (
    IN DWORD RegionIndex,
    IN SECTOR_RUN SectorRun, 
    OUT VOID* pPhysicalAddressList[])
{
    LRESULT Result = ERROR_SUCCESS;

	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::GetPhysicalSectorAddress()\r\n")));

    return Result;
}

LRESULT NorFlashPdd::LockBlocks (
    IN DWORD BlockRunCount,
    IN BLOCK_RUN BlockRunList[])
{
    LRESULT Result = ERROR_SUCCESS;

 	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::LockBlocks()\r\n")));

    return Result;
}

LRESULT NorFlashPdd::GetLifeCycleInfo (
    IN DWORD RegionCount,
    OUT FLASH_LIFE_CYCLE_INFO* pInfo)
{
 	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::GetLifeCycleInfo()\r\n")));
    return ERROR_NOT_SUPPORTED;
}

LRESULT NorFlashPdd::GetIdentityInfo (
    OUT FLASH_IDENTITY_INFO* pInfo)
{
   DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::GetIdentityInfo()\r\n")));
   return ERROR_NOT_SUPPORTED;
}


LRESULT NorFlashPdd::IoControl(
    DWORD IoControlCode,
    PBYTE pInBuf,
    DWORD InBufSize,
    PBYTE pOutBuf,
    DWORD OutBufSize,
    PDWORD pBytesReturned)
{
    LRESULT Result = ERROR_SUCCESS;
	DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): 0x%x\r\n"), IoControlCode));

	switch (IoControlCode)
	{
		case IOCTL_FMD_SET_XIPMODE:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_SET_XIPMODE\r\n")));
			break;
		case IOCTL_FMD_LOCK_BLOCKS:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_LOCK_BLOCKS\r\n")));
			break;
		case IOCTL_FMD_UNLOCK_BLOCKS:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_UNLOCK_BLOCKS\r\n")));
			break;
		case IOCTL_FMD_GET_INTERFACE:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_GET_INTERFACE\r\n")));
			break;
		case IOCTL_FMD_GET_XIPMODE:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_GET_XIPMODE\r\n")));
			break;
		case IOCTL_FMD_READ_RESERVED:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_READ_RESERVED\r\n")));
			break;
		case IOCTL_FMD_WRITE_RESERVED:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_WRITE_RESERVED\r\n")));
			break;
		case IOCTL_FMD_GET_RESERVED_TABLE:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_GET_RESERVED_TABLE\r\n")));
			break;
		case IOCTL_FMD_SET_REGION_TABLE:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_SET_REGION_TABLE\r\n")));
			break;
		case IOCTL_FMD_SET_SECTORSIZE:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_SET_SECTORSIZE\r\n")));
			break;
		case IOCTL_FMD_RAW_WRITE_BLOCKS:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_RAW_WRITE_BLOCKS\r\n")));
			break;
		case IOCTL_FMD_GET_RAW_BLOCK_SIZE:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_GET_RAW_BLOCK_SIZE\r\n")));
			break;
		case IOCTL_FMD_GET_INFO:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): IOCTL_FMD_GET_INFO\r\n")));
			break;
		default:
			DEBUGMSG(ZONE_FUNCTION,(TEXT("NOR Flash PDD: NorFlashPdd::IoControl(): UNKNOWN\r\n")));
			break;
	}

	return ERROR_NOT_SUPPORTED;
}                                                                             

LRESULT NorFlashPdd::BoolToWin32Result (BOOL Result)
{
    if (Result)
    {
        return ERROR_SUCCESS;
    }
    else
    {
        DWORD LastError = GetLastError();
        if (LastError != ERROR_SUCCESS)
        {
            return LastError;
        }
        else
        {
            return ERROR_GEN_FAILURE;
        }
    }
}

ULONG NorFlashPdd::GetSectorAddress( ULONG Sector )
{
    ULONG ulSectorAddr;
	ULONG ulBlock;

	DEBUGMSG(ZONE_WRITE_OPS,(TEXT("NOR Flash PDD: NorFlashPdd::GetSectorAddress() Sector: 0x%x\r\n"), Sector));

	// Determine the Block number
	ulBlock = (ULONG)(Sector / m_RegionInfo.SectorsPerBlock);

	// Calculate the block address.
	ulSectorAddr = ulBlock * m_RegionInfo.SectorsPerBlock *
		          TOTAL_SECTOR_SIZE_BYTES;

	// Now add the sector offset to the block address.
	ulSectorAddr += (Sector % m_RegionInfo.SectorsPerBlock) *
		          TOTAL_SECTOR_SIZE_BYTES;

	return ulSectorAddr;
}

BOOL NorFlashPdd::BlockReadWriteEraseTest(ULONG ulBlock)
{
	ULONG ulBaseAddress;
	ULONG ulAddressOffset;
	UCHAR ucDataByte = 0x33;
	ULONG ulIndex;
	ULONG ulBlockOffset;
	ULONG ulMismatchCount;

	// Get the Block base address
	ulBaseAddress = ulBlock * DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES;

	DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest(): Block 0x%x @ 0x%x\r\n"), ulBlock, ulBaseAddress));

	// Erase the block.
	if (!Nor_EraseFlash(ulBaseAddress, DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES))
	{
		DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest():ERASE @ 0x%x, Erase Failed\r\n"), ulBaseAddress));
	}
	else
	{
		ulMismatchCount = 0;

		for(ulBlockOffset = 0; ulBlockOffset < (DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES / 512); ulBlockOffset++)
		{
			// Clear the data buffer;
			memset ((void*)ucDataBuffer, 0, TOTAL_SECTOR_SIZE_BYTES);

			ulAddressOffset = ulBaseAddress + (ulBlockOffset * 512);

			// Read in a 512 byte chunk of the block
			if (!Nor_ReadFlash((PVOID)(ucDataBuffer),
							   ulAddressOffset,
							   512))
			{
				DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest():ERASE @ 0x%x, Read Failed\r\n"), ulBaseAddress));
			}
			else
			{
				// compare the data read from the sector.
				for(ulIndex = 0; ulIndex < 512; ulIndex++)
				{
					if(ucDataBuffer[ulIndex] != 0xFF)
					{
						//DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest():ERASE @ 0x%x, Data Mismatch, Index=0x%x, value=0x%x\r\n"),
						//						 ulBaseAddress, ulIndex, ucDataBuffer[ulIndex]));
						ulMismatchCount++;
					}
				}
			}
		}

		if(ulMismatchCount)
		{
			DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest():ERASE 0x%x @ 0x%x, Data Mismatch in 0x%x bytes\r\n"),
									 ulBlock, ulBaseAddress, ulMismatchCount));
		}
	}

	// Set up the data buffer that will be written to the sector;
	for(ulIndex = 0; ulIndex < TOTAL_SECTOR_SIZE_BYTES; ulIndex++)
	{
		ucDataBuffer[ulIndex] = ucDataByte;
	}

	for(ulBlockOffset = 0; ulBlockOffset < (DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES / 512); ulBlockOffset++)
	{
		ulAddressOffset = ulBaseAddress + (ulBlockOffset * 512);

		// Write the Sector data
		if (!Nor_WriteFlash(ulAddressOffset,
							(PVOID)(ucDataBuffer),
							512)) 
		{
			DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest():WRITE @ 0x%x, Write Failed\r\n"), ulBaseAddress));
		}
	}

	ulMismatchCount = 0;

	for(ulBlockOffset = 0; ulBlockOffset < (DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES / 512); ulBlockOffset++)
	{

		// Clear the data buffer;
		memset ((void*)ucDataBuffer, 0, TOTAL_SECTOR_SIZE_BYTES);

		ulAddressOffset = ulBaseAddress + (ulBlockOffset * 512);

		// Read the Sector data
		if (!Nor_ReadFlash((PVOID)(ucDataBuffer),
						   ulAddressOffset,
						   512))
		{
			DEBUGMSG(ZONE_TEST,(TEXT("BlockReadWriteEraseTest():WRITE @ 0x%x, Read Failed\r\n"), ulBaseAddress));
		}
		else
		{
			// compare the data read from the sector.
			for(ulIndex = 0; ulIndex < 512; ulIndex++)
			{
				if(ucDataBuffer[ulIndex] != ucDataByte)
				{
					//DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest():WRITE @ 0x%x, Data Mismatch, Index=0x%x, value=0x%x\r\n"),
					//						 ulBaseAddress, ulIndex, ucDataBuffer[ulIndex]));
					ulMismatchCount++;
				}
			}
		}
	}

	if(ulMismatchCount)
	{
		DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest():WRITE 0x%x @ 0x%x, Data Mismatch in 0x%x bytes\r\n"),
								 ulBlock, ulBaseAddress, ulMismatchCount));
	}


	// Erase the block.
	if (!Nor_EraseFlash(ulBaseAddress, DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES))
	{
		DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest():ERASE2 @ 0x%x, Erase Failed\r\n"), ulBaseAddress));
	}
	else
	{
		ulMismatchCount = 0;

		for(ulBlockOffset = 0; ulBlockOffset < (DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES / 512); ulBlockOffset++)
		{
			// Clear the data buffer;
			memset ((void*)ucDataBuffer, 0, TOTAL_SECTOR_SIZE_BYTES);

			ulAddressOffset = ulBaseAddress + (ulBlockOffset * 512);

			// Read in a 512 byte chunk of the block
			if (!Nor_ReadFlash((PVOID)(ucDataBuffer),
							   ulAddressOffset,
							   512))
			{
				DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest():ERASE2 @ 0x%x, Read Failed\r\n"), ulBaseAddress));
			}
			else
			{
				// compare the data read from the sector.
				for(ulIndex = 0; ulIndex < 512; ulIndex++)
				{
					if(ucDataBuffer[ulIndex] != 0xFF)
					{
						//DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest():ERASE2 @ 0x%x, Data Mismatch, Index=0x%x, value=0x%x\r\n"),
						//						 ulBaseAddress, ulIndex, ucDataBuffer[ulIndex]));
						ulMismatchCount++;
					}
				}
			}
		}

		if(ulMismatchCount)
		{
			DEBUGMSG(ZONE_TEST,(TEXT("SectorReadWriteEraseTest():ERASE2 0x%x @ 0x%x, Data Mismatch in 0x%x bytes\r\n"),
									 ulBlock, ulBaseAddress, ulMismatchCount));
		}
	}

	return TRUE;
}

//*****************************************************************************
//
// Start of the low level NOR interface functions
//
//*****************************************************************************
/*++
Routine Description:
    Return the size of block, note that there are 2 flash parts in
    parallel.

Arguments:
    Block - Block number 
    
Return Value:
    Size in bytes of the block including both parts
--*/
static ULONG GetBlockSize( ULONG Block )
{
    ULONG BlockSize;

    if (Block < BOOTSECTOR_COUNT)
	{
        BlockSize = BOOTSECTOR_SIZE_BYTES; 
    }
	else
	{
        BlockSize = SECTOR_SIZE_BYTES;
    }

    return BlockSize * (FLASH_WIDTH/16);
}

/*++
Routine Description:
    Return the base address of a FLASH bank

Arguments:
	Bank   - Bank number (zero based)
    
Return Value:
    Base address of the FLASH bank
--*/
static ULONG GetBankBaseAddress( ULONG Bank )
{
	ULONG BankBase;

	BankBase = FLASH_BASE_KSEG1 + ((FLASH_SIZE/FLASH_BANKS) * Bank);

	return BankBase;
} 

/*++
Routine Description:
    Returns the FLASH bank containing the specified address

Arguments:
    Address - FLASH Address 
    
Return Value:
    FLASH bank containing Address
--*/
static ULONG AddressToBank( ULONG Address )
{
	int Bank;

	for (Bank=FLASH_BANKS-1; Bank>=0; Bank--)
	{
		if (Address >= GetBankBaseAddress(Bank))
		{
			break;
		}
	}

	return Bank;
}

/*++
Routine Description:
    Get the address of the specified block

Arguments:
	Bank   - Bank number (zero based)
    block - block number
        
Return Value:
    Address of the sector   
--*/
static ULONG GetBlockAddress( ULONG Bank, ULONG Block )
{
    ULONG BlockAddr;
	ULONG i;

	BlockAddr = GetBankBaseAddress(Bank);

	for (i=0; i<Block; i++)
	{
		BlockAddr += GetBlockSize(Block);
	}

	return BlockAddr;
}

/*++
Routine Description:
    Returns the FLASH bank and block containing the specified address

Arguments:
    Address - FLASH Address
	pBank   - pointer to ULONG to receive the Bank containing Address
	pBlock - pointer to ULONG to receive the block containing Address
    
Return Value:
--*/
static VOID AddressToBankAndBlock( ULONG Address,
                                    ULONG *pBank,
								    ULONG *pBlock )
{
	int Bank;
	ULONG Block;

	// Find the Bank number first
	for (Bank=FLASH_BANKS-1; Bank>=0; Bank--)
	{
		if (Address >= GetBankBaseAddress(Bank))
		{
			break;
		}
	}

	// Now work out the block number
	Block = 0;

	while (Address >= GetBlockAddress(Bank,Block))
	{
		Block++;
	}
	Block--;
	
	*pBank = Bank;
	*pBlock = Block;
}

/*++
Routine Description:
    IssueFlashCommand RESET/UNLOCK/ERASE/.....
        
Arguments:
    Command - command id
	Param1, Param2 - Command Dependent:
		CMDRESET:        Param1 - FLASH Bank
		CMDUNLOCK:       Param1 - FLASH Bank
		CMDERASESET:     Param1 - FLASH Bank
		CMDERASESECTOR:  Param1 - FLASH Bank
		                 Param2 - Sector
		CMDPROGRAM:      Param1 - FLASH Bank
		CMDWRITEBUFFER:  Param1 - Program Location
		                 Param2 - Word Count - 1. Present twice in 32bit word
		CMDCOMMITBUFFER: Param1 - Program Location
        
Return Value:
        NONE
        
--*/
static void IssueFlashCommand( ULONG Command, 
                               ULONG Param1, 
                               ULONG Param2 )
{
	ULONG Address; // will hold address of the flash

	switch (Command)
	{
		case CMDRESET:
			Address = GetBankBaseAddress(Param1);
			WRITE_FLASH(Address, AMD_RESET32);  // Set the Device to Read Mode
			break;

		case CMDUNLOCK:
			Address = GetBankBaseAddress(Param1);
			WRITE_FLASH(Address + LATCH_OFFSET1, AMD_UNLOCK1);
			WRITE_FLASH(Address + LATCH_OFFSET2, AMD_UNLOCK2);
			break;
            
		case CMDERASESET:
			Address = GetBankBaseAddress(Param1);
			WRITE_FLASH(Address + LATCH_OFFSET1, AMD_ERASESET);
			break;
        
		case CMDERASESECTOR:
			Address = GetBlockAddress(Param1,Param2);
			WRITE_FLASH(Address, AMD_ERASESECTOR); // issue erase sector command
			// check DQ7 (DATA# Polling) for erase complete.
			while(!(*(PULONG)(Address) & STATUS_DATAPOLL))
			{
			}
			break;
        
		case CMDPROGRAM:
			Address = GetBankBaseAddress(Param1);
			WRITE_FLASH(Address + LATCH_OFFSET1, AMD_PROGRAM);
			break;

		case CMDWRITEBUFFER:                
			WRITE_FLASH(Param1, AMD_PROGRAMBUFFER);
			WRITE_FLASH(Param1, Param2);      // word count - 1
			break;
                
		case CMDCOMMITBUFFER:
		{
			unsigned short * pusData = (unsigned short *)Param2;
			
			WRITE_FLASH(Param1, AMD_COMMITBUFFER);

			// During Embedded Programming, check DQ7 (DATA# Polling) for program complete.
			// while device is busy programming, DQ7 is the complement of the data value
			// written to the address. Upon completion, DQ7 is the value written at 
			// the address.
			while( (*(PUSHORT)(Param1) & STATUS_DATAPOLL) ==
				   (~(*pusData) & STATUS_DATAPOLL) )
			{
			}

			break;
		}

		default:
			break;
     }
}

/*++
Routine Description:
	Erases the specified Block

Arguments:
	Block - Block number to be erased (same as NOR sector)
	Bank   - Bank being worked on
    
Return Value:
	TRUE to indicate that erase command has been successfully erased
--*/
static BOOL EraseBlock( ULONG Bank, ULONG Block )
{
    IssueFlashCommand(CMDUNLOCK, Bank, 0); // issue unlock command // no data to write
    IssueFlashCommand(CMDERASESET, Bank, 0); //  // erase setup command
    IssueFlashCommand(CMDUNLOCK, Bank, 0);
    IssueFlashCommand(CMDERASESECTOR, Bank, Block); // issue erase sector command

    return TRUE;
}

/*++
Routine Description:
        ULONG GetFlashStatus(ULONG Address)
        
        Get the status of operations(write/erase) on the flash

Arguments:
        ULONG Address.. Address of the flash to check status
        
Return Value:
            STATUSREADY flash has completed an operation and is ready for new operation
            STATUSERASESUSPEND .. flash erase has been suspended
            STATUSTIMEOUT Time out
            STATUSBUSY  Busy
            STATUSERROR Error           
--*/
static ULONG GetFlashStatus( ULONG Address )
{
	ULONG NewRead, OldRead; // holds first and second consecutive flash reads
	ULONG Status;                //  holds dwFirstRead XOR dwSecondRead 
	ULONG LastTime = 0;
	ULONG Bank;
    ULONG StatusTimeoutValue = STATUS_TIMEOUTVALUE;

#if (FLASH_WIDTH==16)
	StatusTimeoutValue &= 0xFFFF;
#endif

	Bank = AddressToBank(Address);

    //
    // Two consecutive reads to check if bits are toggling
    //  

    OldRead = READ_FLASH(Address);
    NewRead = READ_FLASH(Address);    

    do
	{
        //
        // XOR to see if bits toggled
        //
        Status = OldRead ^ NewRead; 
        if (0 == (Status & STATUS_TOGGLEVALUE))
		{
            Status=STATUSREADY;
            break;
        }

        
        if ((NewRead & StatusTimeoutValue) == StatusTimeoutValue)
		{
        
            NewRead = READ_FLASH(Address);
            OldRead = READ_FLASH(Address);
            
            Status = OldRead ^ NewRead; 
            if (0 == (Status & STATUS_TOGGLEVALUE))
			{
                Status = STATUSREADY;
                break;
            }            
            RETAILMSG(1,(L"FLASH: Fail 0x%08X status 0x%X 0x%08X 0x%08X\r\n", Address,OldRead,NewRead,Status));            
            Status = STATUSTIMEOUT;
            
            IssueFlashCommand(CMDRESET,Bank,0);

            break;
        }
        
        OldRead = NewRead;
        NewRead = READ_FLASH(Address);
        

    } while (1);
 
    return Status;
}

/*
    Program an entire write buffers worth of data
*/
static BOOL FlashWriteBuffer( ULONG Location,
                               PVOID pSrcData,
                               ULONG ByteCount )
{
    ULONG Size;
    ULONG Data;
    BOOL Status = FALSE;
	ULONG Bank = AddressToBank(Location);
#if (FLASH_WIDTH==32)
	PULONG pData;
#elif (FLASH_WIDTH==16)
	PUSHORT pData;
#endif

	pData = (PUSHORT)pSrcData;

    if ((ByteCount & 3) || (0 == ByteCount))
	{
        RETAILMSG(1,(TEXT("Flash Write buffer requires a whole multiple of words\r\n")));
        return FALSE;
    }
        
    //
    // issue Program Command
    // The Write buffer is AMD_WRITE_BUFFER_SIZE entries deep
    // With 2 chips it is 32 bits wide
    Size = (ByteCount/(FLASH_WIDTH/8));
   
    IssueFlashCommand(CMDUNLOCK, Bank, 0);    
    IssueFlashCommand(CMDWRITEBUFFER, Location, Size-1 |( (Size-1) << 16));
    
    while (Size--)
	{
        WRITE_FLASH(Location, *pData);
        Location = Location + (FLASH_WIDTH/8);
        pData++;
    }

    // reset the location to the last location within the address range
	Location = Location - (FLASH_WIDTH/8);
	
	// Reset to data written to location above.
	pData--;
    
	IssueFlashCommand(CMDCOMMITBUFFER, Location, (ULONG)pData);
                   
    //
    // wait until flash is ready to accept new command
    //
    Data = GetFlashStatus(Location);
	   
    if (Data  == STATUSTIMEOUT)
	{
        Status = FALSE;        
        RETAILMSG(1,(TEXT("Flash Write timeout at %X \r\n"), Location));
    }
	else
	{
        Status = TRUE;
    }

    return Status;
}

/*++
Routine Description:
        Writes ULONG to the flash at specified offset.
Arguments:
        ULONG Offset    Bytes Offset from flash base
        ULONG dwData    Data to be written 
        
Return Value:
        TRUE to indicate that flash location has been successfully written  
--*/
static BOOL FlashWrite32( ULONG Location,
                           ULONG dwData )
{
	ULONG Bank = AddressToBank(Location);
	int i;

	// Loop through two 16bit values if the
	// FLASH is 16bits wide.
	for (i=0;i<(32/FLASH_WIDTH);i++)
	{

		// issue Program Command
		IssueFlashCommand(CMDUNLOCK, Bank, 0);
		IssueFlashCommand(CMDPROGRAM, Bank, 0);    

		WRITE_FLASH(Location, dwData);

		while (GetFlashStatus(Location) != STATUSREADY)
		{
			;
		}

		// These two lines are only really doing anything useful
		// when we have 16bit wide FLASH
		Location = Location + (FLASH_WIDTH/8);
		dwData = dwData >> FLASH_WIDTH;
	}

    return TRUE;
}

//*****************************************************************************
//
// The following functions are called by the NorPdd class functions.
//
//*****************************************************************************

BOOL Nor_LockFlash( PVOID Address, 
                ULONG Size )
{
    return TRUE;
}


BOOL Nor_UnlockFlash( PVOID Address, 
                  ULONG Size )
{
    return TRUE;
}

/*++
Routine Description:
    Erase the Flash memory starting at the specified address, for the 
	length specified
    
Arguments:
    ULONG Address       - Offset from base of flash to begin erase
    ULONG Size          - Size in bytes of the region to be erased 
    
Return Value:
        TRUE to indicate that data buffer has been successfully copied
        
--*/
BOOL  Nor_EraseFlash( ULONG Address, 
                      ULONG Size )
{
    ULONG Block;
	ULONG Bank;
	ULONG EndAddress;
	ULONG CurrentAddress;
	ULONG Status;
	ULONG i;

	// Check parameters...
	if (Address+Size-1 > DBAU13XX_SYSTEMFLASH_SIZE)
	{
		RETAILMSG(1,(TEXT("Paramters Address 0x%X and Size 0x%X invalid. System Flash Size is 0->0x%X\r\n"),
		                       Address,Size,DBAU13XX_SYSTEMFLASH_SIZE-1));
		return FALSE;
	}

    Address += FLASH_BASE_KSEG1;
	EndAddress = Address + Size - 1;
	CurrentAddress = Address;
    
    //
    // erase the sectors in this range
    //
    DEBUGMSG(ZONE_ERASE_OPS,(L"Erasing from 0x%x to 0x%x\r\n",
            Address,
            EndAddress));
            
	for (i=0;i<FLASH_BANKS;i++)
	{
		IssueFlashCommand(CMDRESET, i, 0);
		IssueFlashCommand(CMDRESET, i, 0);
	}

	do
	{
		AddressToBankAndBlock(CurrentAddress, &Bank, &Block);

        EraseBlock(Bank, Block);

		CurrentAddress += GetBlockSize(Block);
	}
	while (CurrentAddress < EndAddress);

    Status = GetFlashStatus(CurrentAddress);
		
	if(Status != STATUSREADY)
	{
		RETAILMSG(1,(TEXT("Erase status failure: 0x%X\r\n"),Status));
	}

    return (Status==STATUSREADY);
}

/*++
Routine Description:
    write buffer to the flash from given memory location.
	No attempt is made to verify content.
    
Arguments:
    ULONG TargetOffset  - Offset from base of flash to begin
    PVOID SourceData    - Source buffer 
    ULONG Size          - The source buffer length in bytes, 
                            must be multiple of 4
    
Return Value:
        TRUE to indicate that data buffer has been successfully copied
        
--*/
BOOL Nor_WriteFlash( ULONG TargetOffset,
                     PVOID SourceData,
                     ULONG Size )
{
    BOOL Status = TRUE;
    PULONG SrcWords = (PULONG)SourceData;
    ULONG i;
    ULONG Target = TargetOffset + FLASH_BASE_KSEG1; // DBAU13XX_SYSTEMFLASH_BASE;
	ULONG Bank = AddressToBank(Target);
	ULONG tmp;
	ULONG ulNotErasedCount = 0;
    
	// Check parameters...
    if (DBAU13XX_SYSTEMFLASH_SIZE < (TargetOffset+Size))
	{


        RETAILMSG(1,(L"WriteFlash: Bounds check failure(0x%x, 0x%x, 0x%x)\r\n",
                TargetOffset,
                SourceData,
                Size));
        
        Status = FALSE;
        goto ErrorReturn;    
    }
    

    //
    // Round up to whole word
    //
    if (Size & 0x3)
	{
        Size += Size % 4;
    }
	
	DEBUGMSG(ZONE_WRITE_OPS,(L"Writing @ 0x%08x, Size 0x%0x\r\n",Target, Size));

    
    IssueFlashCommand(CMDRESET, Bank, 0);
        
    //
    // Firstly check that it is erased
    //
    for (i=0;i<Size;i++)
	{
        if (0xff != (tmp=*(PUCHAR)(Target+i)))
		{
			ulNotErasedCount++;
			//RETAILMSG(1,(TEXT("Flash not erased at 0x%08X (%02X)\r\n"),Target+i,tmp));
			//Status=FALSE;
			//goto ErrorReturn;
        }
    }

	if(ulNotErasedCount)
	{
		RETAILMSG(1,(TEXT("Nor_WriteFlash(): Start 0x%x, size 0x%x:  0x%0X bytes not erased\r\n"),
			        Target, Size, ulNotErasedCount));		
		Nor_EraseFlash(TargetOffset, Size);
	}

    //
    // Get to next buffer boundary
    //
    while (Size && (Target & (AMD_WRITE_BUFFER_SIZE-1)) && Status)
	{
        
		DEBUGMSG(ZONE_WRITE_OPS,(TEXT("Adjusting to buffer boundary 0x%08X, 0x%x:0x%x\r\n"),Target, SrcWords, *SrcWords));
        Status = FlashWrite32(Target, *SrcWords);
        
		if (!Status)
		{
			RETAILMSG(1,(TEXT("FLASH: Write failure at 0x%x\r\n"), Target));
		}

		Size -= 4;
        Target += 4;
        SrcWords++;
    }

    IssueFlashCommand(CMDRESET, Bank, 0);

    while (Size && Status)
	{
        ULONG CopySize;

        // AMD_WRITE_BUFFER_SIZE specifies the number of bytes of write buffer
        CopySize = min(Size, AMD_WRITE_BUFFER_SIZE);

        Status = FlashWriteBuffer(Target, SrcWords, CopySize);
        
        Size -= CopySize;
        Target += CopySize;
        SrcWords = &SrcWords[CopySize/4];
    }

ErrorReturn:
    RETAILMSG(!Status, (L"Flash write Error\r\n"));
        
    return Status;
}

/*++
Routine Description:
    read a byte of data from the specified Flash address.
    
Arguments:
    ULONG SourceOffset  - Offset from base of flash to begin reading
    
Return Value:
        Returns the byte of data read from the Flash
        
--*/					 
BYTE Nor_ReadFlashByte( ULONG SourceOffset )
{
	ULONG Bank;

    SourceOffset += FLASH_BASE_KSEG1;

	Bank = AddressToBank(SourceOffset);
    
    IssueFlashCommand(CMDRESET, Bank, 0);

    return *(PUCHAR)SourceOffset;
}


/*++
Routine Description:
    read data from the specified Flash address into the supplied buffer.
    
Arguments:
    ULONG SourceOffset  - Offset from base of flash to begin reading
    PVOID Target        - destination buffer 
    ULONG Size          - The destination buffer length in bytes, 
                            must be multiple of 4
    
Return Value:
        TRUE to indicate that data buffer has been successfully copied
        
--*/
BOOL Nor_ReadFlash( PVOID Target, 
                    ULONG SourceOffset, 
                    ULONG Size )
{
    BOOL Status=TRUE;
    PUCHAR TargetChar = (PUCHAR)Target;
	ULONG Bank;
	ULONG ulOffset;

	ulOffset = SourceOffset + FLASH_BASE_KSEG1;
	DEBUGMSG(ZONE_READ_OPS,(L"Reading @ 0x%08x, Size 0x%0x\r\n",ulOffset, Size));

	Bank = AddressToBank(ulOffset);
    
	IssueFlashCommand(CMDRESET, Bank, 0);
    
	while (Size--)
	{
		TargetChar[Size] = *(PUCHAR)(ulOffset+Size);
	}

    return Status;
}






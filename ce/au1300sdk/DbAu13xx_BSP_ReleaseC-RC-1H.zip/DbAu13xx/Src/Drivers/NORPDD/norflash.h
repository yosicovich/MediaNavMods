//*****************************************************************************
// Copyright (c) 2009  RMI Corporation.  All rights reserved.
//
// Module Name:
//
//    norflash.h
//
// Module Description:
//
//    NOR Flash information for RMI DbAu13xx boards
//
// Based on file flash.h
// Copyright (c) 2002-2005  BSQUARE Corporation.  All rights reserved.
//
//*****************************************************************************

//*****************************************************************************
// Definitions
//*****************************************************************************

#ifndef __NORFLASH_H__
#define __NORFLASH_H__

#include "bceddk.h"

 // DbAu13xx boards
#define SECTOR_SIZE_BYTES		0x20000
#define BOOTSECTOR_COUNT		0
#define BOOTSECTOR_SIZE_BYTES	0
#define AMD_WRITE_BUFFER_SIZE   (16*(FLASH_WIDTH/8))
#define BLOCK_COUNT             0x100
#define BLOCK_SIZE_BYTES        SECTOR_SIZE_BYTES 
#define NOR_FLASH_SIZE          FLASH_SIZE // 64 MB

//
// Flash on the DBAU13XX is broken down into three sections, System Flash, Monitor Flash,
// and File Flash. Monitor Flash is used to hold applications like Yamon, and/or eBoot,
// and should not be overwritten.  File Flash holds persistent data used by the Monitor
// application.  System Flash is the region of NOR Flash that is available for 
// use by Windows CE.
//
#define DBAU13XX_SYSTEMFLASH_BASE               FLASH_BASE   // (0x20000000 - FLASH_SIZE)
// 
// 4MB at top of Flash used for a monitor applicatin (Yamon, eBOOT)
// and persistent data used by the monitor application.
//
#define DBAU13XX_SYSTEMFLASH_SIZE              (NOR_FLASH_SIZE - 0x00400000) 
#define DBAU13XX_SYSTEMFLASH_SECTORSIZE        SECTOR_SIZE_BYTES
#define DBAU13XX_SYSTEMFLASH_BANKCOUNT         FLASH_BANKS
#define DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES   BLOCK_SIZE_BYTES
#define DBAU13XX_SYSTEMFLASH_BLOCKCOUNT        (DBAU13XX_SYSTEMFLASH_SIZE/DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES)
#define DBAU13XX_SYSTEMFLASH_BLOCKSIZE_SECTORS (DBAU13XX_SYSTEMFLASH_BLOCKSIZE_BYTES/DBAU13XX_SYSTEMFLASH_SECTORSIZE)

//
// Location of FLASH
//
#define FLASH_BASE_KSEG1        (FLASH_BASE + KSEG1_OFFSET)

//
// Read flash/Write flash macros
//
#if (FLASH_WIDTH==32)

 #define WRITE_FLASH(Addr,Value) \
	do {                                                  \
		*(volatile unsigned long * const)(Addr) = (Value); \
		__asm("sync");                                    \
	} while(0)  /* (trailing ; supplied by caller) */

 #define READ_FLASH(Addr) \
	*(volatile unsigned long * const)(Addr)

#elif (FLASH_WIDTH==16)

 #define WRITE_FLASH(Addr,Value) \
	do {                                                  \
		*(volatile unsigned short * const)(Addr) = (USHORT)((Value)&0xFFFF); \
		__asm("sync");                                    \
	} while(0)  /* (trailing ; supplied by caller) */

 #define READ_FLASH(Addr) \
	*(volatile unsigned short * const)(Addr)

#else
 #error Flash Width must be either 16 or 32
#endif

#define READ_FLASH_ULONG(Addr) \
	*(volatile unsigned long * const)(Addr)

#define OFFSET_MANUFACTURER_ID 0
#define OFFSET_DEVICE_ID       4

//
// Flash Commands
//
#define  CMDRESET               0x1000
#define  CMDUNLOCK              0x1001
#define  CMDAUTOSELECT          0x1002
#define  CMDERASESET            0x1003
#define  CMDERASESECTOR         0x1004
#define  CMDSUSPENDERASE        0x1005
#define  CMDRESUMEERASE         0x1006
#define  CMDPROGRAM             0x1007
#define  CMDUNLOCKBYPASSSET     0x1008
#define  CMDUNLOCKBYPASSRESET   0x1009
#define  CMDCHIPERASE           0x1010
#define  CMDREADIDCODES         0x1011
#define  CMDCLEARSTATUS         0x1012
#define  CMDREADSTATUS          0x1013
#define  CMDWRITEWORD           0x1014
#define  CMDWRITEBUFFER         0x1015
#define  CMDCOMMITBUFFER        0x1016

//
// AMD/Spansion Specifics
//
#define LATCH_OFFSET1			(0x555 * (FLASH_WIDTH/8))
#define LATCH_OFFSET2			(0x2AA * (FLASH_WIDTH/8))
#define LATCH_UNLOCKBYPASS		(0xBA * (FLASH_WIDTH/8))
#define AMD_UNLOCK1 0x00AA00AA
#define AMD_UNLOCK2 0x00550055

//
// Flash status
//
#define STATUSREADY         100
#define STATUSERASESUSPEND  101
#define STATUSTIMEOUT       102
#define STATUSBUSY          103
#define STATUSERROR         104

// 
// defines for GetFlashStatus() function
//
#define STATUS_READY            0x00000000
#define STATUS_WRITE2BUFABORT   0x00020002 // DQ1
#define STATUS_ERASESUSPEND     0x00040004 // DQ2
#define STATUS_ERASESTART		0x00080008 // DQ3
#define STATUS_TIMEOUTVALUE     0x00200020 // DQ5
#define STATUS_TOGGLEVALUE      0x00400040 // DQ6 - toggle bit one
#define STATUS_DATAPOLL         0x00800080 // DQ7 - DATA# Polling

#define AMD_AUTOSELECT32        0x00900090
#define AMD_RESET32             0x00F000F0
#define AMD_ERASESET            0x00800080
#define AMD_ERASESECTOR         0x00300030
#define AMD_SUSPENDERASE        0x00B000B0
#define AMD_RESUMEERASE         0x00300030
#define AMD_PROGRAM             0x00A000A0
#define AMD_PROGRAMBUFFER       0x00250025
#define AMD_UNLOCKBYPASS        0x00200020
#define AMD_UNLOCKBYPASSPROGRAM 0x00A000A0
#define AMD_UNLOCKBYPASSRESET1  0x00900090
#define AMD_UNLOCKBYPASSRESET2  0x00000000
#define AMD_CHIPERASE           0x00100010
#define AMD_COMMITBUFFER        0x00290029

#define FLASH_TIMEOUT_PERIOD            3

//
// erased location value
//
#define FLASH_ERASE_VALUE       0xFF

//*****************************************************************************
// API Function prototypes
//*****************************************************************************
ULONG Nor_GetSectorAddress( ULONG Bank, ULONG Sector );
BOOL Nor_EraseFlash( ULONG Address, ULONG Size );
BOOL Nor_WriteFlash( ULONG TargetOffset,
                     PVOID SourceData,
                     ULONG Size );
BYTE Nor_ReadFlashByte( ULONG SourceOffset );
BOOL Nor_ReadFlash( PVOID Target, 
                    ULONG SourceOffset, 
                    ULONG Size);

#endif  // _NORFLASH_H__
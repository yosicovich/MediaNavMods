//
// Copyright (c) Microsoft Corporation.  All rights reserved.
// Copyright (c) 2004,2005 BSQUARE Corporation. All rights reserved.
// Copyright (c) 2006,2007 Raza Microelectronics Inc. All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Module Name:    FMD.CPP

Abstract:       FLASH Media Driver for Db1550 Samsung K9F1208U0A based on
                driver for Samsung K9F2808UOB found in:
				\PUBLIC\COMMON\OAK\DRIVERS\BLOCK\MSFLASHFMD\SDNPCI\

-----------------------------------------------------------------------------*/

#define NAND_USE_DDMA
#define NAND_USE_HW_ECC
#define NAND_USE_INTERRUPTS

#include <windows.h>
#include <bceddk.h>
#include "platform.h"
#include "bsp.h"
#include <fmd.h>
#include <wdm.h>
#include <ddkreg.h>
#include "nand.h"
#include "ecc.h"

// #define NAND_BOOT 1

//  Flags and pointers
#define BADBLOCKMARK                0x00

DWORD NAND_ECC_TRIGGER_STALL = 0;

#define	NAND_HW_ECC_SECTOR_SIZE		2048
#define NAND_HW_ECC_SPARE_SIZE		12
#define NAND_HW_ECC_TOTAL_SIZE		(NAND_HW_ECC_SECTOR_SIZE + NAND_HW_ECC_SPARE_SIZE)

#undef DEBUGMSG
#define DEBUGMSG(c,m) RETAILMSG(1,m)


/******************************************************************
							Struct/Macros
******************************************************************/


/******************************************************************
							Globals
******************************************************************/
static PUCHAR IoAddr;
static DWORD  dwSysIntr = 0xFFFFFFFF;
HANDLE hInterruptEvent;
HANDLE hMutex;
static PNAND_DEVICE	pNandDev = NULL;
static AU1X00_STATIC *pStaticController = (AU1X00_STATIC*)(STATIC_MEM_PHYS_ADDR+KSEG1_OFFSET);

static BOOL SelectChip( UINT32 blk )
{
	BOOL retval = FALSE;
	return retval;
}

static void PrintRegs()
{
	DEBUGMSG(ZONE_INIT,(TEXT("NAND Registers:\r\n")));
	DEBUGMSG(ZONE_INIT,(TEXT("STCFG1:  %08x\r\n"), READ_REGISTER_ULONG((PULONG)&pStaticController->stcfg1)));
	DEBUGMSG(ZONE_INIT,(TEXT("STTIME1: %08x\r\n"), READ_REGISTER_ULONG((PULONG)&pStaticController->sttime1)));
	DEBUGMSG(ZONE_INIT,(TEXT("STADDR1: %08x\r\n"), READ_REGISTER_ULONG((PULONG)&pStaticController->staddr1)));
	DEBUGMSG(ZONE_INIT,(TEXT("STNDCTL: %08x\r\n"), READ_REGISTER_ULONG((PULONG)&pStaticController->stndctl)));
	DEBUGMSG(ZONE_INIT,(TEXT("STSTAT: %08x\r\n"), READ_REGISTER_ULONG((PULONG)&pStaticController->ststat)));
}

static void PrintStatus()
{
	DEBUGMSG(ZONE_INIT,(TEXT("MEM_STSTAT: %08x\r\n"), READ_REGISTER_ULONG((PULONG)&pStaticController->ststat)));
}

/*
	The following routines translate a UINT32 sector number into their
	appropriate byte stream for the NAND device.
*/
static UINT32 Addr_2col_3row( UINT32 SectorNumber, PUCHAR *addr, UINT32 isSpare ) {
	static UCHAR _addr[5];
	UINT32 row=0,col=0;

	/* Translate to block number */
	row = (UINT32)((UINT32)SectorNumber);

	/*
	 *	Always enable the proper chip selct when translating Sector Address
	 *     **** Convert to block id first
	 */
	if ( SelectChip(row/pNandDev->pages) )
		row -= (pNandDev->blocks*pNandDev->pages)/2;

	/* Since we only read sectors (ie pages) there is no need for a column
	 * address.  Unless we are trying to access just the spare location.  Per
	 * each 1Gx8bit NAND, there are 128 pages/block * 4096 blocks == 524288 For
	 * the second 1GB NAND addressing, A31 needs to be used to specify the
	 * device to be accessed.  */
	if ( isSpare ) {
		col = pNandDev->spare_offset;
#ifdef NAND_USE_HW_ECC
		/* Account for the 3 ECC words that are inserted in the main data area. */
		col+=13*3;
#endif
	}

	_addr[0] = col&0xFF;
	_addr[1] = ((col>>8)&0xFF);

	_addr[2] = (row&0xFF);
	_addr[3] = ((row>>8)&0xFF);
	_addr[4] = ((row>>16)&0xFF);

	/* Point to our address bytes */
	*addr = _addr;

	RETAILMSG(0,(TEXT("CTG:Addr_2col_3row:%d %02X %02X %02X %02X %02X\r\n"),
		SectorNumber,
		_addr[0],
		_addr[1],
		_addr[2],
		_addr[3],
		_addr[4]));

	return (UINT32)((UINT32)pNandDev->cols + (UINT32)pNandDev->rows);
}

/****************************************************************************/

VOID WaitForReady_IRQ()
{
	while (0 != WaitForSingleObject(hInterruptEvent, 1000)) {
		RETAILMSG(1,(TEXT("Waiting for NAND IRQ...\r\n")));
		PrintRegs();
	}

	InterruptDone(dwSysIntr);
}

VOID WaitForReady_Poll()
{
	volatile DWORD status = 0;
	int timeout = 10000;
	while((READ_REGISTER_ULONG((PULONG)&pStaticController->ststat) & MEM_STSTAT_BSY) != 0) {
		if (--timeout == 0) {
			RETAILMSG(0,(TEXT("WaitForReady timeout reached 0.  Moving on\r\n")));
			break;
		}
	}

	while((READ_REGISTER_ULONG((PULONG)&pStaticController->ststat) & MEM_STSTAT_BSY) == 0) {
		RETAILMSG(0,(TEXT(".")));
	}
}

VOID WaitForReady(ULONG ms_delay)
{
#ifdef NAND_USE_INTERRUPTS
	WaitForReady_IRQ();
#else
	WaitForReady_Poll();
#endif

	if (ms_delay > 0)
		Sleep(1000*ms_delay);
}


//  GetStatus()
//
//  Retrieve the status of the Chip.
//
UCHAR GetStatus()
{
    UCHAR Status;

    //  Issue read status command
    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_STATUS);

	Status = READ_REGISTER_UCHAR(NAND_DATA_PORT);
    return Status;
}

static void NAND_ResetECC()
{
	WRITE_REGISTER_UCHAR(NAND_ECC_RESET_PORT, 1);
}

static void NAND_EnableECC()
{
#ifdef NAND_USE_HW_ECC
	UINT32 stndctl;

	stndctl = READ_REGISTER_ULONG((PULONG)&pStaticController->stndctl);
	stndctl |= MEM_STNDCTRL_ECE;
    WRITE_REGISTER_ULONG((PULONG)&pStaticController->stndctl, stndctl);

	NAND_ResetECC();
#endif
}

static void NAND_DisableECC()
{
#ifdef NAND_USE_HW_ECC
	UINT32 stndctl;

	NAND_ResetECC();

	stndctl = READ_REGISTER_ULONG((PULONG)&pStaticController->stndctl);
	stndctl &= ~MEM_STNDCTRL_ECE;
    WRITE_REGISTER_ULONG((PULONG)&pStaticController->stndctl, stndctl);
#endif
}

/*
 * Set triggers to the number of consecutive 515 byte sectors to read - 1
 */
static void NAND_TriggerECC(int triggers)
{
	DWORD status_count = 0;

	WRITE_REGISTER_ULONG((PULONG)NAND_ECC_TRIGGER_PORT, triggers);

	if (NAND_ECC_TRIGGER_STALL > 0)
		OALStallExecution(NAND_ECC_TRIGGER_STALL);
}

static BOOL NAND_CheckECC(DWORD SectorNumber)
{
	UINT32 status;

	status = READ_REGISTER_ULONG((PULONG)&pStaticController->ststat);
	/*
	 * These bits do not appear to clear on write as they should. (but we'll try anyway)
	 */
	WRITE_REGISTER_ULONG((PULONG)&pStaticController->ststat, MEM_STSTAT_DF | MEM_STSTAT_SN);

	if (status & MEM_STSTAT_DF) {
		RETAILMSG(1,(TEXT("NAND: Decode failed for sector %d! (%08X)\r\n"), SectorNumber, status));
		return FALSE;
	} else if (status & MEM_STSTAT_SN) {
		DEBUGMSG(ZONE_WARNING,(TEXT("NAND: Syndrome not zero, %d errors corrected (%08X)\r\n"), ((status & MEM_STSTAT_NEC)>>8), status));
	} else
		RETAILMSG(0,(TEXT("NAND: Decode successful for sector %d\r\n"), SectorNumber));

	return TRUE;
}


static BOOL NAND_WriteSector_Raw( DWORD       SectorNumber,
                              PUCHAR      pSector,
                              PSectorInfo pSectorInfo,
                              PUCHAR      pECC )
{
    PUCHAR 	pInfoBuffer = (PUCHAR)pSectorInfo;
    UCHAR 	status;
    UINT32 	i;
	UCHAR	addrcnt, *addr;
	BOOL	isDirty=FALSE;

	if ( WAIT_OBJECT_0 != WaitForSingleObject(hMutex,5000) )
		RETAILMSG(1,(TEXT("WaitForSingleObject(hMutex,5000) failed %d\r\n"),__LINE__));
__try {
	addrcnt = pNandDev->pTranslateAddr(SectorNumber, &addr, pSector==NULL?1:0);
	RETAILMSG(0,(TEXT("Writing to sector %d\r\n"),SectorNumber));

	if ( pSectorInfo ) {
		if ( pSectorInfo->bBadBlock != 0xFF )
	        DEBUGMSG(ZONE_WARNING,(TEXT("WARNING: Setting BAD Block on sector %d, val:%X\r\n"),SectorNumber,pSectorInfo->bBadBlock));
	}

    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_WRITE);

	// Write our translated address to the controller
	for(i=0; i<addrcnt; i++)
		WRITE_REGISTER_UCHAR(NAND_ADDR_PORT, addr[i]);

	if (pSector) {
		for (i=0; i<pNandDev->pagesize; i++)
			WRITE_REGISTER_UCHAR(NAND_DATA_PORT,pSector[i]);
	}

	if (pInfoBuffer) {
		for (i=0; i<sizeof(SectorInfo); i++)
			WRITE_REGISTER_UCHAR(NAND_DATA_PORT,pInfoBuffer[i]);
	}

	// Instruct the Flash to commit the data to the media
    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_WRITE2);
	WaitForReady(0);

	status = GetStatus();
}	__finally  {
	ReleaseMutex(hMutex);
}
    if (status & STATUS_ERROR) {
        RETAILMSG(1,(TEXT("Error writing sector %d\r\n"),SectorNumber));
        return FALSE;
    }

    return TRUE;
}

#ifdef NAND_USE_HW_ECC
static BOOL NAND_WriteSector_ECC( DWORD       SectorNumber,
                              PUCHAR      pSector,
                              PSectorInfo pSectorInfo,
                              PUCHAR      pECC )
{
    PDWORD 	pdInfoBuffer = (PDWORD)pSectorInfo;
	PDWORD	pdSector = (PDWORD)pSector;
    UCHAR 	status;
    UINT32 	i;
	UCHAR	addrcnt, *addr;
	BOOL	isDirty=FALSE;

	if (!pSector || !pSectorInfo) {
		DEBUGMSG(ZONE_ERROR,(TEXT("WriteSector_ECC requires both a sector and sector info\r\n")));
		return FALSE;
	}

	if ( WAIT_OBJECT_0 != WaitForSingleObject(hMutex,5000) )
		RETAILMSG(1,(TEXT("WaitForSingleObject(hMutex,5000) failed %d\r\n"),__LINE__));

__try {
	addrcnt = pNandDev->pTranslateAddr(SectorNumber, &addr, 0);

	if ( pSectorInfo->bBadBlock != 0xFF )
		DEBUGMSG(ZONE_WARNING,(TEXT("WARNING: Setting BAD Block on sector %d, val:%X\r\n"),SectorNumber,pSectorInfo->bBadBlock));

    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_WRITE);

	// Write our translated address to the controller
	for(i=0; i<addrcnt; i++)
		WRITE_REGISTER_UCHAR(NAND_ADDR_PORT, addr[i]);

	// Write out the data
	for (i=0; i<pNandDev->pagesize/4; i++)
		WRITE_REGISTER_ULONG((PULONG)NAND_DATA_PORT,pdSector[i]);

	for (i=0; i<sizeof(SectorInfo)/4; i++)
		WRITE_REGISTER_ULONG((PULONG)NAND_DATA_PORT,pdInfoBuffer[i]);

	// Write 4 bytes to finish the page and get the ECC data out from the hardware.
	WRITE_REGISTER_ULONG((PULONG)NAND_DATA_PORT,0xAAAAAAAA);

	// Instruct the Flash to commit the data to the media
    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_WRITE2);

	WaitForReady(0);

	status = GetStatus();
}	__finally  {
	ReleaseMutex(hMutex);
}
    if (status & STATUS_ERROR) {
        RETAILMSG(1,(TEXT("Error writing sector %d\r\n"),SectorNumber));
        return FALSE;
    }

    return TRUE;
}

#ifdef NAND_USE_DDMA
static BOOL NAND_WriteSector_ECC_DDMA( DWORD       SectorNumber,
                              PUCHAR      pSector,
                              PSectorInfo pSectorInfo,
                              PUCHAR      pECC )
{
    PDWORD 	pdInfoBuffer = (PDWORD)pSectorInfo;
	PDWORD	pdSector = (PDWORD)pSector;
    ULONG 	status = 0;
    UINT32 	i;
	UCHAR	addrcnt, *addr;
	BOOL	isDirty=FALSE;
	PULONG 	pDmaBuffer;
	ULONG 	dmaIntMask;      // DMA done mask
	ULONG	stndctl;

	if (!pSector || !pSectorInfo) {
		DEBUGMSG(ZONE_ERROR,(TEXT("WriteSector_ECC_DDMA requires both a sector and sector info\r\n")));
		return FALSE;
	}

	if ( WAIT_OBJECT_0 != WaitForSingleObject(hMutex,5000) )
		RETAILMSG(1,(TEXT("WaitForSingleObject(hMutex,5000) failed %d\r\n"),__LINE__));

__try {
	addrcnt = pNandDev->pTranslateAddr(SectorNumber, &addr, 0);

	if ( pSectorInfo->bBadBlock != 0xFF )
		DEBUGMSG(ZONE_WARNING,(TEXT("WARNING: Setting BAD Block on sector %d, val:%X\r\n"),SectorNumber,pSectorInfo->bBadBlock));

    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_WRITE);

	// Write our translated address to the controller
	for(i=0; i<addrcnt; i++)
		WRITE_REGISTER_UCHAR(NAND_ADDR_PORT, addr[i]);

	stndctl = READ_REGISTER_ULONG((PULONG)&pStaticController->stndctl);
	stndctl |= MEM_STNDCTRL_WFRD;
    WRITE_REGISTER_ULONG((PULONG)&pStaticController->stndctl, stndctl);

	HalStopDMA(pNandDev->TxDmaChannel);
	pDmaBuffer = HalGetNextDMABuffer(pNandDev->TxDmaChannel);

	memcpy((PUCHAR)pDmaBuffer, pSector, NAND_HW_ECC_SECTOR_SIZE);
	memcpy(((PUCHAR)pDmaBuffer) + NAND_HW_ECC_SECTOR_SIZE, (PUCHAR)pSectorInfo, sizeof(SectorInfo));

	HalActivateDMABuffer(pNandDev->TxDmaChannel, pDmaBuffer, NAND_HW_ECC_TOTAL_SIZE);
	HalStartDMA(pNandDev->TxDmaChannel);

	status = WaitForSingleObject(pNandDev->hDmaInterruptEvent, 1000);
	if (status != 0) {
		RETAILMSG(1,(TEXT("DBDMA Interrupt not received!\r\n")));
	}

	dmaIntMask = HalCheckForDMAInterrupt(pNandDev->TxDmaChannel);

	while (dmaIntMask)
	{
		HalAckDMAInterrupt(pNandDev->TxDmaChannel, dmaIntMask);
		HalStopDMA(pNandDev->TxDmaChannel);
		dmaIntMask = HalCheckForDMAInterrupt(pNandDev->TxDmaChannel);
	}

	stndctl &= ~MEM_STNDCTRL_WFRD;
    WRITE_REGISTER_ULONG((PULONG)&pStaticController->stndctl, stndctl);

	InterruptDone(pNandDev->DmaSysIntr);

	// Instruct the Flash to commit the data to the media
    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_WRITE2);

	WaitForReady(0);

	status = GetStatus();
}	__finally  {
	ReleaseMutex(hMutex);
}
    if (status & STATUS_ERROR) {
        RETAILMSG(1,(TEXT("Error writing sector %d\r\n"),SectorNumber));
        return FALSE;
    }

    return TRUE;
}
#endif
#endif

static BOOL NAND_ReadInfo( 	 DWORD		 SectorNumber,
							 PSectorInfo pSectorInfo )
{
	UCHAR	addrcnt, *addr;		/* Used for our translated address */
	PUCHAR  pSectorInfoBuf = (PUCHAR)pSectorInfo;
	DWORD i;

	if ( WAIT_OBJECT_0 != WaitForSingleObject(hMutex,5000) )
		RETAILMSG(1,(TEXT("WaitForSingleObject(hMutex,5000) failed %d\r\n"),__LINE__));

__try {
	addrcnt = pNandDev->pTranslateAddr(SectorNumber, &addr, 1);

	NAND_DisableECC();

    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_READ);

	/*
	 *	Write our translated address to the controller
	 */
	for(i=0; i<addrcnt; i++)
		WRITE_REGISTER_UCHAR(NAND_ADDR_PORT, addr[i]);

	if ( pNandDev->addr_confirm )
	    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, pNandDev->addr_confirm);

	WaitForReady(0);

	for(i=0; i<sizeof(SectorInfo); i++)
		*pSectorInfoBuf++ = READ_REGISTER_UCHAR(NAND_DATA_PORT);

	RETAILMSG(0,(TEXT("Sector %d info: %08X %02X %02X %04X\r\n"), SectorNumber,
		pSectorInfo->dwReserved1, pSectorInfo->bOEMReserved, pSectorInfo->bBadBlock,
		pSectorInfo->wReserved2));

} __finally {
	NAND_EnableECC();
	ReleaseMutex(hMutex);
}
    return TRUE;
}

static BOOL NAND_WriteInfo(	 DWORD		 SectorNumber,
							 PSectorInfo pSectorInfo )
{
	UCHAR	addrcnt, *addr;		/* Used for our translated address */
	PUCHAR  pSectorInfoBuf = (PUCHAR)pSectorInfo;
    UCHAR status;
	int i;

	if ( WAIT_OBJECT_0 != WaitForSingleObject(hMutex,5000) )
		RETAILMSG(1,(TEXT("WaitForSingleObject(hMutex,5000) failed %d\r\n"),__LINE__));

__try {
	addrcnt = pNandDev->pTranslateAddr(SectorNumber, &addr, 1);

	if ( pSectorInfo->bBadBlock != 0xFF )
		RETAILMSG(1,(TEXT("WARNING: Setting BAD Block on sector %d, val:%X\r\n"),SectorNumber,pSectorInfo->bBadBlock));

	NAND_DisableECC();

    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_WRITE);

	for(i=0; i<addrcnt; i++)
		WRITE_REGISTER_UCHAR(NAND_ADDR_PORT, addr[i]);

	RETAILMSG(0,(TEXT("Writing sector info (%d): %08X %02X %02X %04X\r\n"), SectorNumber,
				pSectorInfo->dwReserved1, pSectorInfo->bOEMReserved, pSectorInfo->bBadBlock,
				pSectorInfo->wReserved2));

	for(i=0; i<sizeof(SectorInfo); i++)
		WRITE_REGISTER_UCHAR(NAND_DATA_PORT, *pSectorInfoBuf++);

	// Instruct the Flash to commit the data to the media
    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_WRITE2);
	WaitForReady(0);

	status = GetStatus();
}	__finally  {
	NAND_EnableECC();
	ReleaseMutex(hMutex);
}
    if (status & STATUS_ERROR) {
        RETAILMSG(1,(TEXT("Error writing sector %d\r\n"),SectorNumber));
        return FALSE;
    }

    return TRUE;
}

static void NAND_SendReadCommand(DWORD SectorNumber, DWORD Col)
{
	UCHAR *addr, addrcnt;
	DWORD i;

	addrcnt = pNandDev->pTranslateAddr(SectorNumber, &addr, Col);
    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_READ);

	/*
	 *	Write our translated address to the controller
	 */
	for(i=0; i<addrcnt; i++)
		WRITE_REGISTER_UCHAR(NAND_ADDR_PORT, addr[i]);

	/*
	 *	Some devices need confrm CMD byte
	 */
	if ( pNandDev->addr_confirm )
	    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, pNandDev->addr_confirm);

	WaitForReady(0);
}

static BOOL NAND_ReadSector_Raw( DWORD       SectorNumber,
                             PUCHAR      pSector,
                             PSectorInfo pSectorInfo,
                             PUCHAR      pECC )
{
    PUCHAR pInfoBuffer = (PUCHAR)pSectorInfo;
	UNALIGNED PDWORD pSectorBuffer = (PDWORD)pSector;
    UINT32 i;
	UINT32 sectorBytes = pNandDev->pagesize;
	BOOL   ret = TRUE;

	if ( WAIT_OBJECT_0 != WaitForSingleObject(hMutex,5000) )
		RETAILMSG(1,(TEXT("WaitForSingleObject(hMutex,5000) failed %d\r\n"),__LINE__));
__try {
	NAND_SendReadCommand(SectorNumber, pSector==NULL?1:0);
	if (pSector) {
		for (i=0; i<pNandDev->pagesize; i++)
			*pSector++ = READ_REGISTER_UCHAR(NAND_DATA_PORT);
	}

	if (pInfoBuffer) {
		for (i=0; i<sizeof(SectorInfo); i++)
			*pInfoBuffer++ = READ_REGISTER_UCHAR(NAND_DATA_PORT);
	}

} __finally {
	ReleaseMutex(hMutex);
}

	return ret;
}

#ifdef NAND_USE_HW_ECC
static BOOL NAND_ReadSector_ECC( DWORD       SectorNumber,
                             PUCHAR      pSector,
                             PSectorInfo pSectorInfo,
                             PUCHAR      pECC )
{
	BOOL 	bRet = TRUE;
	DWORD 	dwSectorBytes = pNandDev->pagesize;
	//DWORD	TempBuf[129];
	DWORD	bytes=0;
	DWORD	i;
	DWORD	intrState = -1;
	PDWORD  pdwSector = (PDWORD)pSector;
	PDWORD  pdwSectorInfo = (PDWORD)pSectorInfo;
	DWORD   temp;

	if ( WAIT_OBJECT_0 != WaitForSingleObject(hMutex,5000) )
		RETAILMSG(1,(TEXT("WaitForSingleObject(hMutex,5000) failed %d\r\n"),__LINE__));

	RETAILMSG(0,(TEXT("Reading Sector %d with ECC\r\n"), SectorNumber));

__try {
	NAND_SendReadCommand(SectorNumber, 0);
	intrState = DISABLE_INTERRUPTS();

	NAND_TriggerECC(3);

	for (i=0; i<NAND_HW_ECC_SECTOR_SIZE/4; i++) {
		temp = READ_REGISTER_ULONG((PULONG)NAND_DATA_PORT);
		if (pdwSector)
			*pdwSector++ = temp;
	}

	for (i=0; i<sizeof(SectorInfo)/4; i++) {
		temp = READ_REGISTER_ULONG((PULONG)NAND_DATA_PORT);
		if (pdwSectorInfo)
			*pdwSectorInfo++ = temp;
	}

	READ_REGISTER_ULONG((PULONG)NAND_DATA_PORT);

	bRet = NAND_CheckECC(SectorNumber);

} __finally {
	if (intrState != -1)
		RESTORE_INTERRUPTS(intrState);
	ReleaseMutex(hMutex);
}
    return bRet;
}

#ifdef NAND_USE_DDMA
static BOOL NAND_ReadSector_ECC_DDMA( DWORD       SectorNumber,
                             PUCHAR      pSector,
                             PSectorInfo pSectorInfo,
                             PUCHAR      pECC )
{
	BOOL 	bRet = TRUE;
	DWORD 	dwSectorBytes = pNandDev->pagesize;
	DWORD	bytes=0;

	PDWORD  pdwSector = (PDWORD)pSector;
	PDWORD  pdwSectorInfo = (PDWORD)pSectorInfo;
	PULONG 	pDmaBuffer;
	DWORD 	status;
	ULONG 	dmaIntMask;      // DMA done mask
	ULONG 	BytesLeft = NAND_HW_ECC_SECTOR_SIZE;
	ULONG 	Bytes;


	if ( WAIT_OBJECT_0 != WaitForSingleObject(hMutex,5000) )
		RETAILMSG(1,(TEXT("WaitForSingleObject(hMutex,5000) failed %d\r\n"),__LINE__));

	RETAILMSG(0,(TEXT("Reading Sector %d with ECC\r\n"), SectorNumber));

__try {
	NAND_SendReadCommand(SectorNumber, 0);

	while (BytesLeft) {
		NAND_TriggerECC(0);

		HalStopDMA(pNandDev->RxDmaChannel);
		pDmaBuffer = HalGetNextDMABuffer(pNandDev->RxDmaChannel);
		HalActivateDMABuffer(pNandDev->RxDmaChannel, pDmaBuffer, 516);

		HalStartDMA(pNandDev->RxDmaChannel);

		status = WaitForSingleObject(pNandDev->hDmaInterruptEvent, 1000);
		if (status != 0) {
			RETAILMSG(1,(TEXT("DBDMA Interrupt not received!\r\n")));
		}

		dmaIntMask = HalCheckForDMAInterrupt(pNandDev->RxDmaChannel);

		while (dmaIntMask)
		{
			HalAckDMAInterrupt(pNandDev->RxDmaChannel, dmaIntMask);
			HalStopDMA(pNandDev->RxDmaChannel);
			dmaIntMask = HalCheckForDMAInterrupt(pNandDev->RxDmaChannel);
		}

		InterruptDone(pNandDev->DmaSysIntr);

		bRet = NAND_CheckECC(SectorNumber);

		if (BytesLeft > 515)
			Bytes = 515;
		else
			Bytes = BytesLeft;

		if (pSector) {
			memcpy(pSector, (PUCHAR)pDmaBuffer, Bytes);
			pSector += Bytes;
		}

		BytesLeft -= Bytes;
	}

	if (pSectorInfo)
		memcpy(pSectorInfo, (((PUCHAR)pDmaBuffer) + Bytes), sizeof(SectorInfo));
} __finally {
	ReleaseMutex(hMutex);
}
    return bRet;
}

#endif   /* NAND_USE_DDMA */
#endif	 /* NAND_USE_HW_ECC */

DWORD ReadFlashID()
{
    UCHAR id_data[4];
	int i;

	if ( WAIT_OBJECT_0 != WaitForSingleObject(hMutex,5000) )
		RETAILMSG(1,(TEXT("WaitForSingleObject(hMutex,5000) failed %d\r\n"),__LINE__));

__try {
    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_READID);
    WRITE_REGISTER_UCHAR(NAND_ADDR_PORT, 0x00);

	for (i=0;i<sizeof(id_data);i++) {
		id_data[i] = READ_REGISTER_UCHAR(NAND_DATA_PORT);
	}

    RETAILMSG(1,(TEXT("FMD:ReadID (Maker=%x,Device=%x,3rd=%x,4th=%x)\r\n"),id_data[0],id_data[1],id_data[2],id_data[3]));
} __finally {
    ReleaseMutex(hMutex);
}
    return ((DWORD)id_data[0]<<8 | id_data[1]);

}

UCHAR ReadFlashID2()
{
    UCHAR id2_data[3];
	int i;

	if ( WAIT_OBJECT_0 != WaitForSingleObject(hMutex,5000) )
		RETAILMSG(1,(TEXT("WaitForSingleObject(hMutex,5000) failed %d\r\n"),__LINE__));
__try {
    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_READID2);
    WRITE_REGISTER_UCHAR(NAND_ADDR_PORT, 0x00);

	for (i=0;i<sizeof(id2_data);i++) {
		id2_data[i] = READ_REGISTER_UCHAR(NAND_DATA_PORT);
	}
} __finally {
	ReleaseMutex(hMutex);
}
    DEBUGMSG(ZONE_INIT,(TEXT("FMD:ReadID2 (Char=%x,Org=%x,Size=%x)\r\n"),id2_data[0],id2_data[1],id2_data[2]));

    return (id2_data[0] & 0x04);
}

BOOL IsBlockBad(BLOCK_ID blockID)
{
    SectorInfo info;
    DWORD  sector = blockID*pNandDev->pages;   //  Get the first page of the blcok

	NAND_ReadInfo(sector, &info);

    if (0xff != info.bBadBlock) {
		DEBUGMSG(ZONE_INIT,(TEXT("IsBlockBad %d YES (%02X)\r\n"),blockID,info.bBadBlock));
		return TRUE;
    }

    //  Check the second page
	sector++;

	NAND_ReadInfo(sector, &info);

    if (0xff != info.bBadBlock) {
		DEBUGMSG(ZONE_INIT,(TEXT("IsBlockBad %d YES (page 2) (%02X)\r\n"),blockID,info.bBadBlock));
		return TRUE;
    }

    return FALSE;
}

/*-----------------------------------------------------------------------------
 *  FMD Interface functions
 *
 *----------------------------------------------------------------------------*/

#ifdef NAND_USE_DDMA
BOOL NAND_Init_DMA()
{
	ULONG hwIntr;
	ULONG cp0_config;

	/*
	 * The OD (System Bus Overlap Disable) bit must be set for DDMA to work
	 * correctly.  Without this bit set, NAND ECC with DDMA will hang the
	 * system bus.
	 */
	cp0_config = Cp0RdConfig();
	cp0_config |= (1<<19);		/* Set the OD bit */
	Cp0WrConfig(cp0_config);

	pNandDev->TxDmaChannel = HalAllocateDMAChannel();
	pNandDev->RxDmaChannel = HalAllocateDMAChannel();

	if (pNandDev->TxDmaChannel == NULL || pNandDev->RxDmaChannel == NULL) {
		RETAILMSG(1,(TEXT("NAND: Failed to allocate DMA channel!\r\n")));
		goto ErrorReturn;
	}

	HalInitDmaChannel(pNandDev->TxDmaChannel,
					  DMA_NAND_TX,
					  NAND_HW_ECC_TOTAL_SIZE,
					  TRUE);

	HalInitDmaChannel(pNandDev->RxDmaChannel,
					  DMA_NAND_RX,
					  NAND_HW_ECC_TOTAL_SIZE,
					  TRUE);

	HalSetDMAForReceive(pNandDev->RxDmaChannel);

	hwIntr = HalGetDMAHwIntr(pNandDev->TxDmaChannel);
	hwIntr |= (HalGetDMAHwIntr(pNandDev->RxDmaChannel) << 8);

	pNandDev->DmaSysIntr = InterruptConnect(Internal, 0, hwIntr, 0);

    if (SYSINTR_NOP==pNandDev->DmaSysIntr) {
        RETAILMSG(1,(TEXT("NAND: Can't allocate DMA SYSINTR\r\n")));
        goto ErrorReturn;
    }

    pNandDev->hDmaInterruptEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

    if (NULL == pNandDev->hDmaInterruptEvent) {
        RETAILMSG(1,(TEXT("NAND: Can't create DMA interrupt event\r\n")));
        goto ErrorReturn;
    }

    if (!InterruptInitialize(pNandDev->DmaSysIntr,
                             pNandDev->hDmaInterruptEvent,
                             NULL,
                             0)) {
        RETAILMSG(0,(TEXT("NAND: Call to InterruptInitialize failed\r\n")));
    }

	while (WaitForSingleObject(pNandDev->hDmaInterruptEvent, 0) == WAIT_OBJECT_0)
	  InterruptDone(pNandDev->DmaSysIntr);


	return TRUE;

ErrorReturn:
	return FALSE;

}
#endif


//  FMD_Init
//
//  Initialize the flash chip
//
PVOID FMD_Init(LPCTSTR lpActiveReg, PPCI_REG_INFO pRegIn, PPCI_REG_INFO pRegOut)
{
	PHYSICAL_ADDRESS phBase;
	ULONG tmp;
	ULONG *ptr = (ULONG*)0xBDC00000;
	ULONG stndctl;
	//ULONG stcfg1;

	hMutex = CreateMutex(NULL,FALSE,L"FMD-Mutex");

	tmp = *ptr;
	phBase.LowPart = NAND_PHYS_ADDR;
	phBase.HighPart = 0;

	DEBUGMSG(ZONE_INIT,(TEXT("NAND_FMD: Phys:%X\r\n"),phBase.LowPart));

#ifndef NAND_BOOT
	IoAddr = HalCreateBlockMapping(phBase,0x1000,FALSE);
#else
	IoAddr = (PUCHAR)(NAND_PHYS_ADDR+KSEG1_OFFSET);
#endif

	RETAILMSG(1,(TEXT("NAND_FMD: Virtual Addr:%X\r\n"),IoAddr));

	// disable nand boot mode
	stndctl = READ_REGISTER_ULONG((PULONG)&pStaticController->stndctl);

	stndctl &= ~MEM_STNDCTRL_BOOT;
    WRITE_REGISTER_ULONG((PULONG)&pStaticController->stndctl, stndctl);

#ifdef NAND_USE_INTERRUPTS // Hook the interrupt.
	RETAILMSG(1,(TEXT("FMD_Init: Using interrupt %d\r\n"),HWINTR_NAND));

    if ((hInterruptEvent = CreateEvent(NULL, FALSE, FALSE, NULL)) == INVALID_HANDLE_VALUE)
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("FMD_Init: cannot create the interrupt event!\r\n")));
        hInterruptEvent = 0;
        goto error_exit;
    }
    if ((dwSysIntr = InterruptConnect(Internal, 0, HWINTR_NAND, 0)) == SYSINTR_NOP)
    {
        RETAILMSG(1, (TEXT("FMD_Init: cannot allocate a sysintr for NAND!\r\n")));
		goto error_exit;
    }
    if (!InterruptInitialize(dwSysIntr, hInterruptEvent, NULL, 0))
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("FMD_Init: cannot init the NAND interrupt!\r\n")));
        goto error_exit;
    }

	/* Enable NAND interrupt from RNB */
	stndctl |= MEM_STNDCTRL_IE;
    WRITE_REGISTER_ULONG((PULONG)&pStaticController->stndctl, stndctl);

    WBSYNC();

	while (WaitForSingleObject(hInterruptEvent, 0) == WAIT_OBJECT_0)
	  InterruptDone(dwSysIntr);
#endif

	// Reset NAND
   	WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_RESET);
	WaitForReady(0);

#ifdef NAND_USE_HW_ECC
	/* Make sure the data field size is 515 and clock is at /2 */
	stndctl &= ~MEM_STNDCTRL_ECR;
	stndctl &= ~MEM_STNDCTRL_DFS;

	RETAILMSG(1,(TEXT("Enabling NAND HW ECC\n"), stndctl));

    WRITE_REGISTER_ULONG((PULONG)&pStaticController->stndctl, stndctl);
	NAND_EnableECC();
#endif

	RETAILMSG(1,(TEXT("Init complete...\r\n")));
    return IoAddr;

#ifdef NAND_USE_INTERRUPTS
error_exit:
	return NULL;
#endif
}

//  FMD_Deinit
//
//  De-initialize the flash chip
//
BOOL    FMD_Deinit(PVOID hFMD)
{
    if (hInterruptEvent != 0)
    {
        if (dwSysIntr != SYSINTR_NOP)
        {
            InterruptDisable(dwSysIntr);    // dissociate from the intr event
            InterruptDisconnect(dwSysIntr); // dissociate from the hwintr
        }
        CloseHandle(hInterruptEvent);
    }

	CloseHandle(hMutex);

    return TRUE;
}

//  FMD_GetInfo
//
//  Return the Flash information
//
BOOL    FMD_GetInfo(PFlashInfo pFlashInfo)
{
	UINT32	i;
	DWORD dwDeviceId;
	UINT32 stndctl;

	RETAILMSG(1,(TEXT("In GetInfo...\r\n")));
	/*
	 *	Initialize our Global variable
	 */
	pNandDev = NULL;

    pFlashInfo->flashType = NAND;
    dwDeviceId=ReadFlashID();

	for(i=0; i<NAND_NUM_DEVS; i++) {
		if ( g_NandDevices[i].id == dwDeviceId ) {
			pNandDev = &g_NandDevices[i];
			RETAILMSG(1,(TEXT("FMD_GetInfo: Found %s.\r\n"),pNandDev->name));
			break;
		}
	}

	if ( pNandDev == NULL )
		return FALSE;

#ifdef NAND_USE_DDMA
	NAND_Init_DMA();

	stndctl = READ_REGISTER_ULONG((PULONG)&pStaticController->stndctl);
	stndctl |= MEM_STNDCTRL_FFDM;
    WRITE_REGISTER_ULONG((PULONG)&pStaticController->stndctl, stndctl);
#endif

	pFlashInfo->dwNumBlocks         = pNandDev->blocks;
	pFlashInfo->wSectorsPerBlock    = pNandDev->pages;
    pFlashInfo->wDataBytesPerSector = pNandDev->pagesize;
	pFlashInfo->dwBytesPerBlock     = pNandDev->pagesize * pNandDev->pages;

	/* Check for Block Protection */
	for(i=0; i<pNandDev->protect_cnt; i++)
		FMD_SetBlockStatus(i,BLOCK_STATUS_RESERVED);

    RETAILMSG(1,(TEXT("NAND: DeviceId = %04X\r\n"),dwDeviceId));
    RETAILMSG(1,(TEXT("NAND: pFlashInfo->dwNumBlocks = %d\r\n"),pFlashInfo->dwNumBlocks));
    RETAILMSG(1,(TEXT("NAND: pFlashInfo->wSectorsPerBlock = %d\r\n"),pFlashInfo->wSectorsPerBlock));
    RETAILMSG(1,(TEXT("NAND: pFlashInfo->dwBytesPerBlock = %d\r\n"),pFlashInfo->dwBytesPerBlock));
    RETAILMSG(1,(TEXT("NAND: Total Size = %uMB\r\n"),(pFlashInfo->dwBytesPerBlock * pFlashInfo->dwNumBlocks)/0x100000));

    return TRUE;
}

//  FMD_ReadSector
//
//  Read the content of the sector.
//
//  startSectorAddr: Starting page address
//  pSectorBuff  : Buffer for the data portion
//  pSectorInfoBuff: Buffer for Sector Info structure
//  dwNumSectors : Number of sectors
//
BOOL FMD_ReadSector(SECTOR_ADDR startSectorAddr, LPBYTE pSectorBuff,
                        PSectorInfo pSectorInfoBuff, DWORD dwNumSectors)
{
    DWORD count;
	int i;

	RETAILMSG(0,(TEXT("Reading sector %d (%d sectors)\r\n"),startSectorAddr,dwNumSectors));

	if (pSectorBuff == NULL)
		RETAILMSG(0,(TEXT("Reading sector %d; pSectorBuff == NULL\r\n"),startSectorAddr));
	if (pSectorInfoBuff == NULL)
		RETAILMSG(0,(TEXT("Reading sector %d; pSectorInfoBuff == NULL\r\n"),startSectorAddr));

    //
    //  Sanity check
    if (!pSectorBuff && !pSectorInfoBuff) {
        RETAILMSG(1, (TEXT("Invalid parameters!\n")));
        return FALSE;
    }

	for (count=0; count<dwNumSectors; count++) {
#ifdef NAND_USE_HW_ECC
		SectorInfo si;
		NAND_ReadInfo(startSectorAddr, &si);
		/*
		 * Use the SectorInfo from this call because it reads without ECC which
		 * can sometimes "correct" status bits that change over the life of the
		 * page.  Specifically, the dirty bit that marks a block as ready to
		 * erase gets set after the inital page write - if we allow ECC to
		 * "correct" that bit then we can never reclaim sectors.
		 */
		if (!pSectorBuff && pSectorInfoBuff) {
			memcpy(pSectorInfoBuff, &si, sizeof(SectorInfo));
		} else {
			if (si.wReserved2 == 0xFFFF) {
				/*
				 * The calculated ECC signature of an erased page is not all
				 * FF's, which is what is stored in the ECC area of an erased
				 * page.  If we read it with the ECC engine, it will cause an
				 * ECC decode fail error.  Since we know that an erased page
				 * should contain all FF's, we just return that.
				 */
				if (pSectorBuff)
					memset(pSectorBuff, 0xFF, pNandDev->pagesize);
			} else {
				/*
				 * Currently, we do not know when the ECC read is complete so
				 * we guess with a timeout.  This is not very reliable so we
				 * attempt the read 10 times (it has never failed more than 6
				 * in a row).  This should be fixed in the future once we know
				 * how to determine that the ECC read is complete.
				 */
				RETAILMSG(0,(TEXT("Sector %d info: %08X %02X %02X %04X\r\n"), startSectorAddr,
							si.dwReserved1, si.bOEMReserved, si.bBadBlock, si.wReserved2));
				for (i=0; i<10; i++)
#ifdef NAND_USE_DDMA
					if (NAND_ReadSector_ECC_DDMA(startSectorAddr, pSectorBuff, pSectorInfoBuff, NULL) == TRUE)
#else
					if (NAND_ReadSector_ECC(startSectorAddr, pSectorBuff, pSectorInfoBuff, NULL) == TRUE)
#endif
						break;

				if (i>4)
					RETAILMSG(1,(TEXT("Reading sector %d passed but took %d times.)\r\n"),startSectorAddr, i));
				
				if (i==10) {
					RETAILMSG(1,(TEXT("Reading sector %d failed (%d times!)\r\n"),startSectorAddr, i));
					return FALSE;
				}
			}
		}
#else
		NAND_ReadSector_Raw(startSectorAddr, pSectorBuff, pSectorInfoBuff, NULL);
#endif

		if (pSectorBuff) {
			pSectorBuff += pNandDev->pagesize;
		}

		if (pSectorInfoBuff) {
			pSectorInfoBuff ++;
		}

		startSectorAddr ++;
	}
    return TRUE;
}

//  FMD_EraseBlock
//
//  Erase the given block
//
BOOL FMD_EraseBlock(BLOCK_ID blockID)
{
    UCHAR   status;
	UINT32	i, addrcnt;
	UCHAR	*addr;


if ( WAIT_OBJECT_0 != WaitForSingleObject(hMutex,5000) )
		RETAILMSG(1,(TEXT("WaitForSingleObject(hMutex,5000) failed %d\r\n"),__LINE__));
__try {
	addrcnt = pNandDev->pTranslateAddr( (blockID*pNandDev->pages), &addr, 0);

	RETAILMSG(0,(L"Erasing block %d\r\n", blockID));

    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_ERASE);

	/*
	 *	Write our translated address to the controller
	 * **** This on a block basis only
	 */
	for(i=pNandDev->cols; i<addrcnt; i++)
		WRITE_REGISTER_UCHAR(NAND_ADDR_PORT, addr[i]);

    WRITE_REGISTER_UCHAR(NAND_CMD_PORT, CMD_ERASE2);

    WaitForReady(0);

    status = GetStatus();
} __finally {
	ReleaseMutex(hMutex);
}

    if (status & STATUS_ERROR) {
        RETAILMSG(1, (TEXT("######## Error Erasing block %d!\n"), blockID));
        return FALSE;
    }

    return TRUE;
}


//  FMD_WriteSector
//
//  Write dwNumPages pages to the startSectorAddr
//
BOOL FMD_WriteSector(SECTOR_ADDR startSectorAddr, LPBYTE pSectorBuff, PSectorInfo pSectorInfoBuff,
                        DWORD dwNumSectors)
{
    DWORD  count;
	RETAILMSG(0,(TEXT("Writing sector %d (%d sectors)\r\n"),startSectorAddr,dwNumSectors));

    //  Sanity check
    if (!pSectorBuff && !pSectorInfoBuff) {
        DEBUGMSG(ZONE_ERROR, (TEXT("Invalid parameters!\n")));
        return FALSE;
    }

    for (count=0;count<dwNumSectors;count++) {

        if (pSectorBuff) {
#ifdef NAND_USE_HW_ECC
#ifdef NAND_USE_DDMA
            if ( !NAND_WriteSector_ECC_DDMA(startSectorAddr, pSectorBuff, pSectorInfoBuff, NULL) ) {
				DEBUGMSG(ZONE_ERROR, (TEXT("FMD: Unable to write sector 0x%x!!!\r\n"),startSectorAddr));
				return FALSE;
			}
#else
            if ( !NAND_WriteSector_ECC(startSectorAddr, pSectorBuff, pSectorInfoBuff, NULL) ) {
				DEBUGMSG(ZONE_ERROR, (TEXT("FMD: Unable to write sector 0x%x!!!\r\n"),startSectorAddr));
				return FALSE;
			}
#endif
#else
            if ( !NAND_WriteSector_Raw(startSectorAddr, pSectorBuff, pSectorInfoBuff, NULL) ) {
				DEBUGMSG(ZONE_ERROR, (TEXT("FMD: Unable to write sector 0x%x!!!\r\n"),startSectorAddr));
				return FALSE;
			}
#endif

	        pSectorBuff += pNandDev->pagesize;
        } else {
            if ( !NAND_WriteInfo(startSectorAddr, pSectorInfoBuff) ) {
				DEBUGMSG(ZONE_ERROR, (TEXT("FMD: Unable to write sector info 0x%x!!!\r\n"),startSectorAddr));
				return FALSE;
			}
        }

        pSectorInfoBuff ++;
        startSectorAddr ++;
    }

    return TRUE;
}

/*
 *  FMD_GetBlockStatus
 *
 *  Returns the status of a block.  For read-only blocks, checks the sector info data for the first sector of the block.
 */
DWORD FMD_GetBlockStatus(BLOCK_ID blockID)
{
    SECTOR_ADDR Sector = blockID * pNandDev->pages;
    SectorInfo SI;
    DWORD dwResult = 0;

	RETAILMSG(0,(TEXT("FMD_GetBlockStatus for block %d\r\n"),blockID));

	if (IsBlockBad (blockID)) {
        dwResult = BLOCK_STATUS_BAD;
		goto FMD_GetBlockStatus_out;
	}

	NAND_ReadInfo(Sector, &SI);

    if (!(SI.bOEMReserved & OEM_BLOCK_READONLY))
        dwResult |= BLOCK_STATUS_READONLY;

    if (!(SI.bOEMReserved & OEM_BLOCK_RESERVED))
        dwResult |= BLOCK_STATUS_RESERVED;

FMD_GetBlockStatus_out:
	RETAILMSG(0,(TEXT("-FMD_GetBlockStatus %d\r\n"),dwResult));
	if (dwResult!=0)
		RETAILMSG(1,(TEXT("FMD_GetBlockStatus for block %d: %d\r\n"),blockID, dwResult));

    return dwResult;
}

/*
 *  FMD_SetBlockStatus
 *
 *  Sets the status of a block.
 *  Returns TRUE if no errors in setting.
 */

BOOL FMD_SetBlockStatus(BLOCK_ID blockID, DWORD dwStatus)
{
	SECTOR_ADDR Sector = blockID * pNandDev->pages;
	SectorInfo SI;

	RETAILMSG(1,(TEXT("+FMD_SetBlockStatus %d %08X\r\n"),blockID,dwStatus));

    if (dwStatus & (BLOCK_STATUS_READONLY | BLOCK_STATUS_RESERVED | BLOCK_STATUS_BAD)) {

        if (!FMD_ReadSector(Sector, NULL, &SI, 1)) {
            return FALSE;
        }

        if (dwStatus & BLOCK_STATUS_BAD) {
            SI.bBadBlock = BADBLOCKMARK;
        }

        if (dwStatus & BLOCK_STATUS_READONLY) {
            SI.bOEMReserved &= ~OEM_BLOCK_READONLY;
        }

        if (dwStatus & BLOCK_STATUS_RESERVED) {
            SI.bOEMReserved &= ~OEM_BLOCK_RESERVED;
        }

        if (!NAND_WriteInfo(Sector, &SI)) {
            return FALSE;
        }

		if ( dwStatus & BLOCK_STATUS_BAD ) {
			if (!NAND_WriteInfo (Sector+1, &SI)) {
				return FALSE;
			}
		}
    }

    return TRUE;
}



//  FMD_PowerUp
//
//  Performs any necessary powerup procedures...
//
VOID FMD_PowerUp(VOID)
{
    return;
}


//  FMD_PowerDown
//
//  Performs any necessary powerdown procedures...
//
VOID FMD_PowerDown(VOID)
{
    return;
}


//  FMD_OEMIoControl
//
//  Used for any OEM defined IOCTL operations
//
BOOL  FMD_OEMIoControl(DWORD dwIoControlCode, PBYTE pInBuf, DWORD nInBufSize,
                       PBYTE pOutBuf, DWORD nOutBufSize, PDWORD pBytesReturned)
{
	RETAILMSG(1,(_T("FMD_OEMIoControl: code:%X \n"),dwIoControlCode));

	switch( dwIoControlCode ) {

	    case IOCTL_FMD_GET_INTERFACE:
	    {
			PFMDInterface pInterface;
			RETAILMSG(1,(TEXT("In case IOCTL_FMD_GET_INTERFACE\r\n")));
			if (!pOutBuf || nOutBufSize < sizeof(FMDInterface))
	        {
	            DEBUGMSG(1, (TEXT("FMD_OEMIoControl: IOCTL_FMD_GET_INTERFACE bad parameter(s).\r\n")));
	            return(FALSE);
	        }

	        pInterface = (PFMDInterface)pOutBuf;

	        pInterface->cbSize = sizeof(FMDInterface);
	        pInterface->pInit = FMD_Init;
	        pInterface->pDeInit = FMD_Deinit;
	        pInterface->pGetInfo = FMD_GetInfo;
//	        pInterface->pGetInfoEx = FMD_GetInfoEx;
	        pInterface->pGetBlockStatus = FMD_GetBlockStatus;
	        pInterface->pSetBlockStatus = FMD_SetBlockStatus;
	        pInterface->pReadSector = FMD_ReadSector;
	        pInterface->pWriteSector = FMD_WriteSector;
	        pInterface->pEraseBlock = FMD_EraseBlock;
	        pInterface->pPowerUp = FMD_PowerUp;
	        pInterface->pPowerDown = FMD_PowerDown;
//	        pInterface->pGetPhysSectorAddr = FMD_GetPhysSectorAddr;
	        pInterface->pOEMIoControl = FMD_OEMIoControl;
			break;
		}
		case IOCTL_DISK_GET_STORAGEID:
		{
			PSTORAGE_IDENTIFICATION stor;

			RETAILMSG(1,(TEXT("In Get StorageID\r\n")));
			if (!pOutBuf || nOutBufSize < sizeof(STORAGE_IDENTIFICATION))
	        {
	            DEBUGMSG(1, (TEXT("FMD_OEMIoControl: IOCTL_DISK_GET_STORAGEID bad parameter(s).\r\n")));
	            return(FALSE);
	        }

			stor = (PSTORAGE_IDENTIFICATION)pOutBuf;
			stor->dwSize = pNandDev->pagesize * pNandDev->pages * pNandDev->blocks;
			/*
			 * We're not setting these fields right now.  Let WinCE know that.
			 */
			stor->dwFlags = MANUFACTUREID_INVALID | SERIALNUM_INVALID;
			break;
		}
		default:
			return FALSE;
			break;
	}

    return TRUE;
}

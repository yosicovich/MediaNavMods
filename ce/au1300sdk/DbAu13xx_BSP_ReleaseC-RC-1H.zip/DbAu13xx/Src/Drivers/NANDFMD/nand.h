/*****************************************************************************
Copyright 2003-2007 Raza Microelectronics, Inc.(RMI). All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY Raza Microelectronics, Inc. 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef _NAND_H_
#define _NAND_H_

#include "nanddev.h"

#define NAND_FLAG_READ1			0x01	// opcode 01h
#define NAND_FLAG_READ2			0x02	// opcode 50h
#define NAND_FLAG_ID2			0x04	// Opcode 91h -- readid 2
#define NAND_FLAG_AUTOREAD		0x08	// Power On Auto Read
#define NAND_BLOCK_PROTECT		0x10	// Enables Block Protection

/* Address Translations prototypes */
UINT32	Addr_2col_3row(UINT32,PUCHAR*,UINT32);

static NAND_DEVICE g_NandDevices[] = {
//	{	0xADD3, L"HY27UH08AG5M",				   0, 2048, 64, 64,16384, 0x30, 2048, Addr_2col_3row, 2,3, 0 },
	{	0xADD3, L"HY27UH08AG5M",  NAND_BLOCK_PROTECT, 2048, 64, 64, 8192, 0x30, 2048, Addr_2col_3row, 2,3, 480 } ,
	{	0xADF1, L"HY27UH081G2A",  				   0, 2048, 64, 64, 1024, 0x30, 2048, Addr_2col_3row, 2,3, 0 } ,
	{	0x2cda, L"MT29F2G",       NAND_BLOCK_PROTECT, 2048, 64, 64, 2048, 0x30, 2048, Addr_2col_3row, 2,3, 0 } ,
};
#define NAND_NUM_DEVS		(sizeof(g_NandDevices)/sizeof(NAND_DEVICE))


//  Port Address
#define NAND_CMD_PORT           (IoAddr)
#define NAND_ADDR_PORT          (IoAddr+0x04)
#define NAND_DATA_PORT          (IoAddr+0x20)
#define NAND_ECC_TRIGGER_PORT	(IoAddr+0x30)
#define NAND_ECC_RESET_PORT		(IoAddr+0x38)
#define NAND_BUSY_PORT			((PULONG)0xB4001104)

#define CMD_READ                    0x00        //  Read
#define CMD_READ1                   0x01        //  Read1
#define CMD_READ2                   0x50        //  Read2
#define CMD_READID                  0x90        //  ReadID
#define CMD_READID2                 0x91        //  Read extended ID
#define CMD_WRITE                   0x80        //  Write phase 1
#define CMD_WRITE2                  0x10        //  Write phase 2
#define CMD_ERASE                   0x60        //  Erase phase 1
#define CMD_ERASE2                  0xd0        //  Erase phase 2
#define CMD_STATUS                  0x70        //  Status read
#define CMD_RESET                   0xff        //  Reset

//  Status bit pattern
#define STATUS_READY                0x40        //  Ready
#define STATUS_ERROR                0x01        //  Error

#endif _NAND_H_

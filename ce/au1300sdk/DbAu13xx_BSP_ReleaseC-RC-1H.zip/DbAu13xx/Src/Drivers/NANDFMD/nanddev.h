/*****************************************************************************
Copyright 2003-2007 Raza Microelectronics, Inc.(RMI). All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY Raza Microelectronics, Inc. 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef _NAND_DEV_H
#define _NAND_DEV_H

typedef UINT32 (*TRANSLATE)(UINT32,PUCHAR*,UINT32);

typedef struct {
	UINT32		id;
	WCHAR		name[64];
	UINT32		flags;
	UINT32		pagesize;
	UINT32		pages;
	UINT32		sparesize;		// spare data size
	UINT32		blocks;
	UINT32		addr_confirm;
	UINT32		spare_offset;
	TRANSLATE	pTranslateAddr;
	UINT16		cols,rows; 		// Number of columns/rows in the address reutnred
	UINT32		protect_cnt;	// Specifies number blocks to protect starting from block0
#ifdef NAND_USE_DDMA
	PDMA_CHANNEL_OBJECT RxDmaChannel;
	PDMA_CHANNEL_OBJECT TxDmaChannel;
	DWORD DmaSysIntr;
	HANDLE hDmaInterruptEvent;
#endif
} NAND_DEVICE, *PNAND_DEVICE;

#endif

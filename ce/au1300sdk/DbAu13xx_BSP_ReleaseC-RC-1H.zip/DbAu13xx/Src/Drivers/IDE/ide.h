//
// Copyright (c) 2005 BSQUARE Corporation.  All rights reserved.
//
//

#ifndef _CIDE_H_
#define _CIDE_H_

class CIDE : public CPCIDiskAndCD
{
private:
	PDMA_CHANNEL_OBJECT m_DmaChannel;
    DWORD               m_DmaSysIntr;                     // sysintr for DMA interrupts
    HANDLE              m_hDmaInterruptEvent;             // DMA interrupt event

	PMDL				m_pMDLHead;
public:
    CIDE(HKEY hKey) : CPCIDiskAndCD(hKey) {};
    virtual BOOL Init(HKEY hActiveKey);

    virtual BOOL SetupDMA( PSG_BUF pSgBuf, DWORD dwSgCount, BOOL fRead);
    virtual BOOL BeginDMA(BOOL fRead);
    virtual BOOL EndDMA();
    virtual BOOL AbortDMA();
    virtual BOOL CompleteDMA(PSG_BUF pSgBuf, DWORD dwSgCount, BOOL fRead);

	virtual DWORD ReadWriteDiskDMA(PIOREQ pIOReq, BOOL fRead);
};

#endif //_CIDE1200_H_




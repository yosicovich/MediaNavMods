//
// Copyright (c) 2005 BSQUARE Corporation.  All rights reserved.
//

#include <atamain.h>
#include <atapipcicd.h>
#include "platform.h"
#include "bceddk.h"
#include "ide.h"

//#undef DEBUGMSG
//#define DEBUGMSG(c,m) RETAILMSG(1,m)

// Set this to 1 to use MDLs for the DMA operations.
#define USE_MDL_DMA 1

EXTERN_C CDisk *CreateIDE(HKEY hDevKey)
{
    return new CIDE(hDevKey);
}

BOOL CIDE::Init(HKEY hActiveKey)
{
    BOOL bRet;
	DWORD hwIntr;

	bRet = CPCIDiskAndCD::Init(hActiveKey);

	// Change timeout to something sensible rather than the 20 second default...
	m_dwDiskIoTimeOut = 5000;

	if (!bRet) {
		RETAILMSG(1,(TEXT("CIDE - CPCIDiskAndCD::Init() Failed. Aborting\r\n")));
	}

	if (IsDMASupported()) {
		// Allocate DMA Channel
		m_DmaChannel = HalAllocateDMAChannel();

		if (m_DmaChannel==NULL) {
			RETAILMSG(1,(TEXT("CIDE Can't allocate DMA Channel\r\n")));
			bRet = FALSE;
			goto ErrorReturn;
		}

		// Start out as Receive
		HalInitDmaChannel(m_DmaChannel,
						  DMA_IDE_RX,
						  MAX_SECT_PER_COMMAND * 512,
						  TRUE);

		// set up DMA interrupt
		hwIntr = HalGetDMAHwIntr(m_DmaChannel);

		m_DmaSysIntr = InterruptConnect(Internal, 0, hwIntr, 0);

		if (SYSINTR_NOP==m_DmaSysIntr) {
			RETAILMSG(1,(TEXT("IDE: Can't allocate DMA SYSINTR\r\n")));
			goto ErrorReturn;
		}

			// allocate the dma interrupt event
		m_hDmaInterruptEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

		if (NULL == m_hDmaInterruptEvent) {
			RETAILMSG(1,(TEXT("IDE: Can't create DMA interrupt event\r\n")));
			goto ErrorReturn;
		}

		if (!InterruptInitialize(m_DmaSysIntr,
								 m_hDmaInterruptEvent,
								 NULL,
								 0)) {
			RETAILMSG(1,(TEXT("IDE: Call to InterruptInitialize failed\r\n")));
		}

		m_pMDLHead = NULL;
	}

ErrorReturn:

    return bRet;
}

BOOL CIDE::SetupDMA( PSG_BUF pSgBuf, DWORD dwSgCount, BOOL fRead)
{
	BOOL bStatus = TRUE;
	DWORD i;

#if (USE_MDL_DMA)
	PVOID pBuffer;
	PMDL pMDL = NULL;

	// Populate our MDLs.
	// We'll have one MDL for each SG buffer, linked via the Next field
	for (i=0;i<dwSgCount;i++) {
#if _WINCEOSVER < 600
		pBuffer = MapPtrToProcess((LPVOID)pSgBuf[i].sb_buf, GetCallerProcess());
#else
		pBuffer = pSgBuf[i].sb_buf;
#endif
		// Allocate our first, or next MDL
		if (m_pMDLHead==NULL) {
			pMDL = MmCreateMdl(NULL,pBuffer,pSgBuf[i].sb_len);
			m_pMDLHead = pMDL;
		} else {
			pMDL->Next = MmCreateMdl(NULL,pBuffer,pSgBuf[i].sb_len);
			pMDL = pMDL->Next;
		}
	}

	if (pMDL==NULL || m_pMDLHead==NULL) {
		RETAILMSG(1,(TEXT("Error create MDL for DMA transfer\r\n")));
		return FALSE;
	}

	// Terminate MDL list with a NULL Next pointer
	pMDL->Next = NULL;

	if (fRead) {
		HalReconfigureDMA(m_DmaChannel,DMA_IDE_RX);
	} else {
		HalReconfigureDMA(m_DmaChannel,DMA_IDE_TX);
	}

	HalSetupMdlDMA(m_DmaChannel,m_pMDLHead,fRead);

#else
	DWORD  transferSize = 0;
	PUCHAR pDmaBuffer;
	PUCHAR pTemp;

	for (i=0;i<dwSgCount;i++) {
		transferSize += pSgBuf[i].sb_len;
	}

	if (fRead) {
		// do we need to do anything ?

		HalStopDMA(m_DmaChannel);
		HalReconfigureDMA(m_DmaChannel,DMA_IDE_RX);

		pDmaBuffer = (PUCHAR)HalGetNextDMABuffer(m_DmaChannel);
		HalActivateDMABuffer(m_DmaChannel,pDmaBuffer,transferSize);
		pDmaBuffer = (PUCHAR)HalGetNextDMABuffer(m_DmaChannel);
		HalActivateDMABuffer(m_DmaChannel,pDmaBuffer,transferSize);

	} else {
		HalReconfigureDMA(m_DmaChannel,DMA_IDE_TX);
		// copy data to transmit buffer

		pTemp = pDmaBuffer = (PUCHAR)HalGetNextDMABuffer(m_DmaChannel);

		for (i=0;i<dwSgCount;i++) {
#if _WINCEOSVER < 600
            LPBYTE pBuffer = (PBYTE)MapPtrToProcess((LPVOID)pSgBuf[i].sb_buf, GetCallerProcess());
#else
           LPBYTE pBuffer = (PBYTE)pSgBuf[i].sb_buf;
#endif
			memcpy(pTemp,pBuffer,pSgBuf[i].sb_len);
			pTemp += pSgBuf[i].sb_len;
		}

		HalActivateDMABuffer(m_DmaChannel,pDmaBuffer,transferSize);
	}

#endif

	return bStatus;
}

BOOL CIDE::BeginDMA(BOOL fRead)
{
	BOOL bStatus = TRUE;

#if (USE_MDL_DMA)
	HalStartMdlDMA(m_DmaChannel);
#else
	HalStartDMA(m_DmaChannel);
#endif

	return bStatus;
}

BOOL CIDE::EndDMA()
{
	BOOL bStatus = TRUE;

	WaitForSingleObject(m_hDmaInterruptEvent,INFINITE);

	InterruptDone(m_DmaSysIntr);

	return bStatus;
}

BOOL CIDE::AbortDMA()
{
	BOOL bStatus = TRUE;
	PMDL pMDL = NULL, pMDLNext = NULL;

	HalStopDMA(m_DmaChannel);

#if (USE_MDL_DMA)

	HalCompleteMdlDMA(m_DmaChannel,m_pMDLHead);

	// Free the MDL list
	pMDL = m_pMDLHead;

	do {
		pMDLNext = pMDL->Next;
		MmFreeMdl(pMDL);
		pMDL = pMDLNext;
	} while (pMDL != NULL);

	m_pMDLHead = NULL;

#endif

	return bStatus;
}

BOOL CIDE::CompleteDMA(PSG_BUF pSgBuf, DWORD dwSgCount, BOOL fRead)
{
	BOOL bStatus = TRUE;

#if (USE_MDL_DMA)
	PMDL pMDL, pMDLNext;

	HalCompleteMdlDMA(m_DmaChannel,m_pMDLHead);

	// Free the MDL list
	pMDL = m_pMDLHead;

	do {
		pMDLNext = pMDL->Next;
		MmFreeMdl(pMDL);
		pMDL = pMDLNext;
	} while (pMDL != NULL);

	m_pMDLHead = NULL;

#else
	DWORD i;

	if (fRead) {
		PUCHAR pTemp;

		pTemp = (PUCHAR)HalGetNextDMABuffer(m_DmaChannel);

		for (i=0;i<dwSgCount;i++) {
#if _WINCEOSVER < 600
            LPBYTE pBuffer = (PBYTE)MapPtrToProcess((LPVOID)pSgBuf[i].sb_buf, GetCallerProcess());
#else
            LPBYTE pBuffer = (PBYTE)pSgBuf[i].sb_buf;
#endif
			memcpy(pBuffer,pTemp,pSgBuf[i].sb_len);
			if(0)
			{
			ULONG j;
			BYTE *p=(BYTE*)pBuffer;
				for(j=0; j<pSgBuf[i].sb_len; j+=8)
				{
					RETAILMSG(1,(TEXT("CompleteDMA: ADDR:%04X %X %X %X %X %X %X %X %X\r\n"),
					j, p[0],p[1],p[2],p[3],p[4],p[5],p[6],p[7]));
				}
			}
			pTemp += pSgBuf[i].sb_len;
		}
	} else {
		// Nothing to do for transmit
	}

#endif
	return bStatus;
}

DWORD CIDE::ReadWriteDiskDMA(PIOREQ pIOReq,BOOL fRead)
{
    DWORD dwError = ERROR_SUCCESS;
    PSG_REQ pSgReq = (PSG_REQ)pIOReq->pInBuf;
    DWORD dwSectorsToTransfer;
    SG_BUF CurBuffer[MAX_SG_BUF];
    BYTE bCmd;

    if ((pSgReq == NULL) || (pIOReq->dwInBufSize < sizeof(SG_REQ))) {
        return ERROR_INVALID_PARAMETER;
    }
    if ((pSgReq->sr_num_sec == 0) || (pSgReq->sr_num_sg == 0)) {
        return  ERROR_INVALID_PARAMETER;
    }
    if ((pSgReq->sr_start + pSgReq->sr_num_sec) > m_DiskInfo.di_total_sectors) {
        return ERROR_SECTOR_NOT_FOUND;
    }

    DEBUGMSG(0, (_T(
        "CIDE::ReadWriteDiskDMA> fRead(%d), sr_start(%ld), sr_num_sec(%ld)\r\n"
        ), fRead, pSgReq->sr_start, pSgReq->sr_num_sec));


    GetBaseStatus(); // clear pending interrupt

    DWORD dwStartBufferNum = 0, dwEndBufferNum = 0, dwEndBufferOffset = 0;
    DWORD dwNumSectors = pSgReq->sr_num_sec;
    DWORD dwStartSector = pSgReq->sr_start;

    // process scatter/gather buffers in groups of MAX_SEC_PER_COMMAND sectors
    // each DMA request handles a new SG_BUF array which is a subset of the
    // original request, and may start/stop in the middle of the original buffer

    while (dwNumSectors) {

		dwSectorsToTransfer = (dwNumSectors > MAX_SECT_PER_COMMAND) ? MAX_SECT_PER_COMMAND : dwNumSectors;

        // determine size (in bytes) of transfer
        DWORD dwBufferLeft = dwSectorsToTransfer * BYTES_PER_SECTOR;

        DWORD dwNumSg = 0;

        // while the transfer is not complete
        while (dwBufferLeft) {

            // determine the size of the current scatter/gather buffer
            DWORD dwCurBufferLen = pSgReq->sr_sglist[dwEndBufferNum].sb_len - dwEndBufferOffset;

            if (dwBufferLeft < dwCurBufferLen) {
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_buf = pSgReq->sr_sglist[dwEndBufferNum].sb_buf + dwEndBufferOffset;
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_len = dwBufferLeft;
                dwEndBufferOffset += dwBufferLeft;
                dwBufferLeft = 0;
            }
            else {
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_buf = pSgReq->sr_sglist[dwEndBufferNum].sb_buf + dwEndBufferOffset;
                CurBuffer[dwEndBufferNum - dwStartBufferNum].sb_len = dwCurBufferLen;
                dwEndBufferOffset = 0;
                dwEndBufferNum++;
                dwBufferLeft -= dwCurBufferLen;
            }
            dwNumSg++;
        }

        bCmd = fRead ? m_bDMAReadCommand : m_bDMAWriteCommand;

        WaitForInterrupt(0);

        // setup the DMA transfer
        if (!SetupDMA(CurBuffer, dwNumSg, fRead)) {
            dwError = fRead ? ERROR_READ_FAULT : ERROR_WRITE_FAULT;
            goto ExitFailure;
        }

        // write the read/write command
        if (!SendIOCommand(dwStartSector, dwSectorsToTransfer, bCmd)) {
            DEBUGMSG(ZONE_ERROR,(TEXT("Atapi!ReadWriteDiskDMA> Error sending IO Command fRead = %d\r\n"),fRead));
            dwError = fRead ? ERROR_READ_FAULT : ERROR_WRITE_FAULT;
            AbortDMA();
            goto ExitFailure;
        }

        // start the DMA transfer
        if (BeginDMA(fRead)) {
            if (m_fInterruptSupported) {
                if (!WaitForInterrupt(m_dwDiskIoTimeOut) || (CheckIntrState() == ATA_INTR_ERROR)) {
                    DEBUGMSG(ZONE_IO || ZONE_WARNING, (_T(
                        "Atapi!ReadWriteDiskDMA> Failed to wait for interrupt; device(%d)\r\n"
                        ), m_dwDeviceId));
                    dwError = ERROR_READ_FAULT;
                    AbortDMA();
                    goto ExitFailure;
                }
            }
            // stop the DMA transfer
            if (EndDMA()) {
                WaitOnBusy(FALSE);
                CompleteDMA(CurBuffer, pSgReq->sr_num_sg, fRead);
            }
        }

        // update transfer
        dwStartSector += dwSectorsToTransfer;
        dwStartBufferNum = dwEndBufferNum;
        dwNumSectors -= dwSectorsToTransfer;
    }

ExitFailure:
    if (ERROR_SUCCESS != dwError) {
        ResetController();
    }
    pSgReq->sr_status = dwError;
    return dwError;
}

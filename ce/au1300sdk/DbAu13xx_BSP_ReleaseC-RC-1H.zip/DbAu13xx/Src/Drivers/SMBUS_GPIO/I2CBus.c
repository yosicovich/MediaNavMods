/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*====== Include ======*/
#include <bceddk.h>
#include "platform.h"
#include "gpio.h"
#include "au1x00.h"

/*====== Define ======*/
#define IIC_SHOW_MSG	0

#define I2CWRITE	0x00
#define I2CREAD		0x01

#define DELAY_US 5


//SMB122 driver

#define CLK_BANK		2
#define CLK_BIT			10
#define DAT_BANK		1
#define DAT_BIT			28
#define SDA_GPIO		(DAT_BANK	* 32) + DAT_BIT

#define SET_CLK_HIGH()	\
	{	\
		pin_val[CLK_BANK] = (1<<CLK_BIT);	\
		OALStallExecution(DELAY_US);	\
	}
#define SET_CLK_LOW()	\
	{	\
		pin_valclr[CLK_BANK] = (1<<CLK_BIT);	\
		OALStallExecution(DELAY_US);	\
	}
#define SET_SDA_HIGH()	\
	{	\
		pin_val[DAT_BANK] = (1<<DAT_BIT);	\
		OALStallExecution(DELAY_US);	\
	}
#define SET_SDA_LOW()	\
	{	\
		pin_valclr[DAT_BANK] = (1<<DAT_BIT);	\
		OALStallExecution(DELAY_US);	\
	}

#define GET_SDA_DATA ((pin_val[DAT_BANK] & (1<<DAT_BIT)) ? 1 : 0)


#define ENTER_CRITICAL_AREA(a)		\
	{ 	\
		while(a == TRUE);	\
		a = TRUE;			\
	}

#define LEAVE_CRITICAL_AREA(a)		\
	{	\
		a = FALSE;	\
	}


/*====== Struct ======*/

typedef enum _IOCTRL_TYPE
{
	I2C_IOCTL_INIT,
	I2C_IOCTL_READ,
	I2C_IOCTL_WRITE,
	I2C_IOCTL_READ_WRITE,
	I2C_IOCTL_CLOSE,
	I2C_IOCTL_RADIO_READ,
	I2C_IOCTL_RADIO_WRITE,
	I2C_IOCTL_TRANS_READ,
	I2C_IOCTL_TRANS_WRITE

} IOCTRL_TYPE;

typedef struct _DEVICE_HANDLE
{
	ULONG openCount;
	BOOL controlMutex;

} DEVICE_HANDLE;

typedef struct _PARA_STRUCTURE
{
	BYTE addr;
	BYTE reg;
	BYTE *buffPtr;
	ULONG len;
} PARA_STRUCTURE;

/*====== Variable ======*/
unsigned int    *gpio_int = (unsigned int *)(GPINT_PHYS_ADDR + KSEG1_OFFSET + 0x1000);
unsigned int    *pin_val = (unsigned int *)(GPINT_PHYS_ADDR + KSEG1_OFFSET);
unsigned int    *pin_valclr = (unsigned int *)(GPINT_PHYS_ADDR + KSEG1_OFFSET + 0x10);
//I2C driver
#define SIGNAL_CLK			GPIO2_GPIO208	//GPIO208
#define SIGNAL_SDA			GPIO2_GPIO209	//GPIO209


static BOOL I2cMutex = FALSE;

/*====== Static Function ======*/
static void I2CPortInit(DEVICE_HANDLE *devHandlePtr);
static void I2CSendStart(void);
static void I2CSendStop(void);
static void I2CSendAck(void);
static void I2CSendNack(void);
static void I2CSendByte(unsigned char data);
static unsigned char I2CGetAck(void);
static unsigned char I2CGetByte(void);

static BOOL I2CPortReadWrite_Crypto(DEVICE_HANDLE *devHandlePtr,
						ULONG wtLen, ULONG rdLen,unsigned char *wtBuffPtr,unsigned char *rdBuffPtr);

static BOOL I2CPortWrite(DEVICE_HANDLE *devHandlePtr, unsigned char address, unsigned char reg, unsigned char *inBuffPtr, unsigned long wtLen);
static BOOL I2CPortRead(DEVICE_HANDLE *devHandlePtr, unsigned char address, unsigned char reg, unsigned char *outBuffPtr, unsigned long rdLen);

//
//
static BOOL Radio_IICRead(BYTE Addr, BYTE *pData, ULONG Bytes);
static BOOL Radio_IICWrite(BYTE Addr, BYTE *pData, ULONG Bytes);
static BOOL Trans_IICRead(BYTE Addr, BYTE Reg, BYTE *pData);
static BOOL Trans_IICWrite(BYTE Addr, BYTE Reg, BYTE Data);

/*====== Function Prototype ======*/

/*====== Function ======*/
/*-----------------------------------------------
 *	Name:	 	I2CBus_Entry
 *
 * 	Description:	The entry of I2CBus.dll
 *
 * 	Input:
 *
 * 	Return:
 *
 * 	Effect:
 *
 *----------------------------------------------- */

BOOL WINAPI I2CBus_Entry ( HINSTANCE DllInstance, INT Reason, LPVOID Reserved )
{
	switch(Reason)
	{
		case DLL_PROCESS_ATTACH:
		{
			RETAILMSG(IIC_SHOW_MSG, (TEXT("I2C BUS: DLL_Entry\r\n")));
			break;
		}

		case DLL_PROCESS_DETACH:

		break;
	}

	return TRUE;
}


/*-----------------------------------------------
 *	Name:	 	I2C_Init
 *
 * 	Description:	This function initializes a device
 *
 * 	Input:		ULONG dwContext: registry path for this device's active key
 *
 * 	Return:		Returns context data for this Init instance
 *
 * 	Effect:
 *
 *----------------------------------------------- */

ULONG I2C_Init(ULONG dwContext)
{
	DEVICE_HANDLE *devHandlePtr;

	devHandlePtr = (DEVICE_HANDLE *)LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT, sizeof(DEVICE_HANDLE));
	if (devHandlePtr == NULL)
	{
	    RETAILMSG(IIC_SHOW_MSG, (TEXT("IIC: Failed to allocate device instance.\r\n")));
	    return (ULONG)NULL;
	}

	RETAILMSG(IIC_SHOW_MSG, (TEXT("IIC: I2C_Init successfully(%x)\r\n"), devHandlePtr));
  	return (ULONG)devHandlePtr;
}

/*-----------------------------------------------
 *	Name:	 	I2C_Deinit
 *
 * 	Description:	This function uninitializes a device.
 *
 * 	Input:		ULONG Handle
 *
 * 	Return:		TRUE indicates success. FALSE indicates failure.
 *
 * 	Effect:		Pointer to the per disk structure
 *
 *----------------------------------------------- */
BOOL I2C_Deinit (ULONG Handle)
{
	DEVICE_HANDLE *devHandlePtr;

	devHandlePtr = (DEVICE_HANDLE *)Handle;

	LocalFree(devHandlePtr);

	RETAILMSG(IIC_SHOW_MSG, (TEXT("IIC: I2C_Deinit successfully.\r\n")));
	return TRUE;
}

/*-----------------------------------------------
 *	Name:	 	I2C_Open
 *
 * 	Description:	This function opens a device for reading, writing, or both.
 *
 * 	Input:		ULONG Handle:
 *				ULONG dwAccess:
 *				ULONG dwShareMode:
 *
 * 	Return:		Returns handle value for the open instance.
 *
 * 	Effect:
 *
 *----------------------------------------------- */
ULONG I2C_Open(ULONG Handle, ULONG dwAccess, ULONG dwShareMode)
{
	DEVICE_HANDLE *devHandlePtr;

	devHandlePtr = (DEVICE_HANDLE *)Handle;

	devHandlePtr->openCount++;
	RETAILMSG(IIC_SHOW_MSG, (TEXT("IIC: Driver open count(%x).\r\n"), devHandlePtr->openCount));


	return (ULONG)devHandlePtr;
}

/*-----------------------------------------------
 *	Name:	 	I2C_Close
 *
 * 	Description:	This function closes a device context created by the Handle parameter.
 *
 * 	Input:		ULONG Handle: Used to identify the open context of the device.
 *
 * 	Return:		TRUE indicates success. FALSE indicates failure.
 *
 * 	Effect:
 *
 *----------------------------------------------- */
BOOL I2C_Close (ULONG Handle)
{
	DEVICE_HANDLE *devHandlePtr;

	devHandlePtr = (DEVICE_HANDLE *)Handle;

	devHandlePtr->openCount--;
	RETAILMSG(IIC_SHOW_MSG, (TEXT("IIC: Driver close count(%x).\r\n"), devHandlePtr->openCount));

	return TRUE;
}




/*-----------------------------------------------
 *	Name:	 	I2C_IOControl
 *
 * 	Description:	This function sends a command to a device.
 *
 * 	Input:		ULONG Handle:
 *				ULONG dwIoControlCode:
 *				PBYTE pInBuf: Pointer to the buffer containing
 *						data to transfer to the device.
 *				ULONG nInBufSize: Number of bytes of data
 *						in the buffer specified for pBufIn.
 *				PBYTE pOutBuf: Pointer to the buffer used to
 *						transfer the output data from the device.
 *				ULONG nOutBufSize: Maximum number of bytes
 *						in the buffer specified by pBufOut.
 *				PULONG pBytesReturned: Pointer to the ULONG
 *						buffer that this function uses to return the
 *						actual number of bytes received from the device.
 *
 * 	Return:		TRUE indicates success. FALSE indicates failure.
 *
 * 	Effect:
 *
 *----------------------------------------------- */
BOOL I2C_IOControl(ULONG Handle, ULONG dwIoControlCode, PBYTE pInBuf,
                    ULONG nInBufSize, PBYTE pOutBuf, ULONG nOutBufSize, PULONG pBytesReturned )
{

	DEVICE_HANDLE *devHandlePtr;
	IOCTRL_TYPE ioCtrlType;
	PARA_STRUCTURE *buffPtr;
	
	RETAILMSG(IIC_SHOW_MSG, (TEXT("I2C_IOControl: entry. \r\n")));
	devHandlePtr = (DEVICE_HANDLE *)Handle;
//
// Check parameters
//
	ioCtrlType = (IOCTRL_TYPE)dwIoControlCode;
	switch ( ioCtrlType )
	{
		case I2C_IOCTL_INIT:
		case I2C_IOCTL_CLOSE:
			break;
		case I2C_IOCTL_READ:
		{
			if (pOutBuf == NULL)
				return FALSE;
			break;
		}
		case I2C_IOCTL_WRITE:
		{
			if ((pInBuf == NULL) || (nInBufSize != sizeof(PARA_STRUCTURE)))
				return FALSE;
			break;
		}

		default:
		{
			SetLastError(ERROR_INVALID_PARAMETER);
			return FALSE;
		}
	}


//
// Execute dwIoControlCode
//
	switch (ioCtrlType)
	{
		case I2C_IOCTL_INIT:
		{
			RETAILMSG(IIC_SHOW_MSG, (TEXT("IIC: I2C_IOCTL_INIT.\r\n")));
			I2CPortInit(devHandlePtr);
			break;
		}

		case I2C_IOCTL_CLOSE:
		{

			break;
		}

		case I2C_IOCTL_READ:
		{
			buffPtr = (PARA_STRUCTURE *)pOutBuf;
			RETAILMSG(IIC_SHOW_MSG, (TEXT("IIC: I2C_IOCTL_READ (addr, reg, len) (%x, %x, %x).\r\n"),
				buffPtr->addr, buffPtr->reg, buffPtr->len));
			if (!I2CPortRead(devHandlePtr, buffPtr->addr, buffPtr->reg, buffPtr->buffPtr, buffPtr->len))
				return FALSE;
			break;
		}

		case I2C_IOCTL_WRITE:
		{
			buffPtr = (PARA_STRUCTURE *)pInBuf;
			RETAILMSG(IIC_SHOW_MSG, (TEXT("IIC: I2C_IOCTL_WRITE (addr, reg, len) (%x, %x, %x).\r\n"),
				buffPtr->addr, buffPtr->reg, buffPtr->len));
			if (!I2CPortWrite(devHandlePtr, buffPtr->addr, buffPtr->reg, buffPtr->buffPtr, buffPtr->len))
				return FALSE;
			break;
		}
	}

	return TRUE;
}

/*-----------------------------------------------
 *	Name:	 	I2C_Read
 *
 * 	Description:
 *
 * 	Input:		ULONG Handle:
 *				LPVOID pBuffer:
 *				ULONG dwNumBytes:
 *
 * 	Return:
 *
 * 	Effect:
 *
 *----------------------------------------------- */
ULONG I2C_Read(ULONG Handle, LPVOID pBuffer, ULONG dwNumBytes)
{
  	return 0;
}

/*-----------------------------------------------
 *	Name:	 	I2C_Write
 *
 * 	Description:
 *
 * 	Input:		ULONG Handle:
 *				LPVOID pBuffer:
 *				ULONG dwNumBytes:
 *
 * 	Return:
 *
 * 	Effect:
 *
 *----------------------------------------------- */
ULONG I2C_Write(ULONG Handle, LPCVOID pBuffer, ULONG dwNumBytes)
{
  	return 0;
}

/*-----------------------------------------------
 *	Name:	 	I2C_Seek
 *
 * 	Description:
 *
 * 	Input:		ULONG Handle:
 *				LPVOID IDistance:
 *				ULONG dwMoveMethod:
 *
 * 	Return:
 *
 * 	Effect:
 *
 *----------------------------------------------- */
ULONG I2C_Seek(ULONG Handle, long lDistance, ULONG dwMoveMethod)
{
  	return -1;
}

/*-----------------------------------------------
 *	Name:	 	I2C_PowerUp
 *
 * 	Description:
 *
 * 	Input:		None
 *
 * 	Return:		None
 *
 * 	Effect:
 *
 *----------------------------------------------- */
void I2C_PowerUp(ULONG Handle)
{
#ifdef PLATFORM_I2C_POWERUP_CODE
	PLATFORM_I2C_POWERUP_CODE
#endif

	return;
}

/*-----------------------------------------------
 *	Name:	 	I2C_PowerDown
 *
 * 	Description:
 *
 * 	Input:		None
 *
 * 	Return:		None
 *
 * 	Effect:
 *
 *----------------------------------------------- */
void I2C_PowerDown (ULONG Handle)
{
#ifdef PLATFORM_I2C_POWERDOWN_CODE
	PLATFORM_I2C_POWERDOWN_CODE
#endif

	return;
}

//I2C Bus driver

static void I2CSendStart(void)
{
	SET_SDA_HIGH();
	SET_CLK_HIGH();
	SET_SDA_LOW();
	SET_CLK_LOW();

	// tristate SDA
	gpio_int[SDA_GPIO] = 0;

	return;
}
static void I2CSendStop(void)
{
	SET_SDA_LOW();
	SET_CLK_HIGH();
	SET_SDA_HIGH();
	SET_CLK_LOW();

	// tristate SDA
	gpio_int[SDA_GPIO] = 0;

	return;
}
static void I2CSendAck(void)
{
	SET_CLK_LOW();
	SET_SDA_LOW();
	SET_CLK_HIGH();
	SET_CLK_LOW();

	// tristate SDA
	gpio_int[SDA_GPIO] = 0;

	return;
}
static void I2CSendNack(void)
{
	SET_CLK_LOW();
	SET_SDA_HIGH();
	SET_CLK_HIGH();
	SET_CLK_LOW();

	// tristate SDA
	gpio_int[SDA_GPIO] = 0;

	return;
}

static void I2CSendByte(unsigned char data)
{
	BYTE bit;

	for (bit = 0x80; bit != 0; bit >>= 1)
	{
		if (data & bit)
		{
			SET_SDA_HIGH();
		} else {
			SET_SDA_LOW();
		}

		SET_CLK_HIGH();
		SET_CLK_LOW();
	}

	// tristate SDA
	gpio_int[SDA_GPIO] = 0;

	return;
}

static unsigned char I2CGetAck(void)
{
	BYTE status;

	SET_CLK_HIGH();

	status = GET_SDA_DATA;

	SET_CLK_LOW();

	return (!status);
}

static unsigned char I2CGetByte(void)
{
	BYTE status, data = 0;
	unsigned int i;
	for(i=0; i<8; i++)
	{
		data <<= 1;
		SET_CLK_HIGH();
		status = GET_SDA_DATA;
	   	data |= status;
		SET_CLK_LOW();
	}

	return data;
}

static void I2CPortInit(DEVICE_HANDLE *devHandlePtr)
{
	ENTER_CRITICAL_AREA(I2cMutex);


	SET_CLK_HIGH();

	SET_SDA_HIGH();

	LEAVE_CRITICAL_AREA(I2cMutex);

	return;
}

static BOOL I2CPortWrite(DEVICE_HANDLE *devHandlePtr, BYTE address, BYTE reg, BYTE *inBuffPtr, ULONG wtLen)
{
	BYTE *dataPtr = inBuffPtr;
	ULONG i;

	if (wtLen < 1)
		return TRUE;

	ENTER_CRITICAL_AREA(I2cMutex);

	I2CSendStart();
	I2CSendByte((unsigned char)((address << 1) | I2CWRITE));
	if (!I2CGetAck())
	{
		RETAILMSG(IIC_SHOW_MSG,(TEXT("I2CPortWrite: NACK received after send address. Err!!\n")));
		I2CSendStop();
		return FALSE;
	}

	I2CSendByte(reg);
	if (!I2CGetAck())
	{
		RETAILMSG(IIC_SHOW_MSG,(TEXT("I2CPortWrite: NACK received after command. Err!!\n")));
		I2CSendStop();
		return FALSE;
	}

	for (i=0; i<wtLen; i++)
	{
		I2CSendByte(*inBuffPtr++);
		if (!I2CGetAck())
		{
			RETAILMSG(IIC_SHOW_MSG,(TEXT("I2CPortWrite: Received data (%x) Err!!\n"), i));
			I2CSendStop();
			return FALSE;
		}
	}

	I2CSendStop();

	LEAVE_CRITICAL_AREA(I2cMutex);

	return TRUE;
}


static BOOL I2CPortRead(DEVICE_HANDLE *devHandlePtr, BYTE address, BYTE reg, BYTE *outBuffPtr, ULONG rdLen)
{
	ULONG i;
	BYTE *dataPtr = outBuffPtr;
	BOOL retval = TRUE;

	if (rdLen < 1)
		return TRUE;

	ENTER_CRITICAL_AREA(I2cMutex);

	I2CSendStop();

	//Send read data command
	I2CSendStart();

	I2CSendByte((unsigned char)((address << 1) | I2CWRITE));
	if (!I2CGetAck())
	{
		RETAILMSG(IIC_SHOW_MSG,(TEXT("I2CPortRead: Can not get ACK after send address. Err!!\r\n")));
		retval = FALSE;
		goto End;
	}
	I2CSendByte(reg & 0xff);
	if (!I2CGetAck())
	{
		RETAILMSG(IIC_SHOW_MSG,(TEXT("I2CPortRead: Can not get ACK after send command. Err!!\r\n")));
		retval = FALSE;
		goto End;
	}

	//Read data from device
	I2CSendStart();
	I2CSendByte((unsigned char)((address << 1) | I2CREAD));
	if (!I2CGetAck())
	{
		RETAILMSG(IIC_SHOW_MSG,(TEXT("I2CPortRead: NACK received after send 2nd address. Err!!\r\n")));
		retval = FALSE;
		goto End;
	}

	for(i=1; i<=rdLen; i++)
	{
		*dataPtr++ = I2CGetByte();
		if (i != rdLen)
		{
			I2CSendAck();
		} else {
			I2CSendNack();
		}
	}

//	for(i=0; i<rdLen; i++)
//		RETAILMSG(1,(TEXT(" %02X, "), outBuffPtr[i]));
//	RETAILMSG(1,(TEXT("\r\n")));

End:
	I2CSendStop();
	LEAVE_CRITICAL_AREA(I2cMutex);
	return retval;



}


static int iicWriteByte(BYTE Data)
{
#define MAX_NACK 36
    BYTE i = 0;

	do
	{
		I2CSendStop();
		I2CSendStart();

		I2CSendByte(Data);

	} while(!I2CGetAck() && (++i < MAX_NACK));	//Loop while slave doesn't ACK

	return !(i == MAX_NACK);
}

static BOOL Trans_IICRead(BYTE Addr, BYTE Reg, BYTE *pData)
{
	BOOL bRetCodes = FALSE;

	ENTER_CRITICAL_AREA(I2cMutex);

	I2CSendStart();

	if(iicWriteByte(Addr|I2CWRITE))
	{
		if(iicWriteByte(Reg))
		{
			I2CSendStart();

			if(iicWriteByte(Addr|I2CREAD))
			{
				*pData = I2CGetByte();
				I2CSendNack();

				bRetCodes = TRUE;
			}
		}
	}
    I2CSendStop();

    LEAVE_CRITICAL_AREA(I2cMutex);
    return bRetCodes;
}

static BOOL Trans_IICWrite(BYTE Addr, BYTE Reg, BYTE Data)
{
	BOOL bRetCodes = FALSE;

	ENTER_CRITICAL_AREA(I2cMutex);

	I2CSendStart();

	if(iicWriteByte(Addr|I2CWRITE))
	{
		if(iicWriteByte(Reg))
		{
			if(iicWriteByte(Data))
				bRetCodes = TRUE;
		}
	}
	I2CSendStop();

    LEAVE_CRITICAL_AREA(I2cMutex);
    return bRetCodes;
}

//
BOOL IICRead_Radio(HANDLE Handle, BYTE Addr, BYTE *pData, ULONG Bytes)
{
	BOOL bRetCodes;
	ULONG actLen = 0;
	BYTE inBuf[8];

	*((ULONG*)inBuf)     = (ULONG)Addr;
	*((ULONG*)inBuf + 1) = (ULONG)Bytes;

	bRetCodes = DeviceIoControl( Handle,
								 I2C_IOCTL_RADIO_READ,
								 (PVOID)inBuf,
								 sizeof(ULONG)*2,
								 (PVOID)pData,
								 sizeof(BYTE*),
								 &actLen,
								 NULL);
	return bRetCodes;
}

BOOL IICWrite_Radio(HANDLE Handle, BYTE Addr, BYTE *pData, ULONG Bytes)
{
	BOOL bRetCodes;
	ULONG actLen = 0;
	BYTE inBuf[16];

	*((ULONG*)inBuf)     = (ULONG)Addr;
	*((ULONG*)inBuf + 1) = (ULONG)pData;
	*((ULONG*)inBuf + 2) = (ULONG)Bytes;

	bRetCodes = DeviceIoControl( Handle,
								 I2C_IOCTL_RADIO_WRITE,
								 (PVOID)inBuf,
								 sizeof(ULONG)*3,
								 NULL,
								 0,
								 &actLen,
								 NULL);
	return bRetCodes;
}

BOOL IICRead_Trans(HANDLE Handle, BYTE Addr, BYTE Reg, BYTE *pData)
{
	BOOL bRetCodes;
	ULONG actLen = 0;
	BYTE inBuf[4];

	inBuf[0] = Addr;
	inBuf[1] = Reg;

	bRetCodes = DeviceIoControl( Handle,
								 I2C_IOCTL_TRANS_READ,
								 (PVOID)inBuf,
								 sizeof(BYTE)*2,
								 (PVOID)pData,
								 sizeof(BYTE*),
								 &actLen,
								 NULL);
	return bRetCodes;
}

BOOL IICWrite_Trans(HANDLE Handle, BYTE Addr, BYTE Reg, BYTE Data)
{
	BOOL bRetCodes;
	ULONG actLen = 0;
	BYTE inBuf[4];

	inBuf[0] = Addr;
	inBuf[1] = Reg;
	inBuf[2] = Data;

	bRetCodes = DeviceIoControl( Handle,
								 I2C_IOCTL_TRANS_WRITE,
								 (PVOID)inBuf,
								 sizeof(BYTE)*3,
								 NULL,
								 0,
								 &actLen,
								 NULL);
	return bRetCodes;
}


// RF MODULE IIC END
//

HANDLE IICOpen(void)
{
	HANDLE handle;

	RETAILMSG(IIC_SHOW_MSG, (L"IICOpen: GPIO_Init. \r\n"));
	handle = CreateFile(TEXT("I2C1:"), 0, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	return handle;
}

void IICClose(HANDLE handle)
{
	CloseHandle(handle);
}

BOOL IICWriteData(HANDLE handle, BYTE address, BYTE reg, BYTE *inBuffPtr, ULONG wtLen)
{
	ULONG tmp;
	BOOL retVal;
	PARA_STRUCTURE inPara;

	inPara.addr = address;
	inPara.reg = reg;
	inPara.buffPtr = inBuffPtr;
	inPara.len = wtLen;

	RETAILMSG(IIC_SHOW_MSG, (TEXT("IICWriteData: entry. \r\n")));
	retVal = DeviceIoControl(
		handle,
		I2C_IOCTL_WRITE,
		(void *)&inPara,
		sizeof(inPara),
		NULL,
		0,
		&tmp,
		NULL);

	return retVal;
}

BOOL IICReadData(HANDLE handle, BYTE address, BYTE reg, BYTE *outBuffPtr, ULONG rdLen)
{
	ULONG tmp;
	BOOL retVal;
	PARA_STRUCTURE inPara;

	RETAILMSG(IIC_SHOW_MSG, (TEXT("IICReadData: entry. \r\n")));
	inPara.addr = address;
	inPara.reg = reg;
	inPara.buffPtr = outBuffPtr;
	inPara.len = rdLen;

	retVal = DeviceIoControl(
		handle,
		I2C_IOCTL_READ,
		NULL,
		0,
		(void *)&inPara,
		sizeof(inPara),
		&tmp,
		NULL);

	return retVal;
}

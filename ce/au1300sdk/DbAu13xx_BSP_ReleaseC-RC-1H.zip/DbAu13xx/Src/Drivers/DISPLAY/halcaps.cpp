/*****************************************************************************
Copyright 2003-2007 Raza Microelectronics, Inc.(RMI). All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY Raza Microelectronics, Inc. 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "precomp.h"

extern DDGPE * gGPE;

// callbacks from the DIRECTDRAW object

DDHAL_DDCALLBACKS cbDDCallbacks =
{
    sizeof( DDHAL_DDCALLBACKS ),
        DDHAL_CB32_CREATESURFACE        |
        DDHAL_CB32_WAITFORVERTICALBLANK |
        DDHAL_CB32_CANCREATESURFACE     |
        DDHAL_CB32_CREATEPALETTE        |
//      DDHAL_CB32_GETSCANLINE          |
        0,
    DDGPECreateSurface,
    HalWaitForVerticalBlank,
    DDGPECanCreateSurface,
    DDGPECreatePalette,
    NULL
};

// callbacks from the DIRECTDRAWPALETTE object

DDHAL_DDPALETTECALLBACKS cbDDPaletteCallbacks = {

    sizeof( DDHAL_DDPALETTECALLBACKS ), // dwSize
    DDHAL_PALCB32_DESTROYPALETTE |		// dwFlags
    DDHAL_PALCB32_SETENTRIES |
	0,
    DDGPEDestroyPalette,				// DestroyPalette
    DDGPESetEntries					// SetEntries
};

// callbacks from the DIRECTDRAWCOLORCONTROL pseudo object

DDHAL_DDCOLORCONTROLCALLBACKS ColorControlCallbacks =
{
    sizeof(DDHAL_DDCOLORCONTROLCALLBACKS),
    0, // DDHAL_COLOR_COLORCONTROL,
    0, // ColorControl
	0  // GammaControl
};


// callbacks from the DIRECTDRAWMISCELLANEOUS object

DDHAL_DDMISCELLANEOUSCALLBACKS MiscellaneousCallbacks = {

    sizeof(DDHAL_DDMISCELLANEOUSCALLBACKS),
	0,
    0, //GetAvailDriverMemory,
    0, //GetDeviceIdentifier,
};


// callbacks from the DIRECTDRAWSURFACE object

DDHAL_DDSURFACECALLBACKS cbDDSurfaceCallbacks =
{
    sizeof( DDHAL_DDSURFACECALLBACKS ),
        DDHAL_SURFCB32_DESTROYSURFACE     |
        DDHAL_SURFCB32_FLIP               |
        DDHAL_SURFCB32_LOCK               |
        DDHAL_SURFCB32_UNLOCK             |
        DDHAL_SURFCB32_SETCOLORKEY        |
        DDHAL_SURFCB32_GETBLTSTATUS       |
        DDHAL_SURFCB32_GETFLIPSTATUS      |
        DDHAL_SURFCB32_UPDATEOVERLAY      |
        DDHAL_SURFCB32_SETOVERLAYPOSITION |
        DDHAL_SURFCB32_SETPALETTE         |
        0,
    DDGPEDestroySurface,
    HalFlip,
    HalLock,
    DDGPEUnlock,
    DDGPESetColorKey,
    HalGetBltStatus,
    HalGetFlipStatus,
    HalUpdateOverlay,
    HalSetOverlayPosition,
    DDGPESetPalette
};

// InitDDHALInfo must set up this information
unsigned long           g_nVideoMemorySize      = 0L;
unsigned char *         g_pVideoMemory          = NULL; // virtual address of video memory from client's side
DWORD                   g_nTransparentColor     = 0L;

DWORD WINAPI
HalGetDriverInfo(
    LPDDHAL_GETDRIVERINFODATA lpInput
    )
{
    lpInput->ddRVal = DDERR_CURRENTLYNOTAVAIL;
    return DDHAL_DRIVER_HANDLED;
}

DWORD WINAPI HalLock( LPDDHAL_LOCKDATA pd )
{
    /*
     * If someone is accessing a surface that was just flipped away from,
     * make sure that the old surface (what was the primary) has finished
     * being displayed.
     *
     */
    HRESULT     ddrval;

    /*
     * check to see if any pending physical flip has occurred
     */
	ddrval = ((Au12 *)gGPE)->FlipInProgress() ? DDERR_WASSTILLDRAWING : DD_OK;

    if( ddrval != DD_OK )
    {
        pd->ddRVal = DDERR_WASSTILLDRAWING;
        return DDHAL_DRIVER_HANDLED;
    }
    return DDGPELock(pd);
}


DWORD WINAPI HalGetBltStatus( LPDDHAL_GETBLTSTATUSDATA pd )
{

	// Implementation

	pd->ddRVal = DD_OK;


	if (IS_BUSY)
	{
		DEBUGMSG(1 /*GPE_ZONE_FLIP*/, (L"HalGetBltStatus: busy flipping, no blt!\r\n"));
		pd->ddRVal = DDERR_WASSTILLDRAWING;
	}

	return DDHAL_DRIVER_HANDLED;
}



DWORD WINAPI HalWaitForVerticalBlank( LPDDHAL_WAITFORVERTICALBLANKDATA pd )
{

	switch (pd->dwFlags) {
	case DDWAITVB_I_TESTVB:
		// If TESTVB, it's just a request for the current vertical blank
		// status:
		pd->bIsInVB = IN_VBLANK;
		break;
	case DDWAITVB_BLOCKBEGIN:
		// If BLOCKBEGIN is requested, we wait until the vertical blank
		// is over, and then wait for the display period to end:
		while (IN_VBLANK);
		while (!IN_VBLANK);
		break;
	case DDWAITVB_BLOCKEND:
		// If BLOCKEND is requested, we wait for the vblank interval to end:
        if( IN_VBLANK )
        {
            while( IN_VBLANK );
        }
        else
        {
            while(!IN_VBLANK);
            while(IN_VBLANK);
        }
		break;

	default: // anything else is an error
		return DDHAL_DRIVER_NOTHANDLED;
    }

	pd->ddRVal = DD_OK;
	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalFlip( LPDDHAL_FLIPDATA pd )
{
	int overlayIndex;

    HRESULT ddrval;

    DDGPESurf* pSurfCurr = DDGPESurf::GetDDGPESurf(pd->lpSurfCurr);

    /*
     * check to see if any pending physical flip has occurred
     */
	ddrval = ((Au12 *)gGPE)->FlipInProgress() ? DDERR_WASSTILLDRAWING : DD_OK;
	if (DDERR_WASSTILLDRAWING==ddrval)
	{
		pd->ddRVal = ddrval;
		return DDHAL_DRIVER_HANDLED;
	}


	((Au12 *)gGPE)->WaitForVBlank();

	// Handle flipping overlay surfaces
	for (overlayIndex=0;overlayIndex<NUM_OVERLAYS;overlayIndex++) {
		if (((Au12 *)gGPE)->GetOverlayOffset(overlayIndex) == pSurfCurr->OffsetInVideoMemory()) {
			pd->ddRVal = ((Au12 *)gGPE)->SetOverlaySurface(overlayIndex,pd->lpSurfTarg);
			DEBUGMSG(1,(TEXT("Flipped Overlay %d\r\n"),overlayIndex));
			break;
		}
	}
	if (overlayIndex==NUM_OVERLAYS) {
		// Wasn't an overlay so flip main surface
		DDGPEFlip(pd);
	}

	DEBUGMSG(GPE_ZONE_FLIP,(TEXT("Flip done\r\n")));

	pd->ddRVal = DD_OK;
	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalGetFlipStatus( LPDDHAL_GETFLIPSTATUSDATA pd )
{
	DEBUGENTER( HalGetFlipStatus );
    pd->ddRVal = ((Au12 *)gGPE)->FlipInProgress() ? DDERR_WASSTILLDRAWING : DD_OK;
	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalCreateExecuteBuffer( LPDDHAL_CREATESURFACEDATA pd )
{
	DEBUGENTER( HalCreateExecuteBuffer );
	// Implementation
	pd->ddRVal = DD_OK;

	return DDHAL_DRIVER_HANDLED;
}


DWORD WINAPI HalDestroyExecuteBuffer( LPDDHAL_DESTROYSURFACEDATA pd )
{
	DEBUGENTER( HalDestroyExecutebuffer );
	// Implementation
	pd->ddRVal = DD_OK;

	return DDHAL_DRIVER_HANDLED;
}

DWORD WINAPI HalUpdateOverlay( LPDDHAL_UPDATEOVERLAYDATA  pd )
{
	RETAILMSG(1,(TEXT("HalUpdateOverlay\r\n")));

	// Implementation

	if (pd->dwFlags & DDOVER_HIDE) {
		// Hide the overlay
		pd->ddRVal = ((Au12 *)gGPE)->HideOverlay(pd->lpDDSrcSurface);

	} else {
		DWORD colorKey = 0, width, height;
		DWORD alphaValue = 255;
		DDGPESurf* pColorKeySurf = NULL;

//		if (lpSource->ddpfSurface.dwFlags & DDPF_FOURCC) {
//			return DDHAL_DRIVER_NOTHANDLED;
//		}

		width =  pd->rSrc.right   - pd->rSrc.left;
		height = pd->rSrc.bottom  - pd->rSrc.top;

		// We can do source or destination color keying, BUT only ONE AT A TIME
		// We'll let source keying take precedence if both are set.

		if (pd->dwFlags & DDOVER_KEYSRC || pd->dwFlags & DDOVER_KEYSRCOVERRIDE) {
			// Get source colour key
			if (pd->dwFlags & DDOVER_KEYSRC) {
				colorKey = pd->lpDDDestSurface->ddckCKSrcOverlay.dwColorSpaceLowValue;
			} else {
				colorKey = pd->overlayFX.dckSrcColorkey.dwColorSpaceLowValue;
			}

			pColorKeySurf = DDGPESurf::GetDDGPESurf(pd->lpDDSrcSurface);

			RETAILMSG(1,(TEXT("Source color keying 0x%08X\r\n"),colorKey));
		} else if (pd->dwFlags & DDOVER_KEYDEST || pd->dwFlags & DDOVER_KEYDESTOVERRIDE) {
			// Get destination colour key
			if (pd->dwFlags & DDOVER_KEYDEST) {
				colorKey = pd->lpDDDestSurface->ddckCKDestOverlay.dwColorSpaceLowValue;
			} else {
				colorKey = pd->overlayFX.dckDestColorkey.dwColorSpaceLowValue;
			}
			RETAILMSG(1,(TEXT("Destination color keying 0x%08X\r\n"),colorKey));

			pColorKeySurf = DDGPESurf::GetDDGPESurf(pd->lpDDDestSurface);
		}

		// Convert color key pixel format to RGB 888
		if (pColorKeySurf) {
			UCHAR r,g,b;
			switch(pColorKeySurf->PixelFormat()) {
				case ddgpePixelFormat_8880:
				case ddgpePixelFormat_8888:
					// Swap R and B

                    r = (UCHAR)(colorKey & 0x000000FF);
                    g = (UCHAR)((colorKey & 0x0000FF00)>>8);
                    b = (UCHAR)((colorKey & 0x00FF0000)>>16);

					colorKey = (r<<16) | (g<<8) | b;
					break;

				case ddgpePixelFormat_565:

					r = (UCHAR)((colorKey & 0xF800) >> 11);
					g = (UCHAR)((colorKey & 0x07E0) >> 5);
					b = (UCHAR)(colorKey & 0x001F);

					r <<= 3;
					g <<= 2;
					b <<= 3;

					colorKey = (r<<16) | (g<<8) | b;
					break;


				case ddgpePixelFormat_8bpp:
					// Nothing to do ? Can we support this ?
					break;

				default:
					RETAILMSG(1, (TEXT("Unsupported overlay colorkey pixelformat! %d\r\n"),pColorKeySurf->PixelFormat()));
					pd->ddRVal = DDERR_UNSUPPORTED;
					return DDHAL_DRIVER_HANDLED;
			}

		}

		// Handle source alpha blending
		if (pd->dwFlags & DDOVER_ALPHACONSTOVERRIDE) {
			alphaValue = pd->overlayFX.dwAlphaConst;

			if (pd->dwFlags & DDOVER_ALPHASRCNEG) {
				alphaValue = 255 - alphaValue;
			}
		}
		pd->ddRVal = ((Au12 *)gGPE)->ShowOverlay(pd->lpDDSrcSurface,
		                                                width,
		                                                height,
		                                                pd->rDest.left,
		                                                pd->rDest.top,
		                                                colorKey,
														alphaValue,
		                                                pd->dwFlags,
		                                                pd->overlayFX);
	}

	if (pd->ddRVal == DD_OK) {
		return DDHAL_DRIVER_HANDLED;
	} else {
		return DDHAL_DRIVER_NOTHANDLED;
	}
}

DWORD WINAPI HalSetOverlayPosition( LPDDHAL_SETOVERLAYPOSITIONDATA  pd )
{
	DEBUGENTER( HalSetOverlayPosition );

 	DEBUGMSG(1,(TEXT("HalSetOverlayPosition %d,%d\r\n"),pd->lXPos,pd->lYPos));

	int overlayIndex;
    DDGPESurf *pSurf = DDGPESurf::GetDDGPESurf(pd->lpDDSrcSurface);

	// Implementation

	// find overlay index ?
	for (overlayIndex=0;overlayIndex<NUM_OVERLAYS;overlayIndex++) {
		if (((Au12 *)gGPE)->GetOverlayOffset(overlayIndex) == pSurf->OffsetInVideoMemory()) {

			pd->ddRVal = ((Au12 *)gGPE)->SetOverlayPosition(overlayIndex,pd->lXPos, pd->lYPos);

			break;
		}
	}

	return DDHAL_DRIVER_HANDLED;
}


EXTERN_C void
buildDDHALInfo(
    LPDDHALINFO lpddhi,
    DWORD modeidx
    )
{
    Au12 * pAu12 = static_cast<Au12 *>(GetDDGPE());

    if( !g_pVideoMemory )   // in case this is called more than once...
    {
        unsigned long VideoMemoryStart;

        pAu12->GetVirtualVideoMemory( &VideoMemoryStart, &g_nVideoMemorySize );
        DEBUGMSG( GPE_ZONE_INIT,(TEXT("GetVirtualVideoMemory returned addr=0x%08x size=%d\r\n"), VideoMemoryStart, g_nVideoMemorySize));

        g_pVideoMemory = (BYTE*)VideoMemoryStart;
        DEBUGMSG( GPE_ZONE_INIT,(TEXT("gpVidMem=%08x\r\n"), g_pVideoMemory ));
    }

    memset( lpddhi, 0, sizeof(DDHALINFO) );         // Clear the DDHALINFO structure

    lpddhi->dwSize = sizeof(DDHALINFO);

    lpddhi->lpDDCallbacks = &cbDDCallbacks;
    lpddhi->lpDDSurfaceCallbacks = &cbDDSurfaceCallbacks;
    lpddhi->lpDDPaletteCallbacks = &cbDDPaletteCallbacks;
    lpddhi->GetDriverInfo = HalGetDriverInfo;

    lpddhi->lpdwFourCC = 0;

    // Capability bits.

    lpddhi->ddCaps.dwSize = sizeof(DDCAPS);

    lpddhi->ddCaps.dwVidMemTotal = g_nVideoMemorySize;
    lpddhi->ddCaps.dwVidMemFree = g_nVideoMemorySize;

    lpddhi->ddCaps.dwVidMemStride = 0;

	lpddhi->ddCaps.dwNumFourCCCodes = 0;		// number of four cc codes
	lpddhi->ddCaps.dwAlignBoundarySrc = 4;		// source rectangle alignment
	lpddhi->ddCaps.dwAlignSizeSrc = 8;			// source rectangle byte size
	lpddhi->ddCaps.ddsCaps.dwCaps=				// DDSCAPS structure has all the general capabilities
//		DDSCAPS_ALPHA |							// Can create alpha-only surfaces
		DDSCAPS_BACKBUFFER |					// Can create backbuffer surfaces
//		DDSCAPS_COMPLEX |						// Can create complex surfaces
		DDSCAPS_FLIP |							// Can flip between surfaces
//		DDSCAPS_VIDEOPORT |
		DDSCAPS_FRONTBUFFER |					// Can create front-buffer surfaces
		DDSCAPS_OVERLAY |						// Can create overlay surfaces
		DDSCAPS_PALETTE |						// Has one palette ???
		DDSCAPS_PRIMARYSURFACE |				// Has a primary surface
//		DDSCAPS_PRIMARYSURFACELEFT | 			// Has a left-eye primary surface
//		DDSCAPS_TEXTURE |						// Supports texture surrfaces
        DDSCAPS_SYSTEMMEMORY |					// Surfaces are in system memory
		DDSCAPS_VIDEOMEMORY |					// Surfaces are in video memory
//		DDSCAPS_ZBUFFER |						// Can create (pseudo) Z buffer
//		DDSCAPS_EXECUTEBUFFER |					// Can create execute buffer
//		DDSCAPS_3DDEVICE |						// Surfaces can be 3d targets
//		DDSCAPS_WRITEONLY |						// Can create write-only surfaces
//		DDSCAPS_ALLOCONLOAD |					// Can create alloconload surfaces
//		DDSCAPS_MIPMAP |						// Can create mipmap
		0;

    lpddhi->ddCaps.dwNumFourCCCodes = 0;

	lpddhi->ddCaps.dwPalCaps;			// palette capabilities
		DDPCAPS_PRIMARYSURFACE |		// Palette is attached to primary surface
		0;

    // DirectDraw Blttting caps refer to hardware blitting support only.

  lpddhi->ddCaps.dwBltCaps =                        // blitting capabilities
        DDBLTCAPS_READSYSMEM  |
        DDBLTCAPS_WRITESYSMEM |
        DDBLTCAPS_COPYFOURCC  |
        0;

	lpddhi->ddCaps.dwCKeyCaps =	0;
    lpddhi->ddCaps.dwAlphaCaps = 0;

    // Overlay caps.

  lpddhi->ddCaps.dwOverlayCaps=               // overlay capabilities
        DDOVERLAYCAPS_FLIP |                    // Overlay may be flipped.
        DDOVERLAYCAPS_FOURCC |                  // YUV overlays supported.
        DDOVERLAYCAPS_CKEYSRC |		            // Supports overlaying using the color key for the source with this overlay surface for RGB colors.
        DDOVERLAYCAPS_CKEYDEST |		        // Supports overlaying with color keying of the replaceable bits of the destination surface being overlaid for RGB colors.
        0;
  lpddhi->ddCaps.dwMaxVisibleOverlays = 1;
  lpddhi->ddCaps.dwMinOverlayStretch=1000;
  lpddhi->ddCaps.dwMaxOverlayStretch=9999;

  lpddhi->ddCaps.dwMiscCaps =                 // more driver specific capabilities
        DDMISCCAPS_READSCANLINE |               // The driver allows the current scanline number to be read
        DDMISCCAPS_READVBLANKSTATUS |           // The driver allows the current vertical blank status to be read
        DDMISCCAPS_FLIPVSYNCWITHVBI |           // The driver is able to synchronize flips with the vertical blanking period
        0;

	SETROPBIT(lpddhi->ddCaps.dwRops,SRCCOPY);	// Set bits for ROPS supported
	SETROPBIT(lpddhi->ddCaps.dwRops,PATCOPY);
	SETROPBIT(lpddhi->ddCaps.dwRops,BLACKNESS);
	SETROPBIT(lpddhi->ddCaps.dwRops,WHITENESS);

}


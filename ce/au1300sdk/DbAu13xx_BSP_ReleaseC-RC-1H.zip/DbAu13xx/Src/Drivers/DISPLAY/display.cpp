/*****************************************************************************
Copyright 2003-2007 Raza Microelectronics, Inc.(RMI). All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY Raza Microelectronics, Inc. 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/


#include "precomp.h"
#include <syspal.h>    // for 8Bpp we use the natural palette
#include <gxinfo.h>
#include "dispperf.h"
#include "bceddk.h"
#include "lcd.h"

#ifdef PLATFORM_DB1200
 #define FOCUS_FS453
#endif

#ifdef PLATFORM_DB13XX
// #define FOCUS_FS471
#endif


#if defined(FOCUS_FS453) || defined(FOCUS_FS471)
#include <bceddk.h>
#include ".\focus\os.h"
#include ".\focus\focus.h"
#include ".\focus\sio.h"
#include ".\focus\sioll.h"
#include ".\focus\focus.c"
#include ".\focus\gpio.c"
#include ".\focus\sioll_au1xxx.c"
#include ".\focus\sio.c"
#endif


unsigned long ReverseULong(unsigned long c);
void RotateCursorMask(unsigned long src[32], unsigned long dest[32], int iRotate);

/********************************************************************
      Au1200 Available Panels via S7(Db1200) and S11(Pb1200)
********************************************************************/

// RGB pixel layout used by LCD controller
BitMask RGB655 = { 0xFC00, 0x03E0, 0x001F };
BitMask RGB565 = { 0xF800, 0x07E0, 0x001F };
BitMask RGB556 = { 0xF800, 0x07C0, 0x003F };
BitMask RGB444 = { 0x0F00, 0x00F0, 0x000F };
BitMask RGB888 = { 0x00FF0000, 0x0000FF00, 0x000000FF };


AU1200_LCD_MODE panels[] =
{
    { /* Index 0: Samsung 800x480 V:60Hz */
        TEXT("Samsung 800x480"),
        800, 480,
        /* mode_screen      */ LCD_SCREEN_SX_N(800) | LCD_SCREEN_SY_N(480) | LCD_SCREEN_SWP, // | LCD_SCREEN_SWD,
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(5) | LCD_HORZTIMING_HND1_N(16) | LCD_HORZTIMING_HND2_N(8),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(4) | LCD_VERTTIMING_VND1_N(8) | LCD_VERTTIMING_VND2_N(5),
        /* mode_clkcontrol  */ LCD_CLKCONTROL_PCD_N(1) | LCD_CLKCONTROL_IV | LCD_CLKCONTROL_IH,  // /2 = 24Mhz
        /* mode_pwmdiv      */ 0x00000000,
        /* mode_pwmhi       */ 0x00000000,
        /* mode_outmask     */ 0x00FFFFFF,
        /* mode_fifoctrl    */ 0x2f2f2f2f,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 96/12,
		/* mode_bitmask		*/ &RGB565,
		/* init             */ Au12::inverted_vdd_init,
		/* deinit           */ Au12::inverted_vdd_deinit,
    },

    { /* Index 1: VGA 640x480 H:30.3kHz V:58Hz */
        TEXT("VGA_640x480"),
        640, 480,
        /* mode_screen      */ LCD_SCREEN_SX_N(640) | LCD_SCREEN_SY_N(480) | LCD_SCREEN_SWP,
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(90) | LCD_HORZTIMING_HND1_N(45) | LCD_HORZTIMING_HND2_N(16),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(2) | LCD_VERTTIMING_VND1_N(10) | LCD_VERTTIMING_VND2_N(30),
        /* mode_clkcontrol  */ LCD_CLKCONTROL_PCD_N(1) | LCD_CLKCONTROL_IC, /* /4=24MHz */
        /* mode_pwmdiv      */ 0x00000000,
        /* mode_pwmhi       */ 0x00000000,
        /* mode_outmask     */ 0x00FFFFFF,
        /* mode_fifoctrl    */ 0x2f2f2f2f,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 96/12, /* 96MHz AUXPLL */
		/* mode_bitmask		*/ &RGB565,
		/* init             */ NULL,
		/* deinit           */ NULL,
    },

    { /* Index 2: SVGA 800x600 H:46.1kHz V:69Hz */
        TEXT("SVGA_800x600"),
        800, 600,
        /* mode_screen      */ LCD_SCREEN_SX_N(800) | LCD_SCREEN_SY_N(600) | LCD_SCREEN_SWP,
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(120) | LCD_HORZTIMING_HND1_N(64) | LCD_HORZTIMING_HND2_N(56),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(6) | LCD_VERTTIMING_VND1_N(37) | LCD_VERTTIMING_VND2_N(23),
        /* mode_clkcontrol  */ LCD_CLKCONTROL_PCD_N(0) | LCD_CLKCONTROL_IC, /* /2=48MHz */
        /* mode_pwmdiv      */ 0x00000000,
        /* mode_pwmhi       */ 0x00000000,
        /* mode_outmask     */ 0x00FFFFFF,
        /* mode_fifoctrl    */ 0x2f2f2f2f,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 96/12, /* 96MHz AUXPLL */
		/* mode_bitmask		*/ &RGB565,
		/* init             */ NULL,
		/* deinit           */ NULL,
    },


    { /* Index 3: XVGA 1024x768 H:56.2kHz V:70Hz */
        TEXT("XVGA_1024x768"),
        1024, 768,
        /* mode_screen      */ LCD_SCREEN_SX_N(1024) | LCD_SCREEN_SY_N(768) | LCD_SCREEN_SWP,
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(88) | LCD_HORZTIMING_HND1_N(136) | LCD_HORZTIMING_HND2_N(32),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(2) | LCD_VERTTIMING_VND1_N(6) | LCD_VERTTIMING_VND2_N(30),
        /* mode_clkcontrol  */ LCD_CLKCONTROL_CDD | LCD_CLKCONTROL_IC, /* use LCD clock */
        /* mode_pwmdiv      */ 0x00000000,
        /* mode_pwmhi       */ 0x00000000,
        /* mode_outmask     */ 0x00FFFFFF,
        /* mode_fifoctrl    */ 0x2f2f2f2f,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 72/12, /* 72MHz AUXPLL */
		/* mode_bitmask		*/ &RGB565,
		/* init             */ NULL,
		/* deinit           */ NULL,
    },

    { /* Index 4: XVGA 1280x1024 H:68.5kHz V:65Hz */
        TEXT("XVGA_1280x1024"),
        1280, 1024,
        /* mode_screen      */ LCD_SCREEN_SX_N(1280) | LCD_SCREEN_SY_N(1024) | LCD_SCREEN_SWP,
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(200) | LCD_HORZTIMING_HND1_N(218) | LCD_HORZTIMING_HND2_N(52),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(3) | LCD_VERTTIMING_VND1_N(1) | LCD_VERTTIMING_VND2_N(25),
        /* mode_clkcontrol  */ LCD_CLKCONTROL_CDD | LCD_CLKCONTROL_IC, /* use LCD clock */
        /* mode_pwmdiv      */ 0x00000000,
        /* mode_pwmhi       */ 0x00000000,
        /* mode_outmask     */ 0x00FFFFFF,
        /* mode_fifoctrl    */ 0x2f2f2f2f,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 120/12, /* 120MHz AUXPLL */
		/* mode_bitmask		*/ &RGB565,
		/* init             */ NULL,
		/* deinit           */ NULL,
    },

    { /* Index 5: Samsung 1024x768 TFT */
        TEXT("Samsung_1024x768_TFT"),
        1024, 768,
        /* mode_screen      */ LCD_SCREEN_SX_N(1024) | LCD_SCREEN_SY_N(768) | LCD_SCREEN_SWP,
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(120) | LCD_HORZTIMING_HND1_N(100) | LCD_HORZTIMING_HND2_N(100),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(24) | LCD_VERTTIMING_VND1_N(10) | LCD_VERTTIMING_VND2_N(10),
        /* mode_clkcontrol  */ 0x00000000,  /* 96/2 == 48Mhz */
        /* mode_pwmdiv      */ 0x8000063f,
        /* mode_pwmhi       */ 0x0000FFFF,
        /* mode_outmask     */ 0x00fcfcfc,
        /* mode_fifoctrl    */ 0x2f2f2f2f,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 96/12, /* 96MHz AUXPLL */
		/* mode_bitmask		*/ &RGB565,
		/* init             */ Au12::default_panel_init,
		/* deinit           */ Au12::default_panel_deinit,
    },

    { /* Index 6: Toshiba 640x480 TFT */
        TEXT("Toshiba_640x480_TFT"),
        640, 480,
        /* mode_screen      */ LCD_SCREEN_SX_N(640) | LCD_SCREEN_SY_N(480),
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(96) | LCD_HORZTIMING_HND1_N(13) | LCD_HORZTIMING_HND2_N(51),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(2) | LCD_VERTTIMING_VND1_N(11) | LCD_VERTTIMING_VND2_N(32) ,
        /* mode_clkcontrol  */ 0x00000000, /* /2=48Mhz */
        /* mode_pwmdiv      */ 0x8000063f,
        /* mode_pwmhi       */ 0x03400000,
        /* mode_outmask     */ 0x00fcfcfc,
        /* mode_fifoctrl    */ 0x2f2f2f2f,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 96/12, /* 96MHz AUXPLL */
		/* mode_bitmask		*/ &RGB565,
		/* init             */ Au12::default_panel_init,
		/* deinit           */ Au12::default_panel_deinit,
    },

    { /* Index 7: Sharp 320x240 TFT */
        TEXT("Sharp_320x240_TFT"),
        320, 240,
        /* mode_screen      */ LCD_SCREEN_SX_N(320) | LCD_SCREEN_SY_N(240),
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(60) | LCD_HORZTIMING_HND1_N(13) | LCD_HORZTIMING_HND2_N(2),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(2) | LCD_VERTTIMING_VND1_N(2) | LCD_VERTTIMING_VND2_N(5) ,
        /* mode_clkcontrol  */ LCD_CLKCONTROL_PCD_N(7), /* /16=2Mhz ??? */
        /* mode_pwmdiv      */ 0x8000063f,
        /* mode_pwmhi       */ 0x03400000,
        /* mode_outmask     */ 0x00fcfcfc,
        /* mode_fifoctrl    */ 0x2f2f2f2f,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 96/12, /* 96MHz AUXPLL */
		/* mode_bitmask		*/ &RGB565,
		/* init             */ Au12::default_panel_init,
		/* deinit           */ Au12::default_panel_deinit,
    },

    { /* Index 8: VGA 640x480 H:43.2kHz V:85Hz */
        TEXT("VGA_640x480"),
        640, 480,
        /* mode_screen      */ LCD_SCREEN_SX_N(640) | LCD_SCREEN_SY_N(480) | LCD_SCREEN_SWP,
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(64) | LCD_HORZTIMING_HND1_N(96) | LCD_HORZTIMING_HND2_N(32),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(4) | LCD_VERTTIMING_VND1_N(3) | LCD_VERTTIMING_VND2_N(21),
        /* mode_clkcontrol  */ LCD_CLKCONTROL_PCD_N(0) | LCD_CLKCONTROL_IC, /* /2=36MHz */
        /* mode_pwmdiv      */ 0x00000000,
        /* mode_pwmhi       */ 0x00000000,
        /* mode_outmask     */ 0x00FFFFFF,
        /* mode_fifoctrl    */ 0x2f2f2f2f,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 72/12, /* 72MHz AUXPLL */
		/* mode_bitmask		*/ &RGB565,
		/* init             */ NULL,
		/* deinit           */ NULL,
    },

    { /* Index 9: 1440x900 H:52kHz V:57Hz  */
        TEXT("WXVG+_1440x900"),
        1440, 900,
        /* mode_screen      */ LCD_SCREEN_SX_N(1440) | LCD_SCREEN_SY_N(900) | LCD_SCREEN_SWP,
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(100) | LCD_HORZTIMING_HND1_N(30) | LCD_HORZTIMING_HND2_N(30),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(3) | LCD_VERTTIMING_VND1_N(1) | LCD_VERTTIMING_VND2_N(20),
        /* mode_clkcontrol  */ LCD_CLKCONTROL_CDD | LCD_CLKCONTROL_IC, /* use LCD clock */
        /* mode_pwmdiv      */ 0x00000000,
        /* mode_pwmhi       */ 0x00000000,
        /* mode_outmask     */ 0x00FFFFFF,
        /* mode_fifoctrl    */ 0x38383838,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 84/12, /* 84MHz AUXPLL */
		/* mode_bitmask		*/ &RGB565,
		/* init             */ NULL,
		/* deinit           */ NULL,
    },

#ifdef FOCUS_FS453
    { /* Index 10: TV 640x480 */
        TEXT("FS453_640x480 (Composite/S-Video)"),
        640, 480,
        /* mode_screen      */ LCD_SCREEN_SX_N(640) | LCD_SCREEN_SY_N(480),
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(143) | LCD_HORZTIMING_HND1_N(143) | LCD_HORZTIMING_HND2_N(10),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(1) | LCD_VERTTIMING_VND1_N(59) | LCD_VERTTIMING_VND2_N(5),
        /* mode_clkcontrol  */ 0x00480000 | (1<<17) | (1<<18), /* External Clock, 1:1 clock ratio */
        /* mode_pwmdiv      */ 0x00000000,
        /* mode_pwmhi       */ 0x00000000,
        /* mode_outmask     */ 0x00FFFFFF,
        /* mode_fifoctrl    */ 0x2f2f2f2f,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 8, /* 96MHz AUXPLL */
		/* mode_bitmask		*/ &RGB565,
		/* init             */ NULL,
		/* deinit           */ NULL,
    },
#endif
#ifdef FOCUS_FS471
    { /* Index 10: TV 640x480  HTotal=880, VTotal=540 PCLK=28,483,516Hz */
        TEXT("FS453_640x480 (Composite/S-Video)"),
        640, 480,
        /* mode_screen      */ LCD_SCREEN_SX_N(640) | LCD_SCREEN_SY_N(480),
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(143) | LCD_HORZTIMING_HND1_N(143) | LCD_HORZTIMING_HND2_N(10),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(1) | LCD_VERTTIMING_VND1_N(59) | LCD_VERTTIMING_VND2_N(5),
        /* mode_clkcontrol  */ 0x00480000 | (1<<17) | (1<<18), /* External Clock, 1:1 clock ratio */
        /* mode_pwmdiv      */ 0x00000000,
        /* mode_pwmhi       */ 0x00000000,
        /* mode_outmask     */ 0x00FFFFFF,
        /* mode_fifoctrl    */ 0x2f2f2f2f,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 8, /* 96MHz AUXPLL */
		/* mode_bitmask		*/ &RGB565,
		/* init             */ Au12::focus47x_init,
		/* deinit           */ NULL,
    },
#endif


};

#define NUM_PANELS (sizeof(panels) / sizeof(AU1200_LCD_MODE))


AU1200_LCD_MODE edid_display =
{
        TEXT("EDID Based Display"),
        1440, 900,
        /* mode_screen      */ LCD_SCREEN_SX_N(1440) | LCD_SCREEN_SY_N(900) | LCD_SCREEN_SWP,
        /* mode_horztiming  */ LCD_HORZTIMING_HPW_N(152) | LCD_HORZTIMING_HND1_N(232) | LCD_HORZTIMING_HND2_N(80),
        /* mode_verttiming  */ LCD_VERTTIMING_VPW_N(6) | LCD_VERTTIMING_VND1_N(3) | LCD_VERTTIMING_VND2_N(25),
        /* mode_clkcontrol  */ LCD_CLKCONTROL_CDD | LCD_CLKCONTROL_IC, /* use LCD clock */
        /* mode_pwmdiv      */ 0x00000000,
        /* mode_pwmhi       */ 0x00000000,
        /* mode_outmask     */ 0x00FFFFFF,
        /* mode_fifoctrl    */ 0x38383838,
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll      */ 108/12, /* 84MHz AUXPLL */
        /* mode_bitmask     */ &RGB565,
        /* init             */ NULL,
        /* deinit           */ NULL,
};


INSTANTIATE_GPE_ZONES(0x3,"MGDI Driver","unused1","unused2")    // Start with errors and warnings

DDGPE * gGPE = (DDGPE *)NULL;

static ULONG 	  m_cursorposRestore;
static ULONG      m_cursorpatternRestore[64];


// This prototype avoids problems exporting from .lib
BOOL
APIENTRY
GPEEnableDriver(
    ULONG           engineVersion,
    ULONG           cj,
    DRVENABLEDATA * data,
    PENGCALLBACKS   engineCallbacks
    );

BOOL
APIENTRY
DrvEnableDriver(
    ULONG           engineVersion,
    ULONG           cj,
    DRVENABLEDATA * data,
    PENGCALLBACKS   engineCallbacks
    )
{
    return GPEEnableDriver(engineVersion, cj, data, engineCallbacks);
}
//
// Main entry point for a GPE-compliant driver
//

GPE *
GetGPE()
{
    if (!gGPE)
    {
        gGPE = new Au12();
    }

    return gGPE;
}

ULONG gBitMasks[] = { 0xf800,0x07e0,0x001f};


BOOL
ConvertStringToGuid(LPCTSTR GuidString, GUID *Guid )
{
  UINT Data4[8];
  int  Count;
  BOOL Ok = FALSE;
  LPWSTR GuidFormat = L"{%08lX-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X}";

  DEBUGCHK(Guid != NULL && GuidString != NULL);

    if (_stscanf(GuidString, GuidFormat, &Guid->Data1,
        &Guid->Data2, &Guid->Data3, &Data4[0], &Data4[1], &Data4[2], &Data4[3],
        &Data4[4], &Data4[5], &Data4[6], &Data4[7]) == 11) {
      		for (Count = 0; Count < (sizeof(Data4) / sizeof(Data4[0])); Count++) {
        		Guid->Data4[Count] = (UCHAR) Data4[Count];
      		}
    	}

    Ok = TRUE;

  return Ok;
}

BOOL AdvertisePowerInterface(HMODULE hInst)
{
    BOOL Ok = FALSE;
    GUID Class;
    TCHAR szTemp[MAX_PATH];

    Ok = ConvertStringToGuid(PMCLASS_DISPLAY, &Class);

	if(Ok)
		Ok = GetModuleFileName(hInst, szTemp, sizeof(szTemp) / sizeof(szTemp[0]));

    if(Ok)
    	Ok = AdvertiseInterface(&Class, szTemp, TRUE);

  return Ok;
}

VOID Au12::Shutdown(VOID)
{
	if (m_lcd->screen & LCD_SCREEN_SEN)
	{
	    m_lcd->intstatus = LCD_INT_SS;
	    while (!(m_lcd->intstatus & LCD_INT_SS))
	        WBSYNC();
	    m_lcd->screen &= ~LCD_SCREEN_SEN; /*disable the controller*/
	    do {
	        m_lcd->intstatus = m_lcd->intstatus;
	        WBSYNC();
	    } while (!(m_lcd->intstatus & LCD_INT_SD));
	}
}

VOID Au12::Suspend(void)
{
	int plane;
#ifdef PLATFORM_BACKLIGHT_POWERDOWN_CODE
	PLATFORM_BACKLIGHT_POWERDOWN_CODE;
#endif

#ifdef USE_HW_CURSOR
	// Save cursor pattern and position
	memcpy( (PVOID)m_cursorpatternRestore, (PVOID)m_lcd->cursorpattern, sizeof(m_cursorpatternRestore));
	m_cursorposRestore = m_lcd->hwc.cursorpos;
#endif

	m_lcdSaves.winenable = m_lcd->winenable;

	for (plane=0;plane<NUM_PLANES;plane++) {
		m_lcdSaves.window[plane].winctrl0 = m_lcd->window[plane].winctrl0;
		m_lcdSaves.window[plane].winctrl1 = m_lcd->window[plane].winctrl1;
		m_lcdSaves.window[plane].winctrl2 = m_lcd->window[plane].winctrl2;
		m_lcdSaves.window[plane].winbuf0  = m_lcd->window[plane].winbuf0;
	}
	m_lcdSaves.backcolor   = m_lcd->backcolor;
	m_lcdSaves.colorkey    = m_lcd->colorkey;
	m_lcdSaves.colorkeymsk = m_lcd->colorkeymsk;

	if (m_mode->deinit)
		m_mode->deinit(this);

	m_PowerState_On = FALSE;

	/* Disable the LCD controller at a vertical blanking period */
	m_lcd->winenable = 0;
	WBSYNC();
}

VOID Au12::Restore(void)
{
	int plane;
	if (m_mode->init)
		m_mode->init(this);

	// SCB This code has been added to ensure that the backlight power signals
	// do not assert before the lcd power signals. This no longer executes in the
	// backlight code backlight.c BKL_Init. The CPLD requires this.
#ifdef PLATFORM_BACKLIGHT_POWERUP_CODE
	PLATFORM_BACKLIGHT_POWERUP_CODE;
#endif

	SetRegisters();

	for (plane=0;plane<NUM_PLANES;plane++) {
			m_lcd->window[plane].winctrl0 = m_lcdSaves.window[plane].winctrl0;
			m_lcd->window[plane].winctrl1 = m_lcdSaves.window[plane].winctrl1;
			m_lcd->window[plane].winctrl2 = m_lcdSaves.window[plane].winctrl2;
			m_lcd->window[plane].winbuf0  = m_lcdSaves.window[plane].winbuf0;
	}

	m_lcd->backcolor   = m_lcdSaves.backcolor;
	m_lcd->colorkey    = m_lcdSaves.colorkey;
	m_lcd->colorkeymsk = m_lcdSaves.colorkeymsk;

	m_PowerState_On = TRUE;

#ifdef USE_HW_CURSOR
	// Restore cursor pattern and position
	m_lcd->hwc.cursorpos = m_cursorposRestore;
	memcpy((PVOID)m_lcd->cursorpattern, (PVOID)m_cursorpatternRestore, sizeof(m_cursorpatternRestore));
	m_lcd->hwc.cursorctrl = 1;
#endif

	m_lcd->winenable = m_lcdSaves.winenable;

}

VOID Au12::PowerHandler( CEDEVICE_POWER_STATE state )
{
	static

	RETAILMSG(1,(TEXT("LCD::PowerHandler( From:%d to %d)\r\n"),m_CurrentDx, state ));
	switch (state)
	{
		case D0:
		case D1:
		case D2:
			if (  m_CurrentDx == D3 || m_CurrentDx == D4 )
				Restore();
			break;
		case D3:
		case D4:
			if (  m_CurrentDx != D3 && m_CurrentDx != D4 ) {
				Suspend();
				Shutdown();
			}
			break;

		default:
			RETAILMSG(1,(TEXT("ERROR: %s %d\r\n"),__FILE__, __LINE__));
			break;
	}
}


VOID Au12::SetRegisters(VOID)
{
   	/*
	 * Setup LCD controller
	 */

	// Make sure panel is disabled
	if (m_mode->deinit)
		m_mode->deinit(this);

	/* AuxPLL on Monet is defined to be input to LCD only
	   Its okay to change here.
	   **Minimum freq is 144MHz, so divide down from there.
	   **YAMON sets the clksrc to divide by 2 already.
	 */
	m_sys->auxpll 		= m_mode->mode_auxpll*2;

	m_lcd->screen 		= m_mode->mode_screen;
	m_lcd->horztiming 	= m_mode->mode_horztiming;
	m_lcd->verttiming 	= m_mode->mode_verttiming;
	m_lcd->clkcontrol 	= m_mode->mode_clkcontrol;
	m_lcd->pwmdiv 		= m_mode->mode_pwmdiv;
	m_lcd->pwmhi 		= m_mode->mode_pwmhi;
	m_lcd->outmask 		= m_mode->mode_outmask;
	m_lcd->fifoctrl 	= m_mode->mode_fifoctrl;

	m_lcd->intenable = 0;
	m_lcd->intstatus = ~0;
	m_lcd->winenable = 0;
#ifdef USE_HW_CURSOR
	// Set Cursor colors and transparency
	// Color 0 = Black
	m_lcd->hwc.cursorcolor0 = LCD_CURSORCOLOR_HWCR_N(0) |
	                          LCD_CURSORCOLOR_HWCG_N(0) |
	                          LCD_CURSORCOLOR_HWCB_N(0) |
	                          LCD_CURSORCOLOR_HWCA_N(255);

	// Color 1 = White with 25% transparency, because it looks cool
	m_lcd->hwc.cursorcolor1 = LCD_CURSORCOLOR_HWCR_N(255) |
	                          LCD_CURSORCOLOR_HWCG_N(255) |
	                          LCD_CURSORCOLOR_HWCB_N(255) |
	                          LCD_CURSORCOLOR_HWCA_N(196);

	// Color 2 = Transparent
	m_lcd->hwc.cursorcolor2 = LCD_CURSORCOLOR_HWCR_N(255) |
	                          LCD_CURSORCOLOR_HWCG_N(255) |
	                          LCD_CURSORCOLOR_HWCB_N(255) |
	                          LCD_CURSORCOLOR_HWCA_N(0);

	// Color 3 = 50% Transparent ???
	// CE really would like this to be color invert
	m_lcd->hwc.cursorcolor3 = LCD_CURSORCOLOR_HWCR_N(0) |
	                          LCD_CURSORCOLOR_HWCG_N(0) |
	                          LCD_CURSORCOLOR_HWCB_N(0) |
	                          LCD_CURSORCOLOR_HWCA_N(128);
#else
	m_lcd->hwc.cursorctrl = 0;
#endif

	m_lcd->window[DESKTOP_PLANE].winctrl0 = LCD_WINCTRL0_A_N(255) | LCD_WINCTRL0_AEN;


	if ( m_ModeInfo.Bpp == 32 ){
		m_lcd->window[DESKTOP_PLANE].winctrl1 = LCD_WINCTRL1_FRM_32BPP |
									LCD_WINCTRL1_PO_01 |
									LCD_WINCTRL1_SZX_N(m_mode->Xres) |
									LCD_WINCTRL1_SZY_N(m_mode->Yres);
	}
	else if ( m_ModeInfo.Bpp == 16 ){
		m_lcd->window[DESKTOP_PLANE].winctrl1 = LCD_WINCTRL1_FRM_16BPP565 |
									LCD_WINCTRL1_PO_01 |
									LCD_WINCTRL1_SZX_N(m_mode->Xres) |
									LCD_WINCTRL1_SZY_N(m_mode->Yres);
	}
	else {
		m_lcd->window[DESKTOP_PLANE].winctrl1 = LCD_WINCTRL1_FRM_8BPP |
									LCD_WINCTRL1_PO_01 |
									LCD_WINCTRL1_SZX_N(m_mode->Xres) |
									LCD_WINCTRL1_SZY_N(m_mode->Yres);
	}

	/* Check "pipe" and "priority" settings from registry */
	if ( m_Windows[DESKTOP_PLANE].dwPipe )
		m_lcd->window[DESKTOP_PLANE].winctrl1 |= LCD_WINCTRL1_PIPE;

  	m_lcd->window[DESKTOP_PLANE].winctrl1 |= LCD_WINCTRL1_PRI_N(m_Windows[DESKTOP_PLANE].dwPriority);

	m_lcd->window[DESKTOP_PLANE].winctrl2 = LCD_WINCTRL2_DBM |
	                            LCD_WINCTRL2_BX_N((m_mode->Xres*m_ModeInfo.Bpp/8));
	m_lcd->window[DESKTOP_PLANE].winbuf0 =
	m_lcd->window[DESKTOP_PLANE].winbuf1 = m_pPyhsicalFrameBuffer;
	m_lcd->window[DESKTOP_PLANE].winbufctrl = 0;

    EnablePlane(DESKTOP_PLANE);

	m_lcd->intstatus = (LCD_INT_SA|LCD_INT_SS|LCD_INT_SD);
	m_lcd->intenable = (LCD_INT_SA|LCD_INT_SS);

	m_lcd->screen |= LCD_SCREEN_SEN;

	if (m_mode->init)
		m_mode->init(this);

// SCB This code has been added to ensure that the backlight power signals
// do not assert before the lcd power signals. This no longer executes in the
// backlight code backlight.c BKL_Init. The CPLD requires this.
#ifdef PLATFORM_BACKLIGHT_POWERUP_CODE
  OALStallExecution(50*1000);
  PLATFORM_BACKLIGHT_POWERUP_CODE
#endif

}

BOOL Au12::FreeFrameBuffer( )
{
	DWORD dwOutLen;
    if (!DeviceIoControl(hMemPool, MEM_FREE_BLOCK,
                         &fbMemPool, sizeof(MEM_IOCTL), NULL, 0, &dwOutLen, NULL)) {
        RETAILMSG(1,(L"Cannot free memory\r\n"));
	}

	return TRUE;
}

BOOL Au12::AllocFrameBuffer( DWORD dwSize )
{
	DWORD dwOutLen;
	memset(&fbMemPool, 0, sizeof(fbMemPool));

	/*
	 *	Use MEMPOOL driver to allocate LCD framebuffer memory
	 */
	fbMemPool.dwRegion  = REGION_LCD;
	fbMemPool.dwSize 	= dwSize;
	if (!DeviceIoControl(hMemPool, MEM_REQUEST_BLOCK,
	                     &fbMemPool, sizeof(MEM_IOCTL), NULL, 0, &dwOutLen, NULL)) {
	    RETAILMSG(1,(L"Cannot get memory: size:%d\r\n", dwSize ));
		return FALSE;
	}

	/* Update member vars that are referenced elsewhere */
	m_pPyhsicalFrameBuffer = (DWORD)fbMemPool.pPhysical;
	m_pvFlatFrameBuffer = (DWORD)fbMemPool.pVirtual;

	return TRUE;
}


Au12::Au12():
m_cbOffScreen(DEFAULT_OFFSCREEN_SIZE),
m_colorDepth(DEFAULT_BPP)
{
    ULONG      fbSize;
    ULONG      fbOffset;
    ULONG      offsetX;
    ULONG      offsetY;
	PHYSICAL_ADDRESS	PhysAddr;
	BCSR *bcsr = (BCSR*)BCSR_KSEG1_ADDR;
	int panel = 0, i;

    DEBUGMSG(GPE_ZONE_INIT,(TEXT("Au12::Au12\r\n")));

	/*
	 * Map in Au12xx LCD controller registers
	 */
	PhysAddr.LowPart = LCD_PHYS_ADDR;
	PhysAddr.HighPart = 0;

	m_lcd = (AU1200_LCD *)MmMapIoSpace(PhysAddr, sizeof(AU1200_LCD), FALSE);
	if (!m_lcd)
		RETAILMSG(1,(TEXT("Fail to Map Au1200 LCD registers!\r\n")));
    else if ((UINT)m_lcd != ((UINT)m_lcd & ~0x3))
		RETAILMSG(1,(TEXT("Mapped Au1200 LCD registers to an unaligned address!!! (0x%x)\r\n"),(UINT)m_lcd));

	for(i=1;i<NUM_PLANES;i++)
	{
	    m_lcd->window[i].winctrl0 = 0;
    	m_lcd->window[i].winctrl1 = 0;
	    m_lcd->window[i].winctrl2 = 0;
	    m_lcd->window[i].winbufctrl = 0;
	}

	InitFromRegistry();

	m_CurrentDx = D0;
	m_PowerState_On = TRUE;

#ifdef PLATFORM_LCD_PANEL_SELECT_CODE
	PLATFORM_LCD_PANEL_SELECT_CODE
#else
	panel = 0;
#endif

    m_VesaMode = 0;

    if (panel == ((BCSR_SWITCHES_ROTARY) >> 8)) {
        modeline ml;
        ml = m_EDID.Query();

        m_mode = &edid_display;
        m_mode->Xres = ml.hdisplay;
        m_mode->Yres = ml.vdisplay;
        m_mode->mode_screen         = LCD_SCREEN_SX_N(ml.hdisplay) | LCD_SCREEN_SY_N(ml.vdisplay) | LCD_SCREEN_SWP;
        m_mode->mode_horztiming     = LCD_HORZTIMING_HND2_N(ml.hsyncstart) |
                                      LCD_HORZTIMING_HPW_N(ml.hsyncend) |
                                      LCD_HORZTIMING_HND1_N(ml.htotal-(ml.hdisplay+ml.hsyncstart+ml.hsyncend));
        m_mode->mode_verttiming     = LCD_VERTTIMING_VND1_N(ml.vsyncstart) |
                                      LCD_VERTTIMING_VPW_N(ml.vsyncend) |
                                      LCD_VERTTIMING_VND2_N(ml.vtotal-(ml.vdisplay+ml.vsyncstart+ml.vsyncend));
        m_mode->mode_clkcontrol     = LCD_CLKCONTROL_CDD | LCD_CLKCONTROL_IC;
        m_mode->mode_pwmdiv         = 0;
        m_mode->mode_pwmhi          = 0;
        m_mode->mode_outmask        = 0x00FFFFFF;
        m_mode->mode_fifoctrl       = 0x38383838;
        m_mode->mode_auxpll         = (ml.dotclock/12)+1; // Round up -- TODO:Determine if this is greater than max dot clk
        m_mode->mode_bitmask        = &RGB565;
        m_mode->init                = NULL;
        m_mode->deinit              = NULL;


    }
    else {
		if (panel >= NUM_PANELS) {
			panel=0;
			RETAILMSG(1,(TEXT("Invalid Panel Selected! Defaulting to panel 0\r\n")));
		}


		m_mode = &panels[panel];
    }

	RETAILMSG(1,(TEXT("\r\n\r\nUsing panel %d %s BPP:%d\r\n\r\n"),
		panel, m_mode->description,m_colorDepth));

    m_nScreenWidth = m_mode->Xres;
    m_nScreenHeight = m_mode->Yres;
    m_cxPhysicalScreen = m_nScreenWidth;
    m_cyPhysicalScreen = m_nScreenHeight;
    m_cbScanLineLength = m_nScreenWidth*(m_colorDepth/8);

    m_iRotate = GetRotateModeFromReg();
    SetRotateParams();

    // set rest of ModeInfo values
    m_ModeInfo.modeId = 0;
    m_ModeInfo.width = m_nScreenWidth;
    m_ModeInfo.height = m_nScreenHeight;
    m_ModeInfo.Bpp = m_colorDepth;
    m_ModeInfo.frequency = 60;    // ?
    switch (m_colorDepth)
    {
        case    8:
			m_BytesPP = 1;
            m_ModeInfo.format = gpe8Bpp;
            break;

        case    16:
			m_BytesPP = 2;
            m_ModeInfo.format = gpe16Bpp;
            break;

        case    24:
			m_BytesPP = 4;
            m_ModeInfo.format = gpe24Bpp;
            break;

        case    32:
			m_BytesPP = 4;
            m_ModeInfo.format = gpe32Bpp;
            break;

        default:
			m_BytesPP = 0;
            DEBUGMSG(GPE_ZONE_ERROR,(TEXT("Invalid BPP value passed to driver - %d\r\n"), m_ModeInfo.Bpp));
            m_ModeInfo.format = gpeUndefined;
            break;
    }

    hMemPool = CreateFile(L"MEM1:", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (hMemPool == INVALID_HANDLE_VALUE) {
        RETAILMSG(1,(L"Cannot open MEM1: %d\r\n", GetLastError()));
        return;
    }

    m_pMode = &m_ModeInfo;

    // compute frame buffer displayable area offset
    offsetX = (m_cxPhysicalScreen - m_nScreenWidthSave) / 2;
    offsetY = (m_cyPhysicalScreen - m_nScreenHeightSave) / 2;
    fbOffset = (offsetY * m_cbScanLineLength) + offsetX;

	fbSize = (m_ModeInfo.width * m_ModeInfo.height * m_ModeInfo.Bpp) / 8;
	fbSize += m_cbOffScreen;

	/*
	 * See LCD Performance App note regarding ALIGNment
	 */
	fbSize = fbSize & ~(PAGE_SIZE-1);

	RETAILMSG(1, (TEXT("fbsize: %d, %08x\r\n"), fbSize, fbSize));

	AllocFrameBuffer( fbSize );

	RETAILMSG(1,(TEXT("AllocPhysMem(): p=%08X v=%08X\r\n"), m_pPyhsicalFrameBuffer, m_pvFlatFrameBuffer));
	if (m_pvFlatFrameBuffer == NULL)
	{
		RETAILMSG(1,(TEXT("\n\rERROR: Unable to AllocPhysMem()\n\r")));
		return;
	}
	PhysAddr.LowPart = m_pPyhsicalFrameBuffer;
	PhysAddr.HighPart = 0;
	m_pvFlatFrameBuffer = (DWORD)MmMapIoSpace(PhysAddr, fbSize, FALSE);
	m_VirtualFrameBuffer = m_pvFlatFrameBuffer;

    if ( NULL == m_VirtualFrameBuffer )
    {
        RETAILMSG (1, (L"ERROR: Unable to allocate frame buffer!!!\n"));
        return;
    }

    memset((void *)m_VirtualFrameBuffer, 0, fbSize);

    m_FrameBufferSize = fbSize;

    m_VirtualFrameBuffer += fbOffset;
    fbSize -= fbOffset;

	m_pVideoMemory = new SurfaceHeap(m_FrameBufferSize, (ADDRESS)m_pvFlatFrameBuffer, NULL, NULL);

    if(FAILED(AllocSurface(&m_pPrimarySurface, m_mode->Xres, m_mode->Yres, m_pMode->format, GPE_REQUIRE_VIDEO_MEMORY)))
    {
        RETAILMSG (1, (L"Couldn't allocate primary surface\n"));
        return;
    }
    m_pPrimarySurface->SetRotation(m_nScreenWidth, m_nScreenHeight, m_iRotate);

    m_CursorVisible = FALSE;
    m_CursorDisabled = TRUE;
    m_CursorForcedOff = FALSE;
    memset (&m_CursorRect, 0x0, sizeof(m_CursorRect));

	/* map in toy registers */
	PhysAddr.LowPart = SYS_PHYS_ADDR;
	PhysAddr.HighPart = 0;

	// sets the default blt functions to MS
    DefaultBltFunctions(&GPE::EmulatedBlt);

    // we can override any of the MS blt functions based on our Bpp
    SetBltFunctions(m_ModeInfo.Bpp);

    // Notify the system that we are a power-manageable device
    AdvertisePowerInterface(g_hmodDisplayDll);

#ifdef FOCUS_FS453
	if (!_tcscmp(m_mode->description, TEXT("FS453_640x480 (Composite/S-Video)")))
	{
		RETAILMSG(1, (TEXT("Initializing FS453 for %s\r\n"), m_mode->description));
		board_au1200fb_focus_init_cvsv();
	}
#endif



	/* Map in Au12xx TOY registers for Aux PLL Adjustments */
	m_sys = (AU1X00_SYS *)MmMapIoSpace(PhysAddr, sizeof(*m_sys), FALSE);
	if (!m_sys)
		RETAILMSG(1,(TEXT("Fail to Map TOY registers!\r\n")));


	/*
	 *	Initialize the interrupt
	 */
    if ((hInterruptEvent = CreateEvent(NULL, FALSE, FALSE, NULL)) == INVALID_HANDLE_VALUE)
    {
        DEBUGMSG(1, (TEXT("Au12: cannot create the interrupt event!\r\n")));
        hInterruptEvent = 0;
    }

    if ((dwSysIntr = InterruptConnect(Internal, 0, HWINTR_LCD, 0)) == SYSINTR_NOP)
    {
        RETAILMSG(1, (TEXT("Au12: cannot allocate a sysintr for LCD!\r\n")));
    }
    if (!InterruptInitialize(dwSysIntr, hInterruptEvent, NULL, 0))
    {
        DEBUGMSG(GPE_ZONE_ERROR, (TEXT("Au12: cannot init the LCD interrupt!\r\n")));
    }

	// Make sure there is no stray interrupt pending and enable the interrupt
	while (WaitForSingleObject(hInterruptEvent, 0) == WAIT_OBJECT_0)
	  InterruptDone(dwSysIntr);
}

BOOL Au12::InitFromRegistry(VOID) {
	DWORD 		dwIndex=0;
	TCHAR 		szNewKey[MAX_PATH]; // name of "region" subkey
	DWORD 		dwNewKeySize;       // size of name of "region" subkey
	DWORD		dwType, dwLen; 		// type and length of key
	HKEY		hKey, hActiveKey;

	// Open the Active key for the driver.
	if (ERROR_SUCCESS != RegOpenKeyEx(HKEY_LOCAL_MACHINE, DISPLAY_REGKEY,0, 0, &hActiveKey) )
		return FALSE;

	// ColorDepth
	dwType = REG_DWORD;
	dwLen = sizeof(m_colorDepth);
	RegQueryValueEx (hActiveKey, TEXT("Bpp"), NULL, &dwType, (PBYTE)&m_colorDepth, &dwLen);

	// Off Screen Framebuffer size
	dwType = REG_DWORD;
	dwLen = sizeof(m_cbOffScreen);
	RegQueryValueEx (hActiveKey, TEXT("OffScreenSize"), NULL, &dwType, (PBYTE)&m_cbOffScreen, &dwLen);

	// Read the key value.
	dwLen = sizeof(szNewKey) / sizeof(TCHAR);
	RegQueryValueEx (hActiveKey, TEXT("Key"), NULL, &dwType, (PBYTE)szNewKey, &dwLen);

	// Read the colorkey and mask
	DWORD colorKey;
	DWORD colorKeyMask;

	dwType = REG_DWORD;
	dwLen = sizeof(m_cbOffScreen);
	RegQueryValueEx (hActiveKey, TEXT("ColorKey"), NULL, &dwType, (PBYTE)&colorKey, &dwLen);
	RegQueryValueEx (hActiveKey, TEXT("ColorKeyMask"), NULL, &dwType, (PBYTE)&colorKeyMask, &dwLen);
	
	m_lcd->colorkey = colorKey;
	m_lcd->colorkeymsk = colorKeyMask;


	// Read the backcolor
	DWORD backColor;

	dwType = REG_DWORD;
	dwLen = sizeof(m_cbOffScreen);
	RegQueryValueEx (hActiveKey, TEXT("BackColor"), NULL, &dwType, (PBYTE)&backColor, &dwLen);

	m_lcd->backcolor = backColor;

	if ( ERROR_SUCCESS != RegOpenKeyEx(HKEY_LOCAL_MACHINE, DISPLAY_WINDOWS_REGKEY,0, 0, &hKey))
	{
		return FALSE;
	}

	dwNewKeySize = sizeof(szNewKey) / sizeof(TCHAR);
	while (
	    ERROR_SUCCESS == RegEnumKeyExW(
	        hKey,          //
	        dwIndex,       // index of the subkey to fetch
	        szNewKey,      // name of subkey (e.g., "Device0")
	        &dwNewKeySize, // size of name of subkey
	        NULL,          // lpReserved; set to NULL
	        NULL,          // lpClass; not required
	        NULL,          // lpcbClass; lpClass is NULL; hence, NULL
	        NULL           // lpftLastWriteTime; set to NULL
	)) {
		HKEY hSubKey;
		DWORD dwWin;
		LCD_WINDOW_CONFIG	*pWindow;

        dwIndex += 1;
        dwNewKeySize = (sizeof(szNewKey) / sizeof(TCHAR));

		RegOpenKeyExW(hKey, szNewKey,0, 0, &hSubKey);

		dwType = REG_DWORD;
		dwLen = sizeof(dwWin);
		RegQueryValueEx (hSubKey, TEXT("Index"), NULL,
						      &dwType, (LPBYTE)&(dwWin), &dwLen);

		pWindow = &m_Windows[dwWin];

		dwType = REG_SZ;
		dwLen = sizeof(pWindow->wcName);
		RegQueryValueEx (hSubKey, TEXT("FriendlyName"), NULL,
							  &dwType, (LPBYTE)&(pWindow->wcName), &dwLen);

		dwType = REG_DWORD;
		dwLen = sizeof(pWindow->dwPipe);
		RegQueryValueEx (hSubKey, TEXT("Pipe"), NULL,
						      &dwType, (LPBYTE)&(pWindow->dwPipe), &dwLen);

		dwType = REG_DWORD;
		dwLen = sizeof(pWindow->dwPriority);
		RegQueryValueEx (hSubKey, TEXT("Priority"), NULL,
							  &dwType, (LPBYTE)&(pWindow->dwPriority), &dwLen);

		RegCloseKey( hSubKey );

		RETAILMSG(1,(TEXT("Window(%d) %20s Config. Pipe:%d Priority:%d\r\n"),
			dwWin, pWindow->wcName, pWindow->dwPipe, pWindow->dwPriority ));

	}

	RegCloseKey( hActiveKey );
	RegCloseKey( hKey );


  return TRUE;
}
Au12::~Au12()
{
    if (m_VirtualFrameBuffer != NULL)
        UnmapViewOfFile((LPVOID)m_VirtualFrameBuffer);
    if (m_hVFBMapping != NULL)
        CloseHandle(m_hVFBMapping);
	FreeFrameBuffer();
}

int
Au12::GetBpp()
{
	return m_ModeInfo.Bpp;
}


SCODE    Au12::SetMode (INT modeId, HPALETTE *palette)
{
	UINT32	 i;
    DEBUGMSG(GPE_ZONE_INIT,(TEXT("Au12::SetMode\r\n")));

    if (modeId != 0)
    {
        DEBUGMSG(GPE_ZONE_ERROR,(TEXT("Au12::SetMode Want mode %d, only have mode 0\r\n"),modeId));
        return    E_INVALIDARG;
    }

    if (palette)
    {
        switch (m_colorDepth)
        {
            case    8:
                *palette = EngCreatePalette (PAL_INDEXED,
                                             PALETTE_SIZE,
                                             (ULONG*)_rgbIdentity,
                                             0,
                                             0,
                                             0);
                break;

            case    16:
                *palette = EngCreatePalette (PAL_BITFIELDS,
                                             0,
                                             NULL,
											((unsigned long *)(m_mode->mode_bitmask))[0],  // R
											((unsigned long *)(m_mode->mode_bitmask))[1],  // G
											((unsigned long *)(m_mode->mode_bitmask))[2]); // B
                break;
			case 24:
			case 32:
				*palette =	EngCreatePalette (PAL_BITFIELDS,
											  0,
												NULL,
												RGB888[0],  // R
												RGB888[1],  // G
												RGB888[2]); // B
				break;
        }
    }

	// initialize palette
	if (m_pMode->Bpp != 8)
	{
		for (i = 0; i < 256; i++)
		{
			_rgbIdentity[i].peRed = (BYTE)i;
			_rgbIdentity[i].peGreen = (BYTE)i;
			_rgbIdentity[i].peBlue = (BYTE)i;
		}
	}

	SetPalette(_rgbIdentity, 0, SIZE_RAM_ARRAY);

	SetRegisters();

	RETAILMSG(0, (TEXT("lcd_screen: %08X\r\n"), m_lcd->screen));
	RETAILMSG(0, (TEXT("lcd_intstatus: %08X\r\n"), m_lcd->intstatus));
	RETAILMSG(0, (TEXT("lcd_intenable: %08X\r\n"), m_lcd->intenable));
	RETAILMSG(0, (TEXT("lcd_horztiming: %08X\r\n"), m_lcd->horztiming));
	RETAILMSG(0, (TEXT("lcd_verttiming: %08X\r\n"), m_lcd->verttiming));
	RETAILMSG(0, (TEXT("lcd_clkcontrol: %08X\r\n"), m_lcd->clkcontrol));

    return S_OK;
}

SCODE    Au12::GetModeInfo(GPEMode *mode,    INT modeNumber)
{
    DEBUGMSG (GPE_ZONE_INIT, (TEXT("Au12::GetModeInfo\r\n")));

    if (modeNumber != 0)
    {
        return E_INVALIDARG;
    }

    *mode = m_ModeInfo;

    return S_OK;
}

int        Au12::NumModes()
{
    DEBUGMSG (GPE_ZONE_INIT, (TEXT("Au12::NumModes\r\n")));
    return    1;
}

void    Au12::CursorOn (void)
{
#ifndef USE_HW_CURSOR
    UCHAR    *ptrScreen = (UCHAR*)m_pPrimarySurface->Buffer();
    UCHAR    *ptrLine;
    UCHAR    *cbsLine;
    int        x, y;

    if (!m_CursorForcedOff && !m_CursorDisabled && !m_CursorVisible)
    {
        RECTL cursorRectSave = m_CursorRect;
        int   iRotate;
        RotateRectl(&m_CursorRect);
        for (y = m_CursorRect.top; y < m_CursorRect.bottom; y++)
        {
            if (y < 0)
            {
                continue;
            }
            if (y >= m_nScreenHeightSave)
            {
                break;
            }

            ptrLine = &ptrScreen[y * m_pPrimarySurface->Stride()];
            cbsLine = &m_CursorBackingStore[(y - m_CursorRect.top) * (m_CursorSize.x * (m_colorDepth >> 3))];

            for (x = m_CursorRect.left; x < m_CursorRect.right; x++)
            {
                if (x < 0)
                {
                    continue;
                }
                if (x >= m_nScreenWidthSave)
                {
                    break;
                }

                // x' = x - m_CursorRect.left; y' = y - m_CursorRect.top;
                // Width = m_CursorSize.x;   Height = m_CursorSize.y;
                switch (m_iRotate)
                {
                    case DMDO_0:
                        iRotate = (y - m_CursorRect.top)*m_CursorSize.x + x - m_CursorRect.left;
                        break;
                    case DMDO_90:
                        iRotate = (x - m_CursorRect.left)*m_CursorSize.x + m_CursorSize.y - 1 - (y - m_CursorRect.top);
                        break;
                    case DMDO_180:
                        iRotate = (m_CursorSize.y - 1 - (y - m_CursorRect.top))*m_CursorSize.x + m_CursorSize.x - 1 - (x - m_CursorRect.left);
                        break;
                    case DMDO_270:
                        iRotate = (m_CursorSize.x -1 - (x - m_CursorRect.left))*m_CursorSize.x + y - m_CursorRect.top;
                        break;
                    default:
                        iRotate = (y - m_CursorRect.top)*m_CursorSize.x + x - m_CursorRect.left;
                        break;
                }
                cbsLine[(x - m_CursorRect.left) * (m_colorDepth >> 3)] = ptrLine[x * (m_colorDepth >> 3)];
                ptrLine[x * (m_colorDepth >> 3)] &= m_CursorAndShape[iRotate];
                ptrLine[x * (m_colorDepth >> 3)] ^= m_CursorXorShape[iRotate];
                if (m_colorDepth > 8)
                {
                    cbsLine[(x - m_CursorRect.left) * (m_colorDepth >> 3) + 1] = ptrLine[x * (m_colorDepth >> 3) + 1];
                    ptrLine[x * (m_colorDepth >> 3) + 1] &= m_CursorAndShape[iRotate];
                    ptrLine[x * (m_colorDepth >> 3) + 1] ^= m_CursorXorShape[iRotate];
                    if (m_colorDepth > 16)
                    {
                        cbsLine[(x - m_CursorRect.left) * (m_colorDepth >> 3) + 2] = ptrLine[x * (m_colorDepth >> 3) + 2];
                        ptrLine[x * (m_colorDepth >> 3) + 2] &= m_CursorAndShape[iRotate];
                        ptrLine[x * (m_colorDepth >> 3) + 2] ^= m_CursorXorShape[iRotate];
                    }
                }
            }
        }
        m_CursorRect = cursorRectSave;
        m_CursorVisible = TRUE;
    }
#else
	m_lcd->hwc.cursorctrl = 1;
#endif
}

void    Au12::CursorOff (void)
{
#ifndef USE_HW_CURSOR
	UCHAR	*ptrScreen = (UCHAR*)m_pPrimarySurface->Buffer();
	UCHAR	*ptrLine;
	UCHAR	*cbsLine;
	int		x, y;

	if (!m_CursorForcedOff && !m_CursorDisabled && m_CursorVisible)
	{
		RECTL rSave = m_CursorRect;
		RotateRectl(&m_CursorRect);
		for (y = m_CursorRect.top; y < m_CursorRect.bottom; y++)
		{
			// clip to displayable screen area (top/bottom)
			if (y < 0)
			{
				continue;
			}
			if (y >= m_nScreenHeightSave)
			{
				break;
			}

			ptrLine = &ptrScreen[y * m_pPrimarySurface->Stride()];
			cbsLine = &m_CursorBackingStore[(y - m_CursorRect.top) * (m_CursorSize.x * (m_colorDepth >> 3))];

			for (x = m_CursorRect.left; x < m_CursorRect.right; x++)
			{
				// clip to displayable screen area (left/right)
				if (x < 0)
				{
					continue;
				}
				if (x >= m_nScreenWidthSave)
				{
					break;
				}

				ptrLine[x * (m_colorDepth >> 3)] = cbsLine[(x - m_CursorRect.left) * (m_colorDepth >> 3)];
				if (m_colorDepth > 8)
				{
					ptrLine[x * (m_colorDepth >> 3) + 1] = cbsLine[(x - m_CursorRect.left) * (m_colorDepth >> 3) + 1];
					if (m_colorDepth > 16)
					{
						ptrLine[x * (m_colorDepth >> 3) + 2] = cbsLine[(x - m_CursorRect.left) * (m_colorDepth >> 3) + 2];
					}
				}
			}
		}
		m_CursorRect = rSave;
		m_CursorVisible = FALSE;
	}
#else
	m_lcd->hwc.cursorctrl = 0;
#endif
}

SCODE    Au12::SetPointerShape(GPESurf *pMask, GPESurf *pColorSurf, INT xHot, INT yHot, INT cX, INT cY)
{
	PUCHAR pANDMask, pXORMask;

	DEBUGMSG(GPE_ZONE_CURSOR,(TEXT("Au12::SetPointerShape(0x%X, 0x%X, %d, %d, %d, %d)\r\n"),pMask, pColorSurf, xHot, yHot, cX, cY));

    // store size and hotspot for new cursor
    m_CursorSize.x = cX;
    m_CursorSize.y = cY;
    m_CursorHotspot.x = xHot;
    m_CursorHotspot.y = yHot;

#ifdef USE_HW_CURSOR
	int maskStride;
	int totalBytes = cY * sizeof(unsigned long);
	int byte;

	if (cX!=32 || cY!=32) {
		DEBUGMSG(1,(TEXT("Au1200 only supports 32x32 cursor!!! (%dx%d)\r\n"),cX,cY));
		return S_OK;
	}

	maskStride = pMask->Stride();

	// Turn off cursor before we change the shape...
	HWCursorOff();

	// Save the cursor masks
	// get pointers to And and Xor masks
	pANDMask = (UCHAR*)pMask->Buffer();
	pXORMask = (UCHAR*)pMask->Buffer() + (cY * maskStride);

	// negative stride, so go to start of data...
	pANDMask += (31 * maskStride);
	pXORMask += (31 * maskStride);


	// re-order bytes.  The masks come with bytes in reverse order.
	for (byte = 0; byte < totalBytes; byte++)
    {
		m_CursorAndShape[byte] =  pANDMask[totalBytes - byte - 1];
		m_CursorXorShape[byte] =  pXORMask[totalBytes - byte - 1];
	}

    // Turn Cursor back on
	HWCursorOn();

#else
	UCHAR	*andPtr;		// input pointer
	UCHAR	*xorPtr;		// input pointer
	UCHAR	*andLine;		// output pointer
	UCHAR	*xorLine;		// output pointer
	char	bAnd;
	char	bXor;
	int		col;
	int		row;
	int		i;
	int		bitMask;

	// turn current cursor off
	CursorOff();

	// release memory associated with old cursor
	if (!pMask)							// do we have a new cursor shape
	{
		m_CursorDisabled = TRUE;		// no, so tag as disabled
	}
	else
	{
		m_CursorDisabled = FALSE;		// yes, so tag as not disabled

		andPtr = (UCHAR*)pMask->Buffer();
		xorPtr = (UCHAR*)pMask->Buffer() + (cY * pMask->Stride());

		// store OR and AND mask for new cursor
		for (row = 0; row < cY; row++)
		{
			andLine = &m_CursorAndShape[cX * row];
			xorLine = &m_CursorXorShape[cX * row];

			for (col = 0; col < cX / 8; col++)
			{
				bAnd = andPtr[row * pMask->Stride() + col];
				bXor = xorPtr[row * pMask->Stride() + col];

				for (bitMask = 0x0080, i = 0; i < 8; bitMask >>= 1, i++)
				{
					andLine[(col * 8) + i] = bAnd & bitMask ? 0xFF : 0x00;
					xorLine[(col * 8) + i] = bXor & bitMask ? 0xFF : 0x00;
				}
			}
		}
	}
#endif
    return    S_OK;
}

SCODE    Au12::MovePointer(INT xPosition, INT yPosition)
{
    DEBUGMSG(GPE_ZONE_CURSOR, (TEXT("Au12::MovePointer(%d, %d)\r\n"), xPosition, yPosition));

#ifdef USE_HW_CURSOR
	int xOffset=0, yOffset=0;
int iSwap;

	switch (m_iRotate)
	{
		case DMDO_90:
			// add hotspot once we actually rotate the cursor...
			iSwap = xPosition;
			xPosition = yPosition;
			yPosition = m_nScreenHeightSave - iSwap;
			break;

		case DMDO_180:
			// add hotspot once we actually rotate the cursor...
			xPosition = m_nScreenWidthSave - xPosition;
			yPosition = m_nScreenHeightSave - yPosition;
			break;

		case DMDO_270:
			// add hotspot once we actually rotate the cursor...
			iSwap = xPosition;
			xPosition = m_nScreenWidthSave - yPosition;
			yPosition = iSwap;
			break;
	}

	// Adjust the X and Y so that we draw the Hot part of the cursor at the Hot Spot
	xPosition -= m_CurCursorHotspot.x;
	yPosition -= m_CurCursorHotspot.y;

    if (xPosition < 0)
    {
		// Adjust the offset to draw only the on screen part of the cursor
		xOffset = -xPosition;
		xPosition = 0;

		// We always want to stop going off screen at the hotspot
		if (xOffset > m_CurCursorHotspot.x)
			xOffset = m_CurCursorHotspot.x;
    }

    if (yPosition < 0)
    {
		// Adjust the offset to draw only the on screen part of the cursor
		yOffset = -yPosition;
		yPosition = 0;

		// We always want to stop going off screen at the hotspot
		if (yOffset > m_CurCursorHotspot.y)
			yOffset = m_CurCursorHotspot.y;
    }

	// Set Position and Offset
	m_lcd->hwc.cursorpos = LCD_CURSORPOS_HWCXOFF_N(xOffset) |
	                       LCD_CURSORPOS_HWCXPOS_N(xPosition) |
	                       LCD_CURSORPOS_HWCYOFF_N(yOffset) |
	                       LCD_CURSORPOS_HWCYPOS_N(yPosition);
#else
    CursorOff();

    if (xPosition != -1 || yPosition != -1)
    {
        // compute new cursor rect
        m_CursorRect.left = xPosition - m_CursorHotspot.x;
        m_CursorRect.right = m_CursorRect.left + m_CursorSize.x;
        m_CursorRect.top = yPosition - m_CursorHotspot.y;
        m_CursorRect.bottom = m_CursorRect.top + m_CursorSize.y;

        CursorOn();
    }
#endif
    return    S_OK;
}

#ifdef USE_HW_CURSOR
void Au12::HWCursorOn()
{
	// Set Cursor Pattern
	// Based on AND and XOR masks as follows:
	//
	// AND XOR Color
	// 0   0   0 - Black
	// 0   1   1 - White
	// 1   0   2 - Transparent
	// 1   1   3 - 50% transparant, really this should be inverse...
	//
	// We will use the dibit formed as [AND:XOR] to select the color index 0-3 for each cursor pixel.

	int row, col;
	ULONG  cursorData;
	volatile ULONG *pCursorData;
	UCHAR bitMask;
	int bit, j;
	unsigned char			TmpCursorAndShape[32 * 32];
    unsigned char			TmpCursorXorShape[32 * 32];
	int outputStride = 2; // there are 2 unsigned longs per row
	PUCHAR pANDMask, pXORMask;



	RotateCursorMask((unsigned long *)m_CursorXorShape, (unsigned long *)TmpCursorXorShape, m_iRotate);
	RotateCursorMask((unsigned long *)m_CursorAndShape, (unsigned long *)TmpCursorAndShape, m_iRotate);

	// set pointer to our re-orders masks
	pANDMask = TmpCursorAndShape;
	pXORMask = TmpCursorXorShape;


	// we have 32 unsigned longs in each mask.  Combine the bits from each mask to form an [AND:XOR] dibit for this pixel
	for (row = 0; row < 32; row++)
	{
		//
		pCursorData = &m_lcd->cursorpattern[0] + outputStride * row + 1;
		for (col = 0; col < 2; col++)
		{
			cursorData = 0;
			for (j = 0; j < 2; j++)
			{
				// check each bit of the column
				for (bit = 0, bitMask = 0x1; bit < 8; bit++, bitMask <<=1)
				{
					// Form [AND:XOR] dibit for this pixel
					// make room for the next dibit
					cursorData <<= 2;

					if (*(pXORMask )& bitMask) {
						cursorData |= 0x1;
					}

					if (*(pANDMask  )& bitMask) {
						cursorData |= 0x2;
					}
				}
				pANDMask++;
				pXORMask++;
			}
			// Add to our HW Cursor data
			*pCursorData-- = cursorData;
		}
	}

	// Turn on cursor
	m_lcd->hwc.cursorctrl = 1;
}


void Au12::HWCursorOff()
{
	m_lcd->hwc.cursorctrl = 0;
}
#endif


void    Au12::WaitForNotBusy(void)
{
    DEBUGMSG (GPE_ZONE_INIT, (TEXT("Au12::WaitForNotBusy\r\n")));
    return;
}

int        Au12::IsBusy(void)
{
    DEBUGMSG (GPE_ZONE_INIT, (TEXT("Au12::IsBusy\r\n")));
    return    0;
}

void    Au12::GetPhysicalVideoMemory(unsigned long *physicalMemoryBase, unsigned long *videoMemorySize)
{
    DEBUGMSG (GPE_ZONE_INIT, (TEXT("Au12::GetPhysicalVideoMemory\r\n")));

    *physicalMemoryBase = m_pvFlatFrameBuffer;
    *videoMemorySize    = m_FrameBufferSize;
}

void
Au12::GetVirtualVideoMemory(
    unsigned long *virtualMemoryBase,
    unsigned long *videoMemorySize
    )
{
    DEBUGMSG (GPE_ZONE_INIT, (TEXT("Au12::GetVirtualVideoMemory\r\n")));

    *virtualMemoryBase = m_VirtualFrameBuffer;
    *videoMemorySize   = m_FrameBufferSize;
}

SCODE
Au12::WrappedEmulatedLine(
    GPELineParms *lineParameters
    )
{
    SCODE retval;
    RECT  bounds;
    int   N_plus_1;                // Minor length of bounding rect + 1

    // calculate the bounding-rect to determine overlap with cursor
    if (lineParameters->dN)            // The line has a diagonal component (we'll refresh the bounding rect)
    {
        N_plus_1 = 2 + ((lineParameters->cPels * lineParameters->dN) / lineParameters->dM);
    }
    else
    {
        N_plus_1 = 1;
    }

    switch(lineParameters->iDir)
    {
        case 0:
            bounds.left = lineParameters->xStart;
            bounds.top = lineParameters->yStart;
            bounds.right = lineParameters->xStart + lineParameters->cPels + 1;
            bounds.bottom = bounds.top + N_plus_1;
            break;
        case 1:
            bounds.left = lineParameters->xStart;
            bounds.top = lineParameters->yStart;
            bounds.bottom = lineParameters->yStart + lineParameters->cPels + 1;
            bounds.right = bounds.left + N_plus_1;
            break;
        case 2:
            bounds.right = lineParameters->xStart + 1;
            bounds.top = lineParameters->yStart;
            bounds.bottom = lineParameters->yStart + lineParameters->cPels + 1;
            bounds.left = bounds.right - N_plus_1;
            break;
        case 3:
            bounds.right = lineParameters->xStart + 1;
            bounds.top = lineParameters->yStart;
            bounds.left = lineParameters->xStart - lineParameters->cPels;
            bounds.bottom = bounds.top + N_plus_1;
            break;
        case 4:
            bounds.right = lineParameters->xStart + 1;
            bounds.bottom = lineParameters->yStart + 1;
            bounds.left = lineParameters->xStart - lineParameters->cPels;
            bounds.top = bounds.bottom - N_plus_1;
            break;
        case 5:
            bounds.right = lineParameters->xStart + 1;
            bounds.bottom = lineParameters->yStart + 1;
            bounds.top = lineParameters->yStart - lineParameters->cPels;
            bounds.left = bounds.right - N_plus_1;
            break;
        case 6:
            bounds.left = lineParameters->xStart;
            bounds.bottom = lineParameters->yStart + 1;
            bounds.top = lineParameters->yStart - lineParameters->cPels;
            bounds.right = bounds.left + N_plus_1;
            break;
        case 7:
            bounds.left = lineParameters->xStart;
            bounds.bottom = lineParameters->yStart + 1;
            bounds.right = lineParameters->xStart + lineParameters->cPels + 1;
            bounds.top = bounds.bottom - N_plus_1;
            break;
        default:
            DEBUGMSG(GPE_ZONE_ERROR,(TEXT("Invalid direction: %d\r\n"), lineParameters->iDir));
            return E_INVALIDARG;
    }

    RECTL cursorRect = m_CursorRect;
    RotateRectl (&cursorRect);

    // check for line overlap with cursor and turn off cursor if overlaps
    if (m_CursorVisible && !m_CursorDisabled &&
        cursorRect.top < bounds.bottom && cursorRect.bottom > bounds.top &&
        cursorRect.left < bounds.right && cursorRect.right > bounds.left)
    {
        CursorOff();
        m_CursorForcedOff = TRUE;
    }

    // do emulated line
    retval = EmulatedLine (lineParameters);

    // see if cursor was forced off because of overlap with line bounds and turn back on
    if (m_CursorForcedOff)
    {
        m_CursorForcedOff = FALSE;
        CursorOn();
    }

    return    retval;

}

SCODE    Au12::Line(GPELineParms *lineParameters, EGPEPhase phase)
{
    DEBUGMSG (GPE_ZONE_INIT, (TEXT("Au12::Line\r\n")));

    if (phase == gpeSingle || phase == gpePrepare)
    {
        DispPerfStart(ROP_LINE);

        if ((lineParameters->pDst != m_pPrimarySurface))
        {
            lineParameters->pLine = &GPE::EmulatedLine;
        }
        else
        {
            lineParameters->pLine = (SCODE (GPE::*)(struct GPELineParms *)) &Au12::WrappedEmulatedLine;
        }
    }
    else if (phase == gpeComplete)
    {
        DispPerfEnd(0);
    }
    return S_OK;
}

SCODE Au12::BltPrepare(GPEBltParms *blitParameters)
{
    int srcFormat;

	blitParameters->pBlt = m_BltFunctions.pCatchAllBlt; // catch all

	// Check to ensure that the Destination color depth matches our current color depth
	// No Acceleration for rotated desktop at this time.
    if ((m_iRotate) &&
        (blitParameters->pDst->IsRotate()) ||
        (blitParameters->pSrc != NULL && blitParameters->pSrc->IsRotate())
        )
    {
        blitParameters->pBlt =&GPE::EmulatedBltRotate;

		return S_OK;
	}

	// Make sure it's the Destination has same Bpp as our screen
	if ( blitParameters->pDst->Format() != m_pMode->format )
	{
        return S_OK;
    }

    // Is there a pointer to a Source?
	if (!blitParameters->pSrc)
	{
		return S_OK;
	}

	// Is the Source and Destination addresses the same??  If it is, then we can't handle it.
	if (blitParameters->pDst->Buffer() == blitParameters->pSrc->Buffer())
	{
		return S_OK;
	}

	// Is it a colordepth we can handle? If it's not return out and let the Catchall get it.
	srcFormat = blitParameters->pSrc->Format();
    if ( !( srcFormat == gpe1Bpp  ||
            srcFormat == gpe4Bpp  ||
            srcFormat == gpe8Bpp  ||
            srcFormat == gpe16Bpp ||
            srcFormat == gpe24Bpp ||
            srcFormat == gpe32Bpp ) )
    {
        return S_OK;
    }

    // Emulate if Transparent or AlphaBlend required
    if ( (blitParameters->bltFlags & ( BLT_TRANSPARENT | BLT_ALPHABLEND)) )
    {
        return S_OK;
    }


    switch (blitParameters->rop4)
    {
        ///////////////////////////////////////////////////////////////////////
        // These are only dependent on the Destination Bpp
        ///////////////////////////////////////////////////////////////////////
        case	0x0000:	// BLACKNESS
            blitParameters->solidColor = 0x0;
            blitParameters->pBlt = m_BltFunctions.pFillRectBlt;
            break;

        case	0xFFFF:	// WHITENESS
            blitParameters->solidColor = 0xffffff;
            blitParameters->pBlt = m_BltFunctions.pFillRectBlt;
            break;

        case    0x5555: // DSTINVERT
            blitParameters->pBlt = m_BltFunctions.pDestInvBlt;
            break;

        case	0xF0F0:	// PATCOPY
            if (blitParameters->solidColor != -1)
            {
                blitParameters->pBlt = m_BltFunctions.pFillRectBlt;
                break;
            }
            break;

        case	0x5A5A:	// PATINVERT
            if (blitParameters->solidColor != -1)
            {
                blitParameters->pBlt = m_BltFunctions.pFillRectInvBlt;
                break;
            }
            break;

        ///////////////////////////////////////////////////////////////////////
        //  These are dependent on both the Source Bpp and Destination Bpp
        ///////////////////////////////////////////////////////////////////////
        case	0x6666:	// SRCINVERT
            blitParameters->pBlt = m_BltFunctions.pSrcInvBlt;
            break;

        case	0x8888:	// SRCAND
            blitParameters->pBlt = m_BltFunctions.pSrcAndBlt;
            break;

        case	0xCCCC:	// SRCCOPY
            blitParameters->pBlt = m_BltFunctions.pSrcCopyBlt;
            break;

        case	0xEEEE:	// SRCPAINT
            blitParameters->pBlt = m_BltFunctions.pSrcPaintBlt;
            break;

        case 0xAAF0:    // TEXT
			blitParameters->pBlt = m_BltFunctions.pTextBlt;
            break; // use default emulation

        default:
            break; // do nothing... let's use default emulation
    }

    return S_OK;
}

SCODE    Au12::BltComplete(GPEBltParms *blitParameters)
{
    DEBUGMSG (GPE_ZONE_INIT, (TEXT("Au12::BltComplete\r\n")));

    // see if cursor was forced off because of overlap with source or destination and turn back on
    if (m_CursorForcedOff)
    {
        m_CursorForcedOff = FALSE;
        CursorOn();
    }

    DispPerfEnd(0);

    return S_OK;
}

INT        Au12::InVBlank(void)
{
	static BOOL bIn = FALSE;

	if (bIn) {
		// currently in vblank, are we out yet ? (SA = start active video)
		if (m_lcd->intstatus & LCD_INT_SA) {
			m_lcd->intstatus = LCD_INT_SA; // clear status bit
			bIn = FALSE;
		}
	} else {
		// currently out of vblank, are we in yet ? (SS = start sync)
		if (m_lcd->intstatus & LCD_INT_SS) {
			m_lcd->intstatus = LCD_INT_SS; // clear status bit
			bIn = TRUE;
		}
	}

	return bIn;
}

SCODE    Au12::SetPalette(const PALETTEENTRY *source, USHORT firstEntry, USHORT numEntries)
{
  volatile uint32 *pLcdPalette = m_lcd->palette;
  PULONG pSource = (PULONG)source;
  int i;

  DEBUGMSG (GPE_ZONE_INIT, (TEXT("Au12::SetPalette\r\n")));

  if( firstEntry < 0 || firstEntry + numEntries > 256 )
    return E_INVALIDARG;

  //In case there's any application call SetPalette() at display time,
  //we may have to add the next line to set palette only during
  //Vertical None-Display period to avoid "snowy" effect.
  //   WaitForVBlank();

  for(i=firstEntry; i<numEntries; i++)
     *pLcdPalette++ = *pSource++;

  return    S_OK;
}

int
Au12::GetGameXInfo(
    ULONG iEsc,
    ULONG cjIn,
    PVOID pvIn,
    ULONG cjOut,
    PVOID pvOut
    )
{
    int     RetVal = 0;     // Default not supported
    GXDeviceInfo * pgxoi;

    // GAPI only support P8, RGB444, RGB555, RGB565, and RGB888
    if ((cjOut >= sizeof(GXDeviceInfo)) && (pvOut != NULL)
        && (m_pMode->Bpp == 8 || m_pMode->Bpp == 16 || m_pMode->Bpp == 24 || m_pMode->Bpp == 32))
    {
        if (((GXDeviceInfo *) pvOut)->idVersion == kidVersion100)
        {
            pgxoi = (GXDeviceInfo *) pvOut;
            pgxoi->idVersion = kidVersion100;
            pgxoi->pvFrameBuffer = (void *)m_pPrimarySurface->Buffer();
            pgxoi->cbStride = m_pPrimarySurface->Stride();
            pgxoi->cxWidth = m_pPrimarySurface->Width();
            pgxoi->cyHeight = m_pPrimarySurface->Height();

            if (m_pMode->Bpp == 8)
            {
                pgxoi->cBPP = 8;
                pgxoi->ffFormat = kfPalette;
            }
            else if (m_pMode->Bpp == 16)
            {
                pgxoi->cBPP = 16;
                pgxoi->ffFormat= kfDirect | kfDirect565;
            }
            else if (m_pMode->Bpp == 24)
            {
                pgxoi->cBPP = 24;
                pgxoi->ffFormat = kfDirect | kfDirect888;
            }
            else
            {
                pgxoi->cBPP = 32;
                pgxoi->ffFormat = kfDirect | kfDirect888;
            }

            pgxoi->vkButtonUpPortrait = VK_UP;
            pgxoi->vkButtonUpLandscape = VK_LEFT;
            pgxoi->vkButtonDownPortrait = VK_DOWN;
            pgxoi->vkButtonDownLandscape = VK_RIGHT;
            pgxoi->vkButtonLeftPortrait = VK_LEFT;
            pgxoi->vkButtonLeftLandscape = VK_DOWN;
            pgxoi->vkButtonRightPortrait = VK_RIGHT;
            pgxoi->vkButtonRightLandscape = VK_UP;
            pgxoi->vkButtonAPortrait = 0xC3;            // far right button
            pgxoi->vkButtonALandscape = 0xC5;            // record button on side
            pgxoi->vkButtonBPortrait = 0xC4;            // second from right button
            pgxoi->vkButtonBLandscape = 0xC1;
            pgxoi->vkButtonCPortrait = 0xC5;            // far left button
            pgxoi->vkButtonCLandscape = 0xC2;            // far left button
            pgxoi->vkButtonStartPortrait = 134;            // action button
            pgxoi->vkButtonStartLandscape = 134;
            pgxoi->ptButtonUp.x = 120;
            pgxoi->ptButtonUp.y = 330;
            pgxoi->ptButtonDown.x = 120;
            pgxoi->ptButtonDown.y = 390;
            pgxoi->ptButtonLeft.x = 90;
            pgxoi->ptButtonLeft.y = 360;
            pgxoi->ptButtonRight.x = 150;
            pgxoi->ptButtonRight.y = 360;
            pgxoi->ptButtonA.x = 180;
            pgxoi->ptButtonA.y = 330;
            pgxoi->ptButtonB.x = 210;
            pgxoi->ptButtonB.y = 345;
            pgxoi->ptButtonC.x = -50;
            pgxoi->ptButtonC.y = 0;
            pgxoi->ptButtonStart.x = 120;
            pgxoi->ptButtonStart.y = 360;
            pgxoi->pvReserved1 = (void *) 0;
            pgxoi->pvReserved2 = (void *) 0;
            RetVal = 1;

        }
        else
        {
            SetLastError (ERROR_INVALID_PARAMETER);
            RetVal = -1;
        }
    }
    else
    {
        SetLastError (ERROR_INVALID_PARAMETER);
        RetVal = -1;
    }

    return(RetVal);
}

ULONG
Au12::DrvEscape(
    SURFOBJ * pso,
    ULONG     iEsc,
    ULONG     cjIn,
    void    * pvIn,
    ULONG     cjOut,
    void    * pvOut
    )
{

  if (iEsc == QUERYESCSUPPORT)
  {
    if (*(DWORD*)pvIn == GETGXINFO
      || *(DWORD*)pvIn == DRVESC_GETSCREENROTATION
      || *(DWORD*)pvIn == DRVESC_SETSCREENROTATION
      || *(DWORD*)pvIn == SETPOWERMANAGEMENT
      || *(DWORD*)pvIn == GETPOWERMANAGEMENT
      || *(DWORD*)pvIn == IOCTL_POWER_CAPABILITIES
      || *(DWORD*)pvIn == IOCTL_POWER_GET
      || *(DWORD*)pvIn == IOCTL_POWER_QUERY
      || *(DWORD*)pvIn == IOCTL_POWER_SET )
    {
      // The escape is supported.
      return 1;
    }
    else
    {
      // The escape isn't supported.
      return 0;
    }
  }
  else if (iEsc == DRVESC_GETSCREENROTATION)
  {
    *(int *)pvOut = ((DMDO_0 | DMDO_90 | DMDO_180 | DMDO_270) << 8) | ((BYTE)m_iRotate);
    return DISP_CHANGE_SUCCESSFUL;
  }
  else if (iEsc == DRVESC_SETSCREENROTATION)
  {
    if ((cjIn == DMDO_0)   ||
      (cjIn == DMDO_90)  ||
      (cjIn == DMDO_180) ||
      (cjIn == DMDO_270) )
    {
      return DynRotate(cjIn);
    }

    return DISP_CHANGE_BADMODE;
  }
  else if (iEsc == GETGXINFO)
  {
    return GetGameXInfo(iEsc, cjIn, pvIn, cjOut, pvOut);
  }

  if ( (m_CurrentDx == 4) && (iEsc != IOCTL_POWER_SET) )
  {
	  // The display driver is in power save... we can only do power calls
	  return FALSE;
  }


  /*
  *	RMI Specific ESC codes go here
  */
  switch( iEsc ) {

    case IOCTL_POWER_CAPABILITIES:
      if (pvOut != NULL && cjOut == sizeof(POWER_CAPABILITIES))
      {
        PPOWER_CAPABILITIES ppc = (PPOWER_CAPABILITIES) pvOut;
        memset(ppc, 0, sizeof(*ppc));
        ppc->DeviceDx = DX_MASK(D0) | DX_MASK(D4);	// D0 and D4 only
      }
      break;

    case IOCTL_POWER_QUERY:
      if(pvOut != NULL && cjOut == sizeof(CEDEVICE_POWER_STATE))
      {
        CEDEVICE_POWER_STATE NewDx = *(PCEDEVICE_POWER_STATE)pvOut;
        if(!(VALID_DX(NewDx)))
          return 0;
      }
      break;

    case IOCTL_POWER_SET:
      if(pvOut != NULL && cjOut == sizeof(CEDEVICE_POWER_STATE))
      {
        CEDEVICE_POWER_STATE NewDx = *(PCEDEVICE_POWER_STATE)pvOut;
		PowerHandler(NewDx);
        m_CurrentDx = NewDx;
      }
      break;

    case IOCTL_POWER_GET:
      if(pvOut != NULL && cjOut == sizeof(CEDEVICE_POWER_STATE))
      {
        *((PCEDEVICE_POWER_STATE) pvOut) = m_CurrentDx;
      }
      break;

	/**************************************************************************
	*					Overlay IOCTL Implementation                          *
	***************************************************************************/

	case LCD_SCREEN_GET:
		if(cjOut >= sizeof(ULONG))
			*(ULONG*)pvOut = m_lcd->screen;
		break;

	case LCD_OVERLAY_ENABLE:
		if(cjIn == sizeof(ULONG))
			EnablePlane(*((ULONG*)pvIn));
		break;

	case LCD_OVERLAY_DISABLE:
		if(cjIn == sizeof(ULONG))
			DisablePlane(*((ULONG*)pvIn));
		break;


    case LCD_OVERLAY_CREATE:
      if(cjIn >= sizeof(OVERLAY_IOCTL))
      {
		OVERLAY_IOCTL  * pOverlay = (POVERLAY_IOCTL)pvIn;
		ULONG ndx = pOverlay->ndx;

        m_lcd->window[ndx].winctrl0 = pOverlay->winctrl0;

		// If caller wants to "force" their own settings
		if ( !(pOverlay->flags & OVERLAY_OVERRIDE_REGISTRY) )
		{
			// Clear caller's values if using registry entries
			pOverlay->winctrl1 &= ~(LCD_WINCTRL1_PRI | LCD_WINCTRL1_PIPE);

			// Assign Priority and Pipe to new overlay
			pOverlay->winctrl1 |= (LCD_WINCTRL1_PIPE_N(m_Windows[ndx].dwPipe) |
								   LCD_WINCTRL1_PRI_N(m_Windows[ndx].dwPriority));
		}
        m_lcd->window[ndx].winctrl1 = pOverlay->winctrl1;
        m_lcd->window[ndx].winctrl2 = pOverlay->winctrl2;
        m_lcd->window[ndx].winbufctrl = pOverlay->bufctrl;
      }
      break;

    case LCD_OVERLAY_DESTROY:
	  if(cjIn >= sizeof(OVERLAY_IOCTL))
      {
		OVERLAY_IOCTL  * pOverlay = (POVERLAY_IOCTL)pvIn;
		ULONG ndx = pOverlay->ndx;

		m_lcd->window[ndx].winctrl0 = 0;
        m_lcd->window[ndx].winctrl1 = 0;
        m_lcd->window[ndx].winctrl2 = 0;
        m_lcd->window[ndx].winbufctrl = 0;
      }
      break;

	case LCD_OVERLAY_UPDATE:
	  if(cjIn >= sizeof(OVERLAY_UPDATE_IOCTL))
	  {
	   	OVERLAY_UPDATE_IOCTL *pOverlay = (POVERLAY_UPDATE_IOCTL)pvIn;
	   	ULONG ndx = pOverlay->ndx;
/* TODO -- real double buffering support */
		if (pOverlay->flags & LCD_UPDATE_IN_VBLANK)
		{
			WaitForVBlank();
		}
	   	m_lcd->window[ndx].winbuf0 = m_lcd->window[ndx].winbuf1 = (ULONG)pOverlay->phys;
	   }
	   break;

	case LCD_OVERLAY_SET_NEXT_BUFFER:
		if(cjIn >= sizeof(OVERLAY_UPDATE_IOCTL))
		{
			OVERLAY_UPDATE_IOCTL *pOverlay = (POVERLAY_UPDATE_IOCTL)pvIn;
			ULONG ndx = pOverlay->ndx;

			if (m_lcd->window[ndx].winbufctrl & LCD_WINBUFCTRL_DB)
			{
				m_lcd->window[ndx].winbuf0 = (ULONG)pOverlay->phys;
				m_lcd->window[ndx].winbufctrl = 0;
			}
			else
			{
				m_lcd->window[ndx].winbuf1 = (ULONG)pOverlay->phys;
				m_lcd->window[ndx].winbufctrl = 1;
			}
		}
		break;

    case  LCD_COLORKEY_SET:
      if(cjIn >= sizeof(LCD_COLORKEY_IOCTL))
      {
		LCD_COLORKEY_IOCTL *pKey = (PLCD_COLORKEY_IOCTL)pvIn;
		m_lcd->colorkey		= pKey->colorkey;
		m_lcd->colorkeymsk	= pKey->colorkeymsk;
      }
      break;

    case  LCD_COLORKEY_GET:
      if(cjOut >= sizeof(LCD_COLORKEY_IOCTL))
      {
		LCD_COLORKEY_IOCTL *pKey = (PLCD_COLORKEY_IOCTL)pvOut;
		pKey->colorkey 		= m_lcd->colorkey;
		pKey->colorkeymsk   = m_lcd->colorkeymsk;
      }
      break;

	case LCD_BACKGROUND_SET:
		if(cjIn == sizeof(ULONG))
			m_lcd->backcolor = *((ULONG*)pvIn);
		break;

	case LCD_BACKGROUND_GET:
		if(cjOut >= sizeof(ULONG))
			*((ULONG*)pvOut) = m_lcd->backcolor;
		break;

	case LCD_GAMMA_SET:
		if(cjIn == sizeof(ULONG)*SIZE_RAM_ARRAY)
			SetPalette((PALETTEENTRY *)pvIn, 0, SIZE_RAM_ARRAY);
		break;

	case LCD_GAMMA_GET:
		if(cjOut >= sizeof(ULONG)*SIZE_RAM_ARRAY)
		{
			volatile ULONG *pLcdPalette = m_lcd->palette;
			ULONG i;
			ULONG * pOut = (ULONG*)pvOut;
			for(i=0;i<SIZE_RAM_ARRAY;i++)
				*pOut++ = *pLcdPalette++;
		}
		break;

    case LCD_OVERLAY_CONFIG:
      if(cjIn >= sizeof(OVERLAY_IOCTL))
      {
		OVERLAY_IOCTL  * pOverlay = (POVERLAY_IOCTL)pvIn;
		ULONG ndx = pOverlay->ndx;

		if ( pOverlay->flags & OVERLAY_CONFIG_GET )
		{
	        pOverlay->winctrl0 = m_lcd->window[ndx].winctrl0;
	        pOverlay->winctrl1 = m_lcd->window[ndx].winctrl1;
	        pOverlay->winctrl2 = m_lcd->window[ndx].winctrl2;
	        pOverlay->bufctrl  = m_lcd->window[ndx].winbufctrl;
		}
        else
		{
			unsigned int x_orig = GET_LCD_WINCTRL0_OX_N(pOverlay->winctrl0);
			unsigned int y_orig = GET_LCD_WINCTRL0_OY_N(pOverlay->winctrl0);
			unsigned int width = GET_LCD_WINCTRL1_SZX_N(pOverlay->winctrl1);
			unsigned int height = GET_LCD_WINCTRL1_SZY_N(pOverlay->winctrl1);
			unsigned int stride = GET_LCD_WINCTRL2_BX_N(pOverlay->winctrl2);
			unsigned int x_scaler = GET_LCD_WINCTRL2_SCX_N(pOverlay->winctrl2);
			unsigned int y_scaler = GET_LCD_WINCTRL2_SCY_N(pOverlay->winctrl2);

			// Validate the configuration
			// valid origin?
			if (x_orig > ((unsigned int)m_nScreenWidth - 1))
			{
				RETAILMSG(1, (TEXT("Invalid x_orig: %d\r\n"), x_orig));
				return FALSE;
			}

			if (y_orig > ((unsigned int)m_nScreenHeight - 1))
			{
				RETAILMSG(1, (TEXT("Invalid y_orig: %d\r\n"), y_orig));
				return FALSE;
			}

			// valid size?
			// We need to compare the size with the physica size.  Regardless of the orientation the
			// Overlays are always relative to the physical screen.
			if ((x_orig + width)  > ((unsigned int)m_cxPhysicalScreen  - 1))
			{
				RETAILMSG(1, (TEXT("Invalid width: %d\r\n"), width));
				return FALSE;
			}

			if ((y_orig + height) > ((unsigned int)m_cyPhysicalScreen  - 1))
			{
				RETAILMSG(1, (TEXT("Invalid height: %d\r\n"), height));
				return FALSE;
			}

			// valid stride?
			if (stride > ((m_nScreenWidth + 1) * m_BytesPP))
			{
				RETAILMSG(1, (TEXT("Invalid stride: %d\r\n"), stride));
				return FALSE;
			}


			// valid scale factors?
			if ((x_scaler  > 2) || (y_scaler > 2))
			{
				RETAILMSG(1, (TEXT("Invalid scaler: %d or %d\r\n"), x_scaler, y_scaler));
				return FALSE;
			}

			// Only configure in VBlank or we might get shakey screen
			WaitForVBlank(); 

	        m_lcd->window[ndx].winctrl0 = pOverlay->winctrl0;
	        m_lcd->window[ndx].winctrl1 = pOverlay->winctrl1;
	        m_lcd->window[ndx].winctrl2 = pOverlay->winctrl2;
	        m_lcd->window[ndx].winbufctrl = pOverlay->bufctrl;
		}

	  }
	  break;

	/**************************************************************************
	*			    Pixel Read/Write IOCTL Implementation                     *
	***************************************************************************/
	case PIXEL_READ:
      if(cjIn >= sizeof(PIXEL_IOCTL))
      {
		PIXEL_IOCTL  * pPix = (PPIXEL_IOCTL)pvIn;
		ULONG ndx = pPix->ndx;
		ULONG stride = ((m_lcd->window[ndx].winctrl2 & LCD_WINCTRL2_BX)>>8);
		ULONG i,cpylen;
		UCHAR *pSrc;
		UCHAR *pDst=(PUCHAR)pvOut;
		ULONG bpp = stride / (((m_lcd->window[ndx].winctrl1 & LCD_WINCTRL1_SZX)>>11)+1);

		// Account for the width we're reading
		cpylen = pPix->w * bpp;
		stride -= cpylen;

		if (m_lcd->window[ndx].winbufctrl & LCD_WINBUFCTRL_DB)
			pSrc = (PUCHAR)m_lcd->window[ndx].winbuf0 + (pPix->x + pPix->y * bpp);
		else
			pSrc = (PUCHAR)m_lcd->window[ndx].winbuf1 + (pPix->x + pPix->y * bpp);

		pSrc = (UCHAR*)( (ULONG)pSrc + KSEG1_OFFSET);

		RETAILMSG(0,(TEXT("CTG -- readPixels(x:%d y:%d w:%d h:%d st:%d cpy:%d bpp:%d)\r\n"),
			pPix->x, pPix->y, pPix->w, pPix->h, stride, cpylen, bpp ));

		// copy 'height' number of lines
		for(i=0;i<pPix->h;i++)
		{
			memcpy(pDst, pSrc, cpylen);
			pSrc += stride;	 		// move to next line in rect
			pDst += cpylen;			// increment our dest pointer
		}
	  }
	  break;

	case PIXEL_WRITE:
		break;

  }

  return TRUE;
}

int
Au12::GetRotateModeFromReg()
{
    HKEY hKey;

    if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("SYSTEM\\GDI\\ROTATION"), 0, 0, &hKey))
    {
        DWORD dwSize, dwAngle, dwType = REG_DWORD;
        dwSize = sizeof(DWORD);
        if (ERROR_SUCCESS == RegQueryValueEx(hKey,
                                             TEXT("ANGLE"),
                                             NULL,
                                             &dwType,
                                             (LPBYTE)&dwAngle,
                                             &dwSize))
        {
            switch (dwAngle)
            {
            case 0:
                return DMDO_0;

            case 90:
                return DMDO_90;

            case 180:
                return DMDO_180;

            case 270:
                return DMDO_270;

            default:
                return DMDO_0;
            }
        }

        RegCloseKey(hKey);
    }

    return DMDO_0;
}

void
Au12::SetRotateParams()
{
    int iswap;

    switch(m_iRotate)
    {
    case DMDO_0:
        m_nScreenHeightSave = m_nScreenHeight;
        m_nScreenWidthSave  = m_nScreenWidth;
        break;

    case DMDO_180:
        m_nScreenHeightSave = m_nScreenHeight;
        m_nScreenWidthSave  = m_nScreenWidth;
        break;

    case DMDO_90:
    case DMDO_270:
        iswap               = m_nScreenHeight;
        m_nScreenHeight     = m_nScreenWidth;
        m_nScreenWidth      = iswap;
        m_nScreenHeightSave = m_nScreenWidth;
        m_nScreenWidthSave  = m_nScreenHeight;
        break;

    default:
        m_nScreenHeightSave = m_nScreenHeight;
        m_nScreenWidthSave  = m_nScreenWidth;
        break;
    }

    return;
}


LONG
Au12::DynRotate(
    int angle
    )
{
    GPESurfRotate * pSurf = (GPESurfRotate *)m_pPrimarySurface;

    if (angle == m_iRotate)
    {
        return DISP_CHANGE_SUCCESSFUL;
    }
#ifdef USE_HW_CURSOR
	HWCursorOff();
#else
    CursorOff();
#endif


    m_iRotate = angle;

    switch(m_iRotate)
    {
    case DMDO_0:
    case DMDO_180:
        m_nScreenHeight = m_nScreenHeightSave;
        m_nScreenWidth  = m_nScreenWidthSave;
        break;

    case DMDO_90:
    case DMDO_270:
        m_nScreenHeight = m_nScreenWidthSave;
        m_nScreenWidth  = m_nScreenHeightSave;
        break;
    }

    m_pMode->width  = m_nScreenWidth;
    m_pMode->height = m_nScreenHeight;

    pSurf->SetRotation(m_nScreenWidth, m_nScreenHeight, angle);

#ifdef USE_HW_CURSOR
	HWCursorOn();
#else
    CursorOn();
#endif


    return DISP_CHANGE_SUCCESSFUL;
}

ULONG *
APIENTRY
DrvGetMasks(
    DHPDEV dhpdev
    )
{
    return gBitMasks;
}


unsigned long ReverseULong(unsigned long c)
{
    // with a long you have 4 bytes bytes 1 2 3 and 4
    // swaps bytes 1 and 2 with 3 and 4
    c = (c & 0x0000FFFF) << 16 | (c & 0xFFFF0000) >> 16;

    // swaps bytes 1 and 2 and bytes 3 and 4
    c = (c & 0x00FF00FF) << 8 | (c & 0xFF00FF00) >> 8;

    // now does the same thing as above only within each byte until each bit is in reverse position
    c = (c & 0x0F0F0F0F) << 4 | (c & 0xF0F0F0F0) >> 4;
    c = (c & 0x33333333) << 2 | (c & 0xCCCCCCCC) >> 2;
    c = (c & 0x55555555) << 1 | (c & 0xAAAAAAAA) >> 1;

    return c;
}


void Au12::RotateCursorMask(unsigned long src[32], unsigned long dest[32], int iRotate)
{
	int NewRow;
	int OrigRow;
	unsigned long curRow, curBit;
	int Bit = 31;


	switch (iRotate)
	{
	case DMDO_90:
		for(OrigRow = 0; OrigRow < 32; OrigRow++)
		{
			curRow = src[OrigRow];

			curBit = 0x80000000;
			for(NewRow = 31; NewRow >= 0; NewRow--)
			{
				if ((curBit & curRow))
				{
					// Set Mask to turn bit on
					dest[NewRow] |= (1<< (31 - OrigRow));
				}
				else
				{
					// Set Mask to turn bit off
					dest[NewRow] &= ~(1<<(31 - OrigRow));
				}
				curBit = curBit >> 1;
			}

		}

		// Adjust the hotspot for this rotation
        m_CurCursorHotspot.x = m_CursorHotspot.x;
        m_CurCursorHotspot.y = 32 - m_CursorHotspot.y;
		break;

	case DMDO_180:
		for(OrigRow = 0; OrigRow < 32; OrigRow++)
		{
			dest[Bit] = ReverseULong(src[OrigRow]);
			Bit--;
		}

		// Adjust the hotspot for this rotation
        m_CurCursorHotspot.x = 32 - m_CursorHotspot.x;
        m_CurCursorHotspot.y = 32 - m_CursorHotspot.y;
		break;

	case DMDO_270:
		for(OrigRow = 0; OrigRow < 32; OrigRow++)
		{
			curRow = src[OrigRow];

			curBit = 0x80000000;
			for(NewRow = 0; NewRow < 32; NewRow++)
			{
				if ((curBit & curRow))
				{
					// Set Mask to turn bit on
					dest[NewRow] |= (1<<OrigRow);
				}
				else
				{
					// Set Mask to turn bit off
					dest[NewRow] &= ~(1<<OrigRow);
				}
				curBit = curBit >> 1;
			}

		}

		// Adjust the hotspot for this rotation
		m_CurCursorHotspot.x = 32 - m_CursorHotspot.x;
        m_CurCursorHotspot.y = m_CursorHotspot.y;
		break;

	case DMDO_0:
	default:
			memcpy( (PVOID)dest, (PVOID)src, sizeof (unsigned long) * 32);

			m_CurCursorHotspot.x = m_CursorHotspot.x;
            m_CurCursorHotspot.y = m_CursorHotspot.y;
			break;
	}
}

SCODE Au12::DefaultBltFunctions(SCODE (GPE::*pDefaultBlt)(GPEBltParms *))
{
    m_BltFunctions.pDestInvBlt = pDefaultBlt;
    m_BltFunctions.pFillRectBlt = pDefaultBlt;
    m_BltFunctions.pFillRectInvBlt = pDefaultBlt;
    m_BltFunctions.pSrcAndBlt = pDefaultBlt;
    m_BltFunctions.pSrcCopyBlt = pDefaultBlt;
    m_BltFunctions.pSrcInvBlt = pDefaultBlt;
    m_BltFunctions.pSrcPaintBlt = pDefaultBlt;
    m_BltFunctions.pTextBlt = pDefaultBlt;
	m_BltFunctions.pCatchAllBlt = pDefaultBlt;

    return S_OK;
}

SCODE Au12::SetBltFunctions(int Bpp)
{
    switch (m_ModeInfo.Bpp)
	{
    case 16:
        Set16BppFunctions();
        break;

    case 32:
        Set32BppFunctions();
        break;

    default: // Don't have functions to handle this Bpp so just return and it will use the default
        break;
	}

	return S_OK;
}

void Au12::default_panel_init( Au12 *pAu12 )
{
	BCSR *bcsr = (BCSR*)BCSR_KSEG1_ADDR;
    bcsr->specific |= (BCSR_SPECIFIC_LCDVEEOFF | BCSR_SPECIFIC_LCDVDDOFF);
	WBSYNC();
}

void Au12::default_panel_deinit( Au12 *pAu12 )
{
    BCSR *bcsr = (BCSR*)BCSR_KSEG1_ADDR;
    bcsr->specific &= ~(BCSR_SPECIFIC_LCDVEEOFF | BCSR_SPECIFIC_LCDVDDOFF);
	WBSYNC();
}

void Au12::inverted_vdd_init( Au12 *pAu12 )
{
    BCSR *bcsr = (BCSR*)BCSR_KSEG1_ADDR;

	pAu12->InVBlank();
	pAu12->InVBlank();
	pAu12->InVBlank();

    default_panel_deinit(pAu12);
}

void Au12::inverted_vdd_deinit( Au12 *pAu12 )
{
    default_panel_init(pAu12);
}

#if defined(FOCUS_FS471)
void Au12::focus47x_init( Au12 *pAu12 )
{
    BCSR *bcsr = (BCSR*)BCSR_KSEG1_ADDR;
	bcsr->resets &= ~BCSR_RESETS_TV;
	StallExecution(10000);
	bcsr->resets |= BCSR_RESETS_TV;
	board_au1200fb_focus_init_cvsv(MODE_640x480);
}
#endif

// wait to start sync period
void Au12::WaitForVBlank()
{
	BOOL bInVBlank = FALSE;

	while (!bInVBlank)
	{
		// Clear the interrupt and status bits
		InterruptDone(dwSysIntr);
		m_lcd->intstatus = m_lcd->intstatus;

		WaitForSingleObject(hInterruptEvent, INFINITE);

		if (m_lcd->intstatus & LCD_INT_SS)
		{
			bInVBlank = TRUE;
		}
	}
}

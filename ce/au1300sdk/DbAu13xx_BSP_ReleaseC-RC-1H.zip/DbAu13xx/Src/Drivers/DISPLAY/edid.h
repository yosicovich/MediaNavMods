#define MAX_EDID	128


typedef struct
{
    unsigned int      dotclock;
    unsigned short    hdisplay;
    unsigned short    hsyncstart;
    unsigned short    hsyncend;
    unsigned short    htotal;
    unsigned short    vdisplay;
    unsigned short    vsyncstart;
    unsigned short    vsyncend;
    unsigned short    vtotal;

}modeline;

class EDID
{

private:
    HANDLE	hI2C;
    unsigned char edid[MAX_EDID];

    int parse_timing_description( unsigned char* dtd );
    int block_type( unsigned char* block );
    WCHAR * get_monitor_name( unsigned char const* block );
    WCHAR * get_vendor_sign( unsigned char const* block );
    int parse_monitor_limits( unsigned char* block );
    int parse_dpms_capabilities(unsigned char flags);

    int Parse();
	modeline	m_preferred;

public:
    EDID();
    ~EDID();

    modeline Query();



protected:
};
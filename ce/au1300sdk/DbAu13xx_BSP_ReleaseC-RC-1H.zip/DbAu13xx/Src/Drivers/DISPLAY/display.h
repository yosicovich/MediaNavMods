/*****************************************************************************
Copyright 2003-2007 Raza Microelectronics, Inc.(RMI). All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY Raza Microelectronics, Inc. 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef __AU12_H__
#define __AU12_H__

#include <platform.h>
#include <au1x00.h>

#include <lcd_ioctl.h>
#include <mem_ioctl.h>
#include "edid.h"
#define DEFAULT_OFFSCREEN_SIZE	0x200000
#define DEFAULT_BPP				16

#define NUM_OVERLAYS	1

typedef ULONG	OVERLAY_FLAGS;

// Type used to track overlay surfaces
typedef struct {
	bool			Active;
	ULONG			Offset;
	bool			SourceColorKeyed;
	bool			DestColorKeyed;
} AU1200_LCD_OVERLAY;


typedef struct {
	ULONG			dwPipe;
	ULONG			dwPriority;
    WCHAR 			wcName[MAX_PATH];
} LCD_WINDOW_CONFIG;


class Au12;

typedef void (*lcdinit)( Au12 * );
typedef void (*lcddeinit)( Au12 * );

typedef ULONG BitMask[3]; // RGB bitmasks

typedef struct AU1200_LCD_MODE
{
	unsigned short	*description;
	int			Xres, Yres;
	uint32		mode_screen;
	uint32		mode_horztiming;
	uint32		mode_verttiming;
	uint32		mode_clkcontrol;
	uint32		mode_pwmdiv;
	uint32		mode_pwmhi;
	uint32  	mode_outmask;
	uint32  	mode_fifoctrl;
	uint32		mode_backlight;
	uint32  	mode_auxpll;
	BitMask *	mode_bitmask;
	lcdinit   	init;
	lcddeinit 	deinit;

} AU1200_LCD_MODE;


///////////////////////////////////////////////////////////////////////////////
// Structure containing function pointers to or blit routines
///////////////////////////////////////////////////////////////////////////////
struct BltFunctions
{
    SCODE (GPE::*pDestInvBlt)(GPEBltParms *);
    SCODE (GPE::*pFillRectBlt)(GPEBltParms *);
    SCODE (GPE::*pFillRectInvBlt)(GPEBltParms *);
    SCODE (GPE::*pSrcAndBlt)(GPEBltParms *);
    SCODE (GPE::*pSrcCopyBlt)(GPEBltParms *);
    SCODE (GPE::*pSrcInvBlt)(GPEBltParms *);
    SCODE (GPE::*pSrcPaintBlt)(GPEBltParms *);
    SCODE (GPE::*pTextBlt)(GPEBltParms *);
	SCODE (GPE::*pCatchAllBlt)(GPEBltParms *);
};


/********************************************************************/

class Au12Surf;

class Au12 : public DDGPE
{
private:
	DWORD	  m_BytesPP;
    GPEMode   m_ModeInfo;
    DWORD     m_pvFlatFrameBuffer;
    DWORD     m_pPyhsicalFrameBuffer;
    DWORD     m_cbScanLineLength;
    DWORD     m_cxPhysicalScreen;
    DWORD     m_cyPhysicalScreen;
    DWORD     m_colorDepth;
	DWORD     m_cbOffScreen;
    DWORD     m_VirtualFrameBuffer;
    DWORD     m_FrameBufferSize;
    DWORD     m_RedMaskSize;
    DWORD     m_RedMaskPosition;
    DWORD     m_GreenMaskSize;
    DWORD     m_GreenMaskPosition;
    DWORD     m_BlueMaskSize;
    DWORD     m_BlueMaskPosition;
    DWORD     m_VesaMode;

    SurfaceHeap    *m_pVideoMemory;     // Base entry representing all video memory

    BOOL      m_CursorDisabled;
    BOOL      m_CursorVisible;
    BOOL      m_CursorForcedOff;
    RECTL     m_CursorRect;
    POINTL    m_CursorSize;
    POINTL    m_CursorHotspot;
	POINTL    m_CurCursorHotspot;

#ifdef USE_HW_CURSOR
	int		  m_nXHot;
	int		  m_nYHot;
	UCHAR	  m_CursorAndShape[32 * 32];
	UCHAR	  m_CursorXorShape[32 * 32];
#else
    // allocate enough backing store for a 64x64 cursor on a 32bpp (4 bytes per pixel) screen
    UCHAR     m_CursorBackingStore[64 * 64 * 4];
    UCHAR     m_CursorXorShape[64 * 64];
    UCHAR     m_CursorAndShape[64 * 64];
#endif


    HANDLE    m_hVFBMapping;

	AU1200_LCD		*m_lcd;     /* virtual pointer to LCD registers */
	AU1200_LCD		 m_lcdSaves;
	AU1X00_SYS		*m_sys;
	AU1200_LCD_MODE	*m_mode;

	MEM_IOCTL		fbMemPool;
	HANDLE			hMemPool;

	BOOL 			m_PowerState_On;
	CEDEVICE_POWER_STATE m_CurrentDx;


	Au12Surf	*m_pOldVisibleSurface;
	Au12Surf	*m_pNewVisibleSurface;
	BltFunctions    m_BltFunctions; // member variable containig pointers to our blit functions

	VOID Au12::SetRegisters(VOID);

	DWORD  dwSysIntr;
	HANDLE hInterruptEvent;
	VOID Au12::Shutdown(VOID);
	VOID Au12::Suspend(VOID);
	VOID Au12::Restore(VOID);
	BOOL Au12::InitFromRegistry(VOID);
	BOOL Au12::FreeFrameBuffer();
	BOOL Au12::AllocFrameBuffer(DWORD dwSize);

	EDID m_EDID;


public:
    Au12();

    virtual
    ~Au12();

	/* Panel Init routines */
    static void default_panel_init(Au12 *pAu12);
	static void default_panel_deinit(Au12 *pAu12);
	static void inverted_vdd_init(Au12 *pAu12);
	static void inverted_vdd_deinit(Au12 *pAu12);
	static void focus47x_init(Au12 *pAu12);

	int GetBpp();

    virtual
    int
    NumModes();

    virtual
    SCODE
    SetMode(
        int        modeId,
        HPALETTE * palette
        );

    virtual
    int
    InVBlank();

	virtual
	void
	WaitForVBlank(void);

    virtual
    SCODE
    SetPalette(
        const PALETTEENTRY * source,
        USHORT               firstEntry,
        USHORT               numEntries
        );

    virtual
    SCODE
    GetModeInfo(
        GPEMode * pMode,
        int       modeNumber
        );

    virtual
    SCODE
    SetPointerShape(
        GPESurf * mask,
        GPESurf * colorSurface,
        int       xHot,
        int       yHot,
        int       cX,
        int       cY
        );

    virtual
    SCODE
    MovePointer(
        int xPosition,
        int yPosition
        );

	void
	RotateCursorMask(
		unsigned long src[32],
		unsigned long dest[32],
		int iRotate
		);

    virtual
    void
    WaitForNotBusy();

    virtual
    int
    IsBusy();

    virtual
    void
    GetPhysicalVideoMemory(
        unsigned long * physicalMemoryBase,
        unsigned long * videoMemorySize
        );

    void
    GetVirtualVideoMemory(
        unsigned long * virtualMemoryBase,
        unsigned long * videoMemorySize
        );

    virtual
    SCODE
    Line(
        GPELineParms * lineParameters,
        EGPEPhase      phase
        );

    virtual
    SCODE
    BltPrepare(
        GPEBltParms * blitParameters
        );

    virtual
    SCODE
    BltComplete(
        GPEBltParms * blitParameters
        );

    virtual
    ULONG
    DrvEscape(
        SURFOBJ * pso,
        ULONG     iEsc,
        ULONG     cjIn,
        void    * pvIn,
        ULONG     cjOut,
        void    * pvOut
        );

    int
    GetGameXInfo(
        ULONG   iEsc,
        ULONG   cjIn,
        void  * pvIn,
        ULONG   cjOut,
        void  * pvOut
        );

    SCODE
    WrappedEmulatedLine(
        GPELineParms * lineParameters
        );

    void
    CursorOn();

    void
    CursorOff();

#ifdef USE_HW_CURSOR
	void
	HWCursorOn();

	void
	HWCursorOff();
#endif

	SCODE
	DefaultBltFunctions(
		SCODE (GPE::*pDefaultBlt)(GPEBltParms *)
		);

	SCODE
	SetBltFunctions(
		int Bpp
		);

	void
	Set16BppFunctions(void);

	void
	Set32BppFunctions(void);

	SCODE AcceleratedSrcCopyBlt16( GPEBltParms * pParms );
	SCODE AcceleratedSrcCopyBlt32( GPEBltParms * pParms );
	SCODE AcceleratedFillRect16( GPEBltParms * pParms );
	SCODE AcceleratedFillRect32( GPEBltParms * pParms );
	SCODE AcceleratedFillRectInvert16( GPEBltParms * pParms );
	SCODE AcceleratedFillRectInvert32( GPEBltParms * pParms );
	SCODE AcceleratedDestInvert16(GPEBltParms *pParms);
	SCODE AcceleratedDestInvert32(GPEBltParms *pParms);

    // surf.cpp
    virtual
    SCODE
    AllocSurface(
        GPESurf    ** surface,
        int           width,
        int           height,
        EGPEFormat    format,
        int           surfaceFlags
        );

    virtual
    SCODE
    AllocSurface(
        DDGPESurf         ** ppSurf,
        int                  width,
        int                  height,
        EGPEFormat           format,
        EDDGPEPixelFormat    pixelFormat,
        int                  surfaceFlags
        );

    int
    GetRotateModeFromReg();

    void SetRotateParams();

    long
    DynRotate(
        int angle
        );

    virtual VOID    PowerHandler ( CEDEVICE_POWER_STATE state );


// Added from Au.lcd driver
    unsigned int    m_nTicksPerFrame;       // E.g. 17 for 60 Hz frames, 1mS ticks
    unsigned int    m_nTicksAtFlip;         // TickCount at time flip was requested
    unsigned int    m_nTicksAtResync;       // TickCount when we last waited for VBlank

    virtual int     SurfaceBusyFlipping ( DDGPESurf *pSurf );
    void            CheckVisibleSurface (void);
    virtual int     FlipInProgress (void);

	AU1200_LCD_OVERLAY	m_Overlays[NUM_OVERLAYS];
	LCD_WINDOW_CONFIG   m_Windows[NUM_PLANES];

	DWORD SetOverlayPosition(int overlayIndex,
	                         LONG xPos,
	                         LONG yPos);

	DWORD ShowOverlay(LPDDRAWI_DDRAWSURFACE_LCL lpSrcSurf,
					  LONG                      width,
					  LONG                      height,
	                  LONG                      xPos,
	                  LONG                      yPos,
					  DWORD                     colorKey,
					  DWORD                     alphaValue,
					  DWORD                     dwFlags,
					  DDOVERLAYFX               overlayFX);

	DWORD HideOverlay(LPDDRAWI_DDRAWSURFACE_LCL lpSrcSurf);
	DWORD SetOverlaySurface(int                       overlayIndex,
	                        LPDDRAWI_DDRAWSURFACE_LCL lpSrcSurf);

	LONG  GetOverlayOffset(int overlayIndex) {
		return m_Overlays[overlayIndex].Active ? m_Overlays[overlayIndex].Offset:-1L;
	};

    void EnablePlane(int plane)  { m_lcd->winenable |= LCD_WINENABLE_N(plane); };
    void DisablePlane(int plane) { m_lcd->winenable &= ~LCD_WINENABLE_N(plane); };

    void PutPlaneOnPipe(int plane, int pipe)
    {
        if (0==pipe) {
            m_lcd->window[plane].winctrl1 &= ~LCD_WINCTRL1_PIPE;
        } else {
            m_lcd->window[plane].winctrl1 |= LCD_WINCTRL1_PIPE;
        }
    }

	int NumSourceColorKeyedOverlays()
	{
		int count = 0;
		for (int i=0;i<NUM_OVERLAYS;i++) if (m_Overlays[i].SourceColorKeyed) count++;
		return count;
	}

	int NumDestColorKeyedOverlays()
	{
		int count = 0;
		for (int i=0;i<NUM_OVERLAYS;i++) if (m_Overlays[i].DestColorKeyed) count++;
		return count;
	}

	int NumActiveOverlays()
	{
		int count = 0;
		for (int i=0;i<NUM_OVERLAYS;i++) if (m_Overlays[i].Active) count++;
		return count;
	}

	int	NumColorKeyedOverlays()
	{
		return NumSourceColorKeyedOverlays() + NumDestColorKeyedOverlays();
	}

    virtual void    SetVisibleSurface ( GPESurf* pSurf, BOOL bWaitForVBlank=FALSE );

//
    friend
    void
    buildDDHALInfo(
        LPDDHALINFO lpddhi,
        DWORD       modeidx
        );

};

class Au12Surf : public DDGPESurf
{
private:
    SurfaceHeap     *m_pSurfaceHeap;

public:
    Au12Surf(
        int          width,
        int          height,
        ULONG        offset,
        void       * pBits,
        int          stride,
        EGPEFormat   format,
		SurfaceHeap* pNode
        );

    Au12Surf(
        int                 width,
        int                 height,
        ULONG               offset,
        void              * pBits,
        int                 stride,
        EGPEFormat          format,
        EDDGPEPixelFormat   pixelFormat,
		SurfaceHeap* pNode
        );

    virtual
    ~Au12Surf();

};

#define IN_VBLANK   ( ((Au12 *)gGPE)->InVBlank() )
#define IS_BUSY     ( ((Au12 *)gGPE)->IsBusy() )

#endif __AU12_H__


#include "precomp.h"


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 16bpp operations
SCODE SourceInvert1to16( GPEBltParms * pParms );
SCODE SourceInvert4to16( GPEBltParms * pParms );
SCODE SourceInvert8to16( GPEBltParms * pParms );
SCODE SourceInvert16to16( GPEBltParms * pParms );
SCODE SourceInvert24to16( GPEBltParms * pParms );
SCODE SourceInvert32to16( GPEBltParms * pParms );

SCODE SourceCopy1to16( GPEBltParms * pParms );
SCODE SourceCopy4to16( GPEBltParms * pParms );
SCODE SourceCopy8to16( GPEBltParms * pParms );
SCODE SourceCopy16to16( GPEBltParms * pParms );
SCODE SourceCopy24to16( GPEBltParms * pParms );
SCODE SourceCopy32to16( GPEBltParms * pParms );

SCODE SourceAnd1to16( GPEBltParms * pParms );
SCODE SourceAnd4to16( GPEBltParms * pParms );
SCODE SourceAnd8to16( GPEBltParms * pParms );
SCODE SourceAnd16to16( GPEBltParms * pParms );
SCODE SourceAnd24to16( GPEBltParms * pParms );
SCODE SourceAnd32to16( GPEBltParms * pParms );

SCODE SourcePaint1to16( GPEBltParms * pParms );
SCODE SourcePaint4to16( GPEBltParms * pParms );
SCODE SourcePaint8to16( GPEBltParms * pParms );
SCODE SourcePaint16to16( GPEBltParms * pParms );
SCODE SourcePaint24to16( GPEBltParms * pParms );
SCODE SourcePaint32to16( GPEBltParms * pParms );

SCODE StretchSourceCopy8to16( GPEBltParms * pParms );

#define BPP16_CASE_GPEBLT( function )																					\
switch ( pParms->pSrc->Format() )																						\
{		                                                                                                                \
    case gpe1Bpp:																										\
	{																													\
		if ( pParms->pLookup != NULL &&  !(pParms->bltFlags & BLT_STRETCH))												\
		{																												\
			return function##1to16( pParms );																			\
		}																												\
	}																													\
    break;																												\
    case gpe4Bpp:																										\
	{																													\
		if ( pParms->pLookup != NULL &&  !(pParms->bltFlags & BLT_STRETCH))												\
		{																												\
			return function##4to16( pParms );																			\
		}																												\
	}																													\
    break;																												\
	case gpe8Bpp:																										\
	{																													\
		if ( pParms->pLookup != NULL )																					\
		{																												\
			return function##8to16( pParms );																			\
		}																												\
	}																													\
	break;																												\
	case gpe16Bpp:																										\
	{																													\
        if (!(pParms->bltFlags & BLT_STRETCH))																		    \
		{																												\
            return function##16to16( pParms );																			\
        }                                                                                                               \
	}																													\
	break;																												\
	case gpe24Bpp:																										\
	{																													\
        if (!(pParms->bltFlags & BLT_STRETCH))																		    \
		{																												\
		    return function##24to16( pParms );																			\
        }                                                                                                               \
	}																													\
	break;																												\
	case gpe32Bpp:																										\
	{																													\
        if (!(pParms->bltFlags & BLT_STRETCH))																		    \
		{																												\
		    return function##32to16( pParms );																			\
        }                                                                                                               \
	}																													\
	break;																												\
}
#include "16Bpp.h"

void Au12::Set16BppFunctions()
{
            m_BltFunctions.pFillRectBlt = (SCODE (GPE::*) (GPEBltParms *)) &Au12::AcceleratedFillRect16;
            m_BltFunctions.pDestInvBlt = (SCODE (GPE::*) (GPEBltParms *)) &Au12::AcceleratedDestInvert16;
            m_BltFunctions.pFillRectInvBlt = (SCODE (GPE::*) (GPEBltParms *)) &Au12::AcceleratedFillRectInvert16;
            m_BltFunctions.pSrcInvBlt = (SCODE (GPE::*)(GPEBltParms *))&Au12::AcceleratedSrcCopyBlt16;
            m_BltFunctions.pSrcAndBlt = (SCODE (GPE::*)(GPEBltParms *))&Au12::AcceleratedSrcCopyBlt16;
            m_BltFunctions.pSrcCopyBlt = (SCODE (GPE::*)(GPEBltParms *))&Au12::AcceleratedSrcCopyBlt16;
            m_BltFunctions.pSrcPaintBlt = (SCODE (GPE::*)(GPEBltParms *))&Au12::AcceleratedSrcCopyBlt16;
}

SCODE Au12::AcceleratedSrcCopyBlt16( GPEBltParms * pParms )
{
	// The BBP32 CASE will return if we're able to blit.  If not we're going to use the MS catch all blit
	switch ( pParms->rop4 )
	{
	case 0x6666:	// SRCINVERT
		{
			BPP16_CASE_GPEBLT( SourceInvert )
		}
		break;
	case 0x8888:	// SRCAND
		{
            BPP16_CASE_GPEBLT( SourceAnd )
		}
		break;
	case 0xCCCC:	// SRCCOPY
		{
			BPP16_CASE_GPEBLT( SourceCopy )
		}
		break;
	case 0xEEEE:	// SRCPAINT
		{
			BPP16_CASE_GPEBLT( SourcePaint )
		}
		break;
	default:	// error
		;		
	}

    // If we got here we couldn't handle the blit... send it back to MS
    return GPE::EmulatedBlt(pParms);
}


SCODE Au12::AcceleratedFillRect16( GPEBltParms * pParms )
{
	// BLACKNESS
	// WHITENESS
	// PATCOPY

	UINT32	target_stride	= pParms->pDst->Stride() / 2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();
	PRECTL	target_rect		= pParms->prclDst;
	WORD	color			= (WORD)pParms->solidColor;
	int		height			= target_rect->bottom - target_rect->top;
	int		width			= target_rect->right - target_rect->left;

	target += target_rect->top * target_stride + target_rect->left;

	target_stride -= width;

	for ( int j = 0; j < height; ++j )
	{
		for ( int i = 0; i < width; ++i )
		{
			*target = color;
			++target;
		}
		target += target_stride;
	}
	
	return S_OK;
}


SCODE Au12::AcceleratedFillRectInvert16( GPEBltParms * pParms )
{
	// PATINVERT

	UINT32	target_stride	= pParms->pDst->Stride() / 2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();
	PRECTL	target_rect		= pParms->prclDst;
	WORD	color			= (WORD)pParms->solidColor;
	int		height			= target_rect->bottom - target_rect->top;
	int		width			= target_rect->right - target_rect->left;

	target += target_rect->top * target_stride + target_rect->left;

	target_stride -= width;

	for ( int j = 0; j < height; ++j )
	{
		for ( int i = 0; i < width; ++i )
		{
			*target ^= color;
			++target;
		}
		target += target_stride;
	}
	
	return S_OK;
}



SCODE Au12::AcceleratedDestInvert16(GPEBltParms *pParms)
{
	// DSTINVERT

	UINT32	target_stride	= pParms->pDst->Stride() / 2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();
	PRECTL	target_rect		= pParms->prclDst;
	int		height			= target_rect->bottom - target_rect->top;
	int		width			= target_rect->right - target_rect->left;

	target += target_rect->top * target_stride + target_rect->left;

	target_stride -= width;

	for ( int j = 0; j < height; ++j )
	{
		for ( int i = 0; i < width; ++i )
		{
			*target = ~(*target);
			++target;
		}
		target += target_stride;
	}
	
	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Invert
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
SCODE SourceInvert1to16 (GPEBltParms *pParms)
{
	WORD         * pDibBitsDst      = (WORD *)pParms->pDst->Buffer();
	int            iDstScanStride   = pParms->pDst->Stride()/sizeof(WORD);
	BYTE         * pDibBitsSrc      = (BYTE *)pParms->pSrc->Buffer();
	int            iSrcScanStride   = pParms->pSrc->Stride();
	PRECTL         prcSrc           = pParms->prclSrc;
	PRECTL         prcDst           = pParms->prclDst;
	static ULONG   ulColor[2];
	int            iNumDstRows;
	int            iStartAlignment;
	int            iEndAlignment;
	int            iNumWholeDstCols;
	BYTE         * pbSrcScanLine;
	WORD         * pwDstScanLine;
	BYTE         * pbSrc;
	WORD         * pwDstPixel;
	int            i;
	int            j;
	BYTE           bSrc;

	iNumDstRows      = prcDst->bottom - prcDst->top;
	iStartAlignment  = (8 - (prcSrc->left & 0x7)) & 0x7;
	iNumWholeDstCols = (prcDst->right - prcDst->left - iStartAlignment)>>3;
	iEndAlignment    = (prcDst->right - prcDst->left - iStartAlignment) & 0x7;

	// compute pointers to the starting rows in the src and dst bitmaps
	pbSrcScanLine = pDibBitsSrc + prcSrc->top * iSrcScanStride + (prcSrc->left >> 3);
	pwDstScanLine = (WORD *)pDibBitsDst + prcDst->top * iDstScanStride + prcDst->left;

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++SourceInvert1to16")));
    
	// Create pixel values for both input colors
	for (i=0; i<2; i++) 
	{
		ulColor[i] = i;

		if (pParms->pLookup)
		{
			ulColor[i] = (pParms->pLookup)[i];
		}

		if (pParms->pConvert)
		{
			ulColor[i] = (pParms->pColorConverter->*(pParms->pConvert))( ulColor[i] );
		}
	}

	for (i = 0; i < iNumDstRows; i++) 
	{
		// set up pointers to first bytes on src and dst scanlines
		pbSrc      = pbSrcScanLine;
		pwDstPixel = pwDstScanLine;

		// do unaligned beginning
		bSrc = *pbSrc;

		switch (iStartAlignment)
		{
		case 7: *pwDstPixel++ ^= (WORD)ulColor[(bSrc>>6)&0x1];
		case 6: *pwDstPixel++ ^= (WORD)ulColor[(bSrc>>5)&0x1];
		case 5: *pwDstPixel++ ^= (WORD)ulColor[(bSrc>>4)&0x1];
		case 4: *pwDstPixel++ ^= (WORD)ulColor[(bSrc>>3)&0x1];
		case 3: *pwDstPixel++ ^= (WORD)ulColor[(bSrc>>2)&0x1];
		case 2: *pwDstPixel++ ^= (WORD)ulColor[(bSrc>>1)&0x1];
		case 1: *pwDstPixel++ ^= (WORD)ulColor[(bSrc   )&0x1];
			pbSrc++;
		}
        
		// do the main aligned loop
		for (j = 0; j < iNumWholeDstCols; j++ ) 
		{
			register bitSrc = *pbSrc;

			*(pwDstPixel+7) ^= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+6) ^= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+5) ^= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+4) ^= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+3) ^= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+2) ^= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+1) ^= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel) ^= (WORD)ulColor[bitSrc&0x1];

			pwDstPixel += 8;
			pbSrc++;
		}
        
		// 2009.11.24 Exception 'Access Violation'
		if(iEndAlignment)
		{
			// do the unaligned end
			bSrc = *pbSrc;
			switch (iEndAlignment)
			{
				case 7: *(pwDstPixel+6) ^= (WORD)ulColor[(bSrc>>1)&0x1];
				case 6: *(pwDstPixel+5) ^= (WORD)ulColor[(bSrc>>2)&0x1];
				case 5: *(pwDstPixel+4) ^= (WORD)ulColor[(bSrc>>3)&0x1];
				case 4: *(pwDstPixel+3) ^= (WORD)ulColor[(bSrc>>4)&0x1];
				case 3: *(pwDstPixel+2) ^= (WORD)ulColor[(bSrc>>5)&0x1];
				case 2: *(pwDstPixel+1) ^= (WORD)ulColor[(bSrc>>6)&0x1];
				case 1: *(pwDstPixel  ) ^= (WORD)ulColor[(bSrc>>7)&0x1];
			}
		}
        
		// advance to next scanline
		pbSrcScanLine += iSrcScanStride;
		pwDstScanLine += iDstScanStride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
SCODE SourceInvert4to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
    ULONG       ulColor[16];

	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();
    int width = target_rect->right - target_rect->left;
    int height = target_rect->bottom - target_rect->top;

    // Use these to determine which 4 bits of the byte we need at a time
    BOOL        bStartAlignment = source_rect->left & 1;
    BOOL        bAlignment;

    DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++SourceInvert4to16")));

	source += source_rect->top * source_stride + (source_rect->left >> 1); // divide left by 2 because we need only 4 bits per pixel
    target += target_rect->top * target_stride + target_rect->left;

    // Create pixel values with for all 16 src colors
	for (int i=0; i<16; i++) 
	{
		ulColor[i] = i;

		if (pParms->pLookup)
		{
			ulColor[i] = (pParms->pLookup)[i];
		}

		if (pParms->pConvert)
		{
			ulColor[i] = (pParms->pColorConverter->*(pParms->pConvert))( ulColor[i] );
		}
	}

	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}			

    // We're incrementing our pointer so we need to compensate
    source_stride -= (width >> 1);

	for ( int i = 0; i < height; ++i )
	{
        // Do we need to first half or second half of the byte?
        bAlignment = bStartAlignment;

		for ( int j = 0; j < width; ++j )
		{
            if (bAlignment)
			{
                target[j] ^= (WORD)( ulColor[ *source++ & 0xF ] );
			}
			else
			{
                target[j] ^= (WORD)( ulColor[ *source >> 4 ] );
			}

            bAlignment = !bAlignment;

			
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

SCODE SourceInvert8to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Invert8to16")));

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
			target[j] ^= (WORD)( pParms->pLookup[ source[j] ] );
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourceInvert16to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride()/2;
	WORD*	source			= (WORD*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Invert16to16")));
	
	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
            if (pParms->pConvert) {
                target[j] ^= (WORD) (pParms->pColorConverter->*(pParms->pConvert))( source[j] );
            }
            else {
                target[j] ^= source[j];
            }
//			target[j] ^= source[j];
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourceInvert24to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left * 3;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Invert24to16")));

	// Because we're incrementing this pointer we need to adjust for the extra width
	source_stride -= width * 3;

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
//			target[j] ^= (WORD)( ((*source & 0xF8) >> 3) | ( ( *(source+1) & 0xFC ) << 3) | ( ( *(source+2) & 0xF8 ) << 8) );
            target[j] ^= (WORD) (pParms->pColorConverter->*(pParms->pConvert))( (*source | *(source + 1) << 8 | *(source + 2) << 16) );
				
			source += 3;
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourceInvert32to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride()/4;
	DWORD*	source			= (DWORD*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Invert32to16")));

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
//			target[j] ^= (WORD)(( ( source[j] & 0xFF0000 ) >> 5 ) | ( ( source[j] & 0x00FF00 ) >> 3 ) | ( ( source[j] & 0x0000FF ) ));
            target[j] ^= (WORD) (pParms->pColorConverter->*(pParms->pConvert))( source[j] );
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// And
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
SCODE SourceAnd1to16 (GPEBltParms *pParms)
{
	WORD         * pDibBitsDst      = (WORD *)pParms->pDst->Buffer();
	int            iDstScanStride   = pParms->pDst->Stride()/sizeof(WORD);
	BYTE         * pDibBitsSrc      = (BYTE *)pParms->pSrc->Buffer();
	int            iSrcScanStride   = pParms->pSrc->Stride();
	PRECTL         prcSrc           = pParms->prclSrc;
	PRECTL         prcDst           = pParms->prclDst;
	static ULONG   ulColor[2];
	int            iNumDstRows;
	int            iStartAlignment;
	int            iEndAlignment;
	int            iNumWholeDstCols;
	BYTE         * pbSrcScanLine;
	WORD         * pwDstScanLine;
	BYTE         * pbSrc;
	WORD         * pwDstPixel;
	int            i;
	int            j;
	BYTE           bSrc;

	iNumDstRows      = prcDst->bottom - prcDst->top;
	iStartAlignment  = (8 - (prcSrc->left & 0x7)) & 0x7;
	iNumWholeDstCols = (prcDst->right - prcDst->left - iStartAlignment)>>3;
	iEndAlignment    = (prcDst->right - prcDst->left - iStartAlignment) & 0x7;

	// compute pointers to the starting rows in the src and dst bitmaps
	pbSrcScanLine = pDibBitsSrc + prcSrc->top * iSrcScanStride + (prcSrc->left >> 3);
	pwDstScanLine = (WORD *)pDibBitsDst + prcDst->top * iDstScanStride + prcDst->left;

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++SourceAnd1to16")));
    
	// Create pixel values for both input colors
	for (i=0; i<2; i++) 
	{
		ulColor[i] = i;

		if (pParms->pLookup)
		{
			ulColor[i] = (pParms->pLookup)[i];
		}

		if (pParms->pConvert)
		{
			ulColor[i] = (pParms->pColorConverter->*(pParms->pConvert))( ulColor[i] );
		}
	}

	for (i = 0; i < iNumDstRows; i++) 
	{
		// set up pointers to first bytes on src and dst scanlines
		pbSrc      = pbSrcScanLine;
		pwDstPixel = pwDstScanLine;

		// do unaligned beginning
		bSrc = *pbSrc;

		switch (iStartAlignment)
		{
		case 7: *pwDstPixel++ &= (WORD)ulColor[(bSrc>>6)&0x1];
		case 6: *pwDstPixel++ &= (WORD)ulColor[(bSrc>>5)&0x1];
		case 5: *pwDstPixel++ &= (WORD)ulColor[(bSrc>>4)&0x1];
		case 4: *pwDstPixel++ &= (WORD)ulColor[(bSrc>>3)&0x1];
		case 3: *pwDstPixel++ &= (WORD)ulColor[(bSrc>>2)&0x1];
		case 2: *pwDstPixel++ &= (WORD)ulColor[(bSrc>>1)&0x1];
		case 1: *pwDstPixel++ &= (WORD)ulColor[(bSrc   )&0x1];
			pbSrc++;
		}
        
		// do the main aligned loop
		for (j = 0; j < iNumWholeDstCols; j++ ) 
		{
			register bitSrc = *pbSrc;

			*(pwDstPixel+7) &= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+6) &= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+5) &= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+4) &= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+3) &= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+2) &= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+1) &= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel) &= (WORD)ulColor[bitSrc&0x1];

			pwDstPixel += 8;
			pbSrc++;
		}
        
		// 2009.11.24 Exception 'Access Violation'
		if(iEndAlignment)
		{
			// do the unaligned end
			bSrc = *pbSrc;
			switch (iEndAlignment)
			{
				case 7: *(pwDstPixel+6) &= (WORD)ulColor[(bSrc>>1)&0x1];
				case 6: *(pwDstPixel+5) &= (WORD)ulColor[(bSrc>>2)&0x1];
				case 5: *(pwDstPixel+4) &= (WORD)ulColor[(bSrc>>3)&0x1];
				case 4: *(pwDstPixel+3) &= (WORD)ulColor[(bSrc>>4)&0x1];
				case 3: *(pwDstPixel+2) &= (WORD)ulColor[(bSrc>>5)&0x1];
				case 2: *(pwDstPixel+1) &= (WORD)ulColor[(bSrc>>6)&0x1];
				case 1: *(pwDstPixel  ) &= (WORD)ulColor[(bSrc>>7)&0x1];
			}
		}
        
		// advance to next scanline
		pbSrcScanLine += iSrcScanStride;
		pwDstScanLine += iDstScanStride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
SCODE SourceAnd4to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
    ULONG       ulColor[16];

	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();
    int width = target_rect->right - target_rect->left;
    int height = target_rect->bottom - target_rect->top;

    // Use these to determine which 4 bits of the byte we need at a time
    BOOL        bStartAlignment = source_rect->left & 1;
    BOOL        bAlignment;

    DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++SourceAnd4to16")));

	source += source_rect->top * source_stride + (source_rect->left >> 1); // divide left by 2 because we need only 4 bits per pixel
    target += target_rect->top * target_stride + target_rect->left;

    // Create pixel values with for all 16 src colors
	for (int i=0; i<16; i++) 
	{
		ulColor[i] = i;

		if (pParms->pLookup)
		{
			ulColor[i] = (pParms->pLookup)[i];
		}

		if (pParms->pConvert)
		{
			ulColor[i] = (pParms->pColorConverter->*(pParms->pConvert))( ulColor[i] );
		}
	}

	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}			

    // We're incrementing our pointer so we need to compensate
    source_stride -= (width >> 1);

	for ( int i = 0; i < height; ++i )
	{
        // Do we need to first half or second half of the byte?
        bAlignment = bStartAlignment;

		for ( int j = 0; j < width; ++j )
		{
            if (bAlignment)
			{
                target[j] &= (WORD)( ulColor[ *source++ & 0xF ] );
			}
			else
			{
                target[j] &= (WORD)( ulColor[ *source >> 4 ] );
			}

            bAlignment = !bAlignment;

			
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

SCODE SourceAnd8to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++And8to16")));

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
			target[j] &= (WORD)( pParms->pLookup[ source[j] ] );
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourceAnd16to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride()/2;
	WORD*	source			= (WORD*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++And16to16")));
	
	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
            if (pParms->pConvert) {
                target[j] &= (WORD) (pParms->pColorConverter->*(pParms->pConvert))( source[j] );
            }
            else {
                target[j] &= source[j];
            }
//			target[j] &= source[j];
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourceAnd24to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left * 3;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++And24to16")));

	// Because we're incrementing this pointer we need to adjust for the extra width
	source_stride -= width * 3;

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
//			target[j] &= (WORD)( ((*source & 0xF8) >> 3) | ( ( *(source+1) & 0xFC ) << 3) | ( ( *(source+2) & 0xF8 ) << 8) );
            target[j] &= (WORD) (pParms->pColorConverter->*(pParms->pConvert))( (*source | *(source + 1) << 8 | *(source + 2) << 16) );
				
			source += 3;
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourceAnd32to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride()/4;
	DWORD*	source			= (DWORD*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++And32to16")));

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
//			target[j] &= (WORD)(( ( source[j] & 0xFF0000 ) >> 5 ) | ( ( source[j] & 0x00FF00 ) >> 3 ) | ( ( source[j] & 0x0000FF ) ));
            target[j] &= (WORD) (pParms->pColorConverter->*(pParms->pConvert))( source[j] );
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// And
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
SCODE SourceCopy1to16 (GPEBltParms *pParms)
{
	WORD         * pDibBitsDst      = (WORD *)pParms->pDst->Buffer();
	int            iDstScanStride   = pParms->pDst->Stride()/sizeof(WORD);
	BYTE         * pDibBitsSrc      = (BYTE *)pParms->pSrc->Buffer();
	int            iSrcScanStride   = pParms->pSrc->Stride();
	PRECTL         prcSrc           = pParms->prclSrc;
	PRECTL         prcDst           = pParms->prclDst;
	static ULONG   ulColor[2];
	int            iNumDstRows;
	int            iStartAlignment;
	int            iEndAlignment;
	int            iNumWholeDstCols;
	BYTE         * pbSrcScanLine;
	WORD         * pwDstScanLine;
	BYTE         * pbSrc;
	WORD         * pwDstPixel;
	int            i;
	int            j;
	BYTE           bSrc;

	iNumDstRows      = prcDst->bottom - prcDst->top;
	iStartAlignment  = (8 - (prcSrc->left & 0x7)) & 0x7;
	iNumWholeDstCols = (prcDst->right - prcDst->left - iStartAlignment)>>3;
	iEndAlignment    = (prcDst->right - prcDst->left - iStartAlignment) & 0x7;

	// compute pointers to the starting rows in the src and dst bitmaps
	pbSrcScanLine = pDibBitsSrc + prcSrc->top * iSrcScanStride + (prcSrc->left >> 3);
	pwDstScanLine = (WORD *)pDibBitsDst + prcDst->top * iDstScanStride + prcDst->left;

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++SourceCopy1to16")));
    
	// Create pixel values for both input colors
	for (i=0; i<2; i++) 
	{
		ulColor[i] = i;

		if (pParms->pLookup)
		{
			ulColor[i] = (pParms->pLookup)[i];
		}

		if (pParms->pConvert)
		{
			ulColor[i] = (pParms->pColorConverter->*(pParms->pConvert))( ulColor[i] );
		}
	}

	for (i = 0; i < iNumDstRows; i++) 
	{
		// set up pointers to first bytes on src and dst scanlines
		pbSrc      = pbSrcScanLine;
		pwDstPixel = pwDstScanLine;

		// do unaligned beginning
		bSrc = *pbSrc;

		switch (iStartAlignment)
		{
		case 7: *pwDstPixel++ = (WORD)ulColor[(bSrc>>6)&0x1];
		case 6: *pwDstPixel++ = (WORD)ulColor[(bSrc>>5)&0x1];
		case 5: *pwDstPixel++ = (WORD)ulColor[(bSrc>>4)&0x1];
		case 4: *pwDstPixel++ = (WORD)ulColor[(bSrc>>3)&0x1];
		case 3: *pwDstPixel++ = (WORD)ulColor[(bSrc>>2)&0x1];
		case 2: *pwDstPixel++ = (WORD)ulColor[(bSrc>>1)&0x1];
		case 1: *pwDstPixel++ = (WORD)ulColor[(bSrc   )&0x1];
			pbSrc++;
		}
        
		// do the main aligned loop
		for (j = 0; j < iNumWholeDstCols; j++ ) 
		{
			register bitSrc = *pbSrc;

			*(pwDstPixel+7) = (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+6) = (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+5) = (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+4) = (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+3) = (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+2) = (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+1) = (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel) = (WORD)ulColor[bitSrc&0x1];

			pwDstPixel += 8;
			pbSrc++;
		}
        
		// 2009.11.24 Exception 'Access Violation'
		if(iEndAlignment)
		{
			// do the unaligned end
			bSrc = *pbSrc;
			switch (iEndAlignment)
			{
				case 7: *(pwDstPixel+6) = (WORD)ulColor[(bSrc>>1)&0x1];
				case 6: *(pwDstPixel+5) = (WORD)ulColor[(bSrc>>2)&0x1];
				case 5: *(pwDstPixel+4) = (WORD)ulColor[(bSrc>>3)&0x1];
				case 4: *(pwDstPixel+3) = (WORD)ulColor[(bSrc>>4)&0x1];
				case 3: *(pwDstPixel+2) = (WORD)ulColor[(bSrc>>5)&0x1];
				case 2: *(pwDstPixel+1) = (WORD)ulColor[(bSrc>>6)&0x1];
				case 1: *(pwDstPixel  ) = (WORD)ulColor[(bSrc>>7)&0x1];
			}
		}
        
		// advance to next scanline
		pbSrcScanLine += iSrcScanStride;
		pwDstScanLine += iDstScanStride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
SCODE SourceCopy4to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
    ULONG       ulColor[16];

	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();
    int width = target_rect->right - target_rect->left;
    int height = target_rect->bottom - target_rect->top;

    // Use these to determine which 4 bits of the byte we need at a time
    BOOL        bStartAlignment = source_rect->left & 1;
    BOOL        bAlignment;

    DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++SourceCopy4to16")));

	source += source_rect->top * source_stride + (source_rect->left >> 1); // divide left by 2 because we need only 4 bits per pixel
    target += target_rect->top * target_stride + target_rect->left;

    // Create pixel values with for all 16 src colors
	for (int i=0; i<16; i++) 
	{
		ulColor[i] = i;

		if (pParms->pLookup)
		{
			ulColor[i] = (pParms->pLookup)[i];
		}

		if (pParms->pConvert)
		{
			ulColor[i] = (pParms->pColorConverter->*(pParms->pConvert))( ulColor[i] );
		}
	}

	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}			

    // We're incrementing our pointer so we need to compensate
    source_stride -= (width >> 1);

	for ( int i = 0; i < height; ++i )
	{
        // Do we need to first half or second half of the byte?
        bAlignment = bStartAlignment;

		for ( int j = 0; j < width; ++j )
		{
            if (bAlignment)
			{
                target[j] = (WORD)( ulColor[ *source++ & 0xF ] );
			}
			else
			{
                target[j] = (WORD)( ulColor[ *source >> 4 ] );
			}

            bAlignment = !bAlignment;

			
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

SCODE SourceCopy8to16( GPEBltParms * pParms )
{
    // Handle stretch blits somewhere else
    if ( pParms->bltFlags & BLT_STRETCH )
    {
        return StretchSourceCopy8to16( pParms );
    }

	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Copy8to16")));

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
			// WE HAVE TO PROVIDE A MECHANISM FOR COLOR CONVERTING!!!!!!!
            if (pParms->pConvert) 
            {
				target[j] = (WORD)(pParms->pColorConverter->*(pParms->pConvert))( source[j] );

            }
			else if (pParms->pLookup)
            {
				target[j] = (WORD)(pParms->pLookup)[source[j]];
            }
			else
            {
				target[j] = source[j];
			}
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourceCopy16to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride()/2;
	WORD*	source			= (WORD*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Copy16to16")));
	
  if (pParms->pConvert)
  {
	 for ( int i = 0; i < height; ++i )
	 {
		for ( int j = 0; j < width; ++j )
		{
      // WE HAVE TO PROVIDE A MECHANISM FOR COLOR CONVERTING!!!!!!!
			target[j] = (WORD) (pParms->pColorConverter->*(pParms->pConvert))( source[j] );			
		}
		target = target + target_stride;
		source = source + source_stride;
	 }
  }
  else
  {
    for ( int i = 0; i < height; ++i )
    {
      memcpy(target, source, width*2);
      target = target + target_stride;
      source = source + source_stride;
    }
  }

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourceCopy24to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left * 3;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Copy24to16")));

	// Because we're incrementing this pointer we need to adjust for the extra width
	source_stride -= width * 3;

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
//			target[j] = (WORD)( ((*source & 0xF8) >> 3) | ( ( *(source+1) & 0xFC ) << 3) | ( ( *(source+2) & 0xF8 ) << 8) );
            target[j] = (WORD) (pParms->pColorConverter->*(pParms->pConvert))( (*source | *(source + 1) << 8 | *(source + 2) << 16) );
				
			source += 3;
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourceCopy32to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride()/4;
	DWORD*	source			= (DWORD*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Copy32to16")));

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
			int pix = source[j];
			target[j] = (WORD)( (( pix & 0xf80000 )>>8)| ((pix & 0xFC00)>>5) | ((pix & 0xF8) >> 3));
//			target[j] = (WORD)(( ( source[j] & 0xFF0000 ) >> 5 ) | ( ( source[j] & 0x00FF00 ) >> 3 ) | ( ( source[j] & 0x0000FF ) ));
//            target[j] = (WORD) (pParms->pColorConverter->*(pParms->pConvert))( source[j] );
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Paint
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
SCODE SourcePaint1to16 (GPEBltParms *pParms)
{
	WORD         * pDibBitsDst      = (WORD *)pParms->pDst->Buffer();
	int            iDstScanStride   = pParms->pDst->Stride()/sizeof(WORD);
	BYTE         * pDibBitsSrc      = (BYTE *)pParms->pSrc->Buffer();
	int            iSrcScanStride   = pParms->pSrc->Stride();
	PRECTL         prcSrc           = pParms->prclSrc;
	PRECTL         prcDst           = pParms->prclDst;
	static ULONG   ulColor[2];
	int            iNumDstRows;
	int            iStartAlignment;
	int            iEndAlignment;
	int            iNumWholeDstCols;
	BYTE         * pbSrcScanLine;
	WORD         * pwDstScanLine;
	BYTE         * pbSrc;
	WORD         * pwDstPixel;
	int            i;
	int            j;
	BYTE           bSrc;

	iNumDstRows      = prcDst->bottom - prcDst->top;
	iStartAlignment  = (8 - (prcSrc->left & 0x7)) & 0x7;
	iNumWholeDstCols = (prcDst->right - prcDst->left - iStartAlignment)>>3;
	iEndAlignment    = (prcDst->right - prcDst->left - iStartAlignment) & 0x7;

	// compute pointers to the starting rows in the src and dst bitmaps
	pbSrcScanLine = pDibBitsSrc + prcSrc->top * iSrcScanStride + (prcSrc->left >> 3);
	pwDstScanLine = (WORD *)pDibBitsDst + prcDst->top * iDstScanStride + prcDst->left;

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++SourcePaint1to16")));
    
	// Create pixel values for both input colors
	for (i=0; i<2; i++) 
	{
		ulColor[i] = i;

		if (pParms->pLookup)
		{
			ulColor[i] = (pParms->pLookup)[i];
		}

		if (pParms->pConvert)
		{
			ulColor[i] = (pParms->pColorConverter->*(pParms->pConvert))( ulColor[i] );
		}
	}

	for (i = 0; i < iNumDstRows; i++) 
	{
		// set up pointers to first bytes on src and dst scanlines
		pbSrc      = pbSrcScanLine;
		pwDstPixel = pwDstScanLine;

		// do unaligned beginning
		bSrc = *pbSrc;

		switch (iStartAlignment)
		{
		case 7: *pwDstPixel++ |= (WORD)ulColor[(bSrc>>6)&0x1];
		case 6: *pwDstPixel++ |= (WORD)ulColor[(bSrc>>5)&0x1];
		case 5: *pwDstPixel++ |= (WORD)ulColor[(bSrc>>4)&0x1];
		case 4: *pwDstPixel++ |= (WORD)ulColor[(bSrc>>3)&0x1];
		case 3: *pwDstPixel++ |= (WORD)ulColor[(bSrc>>2)&0x1];
		case 2: *pwDstPixel++ |= (WORD)ulColor[(bSrc>>1)&0x1];
		case 1: *pwDstPixel++ |= (WORD)ulColor[(bSrc   )&0x1];
			pbSrc++;
		}
        
		// do the main aligned loop
		for (j = 0; j < iNumWholeDstCols; j++ ) 
		{
			register bitSrc = *pbSrc;

			*(pwDstPixel+7) |= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+6) |= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+5) |= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+4) |= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+3) |= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+2) |= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel+1) |= (WORD)ulColor[bitSrc&0x1];
			bitSrc = bitSrc>>1;
			*(pwDstPixel) |= (WORD)ulColor[bitSrc&0x1];

			pwDstPixel += 8;
			pbSrc++;
		}
        

		// 2009.11.24 Exception 'Access Violation'
		if(iEndAlignment)
		{
			// do the unaligned end
			bSrc = *pbSrc;
			switch (iEndAlignment)
			{
				case 7: *(pwDstPixel+6) |= (WORD)ulColor[(bSrc>>1)&0x1];
				case 6: *(pwDstPixel+5) |= (WORD)ulColor[(bSrc>>2)&0x1];
				case 5: *(pwDstPixel+4) |= (WORD)ulColor[(bSrc>>3)&0x1];
				case 4: *(pwDstPixel+3) |= (WORD)ulColor[(bSrc>>4)&0x1];
				case 3: *(pwDstPixel+2) |= (WORD)ulColor[(bSrc>>5)&0x1];
				case 2: *(pwDstPixel+1) |= (WORD)ulColor[(bSrc>>6)&0x1];
				case 1: *(pwDstPixel  ) |= (WORD)ulColor[(bSrc>>7)&0x1];
			}
		}
        
		// advance to next scanline
		pbSrcScanLine += iSrcScanStride;
		pwDstScanLine += iDstScanStride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
SCODE SourcePaint4to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
    ULONG       ulColor[16];

	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();
    int width = target_rect->right - target_rect->left;
    int height = target_rect->bottom - target_rect->top;

    // Use these to determine which 4 bits of the byte we need at a time
    BOOL        bStartAlignment = source_rect->left & 1;
    BOOL        bAlignment;

    DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++SourcePaint4to16")));

	source += source_rect->top * source_stride + (source_rect->left >> 1); // divide left by 2 because we need only 4 bits per pixel
    target += target_rect->top * target_stride + target_rect->left;

    // Create pixel values with for all 16 src colors
	for (int i=0; i<16; i++) 
	{
		ulColor[i] = i;

		if (pParms->pLookup)
		{
			ulColor[i] = (pParms->pLookup)[i];
		}

		if (pParms->pConvert)
		{
			ulColor[i] = (pParms->pColorConverter->*(pParms->pConvert))( ulColor[i] );
		}
	}

	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}			

    // We're incrementing our pointer so we need to compensate
    source_stride -= (width >> 1);

	for ( int i = 0; i < height; ++i )
	{
        // Do we need to first half or second half of the byte?
        bAlignment = bStartAlignment;

		for ( int j = 0; j < width; ++j )
		{
            if (bAlignment)
			{
                target[j] |= (WORD)( ulColor[ *source++ & 0xF ] );
			}
			else
			{
                target[j] |= (WORD)( ulColor[ *source >> 4 ] );
			}

            bAlignment = !bAlignment;

			
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

SCODE SourcePaint8to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Paint8to16")));

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
			target[j] |= (WORD)( pParms->pLookup[ source[j] ] );
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourcePaint16to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride()/2;
	WORD*	source			= (WORD*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Paint16to16")));
	
	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
			if (pParms->pConvert) {
                target[j] |= (WORD) (pParms->pColorConverter->*(pParms->pConvert))( source[j] );
            }
            else {
                target[j] |= source[j];
            }
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourcePaint24to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride();
	BYTE*	source			= (BYTE*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left * 3;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Paint24to16")));

	// Because we're incrementing this pointer we need to adjust for the extra width
	source_stride -= width * 3;

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
//			target[j] |= (WORD)( ((*source & 0xF8) >> 3) | ( ( *(source+1) & 0xFC ) << 3) | ( ( *(source+2) & 0xF8 ) << 8) );
            target[j] |= (WORD) (pParms->pColorConverter->*(pParms->pConvert))( (*source | *(source + 1) << 8 | *(source + 2) << 16) );
				
			source += 3;
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
SCODE SourcePaint32to16( GPEBltParms * pParms )
{
	// Source-related info
	PRECTL	source_rect		= pParms->prclSrc;
	int		source_stride	= pParms->pSrc->Stride()/4;
	DWORD*	source			= (DWORD*)pParms->pSrc->Buffer();
		
	// Dest-related info
	PRECTL	target_rect		= pParms->prclDst;
	int		target_stride	= pParms->pDst->Stride()/2;
	WORD*	target			= (WORD*)pParms->pDst->Buffer();

	int width = target_rect->right - target_rect->left;
	int height = target_rect->bottom - target_rect->top;

	source += source_rect->top * source_stride + source_rect->left;
	
	target += target_rect->top * target_stride + target_rect->left;


	// Make sure to copy source before overwriting.
	if (!pParms->yPositive)
	{
		// Scan from end of memory, and negate stride
		source += source_stride * ( height - 1 );
		target += target_stride * ( height - 1 );

		source_stride = -source_stride;
		target_stride = -target_stride;
	}

	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++Paint32to16")));

	for ( int i = 0; i < height; ++i )
	{
		for ( int j = 0; j < width; ++j )
		{
//			target[j] |= (WORD)(( ( source[j] & 0xFF0000 ) >> 5 ) | ( ( source[j] & 0x00FF00 ) >> 3 ) | ( ( source[j] & 0x0000FF ) ));
            target[j] |= (WORD) (pParms->pColorConverter->*(pParms->pConvert))( source[j] );
		}

		target = target + target_stride;
		source = source + source_stride;
	}

	return S_OK;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Streching Source Copy
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// 
///////////////////////////////////////////////////////////////////////////////
SCODE StretchSourceCopy8to16( GPEBltParms * pParms )
{

	WORD       * pDibBitsDst     = (WORD *)pParms->pDst->Buffer();
	int          iDstScanStride  = pParms->pDst->Stride()/2;
	BYTE       * pDibBitsSrc     = (BYTE *)pParms->pSrc->Buffer();
	int          iSrcScanStride  = pParms->pSrc->Stride();
	PRECTL       prcSrc          = pParms->prclSrc;
	PRECTL       prcDst          = pParms->prclDst;
	int          dstWidth;
	int          dstHeight;
	int          srcWidth;
	int          srcHeight;
	BYTE       * pbSrcScanLine;
	WORD       * pwDstScanLine;
	BYTE       * pbSrc;
	WORD       * pwDstPixel;
	int          y;
	int          x;
	BYTE         bSrc;

	// Stretching and shrinking Vars
	int xShrinkStretch = 0;
    int xShrink=0;
    int xStretch=0;
    int yShrinkStretch = 0;
    int yShrink=0;
    int yStretch=0;

    int rowXAccum, xAccum, xDMajor, xDMinor;    // only valid if xShrinkStretch
    int yAccum, yDMajor, yDMinor;               // only valid if yShrinkStretch

	// RECT clipping Vars
	int dstXStartSkip = 0;    // Number of dst pixels to not write (left if dstXPositive else right)
    int dstYStartSkip = 0;    // Number of rows to ignore (top if dstYPositive)
	int srcXStartSkip = 0;    // Number of dst pixels to not write (left if dstXPositive else right)
    int srcYStartSkip = 0;    // Number of rows to ignore (top if dstYPositive)


	DEBUGMSG(GPE_ZONE_BLT_HI, (TEXT("++StretchSourceCopy8to32")));

	// Caller assures a well-ordered, non-empty rect
	// compute size of destination rect
	dstWidth = prcDst->right  - prcDst->left;
	dstHeight = prcDst->bottom - prcDst->top;
	srcWidth = prcSrc->right  - prcSrc->left;
	srcHeight = prcSrc->bottom - prcSrc->top;

	// Setup X Stretching
	if( dstWidth > srcWidth )
    {
        xStretch = 1;
        xDMajor = dstWidth ;
        xDMinor = srcWidth;
    }
    else if( dstWidth < srcWidth )
    {
        xShrink = 1;
        xDMajor = srcWidth;
        xDMinor = dstWidth ;
    }

    if( xStretch || xShrink)
    {
        xShrinkStretch = 1;
        // Convert to Bresenham parameters
        xDMinor *= 2;
        xDMajor = xDMinor - 2 * xDMajor;
        rowXAccum = xShrink?(2*dstWidth  - srcWidth):(3*srcWidth - 2*dstWidth );
            // loaded into xAccum at start of each row
    }

// Setup Y Stretching	
	if( dstHeight > srcHeight )
    {
        yStretch = 1;
        yDMajor = dstHeight;
        yDMinor = srcHeight;
    }
    else if( dstHeight < srcHeight )
    {
        yShrink = 1;
        yDMajor = srcHeight;
        yDMinor = dstHeight;
    }

    if( yStretch || yShrink)
    {
        yShrinkStretch = 1;
        // Convert to Bresenham parameters
        yDMinor *= 2;
        yDMajor = yDMinor - 2 * yDMajor;
        yAccum = yShrink?(2*dstHeight - srcHeight):(3*srcHeight - 2*dstHeight);
    }

	// Setup Clipping
	if( pParms->prclClip )    // ONLY happens if stretch blting
    {
        RECTL rclClipped = *prcDst;

        if( rclClipped.left < pParms->prclClip->left )
        {
            rclClipped.left = pParms->prclClip->left;
        }
        if( rclClipped.top < pParms->prclClip->top )
        {
            rclClipped.top = pParms->prclClip->top;
        }
        if( rclClipped.bottom > pParms->prclClip->bottom )
        {
            rclClipped.bottom = pParms->prclClip->bottom;
        }
        if( rclClipped.right > pParms->prclClip->right )
        {
            rclClipped.right = pParms->prclClip->right;
        }
        if( rclClipped.right <= rclClipped.left || rclClipped.bottom <= rclClipped.top )
        {
            return S_OK;    // the clipping left nothing to do
        }

        dstXStartSkip = rclClipped.left - prcDst->left;
        dstYStartSkip = rclClipped.top - prcDst->top;
        dstWidth = rclClipped.right - rclClipped.left;        // Calculate fully clipped destination width
        dstHeight = rclClipped.bottom - rclClipped.top;    // Fully clipped height
    }


	// need to skip some of the source due to clipping... figure out where to start.
	if( xStretch )
    {
		for( int skipCount = dstXStartSkip; skipCount; skipCount-- )    
        {
            if( rowXAccum < 0 )
            {
                rowXAccum += xDMinor;
            }
            else
            {
                rowXAccum += xDMajor;
                srcXStartSkip++;
            }
        }

    }

	if( yStretch )
    {
        for( int skipCount = dstYStartSkip; skipCount; skipCount-- )
        {
            if( yAccum < 0 )
            {
                yAccum += yDMinor;
            }
            else
            {
                yAccum += yDMajor;
                srcYStartSkip++;
            }
        }
    }

	// compute pointers to the starting rows in the src and dst bitmaps
	pbSrcScanLine = pDibBitsSrc + (prcSrc->top + srcYStartSkip) * iSrcScanStride + prcSrc->left;
	pwDstScanLine = (WORD *)pDibBitsDst + (prcDst->top + dstYStartSkip) * iDstScanStride + prcDst->left;

	for (y = 0; y < dstHeight; y++) 
	{

		xAccum = rowXAccum;

		// set up pointers to first bytes on src and dst scanlines
		pbSrc      = pbSrcScanLine;
		pwDstPixel = pwDstScanLine;

		for (x = 0; x < dstWidth; x++ ) 
		{
            if( xShrinkStretch )
            {
    			// Handle x Stretching
    			if( xStretch )
    			{
    				bSrc = *pbSrc;
    
    				*pwDstPixel = (WORD)(pParms->pLookup)[bSrc];
    
    				if( xAccum < 0 )    // Repeat this pixel
    				{
    					xAccum += xDMinor;
    				}
    				else                // OK to move to next source pixel after this
    				{
    					xAccum += xDMajor;
    					*pbSrc++;
    				}
    			}
    			else    // xShrink
                {
                    while( xAccum < 0 )        // Skip pixel(s)
                    {
                        bSrc++;
                        xAccum += xDMinor;
                    }
    
                    // set this pixel
					bSrc = *pbSrc;
                    *pwDstPixel = (WORD)(pParms->pLookup)[bSrc];
                    *pbSrc++;
                    xAccum += xDMajor;
                }
            }
            else
            {
				bSrc = *pbSrc;
                *pwDstPixel = (WORD)(pParms->pLookup)[bSrc];
                *pbSrc++;

            }

			
			pwDstPixel++;
		}

		
        if ( yShrinkStretch ) 
        {
            if( yShrink )
            {
                while( yAccum < 0 )    // skip source line(s) if shrinking
                {
                    pbSrcScanLine += iSrcScanStride;
                    yAccum += yDMinor;
                }
                pbSrcScanLine += iSrcScanStride;
                yAccum += yDMajor;
            }
            else // Handle y stretching
            {
                
                if( yAccum < 0)
                {
                    // repeat source line if stretching
                    yAccum            += yDMinor;    // yDMinor is a small +ve number
                }
                else
                {
                    // Switch to next source line after this
                    yAccum            += yDMajor;              // yDMajor is a large -ve value (i.e. |yDMajor| > |yDMinor| )
    				pbSrcScanLine += iSrcScanStride;
                }
              
            }
        }
        else
        {
            pbSrcScanLine += iSrcScanStride;
        }

		// advance to next scanline
		pwDstScanLine += iDstScanStride;
	}

	return S_OK;
}
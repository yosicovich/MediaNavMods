#include "precomp.h"

#define EDID_SAMPLE    0


extern "C"
{
#include <smbus.h>
}


#if EDID_SAMPLE
	#pragma warning(disable: 4309)
	static char edid_sample[] =
	{
	    0x00,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x00,0x22,0x64,0x0B,0x19,0x48,0x07,0x00,0x00,
	    0x2A,0x12,0x01,0x03,0x80,0x3B,0x25,0x78,0xEA,0x9E,0x71,0xA6,0x54,0x4C,0x9F,0x24,
	    0x10,0x51,0x57,0xBF,0xEF,0x80,0xD1,0x00,0xB3,0x00,0xA9,0x40,0x95,0x00,0x90,0x40,
	    0x81,0x80,0x81,0x40,0x71,0x4F,0x28,0x3C,0x80,0xA0,0x70,0xB0,0x23,0x40,0x30,0x20,
	    0x36,0x00,0x62,0x5E,0x21,0x00,0x00,0x1A,0x00,0x00,0x00,0xFF,0x00,0x31,0x38,0x36,
	    0x34,0x0A,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x00,0x00,0x00,0xFD,0x00,0x38,
	    0x4B,0x18,0x50,0x0F,0x00,0x0A,0x20,0x20,0x20,0x20,0x20,0x20,0x00,0x00,0x00,0xFC,
	    0x00,0x48,0x46,0x32,0x38,0x39,0x48,0x0A,0x20,0x20,0x20,0x20,0x20,0x20,0x01,0xD4
	};
	#pragma warning(default: 4309)  // disable warning for "no return value"
#endif



#define UPPER_NIBBLE( x ) \
        (((128|64|32|16) & (x)) >> 4)

#define LOWER_NIBBLE( x ) \
        ((1|2|4|8) & (x))

#define COMBINE_HI_8LO( hi, lo ) \
        ( (((unsigned)hi) << 8) | (unsigned)lo )

#define COMBINE_HI_4LO( hi, lo ) \
        ( (((unsigned)hi) << 4) | (unsigned)lo )

const unsigned char edid_v1_header[] = { 0x00, 0xff, 0xff, 0xff,
                                       0xff, 0xff, 0xff, 0x00
                                       };

const unsigned char edid_v1_descriptor_flag[] = { 0x00, 0x00 };


#define EDID_LENGTH                             0x80

#define EDID_HEADER                             0x00
#define EDID_HEADER_END                         0x07

#define ID_MANUFACTURER_NAME                    0x08
#define ID_MANUFACTURER_NAME_END                0x09
#define ID_MODEL								0x0a

#define ID_SERIAL_NUMBER						0x0c

#define MANUFACTURE_WEEK						0x10
#define MANUFACTURE_YEAR						0x11

#define EDID_STRUCT_VERSION                     0x12
#define EDID_STRUCT_REVISION                    0x13

#define DPMS_FLAGS								0x18
#define ESTABLISHED_TIMING_1                    0x23
#define ESTABLISHED_TIMING_2                    0x24
#define MANUFACTURERS_TIMINGS                   0x25

#define DETAILED_TIMING_DESCRIPTIONS_START      0x36
#define DETAILED_TIMING_DESCRIPTION_SIZE        18
#define NO_DETAILED_TIMING_DESCRIPTIONS         4



#define DETAILED_TIMING_DESCRIPTION_1           0x36
#define DETAILED_TIMING_DESCRIPTION_2           0x48
#define DETAILED_TIMING_DESCRIPTION_3           0x5a
#define DETAILED_TIMING_DESCRIPTION_4           0x6c



#define PIXEL_CLOCK_LO     (unsigned)dtd[ 0 ]
#define PIXEL_CLOCK_HI     (unsigned)dtd[ 1 ]
#define PIXEL_CLOCK        (COMBINE_HI_8LO( PIXEL_CLOCK_HI,PIXEL_CLOCK_LO )*10000)

#define H_ACTIVE_LO        (unsigned)dtd[ 2 ]

#define H_BLANKING_LO      (unsigned)dtd[ 3 ]

#define H_ACTIVE_HI        UPPER_NIBBLE( (unsigned)dtd[ 4 ] )

#define H_ACTIVE           COMBINE_HI_8LO( H_ACTIVE_HI, H_ACTIVE_LO )

#define H_BLANKING_HI      LOWER_NIBBLE( (unsigned)dtd[ 4 ] )

#define H_BLANKING         COMBINE_HI_8LO( H_BLANKING_HI, H_BLANKING_LO )




#define V_ACTIVE_LO        (unsigned)dtd[ 5 ]

#define V_BLANKING_LO      (unsigned)dtd[ 6 ]

#define V_ACTIVE_HI        UPPER_NIBBLE( (unsigned)dtd[ 7 ] )

#define V_ACTIVE           COMBINE_HI_8LO( V_ACTIVE_HI, V_ACTIVE_LO )

#define V_BLANKING_HI      LOWER_NIBBLE( (unsigned)dtd[ 7 ] )

#define V_BLANKING         COMBINE_HI_8LO( V_BLANKING_HI, V_BLANKING_LO )



#define H_SYNC_OFFSET_LO   (unsigned)dtd[ 8 ]
#define H_SYNC_WIDTH_LO    (unsigned)dtd[ 9 ]

#define V_SYNC_OFFSET_LO   UPPER_NIBBLE( (unsigned)dtd[ 10 ] )
#define V_SYNC_WIDTH_LO    LOWER_NIBBLE( (unsigned)dtd[ 10 ] )

#define V_SYNC_WIDTH_HI    ((unsigned)dtd[ 11 ] & (1|2))
#define V_SYNC_OFFSET_HI   (((unsigned)dtd[ 11 ] & (4|8)) >> 2)

#define H_SYNC_WIDTH_HI    (((unsigned)dtd[ 11 ] & (16|32)) >> 4)
#define H_SYNC_OFFSET_HI   (((unsigned)dtd[ 11 ] & (64|128)) >> 6)


#define V_SYNC_WIDTH       COMBINE_HI_4LO( V_SYNC_WIDTH_HI, V_SYNC_WIDTH_LO )
#define V_SYNC_OFFSET      COMBINE_HI_4LO( V_SYNC_OFFSET_HI, V_SYNC_OFFSET_LO )

#define H_SYNC_WIDTH       COMBINE_HI_4LO( H_SYNC_WIDTH_HI, H_SYNC_WIDTH_LO )
#define H_SYNC_OFFSET      COMBINE_HI_4LO( H_SYNC_OFFSET_HI, H_SYNC_OFFSET_LO )

#define H_SIZE_LO          (unsigned)dtd[ 12 ]
#define V_SIZE_LO          (unsigned)dtd[ 13 ]

#define H_SIZE_HI          UPPER_NIBBLE( (unsigned)dtd[ 14 ] )
#define V_SIZE_HI          LOWER_NIBBLE( (unsigned)dtd[ 14 ] )

#define H_SIZE             COMBINE_HI_8LO( H_SIZE_HI, H_SIZE_LO )
#define V_SIZE             COMBINE_HI_8LO( V_SIZE_HI, V_SIZE_LO )

#define H_BORDER           (unsigned)dtd[ 15 ]
#define V_BORDER           (unsigned)dtd[ 16 ]

#define FLAGS              (unsigned)dtd[ 17 ]

#define INTERLACED         (FLAGS&128)
#define SYNC_TYPE	   	   (FLAGS&3<<3)  /* bits 4,3 */
#define SYNC_SEPARATE	   (3<<3)
#define HSYNC_POSITIVE	   (FLAGS & 4)
#define VSYNC_POSITIVE     (FLAGS & 2)

#define MONITOR_NAME            0xfc
#define MONITOR_LIMITS          0xfd
#define UNKNOWN_DESCRIPTOR      -1
#define DETAILED_TIMING_BLOCK   -2


#define DESCRIPTOR_DATA         5
#define V_MIN_RATE              block[ 5 ]
#define V_MAX_RATE              block[ 6 ]
#define H_MIN_RATE              block[ 7 ]
#define H_MAX_RATE              block[ 8 ]

#define MAX_PIXEL_CLOCK         (((int)block[ 9 ]) * 10)
#define GTF_SUPPORT		block[10]

#define DPMS_ACTIVE_OFF		(1 << 5)
#define DPMS_SUSPEND		(1 << 6)
#define DPMS_STANDBY		(1 << 7)

char* myname;

int EDID::Parse()
{
    unsigned i;
    unsigned char* block;
    WCHAR * monitor_name = NULL;
    unsigned char checksum = 0;
    WCHAR *vendor_sign;
    int ret = 0;

    for ( i = 0; i < EDID_LENGTH; i++ )
        checksum += edid[ i ];

    if (  checksum != 0  )
    {
        RETAILMSG(1,(TEXT("EDID checksum failed - data is corrupt. Continuing anyway." )));
        ret = 1;
    }
    else
        RETAILMSG(1,(TEXT("EDID checksum passed.")));


    if ( strncmp( (const char *)edid+EDID_HEADER, (const char*)edid_v1_header, EDID_HEADER_END+1 ) )
    {
        RETAILMSG(1,(TEXT("first unsigned chars don't match EDID version 1 header" )));
        RETAILMSG(1,(TEXT("do not trust output (if any).\r\n" )));
        ret = 1;
    }

    vendor_sign = get_vendor_sign( edid + ID_MANUFACTURER_NAME );

    block = edid + DETAILED_TIMING_DESCRIPTIONS_START;

    for ( i = 0; i < NO_DETAILED_TIMING_DESCRIPTIONS; i++,
            block += DETAILED_TIMING_DESCRIPTION_SIZE )
    {

        if ( block_type( block ) == MONITOR_NAME )
        {
            monitor_name = get_monitor_name( block );
            break;
        }
    }

    RETAILMSG(1,(TEXT("----# EDID for %s----\r\n\r\n"),monitor_name));

    RETAILMSG(1,(TEXT("EDID version          : %d.%d\r\n"), (int)edid[EDID_STRUCT_VERSION],(int)edid[EDID_STRUCT_REVISION] ));
    RETAILMSG(1,(TEXT("Manufacturer          : %s\r\n"), vendor_sign ));
    RETAILMSG(1,(TEXT("Model                 : %s\r\n"), monitor_name ));

    parse_dpms_capabilities(edid[DPMS_FLAGS]);

    block = edid + DETAILED_TIMING_DESCRIPTIONS_START;

    for ( i = 0; i < NO_DETAILED_TIMING_DESCRIPTIONS; i++,
            block += DETAILED_TIMING_DESCRIPTION_SIZE )
    {

        if ( block_type( block ) == MONITOR_LIMITS )
            parse_monitor_limits( block );
    }

	/* Standard Vesa timing blocks */
/*
35: ESTABLISHED TIMING I
  bit 7-0: 720�400@70 Hz, 720�400@88 Hz, 640�480@60 Hz, 640�480@67 Hz,
           640�480@72 Hz, 640�480@75 Hz, 800�600@56 Hz, 800�600@60 Hz
36: ESTABLISHED TIMING II
  bit 7-0: 800�600@72 Hz, 800�600@75 Hz, 832�624@75 Hz, 1024�768@87 Hz (Interlaced),
           1024�768@60 Hz, 1024�768@70 Hz, 1024�768@75 Hz, 1280�1024@75 Hz
*/
    RETAILMSG(1,(TEXT("\r\nEstablished Vesa Timings :\r\n")));

	if ( edid[ESTABLISHED_TIMING_1] & 0x01 )
	    RETAILMSG(1,(TEXT("\t\t  800�600 @ 60 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_1] & 0x02 )
	    RETAILMSG(1,(TEXT("\t\t  800�600 @ 56 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_1] & 0x04 )
	    RETAILMSG(1,(TEXT("\t\t  640�480 @ 75 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_1] & 0x08 )
	    RETAILMSG(1,(TEXT("\t\t  640�480 @ 72 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_1] & 0x10 )
	    RETAILMSG(1,(TEXT("\t\t  640�480 @ 67 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_1] & 0x20 )
	    RETAILMSG(1,(TEXT("\t\t  640�480 @ 60 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_1] & 0x40 )
	    RETAILMSG(1,(TEXT("\t\t  720�400 @ 88 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_1] & 0x80 )
	    RETAILMSG(1,(TEXT("\t\t  720�400 @ 70 Hz\r\n")));

	if ( edid[ESTABLISHED_TIMING_2] & 0x01 )
	    RETAILMSG(1,(TEXT("\t\t1280�1024 @ 75 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_2] & 0x02 )
	    RETAILMSG(1,(TEXT("\t\t 1024�768 @ 75 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_2] & 0x04 )
	    RETAILMSG(1,(TEXT("\t\t 1024�768 @ 70 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_2] & 0x08 )
	    RETAILMSG(1,(TEXT("\t\t 1024�768 @ 60 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_2] & 0x10 )
	    RETAILMSG(1,(TEXT("\t\t 1024�768 @ 87 Hz (Interlaced)\r\n")));
	if ( edid[ESTABLISHED_TIMING_2] & 0x20 )
	    RETAILMSG(1,(TEXT("\t\t  832�624 @ 75 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_2] & 0x40 )
	    RETAILMSG(1,(TEXT("\t\t  800�600 @ 75 Hz\r\n")));
	if ( edid[ESTABLISHED_TIMING_2] & 0x80 )
	    RETAILMSG(1,(TEXT("\t\t  800�600 @ 72 Hz\r\n")));



	/* Detailed timing block */
    block = edid + DETAILED_TIMING_DESCRIPTIONS_START;
    for ( i = 0; i < NO_DETAILED_TIMING_DESCRIPTIONS; i++,
            block += DETAILED_TIMING_DESCRIPTION_SIZE )
    {

        if ( block_type( block ) == DETAILED_TIMING_BLOCK )
            parse_timing_description( block );
    }

    RETAILMSG(1,(TEXT("----# End EDID for %s----\r\n\r\n"),monitor_name));
    return ret;
}


int EDID::parse_timing_description( unsigned char* dtd )
{
    int htotal, vtotal;
    htotal = H_ACTIVE + H_BLANKING;
    vtotal = V_ACTIVE + V_BLANKING;

	RETAILMSG(1,(TEXT("\r\nDetailed Timings:\r\n")));

    /* Convert floats to string for RETAILMSG output */
    WCHAR zxString[3][20];
    wsprintf(zxString[0],L"%f",(double)PIXEL_CLOCK/((double)vtotal*(double)htotal));
    wsprintf(zxString[1],L"%f",(double)PIXEL_CLOCK/(double)(htotal*1000));
    wsprintf(zxString[2],L"%f",((double)PIXEL_CLOCK/1000000.0 ));

    RETAILMSG(1, (TEXT("\t\t%d x %d @ %s\r\n"), H_ACTIVE, V_ACTIVE, zxString[0] ));

    RETAILMSG(1, (TEXT("\t\tPixel Clock        : %s\r\n"),zxString[2] ));

    RETAILMSG(1, (TEXT("\t\tHTimings           : %u %u %u %u\r\n"), H_ACTIVE,
                  H_ACTIVE+H_SYNC_OFFSET,
                  H_ACTIVE+H_SYNC_OFFSET+H_SYNC_WIDTH,
                  htotal ));

    RETAILMSG(1, (TEXT("\t\tVTimings           : %u %u %u %u\r\n"), V_ACTIVE,
                  V_ACTIVE+V_SYNC_OFFSET,
                  V_ACTIVE+V_SYNC_OFFSET+V_SYNC_WIDTH,
                  vtotal ));

    if ( INTERLACED || (SYNC_TYPE == SYNC_SEPARATE))
    {
	    RETAILMSG(1,(TEXT("\t\tFlags               : %s\"%sHSync\" \"%sVSync\"\r\n"),
                     INTERLACED ? L"\"Interlace\" ": L"",
                     HSYNC_POSITIVE ? L"+": L"-",
                     VSYNC_POSITIVE ? L"+": L"-"));
    }

	m_preferred.dotclock 	=  (unsigned int)((double)PIXEL_CLOCK/1000000.0 );
	m_preferred.hdisplay 	=  H_ACTIVE;
	m_preferred.hsyncstart 	=  H_SYNC_OFFSET;
	m_preferred.hsyncend    =  H_SYNC_WIDTH;
	m_preferred.htotal      =  htotal;
	m_preferred.vdisplay    =  V_ACTIVE;
	m_preferred.vsyncstart  =  V_SYNC_OFFSET;
	m_preferred.vsyncend    =  V_SYNC_WIDTH;
	m_preferred.vtotal      =  vtotal;

    return 0;
}


int EDID::block_type( unsigned char* block )
{
    if ( !strncmp( (const char *)edid_v1_descriptor_flag, (const char *)block, 2 ) )
    {
//        RETAILMSG(1,(TEXT("\t# Block type: 2:%x 3:%x\r\n"), block[2], block[3]));
        /* descriptor */
        if ( block[ 2 ] != 0 )
            return UNKNOWN_DESCRIPTOR;
        return block[ 3 ];
    }
    else
    {
        /* detailed timing block */
        return DETAILED_TIMING_BLOCK;
    }
}

WCHAR * EDID::get_monitor_name( unsigned char const* block )
{
    static WCHAR name[ 13 ];
    unsigned i;
    unsigned char const* ptr = block + DESCRIPTOR_DATA;


    for ( i = 0; i < 13; i++, ptr++ )
    {

        if ( *ptr == 0xa )
        {
            name[ i ] = 0;
            return name;
        }

        name[ i ] = *ptr;
    }


    return name;
}


WCHAR * EDID::get_vendor_sign( unsigned char const* block )
{
    static WCHAR sign[4];
    unsigned short h;

    /*
       08h	WORD	big-endian manufacturer ID (see #00136)
      	    bits 14-10: first letter (01h='A', 02h='B', etc.)
      	    bits 9-5: second letter
      	    bits 4-0: third letter
    */
    h = COMBINE_HI_8LO(block[0], block[1]);
    sign[0] = ((h>>10) & 0x1f) + 'A' - 1;
    sign[1] = ((h>>5) & 0x1f) + 'A' - 1;
    sign[2] = (h & 0x1f) + 'A' - 1;
    sign[3] = 0;
    return sign;
}

int EDID::parse_monitor_limits( unsigned char* block )
{
    RETAILMSG(1, (TEXT("Valid HSync Range     : %u-%u\r\n"), H_MIN_RATE, H_MAX_RATE ));
    RETAILMSG(1, (TEXT("Valid VRefresh Range  : %u-%u\r\n"), V_MIN_RATE, V_MAX_RATE ));
    if ( MAX_PIXEL_CLOCK == 10*0xff )
	    RETAILMSG(1, (TEXT("Max pixel clock       : n/a\r\n" )));
    else
	    RETAILMSG(1, (TEXT("Max pixel clock       : %u MHz\r\n"), (int)MAX_PIXEL_CLOCK ));

    if ( GTF_SUPPORT )
    {
      	RETAILMSG(1, (TEXT("GTF Support           : YES\r\n" )));
    }

    return 0;
}

int EDID::parse_dpms_capabilities(unsigned char flags)
{
    RETAILMSG(1,(TEXT("DPMS Capabilities     : Active off:%s  Suspend:%s  Standby:%s\r\n\r\n"),
                 (flags & DPMS_ACTIVE_OFF) ? L"yes" : L"no",
                 (flags & DPMS_SUSPEND)    ? L"yes" : L"no",
                 (flags & DPMS_STANDBY)    ? L"yes" : L"no" ));
    return 0;
}

modeline EDID::Query()
{

    static SMBUS_TRANSFER Transfer;

    /* Set the index to 0 */
    Transfer.Address 	= 0x50;
    Transfer.Data[0] 	= 0;
    Transfer.DataSize 	= 1;
    SMBus_WriteData(hI2C, &Transfer);

    /* Read the EDID via DDC/I2C */
    Transfer.Address 	= 0x50;
    Transfer.DataSize 	= MAX_EDID;
    SMBus_ReadData(hI2C, &Transfer);

#if EDID_SAMPLE
    memcpy(edid, edid_sample, MAX_EDID);
#else
    memcpy(edid, &Transfer.Data, MAX_EDID);
#endif
#if EDID_DUMP
    RETAILMSG(1,(TEXT("EDID Dump:\r\r\n ")));
    for (int i=0;i<MAX_EDID;i++)
    {
        if (!(i%16))
            RETAILMSG(1,(TEXT("\r\r\n ")));

        RETAILMSG(1,(TEXT("%02x "), edid[i] ));
    }
    RETAILMSG(1,(TEXT("\r\n\r\n")));
#endif

    Parse();

    return m_preferred;
}

EDID::EDID()
{
    RETAILMSG(1,(TEXT("CTG:::EDID INIT\r\r\n")));
    hI2C = SMBus_Initialize();
}

EDID::~EDID()
{
}

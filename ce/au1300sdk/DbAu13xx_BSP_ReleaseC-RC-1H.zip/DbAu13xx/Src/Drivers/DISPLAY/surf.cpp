/*****************************************************************************
Copyright 2003-2007 Raza Microelectronics, Inc.(RMI). All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY Raza Microelectronics, Inc. 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "precomp.h"

/********************************************************************/
void Au12::CheckVisibleSurface(void)
{
   unsigned long tickCount = GetTickCount();

   if( tickCount - m_nTicksAtFlip > m_nTicksPerFrame + 1 )
   {
      m_pOldVisibleSurface = m_pNewVisibleSurface;
      return;
   }

   DEBUGMSG (GPE_ZONE_FLIP,
      (TEXT("Remaining ticks per frame:%d\n\r"), (tickCount-m_nTicksAtFlip)) );

   WaitForVBlank();
   return;
}

/********************************************************************/
int Au12::SurfaceBusyFlipping( DDGPESurf *pSurf )
{
   if( pSurf == m_pOldVisibleSurface || pSurf == m_pNewVisibleSurface )
      CheckVisibleSurface();

   return ( pSurf == m_pOldVisibleSurface || pSurf == m_pNewVisibleSurface );
}

/********************************************************************/
int Au12::FlipInProgress(void)
{
   if( m_pOldVisibleSurface != m_pNewVisibleSurface )
      CheckVisibleSurface();
   else
      return 0;

   if( m_pOldVisibleSurface != m_pNewVisibleSurface )
   {
      DEBUGMSG (GPE_ZONE_FLIP, ( TEXT("Flip from surf 0x%08x to 0x%08x in progress\r\n"),
         m_pOldVisibleSurface, m_pNewVisibleSurface ));
   }
   return ( m_pOldVisibleSurface != m_pNewVisibleSurface );
}

SCODE
Au12::AllocSurface(
    DDGPESurf         ** ppSurf,
    int                  width,
    int                  height,
    EGPEFormat           format,
    EDDGPEPixelFormat    pixelFormat,
    int                  surfaceFlags
    )
{
	switch (pixelFormat) {
		case ddgpePixelFormat_1bpp:
		case ddgpePixelFormat_2bpp:
		case ddgpePixelFormat_4bpp:
		case ddgpePixelFormat_8bpp:
		case ddgpePixelFormat_565:
		case ddgpePixelFormat_5551:
		case ddgpePixelFormat_8880:
		case ddgpePixelFormat_8888:
			// These are all OK
			break;

			// We're not super happy about these formats though
		case ddgpePixelFormat_5550:
		case ddgpePixelFormat_4444:
		default:
			DEBUGMSG(1,(TEXT("pixelFormat %d not supported\r\n"),pixelFormat));
			return E_INVALIDARG;
	}


    if ( (surfaceFlags & GPE_BACK_BUFFER) ||
         (surfaceFlags & GPE_REQUIRE_VIDEO_MEMORY) ||
         ((format == m_pMode->format) && (surfaceFlags & GPE_PREFER_VIDEO_MEMORY))
       )
    {
        if (!(format == m_pMode->format))
        {
            DEBUGMSG(GPE_ZONE_WARNING, (L"AllocSurface - Invalid format value\n"));
            return E_INVALIDARG;
        }

		// Attempt to allocate from video memory
		DWORD ulStride = ((EGPEFormatToBpp[format] * width + 31) >> 5) << 2;
		DWORD ulHeapSize = ulStride * height;

		ULONG memAvail =  m_pVideoMemory->Available();
		DEBUGMSG(1, (TEXT("Alloc: Vmem avail: 0x%x(%u)\r\n"), memAvail, memAvail));
		DEBUGMSG(1, (TEXT("Alloc: width, height, request size (%u,%u,%u,%u)\r\n"), width, height, ulHeapSize,ulStride));

		SurfaceHeap *pNode = m_pVideoMemory->Alloc(ulHeapSize);

        if (pNode)
        {
			ULONG offset = pNode->Address() - (DWORD)m_pvFlatFrameBuffer;

            DEBUGMSG(1, (L"Allocatting new Au12Surf\n"));
			DEBUGMSG(1,(TEXT("Au12::AllocSurface - offset:0x%X pixelformat:%x\r\n"),offset,pixelFormat));

			*ppSurf = new Au12Surf(width, height, offset, (void *)pNode->Address(), ulStride, format, pixelFormat, pNode);

            if (!(*ppSurf))
            {
                pNode->Free();
                return E_OUTOFMEMORY;
            }

            return S_OK;
        }

        if (surfaceFlags & GPE_REQUIRE_VIDEO_MEMORY)
        {
            *ppSurf = (DDGPESurf *)NULL;
            return DDERR_OUTOFVIDEOMEMORY;
        }
    }

    if (surfaceFlags & GPE_REQUIRE_VIDEO_MEMORY)
    {
        *ppSurf = (DDGPESurf *)NULL;
        RETAILMSG(1, (L"AllocSurface - Out of Memory 3\n"));
        return DDERR_OUTOFVIDEOMEMORY;
    }

    // Allocate from system memory
    DEBUGMSG(0, (TEXT("Creating a GPESurf in system memory. EGPEFormat = %d\r\n"), (int) format));
    {
        DWORD bpp  = EGPEFormatToBpp[format];
        DWORD stride = ((bpp * width + 31) >> 5) << 2;
        DWORD nSurfaceBytes = stride * height;

        *ppSurf = new DDGPESurf(width, height, stride, format, pixelFormat);
    }

    if (*ppSurf != NULL)
    {
        // check we allocated bits succesfully
        if (((*ppSurf)->Buffer()) == NULL)
        {
            delete *ppSurf;
        }
        else
        {
            return    S_OK;
        }
    }

    DEBUGMSG(GPE_ZONE_WARNING, (L"AllocSurface - Out of Memory 4\n"));
    return E_OUTOFMEMORY;
}

SCODE
Au12::AllocSurface(
    GPESurf    ** ppSurf,
    int           width,
    int           height,
    EGPEFormat    format,
    int           surfaceFlags
    )
{

    EDDGPEPixelFormat pixelFormat;
    GPEModeEx modeInfoEx;

    GetModeInfoEx(&modeInfoEx, GetModeId());

    // GDI Issue Work-Around
    // There is an issue with GDI where if you have a printer device context
    // that has the same number of bits per pixel as the display, but
    // different bit masks, you will get the display's masks.

    // This is because in this function, when we are passed
    // the gpeDeviceCompatible constant, it refers to the current device,
    // which we have no knowledge of, not the display.

    if ( (format == modeInfoEx.modeInfo.format) || (format == gpeDeviceCompatible) )
    {
        pixelFormat = modeInfoEx.ePixelFormat;

        DEBUGMSG(1,
            (TEXT("Display Compatible requested: format, ")
             TEXT("pixelFormat = 0x%x, 0x%x\r\n"), format, pixelFormat));
    }
    else
    {
        pixelFormat = EGPEFormatToEDDGPEPixelFormat[format];
        DEBUGMSG(1,
            (TEXT("Explicitly requested: format, ")
             TEXT("pixelFormat = 0x%x, 0x%x\r\n"), format, pixelFormat));
    }

    return AllocSurface((DDGPESurf**)ppSurf, width, height, format, pixelFormat, surfaceFlags);
}



DWORD Au12::SetOverlayPosition(int overlayIndex, LONG xPos, LONG yPos)
{
	DWORD winctrl0;

	winctrl0 = m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl0;

	// mask out X and Y origin values
	winctrl0 &= ~(LCD_WINCTRL0_OX | LCD_WINCTRL0_OY);
	winctrl0 |= LCD_WINCTRL0_OX_N(xPos) | LCD_WINCTRL0_OY_N(yPos);

	m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl0 = winctrl0;

	return DD_OK;
}

DWORD Au12::ShowOverlay(LPDDRAWI_DDRAWSURFACE_LCL lpSrcSurf,
                        LONG                      width,
                        LONG                      height,
                        LONG                      xPos,
                        LONG                      yPos,
                        DWORD                     colorKey,
                        DWORD                     alphaValue,
                        DWORD                     dwFlags,
                        DDOVERLAYFX               overlayFX)
{
  DDGPESurf *pSurf = DDGPESurf::GetDDGPESurf(lpSrcSurf);
  int overlayIndex;
  DWORD overlayBPP, offset;

  offset = pSurf->OffsetInVideoMemory();
  DEBUGMSG(1,(TEXT("Au12::ShowOverlay - offset:0x%X pixelformat:0x%x\r\n"),offset,pSurf->PixelFormat()));

  // Is this an existing overlay surface ?
  for (overlayIndex=0;overlayIndex<NUM_OVERLAYS;overlayIndex++) {
    if (m_Overlays[overlayIndex].Active &&
      m_Overlays[overlayIndex].Offset == offset) {
        break;
    }
  }

  if (overlayIndex == NUM_OVERLAYS) {
    // Not a currently active overlay, see if there's a spare one
    for (overlayIndex=0;overlayIndex<NUM_OVERLAYS;overlayIndex++) {
      if (!m_Overlays[overlayIndex].Active) {
        break;
      }
    }

    if (overlayIndex == NUM_OVERLAYS) {
      // No free overlays, return failure
      DEBUGMSG(1,(TEXT("Au12::ShowOverlay - No free overlay surfaces\r\n")));
      return DDERR_NOTAOVERLAYSURFACE;
    }
  }

  RETAILMSG(1,(TEXT("overlayIndex %d\r\n"),overlayIndex));

  if (!m_Overlays[overlayIndex].Active) {
    //		if (!(lpSourceGbl->ddpfSurface.dwFlags & DDPF_RGB)) {
    overlayBPP = m_ModeInfo.Bpp;
    //		} else {
    //			overlayBPP = lpSourceGbl->ddpfSurface.dwRGBBitCount;
    //		}

    // Set Source overlay format
    switch(pSurf->PixelFormat()) {
        case ddgpePixelFormat_1bpp: m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 = LCD_WINCTRL1_FRM_1BPP; break;
        case ddgpePixelFormat_2bpp: m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 = LCD_WINCTRL1_FRM_2BPP; break;
        case ddgpePixelFormat_4bpp: m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 = LCD_WINCTRL1_FRM_4BPP; break;
        case ddgpePixelFormat_8bpp: m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 = LCD_WINCTRL1_FRM_8BPP; break;
        case ddgpePixelFormat_565:  m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 = LCD_WINCTRL1_FRM_16BPP565; break;
        case ddgpePixelFormat_5551: m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 = LCD_WINCTRL1_FRM_16BPPA1555; break;
        case ddgpePixelFormat_8880: m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 = LCD_WINCTRL1_FRM_24BPP; break;
        case ddgpePixelFormat_8888: m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 = LCD_WINCTRL1_FRM_32BPP; break;

        default:
          DEBUGMSG(1,(TEXT("Au1200LCD::ShowOverlay unsupported PixelFormat %d\r\n"),pSurf->PixelFormat()));
          return DDERR_UNSUPPORTEDFORMAT;
    }

	// Assign Priority and Pipe to DDRAW overlay
	// ** these are global "DirectDraw" window settings. Not overlay specific!
	m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 |= ( \
						   LCD_WINCTRL1_PO_01 |
					       LCD_WINCTRL1_PIPE_N(m_Windows[OVERLAY_PLANE].dwPipe) |
						   LCD_WINCTRL1_PRI_N(m_Windows[OVERLAY_PLANE].dwPriority) );


    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl2 &= ~(LCD_WINCTRL2_BX_N(0x1FFF)); // clear before setting
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl2 |= (LCD_WINCTRL2_DBM |
      LCD_WINCTRL2_BX_N((width*overlayBPP/8)));

    m_lcd->window[OVERLAY_PLANE+overlayIndex].winbufctrl = 0;

    DEBUGMSG(1,(TEXT("ShowOverlay() BX %d bpp=%d\r\n"), width*(overlayBPP/8),overlayBPP));

    SetOverlaySurface(overlayIndex, lpSrcSurf);
  }

  // Either update current overlay or finish configuring a new one

  // Only one overlay can use color keying at a time.
  // Here we make sure that the other overlays are not using color keying
  // before allowing this one too

  if (dwFlags & DDOVER_KEYSRC || dwFlags & DDOVER_KEYSRCOVERRIDE ||
    dwFlags & DDOVER_KEYDEST || dwFlags & DDOVER_KEYDESTOVERRIDE) {

      // check other overlays
      if (NumColorKeyedOverlays()) {
        if (colorKey!=m_lcd->colorkey) {
          DEBUGMSG(1,(TEXT("AU1200LCD::ShowOverlay - overlay %d can't use color keying since already in use with different key value...\r\n"),overlayIndex));
          return DDERR_GENERIC;
        } else {
          DEBUGMSG(1,(TEXT("AU1200LCD::ShowOverlay - overlay %d can share colorkey with existing overlay!!\r\n"),overlayIndex));
        }
      }

      DEBUGMSG(1,(TEXT("ShowOverlay: Overlay %d is using color keying\r\n"),overlayIndex));
  } else {
    DEBUGMSG(1,(TEXT("ShowOverlay: Overlay %d is NOT using color keying\r\n"),overlayIndex));
  }

  // We can do source or destination color keying, BUT only ONE AT A TIME
  // We'll let source keying take precedence if both are set.

  if (dwFlags & DDOVER_KEYSRC || dwFlags & DDOVER_KEYSRCOVERRIDE) {
    m_lcd->backcolor = colorKey;
    m_lcd->colorkey = colorKey;
    m_lcd->colorkeymsk = 0x00FFFFFF;

    m_lcd->window[DESKTOP_PLANE].winctrl2 |= LCD_WINCTRL2_CKMODE_11;
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl2 &= ~LCD_WINCTRL2_CKMODE_11;
    // highest priority for source color keyed
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 &= ~LCD_WINCTRL1_PRI;
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 |=  LCD_WINCTRL1_PRI_N(2+overlayIndex);

    m_Overlays[overlayIndex].SourceColorKeyed = true;
    DEBUGMSG(1,(TEXT("ShowOverlay: Overlay %d is using source color keying %X\r\n"),overlayIndex,colorKey));

  }
  else if (dwFlags & DDOVER_KEYDEST || dwFlags & DDOVER_KEYDESTOVERRIDE) {
    m_lcd->backcolor = colorKey;
    m_lcd->colorkey = colorKey;
    m_lcd->colorkeymsk = 0x00FFFFFF;

    // Set colorkeying in the overlay window so that if the pixel in the
    // other pipe (ie, the main display) matches the colorkey then use the pixel
    // from the overlay, otherwise use pixel from main display.

    m_lcd->window[DESKTOP_PLANE].winctrl2 &= ~LCD_WINCTRL2_CKMODE_11;
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl2 |= LCD_WINCTRL2_CKMODE_11;
    // lowest priority for destination color keyed
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 &= ~LCD_WINCTRL1_PRI;
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 |=  LCD_WINCTRL1_PRI_N(0);

    DEBUGMSG(1,(TEXT("ShowOverlay: Overlay %d is using destination color keying\r\n"),overlayIndex));
    m_Overlays[overlayIndex].DestColorKeyed = true;
  }
  else {
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl2 &= ~LCD_WINCTRL2_CKMODE_11;	// color keying off for this plane
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 &= ~LCD_WINCTRL1_PRI;
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 |=  LCD_WINCTRL1_PRI_N(2+overlayIndex);
  }

  if (dwFlags & DDOVER_ALPHACONSTOVERRIDE) {
    DEBUGMSG(1,(TEXT("Overriding Alpha value -> %d\r\n"),alphaValue));
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl0 = LCD_WINCTRL0_A_N(alphaValue) | LCD_WINCTRL0_AEN;
  } else {
    m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl0 = 0;
  }

  DEBUGMSG(1,(TEXT("AU1200LCD::ShowOverlay() WINCTRL1 POSITION (%d,%d)\r\n"), xPos,yPos));
  SetOverlayPosition(overlayIndex,xPos,yPos);

  DWORD winctrl = m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1;

  winctrl &= ~(LCD_WINCTRL1_SZX|LCD_WINCTRL1_SZY);
  winctrl |= LCD_WINCTRL1_SZX_N(width) | LCD_WINCTRL1_SZY_N(height);

  m_lcd->window[OVERLAY_PLANE+overlayIndex].winctrl1 = winctrl;

  DEBUGMSG(1,(TEXT("AU1200LCD::ShowOverlay() %d SIZE %dx%d\r\n"),  overlayIndex, width,height));

  if (!m_Overlays[overlayIndex].Active) {
    m_Overlays[overlayIndex].Active = true;

    // enable the overlay window
    EnablePlane(OVERLAY_PLANE+overlayIndex);
  }

  return DD_OK;
}

DWORD Au12::HideOverlay(LPDDRAWI_DDRAWSURFACE_LCL lpSrcSurf)
{
    DDGPESurf *pSurf = DDGPESurf::GetDDGPESurf(lpSrcSurf);
	DWORD offset;
	int overlayIndex;

	offset = pSurf->OffsetInVideoMemory();

	for (overlayIndex=0;overlayIndex<NUM_OVERLAYS;overlayIndex++) {

		if (offset == m_Overlays[overlayIndex].Offset) {
			DEBUGMSG(1,(TEXT("Hiding Overlay %d\r\n"),overlayIndex));

            DisablePlane(OVERLAY_PLANE+overlayIndex);

			m_Overlays[overlayIndex].Active = false;
			m_Overlays[overlayIndex].Offset = -1L;
			m_Overlays[overlayIndex].SourceColorKeyed = false;
			m_Overlays[overlayIndex].DestColorKeyed = false;

			// clear source color keying if no longer active
			if (NumSourceColorKeyedOverlays()==0) {
				m_lcd->window[DESKTOP_PLANE].winctrl2 &= ~LCD_WINCTRL2_CKMODE;
				m_lcd->window[MAE_PLANE].winctrl2 &= ~LCD_WINCTRL2_CKMODE;
			}
		}
	}

	return DD_OK;
}


DWORD Au12::SetOverlaySurface(int                       overlayIndex,
                                   LPDDRAWI_DDRAWSURFACE_LCL lpSrcSurf)
{
    DDGPESurf *pSurf = DDGPESurf::GetDDGPESurf(lpSrcSurf);
	LONG offset = pSurf->OffsetInVideoMemory();

	m_lcd->window[OVERLAY_PLANE+overlayIndex].winbuf0 =
	m_lcd->window[OVERLAY_PLANE+overlayIndex].winbuf1 = m_pPyhsicalFrameBuffer + offset;
	m_Overlays[overlayIndex].Offset = offset;

	return DD_OK;
}

void Au12::SetVisibleSurface( GPESurf *pSurf, BOOL bWaitForVBlank )
{
    ULONG offset = pSurf->OffsetInVideoMemory();

    if (bWaitForVBlank)
        WaitForVBlank();

	m_pNewVisibleSurface = (Au12Surf *)pSurf;
	m_lcd->window[DESKTOP_PLANE].winbuf0 =
	m_lcd->window[DESKTOP_PLANE].winbuf1 = m_pPyhsicalFrameBuffer + offset;
	m_nTicksAtFlip = GetTickCount();

#if 0
	if( tickCountValid )
	{
		frameCount++;
		if( m_nTicksAtFlip - lastTickCount > 10000 )
		{
			int framesPerTenSecs = frameCount * 10000 / ( m_nTicksAtFlip - lastTickCount );
			if( framesPerTenSecs < 2000 )
			{
				DEBUGMSG( 1, (TEXT("Frames per second: %d.%1d\r\n"),
					framesPerTenSecs/10, framesPerTenSecs%10 ));
			}
			lastTickCount = m_nTicksAtFlip;
			frameCount = 0;
		}
	}
	else
	{
		tickCountValid = 1;
		lastTickCount = m_nTicksAtFlip;
		frameCount = 0;
	}
#endif DEBUG
}


Au12Surf::Au12Surf(
    int          width,
    int          height,
    ULONG        offset,
    void       * pBits,
    int          stride,
    EGPEFormat   format,
	SurfaceHeap* pNode
    ) : DDGPESurf (width, height, pBits, stride, format)
{
    m_pSurfaceHeap         = pNode;
    m_fInVideoMemory       = FALSE;
    m_nOffsetInVideoMemory = offset;
}

Au12Surf::Au12Surf(
    int                 width,
    int                 height,
    ULONG               offset,
    void              * pBits,
    int                 stride,
    EGPEFormat          format,
    EDDGPEPixelFormat   pixelFormat,
	SurfaceHeap* pNode
    ) : DDGPESurf (width, height, pBits, stride, format, pixelFormat)
{
    m_pSurfaceHeap         = pNode;
    m_fInVideoMemory       = FALSE;
    m_nOffsetInVideoMemory = offset;
}

Au12Surf::~Au12Surf()
{
    m_pSurfaceHeap->Free();
}

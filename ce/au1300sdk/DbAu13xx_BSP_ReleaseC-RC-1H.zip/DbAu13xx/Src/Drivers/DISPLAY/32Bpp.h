#include "precomp.h"


SCODE SourceInvert1to32( GPEBltParms * pParms );
SCODE SourceInvert4to32( GPEBltParms * pParms );
SCODE SourceInvert8to32( GPEBltParms * pParms );
SCODE SourceInvert16to32( GPEBltParms * pParms );
SCODE SourceInvert24to32( GPEBltParms * pParms );
SCODE SourceInvert32to32( GPEBltParms * pParms );

SCODE SourceCopy1to32( GPEBltParms * pParms );
SCODE SourceCopy4to32( GPEBltParms * pParms );
SCODE SourceCopy8to32( GPEBltParms * pParms );
SCODE SourceCopy16to32( GPEBltParms * pParms );
SCODE SourceCopy24to32( GPEBltParms * pParms );
SCODE SourceCopy32to32( GPEBltParms * pParms );

SCODE SourceAnd1to32( GPEBltParms * pParms );
SCODE SourceAnd4to32( GPEBltParms * pParms );
SCODE SourceAnd8to32( GPEBltParms * pParms );
SCODE SourceAnd16to32( GPEBltParms * pParms );
SCODE SourceAnd24to32( GPEBltParms * pParms );
SCODE SourceAnd32to32( GPEBltParms * pParms );

SCODE SourcePaint1to32( GPEBltParms * pParms );
SCODE SourcePaint4to32( GPEBltParms * pParms );
SCODE SourcePaint8to32( GPEBltParms * pParms );
SCODE SourcePaint16to32( GPEBltParms * pParms );
SCODE SourcePaint24to32( GPEBltParms * pParms );
SCODE SourcePaint32to32( GPEBltParms * pParms );

// Stretching blits
SCODE StretchSourceCopy8to32( GPEBltParms * pParms );


#define BPP32_CASE_GPEBLT( function )																					\
switch ( pParms->pSrc->Format() )																						\
{																														\
    case gpe1Bpp:																										\
	{																													\
		if ( pParms->pLookup != NULL &&  !(pParms->bltFlags & BLT_STRETCH))																					\
		{																												\
			return function##1to32( pParms );																			\
		}																												\
	}																													\
    break;																												\
    case gpe4Bpp:																										\
	{																													\
		if ( pParms->pLookup != NULL &&  !(pParms->bltFlags & BLT_STRETCH))																					\
		{																												\
			return function##4to32( pParms );																			\
		}																												\
	}																													\
    break;																												\
	case gpe8Bpp:																										\
	{																													\
		if ( pParms->pLookup != NULL)																					\
		{																												\
			return function##8to32( pParms );																			\
		}																												\
	}																													\
	break;																												\
	case gpe16Bpp:																										\
	{	                                                                                                                \
        if (!(pParms->bltFlags & BLT_STRETCH))																		\
		{																												\
            return function##16to32( pParms );																			\
        }                                                                                                               \
	}																													\
	break;																												\
	case gpe24Bpp:																										\
	{	                                                                                                                \
        if (!(pParms->bltFlags & BLT_STRETCH))																		\
		{																												\
            return function##24to32( pParms );																			\
        }                                                                                                               \
	}																													\
	break;																												\
	case gpe32Bpp:																										\
	{	                                                                                                                \
        if (!(pParms->bltFlags & BLT_STRETCH))																		\
		{																												\
            return function##32to32( pParms );																			\
        }                                                                                                               \
	}																													\
	break;																												\
}

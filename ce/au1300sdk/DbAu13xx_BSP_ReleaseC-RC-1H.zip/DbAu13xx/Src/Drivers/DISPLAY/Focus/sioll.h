

#ifndef SIOLL_H
#define SIOLL_H

int SIOLL_init_focus(void);
int SIOLL_init_smbus(void);
void SIOLL_shutdown_focus(void);
void SIOLL_shutdown_smbus(void);
void SIOLL_output_clock(int value);
void SIOLL_set_data_for_output(void);
void SIOLL_output_data(int value);
int SIOLL_input_data(void);
void SIOLL_set_data_for_input(void);

#define ERR_INVALID_PARAMETER	1
#define ERR_SIO_READ_FAILED		2
#define ERR_SIO_WRITE_FAILED	3


#endif //SIOLL_H

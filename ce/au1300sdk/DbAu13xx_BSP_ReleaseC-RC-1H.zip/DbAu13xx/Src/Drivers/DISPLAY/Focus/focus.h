/*
 * File:	focus.h
 *
 * Purpose:	Init Focus FS4XX TV-Encoder
 *
 * Must set up FS453 to generate PCLK for FS471 for all modes.  There is
 * no TV-Out for the FS453 for modes below 640x480.  VGA modes are for
 * FS453 only.
 *
 * Author:	AMD/Focus
 * Date:	October 2004
 *
 *
 * Copyright (c) 2002-2005 BSQUARE Corporation.  All rights reserved.
 * Copyright (c) 2002-2007 Focus Enhancements, Inc.  All rights reserved.
 */
#ifndef FOCUS_H
#define FOCUS_H

typedef enum
{
	FORMAT_CVSV,
	FORMAT_COMPONENT,
	FORMAT_HDTV
} FOCUS_VIDEO_OUTPUT_FORMAT;

typedef enum
{
	MODE_192x176,
	MODE_192x176_PAL,
	MODE_220x176,
	MODE_220x176_PAL,
	MODE_240x320,
	MODE_240x320_PAL,
	MODE_256x192,
	MODE_256x192_PAL,
	MODE_320x240,
	MODE_320x240_PAL,
	MODE_440x234,
	MODE_440x234_PAL,
	MODE_440x360_PAL,
	MODE_480x272,
	MODE_640x480,
	MODE_640x480_PAL,
	MODE_640x480_VGA,		// FS453 Only
	MODE_720x480,
	MODE_720x576_PAL,
	MODE_800x600,
	MODE_800x600_PAL,
	MODE_800x600_VGA,		// FS453 Only
	MODE_1024x768,
	MODE_1024x768_PAL,
	MODE_1024x768_VGA,		// FS453 Only
	MODE_1280x720,
	MODE_1280x720_PAL,
	MODE_1366x234,
	MODE_1366x768,
	MODE_1366x768_PAL,
	MODE_1400x234
} FOCUS_VIDEO_OUTPUT_MODE;

//FOCUS SMBus Device Address
#define FS453_ADDRESS	0x4A	// Alt Address = H  0xD4
#define FS47X_ADDRESS	0x4A	// Alt Address = L  0x94

#define uint8 unsigned char

//FOCUS Bit Definitions
//CR Register
#define CR_FIFO_CLR		(1<<6)
#define CR_CACQ_CLR		(1<<5)
#define CR_NCO_EN		(1<<1)
#define CR_SRESET		(1<<0)
#define CR_GCC_CK_LVL	(1<<13)
#define CR_CBAR_480P	(1<<9)
//MISC Register
#define MISC_BRDG_RST	(1<<10)
#define MISC_47_COMP_YUV	(1<<2)
//VIDMODE0 Register
#define VID_MODE_CVSV	0
#define VID_MODE_SDTV	1
#define VID_MODE_SCART	1
#define VID_MODE_HDTV	2
#define VID_MODE_VGA	2
//QPR Register
#define QK_PROGRAM			(9<<12)
#define QK_UIM_NATIONAL		(3<<10)
#define QK_OS_SDTV			(0<<8)
#define QK_OS_480P			(1<<8)
#define QK_YC_IN			(1<<7)
#define QK_FF				(1<<6)
#define QK_OM_CVSV			(0<<4)
#define QK_OM_COMPONENT		(1<<4)
#define QK_UO				(1<<3)
#define QK_GMODE_640X480	(0<<1)
#define QK_GMODE_720X480	(1<<1)
#define QK_PN				(1<<0)

// FS453
typedef enum
{
	IHO,
	IVO,
	IHW,
	VSC,
	HSC,
	BYPASS,
	CR,
	MISC,
	NCON,
	NCOD,
	PLL_M,
	PLL_N,
	PLL_PD,
	SHP,
	FLK,
	GPIO,
	ID,
	STATUS_PORT,
	FIFO_SP,
	FIFO_LAT,
	VSOUT_TOTAL,
	VSOUT_START,
	VSOUT_END,
	CHR_FREQ,
	CHR_PHASE,
	MISC_45,
	MISC_46,
	MISC_47,
	HSYNC_WID,
	BURST_WID,
	BPORCH,
	CB_BURST,
	CR_BURST,
	MISC_4D,
	BLACK_LVL,
	BLANK_LVL,
	NUM_LINES,
	WHITE_LVL,
	CB_GAIN,
	CR_GAIN,
	TINT,
	BR_WAY,
	FR_PORCH,
	NUM_PIXELS,
	FIRST_LINE,
	MISC_74,
	SYNC_LVL,
	VBI_BL_LVL,
	SOFT_RST,
	ENC_VER,
	WSS_CONFIG,
	WSS_CLK,
	WSS_DATAF1,
	WSS_DATAF0,
	WSS_LNF1,
	WSS_LNF0,
	WSS_LVL,
	MISC_8D,
	VID_CNTRL0,
	HD_FP_SYNC,
	HD_YOFF_BP,
	SYNC_DL,
	LD_DET,
	DAC_CNTL,
	PWR_MGMT,
	RED_MTX,
	GRN_MTX,
	BLU_MTX,
	RED_SCL,
	GRN_SCL,
	BLU_SCL,
	CC_F1,
	CC_F2,
	CCC,
	CCBV,
	CC_BKS,
	HACT_ST,
	HACK_WD,
	VACT_ST,
	VACT_HT,
	PR_PB,
	Y_BW,
	QPR,
	UNDEFINED_REGISTER
} FOCUS_REGISTER_ID;

typedef struct
{
	FOCUS_REGISTER_ID id;
	char* description;
	uint8 address;
	uint8 size;
} FOCUS_REGISTER;

// FS453 registers
static const FOCUS_REGISTER focus_registers[] =
{
	{IHO,			"IHO",			0x00, 2},
	{IVO,			"IVO",			0x02, 2},
	{IHW,			"IHW",			0x04, 2},
	{VSC,			"VSC",			0x06, 2},
	{HSC,			"HSC",			0x08, 2},
	{BYPASS,		"Bypass",		0x0A, 2},
	{CR,			"CR",			0x0C, 2},
	{MISC,			"MISC",			0x0E, 2},
	{NCON,			"NCON",			0x10, 4},
	{NCOD,			"NCOD",			0x14, 4},
	{PLL_M,			"PLL M",		0x18, 2},
	{PLL_N,			"PLL N",		0x1A, 2},
	{PLL_PD,		"PLL PD",		0x1C, 2},
	{SHP,			"SHP",			0x24, 2},
	{FLK,			"FLK",			0x26, 2},
	{GPIO,			"GPIO",			0x28, 2},
	{ID,			"ID",			0x32, 2},
	{STATUS_PORT,	"Status Port",	0x34, 2},
	{FIFO_SP,		"FIFO_SP",		0x36, 2},
	{FIFO_LAT,		"FIFO_LAT",		0x38, 2},
	{VSOUT_TOTAL,	"VSOUT_TOAL",	0x3A, 2},
	{VSOUT_START,	"VSOUT_START",	0x3C, 2},
	{VSOUT_END,		"VSOUT_END",	0x3E, 2},
	{CHR_FREQ,		"CHR_FREQ",		0x40, 4},
	{CHR_PHASE,		"CHR_PHASE",	0x44, 1},
	{MISC_45,		"MISC_45",		0x45, 1},
	{MISC_46,		"MISC_46",		0x46, 1},
	{MISC_47,		"MISC_47",		0x47, 1},
	{HSYNC_WID,		"HSYNC_WID",	0x48, 1},
	{BURST_WID,		"BURST_WID",	0x49, 1},
	{BPORCH,		"BPORCH",		0x4A, 1},
	{CB_BURST,		"CB_BURST",		0x4B, 1},
	{CR_BURST,		"CR_BURST",		0x4C, 1},
	{MISC_4D,		"MISC_4D",		0x4D, 1},
	{BLACK_LVL,		"BLACK_LVL",	0x4E, 2},
	{BLANK_LVL,		"BLANK_LVL",	0x50, 2},
	{NUM_LINES,		"NUM_LINES",	0x57, 2},
	{WHITE_LVL,		"WHITE_LVL",	0x5E, 2},
	{CB_GAIN,		"CB_GAIN",		0x60, 1},
	{CR_GAIN,		"CR_GAIN",		0x62, 1},
	{TINT,			"TINT",			0x65, 1},
	{BR_WAY,		"BR_WAY",		0x69, 2},
	{FR_PORCH,		"FR_PORCH",		0x6C, 1},
	{NUM_PIXELS,	"NUM_PIXELS",	0x71, 2},
	{FIRST_LINE,	"1ST_LINE",		0x73, 1},
	{MISC_74,		"MISC_74",		0x74, 1},
	{SYNC_LVL,		"SYNC_LVL",		0x75, 1},
	{VBI_BL_LVL,	"VBI_BL_LVL",	0x7C, 2},
	{SOFT_RST,		"SOFT_RST",		0x7E, 1},
	{ENC_VER,		"ENC_VER",		0x7F, 1},
	{WSS_CONFIG,	"WSS_CONFIG",	0x80, 1},
	{WSS_CLK,		"WSS_CLK",		0x81, 2},
	{WSS_DATAF1,	"WSS_DATAF1",	0x83, 3},
	{WSS_DATAF0,	"WSS_DATAF0",	0x86, 3},
	{WSS_LNF1,		"WSS_LNF1",		0x89, 1},
	{WSS_LNF0,		"WSS_LNF0",		0x8A, 1},
	{WSS_LVL,		"WSS_LVL",		0x8B, 2},
	{MISC_8D,		"MISC_8D",		0x8D, 1},
	{VID_CNTRL0,	"VID_CNTRL0",	0x92, 2},
	{HD_FP_SYNC,	"HD_FP_SYNC",	0x94, 2},
	{HD_YOFF_BP,	"HD_YOFF_BP",	0x96, 2},
	{SYNC_DL,		"SYNC_DL",		0x98, 2},
	{LD_DET,		"LD_DET",		0x9C, 2},
	{DAC_CNTL,		"DAC_CNTL",		0x9E, 2},
	{PWR_MGMT,		"PWR_MGMT",		0xA0, 2},
	{RED_MTX,		"RED_MTX",		0xA2, 2},
	{GRN_MTX,		"GRN_MTX",		0xA4, 2},
	{BLU_MTX,		"BLU_MTX",		0xA6, 2},
	{RED_SCL,		"RED_SCL",		0xA8, 2},
	{GRN_SCL,		"GRN_SCL",		0xAA, 2},
	{BLU_SCL,		"BLU_SCL",		0xAC, 2},
	{CC_F1,			"CC_F1",		0xAE, 2},
	{CC_F2,			"CC_F2",		0xB0, 2},
	{CCC,			"CCC",			0xB2, 2},
	{CCBV,			"CCBV",			0xB4, 2},
	{CC_BKS,		"CC_BKS",		0xB6, 2},
	{HACT_ST,		"HACT_ST",		0xB8, 2},
	{HACK_WD,		"HACK_WD",		0xBA, 2},
	{VACT_ST,		"VACT_ST",		0xBC, 2},
	{VACT_HT,		"VACT_HT",		0xBE, 2},
	{PR_PB,			"PR & PB",		0xC0, 2},
	{Y_BW,			"Y_BW",			0xC2, 2},
	{QPR,			"QPR",			0xC4, 2},
	{UNDEFINED_REGISTER}
};

typedef struct
{
	FOCUS_REGISTER_ID id;
	unsigned long value;
} FOCUS_REGISTER_VALUE;

// FS453 192x176	HTotal=240, VTotal=195, PCLK=2,805,195Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_192x176[] =
{
	{IHO,			0x0001	},
	{IVO,			0x0003	},
	{IHW,			0x00C0	},
	{VSC,			0xB13B	},
	{HSC,			0x7000	},
	{BYPASS,		0x0000	},
	{CR,			0x2000	},
	{MISC,			0x0103	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x349F	},
	{PLL_N,			0x00A4	},
	{PLL_PD,		0x4545	},
	{FIFO_LAT,		0x0140	},
	{VID_CNTRL0,	0x0340	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 192x176	***PAL***  HTotal=240, VTotal=195, PCLK=2,340,000Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_192x176_PAL[] =
{
	{IHO,			0x0001	},
	{IVO,			0x0003	},
	{IHW,			0x00C0	},
	{VSC,			0x3483	},
	{HSC,			0x7000	},
	{BYPASS,		0x0000	},
	{CR,			0x2100	},		// bit 8 is PAL
	{MISC,			0x0103	},
	{MISC_74,		0x0059	},		// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x4397	},
	{PLL_N,			0x0077	},
	{PLL_PD,		0x5959	},
	{FIFO_LAT,		0x0140	},
	{VID_CNTRL0,	0x0340	},
	{CHR_FREQ,		0xCB8A092A},	// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},		// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 220x176	HTotal=264, VTotal=195, PCLK=3,085,714Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_220x176[] =
{
	{IHO,			0x0001	},
	{IVO,			0x0003	},
	{IHW,			0x00DC	},
	{VSC,			0xB13B	},
	{HSC,			0x5100	},
	{BYPASS,		0x0000	},
	{CR,			0x2000	},
	{MISC,			0x0103	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x4397	},
	{PLL_N,			0x0068	},
	{PLL_PD,		0x4D4D	},
	{FIFO_LAT,		0x00FA	},
	{VID_CNTRL0,	0x0340	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 220x176	***PAL***  HTotal=264, VTotal=195, PCLK=2,574,000Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_220x176_PAL[] =
{
	{IHO,			0x0001	},
	{IVO,			0x0003	},
	{IHW,			0x00DC	},
	{VSC,			0x3483	},
	{HSC,			0x5100	},
	{BYPASS,		0x0000	},
	{CR,			0x2100	},		// bit 8 is PAL
	{MISC,			0x0103	},
	{MISC_74,		0x0059	},		// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x36A3	},
	{PLL_N,			0x00C7	},
	{PLL_PD,		0x5959	},
	{FIFO_LAT,		0x00FA	},
	{VID_CNTRL0,	0x0340	},
	{CHR_FREQ,		0xCB8A092A},	// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},		// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 240x320	HTotal=286, VTotal=385, PCLK=6.6MHz
static const FOCUS_REGISTER_VALUE register_set_sdtv_240x320[] =
{
	{IHO,			0x001B	},
	{IVO,			0x0014	},
	{IHW,			0x00F0	},
	{VSC,			0x5D17	},
	{HSC,			0x1000	},
	{BYPASS,		0x0000	},
	{CR,			0x2000	},
	{MISC,			0x0113	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x12F1	},		// 0x18
	{PLL_N,			0x00AE	},		// 0x1A
	{PLL_PD,		0x1111	},		// 0x1C
	{FIFO_LAT,		0x0042	},
	{VID_CNTRL0,	0x0340	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 240x320	***PAL***  HTotal=260, VTotal=384, PCLK=4,992,000Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_240x320_PAL[] =
{
	{IHO,			0x001B	},
	{IVO,			0x0014	},
	{IHW,			0x00F0	},
	{VSC,			0x5D17	},
	{HSC,			0x1000	},
	{BYPASS,		0x0000	},
	{CR,			0x2100	},		// bit 8 is PAL
	{MISC,			0x0113	},
	{MISC_74,		0x0059	},		// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x232F	},		// 0x18
	{PLL_N,			0x0095	},		// 0x1A
	{PLL_PD,		0x1D1D	},		// 0x1C
	{FIFO_LAT,		0x0042	},
	{VID_CNTRL0,	0x0340	},
	{CHR_FREQ,		0xCB8A092A},	// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},		// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 256x192	HTotal=308, VTotal=210, PCLK=3,876,923Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_256x192[] =
{
	{IHO,			0x0001	},
	{IVO,			0x0003	},
	{IHW,			0x0100	},
	{VSC,			0x8000	},
	{HSC,			0x3400	},
	{BYPASS,		0x000A	},
	{CR,			0x2000	},
	{MISC,			0x0103	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x4257	},
	{PLL_N,			0x004D	},
	{PLL_PD,		0x3636	},
	{FIFO_LAT,		0x00FA	},
	{VID_CNTRL0,	0x0340	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 256x192	***PAL*** HTotal=312, VTotal=225, PCLK=3,510,000Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_256x192_PAL[] =
{
	{IHO,			0x0001	},
	{IVO,			0x0003	},
	{IHW,			0x0100	},
	{VSC,			0x7FFF	},
	{HSC,			0x3400	},
	{BYPASS,		0x000A	},
	{CR,			0x2100	},		// bit 8 is PAL
	{MISC,			0x0103	},
	{MISC_74,		0x0059	},		// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x2397	},		// 0x18
	{PLL_N,			0x0095	},		// 0x1A
	{PLL_PD,		0x2F2F	},		// 0x1C
	{FIFO_LAT,		0x00FA	},
	{VID_CNTRL0,	0x0340	},
	{CHR_FREQ,		0xCB8A092A},	// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},		// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 320x240	HTotal=385, VTotal=286, PCLK=6.6MHz
static const FOCUS_REGISTER_VALUE register_set_sdtv_320x240[] =
{
	{IHO,			0x001B	},
	{IVO,			0x0014	},
	{IHW,			0x0140	},
	{VSC,			0x7FFF	},
	{HSC,			0x1000	},
	{BYPASS,		0x0000	},
	{CR,			0x2000	},
	{MISC,			0x0113	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x3257	},		// 0x18
	{PLL_N,			0x0068	},		// 0x1A
	{PLL_PD,		0x1717	},		// 0x1C
	{FIFO_LAT,		0x0042	},
	{VID_CNTRL0,	0x0340	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 320x240	***PAL*** HTotal=384, VTotal=285, PCLK=5,472,000Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_320x240_PAL[] =
{
	{IHO,			0x001B	},
	{IVO,			0x0014	},
	{IHW,			0x0140	},
	{VSC,			0x7FFF	},
	{HSC,			0x1000	},
	{BYPASS,		0x000A	},
	{CR,			0x2100	},		// bit 8 is PAL
	{MISC,			0x0103	},
	{MISC_74,		0x0059	},		// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x124F	},		// 0x18
	{PLL_N,			0x0095	},		// 0x1A
	{PLL_PD,		0x1313	},		// 0x1C
	{FIFO_LAT,		0x0042	},
	{VID_CNTRL0,	0x0340	},
	{CHR_FREQ,		0xCB8A092A},	// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},		// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 440x234	HTotal=528, VTotal=256, PCLK=8,101,978Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_440x234[] =
{
	{IHO,			0x001B	},
	{IVO,			0x0014	},
	{IHW,			0x01B8	},
	{VSC,			0x0D00	},
	{HSC,			0x5100	},
	{BYPASS,		0x000A	},
	{CR,			0x2000	},
	{MISC,			0x0103	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x57EF	},		// 0x18
	{PLL_N,			0x00C2	},		// 0x1A
	{PLL_PD,		0x2222	},		// 0x1C
	{FIFO_LAT,		0x0042	},
	{VID_CNTRL0,	0x0340	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 440x234	***PAL*** HTotal=528, VTotal=255, PCLK=6,732,000Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_440x234_PAL[] =
{
	{IHO,			0x001B	},
	{IVO,			0x0014	},
	{IHW,			0x01B8	},
	{VSC,			0x7373	},
	{HSC,			0x5100	},
	{BYPASS,		0x000A	},
	{CR,			0x2100	},		// bit 8 is PAL
	{MISC,			0x0103	},
	{MISC_74,		0x0059	},		// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x35C7	},		// 0x18
	{PLL_N,			0x00C7	},		// 0x1A
	{PLL_PD,		0x1D1D	},		// 0x1C
	{FIFO_LAT,		0x0042	},
	{VID_CNTRL0,	0x0340	},
	{CHR_FREQ,		0xCB8A092A},	// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},		// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 480x272	HTotal=550, VTotal=312, PCLK=10,285,714Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_480x272[] =
{
	{IHO,			0x001B	},
	{IVO,			0x0014	},
	{IHW,			0x01E0	},
	{VSC,			0xAEC5	},
	{HSC,			0x4000	},
	{BYPASS,		0x000A	},
	{CR,			0x2000	},
	{MISC,			0x0103	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x317F	},		// 0x18
	{PLL_N,			0x004A	},		// 0x1A
	{PLL_PD,		0x0D0D	},		// 0x1C
	{FIFO_LAT,		0x0042	},
	{VID_CNTRL0,	0x0340	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 640x480    HTotal=880, VTotal=540, PCLK=28,483,516Hz  (Without NCO)
static const FOCUS_REGISTER_VALUE register_set_sdtv[] =
{
	{IHO,			0x006D	},
	{IVO,			0x0000	},
	{IHW,			0x0280  },
	{VSC,			0xF8E4	},
	{HSC,			0x1000	},
	{BYPASS,		0x0000	},
	{CR,			0x2200	},
	{MISC,			0x0103	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x422F	},
	{PLL_N,			0x005A	},
	{PLL_PD,		0x0505	},
	{FIFO_LAT,		0x0082	},
	{VID_CNTRL0,	0x0340	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 640x480
static const FOCUS_REGISTER_VALUE register_set_vga[] =
{
	{IHO,			0x006D	},
	{IVO,			0x0000	},
	{IHW,			0x0280  },
	{VSC,			0xF8E4	},
	{HSC,			0x1000	},
	{BYPASS,		0x0000	},
	{CR,			0x2200	},
	{MISC,			0x0103	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x422F	},
	{PLL_N,			0x005A	},
	{PLL_PD,		0x0505	},
	{FIFO_LAT,		0x0082	},
	{VID_CNTRL0,	0x0340	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS453 640x480	***PAL*** HTotal=768, VTotal=525, PCLK=20,160,000Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_PAL[] =
{
	{IHO,			0x006D	},
	{IVO,			0x0000	},
	{IHW,			0x0280  },
	{VSC,			0xF8E4	},
	{HSC,			0x1000	},
	{BYPASS,		0x0000	},
	{CR,			0x2100	},		// bit 8 is PAL
	{MISC,			0x0103	},
	{MISC_74,		0x0059	},		// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x128F	},
	{PLL_N,			0x0095	},
	{PLL_PD,		0x0505	},
	{FIFO_LAT,		0x0082	},
	{VID_CNTRL0,	0x0340	},
	{CHR_FREQ,		0xCB8A092A},	// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},		// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

//  FS453 720x480   HTotal=858, VTotal=525, PCLK=27MHz
static const FOCUS_REGISTER_VALUE register_set_sdtv_720x480_overscan[] =
{
	{IHO,			0x001B	},
	{IVO,			0x0003	},
	{IHW,			0x02D0	},
	{VSC,			0x0000	},
	{HSC,			0x0000	},
	{BYPASS,		0x0000	},
	{CR,			0x2000	},
	{MISC,			0x0103	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x3409	},
	{PLL_N,			0x00AE	},
	{PLL_PD,		0x0505	},
	{FIFO_LAT,		0x0082	},
	{BURST_WID,		0x0044	},
	{CB_BURST,		0x0042	},
	{WHITE_LVL,		0x03CB	},
	{CB_GAIN,		0x0098	},
	{CR_GAIN,		0x0098	},
	{VID_CNTRL0,	0x0340	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

//  FS453 720x576	***PAL***  HTotal=864, VTotal=625, PCLK=27MHz
static const FOCUS_REGISTER_VALUE register_set_sdtv_720x576_PAL[] =
{
	{IHO,			0x001B	},
	{IVO,			0x0003	},
	{IHW,			0x02D0	},
	{VSC,			0x0000	},
	{HSC,			0x0000	},
	{BYPASS,		0x0000	},
	{CR,			0x2100	},	// PAL in
	{MISC,			0x0103	},
	{MISC_74,		0x0059	},	// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x1247	},
	{PLL_N,			0x0095	},
	{PLL_PD,		0x0303	},
	{FIFO_LAT,		0x0082	},
	{VID_CNTRL0,	0x0340	},
	{CHR_FREQ,		0xCB8A092A},// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},	// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

//  FS453 800x600	HTotal=975, VTotal=650, PCLK=37,987,013Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_800x600[] =
{
	{IHO,			0x0031	},
	{IVO,			0x0004	},
	{IHW,			0x0320	},
	{VSC,			0xCEC5	},
	{HSC,			0x00F3	},
	{BYPASS,		0x0000	},
	{CR,			0x2000	},
	{MISC,			0x0103	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x2279	},		// M - 17
	{PLL_N,			0x0099	},		// N - 1
	{PLL_PD,		0x0202	},		// P - 1
	{FIFO_LAT,		0x0080	},
	{VID_CNTRL0,	0x0340	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

//  FS453 800x600_PAL  ***PAL***	HTotal=960, VTotal=650, PCLK=31,200,000Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_800x600_PAL[] =
{
	{IHO,			0x0031  },
	{IVO,			0x0004  },
	{IHW,			0x0320  },
	{VSC,			0xF627  },
	{HSC,			0x00F3  },
	{BYPASS,		0x0000  },
	{CR,			0x2100  },	// PAL in
	{MISC,			0x0103  },
	{MISC_74,		0x0059  },	// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x332F  },
	{PLL_N,			0x0077  },
	{PLL_PD,		0x0505  },
	{FIFO_LAT,		0x00a4  },
	{VID_CNTRL0,	0x0340  },
	{CHR_FREQ,		0xCB8A092A},// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},	// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4  },
	{PWR_MGMT,		0x0200  },
	{UNDEFINED_REGISTER}
};

//  FS453 1024x768	HTotal=1365, VTotal=840, PCLK=68,727,273Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_1024x768[] =
{
	{IHO,			0x0063	},
	{IVO,			0x0027	},
	{IHW,			0x0200	},
	{VSC,			0xA000	},
	{HSC,			0x3400	},
	{BYPASS,		0x000A	},
	{CR,			0x2000	},
	{MISC,			0x0183	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x2337	},
	{PLL_N,			0x00A4	},
	{PLL_PD,		0x0103	},
	{FIFO_LAT,		0x0082	},
	{VID_CNTRL0,	0x0000	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

//  FS453 1024x768	***PAL***  HTotal=1240, VTotal=840, PCLK=52,080,000Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_1024x768_PAL[] =
{
	{IHO,			0x0063	},	// Divide by 2 for decimation
	{IVO,			0x0027	},
	{IHW,			0x0200	},	// Divide by 2 for decimation
	{VSC,			0xBE7A	},
	{HSC,			0x3400	},
	{BYPASS,		0x000A	},
	{CR,			0x2100	},	// PAL in
	{MISC,			0x0103	},
	{MISC_74,		0x0059	},	// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x36B7	},
	{PLL_N,			0x00E0	},
	{PLL_PD,		0x0306	},	// 2*P for decimation mode
	{FIFO_LAT,		0x00A0	},
	{VID_CNTRL0,	0x0340	},
	{CHR_FREQ,		0xCB8A092A},// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},	// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

//  FS453 1280x720	HTotal=1650, VTotal=788, PCLK=77,934,066Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_1280x720[] =
{
	{IHO,			0x0079	},
	{IVO,			0x000B	},
	{IHW,			0x0280	},
	{VSC,			0xAA8F	},
	{HSC,			0x1000	},
	{BYPASS,		0x000A	},
	{CR,			0x2000	},
	{MISC,			0x0183	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x4617	},
	{PLL_N,			0x00B5	},
	{PLL_PD,		0x0204	},
	{FIFO_LAT,		0x00A0	},
	{VID_CNTRL0,	0x0000	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

//  FS453 1280x720	***PAL***  HTotal=1530, VTotal=780, PCLK=59,670,000Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_1280x720_PAL[] =
{
	{IHO,			0x0079	},
	{IVO,			0x000B	},
	{IHW,			0x0280	},
	{VSC,			0xCD21	},
	{HSC,			0x1000	},
	{BYPASS,		0x000A	},
	{CR,			0x2100	},	// PAL in
	{MISC,			0x0103	},
	{MISC_74,		0x0059	},	// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x36D7	},
	{PLL_N,			0x00C7	},
	{PLL_PD,		0x0306	},	// 2*P for decimation mode
	{FIFO_LAT,		0x00A0	},
	{VID_CNTRL0,	0x0340	},
	{CHR_FREQ,		0xCB8A092A},// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},	// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

//  FS453 1366x768	HTotal=1640, VTotal=840, PCLK=82,573,427Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_1366x768[] =
{
	{IHO,			0x0060	},		// Divide by 2 for decimation
	{IVO,			0x0024	},
	{IHW,			0x02AA	},		// Divide by 2 for decimation
	{VSC,			0xA000	},
	{HSC,			0x0700	},
	{BYPASS,		0x000A	},
	{CR,			0x2000	},
	{MISC,			0x0183	},
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x350F	},
	{PLL_N,			0x008E	},
	{PLL_PD,		0x0205	},		// 2*P for decimation mode
	{FIFO_LAT,		0x00A0	},
	{VID_CNTRL0,	0x0000	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

//  FS453 1366x768	***PAL***  HTotal=1650, VTotal=840, PCLK=69,300,000Hz
static const FOCUS_REGISTER_VALUE register_set_sdtv_1366x768_PAL[] =
{
	{IHO,			0x0060	},	// Divide by 2 for decimation
	{IVO,			0x0024	},
	{IHW,			0x02AB	},	// Divide by 2 for decimation
	{VSC,			0xBE7A	},
	{HSC,			0x0700	},
	{BYPASS,		0x0000	},
	{CR,			0x2100	},	// PAL in
	{MISC,			0x0103	},
	{MISC_74,		0x0059	},	// PAL encoder
	{NCON,			0x000000},
	{NCOD,			0x000000},
	{PLL_M,			0x2257	},
	{PLL_N,			0x0077	},
	{PLL_PD,		0x0102	},	// 2*P for decimation mode
	{FIFO_LAT,		0x00A0	},
	{VID_CNTRL0,	0x0340	},
	{CHR_FREQ,		0xCB8A092A},// PAL encoder settings
	{MISC_46,		0x0081	},
	{MISC_47,		0x0080	},
	{BURST_WID,		0x0040	},
	{BPORCH,		0x008A	},
	{CB_BURST,		0x002C	},
	{CR_BURST,		0x001F	},
	{BLACK_LVL,		0x00FB	},
	{BLANK_LVL,		0x00FB	},
	{NUM_LINES,		0x019C	},	// 625 lines (swizzle)
	{CB_GAIN,		0x0091	},
	{CR_GAIN,		0x0091	},
	{BR_WAY,		0x001A	},
	{FR_PORCH,		0x0018	},
	{VBI_BL_LVL,	0x00FB	},
	{DAC_CNTL,		0x00E4	},
	{PWR_MGMT,		0x0200	},
	{UNDEFINED_REGISTER}
};

// FS47X
typedef enum
{
	FS47X_QPR,
	FS47X_PDIV,
	FS47X_PLL_AMP,
	FS47X_PLL_VGA,
	FS47X_PLL_TV,
	FS47X_PLL_GCC,
	FS47X_IHO,
	FS47X_IVO,
	FS47X_IHW,
	FS47X_VSC,
	FS47X_VSC2,
	FS47X_HSC,
	FS47X_CR,
	FS47X_MISC1,
	FS47X_RTCNL,
	FS47X_RTCNH,
	FS47X_RTCDL,
	FS47X_RTCDH,
	FS47X_SHP,
	FS47X_FLK,
	FS47X_ID,
	FS47X_STATUS,
	FS47X_FIFO_LAT,
	FS47X_VWIDTH,
	FS47X_VID_CNTRL0,
	FS47X_CHR_FREQ0,
	FS47X_CHR_FREQ1,
	FS47X_ENC_MISC,
	FS47X_RGB_YUV,
	FS47X_BURST_WID,
	FS47X_BPORCH_WID,
	FS47X_CBCR_BURST,
	FS47X_SLV_CNTRL0,
	FS47X_BLACK_LVL,
	FS47X_BLANK_LVL,
	FS47X_NUM_LINES,
	FS47X_WHITE_LVL,
	FS47X_CBCR_GAIN,
	FS47X_BRZ_WAY,
	FS47X_ENC_STUFF,
	FS47X_SYNC_LVL,
	FS47X_VBI_BL_LVL,
	FS47X_DAC_CNTL,
	FS47X_RED_MATRIX,
	FS47X_GRN_MATRIX,
	FS47X_BLU_MATRIX,
	FS47X_RED_SCALE,
	FS47X_GRN_SCALE,
	FS47X_BLU_SCALE,
	FS47X_BYPASS,
	FS47X_PWR_MGMT,
	FS47X_UNDEFINED_REG
} FS47X_REGISTER_ID;

typedef struct
{
	FS47X_REGISTER_ID id;
	char* description;
	uint8 address;
	uint8 size;
} FS47X_REGISTER;

// FS471 registers
static const FS47X_REGISTER fs47x_registers[] =
{
	{FS47X_QPR,			"QPR",			0xC4, 2},
	{FS47X_PDIV,		"PDIV",			0xC6, 2},
	{FS47X_PLL_AMP,		"PLL_AMP",		0xC8, 2},
	{FS47X_PLL_VGA,		"PLL_VGA",		0xCA, 2},
	{FS47X_PLL_TV,		"PLL_TV",		0xCC, 2},
	{FS47X_PLL_GCC,		"PLL_GCC",		0xCE, 2},
	{FS47X_IHO,			"IHO",			0x00, 2},
	{FS47X_IVO,			"IVO",			0x02, 2},
	{FS47X_IHW,			"IHW",			0x04, 2},
	{FS47X_VSC,			"VSC",			0x06, 2},
	{FS47X_VSC2,		"VSC2",			0x08, 2},
	{FS47X_HSC,			"HSC",			0x0A, 2},
	{FS47X_CR,			"CR",			0x0C, 2},
	{FS47X_MISC1,		"MISC1",		0x0E, 2},
	{FS47X_RTCNL,		"RTCNL",		0x12, 2},
	{FS47X_RTCNH,		"RTCNH",		0x14, 2},
	{FS47X_RTCDL,		"RTCDL",		0x16, 2},
	{FS47X_RTCDH,		"RTCDH",		0x18, 2},
	{FS47X_SHP,			"SHP",			0x20, 2},
	{FS47X_FLK,			"FLK",			0x22, 2},
	{FS47X_ID,			"ID",			0x2E, 2},
	{FS47X_STATUS,		"STATUS",		0x30, 2},
	{FS47X_FIFO_LAT,	"FIFO_LAT",		0x34, 2},
	{FS47X_VWIDTH,		"VWIDTH",		0x36, 2},
	{FS47X_VID_CNTRL0,	"VID_CNTRL0",	0x3C, 2},
	{FS47X_CHR_FREQ0,	"CHR_FREQ0",	0x40, 2},
	{FS47X_CHR_FREQ1,	"CHR_FREQ1",	0x42, 2},
	{FS47X_ENC_MISC,	"ENC_MISC",		0x46, 2},
	{FS47X_RGB_YUV,		"RGB_YUV",		0x48, 2},
	{FS47X_BURST_WID,	"BURST_WID",	0x4C, 2},
	{FS47X_BPORCH_WID,	"BPORCH_WID",	0x4E, 2},
	{FS47X_CBCR_BURST,	"CBCR_BURST",	0x50, 2},
	{FS47X_SLV_CNTRL0,	"SLV_CNTRL0",	0x52, 2},
	{FS47X_BLACK_LVL,	"BLACK_LVL",	0x54, 2},
	{FS47X_BLANK_LVL,	"BLANK_LVL",	0x56, 2},
	{FS47X_NUM_LINES,	"NUM_LINES",	0x5E, 2},
	{FS47X_WHITE_LVL,	"WHITE_LVL",	0x64, 2},
	{FS47X_CBCR_GAIN,	"CBCR_GAIN",	0x66, 2},
	{FS47X_BRZ_WAY,		"BRZ_WAY",		0x70, 2},
	{FS47X_ENC_STUFF,	"ENC_STUFF",	0x7E, 2},
	{FS47X_SYNC_LVL,	"SYNC_LVL",	    0x80, 2},
	{FS47X_VBI_BL_LVL,	"VBI_BL_LVL",	0x88, 2},
	{FS47X_DAC_CNTL,	"DAC_CNTL",		0xA0, 2},
	{FS47X_RED_MATRIX,	"RED_MATRIX",	0xA2, 2},
	{FS47X_GRN_MATRIX,	"GRN_MATRIX",	0xA4, 2},
	{FS47X_BLU_MATRIX,	"BLU_MATRIX",	0xA6, 2},
	{FS47X_RED_SCALE,	"RED_SCALE",	0xA8, 2},
	{FS47X_GRN_SCALE,	"GRN_SCALE",	0xAA, 2},
	{FS47X_BLU_SCALE,	"BLU_SCALE",	0xAC, 2},
	{FS47X_BYPASS,		"BYPASS",		0xD0, 2},
	{FS47X_PWR_MGMT,	"PWR_MGMT",		0xD4, 2},
	{FS47X_UNDEFINED_REG}
};

typedef struct
{
	FS47X_REGISTER_ID id;
	unsigned long value;
} FS47X_REGISTER_VALUE;

// FS471 192x176	HTotal=240, VTotal=195, PCLK=2,805,195Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_192x176[] =
{
	{FS47X_QPR,			0x9C00	},		// 0xC4
	{FS47X_PDIV,		0x0102	},		// 0xC6
	{FS47X_PLL_AMP,		0x11AD	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x002A	},		// 0x00
	{FS47X_IVO,			0x000E	},		// 0x02
	{FS47X_IHW,			0x00C0  },		// 0x04
	{FS47X_VSC,			0xB13B	},		// 0x06
	{FS47X_VSC2,		0x0001	},		// 0x08
	{FS47X_HSC,			0x7000	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0xC103	},		// 0x0E
	{FS47X_RTCNL,		0x5AC8	},		// 0x12
	{FS47X_RTCNH,		0x000A	},		// 0x14
	{FS47X_RTCDL,		0x4F5B	},		// 0x16
	{FS47X_RTCDH,		0x000A	},		// 0x18
	{FS47X_FIFO_LAT,	0x0140	},		// 0x34
	{FS47X_VWIDTH,		0x020D	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 192x176		***PAL***  HTotal=240, VTotal=195, PCLK=2,340,000Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_192x176_PAL[] =
{
	{FS47X_QPR,			0x9C04	},		// 0xC4 PAL
	{FS47X_PDIV,		0x0101	},		// 0xC6
	{FS47X_PLL_AMP,		0x415D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x002A	},		// 0x00
	{FS47X_IVO,			0x0008	},		// 0x02
	{FS47X_IHW,			0x00C0  },		// 0x04
	{FS47X_VSC,			0x3483	},		// 0x06
	{FS47X_VSC2,		0x0002	},		// 0x08
	{FS47X_HSC,			0x7000	},		// 0x0A
	{FS47X_CR,			0x0100	},		// 0x0C
	{FS47X_MISC1,		0xC103	},		// 0x0E
	{FS47X_RTCNL,		0x91C0	},		// 0x12
	{FS47X_RTCNH,		0x0008	},		// 0x14
	{FS47X_RTCDL,		0x3D60	},		// 0x16
	{FS47X_RTCDH,		0x0008	},		// 0x18
	{FS47X_FIFO_LAT,	0x0140	},		// 0x34
	{FS47X_VWIDTH,		0x020D	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},		// 0x40
	{FS47X_CHR_FREQ1,	0x2A09	},		// 0x42
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_RGB_YUV,		0x0008	},		// 0x48
	{FS47X_BURST_WID,	0x0044	},		// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},		// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},		// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},		// 0x56
	{FS47X_NUM_LINES,	0x9C01	},		// 0x5E
	{FS47X_CBCR_GAIN,	0x9191	},		// 0x66
	{FS47X_BRZ_WAY,		0x181A	},		// 0x70
	{FS47X_ENC_STUFF,	0x0059	},		// 0x7E
	{FS47X_VBI_BL_LVL,	0x3E03	},		// 0x88
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 220x176	HTotal=264, VTotal=195, PCLK=3,085,714Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_220x176[] =
{
	{FS47X_QPR,			0x9C00	},		// 0xC4
	{FS47X_PDIV,		0x0102	},		// 0xC6
	{FS47X_PLL_AMP,		0x118D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x0024	},		// 0x00
	{FS47X_IVO,			0x0006	},		// 0x02
	{FS47X_IHW,			0x00DC  },		// 0x04
	{FS47X_VSC,			0xB13B	},		// 0x06
	{FS47X_VSC2,		0x0001	},		// 0x08
	{FS47X_HSC,			0x5100	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0xC103	},		// 0x0E
	{FS47X_RTCNL,		0x9AC4	},		// 0x12
	{FS47X_RTCNH,		0x000A	},		// 0x14
	{FS47X_RTCDL,		0x4F5B	},		// 0x16
	{FS47X_RTCDH,		0x000A	},		// 0x18
	{FS47X_FIFO_LAT,	0x0100	},		// 0x34
	{FS47X_VWIDTH,		0x020D	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 220x176		***PAL***  HTotal=264, VTotal=195, PCLK=2,574,000Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_220x176_PAL[] =
{
	{FS47X_QPR,			0x9C04	},		// 0xC4  PAL
	{FS47X_PDIV,		0x0101	},		// 0xC6
	{FS47X_PLL_AMP,		0x412D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_IHO,			0x0024	},		// 0x00
	{FS47X_IVO,			0x0006	},		// 0x02
	{FS47X_IHW,			0x00DC  },		// 0x04
	{FS47X_VSC,			0x3483	},		// 0x06
	{FS47X_VSC2,		0x0002	},		// 0x08
	{FS47X_HSC,			0x5100	},		// 0x0A
	{FS47X_CR,			0x0100	},		// 0x0C PAL
	{FS47X_MISC1,		0xC103	},		// 0x0E
	{FS47X_RTCNL,		0x3F7C	},		// 0x12
	{FS47X_RTCNH,		0x0008	},		// 0x14
	{FS47X_RTCDL,		0x3D60	},		// 0x16
	{FS47X_RTCDH,		0x0008	},		// 0x18
	{FS47X_FIFO_LAT,	0x0100	},		// 0x34
	{FS47X_VWIDTH,		0x020D	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},		// 0x40 PAL
	{FS47X_CHR_FREQ1,	0x2A09	},		// 0x42 PAL
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_RGB_YUV,		0x0008	},		// 0x48
	{FS47X_BURST_WID,	0x0044	},		// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},		// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},		// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},		// 0x56
	{FS47X_NUM_LINES,	0x9C01	},		// 0x5E PAL=625
	{FS47X_CBCR_GAIN,	0x9191	},		// 0x66
	{FS47X_BRZ_WAY,		0x181A	},		// 0x70
	{FS47X_ENC_STUFF,	0x0059	},		// 0x7E PAL
	{FS47X_VBI_BL_LVL,	0x3E03	},		// 0x88
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 240x320	HTotal=286, VTotal=385, PCLK=6.6MHz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_240x320[] =
{
	{FS47X_QPR,			0x9C00	},		// 0xC4
	{FS47X_PDIV,		0x0105	},		// 0xC6
	{FS47X_PLL_AMP,		0x416D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x0000	},		// 0x00
	{FS47X_IVO,			0x0012	},		// 0x02
	{FS47X_IHW,			0x0114  },		// 0x04
	{FS47X_VSC,			0x5D17	},		// 0x06
	{FS47X_VSC2,		0x0000	},		// 0x08
	{FS47X_HSC,			0x1400	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0xC103	},		// 0x0E
	{FS47X_RTCNL,		0x0077	},		// 0x12
	{FS47X_RTCNH,		0x0015	},		// 0x14
	{FS47X_RTCDL,		0x9EB6	},		// 0x16
	{FS47X_RTCDH,		0x0014	},		// 0x18
	{FS47X_FIFO_LAT,	0x0060	},		// 0x34
	{FS47X_VWIDTH,		0x011E	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 240x320		***PAL***  HTotal=260, VTotal=384, PCLK=4,992,000Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_240x320_PAL[] =
{
	{FS47X_QPR,			0x9C00	},		// 0xC4
	{FS47X_PDIV,		0x0105	},		// 0xC6
	{FS47X_PLL_AMP,		0x416D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x0000	},		// 0x00
	{FS47X_IVO,			0x0012	},		// 0x02
	{FS47X_IHW,			0x0114  },		// 0x04
	{FS47X_VSC,			0x5D17	},		// 0x06
	{FS47X_VSC2,		0x0000	},		// 0x08
	{FS47X_HSC,			0x1400	},		// 0x0A
	{FS47X_CR,			0x0100	},		// 0x0C
	{FS47X_MISC1,		0xC103	},		// 0x0E
	{FS47X_RTCNL,		0x0077	},		// 0x12
	{FS47X_RTCNH,		0x0015	},		// 0x14
	{FS47X_RTCDL,		0x9EB6	},		// 0x16
	{FS47X_RTCDH,		0x0014	},		// 0x18
	{FS47X_FIFO_LAT,	0x0060	},		// 0x34
	{FS47X_VWIDTH,		0x011E	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},		// 0x40
	{FS47X_CHR_FREQ1,	0x2A09	},		// 0x42
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_RGB_YUV,		0x0008	},		// 0x48
	{FS47X_BURST_WID,	0x0044	},		// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},		// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},		// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},		// 0x56
	{FS47X_NUM_LINES,	0x9C01	},		// 0x5E
	{FS47X_CBCR_GAIN,	0x9191	},		// 0x66
	{FS47X_BRZ_WAY,		0x181A	},		// 0x70
	{FS47X_ENC_STUFF,	0x0059	},		// 0x7E
	{FS47X_VBI_BL_LVL,	0x3E03	},		// 0x88
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 256x192	HTotal=308, VTotal=210, PCLK=3,876,923Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_256x192[] =
{
	{FS47X_QPR,			0x9C00	},		// 0xC4
	{FS47X_PDIV,		0x0102	},		// 0xC6
	{FS47X_PLL_AMP,		0x112D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x002F	},		// 0x00
	{FS47X_IVO,			0x0004	},		// 0x02
	{FS47X_IHW,			0x0100  },		// 0x04
	{FS47X_VSC,			0x8000	},		// 0x06
	{FS47X_VSC2,		0x0001	},		// 0x08
	{FS47X_HSC,			0x3400	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0xC103	},		// 0x0E
	{FS47X_RTCNL,		0x5CE4	},		// 0x12
	{FS47X_RTCNH,		0x000A	},		// 0x14
	{FS47X_RTCDL,		0x4F5B	},		// 0x16
	{FS47X_RTCDH,		0x000A	},		// 0x18
	{FS47X_FIFO_LAT,	0x0100	},		// 0x34
	{FS47X_VWIDTH,		0x020D	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 256x192	***PAL***  HTotal=312, VTotal=225, PCLK=3,510,000Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_256x192_PAL[] =
{
	{FS47X_QPR,			0x9C04	},		// 0xC4
	{FS47X_PDIV,		0x0102	},		// 0xC6
	{FS47X_PLL_AMP,		0x415D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x002F	},		// 0x00
	{FS47X_IVO,			0x0004	},		// 0x02
	{FS47X_IHW,			0x0100  },		// 0x04
	{FS47X_VSC,			0xC71C	},		// 0x06
	{FS47X_VSC2,		0x0001	},		// 0x08
	{FS47X_HSC,			0x3400	},		// 0x0A
	{FS47X_CR,			0x0100	},		// 0x0C PAL
	{FS47X_MISC1,		0xC103	},		// 0x0E
	{FS47X_RTCNL,		0xDAA0	},		// 0x12
	{FS47X_RTCNH,		0x000C	},		// 0x14
	{FS47X_RTCDL,		0x5C10	},		// 0x16
	{FS47X_RTCDH,		0x000C	},		// 0x18
	{FS47X_FIFO_LAT,	0x0100	},		// 0x34
	{FS47X_VWIDTH,		0x020D	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},		// 0x40 PAL
	{FS47X_CHR_FREQ1,	0x2A09	},		// 0x42 PAL
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_RGB_YUV,		0x0008	},		// 0x48
	{FS47X_BURST_WID,	0x0044	},		// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},		// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},		// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},		// 0x56
	{FS47X_NUM_LINES,	0x9C01	},		// 0x5E PAL=625
	{FS47X_CBCR_GAIN,	0x9191	},		// 0x66
	{FS47X_BRZ_WAY,		0x181A	},		// 0x70
	{FS47X_ENC_STUFF,	0x0059	},		// 0x7E PAL
	{FS47X_VBI_BL_LVL,	0x3E03	},		// 0x88
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 320x240	HTotal=385, VTotal=286, PCLK=6.6MHz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_320x240[] =
{
	{FS47X_QPR,			0x9C00	},		// 0xC4
	{FS47X_PDIV,		0x0105	},		// 0xC6
	{FS47X_PLL_AMP,		0x116D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x0035	},		// 0x00
	{FS47X_IVO,			0x0003	},		// 0x02
	{FS47X_IHW,			0x0140  },		// 0x04
	{FS47X_VSC,			0xD5EE	},		// 0x06
	{FS47X_VSC2,		0x0000	},		// 0x08
	{FS47X_HSC,			0x1000	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0xC103	},		// 0x0E
	{FS47X_RTCNL,		0x0077	},		// 0x12
	{FS47X_RTCNH,		0x0015	},		// 0x14
	{FS47X_RTCDL,		0x9EB6	},		// 0x16
	{FS47X_RTCDH,		0x0014	},		// 0x18
	{FS47X_FIFO_LAT,	0x0070	},		// 0x34
	{FS47X_VWIDTH,		0x011E	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 320x240	***PAL***  HTotal=384, VTotal=285, PCLK=5,472,000Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_320x240_PAL[] =
{
	{FS47X_QPR,			0x9C04	},		// 0xC4
	{FS47X_PDIV,		0x0104	},		// 0xC6
	{FS47X_PLL_AMP,		0x416D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x0035	},		// 0x00
	{FS47X_IVO,			0x000F	},		// 0x02
	{FS47X_IHW,			0x0140  },		// 0x04
	{FS47X_VSC,			0x3167	},		// 0x06
	{FS47X_VSC2,		0x0001	},		// 0x08
	{FS47X_HSC,			0x1000	},		// 0x0A
	{FS47X_CR,			0x0100	},		// 0x0C PAL
	{FS47X_MISC1,		0xC103	},		// 0x0E
	{FS47X_RTCNL,		0xDFC0	},		// 0x12
	{FS47X_RTCNH,		0x0014	},		// 0x14
	{FS47X_RTCDL,		0x9970	},		// 0x16
	{FS47X_RTCDH,		0x0014	},		// 0x18
	{FS47X_FIFO_LAT,	0x0098	},		// 0x34
	{FS47X_VWIDTH,		0x011E	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},		// 0x40 PAL
	{FS47X_CHR_FREQ1,	0x2A09	},		// 0x42 PAL
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_RGB_YUV,		0x0008	},		// 0x48
	{FS47X_BURST_WID,	0x0044	},		// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},		// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},		// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},		// 0x56
	{FS47X_NUM_LINES,	0x9C01	},		// 0x5E PAL=625
	{FS47X_CBCR_GAIN,	0x9191	},		// 0x66
	{FS47X_BRZ_WAY,		0x181A	},		// 0x70
	{FS47X_ENC_STUFF,	0x0059	},		// 0x7E PAL
	{FS47X_VBI_BL_LVL,	0x3E03	},		// 0x88
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 440x234	HTotal=528, VTotal=256, PCLK=8,101,978Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_440x234[] =
{
	{FS47X_QPR,			0x9C00	},		// 0xC4
	{FS47X_PDIV,		0x0106	},		// 0xC6
	{FS47X_PLL_AMP,		0x115D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x004B	},		// 0x00
	{FS47X_IVO,			0x0009	},		// 0x02
	{FS47X_IHW,			0x01B8  },		// 0x04
	{FS47X_VSC,			0x0D00	},		// 0x06
	{FS47X_VSC2,		0x0001	},		// 0x08
	{FS47X_HSC,			0x5100	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0x8103	},		// 0x0E
	{FS47X_RTCNL,		0xC000	},		// 0x12
	{FS47X_RTCNH,		0x0018	},		// 0x14
	{FS47X_RTCDL,		0x0E7F	},		// 0x16
	{FS47X_RTCDH,		0x0018	},		// 0x18
	{FS47X_FIFO_LAT,	0x0090	},		// 0x34
	{FS47X_VWIDTH,		0x011E	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 440x234	***PAL***  HTotal=528, VTotal=255, PCLK=6,732,000Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_440x234_PAL[] =
{
	{FS47X_QPR,			0x9C04	},		// 0xC4 PAL
	{FS47X_PDIV,		0x0105	},		// 0xC6
	{FS47X_PLL_AMP,		0x416D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_IHO,			0x004C	},		// 0x00
	{FS47X_IVO,			0x000F	},		// 0x02
	{FS47X_IHW,			0x01B8  },		// 0x04
	{FS47X_VSC,			0x7373	},		// 0x06
	{FS47X_VSC2,		0x0001	},		// 0x08
	{FS47X_HSC,			0x5100	},		// 0x0A
	{FS47X_CR,			0x0100	},		// 0x0C PAL
	{FS47X_MISC1,		0x0103	},		// 0x0E
	{FS47X_RTCNL,		0xAE38	},		// 0x12
	{FS47X_RTCNH,		0x0019	},		// 0x14
	{FS47X_RTCDL,		0xB820	},		// 0x16
	{FS47X_RTCDH,		0x0018	},		// 0x18
	{FS47X_FIFO_LAT,	0x0090	},		// 0x34
	{FS47X_VWIDTH,		0x011E	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},		// 0x40 PAL
	{FS47X_CHR_FREQ1,	0x2A09	},		// 0x42 PAL
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_RGB_YUV,		0x0008	},		// 0x48
	{FS47X_BURST_WID,	0x0044	},		// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},		// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},		// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},		// 0x56
	{FS47X_NUM_LINES,	0x9C01	},		// 0x5E PAL=625
	{FS47X_CBCR_GAIN,	0x9191	},		// 0x66
	{FS47X_BRZ_WAY,		0x181A	},		// 0x70
	{FS47X_ENC_STUFF,	0x0059	},		// 0x7E PAL
	{FS47X_VBI_BL_LVL,	0x3E03	},		// 0x88
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 480x272	HTotal=550, VTotal=312, PCLK=10,285,714Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_480x272[] =
{
	{FS47X_QPR,			0x9C00	},		// 0xC4
	{FS47X_PDIV,		0x0107	},		// 0xC6
	{FS47X_PLL_AMP,		0x312D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x003B	},		// 0x00
	{FS47X_IVO,			0x0009	},		// 0x02
	{FS47X_IHW,			0x01E0  },		// 0x04
	{FS47X_VSC,			0xAEC5	},		// 0x06
	{FS47X_VSC2,		0x0000	},		// 0x08
	{FS47X_HSC,			0x4000	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0x8103	},		// 0x0E
	{FS47X_RTCNL,		0x7E48	},		// 0x12
	{FS47X_RTCNH,		0x001B	},		// 0x14
	{FS47X_RTCDL,		0x7E48	},		// 0x16
	{FS47X_RTCDH,		0x001B	},		// 0x18
	{FS47X_FIFO_LAT,	0x0090	},		// 0x34
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 640x480	HTotal=880, VTotal=540, PCLK=28,483,516Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv[] =
{
//orig	{FS47X_QPR,			0x9C00	},		// 0xC4 6x4 NTSC,
//orig	{FS47X_PDIV,		0x0115	},		// 0xC6
	{FS47X_PDIV,		0x0015	},		// 0xC6
	{FS47X_PLL_AMP,		0x412D	},		// 0xC8
//orig	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
//orig	{FS47X_PLL_TV,		0x0083	},		// 0xCC
//orig	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_PLL_VGA,		0x0003	},		// 0xCA	// 0x03 for master -- ctg
	{FS47X_PLL_TV,		0x0003	},		// 0xCC // 0x03 for master -- ctg
	{FS47X_PLL_GCC,		0x0003	},		// 0xCE // 0x03 for master -- ctg
	{FS47X_IHO,			0x006d	},		// 0x00
	{FS47X_IVO,			0x0000	},		// 0x02
	{FS47X_IHW,			0x02ba  },		// 0x04
	{FS47X_VSC,			0xF69c	},		// 0x06
	{FS47X_VSC2,		0x0007	},		// 0x08
//orig	{FS47X_HSC,			0x1000	},		// 0x0A
	{FS47X_HSC,			0x0200	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0x0113	},		// 0x0E
	{FS47X_RTCNL,		0x22A0	},		// 0x12
	{FS47X_RTCNH,		0x004C	},		// 0x14
	{FS47X_RTCDL,		0x9B46	},		// 0x16
	{FS47X_RTCDH,		0x004B	},		// 0x18
	{FS47X_FIFO_LAT,	0x00A0	},		// 0x34
	{FS47X_VWIDTH,		0x020D	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0340	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
//orig	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_ENC_MISC,    0x0902  },      // 0x46 // ctg force colorbar
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 640x480		***PAL***  HTotal=768, VTotal=525, PCLK=20,160,000Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_PAL[] =
{
	{FS47X_QPR,			0x9C04	},		// 0xC4 PAL
	{FS47X_PDIV,		0x010F	},		// 0xC6
	{FS47X_PLL_AMP,		0x413D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x0076	},		// 0x00
	{FS47X_IVO,			0x0007	},		// 0x02
	{FS47X_IHW,			0x0280  },		// 0x04
	{FS47X_VSC,			0x30C3	},		// 0x06
	{FS47X_VSC2,		0x0000	},		// 0x08
	{FS47X_HSC,			0x1000	},		// 0x0A
	{FS47X_CR,			0x0100	},		// 0x0C PAL
	{FS47X_MISC1,		0x0103	},		// 0x0E
	{FS47X_RTCNL,		0xAD00	},		// 0x12
	{FS47X_RTCNH,		0x0043	},		// 0x14
	{FS47X_RTCDL,		0xEB00	},		// 0x16
	{FS47X_RTCDH,		0x0041	},		// 0x18
	{FS47X_FIFO_LAT,	0x00A0	},		// 0x34
	{FS47X_VWIDTH,		0x020D	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},		// 0x40
	{FS47X_CHR_FREQ1,	0x2A09	},		// 0x42
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_RGB_YUV,		0x0008	},		// 0x48
	{FS47X_BURST_WID,	0x0044	},		// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},		// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},		// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},		// 0x56
	{FS47X_NUM_LINES,	0x9C01	},		// 0x5E PAL=625
	{FS47X_CBCR_GAIN,	0x9191	},		// 0x66
	{FS47X_BRZ_WAY,		0x181A	},		// 0x70
	{FS47X_ENC_STUFF,	0x0059	},		// 0x7E
	{FS47X_VBI_BL_LVL,	0x3E03	},		// 0x88
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 720x480	HTotal=858, VTotal=525, PCLK=27MHz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_720x480_overscan[] =
{
	{FS47X_PDIV,		0x0114	},		// 0xC6
	{FS47X_PLL_AMP,		0x112D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x0038	},		// 0x00
	{FS47X_IVO,			0x0019	},		// 0x02
	{FS47X_IHW,			0x02D0  },		// 0x04
	{FS47X_VSC,			0x0000	},		// 0x06
	{FS47X_VSC2,		0x0000	},		// 0x08
	{FS47X_HSC,			0x0000	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0x0103	},		// 0x0E
	{FS47X_RTCNL,		0x2B7D	},		// 0x12
	{FS47X_RTCNH,		0x0048	},		// 0x14
	{FS47X_RTCDL,		0x2B7D	},		// 0x16
	{FS47X_RTCDH,		0x0048	},		// 0x18
	{FS47X_FIFO_LAT,	0x00A0	},		// 0x34
	{FS47X_VWIDTH,		0x020D	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CBCR_BURST,	0x0044	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_WHITE_LVL,	0xD303	},		// 0x64
	{FS47X_CBCR_GAIN,	0x9898	},		// 0x66
	{FS47X_BRZ_WAY, 	0x2019	},		// 0x70
	{FS47X_SYNC_LVL,	0x0010	},		// 0x80
	{FS47X_VBI_BL_LVL,	0x4A00	},		// 0x88
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 720x576		***PAL***  HTotal=864, VTotal=625, PCLK=27MHz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_720x576_PAL[] =
{
	{FS47X_PDIV,		0x0114	},		// 0xC6
	{FS47X_PLL_AMP,		0x112D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x0062	},		// 0x00
	{FS47X_IVO,			0x0018	},		// 0x02
	{FS47X_IHW,			0x02D0  },		// 0x04
	{FS47X_VSC,			0x0000	},		// 0x06
	{FS47X_VSC2,		0x0000	},		// 0x08
	{FS47X_HSC,			0x0000	},		// 0x0A
	{FS47X_CR,			0x0100	},		// 0x0C PAL
	{FS47X_MISC1,		0x0103	},		// 0x0E
	{FS47X_RTCNL,		0x8470	},		// 0x12
	{FS47X_RTCNH,		0x0056	},		// 0x14
	{FS47X_RTCDL,		0x8470	},		// 0x16
	{FS47X_RTCDH,		0x0056	},		// 0x18
	{FS47X_FIFO_LAT,	0x00A0	},		// 0x34
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},		// 0x40
	{FS47X_CHR_FREQ1,	0x2A09	},		// 0x42
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_RGB_YUV,		0x0008	},		// 0x48
	{FS47X_BURST_WID,	0x0044	},		// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},		// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},		// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},		// 0x56
	{FS47X_NUM_LINES,	0x9C01	},		// 0x5E PAL=625
	{FS47X_CBCR_GAIN,	0x9191	},		// 0x66
	{FS47X_BRZ_WAY,		0x181A	},		// 0x70
	{FS47X_ENC_STUFF,	0x0059	},		// 0x7E
	{FS47X_VBI_BL_LVL,	0x3E03	},		// 0x88
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 800x600	HTotal=975, VTotal=650, PCLK=37,987,013Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_800x600[] =
{
	{FS47X_PDIV,		0x011D	},		// 0xC6
	{FS47X_PLL_AMP,		0x113D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0083	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_PLL_GCC,		0x0083	},		// 0xCE
	{FS47X_IHO,			0x0077	},		// 0x00
	{FS47X_IVO,			0x001E	},		// 0x02
	{FS47X_IHW,			0x0320  },		// 0x04
	{FS47X_VSC,			0xCEC5	},		// 0x06
	{FS47X_VSC2,		0x0007	},		// 0x08
	{FS47X_HSC,			0x00F3	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0x8103	},		// 0x0E
	{FS47X_RTCNL,		0x5F72	},		// 0x12
	{FS47X_RTCNH,		0x006A	},		// 0x14
	{FS47X_RTCDL,		0x198E	},		// 0x16
	{FS47X_RTCDH,		0x0067	},		// 0x18
	{FS47X_FIFO_LAT,	0x00B0	},		// 0x34
	{FS47X_VWIDTH,		0x028A	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x0000	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 800x600_PAL  ***PAL***	HTotal=960, VTotal=650, PCLK=31,200,000Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_800x600_PAL[] =
{
	{FS47X_QPR,			0x9C04	},	// 0xC4 PAL
	{FS47X_PDIV,		0x0117	},	// 0xC6
	{FS47X_PLL_AMP,		0x412D	},	// 0xC8
	{FS47X_PLL_VGA,		0x0083	},	// 0xCA
	{FS47X_PLL_TV,		0x0083	},	// 0xCC
	{FS47X_IHO,			0x0072	},	// 0x00
	{FS47X_IVO,			0x001D	},	// 0x02
	{FS47X_IHW,			0x0320	},	// 0x04
	{FS47X_VSC,			0xF627	},	// 0x06
	{FS47X_VSC2,		0x0007	},	// 0x08
	{FS47X_HSC,			0x00F3	},	// 0x0A
	{FS47X_CR,			0x0100	},	// 0x0C PAL
	{FS47X_MISC1,		0x0103	},	// 0x0E
	{FS47X_RTCNL,		0xF9C0	},	// 0x12
	{FS47X_RTCNH,		0x0063	},	// 0x14
	{FS47X_RTCDL,		0xE080	},	// 0x16
	{FS47X_RTCDH,		0x0062	},	// 0x18
	{FS47X_FIFO_LAT,	0x00A0	},	// 0x34
	{FS47X_VID_CNTRL0,	0x0000	},	// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},	// 0x40
	{FS47X_CHR_FREQ1,	0x2A09	},	// 0x42
	{FS47X_ENC_MISC,	0x0900	},	// 0x46
	{FS47X_RGB_YUV,		0x0008	},	// 0x48
	{FS47X_BURST_WID,	0x0044	},	// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},	// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},	// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},	// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},	// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},	// 0x56
	{FS47X_NUM_LINES,	0x9C01	},	// 0x5E PAL=625
	{FS47X_CBCR_GAIN,	0x9191	},	// 0x66
	{FS47X_BRZ_WAY,		0x181A	},	// 0x70
	{FS47X_ENC_STUFF,	0x0059	},	// 0x7E
	{FS47X_VBI_BL_LVL,	0x3E03	},	// 0x88
	{FS47X_DAC_CNTL,	0x0000	},	// 0xA0
	{FS47X_BYPASS,		0x0000	},	// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},	// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 1024x768	HTotal=1365, VTotal=840, PCLK=68,727,273Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_1024x768[] =
{
//	{FS47X_QPR,			0x9C00	},		// 0xC4
	{FS47X_PDIV,		0x0134	},		// 0xC6
	{FS47X_PLL_AMP,		0x1258	},		// 0xC8
	{FS47X_PLL_VGA,		0x0005	},		// 0xCA
	{FS47X_PLL_TV,		0x0086	},		// 0xCC
	{FS47X_IHO,			0x0063	},		// 0x00  Divide by 2
	{FS47X_IVO,			0x0027	},		// 0x02
	{FS47X_IHW,			0x0200  },		// 0x04  Divide by 2
	{FS47X_VSC,			0xA000	},		// 0x06
	{FS47X_VSC2,		0x0007	},		// 0x08
	{FS47X_HSC,			0x3400	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0x8183	},		// 0x0E
	{FS47X_RTCNL,		0xA2EC	},		// 0x12
	{FS47X_RTCNH,		0x0037	},		// 0x14
	{FS47X_RTCDL,		0x0003	},		// 0x16
	{FS47X_RTCDH,		0x0033	},		// 0x18
	{FS47X_FIFO_LAT,	0x00C0	},		// 0x34
	{FS47X_VWIDTH,		0x028A	},		// 0x36
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 1024x768  ***PAL***	HTotal=1240, VTotal=840, PCLK=52,080,000Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_1024x768_PAL[] =
{
	{FS47X_QPR,			0x9C04	},		// 0xC4  PAL
	{FS47X_PDIV,		0x0129	},		// 0xC6
	{FS47X_PLL_AMP,		0x42D0	},		// 0xC8
	{FS47X_PLL_VGA,		0x0008	},		// 0xCA
	{FS47X_PLL_TV,		0x0087	},		// 0xCC
	{FS47X_IHO,			0x0046	},		// 0x00  Divide by 2
	{FS47X_IVO,			0x0022	},		// 0x02
	{FS47X_IHW,			0x0200  },		// 0x04  Divide by 2
	{FS47X_VSC,			0xBE7A	},		// 0x06
	{FS47X_VSC2,		0x0007	},		// 0x08
	{FS47X_HSC,			0x3400	},		// 0x0A
	{FS47X_CR,			0x0100	},		// 0x0C  PAL
	{FS47X_MISC1,		0x8183	},		// 0x0E
	{FS47X_RTCNL,		0x8C6C	},		// 0x12
	{FS47X_RTCNH,		0x0025	},		// 0x14
	{FS47X_RTCDL,		0x9B60	},		// 0x16
	{FS47X_RTCDH,		0x0022	},		// 0x18
	{FS47X_FIFO_LAT,	0x00A0	},		// 0x34
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},		// 0x40
	{FS47X_CHR_FREQ1,	0x2A09	},		// 0x42
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_RGB_YUV,		0x0008	},		// 0x48
	{FS47X_BURST_WID,	0x0044	},		// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},		// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},		// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},		// 0x56
	{FS47X_NUM_LINES,	0x9C01	},		// 0x5E  PAL=625
	{FS47X_CBCR_GAIN,	0x9191	},		// 0x66
	{FS47X_BRZ_WAY,		0x181A	},		// 0x70
	{FS47X_ENC_STUFF,	0x0059	},		// 0x7E
	{FS47X_VBI_BL_LVL,	0x3E03	},		// 0x88
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 1280x720	HTotal=1650, VTotal=788, PCLK=77,934,066Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_1280x720[] =
{
	{FS47X_QPR,			0x9C00	},		// 0xC4
	{FS47X_PDIV,		0x013D	},		// 0xC6
	{FS47X_PLL_AMP,		0x4151	},		// 0xC8
	{FS47X_PLL_VGA,		0x0002	},		// 0xCA
	{FS47X_PLL_TV,		0x0083	},		// 0xCC
	{FS47X_IHO,			0x0079	},		// 0x00  Divide by 2
	{FS47X_IVO,			0x0030	},		// 0x02
	{FS47X_IHW,			0x0280  },		// 0x04  Divide by 2
	{FS47X_VSC,			0xAA8F	},		// 0x06
	{FS47X_VSC2,		0x0007	},		// 0x08
	{FS47X_HSC,			0x1000	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0x8183	},		// 0x0E
	{FS47X_RTCNL,		0xA249	},		// 0x12
	{FS47X_RTCNH,		0x00E6	},		// 0x14
	{FS47X_RTCDL,		0x12AE	},		// 0x16
	{FS47X_RTCDH,		0x00D5	},		// 0x18
	{FS47X_FIFO_LAT,	0x00A0	},		// 0x34
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 1280x720  	***PAL***  HTotal=1530, VTotal=780, PCLK=59,670,000Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_1280x720_PAL[] =
{
	{FS47X_QPR,			0x9C04	},		// 0xC4  PAL
	{FS47X_PDIV,		0x012D	},		// 0xC6
	{FS47X_PLL_AMP,		0x3204	},		// 0xC8
	{FS47X_PLL_VGA,		0x0005	},		// 0xCA
	{FS47X_PLL_TV,		0x0085	},		// 0xCC
	{FS47X_IHO,			0x004F	},		// 0x00  Divide by 2
	{FS47X_IVO,			0x0025	},		// 0x02
	{FS47X_IHW,			0x0280  },		// 0x04  Divide by 2
	{FS47X_VSC,			0xCD21	},		// 0x06
	{FS47X_VSC2,		0x0007	},		// 0x08
	{FS47X_HSC,			0x1000	},		// 0x0A
	{FS47X_CR,			0x0100	},		// 0x0C  PAL
	{FS47X_MISC1,		0x8183	},		// 0x0E
	{FS47X_RTCNL,		0x0F53	},		// 0x12
	{FS47X_RTCNH,		0x009D	},		// 0x14
	{FS47X_RTCDL,		0x22B8	},		// 0x16
	{FS47X_RTCDH,		0x008E	},		// 0x18
	{FS47X_FIFO_LAT,	0x00A0	},		// 0x34
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},		// 0x40
	{FS47X_CHR_FREQ1,	0x2A09	},		// 0x42
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_RGB_YUV,		0x0008	},		// 0x48
	{FS47X_BURST_WID,	0x0044	},		// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},		// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},		// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},		// 0x56
	{FS47X_NUM_LINES,	0x9C01	},		// 0x5E  PAL=625
	{FS47X_CBCR_GAIN,	0x9191	},		// 0x66
	{FS47X_BRZ_WAY,		0x181A	},		// 0x70
	{FS47X_ENC_STUFF,	0x0059	},		// 0x7E
	{FS47X_VBI_BL_LVL,	0x3E03	},		// 0x88
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 1366x768	HTotal=1640, VTotal=840, PCLK=82,573,427Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_1366x768[] =
{
	{FS47X_QPR,			0x9C00	},		// 0xC4
	{FS47X_PDIV,		0x013F	},		// 0xC6
	{FS47X_PLL_AMP,		0x21DC	},		// 0xC8
	{FS47X_PLL_VGA,		0x0003	},		// 0xCA
	{FS47X_PLL_TV,		0x0085	},		// 0xCC
	{FS47X_IHO,			0x0060	},		// 0x00  Divide by 2
	{FS47X_IVO,			0x0024	},		// 0x02
	{FS47X_IHW,			0x02AA  },		// 0x04  Divide by 2
	{FS47X_VSC,			0xA000	},		// 0x06
	{FS47X_VSC2,		0x0007	},		// 0x08
	{FS47X_HSC,			0x0700	},		// 0x0A
	{FS47X_CR,			0x0000	},		// 0x0C
	{FS47X_MISC1,		0x8183	},		// 0x0E
	{FS47X_RTCNL,		0xE800	},		// 0x12
	{FS47X_RTCNH,		0x001A	},		// 0x14
	{FS47X_RTCDL,		0x64C0	},		// 0x16
	{FS47X_RTCDH,		0x001A	},		// 0x18
	{FS47X_FIFO_LAT,	0x00A0	},		// 0x34
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

// FS471 1366x768  ***PAL***	HTotal=1650, VTotal=840, PCLK=69,300,000Hz
static const FS47X_REGISTER_VALUE fs47x_register_set_sdtv_1366x768_PAL[] =
{
	{FS47X_QPR,			0x9C04	},		// 0xC4
	{FS47X_PDIV,		0x0135	},		// 0xC6
	{FS47X_PLL_AMP,		0x518D	},		// 0xC8
	{FS47X_PLL_VGA,		0x0003	},		// 0xCA
	{FS47X_PLL_TV,		0x0084	},		// 0xCC
	{FS47X_IHO,			0x0060	},		// 0x00  Divide by 2
	{FS47X_IVO,			0x0024	},		// 0x02
	{FS47X_IHW,			0x02AB  },		// 0x04  Divide by 2
	{FS47X_VSC,			0xBE7A	},		// 0x06
	{FS47X_VSC2,		0x0007	},		// 0x08
	{FS47X_HSC,			0x0700	},		// 0x0A
	{FS47X_CR,			0x0100	},		// 0x0C  PAL
	{FS47X_MISC1,		0x8183	},		// 0x0E
	{FS47X_RTCNL,		0x8CFC	},		// 0x12
	{FS47X_RTCNH,		0x001C	},		// 0x14
	{FS47X_RTCDL,		0xCF24	},		// 0x16
	{FS47X_RTCDH,		0x001B	},		// 0x18
	{FS47X_FIFO_LAT,	0x00A0	},		// 0x34
	{FS47X_VID_CNTRL0,	0x0000	},		// 0x3C
	{FS47X_CHR_FREQ0,	0x8ACB	},		// 0x40
	{FS47X_CHR_FREQ1,	0x2A09	},		// 0x42
	{FS47X_ENC_MISC,	0x0900	},		// 0x46
	{FS47X_RGB_YUV,		0x0008	},		// 0x48
	{FS47X_BURST_WID,	0x0044	},		// 0x4C,
	{FS47X_BPORCH_WID,	0x008A	},		// 0x4E
	{FS47X_CBCR_BURST,	0x1F2C	},		// 0x50
	{FS47X_SLV_CNTRL0,	0x0001	},		// 0x52
	{FS47X_BLACK_LVL,	0x3E03	},		// 0x54
	{FS47X_BLANK_LVL,	0x3E03	},		// 0x56
	{FS47X_NUM_LINES,	0x9C01	},		// 0x5E  PAL=625
	{FS47X_CBCR_GAIN,	0x9191	},		// 0x66
	{FS47X_BRZ_WAY,		0x181A	},		// 0x70
	{FS47X_ENC_STUFF,	0x0059	},		// 0x7E
	{FS47X_VBI_BL_LVL,	0x3E03	},		// 0x88
	{FS47X_DAC_CNTL,	0x0000	},		// 0xA0
	{FS47X_BYPASS,		0x000A	},		// 0xD0
	{FS47X_PWR_MGMT,	0x0000	},		// 0xD4
	{FS47X_UNDEFINED_REG}
};

//Init, Deinit routines
int focus_init_component(void);
int focus_init_cvsv(void);
int focus_init_hdtv(void);
int focus_shutdown(void);


#endif //FOCUS_H


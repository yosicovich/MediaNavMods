/*
 * File:	focus.c
 *
 * Purpose:	Init Focus FS4XX TV-Encoder
 *
 * Author:	AMD/Focus
 * Date:	October 2004
 *
 *
 * Copyright (c) 2002-2005 BSQUARE Corporation.  All rights reserved.
 * Copyright (c) 2002-2007 Focus Enhancements, Inc.  All rights reserved.
 */

// extern int board_au1200fb_focus_init_cvsv(void);


static uint32 focus_read(FOCUS_REGISTER_ID id)
{
	unsigned long data;
	SIO_read(FS453_ADDRESS, focus_registers[id].address, &data, focus_registers[id].size);
	//SIO_read(FS453_ADDRESS, 0x32, &data, 0x2);
	//RETAILMSG(1, (TEXT("offset 0x32 DATA=%x\r\n"),data));
//	RETAILMSG (1, (TEXT("AdvertisePowerInterface++ \r\n") ));
	return (uint32) data;
}

static void focus_write(FOCUS_REGISTER_ID id, uint32 value)
{
	SIO_write(FS453_ADDRESS, focus_registers[id].address, (unsigned long) value, focus_registers[id].size);
}

static uint32 fs47x_read(FS47X_REGISTER_ID id)
{
	unsigned long data;
	SIO_read(FS47X_ADDRESS, fs47x_registers[id].address, &data, fs47x_registers[id].size);
	return (uint32) data;
}

static void fs47x_write(FS47X_REGISTER_ID id, uint32 value)
{
	SIO_write(FS47X_ADDRESS, fs47x_registers[id].address, (unsigned long) value, fs47x_registers[id].size);
}

static void focus_set_bits(FOCUS_REGISTER_ID id, uint32 bits)
{
	focus_write(id, focus_read(id) | bits);
}

static void focus_clear_bits(FOCUS_REGISTER_ID id, uint32 bits)
{
	focus_write(id, focus_read(id) & ~bits);
}

void focus_soft_reset(void)
{
	focus_set_bits(CR, CR_SRESET);
	focus_clear_bits(CR, CR_SRESET);
}

void focus_latch_nco_pll(void)
{
	focus_set_bits(CR, CR_NCO_EN);
	focus_clear_bits(CR, CR_NCO_EN);
	focus_set_bits(CR, CR_GCC_CK_LVL);	//I don't think this applies to this operation
}

void focus_bridge_reset(void)
{
	focus_set_bits(MISC, MISC_BRDG_RST);
	//OS_mdelay(100);
	Sleep(100);
	focus_clear_bits(MISC, MISC_BRDG_RST);
}

void focus_set_qpr(FOCUS_VIDEO_OUTPUT_FORMAT format)
{
	uint32 qpr = QK_PROGRAM | QK_FF | QK_UIM_NATIONAL;

	switch(format)
	{
		case FORMAT_HDTV:		qpr |= QK_OS_480P | QK_YC_IN | QK_OM_COMPONENT | QK_GMODE_720X480;
								break;
		case FORMAT_COMPONENT:	qpr |= QK_OS_SDTV | QK_OM_COMPONENT | QK_GMODE_640X480;
								break;
		case FORMAT_CVSV:		qpr |= QK_OS_SDTV | QK_OM_CVSV | QK_GMODE_640X480;
								break;
	}

	focus_write(QPR, qpr);
}

void focus_set_video_mode(FOCUS_VIDEO_OUTPUT_FORMAT format)
{
	focus_clear_bits(VID_CNTRL0, 0x3);	//zero out current video mode

	switch(format)
	{
		case FORMAT_HDTV:		focus_set_bits(MISC_47, MISC_47_COMP_YUV);
								focus_set_bits(VID_CNTRL0, VID_MODE_HDTV);
								break;
		case FORMAT_COMPONENT:	focus_set_bits(MISC_47, MISC_47_COMP_YUV);
								focus_set_bits(VID_CNTRL0, VID_MODE_SDTV);
								break;
		case FORMAT_CVSV:		focus_set_bits(VID_CNTRL0, VID_MODE_CVSV);
								break;
	}
}

void focus_reg_dump(void)
{
	RETAILMSG(1,(TEXT("focus_reg_dump()\r\n")));
	int i;
	for(i = 0; focus_registers[i].id != UNDEFINED_REGISTER; ++i)
	{
		//OS_printf("OS_printf %12s (0x%02X) = 0x%X\n", focus_registers[i].description, focus_registers[i].address, focus_read(focus_registers[i].id));
		RETAILMSG(1,(TEXT("(0x%02X) = 0x%X\r\n"), focus_registers[i].address, focus_read(focus_registers[i].id)));
	}
}

void fs47x_reg_dump(void)
{
	RETAILMSG(1,(TEXT("fs47x_reg_dump()\r\n")));
	int i;
	for(i = 0; fs47x_registers[i].id != FS47X_UNDEFINED_REG; ++i)
	{
		//OS_printf("OS_printf %12s (0x%02X) = 0x%X\n", fs47x_registers[i].description, fs47x_registers[i].address, focus_read(focus_registers[i].id));
		RETAILMSG(1,(TEXT("(0x%02X) = 0x%X\r\n"), fs47x_registers[i].address, fs47x_read(fs47x_registers[i].id)));
	}
}

int board_au1200fb_focus_shutdown(void)
{
	SIOLL_shutdown_focus();
	return 1;
}

int focus_init(FOCUS_VIDEO_OUTPUT_FORMAT format, const FOCUS_REGISTER_VALUE* regs)
{
	int i = 0;
	if(regs == 0)
		return 0;

	SIOLL_init_focus();
	SIO_init();

	focus_clear_bits(CR, CR_NCO_EN | CR_SRESET);

	focus_set_qpr(format);

	focus_soft_reset();


	//Program configuration
	for(i = 0; regs[i].id != UNDEFINED_REGISTER; ++i)
		focus_write(regs[i].id, regs[i].value);

	focus_latch_nco_pll();

	focus_bridge_reset();

	//Clear the CACQ and FIFO flags
	focus_set_bits(CR, CR_FIFO_CLR | CR_CACQ_CLR);
	OS_mdelay(100);
	focus_clear_bits(CR, CR_FIFO_CLR | CR_CACQ_CLR);

	focus_set_video_mode(format);

	focus_reg_dump();
	SIO_shutdown();

	return 1;
}

int fs47x_init(FOCUS_VIDEO_OUTPUT_FORMAT format, const FS47X_REGISTER_VALUE* regs)
{
	int i = 0;
	if(regs == 0)
		return 0;

	// Allow PCLK from FS453 to settle, i.e. no breaks in pclk
	//Sleep(10000);
	SIOLL_init_focus();
	SIO_init();

	// Issue a Soft RESET of FS471
	fs47x_write(regs[FS47X_CR].id, 0x01);
	OALStallExecution(100*1000);
	fs47x_write(regs[FS47X_CR].id, 0x00);

	//Program configuration
	for(i = 0; regs[i].id != FS47X_UNDEFINED_REG; ++i)
		fs47x_write(regs[i].id, regs[i].value);

	fs47x_reg_dump();
	SIO_shutdown();

	return 1;
}

int board_au1200fb_focus_init_component(void)
{
	return focus_init(FORMAT_COMPONENT, register_set_sdtv);
}

int board_au1200fb_focus_init_cvsv(FOCUS_VIDEO_OUTPUT_MODE mode)
{
	RETAILMSG(1,(TEXT("board_au1200fb_focus_init_cvsv\r\n")));

	switch(mode)
	{
		case MODE_192x176:
			RETAILMSG(1,(TEXT("focus init 192x176.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_192x176);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_192x176);
			break;
		case MODE_192x176_PAL:
			RETAILMSG(1,(TEXT("focus init 192x176 PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_192x176_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_192x176_PAL);
			break;
		case MODE_220x176:
			RETAILMSG(1,(TEXT("focus init 220x176.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_220x176);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_220x176);
			break;
		case MODE_220x176_PAL:
			RETAILMSG(1,(TEXT("focus init 220x176 PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_220x176_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_220x176_PAL);
			break;
		case MODE_240x320:
			RETAILMSG(1,(TEXT("focus init 240x320.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_240x320);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_240x320);
			break;
		case MODE_240x320_PAL:
			RETAILMSG(1,(TEXT("focus init 240x320 PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_240x320_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_240x320_PAL);
			break;
		case MODE_256x192:
			RETAILMSG(1,(TEXT("focus init 256x192.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_256x192);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_256x192);
			break;
		case MODE_256x192_PAL:
			RETAILMSG(1,(TEXT("focus init 256x192_PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_256x192_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_256x192_PAL);
			break;
		case MODE_320x240:
			RETAILMSG(1,(TEXT("focus init 320x240.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_320x240);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_320x240);
			break;
		case MODE_320x240_PAL:
			RETAILMSG(1,(TEXT("focus init 320x240_PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_320x240_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_320x240_PAL);
			break;
		case MODE_440x234:
			RETAILMSG(1,(TEXT("focus init 440x234.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_440x234);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_440x234);
			break;
		case MODE_440x234_PAL:
			RETAILMSG(1,(TEXT("focus init 440x234_PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_440x234_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_440x234_PAL);
			break;
		case MODE_480x272:
			RETAILMSG(1,(TEXT("focus init 480x272.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_480x272);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_480x272);
			break;
		case MODE_640x480:
			RETAILMSG(1,(TEXT("focus init 640x480.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv);
			return 1;
			break;
		case MODE_640x480_PAL:
			RETAILMSG(1,(TEXT("focus init 640x480 PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_PAL);
			break;
		case MODE_720x480:
			RETAILMSG(1,(TEXT("focus init 720x480.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_720x480_overscan);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_720x480_overscan);
			break;
		case MODE_720x576_PAL:
			RETAILMSG(1,(TEXT("focus init 720x576_PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_720x576_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_720x576_PAL);
			break;
		case MODE_800x600:
			RETAILMSG(1,(TEXT("focus init 800x600.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_800x600);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_800x600);
			break;
		case MODE_800x600_PAL:
			RETAILMSG(1,(TEXT("focus init 800x600_PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_800x600_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_800x600_PAL);
			break;
		case MODE_1024x768:
			RETAILMSG(1,(TEXT("focus init 1024x768.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_1024x768);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_1024x768);
			break;
		case MODE_1024x768_PAL:
			RETAILMSG(1,(TEXT("focus init 1024x768_PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_1024x768_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_1024x768_PAL);
			break;
		case MODE_1280x720:
			RETAILMSG(1,(TEXT("focus init 1280x720.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_1280x720);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_1280x720);
			break;
		case MODE_1280x720_PAL:
			RETAILMSG(1,(TEXT("focus init 1280x720_PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_1280x720_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_1280x720_PAL);
			break;
		case MODE_1366x768:
			RETAILMSG(1,(TEXT("focus init 1366x768.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_1366x768);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_1366x768);
			break;
		case MODE_1366x768_PAL:
			RETAILMSG(1,(TEXT("focus init 1366x768_PAL.\r\n")));
			focus_init(FORMAT_CVSV, register_set_sdtv_1366x768_PAL);
			return fs47x_init(FORMAT_CVSV, fs47x_register_set_sdtv_1366x768_PAL);
			break;
		default:
			RETAILMSG(1,(TEXT("No valid mode!!!!\r\n")));
			return 1;
	}
}

int board_au1200fb_focus_init_hdtv(void)
{
	//return focus_init(FORMAT_HDTV, register_set_hdtv);
	return focus_init(FORMAT_CVSV, register_set_sdtv);
}

int focus_vga_6x4()
{

	SIOLL_init_focus();
	SIO_init();

	// 640x480 @ 60Hz
	// HTOTAL = 800, HSYN Width = 96, HFP = 16, HSYNC BP = 48
	// VTOTAL = 525, VSYNC Width = 2, VFP = 10, VBP = 33

	focus_write(CR, 0x2000);	// set NCO_EN=0 and SRESET=0
	focus_write(QPR, 0x9E30);	// set QPR = VGA

	// Patch QPR VGA mdoe no Clock out bug
	focus_write(BYPASS, 0x0000);


	focus_write(CR, 0x2001);	// SRESET=1
	focus_write(CR, 0x2000);	// SRESET=0

	focus_write(NCON, 0x00000000);
	focus_write(NCOD, 0x00000000);

	focus_write(PLL_M, 0x317F);
	focus_write(PLL_N, 0x008E);
	focus_write(PLL_PD, 0x0202);
	focus_write(CR, 0x2002);		// Latch the NCO and PLL values
	focus_write(CR, 0x2000);

	focus_write(MISC, 0x0113);		// UIM settings, swap UV
	focus_write(VID_CNTRL0, 0x0006);
	focus_write(MISC_47, 0x01);		// RGB out

	// VGA Pass-through mode DAC A = Green, DAC B = Red, DAC C = Blue
	focus_write(DAC_CNTL, 0x00E4);

	focus_reg_dump();
	SIO_shutdown();

	return 1;
}

int focus_vga_8x6()
{

	SIOLL_init_focus();
	SIO_init();

	// 800x600 @ 60Hz
	// HTOTAL = 1056, HSYN Width = 128, HFP = 40, HSYNC BP = 88
	// VTOTAL = 628, VSYNC Width = 4, VFP = 1, VBP = 23

	focus_write(CR, 0x2000);	// set NCO_EN=0 and SRESET=0
	focus_write(QPR, 0x9E30);	// set QPR = VGA

	// Patch QPR VGA mdoe no Clock out bug
	focus_write(BYPASS, 0x0000);


	focus_write(CR, 0x2001);	// SRESET=1
	focus_write(CR, 0x2000);	// SRESET=0

	focus_write(NCON, 0x00000000);
	focus_write(NCOD, 0x00000000);

	focus_write(PLL_M, 0x3107);
	focus_write(PLL_N, 0x001A);
	focus_write(PLL_PD, 0x0606);
	focus_write(CR, 0x2002);		// Latch the NCO and PLL values
	focus_write(CR, 0x2000);

	focus_write(MISC, 0x0113);		// UIM settings, swap UV
	focus_write(VID_CNTRL0, 0x0006);
	focus_write(MISC_47, 0x01);		// RGB out

	// VGA Pass-through mode DAC A = Green, DAC B = Red, DAC C = Blue
	focus_write(DAC_CNTL, 0x00E4);

	focus_reg_dump();
	SIO_shutdown();

	return 1;
}

int focus_vga_10x7()
{

	SIOLL_init_focus();
	SIO_init();

	// 1024x768 @ 60Hz
	// HTOTAL = 1344, HSYN Width = 136, HFP = 24, HSYNC BP = 160
	// VTOTAL = 806, VSYNC Width = 6, VFP = 3, VBP = 29

	focus_write(CR, 0x2000);	// set NCO_EN=0 and SRESET=0
	focus_write(QPR, 0x9E30);	// set QPR = VGA

	// Patch QPR VGA mdoe no Clock out bug
	focus_write(BYPASS, 0x0000);


	focus_write(CR, 0x2001);	// SRESET=1
	focus_write(CR, 0x2000);	// SRESET=0

	focus_write(NCON, 0x00000000);
	focus_write(NCOD, 0x00000000);

	focus_write(PLL_M, 0x30F3);
	focus_write(PLL_N, 0x001A);
	focus_write(PLL_PD, 0x0303);
	focus_write(CR, 0x2002);		// Latch the NCO and PLL values
	focus_write(CR, 0x2000);

	focus_write(MISC, 0x0113);		// UIM settings, swap UV
	focus_write(VID_CNTRL0, 0x0006);
	focus_write(MISC_47, 0x01);		// RGB out

	// VGA Pass-through mode DAC A = Green, DAC B = Red, DAC C = Blue
	focus_write(DAC_CNTL, 0x00E4);

	focus_reg_dump();
	SIO_shutdown();

	return 1;
}


int board_au1200fb_focus_vga(FOCUS_VIDEO_OUTPUT_MODE mode)
{
	RETAILMSG(1,(TEXT("board_au1200fb_focus_vga\r\n")));

	switch(mode)
	{
		case MODE_640x480_VGA:
			RETAILMSG(1,(TEXT("focus vga 640x480_VGA.\r\n")));
			return focus_vga_6x4();
			break;
		case MODE_800x600_VGA:
			RETAILMSG(1,(TEXT("focus vga 800x600_VGA.\r\n")));
			return focus_vga_8x6();
			break;
		case MODE_1024x768_VGA:
			RETAILMSG(1,(TEXT("focus vga 1024x768_VGA.\r\n")));
			return focus_vga_10x7();
			break;
		default:
			RETAILMSG(1,(TEXT("No valid mode!!!!\r\n")));
			return 1;
	}
}
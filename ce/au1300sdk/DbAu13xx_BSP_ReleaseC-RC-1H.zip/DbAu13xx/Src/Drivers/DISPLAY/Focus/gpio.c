static AU1X00_SYS* const sys = (AU1X00_SYS *)(SYS_PHYS_ADDR + KSEG1_OFFSET);//0xB1900000;

#define gpio1 sys

int au1xxx_gpio1_read(int signal)
{
/*	gpio1->trioutclr |= (0x01 << signal); */
	return ((gpio1->pinstaterd >> signal) & 0x01);
}

void au1xxx_gpio1_write(int signal, int value)
{
	if(value)
		gpio1->outputset = (0x01 << signal);
	else
		gpio1->outputclr = (0x01 << signal);	/* Output a Zero */
}

void au1xxx_gpio1_tristate(int signal)
{
	gpio1->trioutclr = (0x01 << signal);		/* Tristate signal */
}


int au1xxx_gpio_read(int signal)
{
	return au1xxx_gpio1_read(signal);
}

void au1xxx_gpio_write(int signal, int value)
{
	au1xxx_gpio1_write(signal, value);
}

void au1xxx_gpio_tristate(int signal)
{
	au1xxx_gpio1_tristate(signal);
}

void au1xxx_gpio1_set_inputs(void)
{
	gpio1->pininputen = 0;
}


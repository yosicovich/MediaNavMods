//	SIO.h

// Copyright (c) 1999-2000, FOCUS Enhancements, Inc., All Rights Reserved.

//	This file defines the high-level SIO interface.  It provides functions
//	that can be used from other modules to read or write an SIO device.


#ifndef	__SIO_H__
#define	__SIO_H__

int SIO_init(void);
void SIO_shutdown(void);

int SIO_read(unsigned char address, unsigned int reg, unsigned long *p_value, unsigned int bytes);
int SIO_read_current_offset(unsigned char address, unsigned long *p_value, unsigned int bytes);

int SIO_write(unsigned char address, unsigned int reg, unsigned long value, unsigned int bytes);

#endif


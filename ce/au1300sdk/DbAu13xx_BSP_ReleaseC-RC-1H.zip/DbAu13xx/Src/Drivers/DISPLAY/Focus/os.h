/*
#include <linux/config.h>
#include <linux/delay.h>
#include <linux/console.h>

#include <asm/mach-au1x00/au1000.h>
#include <asm/mach-au1x00/au1xxx_gpio.h>

#ifdef CONFIG_MIPS_DB1200
	#define DB1200
	#include <asm/mach-db1x00/db1200.h>
#endif
#endif
*/

#ifndef __OS_H
#define __OS_H
//#include <au1x00.h>
//#include <platform.h>
#include "au1xxx_gpio.h"
#define DB1200
//#include <db1200.h>
/*
#if defined(CONFIG_SOC_AU1200)
*/
#define CONFIG_SOC_AU1200
#define AU1200
#define SYS_PINFUNC_P0B		(1<<4)
#define GPIO_DATA	18
#define GPIO_CLOCK	25
/*
#elif defined(CONFIG_SOC_AU1100)
	#define AU1100
	//#define GPIO_DATA	22
	//#define GPIO_CLOCK	4
	#define GPIO_DATA	4
	#define GPIO_CLOCK	1
#endif
*/
/*
#define uint8					u8
#define uint16					u16
#define uint32					u32
*/
#define OS_mdelay(x)			Sleep(x)
#define OS_udelay(x)			HalStallExecution(x)
#define OS_set_config_bits(x)		//ficmmp_config_set
#define OS_clear_config_bits(x)		//ficmmp_config_clear
#define OS_gpio_write			au1xxx_gpio_write
#define OS_gpio_read			au1xxx_gpio_read
#define OS_gpio_tristate		au1xxx_gpio_tristate
#define OS_gpio_set_inputs		au1xxx_gpio1_set_inputs
#define OS_printf				//printk

#if 0
#define _DEBUG
#ifdef _DEBUG
/* note: prints function name for you */
#define DPRINTF(fmt, args...) //printk(fmt, ## args)
#else
#define DPRINTF
#endif
#endif
#endif //__OS_H
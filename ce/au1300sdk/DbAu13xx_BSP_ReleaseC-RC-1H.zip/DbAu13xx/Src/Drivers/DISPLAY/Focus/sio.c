//sio.c----
extern "C"
{
#include <i2c.h>
}

static HANDLE hI2c=NULL;

//----------------------------------------------------------------------
//
//	void SIO_init(void)
//
//	This routine initializes the SIO interface. Clients of the SIO module
//	will call this routine before calling any other routine in the module.
//
//----------------------------------------------------------------------
static int g_initialized = 0;

int SIO_init(void)
{
	hI2c = IICOpen();

	RETAILMSG(1, (TEXT("FOCUS_471:: SIO_init...!\r\n")));

	g_initialized = 1;

	return 0;
}

//----------------------------------------------------------------------
//
//	void SIO_cleanup(void)
//
//	This routine disables the SIO interface. Clients of the SIO module will not
//	call any other SIO routine after calling this routine.
//
//----------------------------------------------------------------------
void SIO_shutdown(void)
{
	if (g_initialized)
	{
		g_initialized = 0;
	}
}


int SIO_read(unsigned char address, unsigned int reg, unsigned long *p_value, unsigned int bytes)
{
	*p_value = 0;
	IICReadData(hI2c, address, reg, (BYTE*)p_value, bytes);

//	RETAILMSG(1, (TEXT("Leaving SIO_READ, addr: %X, reg: %X, value: 0x%X, bytes: %x\r\n"),address, reg,*p_value, bytes));
	return 0;
}

int SIO_write(unsigned char address, unsigned int reg, unsigned long value, unsigned int bytes)
{
	ULONG data = value;
	IICWriteData(hI2c, address, reg, (BYTE*)&data, bytes);

//	RETAILMSG(1, (TEXT("Leaving SIO_WRITE, addr: %X, reg: %X, value: 0x%X, bytes: %x\r\n"),address,reg,data,bytes));
	return 0;
}

//sio.c----

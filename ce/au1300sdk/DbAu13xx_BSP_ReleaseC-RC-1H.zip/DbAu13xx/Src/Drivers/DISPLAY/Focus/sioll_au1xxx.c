
int SIOLL_init_focus(void)
{
	return 0;
}

void SIOLL_shutdown_focus(void)
{
}

int SIOLL_init_smbus(void)
{
	return 0;
}

void SIOLL_shutdown_smbus(void)
{
}

void SIOLL_output_clock(int value)
{
}

void SIOLL_output_data(int value)
{
	volatile unsigned int delay = 0;
	if(value)
		OS_gpio_tristate(GPIO_DATA);		//Let the pullup drive the logic '1'
	else
		OS_gpio_write(GPIO_DATA, value);

	//OS_udelay(5);		//These pullups are pretty weak, allow time to reach 3.3V
	for (delay = 0; delay < 1000;)
	{
		delay++;
	}
}

int SIOLL_input_data(void)
{
	return OS_gpio_read(GPIO_DATA);
}

void SIOLL_set_data_for_output(void)
{
	//This functionality is accomplished when a write occurs
}

void SIOLL_set_data_for_input(void)
{
	volatile unsigned int delay = 0;
	OS_gpio_tristate(GPIO_DATA);
	//OS_udelay(5);
	for (delay = 0; delay < 1000;)
	{
		delay++;
	}
	//gpio_input_enable(GPIO_DATA);
}


//sioll_au1xxx.c-----

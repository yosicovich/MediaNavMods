/*****************************************************************************
Copyright 2003-2008 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include <windows.h>
#include <bceddk.h>
#include <ddkreg.h>
#include "platform.h"


#include <smbus.h>

// Why is this part not in the header?
enum {
    IOCTL_SMBUS_READDATA = 0x80002000,  // some arbirary base
    IOCTL_SMBUS_WRITEDATA
};

#include "camera.h"
#include "camera_hw.h"

// Probably not the best place to put this, but let's get this
// .. thing running first

HANDLE	hI2C;

#ifdef DEBUG
DBGPARAM dpCurSettings = {
    L"Camera",
    {L"Trace",       L"Undefined",   L"Undefined",   L"Undefined",
     L"Undefined",   L"Undefined",   L"Undefined",   L"Undefined",
     L"Undefined",   L"Undefined",   L"Undefined",   L"Undefined",
     L"Undefined",   L"Power",       L"Warning",     L"Error",
    },
    0xC000
};
#endif  // DEBUG

/*
#undef DEBUGMSG
#define DEBUGMSG(c,m) RETAILMSG(1,m)
*/

/*
 * Global Variables
 */
AU13XX_CIM *pCim = NULL;        // Camera Interface Module
pBCSR       pBcsr = NULL;       // Board Registers

BOOL            bInPowerHandler = FALSE;



INT WINAPI CIMThread(DEVICE_CONTEXT *pDevice);


#ifdef USE_OLD_WAY
BOOL SMBusInit(void);
BOOL SMBusDeinit(void);
BOOL DeviceWriteReg(USHORT dev_addr, USHORT sub_addr, USHORT value);
BOOL DeviceReadReg(USHORT dev_addr, USHORT sub_addr, USHORT *value);
void ReadStatusRegisters(void);
#endif

HANDLE g_hSMB = NULL;
HANDLE g_CIMThread = NULL;

typedef enum _IOCTRL_TYPE
{
	I2C_IOCTL_INIT,
	I2C_IOCTL_READ,
	I2C_IOCTL_WRITE,
	I2C_IOCTL_READ_WRITE,
	I2C_IOCTL_CLOSE,
	I2C_IOCTL_RADIO_READ,
	I2C_IOCTL_RADIO_WRITE,
	I2C_IOCTL_TRANS_READ,
	I2C_IOCTL_TRANS_WRITE

} IOCTRL_TYPE;

typedef struct _PARA_STRUCTURE
{
	BYTE addr;
	BYTE reg;
	BYTE *buffPtr;
	ULONG len;
} PARA_STRUCTURE;



/****************************************************************
 *  Configurations for Different Modes of Different Cameras
 ****************************************************************/

CAMERA CameraModes[] =
{
    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 1280x960 Mode (SXGA) in RAW 1.3 MP at 15 Fps
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */  1280,
		/* frame heigth         */  960,
		/* camera name          */  L"Omnivision",
		/* camera mode          */  L"raw_SXGA",
		/* Cmos output format   */  CMOS_RAW,
		/* Resolution Format    */  RAW_SXGA,
		/* DPS mode             */  CIM_CONFIG_RAW,
		/* Bayer Mode           */  CIM_CONFIG_BGGR,
		/* dbdma channel        */  1,
		/* Device Address       */  0x30,

		/* No of Sub Register   */  51,
        {
			{0x12, 0x80},{0x12, 0x04},{0x11,0x80},{0x3b, 0x00},{0x33, 0x02},
			{0x37, 0x02},{0x38, 0x13},{0x39,0xf0},{0x6c, 0x40},{0x6d, 0x30},
			{0x6e, 0x4b},{0x6f, 0x60},{0x70,0x70},{0x71, 0x70},{0x74, 0x60},
			{0x75, 0x60},{0x76, 0x50},{0x77,0x48},{0x78, 0x3a},{0x79, 0x2e},
			{0x7a, 0x2a},{0x7b, 0x22},{0x7c,0x04},{0x7d, 0x07},{0x7e, 0x10},
			{0x7f, 0x28},{0x80, 0x36},{0x81,0x44},{0x82, 0x52},{0x83, 0x60},
			{0x84, 0x6c},{0x85, 0x78},{0x86,0x8c},{0x87, 0x9e},{0x88, 0xbb},
			{0x89, 0xd2},{0x8a, 0xe6},{0x0f,0x4f},{0x3c, 0x40},{0x14, 0xca},
			{0x42, 0x89},{0x24, 0x78},{0x25,0x68},{0x26, 0xd4},{0x27, 0x90},
			{0x2a, 0x00},{0x2b, 0x00},{0x3d,0x80},{0x41, 0x00},{0x60, 0x8d},
			{0x40, 0x10}
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 640x480 Mode (VGA) in "Pass Through Mode"
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    640,
		/* frame heigth         */    480,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"raw_VGA",
		/* Cmos output format   */    CMOS_RAW,
		/* Resolution Format    */    RAW_VGA,
		/* DPS mode             */    CIM_CONFIG_RAW,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    1,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    10,
        {
			{0x12, 0x80},{0x12, 0x40},{0x3b, 0x08},
			{0x0D, 0x81},{0x11, 0x81},
			{0x85, 0x17},{0xD5, 0xFF},{0xD6,0x03},{0xD7,0x01},
			{0xD8, 0x01},
#if 0
			{0x11,0x81},{0x0c, 0x04},{0x0d, 0x40},
            {0x3b, 0x00},{0x33, 0x02},{0x40,0x10},{0x1e, 0x10},
			{0x37, 0x02},{0x38, 0x13},{0x39,0xf0},{0x6c, 0x40},{0x6d, 0x30},
			{0x6e, 0x4b},{0x6f, 0x60},{0x70,0x70},{0x71, 0x70},{0x72, 0x70},
            {0x73, 0x70},{0x74, 0x60},
			{0x75, 0x60},{0x76, 0x50},{0x77,0x48},{0x78, 0x3a},{0x79, 0x2e},
			{0x7a, 0x28},{0x7b, 0x22},{0x7c,0x04},{0x7d, 0x07},{0x7e, 0x2e},
			{0x7f, 0x28},{0x80, 0x36},{0x81,0x44},{0x82, 0x52},{0x83, 0x60},
			{0x84, 0x6c},{0x85, 0x78},{0x86,0x8c},{0x87, 0x9e},{0x88, 0xbb},
			{0x89, 0xd2},{0x8a, 0xe6},{0x0f,0x4f},{0x3c, 0x40},{0x14, 0xca},
			{0x42, 0x89},{0x24, 0x78},{0x25,0x68},{0x26, 0xd4},{0x27, 0x90},
			{0x2a, 0x00},{0x2b, 0x00},{0x3d,0x80},{0x41, 0x00},{0x60, 0x8d},
#endif
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 352x280 Mode CIF "Pass Through Mode"
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    352,
		/* frame heigth         */    288,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"raw_CIF",
		/* Cmos output format   */    CMOS_RAW,
		/* Resolution Format    */    RAW_CIF,
		/* DPS mode             */    CIM_CONFIG_RAW,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    1,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    54,
        {
			{0x12, 0x80},{0x12, 0x25},{0x11,0x80},{0x0c, 0x04},{0x0d, 0x40},
            {0x3b, 0x00},{0x33, 0x02},
			{0x37, 0x02},{0x38, 0x13},{0x39,0xf0},{0x6c, 0x40},{0x6d, 0x30},
			{0x6e, 0x4b},{0x6f, 0x60},{0x70,0x70},{0x71, 0x70},{0x72, 0x70},
            {0x73, 0x70},{0x74, 0x60},
			{0x75, 0x60},{0x76, 0x50},{0x77,0x48},{0x78, 0x3a},{0x79, 0x2e},
			{0x7a, 0x28},{0x7b, 0x22},{0x7c,0x04},{0x7d, 0x07},{0x7e, 0x10},
			{0x7f, 0x28},{0x80, 0x36},{0x81,0x44},{0x82, 0x52},{0x83, 0x60},
			{0x84, 0x6c},{0x85, 0x78},{0x86,0x8c},{0x87, 0x9e},{0x88, 0xbb},
			{0x89, 0xd2},{0x8a, 0xe6},{0x0f,0x4f},{0x3c, 0x40},{0x14, 0xca},
			{0x42, 0x89},{0x24, 0x78},{0x25,0x68},{0x26, 0xd4},{0x27, 0x90},
			{0x2a, 0x00},{0x2b, 0x00},{0x3d,0x80},{0x41, 0x00},{0x60, 0x8d},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 320x240 Mode (QVGA) in "Pass Through Mode"
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    320,
		/* frame heigth         */    240,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"raw_QVGA",
		/* Cmos output format   */    CMOS_RAW,
		/* Resolution Format    */    RAW_QVGA,
		/* DPS mode             */    CIM_CONFIG_RAW,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    1,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    54,
        {
			{0x12, 0x80},{0x12, 0x15},{0x11,0x83},{0x0c, 0x04},{0x0d, 0xc0},
            {0x3b, 0x00},{0x33, 0x02},
			{0x37, 0x02},{0x38, 0x13},{0x39,0xf0},{0x6c, 0x40},{0x6d, 0x30},
			{0x6e, 0x4b},{0x6f, 0x60},{0x70,0x70},{0x71, 0x70},{0x72, 0x70},
            {0x73, 0x70},{0x74, 0x60},
			{0x75, 0x60},{0x76, 0x50},{0x77,0x48},{0x78, 0x3a},{0x79, 0x2e},
			{0x7a, 0x28},{0x7b, 0x22},{0x7c,0x04},{0x7d, 0x07},{0x7e, 0x10},
			{0x7f, 0x28},{0x80, 0x36},{0x81,0x44},{0x82, 0x52},{0x83, 0x60},
			{0x84, 0x6c},{0x85, 0x78},{0x86,0x8c},{0x87, 0x9e},{0x88, 0xbb},
			{0x89, 0xd2},{0x8a, 0xe6},{0x0f,0x4f},{0x3c, 0x40},{0x14, 0xca},
			{0x42, 0x89},{0x24, 0x78},{0x25,0x68},{0x26, 0xd4},{0x27, 0x90},
			{0x2a, 0x00},{0x2b, 0x00},{0x3d,0x80},{0x41, 0x00},{0x60, 0x8d},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 176x144 QCIF Mode "Pass Through Mode"
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    176,
		/* frame heigth         */    144,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"raw_QCIF",
		/* Cmos output format   */    CMOS_RAW,
		/* Resolution Format    */    RAW_QCIF,
		/* DPS mode             */    CIM_CONFIG_RAW,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    1,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    54,
        {
			{0x12, 0x80},{0x12, 0x0D},{0x11,0x80},{0x0c, 0x04},{0x0d, 0xc0},
            {0x3b, 0x00},{0x33, 0x02},
			{0x37, 0x02},{0x38, 0x13},{0x39,0xf0},{0x6c, 0x40},{0x6d, 0x30},
			{0x6e, 0x4b},{0x6f, 0x60},{0x70,0x70},{0x71, 0x70},{0x72, 0x70},
            {0x73, 0x70},{0x74, 0x60},
			{0x75, 0x60},{0x76, 0x50},{0x77,0x48},{0x78, 0x3a},{0x79, 0x2e},
			{0x7a, 0x28},{0x7b, 0x22},{0x7c,0x04},{0x7d, 0x07},{0x7e, 0x10},
			{0x7f, 0x28},{0x80, 0x36},{0x81,0x44},{0x82, 0x52},{0x83, 0x60},
			{0x84, 0x6c},{0x85, 0x78},{0x86,0x8c},{0x87, 0x9e},{0x88, 0xbb},
			{0x89, 0xd2},{0x8a, 0xe6},{0x0f,0x6f},{0x3c, 0x60},{0x14, 0xca},
			{0x42, 0x89},{0x24, 0x78},{0x25,0x68},{0x26, 0xd4},{0x27, 0x90},
			{0x2a, 0x00},{0x2b, 0x00},{0x3d,0x80},{0x41, 0x00},{0x60, 0x8d},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 1280x960 Mode (SXGA) in BAYER Mode (Planar)
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */  1280,
		/* frame heigth         */  960,
		/* camera name          */  L"Omnivision",
		/* camera mode          */  L"bayer_SXGA",
		/* Cmos output format   */  CMOS_RAW,
		/* Resolution Format    */  BAYER_SXGA,
		/* DPS mode             */  CIM_CONFIG_BAYER,
		/* Bayer Mode           */  CIM_CONFIG_BGGR,
		/* dbdma channel        */  3,
		/* Device Address       */  0x30,

		/* No of Sub Register   */  50,
        {
			{0x12, 0x80},{0x12, 0x05},{0x11,0x80},{0x3b, 0x00},{0x33, 0x02},
			{0x37, 0x02},{0x38, 0x13},{0x39,0xf0},{0x6c, 0x40},{0x6d, 0x30},
			{0x6e, 0x4b},{0x6f, 0x60},{0x70,0x70},{0x71, 0x70},{0x74, 0x60},
			{0x75, 0x60},{0x76, 0x50},{0x77,0x48},{0x78, 0x3a},{0x79, 0x2e},
			{0x7a, 0x2a},{0x7b, 0x22},{0x7c,0x04},{0x7d, 0x07},{0x7e, 0x10},
			{0x7f, 0x28},{0x80, 0x36},{0x81,0x44},{0x82, 0x52},{0x83, 0x60},
			{0x84, 0x6c},{0x85, 0x78},{0x86,0x8c},{0x87, 0x9e},{0x88, 0xbb},
			{0x89, 0xd2},{0x8a, 0xe6},{0x0f,0x4f},{0x3c, 0x40},{0x14, 0xca},
			{0x42, 0x89},{0x24, 0x78},{0x25,0x68},{0x26, 0xd4},{0x27, 0x90},
			{0x2a, 0x00},{0x2b, 0x00},{0x3d,0x80},{0x41, 0x00},{0x60, 0x8d},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 640x480 Mode (VGA) in BAYER Mode (Planar)
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    640,
		/* frame heigth         */    480,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"bayer_VGA",
		/* Cmos output format   */    CMOS_RAW,
		/* Resolution Format    */    BAYER_VGA,
		/* DPS mode             */    CIM_CONFIG_BAYER,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    3,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    54,
        {
			{0x12, 0x80},{0x12, 0x45},{0x11,0x81},{0x0c, 0x04},{0x0d, 0x40},
            {0x3b, 0x00},{0x33, 0x02},
			{0x37, 0x02},{0x38, 0x13},{0x39,0xf0},{0x6c, 0x40},{0x6d, 0x30},
			{0x6e, 0x4b},{0x6f, 0x60},{0x70,0x70},{0x71, 0x70},{0x72, 0x70},
            {0x73, 0x70},{0x74, 0x60},
			{0x75, 0x60},{0x76, 0x50},{0x77,0x48},{0x78, 0x3a},{0x79, 0x2e},
			{0x7a, 0x28},{0x7b, 0x22},{0x7c,0x04},{0x7d, 0x07},{0x7e, 0x2e},
			{0x7f, 0x28},{0x80, 0x36},{0x81,0x44},{0x82, 0x52},{0x83, 0x60},
			{0x84, 0x6c},{0x85, 0x78},{0x86,0x8c},{0x87, 0x9e},{0x88, 0xbb},
			{0x89, 0xd2},{0x8a, 0xe6},{0x0f,0x4f},{0x3c, 0x40},{0x14, 0xca},
			{0x42, 0x89},{0x24, 0x78},{0x25,0x68},{0x26, 0xd4},{0x27, 0x90},
			{0x2a, 0x00},{0x2b, 0x00},{0x3d,0x80},{0x41, 0x00},{0x60, 0x8d},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 352x288 CIF Mode in BAYER Mode (Planar)
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    352,
		/* frame heigth         */    288,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"bayer_CIF",
		/* Cmos output format   */    CMOS_RAW,
		/* Resolution Format    */    BAYER_CIF,
		/* DPS mode             */    CIM_CONFIG_BAYER,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    3,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    54,
        {
			{0x12, 0x80},{0x12, 0x25},{0x11,0x80},{0x0c, 0x04},{0x0d, 0x40},
            {0x3b, 0x00},{0x33, 0x02},
			{0x37, 0x02},{0x38, 0x13},{0x39,0xf0},{0x6c, 0x40},{0x6d, 0x30},
			{0x6e, 0x4b},{0x6f, 0x60},{0x70,0x70},{0x71, 0x70},{0x72, 0x70},
            {0x73, 0x70},{0x74, 0x60},
			{0x75, 0x60},{0x76, 0x50},{0x77,0x48},{0x78, 0x3a},{0x79, 0x2e},
			{0x7a, 0x28},{0x7b, 0x22},{0x7c,0x04},{0x7d, 0x07},{0x7e, 0x10},
			{0x7f, 0x28},{0x80, 0x36},{0x81,0x44},{0x82, 0x52},{0x83, 0x60},
			{0x84, 0x6c},{0x85, 0x78},{0x86,0x8c},{0x87, 0x9e},{0x88, 0xbb},
			{0x89, 0xd2},{0x8a, 0xe6},{0x0f,0x4f},{0x3c, 0x40},{0x14, 0xca},
			{0x42, 0x89},{0x24, 0x78},{0x25,0x68},{0x26, 0xd4},{0x27, 0x90},
			{0x2a, 0x00},{0x2b, 0x00},{0x3d,0x80},{0x41, 0x00},{0x60, 0x8d},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 320x240 Mode (QVGA) in BAYER Mode (Planar)
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    320,
		/* frame heigth         */    240,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"bayer_QVGA",
		/* Cmos output format   */    CMOS_RAW,
		/* Resolution Format    */    BAYER_QVGA,
		/* DPS mode             */    CIM_CONFIG_BAYER,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    3,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    54,
        {
			{0x12, 0x80},{0x12, 0x15},{0x11,0x83},{0x0c, 0x04},{0x0d, 0xc0},
            {0x3b, 0x00},{0x33, 0x02},
			{0x37, 0x02},{0x38, 0x13},{0x39,0xf0},{0x6c, 0x40},{0x6d, 0x30},
			{0x6e, 0x4b},{0x6f, 0x60},{0x70,0x70},{0x71, 0x70},{0x72, 0x70},
            {0x73, 0x70},{0x74, 0x60},
			{0x75, 0x60},{0x76, 0x50},{0x77,0x48},{0x78, 0x3a},{0x79, 0x2e},
			{0x7a, 0x28},{0x7b, 0x22},{0x7c,0x04},{0x7d, 0x07},{0x7e, 0x10},
			{0x7f, 0x28},{0x80, 0x36},{0x81,0x44},{0x82, 0x52},{0x83, 0x60},
			{0x84, 0x6c},{0x85, 0x78},{0x86,0x8c},{0x87, 0x9e},{0x88, 0xbb},
			{0x89, 0xd2},{0x8a, 0xe6},{0x0f,0x4f},{0x3c, 0x40},{0x14, 0xca},
			{0x42, 0x89},{0x24, 0x78},{0x25,0x68},{0x26, 0xd4},{0x27, 0x90},
			{0x2a, 0x00},{0x2b, 0x00},{0x3d,0x80},{0x41, 0x00},{0x60, 0x8d},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 640x480 Mode (QCIF) in BAYER Mode (Planar)
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    176,
		/* frame heigth         */    144,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"bayer_QCIF",
		/* Cmos output format   */    CMOS_RAW,
		/* Resolution Format    */    BAYER_QCIF,
		/* DPS mode             */    CIM_CONFIG_BAYER,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    3,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    54,
        {
			{0x12, 0x80},{0x12, 0x0D},{0x11,0x80},{0x0c, 0x04},{0x0d, 0xc0},
            {0x3b, 0x00},{0x33, 0x02},
			{0x37, 0x02},{0x38, 0x13},{0x39,0xf0},{0x6c, 0x40},{0x6d, 0x30},
			{0x6e, 0x4b},{0x6f, 0x60},{0x70,0x70},{0x71, 0x70},{0x72, 0x70},
            {0x73, 0x70},{0x74, 0x60},
			{0x75, 0x60},{0x76, 0x50},{0x77,0x48},{0x78, 0x3a},{0x79, 0x2e},
			{0x7a, 0x28},{0x7b, 0x22},{0x7c,0x04},{0x7d, 0x07},{0x7e, 0x10},
			{0x7f, 0x28},{0x80, 0x36},{0x81,0x44},{0x82, 0x52},{0x83, 0x60},
			{0x84, 0x6c},{0x85, 0x78},{0x86,0x8c},{0x87, 0x9e},{0x88, 0xbb},
			{0x89, 0xd2},{0x8a, 0xe6},{0x0f,0x6f},{0x3c, 0x60},{0x14, 0xca},
			{0x42, 0x89},{0x24, 0x78},{0x25,0x68},{0x26, 0xd4},{0x27, 0x90},
			{0x2a, 0x00},{0x2b, 0x00},{0x3d,0x80},{0x41, 0x00},{0x60, 0x8d},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 1280x960 Mode (SXGA) in YCbCr Camera
    // pass Thru Mode
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    1280,
		/* frame heigth         */    960,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"YCbCr_SXGA",
		/* Cmos output format   */    CMOS_CCIR656,
		/* Resolution Format    */    YCbCr_SXGA_RAW,
		/* DPS mode             */    CIM_CONFIG_RAW,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    1,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    115,
        {
			{0x12, 0x80},{0x11, 0x80},{0x12,0x00},{0x13, 0xA8},{0x01, 0x80},
			{0x02, 0x80},{0x04, 0x40},{0x0C,0x04},{0x0D, 0xC0},{0x0E, 0x81},
			{0x0f, 0x4F},{0x14, 0x4A},{0x16,0x02},{0x1B, 0x01},{0x24, 0x70},
			{0x25, 0x68},{0x26, 0xD3},{0x27,0x90},{0x2A, 0x00},{0x2B, 0x00},
			{0x33, 0x28},{0x37, 0x02},{0x38,0x13},{0x39, 0xF0},{0x3A, 0x00},
			{0x3B, 0x01},{0x3C, 0x46},{0x3D,0x90},{0x3E, 0x02},{0x3F, 0xF2},
			{0x41, 0x02},{0x42, 0xC9},{0x43,0xF0},{0x44, 0x10},{0x45, 0x6C},
			{0x46, 0x6C},{0x47, 0x44},{0x48,0x44},{0x49, 0x03},{0x4F, 0x50},
			{0x50, 0x43},{0x51, 0x0D},{0x52,0x19},{0x53, 0x4C},{0x54, 0x65},
			{0x59, 0x49},{0x5A, 0x94},{0x5B,0x46},{0x5C, 0x84},{0x5D, 0x5C},
			{0x5E, 0x08},{0x5F, 0x00},{0x60,0x14},{0x61, 0xCE},{0x62, 0x70},
			{0x63, 0x00},{0x64, 0x04},{0x65,0x00},{0x66, 0x00},{0x69, 0x00},
			{0x6A, 0x3E},{0x6B, 0x3F},{0x6C,0x40},{0x6D, 0x30},{0x6E, 0x4B},
			{0x6F, 0x60},{0x70, 0x70},{0x71,0x70},{0x72, 0x70},{0x73, 0x70},
			{0x74, 0x70},{0x75, 0x60},{0x76,0x50},{0x77, 0x48},{0x78, 0x3A},
			{0x79, 0x2E},{0x7A, 0x28},{0x7B,0x22},{0x7C, 0x04},{0x7D, 0x07},
			{0x7E, 0x10},{0x7F, 0x28},{0x80,0x36},{0x81, 0x44},{0x82, 0x52},
			{0x83, 0x60},{0x84, 0x6C},{0x85,0x78},{0x86, 0x8C},{0x87, 0x9E},
			{0x88, 0xBB},{0x89, 0xD2},{0x8A,0xE6},{0x13, 0xAF},{0x13, 0x8D},
			{0x01, 0x80},{0x02, 0x80},{0x42,0xC9},{0x16, 0x02},{0x43, 0xF0},
			{0x44, 0x10},{0x45, 0x20},{0x46,0x20},{0x47, 0x20},{0x48, 0x20},
			{0x59, 0x17},{0x5A, 0x71},{0x5B,0x56},{0x5C, 0x74},{0x5D, 0x68},
			{0x5e, 0x10},{0x5f, 0x00},{0x60,0x14},{0x61, 0xCE},{0x13, 0x8F},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 640x480 Mode (SXGA) in YCbCr Camera
    // pass Thru Mode
    //////////////////////////////////////////////////////////////////////////

    {
		/* frame width          */    640,
		/* frame heigth         */    480,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"YCbCr_VGA_raw",
		/* Cmos output format   */    CMOS_CCIR656,
		/* Resolution Format    */    YCbCr_VGA_RAW,
		/* DPS mode             */    CIM_CONFIG_RAW,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    1,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    94,
        {
			{0x12, 0x80},{0x11, 0x81},{0x12,0x40},{0x13, 0xA8},{0x01, 0x80},
			{0x02, 0x80},{0x04, 0x40},{0x0C,0x04},{0x0D, 0xC0},{0x0E, 0x81},
			{0x0f, 0x4F},{0x14, 0x4A},{0x16,0x02},{0x1B, 0x01},{0x24, 0x70},
			{0x25, 0x68},{0x26, 0xD3},{0x27,0x90},{0x2A, 0x00},{0x2B, 0x00},
			{0x33, 0x02},{0x37, 0x02},{0x38,0x13},{0x39, 0xF0},{0x3A, 0x00},
			{0x3B, 0x01},{0x3C, 0x46},{0x3D,0x90},{0x3E, 0x02},{0x3F, 0xF2},
			{0x41, 0x02},{0x42, 0xC9},{0x43,0xF0},{0x44, 0x10},{0x45, 0x6C},
			{0x46, 0x6C},{0x47, 0x44},{0x48,0x44},{0x49, 0x03},{0x4F, 0x50},
			{0x50, 0x43},{0x51, 0x0D},{0x52,0x19},{0x53, 0x4C},{0x54, 0x65},
			{0x59, 0x49},{0x5A, 0x94},{0x5B,0x46},{0x5C, 0x84},{0x5D, 0x5C},
			{0x5E, 0x08},{0x5F, 0x00},{0x60,0x14},{0x61, 0xCE},{0x62, 0x70},
			{0x63, 0x00},{0x64, 0x04},{0x65,0x00},{0x66, 0x00},{0x69, 0x00},
			{0x6A, 0x3E},{0x6B, 0x3F},{0x6C,0x40},{0x6D, 0x30},{0x6E, 0x4B},
			{0x6F, 0x60},{0x70, 0x70},{0x71,0x70},{0x72, 0x70},{0x73, 0x70},
			{0x74, 0x60},{0x75, 0x60},{0x76,0x50},{0x77, 0x48},{0x78, 0x3A},
			{0x79, 0x2E},{0x7A, 0x28},{0x7B,0x22},{0x7C, 0x04},{0x7D, 0x07},
			{0x7E, 0x10},{0x7F, 0x28},{0x80,0x36},{0x81, 0x44},{0x82, 0x52},
			{0x83, 0x60},{0x84, 0x6C},{0x85,0x78},{0x86, 0x8C},{0x87, 0x9E},
			{0x88, 0xBB},{0x89, 0xD2},{0x8A,0xE6},{0x13, 0xAF},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 352x288 Mode (CIF) in YCbCr Camera
    // pass Thru Mode
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    352,
		/* frame heigth         */    288,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"YCbCr_CIF_raw",
		/* Cmos output format   */    CMOS_CCIR656,
		/* Resolution Format    */    YCbCr_CIF_RAW,
		/* DPS mode             */    CIM_CONFIG_RAW,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    1,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    94,
        {
			{0x12, 0x80},{0x11, 0x81},{0x12,0x20},{0x13, 0xA8},{0x01, 0x80},
			{0x02, 0x80},{0x04, 0x40},{0x0C,0x04},{0x0D, 0xC0},{0x0E, 0x81},
			{0x0f, 0x4F},{0x14, 0x4A},{0x16,0x02},{0x1B, 0x01},{0x24, 0x70},
			{0x25, 0x68},{0x26, 0xD3},{0x27,0x90},{0x2A, 0x00},{0x2B, 0x00},
			{0x33, 0x02},{0x37, 0x02},{0x38,0x13},{0x39, 0xF0},{0x3A, 0x00},
			{0x3B, 0x01},{0x3C, 0x46},{0x3D,0x90},{0x3E, 0x02},{0x3F, 0xF2},
			{0x41, 0x02},{0x42, 0xC9},{0x43,0xF0},{0x44, 0x10},{0x45, 0x6C},
			{0x46, 0x6C},{0x47, 0x44},{0x48,0x44},{0x49, 0x03},{0x4F, 0x50},
			{0x50, 0x43},{0x51, 0x0D},{0x52,0x19},{0x53, 0x4C},{0x54, 0x65},
			{0x59, 0x49},{0x5A, 0x94},{0x5B,0x46},{0x5C, 0x84},{0x5D, 0x5C},
			{0x5E, 0x08},{0x5F, 0x00},{0x60,0x14},{0x61, 0xCE},{0x62, 0x70},
			{0x63, 0x00},{0x64, 0x04},{0x65,0x00},{0x66, 0x00},{0x69, 0x00},
			{0x6A, 0x3E},{0x6B, 0x3F},{0x6C,0x40},{0x6D, 0x30},{0x6E, 0x4B},
			{0x6F, 0x60},{0x70, 0x70},{0x71,0x70},{0x72, 0x70},{0x73, 0x70},
			{0x74, 0x60},{0x75, 0x60},{0x76,0x50},{0x77, 0x48},{0x78, 0x3A},
			{0x79, 0x2E},{0x7A, 0x28},{0x7B,0x22},{0x7C, 0x04},{0x7D, 0x07},
			{0x7E, 0x10},{0x7F, 0x28},{0x80,0x36},{0x81, 0x44},{0x82, 0x52},
			{0x83, 0x60},{0x84, 0x6C},{0x85,0x78},{0x86, 0x8C},{0x87, 0x9E},
			{0x88, 0xBB},{0x89, 0xD2},{0x8A,0xE6},{0x13, 0xAF},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 352x288 Mode (CIF) in YCbCr Camera
    // pass Thru Mode
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    320,
		/* frame heigth         */    240,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"YCbCr_QVGA_raw",
		/* Cmos output format   */    CMOS_CCIR656,
		/* Resolution Format    */    YCbCr_QVGA_RAW,
		/* DPS mode             */    CIM_CONFIG_RAW,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    1,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    94,
        {
			{0x12, 0x80},{0x11, 0x81},{0x12,0x10},{0x13, 0xA8},{0x01, 0x80},
			{0x02, 0x80},{0x04, 0x40},{0x0C,0x04},{0x0D, 0xC0},{0x0E, 0x81},
			{0x0f, 0x4F},{0x14, 0x4A},{0x16,0x02},{0x1B, 0x01},{0x24, 0x70},
			{0x25, 0x68},{0x26, 0xD3},{0x27,0x90},{0x2A, 0x00},{0x2B, 0x00},
			{0x33, 0x02},{0x37, 0x02},{0x38,0x13},{0x39, 0xF0},{0x3A, 0x00},
			{0x3B, 0x01},{0x3C, 0x46},{0x3D,0x90},{0x3E, 0x02},{0x3F, 0xF2},
			{0x41, 0x02},{0x42, 0xC9},{0x43,0xF0},{0x44, 0x10},{0x45, 0x6C},
			{0x46, 0x6C},{0x47, 0x44},{0x48,0x44},{0x49, 0x03},{0x4F, 0x50},
			{0x50, 0x43},{0x51, 0x0D},{0x52,0x19},{0x53, 0x4C},{0x54, 0x65},
			{0x59, 0x49},{0x5A, 0x94},{0x5B,0x46},{0x5C, 0x84},{0x5D, 0x5C},
			{0x5E, 0x08},{0x5F, 0x00},{0x60,0x14},{0x61, 0xCE},{0x62, 0x70},
			{0x63, 0x00},{0x64, 0x04},{0x65,0x00},{0x66, 0x00},{0x69, 0x00},
			{0x6A, 0x3E},{0x6B, 0x3F},{0x6C,0x40},{0x6D, 0x30},{0x6E, 0x4B},
			{0x6F, 0x60},{0x70, 0x70},{0x71,0x70},{0x72, 0x70},{0x73, 0x70},
			{0x74, 0x60},{0x75, 0x60},{0x76,0x50},{0x77, 0x48},{0x78, 0x3A},
			{0x79, 0x2E},{0x7A, 0x28},{0x7B,0x22},{0x7C, 0x04},{0x7D, 0x07},
			{0x7E, 0x10},{0x7F, 0x28},{0x80,0x36},{0x81, 0x44},{0x82, 0x52},
			{0x83, 0x60},{0x84, 0x6C},{0x85,0x78},{0x86, 0x8C},{0x87, 0x9E},
			{0x88, 0xBB},{0x89, 0xD2},{0x8A,0xE6},{0x13, 0xAF},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 352x288 Mode (CIF) in YCbCr Camera
    // pass Thru Mode
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    176,
		/* frame heigth         */    144,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"YCbCr_QCIF_raw",
		/* Cmos output format   */    CMOS_CCIR656,
		/* Resolution Format    */    YCbCr_QCIF_RAW,
		/* DPS mode             */    CIM_CONFIG_RAW,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    1,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    94,
        {
			{0x12, 0x80},{0x11, 0x81},{0x12,0x08},{0x13, 0xA8},{0x01, 0x80},
			{0x02, 0x80},{0x04, 0x40},{0x0C,0x04},{0x0D, 0xC0},{0x0E, 0x81},
			{0x0f, 0x4F},{0x14, 0x4A},{0x16,0x02},{0x1B, 0x01},{0x24, 0x70},
			{0x25, 0x68},{0x26, 0xD3},{0x27,0x90},{0x2A, 0x00},{0x2B, 0x00},
			{0x33, 0x02},{0x37, 0x02},{0x38,0x13},{0x39, 0xF0},{0x3A, 0x00},
			{0x3B, 0x01},{0x3C, 0x46},{0x3D,0x90},{0x3E, 0x02},{0x3F, 0xF2},
			{0x41, 0x02},{0x42, 0xC9},{0x43,0xF0},{0x44, 0x10},{0x45, 0x6C},
			{0x46, 0x6C},{0x47, 0x44},{0x48,0x44},{0x49, 0x03},{0x4F, 0x50},
			{0x50, 0x43},{0x51, 0x0D},{0x52,0x19},{0x53, 0x4C},{0x54, 0x65},
			{0x59, 0x49},{0x5A, 0x94},{0x5B,0x46},{0x5C, 0x84},{0x5D, 0x5C},
			{0x5E, 0x08},{0x5F, 0x00},{0x60,0x14},{0x61, 0xCE},{0x62, 0x70},
			{0x63, 0x00},{0x64, 0x04},{0x65,0x00},{0x66, 0x00},{0x69, 0x00},
			{0x6A, 0x3E},{0x6B, 0x3F},{0x6C,0x40},{0x6D, 0x30},{0x6E, 0x4B},
			{0x6F, 0x60},{0x70, 0x70},{0x71,0x70},{0x72, 0x70},{0x73, 0x70},
			{0x74, 0x60},{0x75, 0x60},{0x76,0x50},{0x77, 0x48},{0x78, 0x3A},
			{0x79, 0x2E},{0x7A, 0x28},{0x7B,0x22},{0x7C, 0x04},{0x7D, 0x07},
			{0x7E, 0x10},{0x7F, 0x28},{0x80,0x36},{0x81, 0x44},{0x82, 0x52},
			{0x83, 0x60},{0x84, 0x6C},{0x85,0x78},{0x86, 0x8C},{0x87, 0x9E},
			{0x88, 0xBB},{0x89, 0xD2},{0x8A,0xE6},{0x13, 0xAF},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Omnivision OV9640 Camera 640x480 Mode (SXGA) in YCbCr Planar Mode
    //////////////////////////////////////////////////////////////////////////

	{
		/* frame width          */    640,
		/* frame heigth         */    480,
		/* camera name          */    L"Omnivision",
		/* camera mode          */    L"YCbCr_VGA",
		/* Cmos output format   */    CMOS_CCIR656,
		/* Resolution Format    */    YCbCr_VGA,
		/* DPS mode             */    CIM_CONFIG_656,
		/* Bayer Mode           */    CIM_CONFIG_BGGR,
		/* dbdma channel        */    3,
		/* Device Address       */    0x30,

		/* No of Sub Register   */    94,
        {
			{0x12, 0x80},{0x11, 0x81},{0x12,0x40},{0x13, 0xA8},{0x01, 0x80},
			{0x02, 0x80},{0x04, 0x40},{0x0C,0x04},{0x0D, 0xC0},{0x0E, 0x81},
			{0x0f, 0x4F},{0x14, 0x4A},{0x16,0x02},{0x1B, 0x01},{0x24, 0x70},
			{0x25, 0x68},{0x26, 0xD3},{0x27,0x90},{0x2A, 0x00},{0x2B, 0x00},
			{0x33, 0x02},{0x37, 0x02},{0x38,0x13},{0x39, 0xF0},{0x3A, 0x00},
			{0x3B, 0x01},{0x3C, 0x46},{0x3D,0x90},{0x3E, 0x02},{0x3F, 0xF2},
			{0x41, 0x02},{0x42, 0xC9},{0x43,0xF0},{0x44, 0x10},{0x45, 0x6C},
			{0x46, 0x6C},{0x47, 0x44},{0x48,0x44},{0x49, 0x03},{0x4F, 0x50},
			{0x50, 0x43},{0x51, 0x0D},{0x52,0x19},{0x53, 0x4C},{0x54, 0x65},
			{0x59, 0x49},{0x5A, 0x94},{0x5B,0x46},{0x5C, 0x84},{0x5D, 0x5C},
			{0x5E, 0x08},{0x5F, 0x00},{0x60,0x14},{0x61, 0xCE},{0x62, 0x70},
			{0x63, 0x00},{0x64, 0x04},{0x65,0x00},{0x66, 0x00},{0x69, 0x00},
			{0x6A, 0x3D},{0x6B, 0x3F},{0x6C,0x40},{0x6D, 0x30},{0x6E, 0x4B},
			{0x6F, 0x60},{0x70, 0x70},{0x71,0x70},{0x72, 0x70},{0x73, 0x70},
			{0x74, 0x60},{0x75, 0x60},{0x76,0x50},{0x77, 0x48},{0x78, 0x3A},
			{0x79, 0x2E},{0x7A, 0x28},{0x7B,0x22},{0x7C, 0x04},{0x7D, 0x07},
			{0x7E, 0x10},{0x7F, 0x28},{0x80,0x36},{0x81, 0x44},{0x82, 0x52},
			{0x83, 0x60},{0x84, 0x6C},{0x85,0x78},{0x86, 0x8C},{0x87, 0x9E},
			{0x88, 0xBB},{0x89, 0xD2},{0x8A,0xE6},{0x13, 0xAF},
		}
	},

    //////////////////////////////////////////////////////////////////////////
    // Analog Devices 7180 NTSC CCIR656 Interlaced
    //////////////////////////////////////////////////////////////////////////
	{
		/* frame width          */  720,
		/* frame heigth         */  512,
		/* camera name          */  L"Analog Devices",
		/* camera mode          */  L"YCbCr_D1_raw",
		/* Cmos output format   */  INT_CCIR656, //CFG_422 | CFG_YUYV | CFG_LITTLE_ENDIAN | CFG_INTERLEAVED,
		/* Resolution Format    */  YCbCr_NTSC,
		/* DPS mode             */  CIM_CONFIG_656,
		/* Bayer Mode           */  CIM_CONFIG_BGGR,
		/* dbdma channel        */  2,
		/* Device Address       */  0x21,

		/* No of Sub Register   */  10,
        {
			{0x03, 0x0C}, // Enable SFL
			{0x04, 0x52}, // Enable SFL
			{0x17, 0x41}, // Select SH1
			{0x31, 0x02}, // Clear NEWAV_MODE, SAV/EAV to suit ADV video encoders
			{0x3D, 0xA2}, // MWE enable manual window, color kill threshold to 2
			{0x3E, 0x6A}, // BLM optimization
			{0x3F, 0xA0}, // BGB optimization
			{0x0E, 0x80}, // Hidden space
			{0x55, 0x81}, // ADC configuration
			{0x0E, 0x00}, // ADC configuration
		}
	},
};

#define NUM_CAMERA_MODES    (sizeof(CameraModes)/sizeof(CAMERA))


// Utility functions
// Quick note: the functions below adapt the "old" SMBUS calls to
// ..the "new" way of doing things.  sub_addr is actually the register
// ..on the slave device and is packed in as part of the transfer data
// ..automatically.

static BOOL DeviceWriteReg(USHORT dev_addr, USHORT sub_addr, USHORT data)
{
  SMBUS_TRANSFER Transfer;

  Transfer.Address 	= (UCHAR)dev_addr;
  Transfer.Data[0]  = (UCHAR)sub_addr;
  Transfer.Data[1] 	= (UCHAR)data;
  Transfer.DataSize 	= 2;
  return SMBus_WriteData(hI2C, &Transfer);

}

/******************************************************************************
             Capture Image
 ******************************************************************************/

static BOOL Capture_Image(void)
{
	pCim->capture = 0; // demand that any in-progress captures terminate
    while (pCim->stat & (CIM_STATUS_SC | CIM_STATUS_VC)) {
        DEBUGMSG(ZONE_TRACE, (L"CAM Capture_image waiting for last frame to finish...\r\n"));
        Sleep(10);
    }

	pCim->capture = CIM_CAPTURE_CLR;  // clear the data path
	pCim->capture = CIM_CAPTURE_SCE;  // trigger a snapshot

    return TRUE;
}

/******************************************************************************
             Power Down Camera
 ******************************************************************************/

static void Camera_pwr_down(DEVICE_CONTEXT* p)
{
    if ( ! bInPowerHandler )
        DEBUGMSG(ZONE_POWER, (TEXT("CAM: Camera_pwr_down\r\n")));

    p->bPowerIsOn = FALSE;
}

/******************************************************************************
             Power Up Camera
*******************************************************************************/

static void Camera_pwr_up(DEVICE_CONTEXT* p)
{
    if ( ! bInPowerHandler )
        DEBUGMSG(ZONE_POWER, (TEXT("CAM: Camera_pwr_up\r\n")));

	// pBcsr->specific &= ~(BCSR_SPECIFIC_CAMPWRDOWN | BCSR_SPECIFIC_CAM_CS);
    p->bPowerIsOn = TRUE;
}

/*******************************************************
        Clean Up Function (cleans memory, channel allocation etc)
 ********************************************************/

void CAM_Cleanup( CAMERA_RUNTIME *cim_cleanup)
{
    CAMERA  *cim_ptr;
    DWORD   frame_size;

    cim_ptr    = cim_cleanup->cmos_camera;
    frame_size = cim_ptr->frame_width*cim_ptr->frame_height;

    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: CAM_Cleanup: cleaning mode %s\r\n"),
                         cim_ptr->camera_mode));

    cim_cleanup->cmos_camera = 0; // mark the camera "unconfigured"

    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: DMA Channel and Memory Cleared Now!\r\nCAM: Ready to be reused\r\n")));
}

/****************************************************************************
            DMA Channel COnfiguration
	    External Camera configuration using SMBus
	    Au1200 Comtrol Block configuration
 ****************************************************************************/

int Camera_Config(CAMERA_RUNTIME* cim_config )
{
    int i;
    CAMERA * const cim_config_ptr = cim_config->cmos_camera;
    const DWORD frame_size = cim_config_ptr->frame_width * cim_config_ptr->frame_height;

	int     ErrorCheck         = 0;
	DWORD   nCameraModeConfig  = 0;
	DWORD   nClearSetInterrupt = 0;

	DEBUGMSG(ZONE_TRACE, (TEXT("CAM: Camera_Config: width %d, height %d, ch %d, DPS mode %d\r\n"),
	            cim_config_ptr->frame_width,
                cim_config_ptr->frame_height,
                cim_config_ptr->dbdma_channel,
                cim_config_ptr->au1200_dpsmode));

    /*************************************************
	    Setting up DBDMA Channel
     *************************************************/

	// To get rid of hard-coded number from Transfer Size,
	// transfer size will be calulated on the fly:

    //      In YCbCr 4:2:2 data size is twice the frame size
    //      Y=Frame Size
    //      Cb=Frame Size/2
    //      Cr=Frame Size/2
    //      Total size of Frame: Y+Cb+Cr effectively 2*FrameSize

	if ( cim_config_ptr->au1200_dpsmode == CIM_CONFIG_RAW )
	{
        if ( cim_config_ptr->cmos_output_format == CMOS_CCIR656 )
		{
		    cim_config->nTransferSize[0] = frame_size * 2;
		    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: FIFO-A YCbCR Transfer Size in Raw mode %d \r\n"),
                        cim_config->nTransferSize[0]));
		}
		else
		{
	        cim_config->nTransferSize[0] = frame_size;
		    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: FIFO-A RGB Transfer Size in Raw mode %d \r\n"),
                        cim_config->nTransferSize[0]));
		}
    }
	else if ( cim_config_ptr->au1200_dpsmode == CIM_CONFIG_BAYER )
	{
	    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: Bayer Mode (Planar) Memory Size Calculation\r\n")));

	    /* FIFO A Hold Red Pixels which is Total Pixels/4 */
	    cim_config->nTransferSize[0] = frame_size / 4;
	    cim_config->nTransferSize[1] = frame_size / 2;
	    cim_config->nTransferSize[2] = frame_size / 4;
	    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: Transfer Size of FIFO-A %d FIFO-B %d & FIFO-C in Bayer Mode %d\r\n"),
                        cim_config->nTransferSize[0],
	                    cim_config->nTransferSize[1],
                        cim_config->nTransferSize[2]));
    }
	else
	{
		if ( cim_config_ptr->cmos_output_format == INT_CCIR656 )
		{
			cim_config->nTransferSize[0] = frame_size;
			cim_config->nTransferSize[1] = frame_size;
		    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: FIFO-A YCbCR Interlaced Transfer Size in Raw mode %d \r\n"),
                        cim_config->nTransferSize[0]));
			DEBUGMSG(ZONE_TRACE, (TEXT("CAM: FIFO-B YCbCR Interlaced Transfer Size in Raw mode %d \r\n"),
                        cim_config->nTransferSize[1]));
		}
		else
		{
			DEBUGMSG(ZONE_TRACE, (TEXT("CAM: CCIR656 (Planar) Mode Memory Size Calculation\r\n")));

			cim_config->nTransferSize[0] = frame_size;
			cim_config->nTransferSize[1] = frame_size / 2;
			cim_config->nTransferSize[2] = frame_size / 2;
			DEBUGMSG(ZONE_TRACE, (TEXT("CAM: Transfer Size of FIFO-A %d FIFO-B %d & FIFO-C in CCIR656 Mode %d\r\n"),
							cim_config->nTransferSize[0],
							cim_config->nTransferSize[1],
							cim_config->nTransferSize[2]));
		}
	}

    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: DMA Setup Successful\r\n")));

	/****** END DMA****************/

	/********************************
		Configure CMOS CAMERA
	**********************************/

	DEBUGMSG(ZONE_TRACE, (TEXT("CAM: CMOS Camera configuration \n")));
    {
		hI2C = SMBus_Initialize();

		switch(cim_config_ptr->device_addr)
		{
		case 0x30: // Omnivision camera
			RETAILMSG(1, (TEXT("Power Omnivision\r\n")));
			pBcsr->specific &= ~(BCSR_SPECIFIC_CAMPWRDOWN | BCSR_SPECIFIC_CAM_CS);
			break;
		case 0x21: // Analog Devices ADV7180
			RETAILMSG(1, (TEXT("Power ADV7180\r\n")));
			pBcsr->specific |= (BCSR_SPECIFIC_CAMPWRDOWN | BCSR_SPECIFIC_CAM_CS);
			break;
		}


        for ( i=0; i < cim_config_ptr->cmd_size; i++ )
        {

			RETAILMSG (1, (TEXT("CAM: I2C: dev: 0x%x reg: 0x%x val:0x%x\r\n"), cim_config_ptr->device_addr, cim_config_ptr->config_cmd[i][0], cim_config_ptr->config_cmd[i][1]));
			if (!DeviceWriteReg(cim_config_ptr->device_addr, cim_config_ptr->config_cmd[i][0], cim_config_ptr->config_cmd[i][1]))
			{
				RETAILMSG(1, (TEXT("CAM: I2C: Camera count cannot be initialized -1 %d\r\n"), i));
                break;
			}

            if ( i == 0 )
                Sleep(1);
        }


//		ReadStatusRegisters();

//        SMBusDeinit();

        if ( i != cim_config_ptr->cmd_size )
        {
            DEBUGMSG(ZONE_ERROR, (TEXT("CAM: External CMOS camera not present or not properly connected!\r\n")));
            goto error_ch_alloc;
        }
	}
    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: CMOS camera configuration sucessful\r\n")));


	/********************************
	    Configure CAMERA Interface
	**********************************/

	/* Enable the Camera Module*/
	pCim->enable  = CIM_ENABLE_EN;
	pCim->capture = CIM_CAPTURE_CLR;

	/* Config Register Setting */

    nCameraModeConfig = CIM_CONFIG_DPS_N(cim_config_ptr->au1200_dpsmode) |
                        CIM_CONFIG_FS                                    |
					    CIM_CONFIG_BAY_N(cim_config_ptr->au1200_baymode) |
                        CIM_CONFIG_BYT                                   |
					    CIM_CONFIG_LEN_N(CIM_CONFIG_LEN_10BIT);
    switch (cim_config_ptr->au1200_dpsmode) {
	  case 2:
		  if (INT_CCIR656 == cim_config_ptr->cmos_output_format)
			  nCameraModeConfig |= CIM_CONFIG_SI;
		  break;
      case 1:
		  break;
      case 0:
		  nCameraModeConfig |= CIM_CONFIG_PM;
		  break;
      default:
		  nCameraModeConfig |= CIM_CONFIG_FS_N(CIM_CONFIG_FIELD2);
		  break;
    }

	pCim->config = nCameraModeConfig;

	nClearSetInterrupt= CIM_INSTAT_CD  | CIM_INSTAT_FD  |
						CIM_INSTAT_UFA | CIM_INSTAT_OFA |
						CIM_INSTAT_UFB | CIM_INSTAT_OFB |
						CIM_INSTAT_UFB | CIM_INSTAT_OFC;

	// Clear Sticky Bit in the Interrupt Status Register.
	pCim->instat = nClearSetInterrupt;

	// Set Interrupt Bits in Interrupt Enable Register.
	pCim->inten = nClearSetInterrupt;

	DEBUGMSG(ZONE_TRACE, (TEXT("CAM: Config register => 0x%08X \r\n"), pCim->config));

    Sleep(6);

	return 0;

error_ch_alloc:

	if ( ErrorCheck )
	{
		CAM_Cleanup(cim_config);
	}
    return -1;
}


/***************************************************************
 *              Init Module
 ***************************************************************/

////////////////////////////////////////////////////////////////////////
//              Driver Entry
////////////////////////////////////////////////////////////////////////

BOOL WINAPI
DllEntry(HINSTANCE DllInstance, INT Reason, LPVOID Reserved)
{
    switch ( Reason )
    {
        case DLL_PROCESS_ATTACH:
            DEBUGREGISTER(DllInstance);
            DEBUGMSG(ZONE_TRACE, (TEXT("CAM: DllEntry: DLL_PROCESS_ATTACH\r\n")));
            break;

        case DLL_PROCESS_DETACH:
            DEBUGMSG(ZONE_TRACE, (TEXT("CAM: DllEntry: DLL_PROCESS_DETACH\r\n")));
            break;

        default:
            break;
    }

    // return TRUE for success, FALSE for failure
    return TRUE;
}

////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
//              Windows CE Device Driver Entry Points
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////
//              Initialize Device
////////////////////////////////////////////////////////////////////////

BOOL CAM_Deinit(DWORD hDeviceContext);

DWORD
CAM_Init(DWORD pContext)
{
    DEVICE_CONTEXT *pDevice = 0;
    PHYSICAL_ADDRESS    PhysAddr;

    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: CAM_Init(%s)\r\n"), pContext));

    // Allocate device context.
    pDevice = LocalAlloc(LPTR, sizeof(DEVICE_CONTEXT));

    if ( ! pDevice )
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("CAM_Init: Failed to allocate device context\r\n")));
        goto error_exit;
    }
    memset(pDevice, 0, sizeof(*pDevice));

    // Map Camera Interface Module registers.
    PhysAddr.HighPart = 0;
    PhysAddr.LowPart  = CIM_PHYS_ADDR;
    pCim = MmMapIoSpace(PhysAddr, sizeof(AU13XX_CIM), FALSE);
    if ( pCim == NULL )
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("CAM_Init: MmMapIoSpace 0x%08X Failed!\r\n"),
                        CIM_PHYS_ADDR));
        goto error_exit;
    }

    DEBUGMSG(ZONE_TRACE, (TEXT("CAM_Init: CIM:  physical 0x%08X => virtual 0x%08X\r\n"),
                    PhysAddr.LowPart, pCim));

    // Map board contol registers.
    PhysAddr.HighPart = 0;
    PhysAddr.LowPart  = BCSR_PHYSADDR;
    pBcsr = MmMapIoSpace(PhysAddr, sizeof(BCSR), FALSE);
    if ( pBcsr == NULL )
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("CAM_Init: MmMapIoSpace 0x%08X Failed!\r\n"),
                        BCSR_PHYSADDR));
        goto error_exit;
    }

    DEBUGMSG(ZONE_TRACE, (TEXT("CAM_Init: BCSR: physical 0x%08X => virtual 0x%08X\r\n"),
                    PhysAddr.LowPart, pBcsr));

    // Hook the interrupt.
    if ((pDevice->hInterruptEvent = CreateEvent(NULL, FALSE, FALSE, NULL)) == INVALID_HANDLE_VALUE)
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("CAM_Init: cannot create the interrupt event!\r\n")));
        pDevice->hInterruptEvent = 0; // so it looks like we didn't even try to create it
        goto error_exit;
    }
    if ((pDevice->dwSysintr = InterruptConnect(Internal, 0, HWINTR_CIM, 0)) == SYSINTR_NOP)
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("CAM_Init: cannot allocate a sysintr for the CIM!\r\n")));
        goto error_exit;
    }
    if (!InterruptInitialize(pDevice->dwSysintr, pDevice->hInterruptEvent, NULL, 0))
    {
        DEBUGMSG(ZONE_ERROR, (TEXT("CAM_Init: cannot init the CIM interrupt!\r\n")));
        goto error_exit;
    }

    // Clear any pendind and enable
    InterruptDone(pDevice->dwSysintr);

    // Initialize global flags.
    pDevice->bPowerIsOn    = FALSE;
    pDevice->dwCurrentMode = 0;

    // Done.
    return((DWORD) pDevice);

error_exit:

    if ( pDevice )
    {
        // This also frees the allocated memory for pDevice:
        CAM_Deinit((DWORD) pDevice);
    }

    return 0;
}

////////////////////////////////////////////////////////////////////////
//              Deinitialize Device
////////////////////////////////////////////////////////////////////////

BOOL
CAM_Deinit(
    DWORD hDeviceContext
    )
{
    DEVICE_CONTEXT *pDevice = (DEVICE_CONTEXT *) hDeviceContext;

    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: CAM_Deinit\r\n")));

    if ( pDevice )
    {
        CAM_Cleanup(&pDevice->cam_base);
        Camera_pwr_down(pDevice);

        if (pDevice->hInterruptEvent != 0)
        {
            if (pDevice->dwSysintr != SYSINTR_NOP)
            {
                InterruptDisable(pDevice->dwSysintr);    // dissociate from the intr event
                InterruptDisconnect(pDevice->dwSysintr); // dissociate from the hwintr
            }
            CloseHandle(pDevice->hInterruptEvent);
        }

        if ( pCim )
        {
            MmUnmapIoSpace((PVOID) pCim, sizeof(AU13XX_CIM));
            pCim = NULL;
        }

        if ( pBcsr )
        {
            MmUnmapIoSpace((PVOID) pBcsr, sizeof(BCSR));
            pBcsr = NULL;
        }

        // Free the device context.
        LocalFree(pDevice);
        pDevice = NULL;
    }

    return TRUE;
}

////////////////////////////////////////////////////////////////////////
//              Open Device
////////////////////////////////////////////////////////////////////////

DWORD
CAM_Open(
    DWORD hDeviceContext,
    DWORD AccessCode,
    DWORD Sharemode
    )
{
    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: CAM_Open\r\n")));

    // **** TBD: Increment read/write access counts?
    // **** TBD: Enforce 1 write access?

    return(hDeviceContext);
}

////////////////////////////////////////////////////////////////////////
//              Close Device
////////////////////////////////////////////////////////////////////////

BOOL
CAM_Close(
    DWORD hOpenContext
    )
{
    DEBUGMSG(ZONE_TRACE, (TEXT("CAM: CAM_Close\r\n")));

    // **** TBD: Decrement read/write access counts?
    // **** TBD: If write access goes to 0, stop in-progress activity and
    //           power down camera?

    return(TRUE);
}

////////////////////////////////////////////////////////////////////////
//              Power Up
////////////////////////////////////////////////////////////////////////

void
CAM_PowerUp(
    DWORD hDeviceContext
    )
{
    // **** TBD: Skip if camera not powered up?
    // **** TBD: Restart paused activity?

    bInPowerHandler = TRUE;
    Camera_pwr_up((DEVICE_CONTEXT*)hDeviceContext);
    bInPowerHandler = FALSE;
}

////////////////////////////////////////////////////////////////////////
//              Power Down
////////////////////////////////////////////////////////////////////////

void
CAM_PowerDown(
    DWORD hDeviceContext
    )
{
    // **** TBD: Pause any activity?

    bInPowerHandler = TRUE;
    Camera_pwr_down((DEVICE_CONTEXT*)hDeviceContext);
    bInPowerHandler = FALSE;
}

////////////////////////////////////////////////////////////////////////
//              I/O Control Device
////////////////////////////////////////////////////////////////////////

BOOL
CAM_IOControl(
    DWORD hOpenContext,
    DWORD dwCode,
    PBYTE pBufIn,
    DWORD dwLenIn,
    PBYTE pBufOut,
    DWORD dwLenOut,
    PDWORD pdwActualOut
    )
{
    DWORD actual = 0;
    DWORD result = ERROR_SUCCESS;

    DEVICE_CONTEXT *pDevice = (DEVICE_CONTEXT *) hOpenContext;

    if ( ! pDevice )
    {
        RETAILMSG(1, (TEXT("CAM_IOControl - Device context not allocated\r\n")));
        result = ERROR_GEN_FAILURE;
        goto error_exit;
    }

    DEBUGMSG(ZONE_TRACE,
              (TEXT("CAM: CAM_IOControl(0x%X, 0x%X, %d, 0x%X, %d, 0x%X)\r\n"),
                    dwCode, pBufIn, dwLenIn, pBufOut, dwLenOut, pdwActualOut));

    //////////////////////////
    // Process request.
    //////////////////////////

    switch ( dwCode )
    {
      case IOCTL_CAMERA_QUERY:
        // **** TBD: Define parameters
        // **** TBD: Verify parameters
        // **** TBD: Return whatever we are returning
        DEBUGMSG(ZONE_TRACE, (L" CAM QUERY Mode\r\n"));
        if (dwLenOut < sizeof(CameraMode)) {
            result = ERROR_INSUFFICIENT_BUFFER;
            goto error_exit;
        } else {
            CAMERA *pcam = pDevice->cam_base.cmos_camera;
            if (pcam) {
                CameraMode *pmode = (CameraMode*) pBufOut;
                pmode->mode = pcam->camera_resformat;
                memcpy(pmode->modename, pcam->camera_mode, sizeof(pcam->camera_mode));
                pmode->width = pcam->frame_width;
                pmode->height = pcam->frame_height;
                pmode->nPlanes = pcam->dbdma_channel;
                actual = sizeof(*pmode);
            } else {
                // no configuration has been set so there's nothing to report
                result = ERROR_NOT_CONNECTED; // for lack of a better choice
                goto error_exit;
            }
        }
        break;

      case IOCTL_CAMERA_CONFIGURE:
      {
          int resmode, mode_index;

          // BufIn is an int, identifying the camera mode to configure.
          // A list of modes is enumerated in camera.h.
          // Only modes 1 through 7 are known to work yet.
          if (dwLenIn != sizeof(int)) {
              result = ERROR_INVALID_DATA;
              goto error_exit;
          }
          memcpy(&resmode, pBufIn, sizeof(int));
		  for (mode_index=0; mode_index<NUM_CAMERA_MODES; ++mode_index) {
			  RETAILMSG(0, (L"resmode %d cam_mode %d\n", resmode, CameraModes[mode_index].camera_resformat));
              if (resmode == CameraModes[mode_index].camera_resformat)
                  break;
		  }
          if (mode_index == NUM_CAMERA_MODES) {
              result = ERROR_INVALID_INDEX;
              goto error_exit;
          }
          DEBUGMSG(ZONE_TRACE, (L" CAM CONFIGURE Mode %d => Index %d\n", resmode, mode_index));

          pDevice->dwCurrentMode = mode_index;
          pDevice->cam_base.cmos_camera = &CameraModes[mode_index];

          /* Configure CMOS Camera*/
          if (!pDevice->bPowerIsOn) {
              DEBUGMSG(ZONE_TRACE, (L" CAM CONFIGURE turning camera power on\n"));
              Camera_pwr_up(pDevice);
          }
          pCim->enable &= ~CIM_ENABLE_EN;
          if (Camera_Config(&pDevice->cam_base) == 0) {
              Camera_pwr_down(pDevice);
              Sleep(1);
              Camera_pwr_up(pDevice);
              Sleep(6);
          }  else {
              result = ERROR_GEN_FAILURE;
          }
      }
      break;

      case IOCTL_CAMERA_CAPTURE:
      {
          CAMERA* pcam = pDevice->cam_base.cmos_camera;
          DWORD camera_status;

          if (pcam == 0) {
              // unconfigured cameras cannot take snapshots!
              result = ERROR_NOT_CONNECTED; // would prefer NOT_CONFIGURED if it existed.
              goto error_exit;
          }
          DEBUGMSG(ZONE_TRACE, (L"CAM CAPTURE: Camera Array Index # %d : %s (%d x %d = %d)\r\n",
                               pDevice->dwCurrentMode,
                               pcam->camera_mode,
                               pcam->frame_width,
                               pcam->frame_height,
                               pcam->frame_width * pcam->frame_height));

          // Fetch and validate parameters
          if (((DWORD)pBufOut & 3) != 0) {
              // bad buffer alignment!
              result = ERROR_INVALID_DATA;
          }
          if (dwLenOut < pcam->frame_width*pcam->frame_height) {
              result = ERROR_INSUFFICIENT_BUFFER;
          }
          if (result != ERROR_SUCCESS)
              goto error_exit;

          // Make sure there is no stray interrupt pending
          while (WaitForSingleObject(pDevice->hInterruptEvent, 0) == WAIT_OBJECT_0)
          {
              pCim->instat = 0x1ff; // ack all intrs; don't care what they are.
              InterruptDone(pDevice->dwSysintr);
          }

		  pCim->cim_rxc_buf0	= 0;
		  pCim->cim_rxc_max		= 0;
		  pCim->cim_rxb_buf0	= 0;
		  pCim->cim_rxb_max		= 0;
		  pCim->cim_rxa_buf0	= 0;
		  pCim->cim_rxa_max		= 0;

		  switch (pcam->dbdma_channel)
		  {
		  case 3:
			  pCim->cim_rxc_buf0	= (unsigned long)pBufOut + pDevice->cam_base.nTransferSize[0] + pDevice->cam_base.nTransferSize[1];
			  pCim->cim_rxc_max		= (unsigned long)pDevice->cam_base.nTransferSize[2];
		  case 2:
			  pCim->cim_rxb_buf0	= (unsigned long)pBufOut + pDevice->cam_base.nTransferSize[0];
			  pCim->cim_rxb_max		= (unsigned long)pDevice->cam_base.nTransferSize[1];
		  case 1:
			  pCim->cim_rxa_buf0	= (unsigned long)pBufOut;
			  pCim->cim_rxa_max		= (unsigned long)pDevice->cam_base.nTransferSize[0];
			  break;
		  default:
			  RETAILMSG (1, (TEXT("Unsupported number of DMA channels [0x%x]\r\n"), pcam->dbdma_channel));
			  break;
		  }

		  // Enable DMA, Swizzle word and halfword, and burst size of 8
		  pCim->config2 =	CIM_CONFIG2_DW | CIM_CONFIG2_SW | CIM_CONFIG2_BS(3);

#ifdef BLANKSCREEN // this alleviates memory bus contention while streaming from the camera
          { DWORD oldlcd = *(DWORD*)0xb5000024; *(DWORD*)0xb5000024 = 0;
#endif

          Capture_Image(); // trigger the snapshot
          RETAILMSG(0, (L"CAM CAPTURE:Status Reg %x Capture Reg %x IntStat %x\r\n",
                               pCim->stat, pCim->capture, pCim->instat));

          // wait for the snapshot to complete.
          camera_status = 0;
		  do {
              DWORD t;
              WaitForSingleObject(pDevice->hInterruptEvent, 1000 /* INFINITE */);
              t = pCim->instat; // perform only one read
			  RETAILMSG(0, (L"INSTAT %04x\n", t));
			  camera_status |= t; // and remember that the condition occurred
              pCim->instat = t; // ack the interrupt/s
              InterruptDone(pDevice->dwSysintr);
          } while ( ! (camera_status & CIM_INTEN_CD) ); // repeat until done

          DEBUGMSG(ZONE_TRACE, (L"CAM CAPTURE: cleaning\r\n"));
#ifdef BLANKSCREEN
          *(DWORD*)0xb5000024 = oldlcd; }
#endif

          DEBUGMSG(ZONE_TRACE, (L"CAM CAPTURE:Status Reg %x Capture Reg %x IntStat %x\r\n",
                                   pCim->stat, pCim->capture, camera_status));
          DEBUGMSG(ZONE_TRACE, (L"CAM CAPTURE: Snapped %d bytes\r\n", actual));
      }
      break;

      default:
        result = ERROR_NOT_SUPPORTED;
        break;
    }

error_exit:

    if ( pdwActualOut )
    {
        *pdwActualOut = actual;
    }
    if ( result != ERROR_SUCCESS )
    {
        SetLastError(result);
    }

    return(result == ERROR_SUCCESS);
}


#if 0
BOOL SMBusInit(void)
{
	if (g_hSMB)
		return TRUE;

	g_hSMB = CreateFile(L"I2C1:", 0, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if (g_hSMB == INVALID_HANDLE_VALUE)
    {
		g_hSMB = NULL;
        DEBUGMSG(ZONE_TRACE, (L"CIM: cannot open a handle to the I2C\r\n"));
		return FALSE;
    }

	return TRUE;
}

BOOL SMBusDeinit(void)
{
	if (g_hSMB)
	{
		CloseHandle(g_hSMB);
		g_hSMB = NULL;
	}

	return TRUE;
}
#endif

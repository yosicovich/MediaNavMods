//
// Copyright (c) 2005 BSQUARE Corporation. All rights reserved.
//
//

#ifndef __CIM_H
#define __CIM_H


// Debug zones
#define ZONE_TRACE      DEBUGZONE(0)
#define ZONE_POWER      DEBUGZONE(13)
#define ZONE_WARNING    DEBUGZONE(14)
#define ZONE_ERROR      DEBUGZONE(15)

// Number of DMA channels used by CIM interface.
#define MAX_DBDMA_CHANNEL       3

// Maximum commands sent over SMbus to configure external camera device.
#define MAX_DEVICE_CMD          115

#define MAX_FRAME_SIZE          (1280*960) 

// Camera device configuration.

struct s_CAMERA
{
    DWORD   frame_width;      // Frame Width (Pixel per Line)
    DWORD   frame_height;     // Frame Height
    TCHAR   camera_name[32];  // Camera Name (Display/Debug Purpose)
    TCHAR   camera_mode[32];  // Camera Mode(Display/Debug Purpose)
    DWORD   cmos_output_format; // CMOS Camera output (Bayer, CCIR656
    DWORD   camera_resformat; // Camera Mode(Display/Debug Purpose)
    DWORD   au1200_dpsmode;   // Data Pattern Select ie: Mode on Camera Interface (BAYER, YUV, RAW)
    DWORD   au1200_baymode;   // Mode within BAYER mode
    int     dbdma_channel;    // Number of DBDMA channels to be used 
    BYTE    device_addr;      // Camera Device address
    int     cmd_size;         // Number of commands to be sent to device

    // Initialization array: command+data.
    BYTE    config_cmd[MAX_DEVICE_CMD][2];
};
typedef const struct s_CAMERA CAMERA;

typedef struct
{
    PDMA_CHANNEL_OBJECT ChannelArray[MAX_DBDMA_CHANNEL];// Pointers to DBDMA structures
//    void        *memory[MAX_DBDMA_CHANNEL];       // Number of DMA channels
    DWORD       nTransferSize[MAX_DBDMA_CHANNEL]; // Transfer size for DMA descriptor
    CAMERA      *cmos_camera;
}
    CAMERA_RUNTIME;

typedef struct
{
    BOOL bPowerIsOn;         // Current camera power state
    DWORD dwCurrentMode;      // Current camera mode index

    DWORD dwSysintr;
    HANDLE hInterruptEvent;

    CAMERA_RUNTIME cam_base;
}
    DEVICE_CONTEXT;

#endif      // __CIM_H


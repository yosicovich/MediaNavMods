/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/


#include <windows.h>
#include <platform.h>
#include <bceddk.h>
#include "aclink.h"

static volatile AC97_GLOBALS *g_pAc97Shared = NULL;

static PSC_AC97 *g_pAC97  = NULL;

BOOL Au13xxAC97Write(PSC_AC97 *pAC97, ULONG Reg, UINT16 Value);
BOOL Au13xxAC97Read(PSC_AC97 *pAC97, ULONG InReg, ULONG *Result);
BOOL Au13xxAc97Init(PSC_AC97 *pAC);

static BOOL InitializeCodec(PSC_AC97 *pAC);

BOOL InitializeACLink(BOOL InPowerHandler, UINT8 DevId)
{
    DEBUGMSG(1, (TEXT("InitializeACLink()\r\n")));

	RETAILMSG(1, (TEXT("InitializeACLink() -- Dev 0x%x\r\n"), DevId));

    // Allocate AC link control resources.
    //
    if (!AllocateACLinkResources(DevId))
    {
        return(FALSE);
    }

    return(TRUE);
}

BOOL DeInitializeACLink(BOOL InPowerHandler, UINT8 DevId)
{
    DEBUGMSG(1, (TEXT("DeInitializeACLink()\r\n")));

    if (!DeAllocateACLinkResources(DevId))
    {
        return(FALSE);
    }

    return(TRUE);
}

/////////////////////////////////////
// REMOVE REMOVE REMOVE REMOVE
//		REMOVE REMOVE REMOVE REMOVE
//			REMOVE REMOVE REMOVE REMOVE
///////////////////////////////////////
#define AC97_POWER_CONTROL           	    0x26
#define PR4                     0x1000  // WO - 1 powers down AC-Link; 0 powers up

static BOOL AllocateACLinkResources(UINT8 DevId)
{
    PHYSICAL_ADDRESS RegPA;

	if (NULL == g_pAC97)
	{
		RegPA.QuadPart = PLATFORM_AC97_PSC;
		g_pAC97 = (PSC_AC97 *) MmMapIoSpace(RegPA, sizeof(PSC_AC97), FALSE);
	}

    if (hACLinkControlMutex == NULL)
    {
        hACLinkControlMutex = CreateMutex(NULL, FALSE, ACLINK_MUTEX_NAME);
    }

    if (NULL == g_pAc97Shared)
    {
        HANDLE hShareMap;
        DWORD dwError;
        hShareMap = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE,
                    0, sizeof(AC97_GLOBALS), AC97_SHARED_FILENAME );
        dwError = GetLastError();
        if((0 == dwError) || (ERROR_ALREADY_EXISTS == dwError))
        {
            // Get a valid process pointer to the buffer mapped above.
            g_pAc97Shared = (volatile AC97_GLOBALS *)MapViewOfFile( hShareMap, FILE_MAP_ALL_ACCESS, 0, 0, 0 );
            //handle is not needed because mapped view has an internal open handle to the object
            CloseHandle(hShareMap);

            if (g_pAc97Shared && (0 == dwError))
            {
                g_pAc97Shared->InitRefCnt = 0;
            }
        }
    }

    if (!g_pAC97)
    {
        DEBUGMSG(TRUE, (TEXT("ERROR:  Failed to allocate AC Link resources.\r\n")));
        DeAllocateACLinkResources(DevId);
        return(FALSE);
    }


    return(TRUE);
}


static BOOL DeAllocateACLinkResources(UINT8 DevId)
{
	if (g_pAC97)
    {
        VirtualFree((void *)g_pAC97, 0, MEM_RELEASE);
        g_pAC97 = NULL;
    }

    if (g_pAc97Shared)    
    {
        UnmapViewOfFile((void *)g_pAc97Shared);
        g_pAc97Shared = NULL;
    }

    if (hACLinkControlMutex)
    {
        CloseHandle(hACLinkControlMutex);
        hACLinkControlMutex = NULL;
    }

    return(TRUE);
}

BOOL ConfigureAC97Control(void)
{
    if (!GetAC97Lock())
    {
        return(FALSE);
    }

    DEBUGMSG(1, (TEXT("ConfigureAC97Control: InitRefCnt=%d\r\n"), g_pAc97Shared->InitRefCnt));

    if (g_pAc97Shared->InitRefCnt)
    {
        g_pAc97Shared->InitRefCnt++;
        ReleaseAC97Lock();
        return(TRUE);
    }

	if (Au13xxAc97Init(g_pAC97) != TRUE)
    {
        DEBUGMSG(1, (TEXT("CongirureAC97Control: Au13xxAc97Init() failed\r\n")));
        ReleaseAC97Lock();
        return(FALSE);
    }

	// Finally power up AC-Link to stop the bit clk.
	WriteAC97(AC97_POWER_CONTROL, 0, 0);

    g_pAc97Shared->InitRefCnt = 1;
    ReleaseAC97Lock();
    return(TRUE);
}

BOOL UnConfigureAC97Control(void)
{
    if(g_pAc97Shared->InitRefCnt == 0)
    {
        DEBUGMSG(1, (TEXT("Reference count is zero!\r\n")));
        return FALSE;
    }

    if (!GetAC97Lock())
    {
        return(FALSE);
    }
    
    g_pAc97Shared->InitRefCnt--;

    if (g_pAc97Shared->InitRefCnt)
    {
        ReleaseAC97Lock();
        return(TRUE);
    }

	// Finally power up AC-Link to stop the bit clk.
	WriteAC97(AC97_POWER_CONTROL, PR4, 0);

    ReleaseAC97Lock();
    return(TRUE);
}

BOOL GetAC97Lock(void)
{   

    if (WaitForSingleObject(hACLinkControlMutex, 3000) == WAIT_OBJECT_0)
    {
        return(TRUE);
    }
    else
    {
        DEBUGMSG(1, (TEXT("GetAC97Lock failed\r\n")));
        return(FALSE);
    }
}

BOOL ReleaseAC97Lock(void)
{
    ReleaseMutex(hACLinkControlMutex);

    return(TRUE);
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL ReadAC97Raw(UINT Offset, UINT16 *pData, UINT8 DevId)
{
	ULONG Data;

	if (Au13xxAC97Read(g_pAC97, Offset, &Data) != TRUE)
    {
		DEBUGMSG(1, (TEXT("ReadAC97Raw failed\r\n")));
        return(FALSE);
    }

	*pData = (UINT16)Data;

    return(TRUE);
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL ReadAC97(UINT Offset, UINT16 *pData, UINT8 DevId)
{
    BOOL retVal = FALSE;

    if (GetAC97Lock() == TRUE)
    {
        retVal = ReadAC97Raw(Offset, pData, DevId);
        ReleaseAC97Lock();
    }

    return(retVal);
}

BOOL WriteAC97Raw(UINT Offset, UINT16 Data, UINT8 DevId)
{
	if (Au13xxAC97Write(g_pAC97, Offset, Data) != TRUE)
    {
        DEBUGMSG(1, (TEXT("WriteAC97Raw failed - Dev 0x%x\r\n"), DevId));
        return(FALSE);
    }

    return(TRUE);
}

BOOL WriteAC97(UINT Offset, UINT16 Data, UINT8 DevId)
{
    BOOL retVal = FALSE;

    if (GetAC97Lock() == TRUE)
    {
        retVal = WriteAC97Raw(Offset, Data, DevId);
        ReleaseAC97Lock();
    }

    return(retVal);
}


BOOL ColdResetAC97Control(void)
{
    DEBUGMSG(1, (TEXT("InitializeACLink()\r\n")));

    if (!GetAC97Lock())
    {
        return(FALSE);
    }

// TODO:
//	Add Alchemy cold reset

    ReleaseAC97Lock();
    return(TRUE);
}





///////////////////////////////////////////////////////////////////////////////
//
//	Au13xx Specific ACLink stuff
//
///////////////////////////////////////////////////////////////////////////////



//
// Macros
//
#define	STALLEXECUTION(x) OALStallExecution(x)
#define TIMEOUT     200

BOOL StartAC97Rx(void)
{
	DEBUGMSG(1, (TEXT("StartAC97Rx()\r\n")));

    if (!GetAC97Lock())
    {
        return(FALSE);
    }

	WRITE_REGISTER_ULONG((PULONG)&g_pAC97->pcr, PSC_AC97_PCR_RS);

	ReleaseAC97Lock();
    return(TRUE);
}

BOOL StartAC97Tx(void)
{
	DEBUGMSG(1, (TEXT("StartAC97Rx()\r\n")));

    if (!GetAC97Lock())
    {
        return(FALSE);
    }

	WRITE_REGISTER_ULONG((PULONG)&g_pAC97->pcr, PSC_AC97_PCR_TS);

	ReleaseAC97Lock();
    return(TRUE);
}

BOOL StopAC97Rx(void)
{
	DEBUGMSG(1, (TEXT("StartAC97Rx()\r\n")));

    if (!GetAC97Lock())
    {
        return(FALSE);
    }

	WRITE_REGISTER_ULONG((PULONG)&g_pAC97->pcr, PSC_AC97_PCR_RP);

	ReleaseAC97Lock();
    return(TRUE);
}

BOOL StopAC97Tx(void)
{
	DEBUGMSG(1, (TEXT("StartAC97Rx()\r\n")));

    if (!GetAC97Lock())
    {
        return(FALSE);
    }

	WRITE_REGISTER_ULONG((PULONG)&g_pAC97->pcr, PSC_AC97_PCR_TP);

	ReleaseAC97Lock();
    return(TRUE);
}

///////////////////////////////////////////////////////////////////////////////
// AC97ReadReg
// -----------------
//
// Parameters
// ----------
// Reg    - [in]  Register to read from
// Result - [out] Contents of register
// 
// Return Values
// -------------
// TRUE indicates success, FALSE indicates failure of read operation
// 
// Remarks
// -------
// Reads an AC97 register. A synchronization mutex is used to control access
// to the AC97 controller between touch and audio drivers.
///////////////////////////////////////////////////////////////////////////////
static BOOL Au13xxAC97Read(IN PSC_AC97 *pAC97, IN ULONG Reg,OUT ULONG *Result)
{
    ULONG Data;
    ULONG Timeout=TIMEOUT*1000;

	Data = PSC_AC97_CDC_INDX_N(Reg) | (1<<25);

    WRITE_REGISTER_ULONG((PULONG)&pAC97->cdc, Data);


    while(Timeout) {
		if( (READ_REGISTER_ULONG((PULONG)&pAC97->sts)&PSC_AC97_STS_CP) == 0x0 )
		{
        if(READ_REGISTER_ULONG((PULONG)&pAC97->evnt)&PSC_AC97_EVNT_CD)
		break;
		}

        Timeout--;
    }

    if(Timeout)
	{
        Data = READ_REGISTER_ULONG((PULONG)&g_pAC97->cdc);
        Data &= PSC_AC97_CDC_DATA;
        *Result = Data;
		// Clear Command Done flag
		WRITE_REGISTER_ULONG((PULONG)&pAC97->evnt,PSC_AC97_EVNT_CD);
        return TRUE;
    }
	// Clear Command Done flag
	WRITE_REGISTER_ULONG((PULONG)&pAC97->evnt,PSC_AC97_EVNT_CD);

	return FALSE;
}

BOOL
Au13xxAC97Write(
    IN PSC_AC97 *pAC97,
    IN ULONG    Reg,
    IN UINT16    Value
    )
{
    ULONG Data;
    ULONG Timeout = TIMEOUT * 10;


    Data  = PSC_AC97_CDC_DATA_N(Value);
	Data |= (ULONG) PSC_AC97_CDC_INDX_N(Reg);

    WRITE_REGISTER_ULONG((PULONG)&pAC97->cdc, Data);

    while(Timeout) {
        if(READ_REGISTER_ULONG((PULONG)&pAC97->evnt)&PSC_AC97_EVNT_CD) break;
        Timeout--;
    }

	// Clear Command Done flag
	WRITE_REGISTER_ULONG((PULONG)&pAC97->evnt,PSC_AC97_EVNT_CD);

    if(Timeout) {
        return TRUE;
    }

    return FALSE;
}


static BOOL Au13xxAc97Init(PSC_AC97 *pAC)
{
	int timeout;
	HANDLE hGPIO = NULL;
	ULONG tmp;
	BOOL status = TRUE;

	if (READ_REGISTER_ULONG((PULONG)&pAC->sts) & PSC_AC97_STS_SR)
		return status;

	WRITE_REGISTER_ULONG((PULONG)&pAC->psc.ctl, 0);
	// Reset and configure the PSC for AC97
	WRITE_REGISTER_ULONG((PULONG)&pAC->psc.sel, PSC_SEL_PS_AC97 | PSC_SEL_CLK_SERIAL);

	// Enable the PSC
	WRITE_REGISTER_ULONG((PULONG)&pAC->psc.ctl, PSC_CTL_CE |PSC_CTL_EN);

	// wait for clock detect
	timeout = 1000;
	while (timeout && !((tmp=READ_REGISTER_ULONG((PULONG)&pAC->sts)) & PSC_AC97_STS_SR)) {
		StallExecution(1000);
		timeout--;
	}

	if (!timeout) {
		status = FALSE;
		DEBUGMSG(1,(TEXT("InitializeCodec: Fail to initialize PSC controller.\r\n")));
		goto ErrorReturn;
	}

	// configure the AC97 controller
	tmp = PSC_AC97_CFG_TRD_N(3) |
	      PSC_AC97_CFG_RRD_N(3) |
          PSC_AC97_CFG_LEN_N(7) |
		  PSC_AC97_CFG_TXSLOT_N(3) |
		  PSC_AC97_CFG_RXSLOT_N(3) |
		  PSC_AC97_CFG_DE;

	WRITE_REGISTER_ULONG((PULONG)&pAC->cfg, tmp);

	// mask all interrupts
	WRITE_REGISTER_ULONG((PULONG)&pAC->msk,0xFFFFFFFF);

	// wait until the device is ready
	timeout = 1000;
	while (timeout && !((tmp=READ_REGISTER_ULONG((PULONG)&pAC->sts)) & PSC_AC97_STS_DR))
	{
		StallExecution(1000);
		timeout--;
	}

	if (!timeout) {
		status = FALSE;
		DEBUGMSG(1,(TEXT("InitializeCodec: Fail to config PSC controller.\r\n")));
		goto ErrorReturn;
	}

	tmp = *((ULONG *)0xb1a00008);
	DEBUGMSG(1,(TEXT("InitializeCodec: Initialize PSC controller successful (%x)%d.\r\n"), tmp, timeout));

ErrorReturn:
	return status;
}
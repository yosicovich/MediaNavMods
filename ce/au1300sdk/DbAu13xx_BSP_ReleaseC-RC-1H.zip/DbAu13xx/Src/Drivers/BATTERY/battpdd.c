/*++

Copyright:

    Copyright (c) 2003 BSQUARE Corporation.  All rights reserved.

Module Name:

    battpdd.c    

Abstract:

    Implements the battery PDD that when linked to the MDD at public\common\oak\battdrvr will
	implement a 4.2 compliant battery driver.  

Author:

    IMR July 2003

Revision History:

--*/

#include <windows.h>
#include "platform.h"
#include "bceddk.h"

// structure to hold battery information
typedef struct {
	HANDLE hSSI;
	HANDLE hGPIO;
	BOOL   bCharging;
	BOOL   bACStatus;
	ULONG  Voltage;
	ULONG  Current;
} BATTERY_INFO, *PBATTERY_INFO;

// instance of the structure
static PBATTERY_INFO pBatteryInfo = NULL;

// Hydrogen 2 specific implementation
#ifdef PLATFORM_HYD1100
#include "gpio.h"
#include "ssi.h"

#define BATTERY_MONITORING_PERIOD 1000

#define EXTERNAL_POWER_GPIO		GPIO_4
#define CHARGE_ENABLE_GPIO		GPIO_19

#define	BATTERY_VOLTAGE_ADDR	0xA7
#define	BATTERY_CURRENT_ADDR	0xE7
// Value of current setting resistor in LTC1734 circuit, in kOhms
#define CHARGE_RESISTOR		3
#define C2_CURRENT			500
#define C20_CURRENT			100

// The minimum voltage a plugged in battery should have, mV
#define DISCHARGE_CUT_OFF_VOLT	2700

//The maximum voltage the LTC part should output to the battery, mV
#define CHARGE_CUT_OFF_VOLT	4250

// Local functions
//
static BOOL CheckRunningOnAC(void)
{
	DWORD gpioState;

	GPIO_GetState(pBatteryInfo->hGPIO,&gpioState);

	if (~gpioState&EXTERNAL_POWER_GPIO) {
		return TRUE;
	} else {
		return FALSE;
	}
}

static ULONG AverageSSIReading( ULONG Address,
                                ULONG Count )
{
	ULONG i;
	ULONG total = 0;
	ULONG reading;

	for (i=0; i<Count; i++ ) {
		SSI_ReadData(pBatteryInfo->hSSI,Address,&reading);
		total += reading;
	}

	return total/Count;
}

static ULONG ReadBatteryVoltage() 
{
	ULONG rawData;
	rawData = AverageSSIReading( BATTERY_VOLTAGE_ADDR, 4 );

	// 12bits full scale = 10,000mV
	rawData = (rawData * 10000) >> 12;

	return rawData;
}

static ULONG ReadBatteryCurrent()
{
	ULONG rawData;
	rawData = AverageSSIReading( BATTERY_CURRENT_ADDR, 4 );

	// 12bits full scale = 2500mV
	rawData = (rawData * 2500) >> 12;

	return rawData/CHARGE_RESISTOR;
}

static ULONG BatteryMonitorThread()
{
	ULONG current, voltage;
	BOOL  bACStatus;
	BOOL  bCharging = FALSE;

	while(TRUE) {
	
		// get current and voltage
		current = ReadBatteryCurrent();
		voltage = ReadBatteryVoltage();
		// store current and voltage in global structure
		pBatteryInfo->Current = current;
		pBatteryInfo->Voltage = voltage;

		// get AC status
		bACStatus = CheckRunningOnAC();
		// store AC status
		pBatteryInfo->bACStatus = bACStatus;

		if (bCharging) {
			if (!bACStatus ||
			    voltage > CHARGE_CUT_OFF_VOLT ||
				current > (C2_CURRENT+40)/* ||
				current < C20_CURRENT*/ )
			{
				// disable charging
				DEBUGMSG(1,(TEXT("Disabling charger\r\n")));
				GPIO_ClearPinOutputState(pBatteryInfo->hGPIO,CHARGE_ENABLE_GPIO);
				bCharging = FALSE;
			}
		} else {
			if (bACStatus &&
			    voltage < 4000 /*&& // < 4 Volts
				voltage > DISCHARGE_CUT_OFF_VOLT*/)
			{
				DEBUGMSG(1,(TEXT("Enabling charger\r\n")));
				GPIO_SetPinOutputState(pBatteryInfo->hGPIO,CHARGE_ENABLE_GPIO);
				bCharging = TRUE;
			}
		}
		
		// store charging status
		pBatteryInfo->bCharging = bCharging;	

		Sleep(BATTERY_MONITORING_PERIOD);
	}

	return 0;
}
#endif // PLATFORM_HYD1100


// PDD functions required by the MDD layer
//


BOOL BatteryPDDInitialize( LPCTSTR pszRegistryContext )
{
#ifdef PLATFORM_HYD1100
	ULONG threadID;
#endif

	pBatteryInfo = (PBATTERY_INFO)LocalAlloc(LPTR,sizeof(*pBatteryInfo));
		
	if (NULL == pBatteryInfo) {
		DEBUGMSG(1,(TEXT("Battery: Failed to allocate driver info\r\n")));
		return FALSE;
	}

#ifdef PLATFORM_HYD1100
	pBatteryInfo->hSSI = SSI_Initialize();
	
	if (INVALID_HANDLE_VALUE == pBatteryInfo->hSSI) {
		DEBUGMSG(1,(TEXT("Battery: Failed to initialize SSI\r\n")));
		return FALSE;
	}


        // initialize the GPIO driver
    pBatteryInfo->hGPIO = GPIO_Init();

    if (INVALID_HANDLE_VALUE == pBatteryInfo->hGPIO) {
        DEBUGMSG(1,(TEXT("Battery: Unable to open GPIO device\r\n")));
		return 0;
    }

        // set external power pin as input
	GPIO_SetAsInput(pBatteryInfo->hGPIO,EXTERNAL_POWER_GPIO);
	GPIO_SetAsOutput(pBatteryInfo->hGPIO,CHARGE_ENABLE_GPIO);

	pBatteryInfo->bCharging = FALSE;

	CreateThread(NULL,
	           0,
			   (LPTHREAD_START_ROUTINE)BatteryMonitorThread,
			   NULL,
			   0,
			   &threadID);
#endif

	return TRUE;
}

void BatteryPDDDeinitialize()
{
	CloseHandle(pBatteryInfo->hSSI);
	CloseHandle(pBatteryInfo->hGPIO);
	LocalFree(pBatteryInfo);
}


BOOL BatteryPDDGetStatus( PSYSTEM_POWER_STATUS_EX2 pStatus,
                          PBOOL                    pfBatteriesChangedSinceLastCall )
{

#ifdef PLATFORM_HYD1100
	pStatus->ACLineStatus = pBatteryInfo->bACStatus;
		
	if (pBatteryInfo->bCharging) {
		pStatus->BatteryFlag = BATTERY_FLAG_CHARGING;
	} else {
		if (pBatteryInfo->Voltage < DISCHARGE_CUT_OFF_VOLT) {
			pStatus->BatteryFlag = BATTERY_FLAG_CRITICAL;
		} else if (pBatteryInfo->Voltage < 3500) {
			pStatus->BatteryFlag = BATTERY_FLAG_LOW;
		} else {
			pStatus->BatteryFlag = BATTERY_FLAG_HIGH;
		}
	}

	pStatus->BatteryLifePercent = BATTERY_PERCENTAGE_UNKNOWN;
	pStatus->BatteryLifeTime = BATTERY_LIFE_UNKNOWN;
	pStatus->BatteryFullLifeTime = BATTERY_LIFE_UNKNOWN;

	pStatus->BackupBatteryFlag = BATTERY_FLAG_NO_BATTERY;
	pStatus->BackupBatteryLifePercent = BATTERY_PERCENTAGE_UNKNOWN;
	pStatus->BackupBatteryLifeTime = BATTERY_LIFE_UNKNOWN;
	pStatus->BackupBatteryFullLifeTime = BATTERY_LIFE_UNKNOWN;
	pStatus->BackupBatteryVoltage = 0;

	pStatus->BatteryVoltage = pBatteryInfo->Voltage;
	pStatus->BatteryCurrent = pBatteryInfo->Current;
	pStatus->BatteryAverageCurrent = 0;
	pStatus->BatteryAverageInterval = 0;
	pStatus->BatterymAHourConsumed = 0;
	pStatus->BatteryTemperature = 32767; // that's HOT...

	pStatus->BatteryChemistry = BATTERY_CHEMISTRY_UNKNOWN;


#else
    pStatus->ACLineStatus               = AC_LINE_ONLINE;
    pStatus->BatteryFlag                = BATTERY_FLAG_NO_BATTERY;
    pStatus->BatteryLifePercent         = 0;
    pStatus->Reserved1                  = 0;
    pStatus->BatteryLifeTime            = BATTERY_LIFE_UNKNOWN;
    pStatus->BatteryFullLifeTime        = BATTERY_LIFE_UNKNOWN;

    pStatus->Reserved2                  = 0;
	// ideally we would report NO_BATTERY here but something doesn't understand that
	// and we get warnings of critically low battery levels.
    pStatus->BackupBatteryFlag          = BATTERY_FLAG_HIGH;
    pStatus->BackupBatteryLifePercent   = 0;
    pStatus->Reserved3                  = 0;
    pStatus->BackupBatteryLifeTime      = BATTERY_LIFE_UNKNOWN;
    pStatus->BackupBatteryFullLifeTime  = BATTERY_LIFE_UNKNOWN;

    pStatus->BatteryChemistry           = BATTERY_CHEMISTRY_UNKNOWN;
    pStatus->BatteryVoltage             = 0;
    pStatus->BatteryCurrent             = 0;
    pStatus->BatteryAverageCurrent      = 0;
    pStatus->BatteryAverageInterval     = 0;
    pStatus->BatterymAHourConsumed      = 0;
    pStatus->BatteryTemperature         = 0;
    pStatus->BackupBatteryVoltage       = 0;
    
    *pfBatteriesChangedSinceLastCall = FALSE;
#endif	
	return TRUE;
}

LONG BatteryPDDGetLevels(void)
{
	return 3;
}

BOOL BatteryPDDSupportsChangeNotification(void)
{
	return FALSE;
}

void BatteryPDDPowerHandler( BOOL bOff )
{
	// nothing to do here...
}

void BatteryPDDResume(void)
{
	// nothing to do here...
}


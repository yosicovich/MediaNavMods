// secservlib.cpp : Defines the entry point for the DLL application.
//

#include <windows.h>
#include <tchar.h>
#include "secservlib.h"

#include "..\base64.h"
#include "..\secure_serial.h"
#include "..\secure_serial_priv.h"
#include "..\sfiles.h"


BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

// This is an example of an exported function.
secservlib_API TCHAR * getSerialNum(int *errorCode)
{

	TCHAR   eserialNum[SER_BUF_SIZE];
	TCHAR   serialNum[SER_BUF_SIZE];
	TCHAR 	 *sig;
	TCHAR	 *hash=NULL;

	TCHAR	 **fptr;
	int		rc;
	FILE	*fs;

	fptr = sfilenames;
	//sptr = regNames;

	while(1)
	{
		//
		// aquire a serial strings
		//
		if ( NULL == fptr )  // fail safe break out
      return(NULL);


		if (*fptr != NULL)
			{
  			fs = _tfopen(*fptr,L"r");
  			fptr++;  // no matter what happens we want to bump the file name
  			if (NULL == fs)
					continue;

   			if (_fgetts(eserialNum,SER_BUF_SIZE-1,fs) == NULL)
   				{
   					fclose(fs);
						continue;
   				}
   			fclose(fs);
   			// remove eof char
   			if ((sig = _tcschr(eserialNum,L'\n')) != NULL)
   				*sig = '\0';
    		if ((sig = _tcschr(eserialNum,L'\r')) != NULL)
   				*sig = '\0';

			}

   	// parse line into serial and signature
   	sig = _tcschr(eserialNum,SERIAL_DELIMITER);
   	if (sig == NULL)
   		{
   			*errorCode=SERIAL_PARSING_ERROR;
   			continue;  // couldn't find the the delimiters try next file
   		}

   	*sig = '\0';
   	sig++;

   	// decode the serial number ( serial number is stored in base64 format
   	// to avoid any special characters)

		rc = base64_decode(eserialNum, (u_int8_t*)serialNum,SER_BUF_SIZE);
		if (rc == -1 )
			continue;
		serialNum[rc] = '\0';

		// hash the serial number with a secret key.
   	hash = hashSerial(serialNum);
   	if (hash == NULL)
   		{
   			*errorCode=SERIAL_HASH_NOT_FOUND;
   			continue;
   		}

		// compare what we got from the file with what we have computed.
   	if (_tcscmp(hash,sig))
   		{
   			free(hash);
   			hash=NULL;
   			*errorCode=SERIAL_HASH_MISMATCH;
   			continue;
   		}
   	else  // ok we have found a serial number that verified
   		break;
	}


	free(hash);
	hash=NULL;
	return(_tcsdup(serialNum));

}

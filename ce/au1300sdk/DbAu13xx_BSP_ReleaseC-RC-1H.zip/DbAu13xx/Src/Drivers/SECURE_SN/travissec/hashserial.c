#include <windows.h>
#include <tchar.h>
#include "..\base64.h"
#include "..\secure_serial.h"
#include "..\secure_serial_priv.h"
#include "..\sfiles.h"


// This is an example of an exported variable
//secservlib_API int nsecservlib=0;
TCHAR * hashSerial(TCHAR *serialNum)
{

    static unsigned char keyArray[KEY_SIZE] = {
 		  199,160,63,17,198,250,18,166,35,107,7,16,142,1,165,114,
		  137,153,41,67,52,138,128,64,99,30,157,61,210,30,99,140};

		serialMsg msg;
		SHA1_CTX context;
		u_int8_t digest[SHA1_DIGEST_LENGTH];
		TCHAR *hash=NULL;
		int			i;
		int     rc;

		memset(&msg,0,sizeof(msg));

		SHA1Init(&context);
		SHA1Update(&context, (u_int8_t *)serialNum, _tcslen(serialNum)*sizeof(TCHAR));
		SHA1Final(digest,&context);

		// this makes the key unique to a serial number
		for(i=0;i<SHA1_DIGEST_LENGTH;i++)
			{
				msg.frontKey[i] = keyArray[i] ^ digest[i%SHA1_DIGEST_LENGTH];
				msg.endKey[i] = msg.frontKey[i];
			}

		_tcsncpy(msg.serialNum,serialNum,sizeof(msg.serialNum));

		SHA1Init(&context);
		SHA1Update(&context, (u_int8_t *)&msg, sizeof(msg));
		SHA1Final(digest,&context);

		rc = base64_encode(digest,sizeof(digest),&hash);
		if (rc < 0)
			return(NULL);
		return(hash);
}

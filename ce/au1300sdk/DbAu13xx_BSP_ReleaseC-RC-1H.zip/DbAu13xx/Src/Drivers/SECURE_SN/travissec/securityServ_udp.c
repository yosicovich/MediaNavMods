/* <LIC_AMD_STD>
 * Copyright (C) 2003-2005 Advanced Micro Devices, Inc.  All Rights Reserved.
 *
 * Unless otherwise designated in writing, this software and any related
 * documentation are the confidential proprietary information of AMD.
 * THESE MATERIALS ARE PROVIDED "AS IS" WITHOUT ANY
 * UNLESS OTHERWISE NOTED IN WRITING, EXPRESS OR IMPLIED WARRANTY OF ANY
 * KIND, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * NONINFRINGEMENT, TITLE, FITNESS FOR ANY PARTICULAR PURPOSE AND IN NO
 * EVENT SHALL AMD OR ITS LICENSORS BE LIABLE FOR ANY DAMAGES WHATSOEVER.
 *
 * AMD does not assume any responsibility for any errors which may appear
 * in the Materials nor any responsibility to support or update the
 * Materials.  AMD retains the right to modify the Materials at any time,
 * without notice, and is not obligated to provide such modified
 * Materials to you. AMD is not obligated to furnish, support, or make
 * any further information available to you.
 * </LIC_AMD_STD>  */
/* <CTL_AMD_STD>
 * </CTL_AMD_STD>  */
/* <DOC_AMD_STD>
 * This is a security udp server which provide:
 *
 * 1.  encoded serial number string for clients.
 * 2.  consistency checks for serial number files
 * 3.  hostid consistency check
 * 4.  obfuscate client serial number file access
 * 5.  recovers damaged serial number files
 *
 * In some ways this is just a glorified file read.
 * </DOC_AMD_STD>  */

#ifdef __linux__
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include "mae_interface.h"
#include <sys/resource.h>
#elif defined(UNDER_CE)
#include <tchar.h>
#include <Winsock2.h>
#include <Winbase.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// debug

#define NEED_HW_SECRET


#include "..\base64.h"
#include "..\secure_serial.h"
#include "..\secure_serial_priv.h"
#include "..\sfiles.h"

#ifndef TRUE
#define TRUE -1
#endif

#ifndef FALSE
#define FALSE 0
#endif

void error(char *msg)
{
//    perror(msg);
    exit(0);
}

static netMsg               gNetMsg;
static TCHAR				gSerialLine[255];
static u_int8_t             gDivxKeyMsg[SHA1_DIGEST_LENGTH];
static unsigned char        gDrm[HARDWARE_SECRET_SIZE];

static int                  needHwSecret=TRUE;

#ifdef __linux__
static int  myGetHwSecret()
{
  int fd;
  int i;
  int rc;
  unsigned int drm[HARDWARE_SECRET_SIZE/4];

  fd = open("/dev/mae",O_RDONLY);
  if (fd < 0)
    {
      return(SERIAL_MAE_DEV_OPEN);
    }

  rc = ioctl(fd,AU1XXXMAE_GETDIVXSTR,drm);
  if (rc < 0)
    {
      close(fd);
      return(SERIAL_MAE_DEV_IOCTL);
    }

  for (i=0;i<8;i++)
    drm[i] = drm[i] ^ salt[i];

  needHwSecret=FALSE;
  close(fd);


  // This loop takes an array of 8 32 bit words and formats them
  // into 32 bytes
  for(i=0;i<8;i++)
    {
      int j,k=0;
      unsigned char *cPtr;
      cPtr = (unsigned char *)&drm[i];
      for(j=3;j>=0;j--)
        {
          gDrm[i*4+j] = cPtr[k++];
        }
    }


  // format into a fixed length string
  //sprintf(gDrm,"%08x%08x%08x%08x%08x%08x%08x%08x",
   // drm[0],drm[1],drm[2],drm[3],drm[4],drm[5],drm[6],drm[7]);
#ifdef DEBUG
  printf("%08x-%08x-%08x-%08x-%08x-%08x-%08x-%08x\n",drm[0],drm[1],drm[2],drm[3],
    drm[4],drm[5],drm[6],drm[7]);
#endif

  return(SERIAL_STATUS_OK);

}
#endif
static TCHAR *svrGetSerialNum()
{

	TCHAR   eserialNum[SER_BUF_SIZE];
	TCHAR   serialNum[SER_BUF_SIZE];
	TCHAR 	 *sig;
	TCHAR	 *hash=NULL;
//	long	 hid2;
	TCHAR	 **fptr;
	TCHAR	 **sptr;
	int		rc;
	FILE	*fs;

	fptr = sfilenames;
	sptr = regNames;

	memset(&gNetMsg,0,sizeof(gNetMsg));

	while(1)
	{
		//
		// aquire a serial strings
		//
		if ((NULL == fptr) && (NULL == sptr))  // fail safe break out
      return(NULL);


		if (*fptr != NULL)
			{
  			fs = _tfopen(*fptr,L"r");
  			fptr++;  // no matter what happens we want to bump the file name
  			if (NULL == fs)
					continue;

   			if (_fgetts(eserialNum,SER_BUF_SIZE-1,fs) == NULL)
   				{
   					fclose(fs);
						continue;
   				}
   			fclose(fs);
   			// remove eof char
   			if ((sig = _tcschr(eserialNum,L'\n')) != NULL)
   				*sig = '\0';
    		if ((sig = _tcschr(eserialNum,L'\r')) != NULL)
   				*sig = '\0';

			}
#if 0
		else if (*sptr != NULL)
			{
				//rc = rReadLink(*sptr,eserialNum,SER_BUF_SIZE-1);
				//sptr++;
				//if (rc < 10)  // make sure readlink isn't too small.
				//	continue;
			}
		else
			{
				// if we get here then all attempts to find a file have failed
				// This is a catastrophic error
				gNetMsg.status = SERIAL_FILE_ERROR;
				return(NULL);
			}
#endif
		_tcscpy(gSerialLine,eserialNum);  // make this the standard
   	// parse line into serial and signature
   	sig = _tcschr(eserialNum,SERIAL_DELIMITER);
   	if (sig == NULL)
   		{
   			gNetMsg.status=SERIAL_PARSING_ERROR;
   			continue;  // couldn't find the the delimiters try next file
   		}

   	*sig = '\0';
   	sig++;

   	// decode the serial number ( serial number is stored in base64 format
   	// to avoid any special characters)

		rc = base64_decode(eserialNum, (u_int8_t*)serialNum,SER_BUF_SIZE);
		if (rc == -1 )
			continue;
		serialNum[rc] = '\0';

		// hash the serial number with a secret key.
   	hash = hashSerial(serialNum);
   	if (hash == NULL)
   		{
   			gNetMsg.status=SERIAL_HASH_NOT_FOUND;
   			continue;
   		}

		// compare what we got from the file with what we have computed.
   	if (_tcscmp(hash,sig))
   		{
   			free(hash);
   			hash=NULL;
   			gNetMsg.status=SERIAL_HASH_MISMATCH;
   			continue;
   		}
   	else  // ok we have found a serial number that verified
   		break;
	}
	// compute and set hostid
	//hid2 = getMyHostid(serialNum);
	//sethostid(hid2);

	//
	_tcsncpy(gNetMsg.serialNum,serialNum,MAX_SERIAL_NUM_SIZE);
	_tcsncpy(gNetMsg.sig,hash,MAX_SERIAL_NUM_SIZE);
	gNetMsg.status = SERIAL_STATUS_OK;
	//gNetMsg.hostid = hid2;

	free(hash);
	hash=NULL;
	return(gNetMsg.serialNum);
}


// serialCheck will check the to make sure the serial number files and
// symlinks match what has been verified by the daemon.
//
// As it turns out it is easier and faster to rewrite the information
// than it is to verified it.
//
static int serialCheck()
{

	TCHAR	 **fptr;
	TCHAR	 **sptr;
	FILE	*fs;

	fptr = sfilenames;
	sptr = regNames;


#ifdef __linux__
	struct rusage  ru;

	if (!getrusage(RUSAGE_SELF,&ru))
	{
		/*
		printf("system time: %ld.%ld\n",ru.ru_stime.tv_sec,ru.ru_stime.tv_usec);
		printf("user time: %ld.%ld\n",ru.ru_utime.tv_sec,ru.ru_utime.tv_usec);

		printf("maxrss: %ld\n",ru.ru_maxrss);
		printf("ixrss : %ld\n",ru.ru_ixrss);
		printf("majflt: %ld\n",ru.ru_majflt);
		printf("nswap : %ld\n",ru.ru_nswap);
		printf("idrss : %ld\n",ru.ru_idrss);
		printf("isrss : %ld\n",ru.ru_isrss);
		*/
	}
#endif
	// getloadavg(load,3); // not supported in uclibc

	// skip if CPU is busy
	//if (load[0] > 0.25)
	//	return(0);

	//
	// This routine will rewrite (because it is cheaper than checking then
	// and then rewritten if changed.
	//
	while(1)
	{
		//
		// aquire a serial strings
		//
		if ((NULL == fptr) && (NULL == sptr))  // fail safe break out
			break;

		if (*fptr != NULL)
			{
  			fs = _tfopen(*fptr,L"w+");
  			fptr++;  // no matter what happens we want to bump the file name
  			if (NULL == fs)
					continue;
				_fputts(gSerialLine,fs);
				_fputts(L"\n",fs);
				fclose(fs);
			}
#if 0
		else if (*sptr != NULL)
			{
				rSymLink(gSerialLine,*sptr);
				sptr++;
			}
#endif
		else
			{
				// We have reached the end of the list
				return(1);
			}
	}
	return(0);
}
// This will spin off a low priority thread to check serial number files.
//

DWORD checkThread(LPVOID lpParameter)
{
  //setpriority(PRIO_PROCESS,q
	while(1)
		{
			//printf("sleep thread %s\n",gSerialLine);
			serialCheck();
			Sleep(CHECK_SLEEP*60*1000);
		}
  return -1; //make the compiler happy
}

static void setDivxKey()
{

    SHA1_CTX context;

    u_int8_t digest[SHA1_DIGEST_LENGTH];

    int i;

    SHA1Init(&context);
    SHA1Update(&context, (u_int8_t*)(gNetMsg.serialNum), _tcslen(gNetMsg.serialNum)*sizeof(TCHAR));
    SHA1Update(&context, (u_int8_t*)(gNetMsg.sig), _tcslen(gNetMsg.sig)*sizeof(TCHAR));
    SHA1Update(&context, "QvikGenivfNZQ",_tcslen(L"QvikGenivfNZQ"));
    SHA1Final(digest,&context);

    for(i=1;i<SHA1_DIGEST_LENGTH-1;i++)
      digest[i+1] = digest[i] ^ digest[i+1];

    SHA1Init(&context);
    SHA1Update(&context, digest, SHA1_DIGEST_LENGTH);
    SHA1Update(&context, "QvikGenivfNZQ",_tcslen(L"QvikGenivfNZQ"));
    SHA1Final(gDivxKeyMsg,&context);

    for (i = sizeof(gDivxKeyMsg) - 1; i > 0; i--)
          gDivxKeyMsg[i] = gDivxKeyMsg[i] ^ gDivxKeyMsg[i-1];

}
int main(int argc, char *argv[])
{
   int sock, length, fromlen, n;
   struct sockaddr_in server;
   struct sockaddr_in from;
   TCHAR *serialNum;
   char buf[1024];
   HANDLE hThread;


	serialNum = svrGetSerialNum();
	if (serialNum == NULL)
		{
			fprintf(stderr,"Initial read of serial number failed! Error code: %ld\n",
        gNetMsg.status);
			return(0);
		}
   setDivxKey();


    // Create the command thread.
    hThread = CreateThread(NULL, 0, checkThread, NULL, 0, NULL);
    if ( hThread == NULL )
    {
        ERRORMSG(1, (_T("Secserv failed to create thread. Error %d\r\n"),
                        GetLastError()));
        return(-1);
    }
   //pthread_create(&thread1,NULL,&checkThread,NULL);
   sock=socket(AF_INET, SOCK_DGRAM, 0);
   if (sock < 0)
   	error("Opening socket");
   length = sizeof(server);
   memset(&server,0,length);
   server.sin_family=AF_INET;
   server.sin_addr.s_addr=INADDR_ANY;
   server.sin_port=htons(SEC_PORT);
   if (bind(sock,(struct sockaddr *)&server,length)<0)
       error("binding");
   fromlen = sizeof(struct sockaddr_in);
   if (svrGetSerialNum() == NULL)
   	error("Failed to get initial serial number\n");


   while (1) {
       n = recvfrom(sock,buf,1024,0,(struct sockaddr *)&from,&fromlen);
       if (n < 0)
       	error("recvfrom");
			 if (buf[COMMAND_OFFSET] == GET_SERIAL_NUM)
			 	{
#ifdef DEBUG
			 		fprintf(stderr,"got serial request sending %s:%s\n",
			 			gNetMsg.serialNum,gNetMsg.sig);
#endif
       		n = sendto(sock,(char *)&gNetMsg,sizeof(gNetMsg),0,(struct sockaddr *)&from,fromlen);
       		if (n  < 0)
       			error("sendto");
			 	}
       else if (buf[COMMAND_OFFSET] == GET_DIVX_KEY)
        {
          n = sendto(sock,(char *)&gDivxKeyMsg,SHA1_DIGEST_LENGTH,0,(struct sockaddr *)&from,fromlen);
          if (n  < 0)
            error("sendto");
        }
       else if (buf[COMMAND_OFFSET] == GET_HARDWARE_SECRET)
        {
#if 0
          if (needHwSecret)  // call if we need it.
            myGetHwSecret();
          n = sendto(sock,(char *)gDrm,sizeof(gDrm),0,(struct sockaddr *)&from,fromlen);
          if (n  < 0)
            error("sendto");
#endif
        }

   }
 }

/* <LIC_AMD_STD>
 * Copyright (C) 2003-2005 Advanced Micro Devices, Inc.  All Rights Reserved.
 *
 * Unless otherwise designated in writing, this software and any related
 * documentation are the confidential proprietary information of AMD.
 * THESE MATERIALS ARE PROVIDED "AS IS" WITHOUT ANY
 * UNLESS OTHERWISE NOTED IN WRITING, EXPRESS OR IMPLIED WARRANTY OF ANY
 * KIND, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * NONINFRINGEMENT, TITLE, FITNESS FOR ANY PARTICULAR PURPOSE AND IN NO
 * EVENT SHALL AMD OR ITS LICENSORS BE LIABLE FOR ANY DAMAGES WHATSOEVER.
 *
 * AMD does not assume any responsibility for any errors which may appear
 * in the Materials nor any responsibility to support or update the
 * Materials.  AMD retains the right to modify the Materials at any time,
 * without notice, and is not obligated to provide such modified
 * Materials to you. AMD is not obligated to furnish, support, or make
 * any further information available to you.
 * </LIC_AMD_STD>  */
/* <CTL_AMD_STD>
 * </CTL_AMD_STD>  */
/* <DOC_AMD_STD>
 * </DOC_AMD_STD>  */
#include <stdio.h>
#include <stdlib.h>
#ifdef __linux__
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/poll.h>
#include "mae_interface.h"
#elif defined (UNDER_CE)
#include <tchar.h>
#include <Winsock2.h>
#endif
#include <string.h>


#define SEC_NEEDKEYS
#include "..\secure_serial.h"
#include "..\secure_serial_priv.h"
#include "..\base64.h"


static void rot13 (TCHAR *str)
{
  register TCHAR cap;
  unsigned int i;
  for(i=0;i<_tcslen(str);i++)
    {
      cap = str[i] & 32;
      str[i] &= ~cap;
      str[i] = ((str[i] >= 'A') && (str[i] <= 'Z') ?
      	((str[i] - 'A' + 13) % 26 + 'A') : str[i]) | cap;
    }
}



TCHAR *getSerialNum(int *errorCode)
{
#ifdef __linux__
	int sock;
	long	 hid1, hid2;
#elif defined(UNDER_CE)
	SOCKET sock;
#endif
	 int length, n;
   struct sockaddr_in server, from;
   struct hostent *hp;
   int  i;

	fd_set  fds;
	struct timeval tv;
	static netMsg sMsg;
   int pollrc;
   int retryCount;

	 TCHAR   eserialNum[SER_BUF_SIZE];
	 char    pserialNum[SER_BUF_SIZE];

	 TCHAR	 *hash;
	 char  localhost[] = "ybpnyubfg";

   *errorCode = SERIAL_STATUS_OK;
   sock= socket(AF_INET, SOCK_DGRAM, 0);
   if (sock < 0)
   	{
      *errorCode = SERIAL_SOCKET_ERROR;
   		return(NULL);
   	}

   server.sin_family = AF_INET;
   hp = gethostbyname(localhost);

   if (hp==0)
   	{
      *errorCode = SERIAL_HOSTNAME_ERROR;
   		return(NULL);
   	}


   memcpy((char *)&server.sin_addr,(char *)hp->h_addr,hp->h_length);
   server.sin_port = htons(SEC_PORT);
   length=sizeof(struct sockaddr_in);

   memset(eserialNum,0,SER_BUF_SIZE);

   // throw in random bits to hide command
#ifdef __linux__
	srand(time(NULL));
#elif defined (UNDER_CE)
	srand(GetTickCount());
#endif
   for(i=0;i<COMMAND_SIZE;i++)
   {
		eserialNum[i] = rand() & 0xff;
   }

   // set the command to send to sec server
   eserialNum[COMMAND_OFFSET]=GET_SERIAL_NUM;
   retryCount = 0;
   do
    {
      // make sure it doesn't loop forevery
      if (retryCount > RETRY_COUNT)
        {
          *errorCode = SERIAL_TOO_MANY_RETRY;
          return(NULL);
        }

      retryCount++;
	  wcstombs(pserialNum, eserialNum, SER_BUF_SIZE);
      n=sendto(sock,pserialNum,COMMAND_SIZE,0,(const struct sockaddr *)&server,length);
      if (n < 0)
   	    {
          *errorCode = SERIAL_SOCKET_ERROR;
#ifdef UNDER_CE
   		     closesocket(sock);
#elif defined(__linux__)
   		     close(sock);
#endif
   		     return(NULL);
   	    }

	  FD_ZERO(&fds);
	  FD_SET(sock,&fds);
	  tv.tv_sec = 0;
	  tv.tv_usec = 10000;
	  pollrc=select(1,&fds,NULL,NULL,&tv);

    } while (pollrc < 1);


    n = recvfrom(sock,(char *)&sMsg,sizeof(sMsg),0,(struct sockaddr *)&from, &length);
    if (n < 0)
   	  {
        *errorCode = SERIAL_SOCKET_ERROR;
#ifdef UNDER_CE
   		     closesocket(sock);
#elif defined(__linux__)
   		     close(sock);
#endif
   		   return(NULL);
   	  }
#ifdef UNDER_CE
   		     closesocket(sock);
#elif defined(__linux__)
   		     close(sock);
#endif

   	hash = hashSerial(sMsg.serialNum);
   	if (hash == NULL)
   		{
        *errorCode = SERIAL_HASH_NOT_FOUND;
   			return(NULL);
   		}
#ifdef __linux__
   	if (strcmp(hash,sMsg.sig))
   		{
        *errorCode = SERIAL_HASH_MISMATCH;
   			free(hash);
   			return(NULL);
   		}
		free(hash);

		hid1 = gethostid();
		hid2 = getMyHostid(sMsg.serialNum);

		if (hid1 != hid2)
			{
        *errorCode = SERIAL_HOSTID_MISMATCH;
				return(NULL);
			}
#endif
		return(sMsg.serialNum);

}
TCHAR * hashSerial(TCHAR *serialNum)
{
		serialMsg msg;
		SHA1_CTX context;
		u_int8_t digest[SHA1_DIGEST_LENGTH];
		TCHAR *hash=NULL;
		int			i;
		int     rc;

		memset(&msg,0,sizeof(msg));

		SHA1Init(&context);
		SHA1Update(&context, (u_int8_t *)serialNum, _tcslen(serialNum)*sizeof(TCHAR));
		SHA1Final(digest,&context);

		// this makes the key unique to a serial number
		for(i=0;i<SHA1_DIGEST_LENGTH;i++)
			{
				msg.frontKey[i] = keyArray[i] ^ digest[i%SHA1_DIGEST_LENGTH];
				msg.endKey[i] = msg.frontKey[i];
			}

		_tcsncpy(msg.serialNum,serialNum,sizeof(msg.serialNum));

		SHA1Init(&context);
		SHA1Update(&context, (u_int8_t *)&msg, sizeof(msg));
		SHA1Final(digest,&context);

		rc = base64_encode(digest,sizeof(digest),&hash);
		if (rc < 0)
			return(NULL);
		return(hash);
}
#ifdef __linux__
int getDivxKey(u_int8_t **key, int *errorCode)
{

   static   u_int8_t      divxKey[SHA1_DIGEST_LENGTH];
   int                    sock, length, n;
   struct                 sockaddr_in server, from;
   struct                 hostent *hp;
   int                    i;
   static   int           found=0;
   char                   eserialNum[COMMAND_SIZE];

   char  localhost[] = "ybpnyubfg";
   struct pollfd   fds;
   int pollrc;
   int     retryCount;

   *errorCode = SERIAL_STATUS_OK;
   (*key) = divxKey;
   if (found)
    return(0);

   sock= socket(AF_INET, SOCK_DGRAM, 0);
   if (sock < 0)
    {
      *errorCode = SERIAL_SOCKET_ERROR;
      return(-1);
    }

   server.sin_family = AF_INET;
   rot13(localhost);
   hp = gethostbyname(localhost);

   if (hp==0)
    {
      *errorCode = SERIAL_HOSTNAME_ERROR;
      return(-1);
    }


   bcopy((char *)hp->h_addr,(char *)&server.sin_addr,hp->h_length);
   server.sin_port = htons(SEC_PORT);
   length=sizeof(struct sockaddr_in);

   bzero(divxKey,SHA1_DIGEST_LENGTH);
   divxKey[0] = 'A';
   // throw in random bits to hide command
   srand(time(NULL));
   for(i=0;i<COMMAND_SIZE;i++)
   {
        eserialNum[i] = rand() & 0xff;
   }

   // set the command to send to sec server
   eserialNum[COMMAND_OFFSET]=GET_DIVX_KEY;

   retryCount = 0;
   do
    {
      // make sure it doesn't loop forevery
      if (retryCount > RETRY_COUNT)
        {
          *errorCode = SERIAL_TOO_MANY_RETRY;
          return(-1);
        }

      retryCount++;
      n=sendto(sock,eserialNum,COMMAND_SIZE,0,(const struct sockaddr *)&server,length);
      if (n < 0)
        {
          *errorCode = SERIAL_SOCKET_ERROR;
           close(sock);
           return(-1);
        }
      usleep(10000);  // sleep for 0.1 secs
      fds.fd=sock;
      fds.events |= POLLIN;

      pollrc=poll(&fds,1,1000);
    } while (!(fds.revents & POLLIN));

   if (pollrc < 0)
    {
      *errorCode = SERIAL_SOCKET_ERROR;
      return(-1);
    }

   n = recvfrom(sock,divxKey,SHA1_DIGEST_LENGTH,0,(struct sockaddr *)&from, &length);
   if (n < 0)
    {
      *errorCode = SERIAL_SOCKET_ERROR;
      close(sock);
      return(-1);
    }

    found=1;
    close(sock);
    return(0);

}
#endif
#ifdef __linux__
int getHwSecret(unsigned char **key, int *errorCode)
{

   static   unsigned char        hwSecret[HARDWARE_SECRET_SIZE];
   int                    sock, length, n;
   struct                 sockaddr_in server, from;
   struct                 hostent *hp;
   int                    i;
   static   int           found=0;
   char                   eserialNum[COMMAND_SIZE];

   char  localhost[] = "ybpnyubfg";
   struct pollfd   fds;
   int pollrc;
   int     retryCount;

   *errorCode = SERIAL_STATUS_OK;
   (*key) = hwSecret;

   if (found)
    return(0);

   sock= socket(AF_INET, SOCK_DGRAM, 0);
   if (sock < 0)
    {
      *errorCode = SERIAL_SOCKET_ERROR;
      return(-1);
    }

   server.sin_family = AF_INET;
   rot13(localhost);
   hp = gethostbyname(localhost);

   if (hp==0)
    {
      *errorCode = SERIAL_HOSTNAME_ERROR;
      return(-1);
    }


   bcopy((char *)hp->h_addr,(char *)&server.sin_addr,hp->h_length);
   server.sin_port = htons(SEC_PORT);
   length=sizeof(struct sockaddr_in);

   bzero(hwSecret,sizeof(hwSecret));

   // throw in random bits to hide command
   srand(time(NULL));
   for(i=0;i<COMMAND_SIZE;i++)
   {
        eserialNum[i] = rand() & 0xff;
   }

   // set the command to send to sec server
   eserialNum[COMMAND_OFFSET]=GET_HARDWARE_SECRET;

   retryCount = 0;
   do
    {
      // make sure it doesn't loop forevery
      if (retryCount > RETRY_COUNT)
        {
          *errorCode = SERIAL_TOO_MANY_RETRY;
          return(-1);
        }

      retryCount++;
      n=sendto(sock,eserialNum,COMMAND_SIZE,0,(const struct sockaddr *)&server,length);
      if (n < 0)
        {
          *errorCode = SERIAL_SOCKET_ERROR;
           close(sock);
           return(-1);
        }
      usleep(10000);  // sleep for 0.1 secs
      fds.fd=sock;
      fds.events |= POLLIN;

      pollrc=poll(&fds,1,1000);
    } while (!(fds.revents & POLLIN));

   if (pollrc < 0)
    {
      *errorCode = SERIAL_SOCKET_ERROR;
      return(-1);
    }

   n = recvfrom(sock,hwSecret,sizeof(hwSecret),0,(struct sockaddr *)&from, &length);
   if (n < 0)
    {
      *errorCode = SERIAL_SOCKET_ERROR;
      close(sock);
      return(-1);
    }

    found=1;
    close(sock);
    return(0);

}
#endif
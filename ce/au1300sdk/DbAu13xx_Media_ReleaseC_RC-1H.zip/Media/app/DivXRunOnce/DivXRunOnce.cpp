// DivXRunOnce.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <commctrl.h>

#include "DivXInterface.h"

int _tmain(int argc, _TCHAR* argv[])
{
	HINSTANCE hInstDivXLibrary;
	fnInitDrmMemory_t fnInitDrmMemory;

	RETAILMSG(1, (TEXT("Attempting to initialize DRM memory...\r\n")));
	
	hInstDivXLibrary = LoadLibrary(TEXT("DivXInterface.dll"));

	if (hInstDivXLibrary)
	{
		fnInitDrmMemory = (fnInitDrmMemory_t) GetProcAddress(hInstDivXLibrary, TEXT("InitDrmMemory"));
		
		if (NULL == fnInitDrmMemory)
		{
			DWORD dwError = GetLastError();

			RETAILMSG(1, (TEXT("Failed to get function InitDrmMemory %d\r\n"), dwError));
		}
		else
		{
			HRESULT hResult = (* fnInitDrmMemory)();

			if (SUCCEEDED(hResult))
			{
				RETAILMSG(1, (TEXT("Successfully initialized DRM Memory!!!\r\n")));
			}
			else
			{
				RETAILMSG(1, (TEXT("Failed to initialize DRM Memory!!!\r\n")));
			}
		}


		FreeLibrary(hInstDivXLibrary);
	}
	else
	{
		RETAILMSG(1, (TEXT("Failed to load DivX interface!!!\r\n")));
	}

	return 0;
}


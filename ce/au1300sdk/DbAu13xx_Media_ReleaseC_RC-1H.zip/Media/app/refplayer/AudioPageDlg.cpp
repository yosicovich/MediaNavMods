#include <dshow.h>
#include <windows.h>                 // For all that Windows stuff
#include <commctrl.h>                // Common Control includes
#include <prsht.h>                   // Property sheet includes
#include <nsplay.h>
#include <uuids.h>

#ifndef UNDER_CE
#include <initguid.h>
#endif // !UNDER_CE
#include <qnetwork.h>

#include "AvPageDlg.h"               // Program-specific stuff
#include "resource.h"
#include "playerwindow.h"
#include "refplayerutil.h"
#include "decibels.h"

#include "IAudioPostProc.h"

// DONE create a function to update eq settings from player window when file changes
// FIXIT call the funtion from the proper location, calling from CompleteOpen does not work

extern IAudioCore *g_pAudioCore;
HWND g_dlgEncodeAudio;
extern HMENU ghMenu;

// Identification strings for various WM_NOTIFY notifications
NOTELABELS nlPage1[] = 
{
  {TEXT ("MCN_SELCHANGE   "), MCN_SELCHANGE},
  {TEXT ("MCN_GETDAYSTATE "), MCN_GETDAYSTATE},
  {TEXT ("MCN_SELECT      "), MCN_SELECT},
  #ifdef UNDER_CE
    {TEXT ("MCN_SELECTNONE  "), MCN_SELECTNONE},
  #else
    {TEXT ("MCN_SELECTNONE  "), MCN_SELCHANGE},
  #endif
};

HRESULT GetAudioCorePointer(void)
{
  if (!g_pAudioCore)
  {
    if (!g_pPlayerWindow->GetAudioCoreInterface())
    {
      //DP_ERROR((TEXT("ERROR: SetAudioEqLevel cannot get AudioCore interface")));
      return S_FALSE;
    }
  }

  if (!g_pAudioCore)
    return S_FALSE;

  return S_OK;
}

int audio_page_eq_db_setting[5] = {0,0,0,0,0};
static int check_eq_level[5];
static int check_eq_bw[5] = { 50,50,50,50,50,};
static int check_eq_cf[5];
void SetAudioEqLevel(int band)
{
  if (FAILED(GetAudioCorePointer())) 
    return;

  if (check_eq_level[band] != audio_page_eq_db_setting[band]) // avoid sending the same info over and over
  {
    check_eq_level[band] = audio_page_eq_db_setting[band];
    if (FAILED(g_pAudioCore->SetEqLevel(NUMBER_OF_EQ_BANDS, band, audio_page_eq_db_setting[band])))
      DP_ERROR((TEXT("Failed SetEq(band %d %d)"), band, audio_page_eq_db_setting[band]));       
  } 
}

void GetAudioEqLevel(void)
{
  int ii;
  if (FAILED(GetAudioCorePointer())) 
  {
    for (ii = 0; ii < NUMBER_OF_EQ_BANDS; ii++)
      audio_page_eq_db_setting[ii] = 0;
    return;
  }

  for (ii = 0; ii < NUMBER_OF_EQ_BANDS; ii++)
  {
    int num_bands;
    if (FAILED(g_pAudioCore->GetEqLevel(&num_bands, ii, &audio_page_eq_db_setting[ii])))
    {            
      DP_ERROR((TEXT("Failed GetEq(band %d %d %d)"), num_bands, ii, audio_page_eq_db_setting[ii]));       
    } 
    else
      DP_INFO((TEXT("GetEq(band %d %d %d)"), num_bands, ii, audio_page_eq_db_setting[ii]));       
  }
}

void ReapplyAudioPageSettings(void)
{
  int ii;

  //DP_ERROR((TEXT("ReapplyAudioPageSettings enter")));
  if (FAILED(GetAudioCorePointer())) 
  {
    //DP_ERROR((TEXT("ReapplyAudioPageSettings GetAudioCorePointer failed")));
    return;
  }

  if (!g_pAudioCore)
  {
   // DP_ERROR((TEXT("ReapplyAudioPageSettings g_pAudioCore NULL")));
    return;
  }

  for (ii = 0; ii < NUMBER_OF_EQ_BANDS; ii++)
  {
    g_pAudioCore->SetEqCenterFrequency(ii, check_eq_cf[ii]);
    g_pAudioCore->SetEqBandwidthPercent(ii, check_eq_bw[ii]);
  }

  for (ii = 0; ii < NUMBER_OF_EQ_BANDS; ii++)
    SetAudioEqLevel(ii);
  //DP_ERROR((TEXT("ReapplyAudioPageSettings end")));
}


#define MAX_CF_SELECT_ENTRIES 10
const TCHAR cf_message[MAX_CF_SELECT_ENTRIES][8] =
{
  TEXT("60hz "),
  TEXT("125hz"),
  TEXT("250hz"),
  TEXT("500hz"),
  TEXT("1khz "),
  TEXT("2khz "),
  TEXT("4khz "),
  TEXT("5khz "),
  TEXT("8khz "),
  TEXT("10khz"),
};

//======================================================================
// AudioPageDlgProc - Page1 dialog box procedure
//
BOOL CALLBACK AudioPageDlgProc(HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam) 
{
  unsigned int nSetting;
  int ii, jj;
  LONG lVolume;
  int vol_disp_position;

  switch (wMsg) 
  {
    case WM_ACTIVATE:
      g_pPlayerWindow->m_pMP->get_Volume(&lVolume);
      lVolume = VolumeLogToLin(lVolume);
      if ((0 <= lVolume) && (lVolume <= 100))
        vol_disp_position = lVolume;
      else
        vol_disp_position = 50;// mid point
      SendDlgItemMessage(hWnd, IDC_EQ_VOL_SLIDER, TBM_SETPOS, (WPARAM)TRUE, (LPARAM)vol_disp_position);
      //use the saved eq values and apply them here
      for (ii = 0; ii < NUMBER_OF_EQ_BANDS; ii++)
      {
        int eq_db_position = (12 - audio_page_eq_db_setting[ii]) * 100 / 24;
        SendDlgItemMessage(hWnd, IDC_EQ_SLIDER_0 + ii, TBM_SETPOS, (WPARAM)TRUE, (LPARAM)eq_db_position);
        ComboBox_SetCurSel(GetDlgItem(hWnd, IDC_EQ_CF_CONTROL_0 + ii), check_eq_cf[ii]);
        SendDlgItemMessage(hWnd, IDC_EQ_BW_SLIDER_0 + ii, TBM_SETPOS, (WPARAM)TRUE, (LPARAM)check_eq_bw[ii]);
      }
      return TRUE;

    case WM_INITDIALOG:
      //DP_ERROR((TEXT("AudioPageDlgProc WM_INITDIALOG")));
      // NO GetAudioEqLevel(); Use the locally saved values instead since the graph may have been rebuilt.
      GetAudioCorePointer();
      // Set one of the eq bands just to get the eq engine running
      if (FAILED(g_pAudioCore->SetEqLevel(NUMBER_OF_EQ_BANDS, 0, audio_page_eq_db_setting[0])))
        DP_ERROR((TEXT("AudioPageDlgProc Failed SetEq(band %d %d)"), 0, audio_page_eq_db_setting[0]));       

      for (ii = 0; ii < NUMBER_OF_EQ_BANDS; ii++)
      {
        int index;
        int eq_db_position = (12 - audio_page_eq_db_setting[ii]) * 100 / 24;
        DP_INFO((TEXT("EQ %d %d %d %d)"), IDC_EQ_SLIDER_0 + ii, ii, eq_db_position, audio_page_eq_db_setting[ii]));       
        SendDlgItemMessage(hWnd, IDC_EQ_SLIDER_0 + ii, TBM_SETPOS, (WPARAM)TRUE, (LPARAM)eq_db_position);
        SendDlgItemMessage(hWnd, IDC_EQ_SLIDER_0 + ii, TBM_SETTICFREQ, (WPARAM)10, (LPARAM)0);
        
        SendDlgItemMessage(hWnd, IDC_EQ_BW_SLIDER_0 + ii, TBM_SETPOS, (WPARAM)TRUE, (LPARAM)check_eq_bw[ii]);
        
        for (jj = 0; jj < MAX_CF_SELECT_ENTRIES; jj++)
          ComboBox_AddString(GetDlgItem(hWnd, IDC_EQ_CF_CONTROL_0 + ii), cf_message[jj]);
        if (g_pAudioCore != NULL)
          g_pAudioCore->GetEqCenterFrequency(ii, &index);
        check_eq_cf[ii] = index;
        ComboBox_SetCurSel(GetDlgItem(hWnd, IDC_EQ_CF_CONTROL_0 + ii), check_eq_cf[ii]);
      }

      // also raise the global volume by 12 db to compensate for the 12 db attenuation in the eq block
      g_pPlayerWindow->m_pMP->get_Volume(&lVolume);
      vol_disp_position = VolumeLogToLin(lVolume);
      vol_disp_position += 50;
      if (vol_disp_position > 100)
        vol_disp_position = 100;
      g_pPlayerWindow->m_pMP->put_Volume(VolumeLinToLog((short)vol_disp_position));
      SendDlgItemMessage(hWnd, IDC_EQ_VOL_SLIDER, TBM_SETPOS, (WPARAM)TRUE, (LPARAM)vol_disp_position);
      return TRUE;
     
    // all other WM_COMMAND messages handled by main window
    case WM_COMMAND:
      if (HIWORD(wParam) == 8)
      {
        if (LOWORD(wParam) == IDC_EQ_CF_CONTROL_0)
        {
          nSetting = ComboBox_GetCurSel(GetDlgItem(hWnd, IDC_EQ_CF_CONTROL_0));
          if (check_eq_cf[0] != nSetting)
          {
            check_eq_cf[0] = nSetting;
            if (g_pAudioCore != NULL)
              g_pAudioCore->SetEqCenterFrequency(0, nSetting);
          }
        }
        else if (LOWORD(wParam) == IDC_EQ_CF_CONTROL_1)
        {
          nSetting = ComboBox_GetCurSel(GetDlgItem(hWnd, IDC_EQ_CF_CONTROL_1));
          if (check_eq_cf[1] != nSetting)
          {
            check_eq_cf[1] = nSetting;
            if (g_pAudioCore != NULL)
              g_pAudioCore->SetEqCenterFrequency(1, nSetting);
          }
        }
        else if (LOWORD(wParam) == IDC_EQ_CF_CONTROL_2)
        {
          nSetting = ComboBox_GetCurSel(GetDlgItem(hWnd, IDC_EQ_CF_CONTROL_2));
          if (check_eq_cf[2] != nSetting)
          {
            check_eq_cf[2] = nSetting;
            if (g_pAudioCore != NULL)
              g_pAudioCore->SetEqCenterFrequency(2, nSetting);
          }
        }
        else if (LOWORD(wParam) == IDC_EQ_CF_CONTROL_3)
        {
          nSetting = ComboBox_GetCurSel(GetDlgItem(hWnd, IDC_EQ_CF_CONTROL_3));
          if (check_eq_cf[3] != nSetting)
          {
            check_eq_cf[3] = nSetting;
            if (g_pAudioCore != NULL)
              g_pAudioCore->SetEqCenterFrequency(3, nSetting);
          }
        }
        else if (LOWORD(wParam) == IDC_EQ_CF_CONTROL_4)
        {
          nSetting = ComboBox_GetCurSel(GetDlgItem(hWnd, IDC_EQ_CF_CONTROL_4));
          if (check_eq_cf[4] != nSetting)
          {
            check_eq_cf[4] = nSetting;
            if (g_pAudioCore != NULL)
              g_pAudioCore->SetEqCenterFrequency(4, nSetting);
          }
        }
      }
      return TRUE;

    case WM_NOTIFY:
      {
        LPNMHDR pnmh = (LPNMHDR)lParam;
        switch (pnmh->code)
        {
          case PSN_APPLY:
            // OK button. Instead of applying the changes we just close the dialog box
            DestroyWindow(GetParent(hWnd));
            g_hwndAvSettings = NULL;
            break;
          case PSN_RESET:
            // X button. Close the dialog box
            DestroyWindow(GetParent(hWnd));
            g_hwndAvSettings = NULL;
            break;
        }
      }
      return FALSE;

    case WM_HSCROLL:
      lVolume = SendDlgItemMessage(hWnd, IDC_EQ_VOL_SLIDER, TBM_GETPOS, 0, 0);
      g_pPlayerWindow->m_pMP->put_Volume(VolumeLinToLog((short)lVolume));
      for (ii = 0; ii < NUMBER_OF_EQ_BANDS; ii++)
      {
        int bw_position = SendDlgItemMessage(hWnd, IDC_EQ_BW_SLIDER_0 + ii, TBM_GETPOS, 0, 0);
        if (check_eq_bw[ii] != bw_position)
        {
          //if (g_pAudioCore != NULL)
          //  g_pAudioCore->GetEqBandwidthPercent(ii, &check_eq_bw[ii]);
          check_eq_bw[ii] = bw_position;
          if (g_pAudioCore != NULL)
            g_pAudioCore->SetEqBandwidthPercent(ii, bw_position);
        }
      }
      return FALSE;

    case WM_VSCROLL:
      for (ii = 0; ii < NUMBER_OF_EQ_BANDS; ii++)
      {
        audio_page_eq_db_setting[ii] = 12 - (24 * SendDlgItemMessage(hWnd, IDC_EQ_SLIDER_0 + ii, TBM_GETPOS, 0, 0) / 100);
        SetAudioEqLevel(ii);
      }
      return FALSE;
  }
  return FALSE;
}


void CPlayerWindow::EnableEncodeAudioMenu(BOOL bEnable)
{
  EnableMenuItem(ghMenu, (UINT) ID_ENCODE_AUDIO, (UINT) (bEnable) ? MF_ENABLED : MF_GRAYED);
}

#define MAX_MESSAGE_SIZE 256
#define ENCODE_AUDIO_NAME_CHOICES 4
TCHAR encode_audio_file_name[ENCODE_AUDIO_NAME_CHOICES][MAX_MESSAGE_SIZE];

typedef struct _AudioInfo
{
    WAVEFORMATEX wfmtWaveFormat;
    BSTR         bstrCodecDescription;
    LPWSTR       lpwcCodecBitrate;
    BOOL         bStereo;   
    VARIANT_BOOL bSecure;
} AUDIOINFO, LPAUDIOINFO;

static HRESULT AudioInfo( LPAUDIOINFO           * audioInfo,
                   IBasicAudio           * piba,
                   IAMNetShowExProps     * pnsep,
                   IAMSecureMediaContent * psmc )
{
  HRESULT hResult = E_FAIL;

  if (NULL == audioInfo)
  {
    hResult = E_INVALIDARG;
  }
  else
  {
    audioInfo->wfmtWaveFormat.nSamplesPerSec = 0;
    audioInfo->wfmtWaveFormat.nChannels = 0;
    audioInfo->lpwcCodecBitrate = NULL;
    audioInfo->bstrCodecDescription = L"";
    audioInfo->bSecure = FALSE;

    if (NULL != piba)
    {
      IBaseFilter *pibf = NULL;
      piba->QueryInterface( IID_IBaseFilter, (void **)&pibf );
      if ( pibf != NULL )
      {
        IEnumPins *piep = NULL;
        DWORD lFetched;
      
        IPin *pp;
        pibf->EnumPins( &piep );
        if ( piep != NULL )
        {
          piep->Reset();
        
          while ( (NOERROR == piep->Next( 1, &pp, &lFetched ) ) && ( pp != NULL ) )
          {
            AM_MEDIA_TYPE mt;
            if ( SUCCEEDED( pp->ConnectionMediaType( &mt ) ) )
            {
              if ( mt.formattype == FORMAT_WaveFormatEx )
              {
                WAVEFORMATEX *pwfx = ( WAVEFORMATEX * )mt.pbFormat;
                if ( pwfx != NULL )
                {
                  *(&audioInfo->wfmtWaveFormat) = *pwfx;
                  hResult = S_OK;

                  if ( mt.cbFormat )
                    CoTaskMemFree( mt.pbFormat );
                  pp->Release();
                  pp = NULL;
                  break;
                }
                else
                {
                  hResult = E_POINTER;
                }
              }
              else
              {
                hResult = S_FALSE;
              }
              // AM_MEDIA_TYPE is a structure on the stack, NOT an object.
              // When it goes out of scope, it will not clean up its internal members.
              if ( mt.cbFormat )
                CoTaskMemFree( mt.pbFormat );
            }

            pp->Release();
            pp = NULL;
          }
          piep->Release();
        }
        pibf->Release();
      }
    }

    if (NULL != pnsep)
    {
      long codecCount = 0;
      if ( SUCCEEDED( g_pPlayerWindow->m_pMP->get_CodecCount( &codecCount ) ) 
        && codecCount )
      {
        int i;
        for( i = 1; i <= codecCount; i++ )
        {
          BSTR codecDesc;
          if ( SUCCEEDED( g_pPlayerWindow->m_pMP->GetCodecDescription( i, &codecDesc ) ) && wcsstr( codecDesc, L"Audio" ) )
          {
            audioInfo->bstrCodecDescription = codecDesc;
            hResult = S_OK;
            break;
          }
        } // for each codec, until audio is found
      } // get_CodecCount succeeded and count > 0
    } // g_pPlayerWindow->m_pMP is valid

#ifdef UNDER_CE
    if ( NULL != psmc )
    {
      psmc->get_IsSecure( &audioInfo->bSecure );
      hResult = S_OK;
    }
#endif /* UNDER_CE */
  }

  return hResult;
}

void UpdateEncodeAudioDialog(HWND hWnd)
{
  ComboBox_ResetContent(GetDlgItem(hWnd, IDC_ENCODEAUDIO_LIST));

  TCHAR *filename;
  IBasicAudio           * piba  = NULL;
  IAMNetShowExProps     * pnsep = NULL;
  IAMSecureMediaContent * psmc  = NULL;

  g_pPlayerWindow->FindInterfaceOnGraph(IID_IBasicAudio,           (void**)&piba);
  g_pPlayerWindow->FindInterfaceOnGraph(IID_IAMNetShowExProps,     (void**)&pnsep);
  g_pPlayerWindow->FindInterfaceOnGraph(IID_IAMSecureMediaContent, (void**)&psmc);

  BSTR property = NULL;

  g_pPlayerWindow->m_pMP->get_FileName( &property );
  if ( property )
  {
    if ( *property )
    {
      TCHAR *slash = wcsrchr( property, L'\\' );
      filename = slash ? ++slash : property;
      DP_ENCODE((TEXT("UpdateEncodeAudioDialog filename %s"), filename));
    }
  }
  // Fill in our audio-specific information
  AUDIOINFO audioInfo;
  memset( &audioInfo, 0, sizeof( AUDIOINFO ) );
  if ( SUCCEEDED( AudioInfo( &audioInfo, piba, pnsep, psmc ) ) )
  {
    if ( audioInfo.wfmtWaveFormat.nSamplesPerSec )
    {
      //WCHAR frequency[8];
      //StringCchPrintf(frequency, 8, L"%d hz", audioInfo.wfmtWaveFormat.nSamplesPerSec);
      DP_ENCODE((TEXT("UpdateEncodeAudioDialog sampling rate %d"), audioInfo.wfmtWaveFormat.nSamplesPerSec));
    }
    if ( audioInfo.wfmtWaveFormat.nChannels )
    {
      //WCHAR stereo[4];
      //StringCchCopy(stereo, 4, audioInfo.wfmtWaveFormat.nChannels > 1 ? L"Yes" : L"No" );
      DP_ENCODE((TEXT("UpdateEncodeAudioDialog channels %d"), audioInfo.wfmtWaveFormat.nChannels));
    }
  }
  // 'filename' the name from the graph
  // check the file extension, for now we are only converting wav and wma files
  TCHAR *lpwszExtension = wcsrchr(filename, L'.');
  DP_ENCODE((TEXT("EncodeAudioDlgProc file extension is '%s'"), lpwszExtension));
  if ( !(
     (wcsicmp(lpwszExtension, L".wav") == 0) || 
     (wcsicmp(lpwszExtension, L".wma") == 0) ||
     (wcsicmp(lpwszExtension, L".mp3") == 0) 
     ))
  {
    DP_ENCODE((TEXT("EncodeAudioDlgProc only wav, wma, or mp3 files can be converted! '%s'"), lpwszExtension));
    // unsupported, so grey out everything
    EnableWindow(GetDlgItem(hWnd, IDC_ENCODEAUDIO_LIST      ), FALSE);
    return;
  }

  if (audioInfo.wfmtWaveFormat.nChannels != 2  || audioInfo.wfmtWaveFormat.nSamplesPerSec != 44100)
  {
    DP_ENCODE((TEXT("EncodeAudioDlgProc unsupported channels %d or rate %d"), audioInfo.wfmtWaveFormat.nChannels, audioInfo.wfmtWaveFormat.nSamplesPerSec));
    // unsupported channels or rate so grey out everything
    EnableWindow(GetDlgItem(hWnd, IDC_ENCODEAUDIO_LIST      ), FALSE);
    return;
  }

  if (g_pAudioCore)
  {
    int filename_num = 0;
    unsigned int enabled;

    // remove the file extension from the file name
    lpwszExtension[0] = 0;
    // make the file extension .ogg
    wsprintf(encode_audio_file_name[0], TEXT("%s.ogg\0"), filename);
    
    for (filename_num = 0; filename_num < ENCODE_AUDIO_NAME_CHOICES; filename_num++)
    {
      if (filename_num != 0)
        wsprintf(encode_audio_file_name[filename_num], TEXT("test%d.ogg\0"), filename_num);
      ComboBox_AddString(GetDlgItem(hWnd, IDC_ENCODEAUDIO_LIST), encode_audio_file_name[filename_num]);
    }
    EnableWindow(GetDlgItem(hWnd, IDC_ENCODEAUDIO_LIST), TRUE);
    g_pAudioCore->GetAudioEncode(&enabled);
    DP_ENCODE((TEXT("EncodeAudioDlgProc enabled %d"), enabled));

  } 
  else
  {
    //no interface so grey out everything
    EnableWindow(GetDlgItem(hWnd, IDC_ENCODEAUDIO_LIST      ), FALSE);
  }
}

LRESULT CALLBACK EncodeAudioDlgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  unsigned int nSetting;

  switch (message)
  {
    case WM_INITDIALOG:
      UpdateEncodeAudioDialog(hWnd);
      return TRUE;
    case WM_CLOSE:
      DestroyWindow(g_dlgEncodeAudio);
      g_dlgEncodeAudio = NULL;
      return TRUE;
    case WM_COMMAND:
      if (LOWORD(wParam) == IDC_ENCODEAUDIO_ENABLED)
      {
        int checked = SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
        DP_ENCODE((TEXT("EncodeAudioDlgProc encode audio checkbox %d"), checked));
        g_pAudioCore->SetAudioEncode(checked);
      }
      else if (LOWORD(wParam) == IDC_ENCODEAUDIO_LIST)
      {
        if (HIWORD(wParam) == 8)
        {
          nSetting = ComboBox_GetCurSel(GetDlgItem(hWnd, IDC_ENCODEAUDIO_LIST));
          DP_ENCODE((TEXT("EncodeAudioDlgProc filename nSetting %d"), nSetting, encode_audio_file_name[nSetting]));
          if (g_pAudioCore)
            g_pAudioCore->SetAudioEncodeName(encode_audio_file_name[nSetting]);
        }
      }  
      else if ((wParam == IDCANCEL) || (wParam == IDCLOSE))
      {
        DestroyWindow(g_dlgEncodeAudio);
        g_dlgEncodeAudio = NULL;
        return TRUE;
      }
      break;
    default:
      //DP_WARNING((TEXT("EncodeAudioDlgProc ungrabbed message %d %x"), message, message));
      break;
  }
  return FALSE;
}

bool CPlayerWindow::OnEncodeAudioMenu(void)
{
  bool bResult = true;
 
  // Disallow other instances of this window.
  if (g_dlgEncodeAudio)
  {
    DP_WARNING((TEXT("OnEncodeAudioMenu window already open")));
    return false;
  }
  if (g_pAudioCore == NULL)
  {
    if (!g_pAudioCore)
      GetAudioCoreInterface();

    if (g_pAudioCore != NULL)
    {
      DP_STREAM((TEXT("FindInterface ok for Encode Audio g_pAudioCore found")));
      g_pPlayerWindow->EnableEncodeAudioMenu(TRUE);
    } 
    else
    {
      DP_ERROR((TEXT("FindInterface failed for Encode Audio")));
      g_pPlayerWindow->EnableEncodeAudioMenu(FALSE);
    }
  }

  if (g_pAudioCore != NULL)
  {
    DP_STREAM((TEXT("OnEncodeAudioMenu try to open IDD_ENCODE_AUDIO_MENU")));
    g_dlgEncodeAudio = CreateDialog(m_hInstance, (LPCTSTR)IDD_ENCODE_AUDIO_MENU, m_hWnd, (DLGPROC)EncodeAudioDlgProc);
    ShowWindow(g_dlgEncodeAudio, SW_SHOW);
  }
  else
  {
    DP_STREAM((TEXT("OnEncodeAudioMenu failed to open a window g_pAudioCore %p"), g_pAudioCore));
    bResult = false;
  }

  return bResult;
}


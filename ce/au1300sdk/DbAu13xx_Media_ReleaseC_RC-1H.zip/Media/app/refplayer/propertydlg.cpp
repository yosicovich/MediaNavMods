//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
///////////////////////////////////////////////////////////////////////////////
// File: PropertyDlg.cpp
//
// Desc: This file defines the member functions of the Property Dialog class
//       as well as the DialogProc for the dialog.
//
///////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#define _COMCTL32_
#include <commctrl.h>
#undef  _COMCTL32_

#include <nsplay.h>

#include "PropertyDlg.h"
#include "resource.h"

#include <uuids.h>

#ifndef UNDER_CE
#include <initguid.h>
#endif // !UNDER_CE
#include "qnetwork.h"

#include "aygshell_helper.h"
#include <strsafe.h>
#include <atlbase.h>

#include "debug.h"

extern bool g_bSmallScreen;

///////////////////////////////////////////////////////////////////////////////
// Name: PropertyDialogProc()
// Desc: This function handles dialog messages for the Property dialog box.
///////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK PropertyDialogProc(HWND hWndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  static CPropertyDlg *pPropertyDlg = NULL;

  switch (uMsg)
  {
    case WM_INITDIALOG:
      // Once this dialog is created, create the associated PropertyDlg class.
      // There can only be one Property dialog open at a time, hence the need
      // for the static variable pPropertyDlg.
      pPropertyDlg = new CPropertyDlg;

      if (NULL == pPropertyDlg || false == pPropertyDlg->Init(hWndDlg))
      {
         DestroyWindow(hWndDlg);
      }
      else if ( g_bSmallScreen && g_AygshellHelper.Loaded() )
      {
          SHINITDLGINFO shidi;
          shidi.dwMask = SHIDIM_FLAGS;
          shidi.dwFlags = SHIDIF_SIZEDLGFULLSCREEN | SHIDIF_SIPDOWN | SHIDIF_DONEBUTTON;
          shidi.hDlg = hWndDlg;
          g_AygshellHelper.SHInitDialog( &shidi );
      }

      return TRUE;

    case WM_COMMAND:
      switch (LOWORD(wParam))
      {
       case IDCANCEL:
       case IDOK:
       case ID_DLG_CLOSE:
         DestroyWindow(hWndDlg);
         return TRUE;
      }

      return FALSE;

    case WM_NOTIFY:
        if (pPropertyDlg)
            return pPropertyDlg->HandleNotifyMsg( hWndDlg, uMsg, wParam, lParam );
        break;

    case WM_CLOSE:
        DestroyWindow(hWndDlg);
        return FALSE;

    case WM_DESTROY:
      if (NULL != pPropertyDlg)
      {
         delete pPropertyDlg;
         pPropertyDlg = NULL;
      }

      return TRUE;

    // This message is sent by the parent window to tell the dialog to show
    // itself.
    case PD_SHOW:
        if (pPropertyDlg)
        {
            pPropertyDlg->Show(static_cast<int>(wParam));
            return TRUE;
        }
        break;

    // This message is sent by the parent window to get the dialog to update
    // its display.
    case PD_UPDATE:
        if (pPropertyDlg)
        {
            if (!lParam)
                pPropertyDlg->Update(reinterpret_cast<TCHAR*>(wParam));
            else
                pPropertyDlg->UpdateAndRender(reinterpret_cast<TCHAR*>(wParam));
            return TRUE;
        }
        break;
  }

  return FALSE;
}

CPropertyDlg::CPropertyDlg() : m_hWnd(NULL),
                               m_hWndParent(NULL),
                               m_hListView(NULL),
                               m_hFont(NULL)
{
    LOGFONT logfont;
    memset( &logfont, 0, sizeof( logfont ) );
    logfont.lfWeight = FW_SEMIBOLD;
    logfont.lfHeight = -11;
    m_hFont = CreateFontIndirect( &logfont );
}

CPropertyDlg::~CPropertyDlg()
{
   (void)Fini();

   if (m_hFont)
       DeleteObject(m_hFont);
}

BOOL CPropertyDlg::HandleNotifyMsg( HWND hWndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    BOOL fHandled = FALSE;
    NMHDR *pnmh = (NMHDR *)lParam;
    NMLISTVIEW *pnmlv = (NMLISTVIEW *)lParam;

    if ( ( NM_CUSTOMDRAW == pnmh->code ) &&
        ( m_hListView == pnmh->hwndFrom ) )
    {
        NMLVCUSTOMDRAW *pcd = (NMLVCUSTOMDRAW *)lParam;

        if ( CDDS_PREPAINT == pcd->nmcd.dwDrawStage )
        {
            SetWindowLong( hWndDlg, DWL_MSGRESULT, CDRF_NOTIFYITEMDRAW );
            fHandled = TRUE;
        }
        else if ( CDDS_ITEMPREPAINT == pcd->nmcd.dwDrawStage )
        {
            if ( 0 == ( pcd->nmcd.dwItemSpec % 2 ) && m_hFont)
            {
                SelectObject( pcd->nmcd.hdc, m_hFont);
                SetWindowLong( hWndDlg, DWL_MSGRESULT, CDRF_NEWFONT );
            }
            fHandled = TRUE;
        }
    }
    else if ( LVN_DELETEALLITEMS == pnmh->code )
    {
        //
        // Suppress LVN_DELETEITEM notifications
        //
        SetWindowLong( hWndDlg, DWL_MSGRESULT, TRUE );
        fHandled = TRUE;
    }
    return fHandled;
}

///////////////////////////////////////////////////////////////////////////////
// Name: CPropertyDlg::Init()
// Desc: This function initializes the PropertyDlg class.  The parameter hWnd
//       is a handle to the Property dialog box.
///////////////////////////////////////////////////////////////////////////////
bool CPropertyDlg::Init(HWND hWnd)
{
    m_hWnd       = hWnd;
    m_hWndParent = ::GetParent(m_hWnd);
    m_hListView  = GetDlgItem( m_hWnd, IDC_PROPERTIES_LIST );

    //
    // Check to see if the screen is small
    //
    if (g_bSmallScreen)
    {
        RECT rcWorkArea;
        RECT rcWnd, rcList;

        GetWindowRect(m_hWnd,      &rcWnd);
        GetWindowRect(m_hListView, &rcList);

        if (!SystemParametersInfo(SPI_GETWORKAREA, 0, &rcWorkArea, 0))
        {
            HDC hdc = ::GetDC(NULL);

            rcWorkArea.left = 0;
            rcWorkArea.top  = 0;

            rcWorkArea.right  = GetDeviceCaps(hdc, HORZRES);
            rcWorkArea.bottom = GetDeviceCaps(hdc, VERTRES) - GetSystemMetrics(SM_CYMENU);

            ::ReleaseDC(NULL, hdc);
        }

        MoveWindow(m_hWnd,
                   rcWorkArea.left,
                   rcWorkArea.top,
                   rcWorkArea.right,
                   rcWorkArea.bottom,
                   TRUE);

        rcWorkArea.left   += rcList.left - rcWnd.left;
        rcWorkArea.right  -= rcList.left - rcWnd.left;
        rcWorkArea.right  += rcList.right - rcWnd.right - 2*GetSystemMetrics(SM_CXDLGFRAME);

        rcWorkArea.top    += rcList.top  - rcWnd.top - GetSystemMetrics(SM_CYCAPTION);
        rcWorkArea.bottom -= rcList.top  - rcWnd.top;
        rcWorkArea.bottom += rcList.bottom - rcWnd.bottom;

        MoveWindow(m_hListView,
                   rcWorkArea.left,
                   rcWorkArea.top,
                   rcWorkArea.right,
                   rcWorkArea.bottom,
                   TRUE);
    }

    LVCOLUMN column;
    int i = 0;

    RECT rect;
    GetClientRect( m_hListView, &rect );
    column.mask = LVCF_FMT | LVCF_WIDTH;
    column.fmt = LVCFMT_LEFT;
    column.cx = rect.right - rect.left;
    column.iSubItem = 0;
    column.iOrder = 0;
    column.iImage = 0;
    int result = ListView_InsertColumn( m_hListView, 0, &column );

    ListView_SetExtendedListViewStyle( m_hListView, LVS_EX_GRIDLINES );
   return true;
}

///////////////////////////////////////////////////////////////////////////////
// Name: CPropertyDlg::Fini()
// Desc: This function takes care of all the clean-up necessary for the
//       PropertyDlg class, including destroying the window and notifying the
//       parent window that the dialog has closed.
///////////////////////////////////////////////////////////////////////////////
bool CPropertyDlg::Fini()
{
   bool bResult = false;

   if (NULL != m_hWndParent)
   {
      PostMessage(m_hWndParent, PD_CLOSED, NULL, NULL);
      m_hWndParent = NULL;
   }

   return bResult;
}

///////////////////////////////////////////////////////////////////////////////
// Name: CPropertyDlg::Show()
// Desc: This function makes the dialog show/hide itself.
///////////////////////////////////////////////////////////////////////////////
bool CPropertyDlg::Show(int iShowCmd)
{
   bool  bResult = false;

   // Simple error check
   if (NULL == m_hWnd)
   {
      return bResult;
   }

   if (FALSE == ShowWindow(m_hWnd, iShowCmd))
   {
      bResult = false;
   }
   else
   {
      bResult = true;
   }

   return bResult;
}

static void Time2String( double dTime, __out_ecount (dwcchTime) LPTSTR tszTime, DWORD dwcchTime, BOOL fShowMilliSecs, BOOL fShowZeroHour, LPCTSTR tszTimeSep, LPCTSTR tszDecimalSep )
{
    LONG lRemainingSecs;  // remaining secons we have to convert
    
    lRemainingSecs = (LONG) dTime;  // ignore fractions of secs for a sec :-)
    
    LONG lHours = lRemainingSecs / 3600;   // 3600 seconds in the hour
    lRemainingSecs  = lRemainingSecs % 3600;
    
    LONG lMinutes = lRemainingSecs / 60;   // 60 seconds in the minute
    lRemainingSecs    = lRemainingSecs % 60;
    
    LONG lSeconds = lRemainingSecs;
    
    // take remaining fraction and scale to millisecs
    if (fShowMilliSecs) {
        LONG lMilliSecs = (LONG) ((dTime - (LONG) dTime) * 1000.0);
        
        if (lHours == 0 && !fShowZeroHour) {
            StringCchPrintf( tszTime, dwcchTime, TEXT("%02lu%s%02lu%s%03lu"), lMinutes, tszTimeSep, lSeconds, tszDecimalSep, lMilliSecs );
        } else {
            StringCchPrintf( tszTime, dwcchTime, TEXT("%02lu%s%02lu%s%02lu%s%03lu"), lHours, tszTimeSep, lMinutes, tszTimeSep, lSeconds, tszDecimalSep, lMilliSecs );
        }
    } else {
        if (lHours == 0 && !fShowZeroHour) {
            StringCchPrintf( tszTime, dwcchTime, TEXT("%02lu%s%02lu"), lMinutes, tszTimeSep, lSeconds );
        } else {
            StringCchPrintf( tszTime, dwcchTime, TEXT("%02lu%s%02lu%s%02lu"), lHours, tszTimeSep, lMinutes, tszTimeSep, lSeconds );
        }
    }
}

HRESULT CPropertyDlg::VideoInfo( BSTR * videoInfo, IAMNetShowExProps * pnsep )
{
    HRESULT hResult = E_FAIL;
    *videoInfo = (TCHAR *)L"";

    if (NULL != pnsep)
    {
        long codecCount = 0;

        if (SUCCEEDED(pnsep->get_CodecCount(&codecCount)))
        {
            for (int i = codecCount; i > 0; i--)
            {
                BSTR codecDesc;

                if (SUCCEEDED(pnsep->GetCodecDescription(i, &codecDesc))
                    && !wcsstr(codecDesc, L"Audio"))
                {
                    LPWSTR comma;

                    if (comma = wcsrchr(codecDesc, L'('))
                    {
                        *comma = L'\0';
                    }

                    *videoInfo = codecDesc;
                    hResult = S_OK;
                    break;
                }
            }
        }
    }

    return hResult;
}

HRESULT CPropertyDlg::AudioInfo( LPAUDIOINFO           * audioInfo,
                                 IBasicAudio           * piba,
                                 IAMNetShowExProps     * pnsep,
                                 IAMSecureMediaContent * psmc )
{
  HRESULT hResult = E_FAIL;

  if (NULL == audioInfo)
  {
    hResult = E_INVALIDARG;
  }
  else
  {
    audioInfo->wfmtWaveFormat.nSamplesPerSec = 0;
    audioInfo->wfmtWaveFormat.nChannels = 0;
    audioInfo->lpwcCodecBitrate = NULL;
    audioInfo->bstrCodecDescription = L"";
    audioInfo->bSecure = FALSE;

    if (NULL != piba)
    {
      IBaseFilter *pibf = NULL;
      piba->QueryInterface( IID_IBaseFilter, (void **)&pibf );
      if ( pibf != NULL )
      {
        IEnumPins *piep = NULL;
        DWORD lFetched;
      
        IPin *pp;
        pibf->EnumPins( &piep );
        if ( piep != NULL )
        {
          piep->Reset();
        
          while ( (NOERROR == piep->Next( 1, &pp, &lFetched ) ) && ( pp != NULL ) )
          {
            AM_MEDIA_TYPE mt;
            if ( SUCCEEDED( pp->ConnectionMediaType( &mt ) ) )
            {
              if ( mt.formattype == FORMAT_WaveFormatEx )
              {
                WAVEFORMATEX *pwfx = ( WAVEFORMATEX * )mt.pbFormat;
                if ( pwfx != NULL )
                {
                  *(&audioInfo->wfmtWaveFormat) = *pwfx;
                  hResult = S_OK;

                  if ( mt.cbFormat )
                    CoTaskMemFree( mt.pbFormat );
                  pp->Release();
                  pp = NULL;
                  break;
                }
                else
                {
                  hResult = E_POINTER;
                }
              }
              else
              {
                hResult = S_FALSE;
              }
              // AM_MEDIA_TYPE is a structure on the stack, NOT an object.
              // When it goes out of scope, it will not clean up its internal members.
              if ( mt.cbFormat )
                CoTaskMemFree( mt.pbFormat );
            }

            pp->Release();
            pp = NULL;
          }
          piep->Release();
        }
        pibf->Release();
      }
    }

    if (NULL != pnsep)
    {
      long codecCount = 0;
      if ( SUCCEEDED( g_pPlayerWindow->m_pMP->get_CodecCount( &codecCount ) ) 
        && codecCount )
      {
        int i;
        for( i = 1; i <= codecCount; i++ )
        {
          BSTR codecDesc;
          if ( SUCCEEDED( g_pPlayerWindow->m_pMP->GetCodecDescription( i, &codecDesc ) )
            && wcsstr( codecDesc, L"Audio" ) )
          {
            audioInfo->bstrCodecDescription = codecDesc;
            hResult = S_OK;
            break;
          }
        } // for each codec, until audio is found
      } // get_CodecCount succeeded and count > 0
    } // g_pPlayerWindow->m_pMP is valid

#ifdef UNDER_CE
    if ( NULL != psmc )
    {
      psmc->get_IsSecure( &audioInfo->bSecure );
      hResult = S_OK;
    }
#endif /* UNDER_CE */
  }

  return hResult;
}

#define MAX_FILTS 16
#define MAX_PINS   4
typedef struct 
{
  wchar_t     fname[256];
  IBaseFilter *filt;
  int         pincount;
  int         pintype[MAX_PINS];
  PIN_INFO    pininfo[MAX_PINS];
  IPin        *pin[MAX_PINS];
  IPin        *connectedpin[MAX_PINS];
} FilterPinInfo;

FilterPinInfo filters_to_show[MAX_FILTS];

int num_connected_pins(FilterPinInfo *fpi)
{
  int count = 0;
  int jj;

  DP_INFO((TEXT("%d pins"), fpi->pincount));
  for (jj = 0; jj < fpi->pincount; jj++)
  {
    DP_INFO((TEXT("pin %d   %d "), fpi->pintype[jj], jj));
    if (fpi->pintype[jj] >= 0)
      count++;
  }
  DP_INFO((TEXT("count %d"), count));
  return count;
}

typedef struct 
{
  int fa;
  int fb;
  int direction;
} f_connections;

int rchain(int end, f_connections *sc, int sci, int *chain, int *ccnt)
{
  int ii, jj;
  int head;
  
  DP_INFO((TEXT("rchain enter ccnt %d"), *ccnt));
  for (ii = 0; ii < sci; ii++)
  {
    DP_INFO((TEXT("A check %d->%d with end %d"), sc[ii].fa, sc[ii].fb,  end));
    if (sc[ii].fb == end)
    {
      head = sc[ii].fa;
      for (jj = 0; jj < sci; jj++)
      {
        DP_INFO((TEXT("B check %d->%d with %d"), sc[jj].fa, sc[jj].fb,  sc[ii].fa));
        if ((sc[ii].fa == sc[jj].fb) && (sc[ii].fa != -1))
        {
          DP_INFO((TEXT("%d"), sc[jj].fb));
          chain[(*ccnt)++] = sc[jj].fb;
          return rchain(sc[jj].fb, sc, sci, chain, ccnt);
        }
      }
    }
  }
  chain[(*ccnt)++] = head;
  DP_INFO((TEXT("%d is head"), head));
  return head;
}


HRESULT CPropertyDlg::EnumFilters(IFilterGraph *pGraph, LVITEM *item, HDC hdc, SIZE *size, LONG *cx) 
{
  IEnumFilters *pEnum = NULL;
  IBaseFilter *pFilter;
  ULONG cFetched;
  int ii, filt_count = 0;
  int jj, fci, sci;
  f_connections fc[MAX_FILTS * MAX_PINS];
  f_connections sc[2*MAX_FILTS];
  int chains[MAX_PINS][MAX_FILTS];
  int orphan_count = 0;
  int orphans[MAX_FILTS];

  memset(filters_to_show, 0, sizeof(filters_to_show));

  HRESULT hr = pGraph->EnumFilters(&pEnum);
  if (FAILED(hr)) 
    return hr;

  while (pEnum->Next(1, &pFilter, &cFetched) == S_OK)
  {
    FILTER_INFO FilterInfo;
    IEnumPins *pEnumPins;
    hr = pFilter->QueryFilterInfo(&FilterInfo);
    if (FAILED(hr))
    {
      DP_WARNING((TEXT("CPropertyDlg::EnumFilters   Could not get the filter info, trying the next one")));
      continue;  // Maybe the next one will work.
    }

    filters_to_show[filt_count].pincount = 0;
    if (SUCCEEDED(hr = pFilter->EnumPins(&pEnumPins)))
    {
      IPin *tpin;
      while (pEnumPins->Next(1, &tpin, 0) == NOERROR)
      {
        PIN_INFO tpininfo;
        tpin->QueryPinInfo(&tpininfo);
        if (tpininfo.pFilter)
          tpininfo.pFilter->Release();   //QueryPinInfo adds a reference to the filter.

        filters_to_show[filt_count].pininfo[filters_to_show[filt_count].pincount] = tpininfo;
        filters_to_show[filt_count].pin[filters_to_show[filt_count].pincount] = tpin;
        hr = tpin->ConnectedTo(&filters_to_show[filt_count].connectedpin[filters_to_show[filt_count].pincount]);
        if (FAILED(hr))
        {
          filters_to_show[filt_count].connectedpin[filters_to_show[filt_count].pincount] = NULL;
          filters_to_show[filt_count].pintype[filters_to_show[filt_count].pincount] = -1;
          DP_INFO((TEXT("EnumFilters %d Pin %d Name: %s, direction %d NOT CONNECTED"), filt_count, filters_to_show[filt_count].pincount, tpininfo.achName, tpininfo.dir));
        }
        else
        {
          DP_INFO((TEXT("EnumFilters %d Pin %d Name: %s, direction %d connected"), filt_count, filters_to_show[filt_count].pincount, tpininfo.achName, tpininfo.dir));
          if (tpininfo.dir == PINDIR_INPUT)
          {
            filters_to_show[filt_count].pintype[filters_to_show[filt_count].pincount] = 0;
            DP_INFO((TEXT("EnumFilters %d Input Pin %d Name: %s, direction %d "), filt_count, filters_to_show[filt_count].pincount, tpininfo.achName, tpininfo.dir));
          }
          else if (tpininfo.dir == PINDIR_OUTPUT)
          {
            filters_to_show[filt_count].pintype[filters_to_show[filt_count].pincount] = 1;
            DP_INFO((TEXT("EnumFilters %d Output Pin %d Name: %s, direction %d "), filt_count, filters_to_show[filt_count].pincount, tpininfo.achName, tpininfo.dir));
          }
          else
          {
            filters_to_show[filt_count].pintype[filters_to_show[filt_count].pincount] = 2;
            DP_INFO((TEXT("EnumFilters %d other Pin %d Name: %s, direction %d"), filt_count, filters_to_show[filt_count].pincount, tpininfo.achName, tpininfo.dir));
          }
        }
        filters_to_show[filt_count].pincount++;
      }
      pEnumPins->Release(); // release to dec ref count
    }

    _stprintf(filters_to_show[filt_count].fname, TEXT("%d %s, pins %d"), filt_count, FilterInfo.achName, filters_to_show[filt_count].pincount);

    DP_INFO((TEXT("EnumFilters (%d at %d, %d) Filter %s "), m_itemNumber, *cx, size->cx, item->pszText));
    DP_INFO((TEXT("EnumFilters Filter %s "),item->pszText));
    item->iItem = m_itemNumber;
    item->pszText = filters_to_show[filt_count].fname;
    //item->pszText = FilterInfo.achName;
    if ( ListView_InsertItem( m_hListView, item ) != -1 )
      m_itemNumber++;
    if (GetTextExtentExPoint(hdc, item->pszText, _tcslen(item->pszText), 0, NULL, NULL, size) && size->cx > *cx)
      *cx = size->cx;

    // The FILTER_INFO structure holds a pointer to the Filter Graph
    // Manager, with a reference count that must be released.
    if (FilterInfo.pGraph != NULL)
    {
        FilterInfo.pGraph->Release();
    }
    pFilter->Release();
    filt_count++;
  }

  /* find the connections */
  for (fci = 0, ii = 0; ii < MAX_FILTS; ii++)
  {
    int kk, ll;
    for (jj = 0; jj < filters_to_show[ii].pincount; jj++)
    {
      if (filters_to_show[ii].pin[jj])
      {
         for (kk = 0; kk < MAX_FILTS; kk++)
         {
           for (ll = 0; ll < MAX_PINS; ll++)
           {
             if ((filters_to_show[kk].pin[ll] != NULL) && (filters_to_show[ii].connectedpin[jj] == filters_to_show[kk].pin[ll]))
             {
               DP_INFO((TEXT("EnumFilters %s connected to %s"),  filters_to_show[ii].fname, filters_to_show[kk].fname));
               fc[fci].fa = kk;
               fc[fci].fb = ii;
               fc[fci].direction = filters_to_show[ii].pintype[jj];
               fci++;
             }
           }
         }
      }
    }
  }

  /* just use the output direction */
  for (sci = 0, ii = 0; ii < fci; ii++)
  {
    if (fc[ii].direction == 1)
    {
      sc[sci].fa = fc[ii].fb;
      sc[sci].fb = fc[ii].fa;
      sc[sci].direction = 1;
      sci++;
      DP_INFO((TEXT("%d -> %d    sci %d"), fc[ii].fb, fc[ii].fa, sci));
    }
  }

  /* sort */    
  {
    /* first find the nodes that have an input but no output */
    int end[MAX_FILTS];
    int iend;
    int ccnt;

    for (jj = 0; jj < sci; jj++)
    {
      if (num_connected_pins(&filters_to_show[jj]) == 0) // orphan node
      {
        end[jj] = -1;
        orphans[orphan_count++] = jj;
        DP_INFO((TEXT("node %d is an orphan"), jj));
      }
      else
        end[jj] = 0;
    }

    /* find nodes that are an end */
    for (iend = 0, ii = 0; ii < sci; ii++)
    {
      for (jj = 0; jj < sci; jj++)
      {
        if (sc[ii].fb == sc[jj].fa) // then not an end
        {
          end[sc[ii].fb]++;
        }
      }
    }

    for (jj = 0; jj < sci; jj++)
    {
      /* traverse each chain starting with an end */
      if (end[jj] == 0) // means that is is an end
      {
        wchar_t ss[256] = TEXT("");
        wchar_t ff[16];
        DP_INFO((TEXT("node %d is an end, make its chain"), jj));
        chains[jj][0] = jj;  // the end node number
        ccnt = 1; 
        rchain(jj, sc, sci, chains[jj], &ccnt);
        for (ii = ccnt - 1;  ii >= 0; ii--)
        {

          if (ii > 0)
            _stprintf(ff, TEXT("%d->"), chains[jj][ii]);
          else
            _stprintf(ff, TEXT("%d"), chains[jj][ii]);

          DP_INFO((TEXT("%d ->      %d"),  chains[jj][ii],   ii));
          wcscat(ss, ff);
        }
        if (orphan_count)
        {
          int kk;
          _stprintf(ff, TEXT("   orphan"));
          wcscat(ss, ff);
          for (kk = 0; kk < orphan_count; kk++)
          {
            _stprintf(ff, TEXT(" %d"), orphans[kk]);
            wcscat(ss, ff);
          }
        }
        DP_INFO((TEXT("%s"), ss));
        item->iItem = m_itemNumber;
        item->pszText = ss;
        if ( ListView_InsertItem( m_hListView, item ) != -1 )
          m_itemNumber++;
        if (GetTextExtentExPoint(hdc, item->pszText, _tcslen(item->pszText), 0, NULL, NULL, size) && size->cx > *cx)
          *cx = size->cx;
      }
    }
  }

  /* decrement pin reference counts */
  for (ii = 0; ii < MAX_FILTS; ii++)
  {
    for (jj = 0; jj < filters_to_show[ii].pincount; jj++)
    {
      if (filters_to_show[ii].pin[jj])
      {
        filters_to_show[ii].pin[jj]->Release();
        filters_to_show[ii].pin[jj] = NULL;
      }
      if (filters_to_show[ii].connectedpin[jj])
      {
        filters_to_show[ii].connectedpin[jj]->Release();
        filters_to_show[ii].connectedpin[jj] = NULL;
      }
    }
  }

  pEnum->Release();
  return S_OK;
}

HRESULT CPropertyDlg::GraphInfo(LVITEM *item, HDC hdc, SIZE *size, LONG *cx)
{
  CComPtr<IFileSourceFilter> src;
  HRESULT hResult       = E_FAIL;
  IActiveMovie *pAM     = NULL;
  IFilterGraph *pFG     = NULL;

  item->iItem = m_itemNumber;
  item->pszText = L"Filters in current graph:";
  if ( ListView_InsertItem( m_hListView, item ) != -1 )
    m_itemNumber++;
  if (GetTextExtentExPoint(hdc, item->pszText, _tcslen(item->pszText), 0, NULL, NULL, size) && size->cx > *cx)
    *cx = size->cx;

  if (SUCCEEDED(g_pPlayerWindow->m_pUnk->QueryInterface(IID_IActiveMovie, reinterpret_cast<LPVOID*>(&pAM))))
  {
    if (SUCCEEDED(pAM->get_FilterGraph(reinterpret_cast<IUnknown**>(&pFG))))
    {
      hResult = EnumFilters(pFG, item, hdc, size, cx); 
      pFG->Release();
      pFG = NULL;
    }
      
    pAM->Release();
    pAM = NULL;
  }
  return hResult;
}

///////////////////////////////////////////////////////////////////////////////
// Name: CPropertyDlg::Update()
// Desc: This function is called when the dialog receives a PD_UPDATE message.
//       It then updates the filename and filters in the dialog.
///////////////////////////////////////////////////////////////////////////////
void CPropertyDlg::Update(TCHAR *szFilename)
{
    IBasicAudio           * piba  = NULL;
    IAMNetShowExProps     * pnsep = NULL;
    IAMSecureMediaContent * psmc  = NULL;

    SIZE size;
    LONG cx = 0;
    HDC  hdc;

    hdc = ::GetDC(m_hListView);

    g_pPlayerWindow->FindInterfaceOnGraph(IID_IBasicAudio,           (void**)&piba);
    g_pPlayerWindow->FindInterfaceOnGraph(IID_IAMNetShowExProps,     (void**)&pnsep);
    g_pPlayerWindow->FindInterfaceOnGraph(IID_IAMSecureMediaContent, (void**)&psmc);

    ListView_DeleteAllItems( m_hListView );

    BSTR property = NULL;
    LVITEM item;
    m_itemNumber = 0;
    item.mask = LVIF_TEXT;
    item.iSubItem = 0;
    item.state = 0;
    item.stateMask = 0;


    if (SUCCEEDED( GraphInfo(  &item, hdc, &size, &cx)))
    {
      DP_INFO((TEXT("CPropertyDlg::Update GraphInfo succeeded")));
    }

    // Fill in our Show Title
    g_pPlayerWindow->m_pMP->GetMediaInfoString( mpShowTitle, &property );
    if ( property )
    {
        if ( *property )
        {
            item.iItem = m_itemNumber;
            item.pszText = L"Show Title:";
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = m_itemNumber;
            item.pszText = property;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }
        SysFreeString(property);
        property = NULL;
    }

    // Fill in our Show Author
    g_pPlayerWindow->m_pMP->GetMediaInfoString( mpShowAuthor, &property );
    if ( property )
    {
        if ( *property )
        {
            item.iItem = m_itemNumber;
            item.pszText = L"Show Author:";
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = m_itemNumber;
            item.pszText = property;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }
        SysFreeString(property);
        property = NULL;
    }

    // Fill in our Show Copyright
    g_pPlayerWindow->m_pMP->GetMediaInfoString( mpShowCopyright, &property );
    if ( property )
    {
        if ( *property )
        {
            item.iItem = m_itemNumber;
            item.pszText = L"Show Copyright:";
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = m_itemNumber;
            item.pszText = property;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }
        SysFreeString(property);
        property = NULL;
    }

    // Fill in our Clip Title
    g_pPlayerWindow->m_pMP->GetMediaInfoString( mpClipTitle, &property );
    if ( property )
    {
        if ( *property )
        {
            item.iItem = m_itemNumber;
            item.pszText = L"Clip Title:";
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = m_itemNumber;
            item.pszText = property;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }
        SysFreeString(property);
        property = NULL;
    }

    // Fill in our Clip Artist
    g_pPlayerWindow->m_pMP->GetMediaInfoString( mpClipAuthor, &property );
    if ( property )
    {
        if ( *property )
        {
            item.iItem = m_itemNumber;
            item.pszText = L"Clip Artist:";
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = m_itemNumber;
            item.pszText = property;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }
        SysFreeString(property);
        property = NULL;
    }

    // Fill in our Clip Description
    g_pPlayerWindow->m_pMP->GetMediaInfoString( mpClipDescription, &property );
    if ( property )
    {
        if ( *property )
        {
            item.iItem = m_itemNumber;
            item.pszText = L"Clip Album:"; // The mpClipDescription maps to IAMMediaContent internally.  On CE 4.2, we override
                                        // the "description" field to be Album information (from ID3 or ASF metadata).  So
                                        // let's call this what it usually is - Clip Album, not Clip Description.
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = m_itemNumber;
            item.pszText = property;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }
        SysFreeString(property);
        property = NULL;
    }

    // Fill in our Clip Copyright
    g_pPlayerWindow->m_pMP->GetMediaInfoString( mpClipCopyright, &property );
    if ( property )
    {
        if ( *property )
        {
            item.iItem = m_itemNumber;
            item.pszText = L"Clip Copyright:";
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = m_itemNumber;
            item.pszText = property;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }
        SysFreeString(property);
        property = NULL;
    }

    g_pPlayerWindow->m_pMP->get_FileName( &property );
    if ( property )
    {
        if ( *property )
        {
            // Fill in our filename
            item.iItem = m_itemNumber;
            item.pszText = L"Filename:";
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            TCHAR *slash = wcsrchr( property, L'\\' );
            item.iItem = m_itemNumber;
            item.pszText = slash ? ++slash : property;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }
    }
    // Fill in our duration
    double duration = 0.0;
    VARIANT_BOOL fDurationValid;

    g_pPlayerWindow->m_pMP->get_Duration( &duration );
        g_pPlayerWindow->m_pMP->get_IsDurationValid(&fDurationValid);

    if ( fDurationValid && duration != 0.0 )
    {
        WCHAR durationText[10] = L"";
        Time2String( duration, durationText, 10, FALSE, FALSE, L":", L"." );

        item.iItem = m_itemNumber;
        item.pszText = L"Duration:";
        if ( ListView_InsertItem( m_hListView, &item ) != -1 )
            m_itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        item.iItem = m_itemNumber;
        item.pszText = durationText;
        if ( ListView_InsertItem( m_hListView, &item ) != -1 )
            m_itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;
    }

    // Fill in our audio-specific information
    AUDIOINFO audioInfo;
    memset( &audioInfo, 0, sizeof( AUDIOINFO ) );
    if ( SUCCEEDED( AudioInfo( &audioInfo, piba, pnsep, psmc ) ) )
    {
        // Codec description
        if ( audioInfo.bstrCodecDescription && *audioInfo.bstrCodecDescription )
        {
            item.iItem = m_itemNumber;
            item.pszText = L"Audio Codec:";
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = m_itemNumber;
            item.pszText = audioInfo.bstrCodecDescription;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
                          
            SysFreeString(audioInfo.bstrCodecDescription);
        }

        // audio bitrate
        if ( audioInfo.lpwcCodecBitrate && *audioInfo.lpwcCodecBitrate )
        {
            item.iItem = m_itemNumber;
            item.pszText = L"Audio Bitrate:";
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = m_itemNumber;
            item.pszText = audioInfo.lpwcCodecBitrate;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            delete [] audioInfo.lpwcCodecBitrate;
        }

        // What's the frequency, Kenneth?
        WCHAR frequency[8];
        if ( audioInfo.wfmtWaveFormat.nSamplesPerSec )
        {
            StringCchPrintf(frequency, 8, L"%2.1fKHz", (float)(audioInfo.wfmtWaveFormat.nSamplesPerSec) / 1000.0 );

            item.iItem = m_itemNumber;
            item.pszText = L"Audio Frequency:";
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = m_itemNumber;
            item.pszText = frequency;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }

        WCHAR stereo[8];
        if ( audioInfo.wfmtWaveFormat.nChannels )
        {
            StringCchPrintf(stereo, 4, L"%d", audioInfo.wfmtWaveFormat.nChannels );
            //StringCchCopy(stereo, 4, audioInfo.wfmtWaveFormat.nChannels > 1 ? L"Yes" : L"No" );

            item.iItem = m_itemNumber;
            item.pszText = L"Audio channels:";
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = m_itemNumber;
            item.pszText = stereo;
            if ( ListView_InsertItem( m_hListView, &item ) != -1 )
                m_itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }
    }

    // Fill in our video-codec information
    BSTR videoCodec = NULL;
    if ( SUCCEEDED( VideoInfo( &videoCodec, pnsep ) ) )
    {
        item.iItem = m_itemNumber;
        item.pszText = L"Video Codec:";
        if ( ListView_InsertItem( m_hListView, &item ) != -1 )
            m_itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        item.iItem = m_itemNumber;
        item.pszText = videoCodec;
        if ( ListView_InsertItem( m_hListView, &item ) != -1 )
            m_itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        SysFreeString(videoCodec);
    }

    // Fill in our video resolution
    long lWidth, lHeight;
    WCHAR resolution[10] = L"";
    if ( SUCCEEDED( g_pPlayerWindow->m_pMP->get_ImageSourceWidth( &lWidth ) ) &&
        SUCCEEDED( g_pPlayerWindow->m_pMP->get_ImageSourceHeight( &lHeight ) ) &&
        lWidth && lHeight )
    {
        StringCchPrintf(resolution, 10, L"%d x %d", lWidth, lHeight );

        item.iItem = m_itemNumber;
        item.pszText = L"Video Size:";
        if ( ListView_InsertItem( m_hListView, &item ) != -1 )
            m_itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        item.iItem = m_itemNumber;
        item.pszText = resolution;
        if ( ListView_InsertItem( m_hListView, &item ) != -1 )
            m_itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;
    }

    // Fill in our "protected" information
    item.iItem = m_itemNumber;
    item.pszText = L"Protected:";
    if ( ListView_InsertItem( m_hListView, &item ) != -1 )
        m_itemNumber++;

    if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size) && size.cx > cx)
        cx = size.cx;

    item.iItem = m_itemNumber;
    item.pszText = audioInfo.bSecure ? L"Yes" : L"No";
    if ( ListView_InsertItem( m_hListView, &item ) != -1 )
        m_itemNumber++;
    if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size) && size.cx > cx)
        cx = size.cx;

    // Tidy up the ListView...
    if (hdc)
    {
        ::ReleaseDC(m_hListView, hdc);
    }

    // First, check if our ListView is too tall...
    RECT rc;
    LONG width;

    GetClientRect(m_hListView, &rc);

    width = rc.right - rc.left;

    if (ListView_GetCountPerPage(m_hListView) < ListView_GetItemCount(m_hListView))
    {
        width -= GetSystemMetrics(SM_CXVSCROLL);
    }

    if (cx < width)
    {
        cx = width;
    }

    ListView_SetColumnWidth(m_hListView, 0, cx);

    SendMessage(m_hListView, WM_SETREDRAW, TRUE, 0);

    InvalidateRect(m_hListView, NULL, TRUE);

    if (NULL != piba)
    {
        piba->Release();
        piba = NULL;
    }

    if (NULL != pnsep)
    {
        pnsep->Release();
        pnsep = NULL;
    }

    if (NULL != psmc)
    {
        psmc->Release();
        psmc = NULL;
    }
}

void CPropertyDlg::UpdateAndRender(TCHAR * szFilename)
{
    IGraphBuilder   * pGraphBuilder = NULL;
    IAMMediaContent * pMediaContent = NULL;
    IEnumFilters    * pEnum         = NULL;
    IBaseFilter     * pFilter       = NULL;
    IBasicAudio           * piba    = NULL;
    IBasicVideo           * pibv    = NULL;
    IAMNetShowExProps     * pnsep   = NULL;
    IAMSecureMediaContent * psmc    = NULL;
    IMediaSeeking         * pims    = NULL;
    BSTR              property      = ::SysAllocString(L"");
    int               itemNumber    = 0;
    LVITEM            item;
    HRESULT           hr            = S_OK;

    SIZE size;
    LONG cx = 0;
    HDC  hdc;

    hdc = ::GetDC(m_hListView);

    item.mask      = LVIF_TEXT;
    item.iSubItem  = 0;
    item.state     = 0;
    item.stateMask = 0;

    ListView_DeleteAllItems(m_hListView);

    //
    // Render file
    //

    HCURSOR hPrevCursor;

    // Display an hour glass while rendering the file
    hPrevCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));

    hr = CoCreateInstance(CLSID_FilterGraph,
                          NULL,
                          CLSCTX_INPROC_SERVER,
                          IID_IGraphBuilder,
                          (void**)&pGraphBuilder);

    if (SUCCEEDED(hr))
    {
        hr = pGraphBuilder->RenderFile(szFilename, NULL);
    }

    //
    // Get IAMMediaContent interface
    //

    if (SUCCEEDED(hr))
    {
         hr = pGraphBuilder->EnumFilters(&pEnum);
    }

    if (NULL != pEnum)
    {
        hr = E_NOINTERFACE;

        while ( ( NULL == pMediaContent
                  || NULL == piba
                  || NULL == pnsep
                  || NULL == psmc )
               && S_OK == pEnum->Next(1, &pFilter, NULL))
        {
            if (NULL == pMediaContent)
                pFilter->QueryInterface(IID_IAMMediaContent,       (void**)&pMediaContent);
            if (NULL == piba)
                pFilter->QueryInterface(IID_IBasicAudio,           (void**)&piba);
            if (NULL == pibv)
                pFilter->QueryInterface(IID_IBasicVideo,           (void**)&pibv);
            if (NULL == pnsep)
                pFilter->QueryInterface(IID_IAMNetShowExProps,     (void**)&pnsep);
            if (NULL == psmc)
                pFilter->QueryInterface(IID_IAMSecureMediaContent, (void**)&psmc);
            if (NULL == pims)
                pFilter->QueryInterface(IID_IMediaSeeking,         (void**)&pims);

            pFilter->Release();
            pFilter = NULL;
        }

        pEnum->Release();
        pEnum = NULL;
    }

    // Restore the old cursor
    SetCursor(hPrevCursor);
 
    //
    // Display info
    //

    // Clip Title
    if (pMediaContent)
    {
        pMediaContent->get_Title(&property);
    }

    if (*property)
    {
        item.iItem   = itemNumber;
        item.pszText = L"Clip Title:";
        if (ListView_InsertItem(m_hListView, &item) != -1)
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        item.iItem   = itemNumber;
        item.pszText = property;
        if (ListView_InsertItem(m_hListView, &item) != -1)
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        SysFreeString(property);
    }
 
    // Clip Author
    if (pMediaContent)
    {
        property = (TCHAR *)L"";
        pMediaContent->get_AuthorName(&property);
    }

    if (*property)
    {
        item.iItem   = itemNumber;
        item.pszText = L"Clip Artist:";
        if (ListView_InsertItem(m_hListView, &item) != -1)
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        item.iItem   = itemNumber;
        item.pszText = property;
        if (ListView_InsertItem(m_hListView, &item) != -1)
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        SysFreeString(property);
    }

    // Clip Description
    if (pMediaContent)
    {
        property = (TCHAR *)L"";
        pMediaContent->get_Description(&property);
    }

    if (*property)
    {
        item.iItem   = itemNumber;
        item.pszText = L"Clip Album:";

        if (ListView_InsertItem(m_hListView, &item) != -1)
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        item.iItem   = itemNumber;
        item.pszText = property;
        if (ListView_InsertItem(m_hListView, &item) != -1)
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        SysFreeString(property);
    }

    // Clip Copyright
    if (pMediaContent)
    {
        property = (TCHAR *)L"";
        pMediaContent->get_Copyright(&property);
    }

    if (*property)
    {
        item.iItem   = itemNumber;
        item.pszText = L"Clip Copyright:";
        if (ListView_InsertItem(m_hListView, &item) != -1)
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        item.iItem   = itemNumber;
        item.pszText = property;
        if (ListView_InsertItem(m_hListView, &item) != -1)
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        SysFreeString(property);
    }

    // Filename
    item.iItem   = itemNumber;
    item.pszText = L"Filename:";
    if (ListView_InsertItem(m_hListView, &item) != -1)
        itemNumber++;

    if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
        && size.cx > cx)
        cx = size.cx;

    TCHAR * slash = wcsrchr(szFilename, L'\\');
    item.iItem   = itemNumber;
    item.pszText = slash ? ++slash : szFilename;
    if (ListView_InsertItem(m_hListView, &item) != -1)
        itemNumber++;

    if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
        && size.cx > cx)
        cx = size.cx;

    // duration
    if (NULL != pims)
    {
        double   dDuration  = 0.0;
        LONGLONG llDuration = 0;

        pims->GetDuration(&llDuration);

        if (llDuration)
        {
            WCHAR durationText[10] = L"";

            dDuration = llDuration / 1E7;

            Time2String(dDuration, durationText, 10, FALSE, FALSE, L":", L".");

            item.iItem = itemNumber;
            item.pszText = L"Duration:";
            if (-1 != ListView_InsertItem(m_hListView, &item))
                itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = itemNumber;
            item.pszText = durationText;
            if (-1 != ListView_InsertItem(m_hListView, &item))
                itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }
    }

    // audio info
    AUDIOINFO audioInfo;
    memset(&audioInfo, 0, sizeof (AUDIOINFO));
    if (SUCCEEDED(AudioInfo(&audioInfo, piba, pnsep, psmc)))
    {
        // codec description
        if (audioInfo.bstrCodecDescription && *audioInfo.bstrCodecDescription)
        {
            item.iItem = itemNumber;
            item.pszText = L"Audio Codec:";
            if (-1 != ListView_InsertItem(m_hListView, &item))
                itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = itemNumber;
            item.pszText = audioInfo.bstrCodecDescription;
            if (-1 != ListView_InsertItem(m_hListView, &item))
                itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            SysFreeString(audioInfo.bstrCodecDescription);
        }

        // audio bitrate
        if (audioInfo.lpwcCodecBitrate && *audioInfo.lpwcCodecBitrate)
        {
            item.iItem = itemNumber;
            item.pszText = L"Audio Bitrate:";
            if (-1 != ListView_InsertItem(m_hListView, &item))
                itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = itemNumber;
            item.pszText = audioInfo.lpwcCodecBitrate;
            if (-1 != ListView_InsertItem(m_hListView, &item))
                itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            delete [] audioInfo.lpwcCodecBitrate;
        }

        // What's the frequency, Kenneth?
        WCHAR frequency[8];
        if (audioInfo.wfmtWaveFormat.nSamplesPerSec)
        {
            StringCchPrintf( frequency, 8, L"%2.1fKHz", (float)(audioInfo.wfmtWaveFormat.nSamplesPerSec) / 1000.0);

            item.iItem = itemNumber;
            item.pszText = L"Audio Frequency:";
            if (-1 != ListView_InsertItem(m_hListView, &item))
                itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = itemNumber;
            item.pszText = frequency;
            if (-1 != ListView_InsertItem(m_hListView, &item))
                itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }

        // stero or mono sound?
        WCHAR stereo[4];
        if (audioInfo.wfmtWaveFormat.nChannels)
        {
            if (audioInfo.wfmtWaveFormat.nChannels > 1)
                StringCchPrintf( stereo, 4, L"Yes");
            else
                StringCchPrintf( stereo, 4, L"No");

            item.iItem = itemNumber;
            item.pszText = L"Stereo:";
            if (-1 != ListView_InsertItem(m_hListView, &item))
                itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;

            item.iItem = itemNumber;
            item.pszText = stereo;
            if (-1 != ListView_InsertItem(m_hListView, &item))
                itemNumber++;

            if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
                && size.cx > cx)
                cx = size.cx;
        }
    }

    // video info
    BSTR videoCodec = NULL;
    if (SUCCEEDED(VideoInfo(&videoCodec, pnsep)))
    {
        item.iItem = itemNumber;
        item.pszText = L"Video Codec:";
        if (-1 != ListView_InsertItem(m_hListView, &item))
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        item.iItem = itemNumber;
        item.pszText = videoCodec;
        if (-1 != ListView_InsertItem(m_hListView, &item))
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        SysFreeString(videoCodec);
    }

    // video resolution
    long lWidth, lHeight;
    WCHAR resolution[10] = L"";
    if (NULL != pibv
        && SUCCEEDED(pibv->get_VideoWidth(&lWidth))
        && SUCCEEDED(pibv->get_VideoHeight(&lHeight))
        && lWidth && lHeight)
    {
        StringCchPrintf( resolution, 10, L"%d x %d", lWidth, lHeight);

        item.iItem = itemNumber;
        item.pszText = L"Video Size:";
        if (-1 != ListView_InsertItem(m_hListView, &item))
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;

        item.iItem = itemNumber;
        item.pszText = resolution;
        if (-1 != ListView_InsertItem(m_hListView, &item))
            itemNumber++;

        if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
            && size.cx > cx)
            cx = size.cx;
    }

    // protected
    item.iItem = itemNumber;
    item.pszText = L"Protected:";
    if (-1 != ListView_InsertItem(m_hListView, &item))
        itemNumber++;

    if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
        && size.cx > cx)
        cx = size.cx;

    item.iItem = itemNumber;
    item.pszText = audioInfo.bSecure ? L"Yes" : L"No";
    if (-1 != ListView_InsertItem(m_hListView, &item))
        itemNumber++;

    if (GetTextExtentExPoint(hdc, item.pszText, _tcslen(item.pszText), 0, NULL, NULL, &size)
        && size.cx > cx)
        cx = size.cx;

    if (hdc)
    {
        ::ReleaseDC(m_hListView, hdc);
    }

    // Clean up list view
    RECT rc;
    LONG width;

    GetClientRect(m_hListView, &rc);

    width = rc.right - rc.left;

    if (ListView_GetCountPerPage(m_hListView) < ListView_GetItemCount(m_hListView))
    {
        width -= GetSystemMetrics(SM_CXVSCROLL);
    }

    if (cx < width)
    {
        cx = width;
    }

    ListView_SetColumnWidth(m_hListView, 0, cx);

    SendMessage(m_hListView, WM_SETREDRAW, TRUE, 0);

    InvalidateRect(m_hListView, NULL, TRUE);

    // Release filter interfaces
    if (NULL != pMediaContent)
    {
        pMediaContent->Release();
        pMediaContent = NULL;
    }

    if (NULL != piba)
    {
        piba->Release();
        piba = NULL;
    }

    if (NULL != pibv)
    {
        pibv->Release();
        pibv = NULL;
    }

    if (NULL != pnsep)
    {
        pnsep->Release();
        pnsep = NULL;
    }

    if (NULL != psmc)
    {
        psmc->Release();
        psmc = NULL;
    }

    if (NULL != pims)
    {
        pims->Release();
        pims = NULL;
    }

    // Release IGraphBuilder
    if (NULL != pGraphBuilder)
    {
         pGraphBuilder->Release();
         pGraphBuilder = NULL;
    }
    ::SysFreeString( property );
}

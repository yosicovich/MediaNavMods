#include "PlayerWindow.h"

extern HWND g_hwndAvSettings;

// Returns number of elements
#define dim(x) (sizeof(x) / sizeof(x[0]))

//----------------------------------------------------------------------
// Generic defines and data types
//
struct decodeUINT {                             // Structure associates
    UINT Code;                                  // messages
                                                // with a function.
    LRESULT (*Fxn)(HWND, UINT, WPARAM, LPARAM);
};
struct decodeCMD {                              // Structure associates
    UINT Code;                                  // menu IDs with a
    LRESULT (*Fxn)(HWND, WORD, HWND, WORD);     // function.
};

//----------------------------------------------------------------------
// Program-specific structures
//
typedef struct 
{
    TCHAR *pszLabel;
    DWORD wNotification;
} NOTELABELS, *PNOTELABELS;

// Dialog box procedures
BOOL CALLBACK AudioPageDlgProc (HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK VideoPageDlgProc (HWND, UINT, WPARAM, LPARAM);

extern void ReapplyAudioPageSettings(void);


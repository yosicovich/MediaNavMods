
#include <windows.h>                 // For all that Windows stuff
#include <commctrl.h>                // Common Control includes
#include <prsht.h>                   // Property sheet includes
#include "AvPageDlg.h"                 // Program-specific stuff
#include "resource.h"
#include "debug.h"

#include "IVrend.h"
#include "AuMedia.h"

extern IVrend *g_pVrend;
extern int Prev_trackbar;

IAuDecoder *g_pVDecoder = NULL;


BOOL GetVrendInterface(void)
{
  if (!g_pPlayerWindow)
    return FALSE;

  g_pPlayerWindow->FindInterfaceOnGraph(IID_IVrend, (void**)&g_pVrend);
  
  if (!g_pVrend)
      return FALSE;

  return TRUE;
}

BOOL GetVDecoderInterface(void)
{
  if (!g_pPlayerWindow)
    return FALSE;

  g_pPlayerWindow->FindInterfaceOnGraph(IID_IAuDecoder, (void**)&g_pVDecoder);
  
  if (!g_pVDecoder)
      return FALSE;

  return TRUE;
}

void SetVideoOff(BOOL bMode)
{
  if (!g_pVDecoder)
  {
    if (!GetVDecoderInterface())
    {
      DP_ERROR((TEXT("ERROR: cannot get VDecoder interface")));
      return;
    }
  }

  if (bMode)
  {
	  g_pVDecoder->ToggleVideo(FALSE);
  }
  else
  {
	  g_pVDecoder->ToggleVideo(TRUE);
  }
}

void SetGamma(ULONG nVal)
{
  if (!g_pVrend)
    if (!GetVrendInterface())
    {
      DP_ERROR((TEXT("ERROR: cannot get Vrend interface")));
      return;
    }
  if (FAILED(g_pVrend->SetGamma(nVal) ))
    DP_ERROR((TEXT("Failed SetGamma(%d)"), nVal));       
}

void SetAvSyncMode(ULONG nVal)
{
  if (!g_pVrend)
    if (!GetVrendInterface())
    {
      DP_ERROR((TEXT("ERROR: cannot get Vrend interface")));
      return;
    }
  if (FAILED(g_pVrend->SetAvSyncMode(nVal) ))
    DP_ERROR((TEXT("Failed SetAvSyncMode(%d)"), nVal));       
}

void SetDeinterlace(ULONG nVal)
{
  if (!g_pVrend)
    if (!GetVrendInterface())
    {
      DP_ERROR((TEXT("ERROR: cannot get Vrend interface")));
      return;
    }
  if (FAILED(g_pVrend->SetDeinterlaceMode(nVal) ))
    DP_ERROR((TEXT("Failed SetDeinterlace(%d)"), nVal));       
}

void SetRotationMode(ULONG nVal)
{
  if (!g_pVrend)
    if (!GetVrendInterface())
    {
      DP_ERROR((TEXT("ERROR: cannot get Vrend interface")));
      return;
    }
  if (FAILED(g_pVrend->SetRotationMode(nVal) ))
    DP_ERROR((TEXT("Failed SetRotate(%d)"), nVal));       
}

void SetDeblock(ULONG nVal)
{
  if (!g_pVrend)
    if (!GetVrendInterface())
    {
      DP_ERROR((TEXT("ERROR: cannot get Vrend interface")));
      return;
    }
  if (FAILED(g_pVrend->SetDeblockMode(nVal) ))
    DP_ERROR((TEXT("Failed SetDeblock(%d)"), nVal));       
}

//======================================================================
// VideoPageDlgProc - Button page dialog box procedure
//
BOOL CALLBACK VideoPageDlgProc (HWND hWnd, UINT wMsg, WPARAM wParam,
                          LPARAM lParam) {
  int i;
  switch (wMsg) {
  case WM_INITDIALOG:
    i = SendDlgItemMessage (hWnd, IDC_TRACKBAR_V, 
                                  TBM_SETRANGEMAX, 0, 33);
    i = SendDlgItemMessage (hWnd, IDC_TRACKBAR_V, 
                                  TBM_SETPOS, Prev_trackbar, Prev_trackbar);

		
    return TRUE;

  // WM_COMMAND messages handled by main window
  case WM_COMMAND:
    switch (LOWORD(wParam))
    {
    case IDC_ONSCREEN_STATS:
      i = SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
      SetVideoOff(i);
      return TRUE; // FALSE?

    case IDC_DISABLE_AVSYNC:
      i = SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
      SetAvSyncMode(i);
      return TRUE; // FALSE?

    case IDC_DEINTERLACE:
      i = SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
      SetDeinterlace(i);
      return TRUE; // FALSE?

    case IDC_DEBLOCK:
      i = SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
      SetDeblock(i);
      return TRUE; // FALSE?

      // here?
    case IDC_ROTATE0:
      if (SendMessage((HWND)lParam, BM_GETCHECK, 0, 0))
        SetRotationMode(0);
      return TRUE; // FALSE?
    case IDC_ROTATE1:
      if (SendMessage((HWND)lParam, BM_GETCHECK, 0, 0))
        SetRotationMode(1);
      return TRUE; // FALSE?
    case IDC_ROTATE2:
      if (SendMessage((HWND)lParam, BM_GETCHECK, 0, 0))
        SetRotationMode(2);
      return TRUE; // FALSE?
    case IDC_ROTATE3:
      if (SendMessage((HWND)lParam, BM_GETCHECK, 0, 0))
        SetRotationMode(3);
      return TRUE; // FALSE?

    }
    return TRUE;

  case WM_NOTIFY:
	{
	  LPNMHDR pnmh = (LPNMHDR)lParam;
		switch (pnmh->code)
		{
		case PSN_APPLY:
  		// OK button. Instead of applying the changes we just close the dialog box
			DestroyWindow(GetParent(hWnd));
			g_hwndAvSettings = NULL;
			break;
		case PSN_RESET:
      // X button. Close the dialog box
			DestroyWindow(GetParent(hWnd));
			g_hwndAvSettings = NULL;
			break;
		}
		return FALSE;
  }

  
  case WM_VSCROLL:
    // Get the position of the trackbar
    Prev_trackbar = i = SendDlgItemMessage (hWnd, IDC_TRACKBAR_V, TBM_GETPOS, 0, 0);
    SetGamma(i);
    return FALSE;

  case WM_HSCROLL:
    return FALSE;

  }
  return FALSE;
}


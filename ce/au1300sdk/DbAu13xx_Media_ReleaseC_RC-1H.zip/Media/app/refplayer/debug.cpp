// Debug statement routines 
//
// debug.cpp
//

#include <stdio.h>
#include <windows.h>
#include "debug.h"

void DebugPrintF(TCHAR *fmtstr, ...)
{
  TCHAR _pcTempTextW[256];
  TCHAR _pcTempTextWout[256];
  int len = 0;
  
  va_list argptr;
  va_start(argptr, fmtstr);
#ifdef UNDER_CE
  //len = vscwprintf(fmtstr, argptr)+1; //+1 for '\0'
  //vswprintf_s(_pcTempTextW, len, fmtstr, argptr);
  vswprintf(_pcTempTextW, fmtstr, argptr);
#else
  len = _vscprintf(fmtstr, argptr)+1; //+1 for '\0'
  vsprintf_s(_pcTempTextW, len, fmtstr, argptr);
#endif
  va_end(argptr);
#ifdef UNDER_CE
  _tcscpy(_pcTempTextWout, TEXT("REFPLAYER: "));
  _tcscat(_pcTempTextWout, _pcTempTextW);
  _tcscat(_pcTempTextWout, TEXT("\r\n"));
#else
  strcpy_s(_pcTempTextWout, TEXT("REFPLAYER: "));
  strcat_s(_pcTempTextWout, _pcTempTextW);
  strcat_s(_pcTempTextWout, TEXT("\r\n"));
#endif
  
  OutputDebugString(_pcTempTextWout);
}


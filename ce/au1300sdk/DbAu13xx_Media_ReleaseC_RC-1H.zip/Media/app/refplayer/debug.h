// Debug statement routines 
//
// debug.h
//

#ifndef __DEBUG__H
#define __DEBUG__H

void _cdecl DebugPrintF(TCHAR * szFormat, ...);

//Debug statements for Errors
#define DP_ERROR(msg)     DebugPrintF msg  // Error statements
#define DP_WARNING(msg)   DebugPrintF msg  // Warning statements

//main debugging statements
#define DP_FUNC(msg)      //DebugPrintF msg  //function calling statements
#define DP_INFO(msg)      //DebugPrintF msg  //Information statements
#define DP_STREAM(msg)    //DebugPrintF msg  //Stream Information statements
#define DP_RECONNECT(msg) //DebugPrintF msg  //Disconnect/reconnect/render statements
#define DP_POSITION(msg)  //DebugPrintF msg  //Position statements
#define DP_EQ(msg)        //DebugPrintF msg  //EQ debug statements
#define DP_ENCODE(msg)    DebugPrintF msg  //Audio Encode debug statements
#define DP_OUTPUT(msg)    //DebugPrintF msg  //output processing statements
#define DP_FLUSH(msg)     //DebugPrintF msg  //detailed Flushing statements

#endif // __DEBUG__H

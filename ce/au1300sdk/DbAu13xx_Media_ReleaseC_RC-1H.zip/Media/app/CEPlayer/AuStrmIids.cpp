#include <windows.h>
#include <initguid.h>
#include "AuMedia.h"
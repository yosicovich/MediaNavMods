#ifndef __DIVXPLAYER_H
#define __DIVXPLAYER_H

#include "DivXInterface.h"
#include "AuMedia.h"

class CDivXPlayer
{
private:
	HINSTANCE					m_hInstDivXLibrary;
	IDivXInterface				*m_pDivX;
	BYTE						m_RentalMessageFlag;
	BYTE						m_UseLimit;
	BYTE						m_UseCount;

	fnIsDeviceActivated_t		m_fnIsDeviceActivated;
	fnGetRegistrationCode_t		m_fnGetRegistrationCode;
	fnGetDeregistrationCode_t	m_fnGetDeregistrationCode;
	fnSetRandomSample_t			m_fnSetRandomSample;

protected:

public:
	CDivXPlayer();
	~CDivXPlayer();
	HRESULT LoadDivXInterface();
	HRESULT UnloadDivXInterface();
	HRESULT SetRandomSample();
	HRESULT PreparePlayback();
	HRESULT	CommitPlayback();
	HRESULT	FinalizePlayback();
	BOOL IsDeviceActivated();
	HRESULT GetRegistrationCode(TCHAR *);
	HRESULT GetDeregistrationCode(TCHAR *);

	BOOL IsRental() { return m_RentalMessageFlag; };
	BYTE GetUseCount() { return m_UseCount; };
	BYTE GetUseLimit() { return m_UseLimit; };
	void HandleDivXError(HWND hWndParent, HRESULT hResult);
};


#endif __DIVXPLAYER_H
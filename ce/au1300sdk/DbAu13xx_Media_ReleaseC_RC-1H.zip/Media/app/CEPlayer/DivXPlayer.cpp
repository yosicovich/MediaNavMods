#include <windows.h>

#include "playerwindow.h"

#include "DivXPlayer.h"

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
CDivXPlayer::CDivXPlayer()
{
	m_RentalMessageFlag = 0;
	m_UseLimit = 0;
	m_UseCount = 0;

	m_hInstDivXLibrary = NULL;
	m_fnGetRegistrationCode = NULL;
	m_fnGetDeregistrationCode = NULL;
	m_fnSetRandomSample = NULL;
	m_fnIsDeviceActivated = NULL;

	// Load the DLL.
	m_hInstDivXLibrary = LoadLibrary(TEXT("DivXInterface.dll"));

	if (NULL == m_hInstDivXLibrary)
	{
		DEBUGMSG(ZONE_ERROR, (TEXT("DivXPlayer: Failed to look DivX Interface library!!\r\n")));
	}

	// Load the functions we need for the player.
	m_fnSetRandomSample = (fnSetRandomSample_t) GetProcAddress(m_hInstDivXLibrary, TEXT("SetRandomSample"));
	if (NULL == m_fnSetRandomSample)
	{
		DWORD dwError = GetLastError();

		DEBUGMSG(ZONE_ERROR, (TEXT("DivXPlayer: Failed to get function  SetRandomSample %d\r\n"), dwError));
	}

	SetRandomSample();
	SetRandomSample();

	m_fnGetRegistrationCode = (fnGetRegistrationCode_t) GetProcAddress(m_hInstDivXLibrary, TEXT("GetDivXRegistrationCode"));
	if (NULL == m_fnGetRegistrationCode)
	{
		DWORD dwError = GetLastError();

		DEBUGMSG(ZONE_ERROR, (TEXT("DivXPlayer: Failed to get function  GetDivXRegistrationCode %d\r\n"), dwError));
	}

	SetRandomSample();
	SetRandomSample();

	m_fnIsDeviceActivated = (fnIsDeviceActivated_t) GetProcAddress(m_hInstDivXLibrary, TEXT("IsDeviceActivated"));
	if (NULL == m_fnIsDeviceActivated)
	{
		DWORD dwError = GetLastError();

		DEBUGMSG(ZONE_ERROR, (TEXT("DivXPlayer: Failed to get function  IsDeviceActivated %d\r\n"), dwError));
	}

	SetRandomSample();
	SetRandomSample();

	m_fnGetDeregistrationCode = (fnGetDeregistrationCode_t) GetProcAddress(m_hInstDivXLibrary, TEXT("GetDivXDeregistrationCode"));
	if (NULL == m_fnGetDeregistrationCode)
	{
		DWORD dwError = GetLastError();

		DEBUGMSG(ZONE_ERROR, (TEXT("DivXPlayer: Failed to get function GetDivXDeregistrationCode %d\r\n"), dwError));
	}

	SetRandomSample();
	SetRandomSample();
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
CDivXPlayer::~CDivXPlayer()
{
	// Unload the DLL.
	if (m_hInstDivXLibrary)
	{
		DEBUGMSG(ZONE_INFO, (TEXT("DivXPlayer: UNLOADED THE DIVX INTERFACE LIBRARY\r\n")));
		FreeLibrary(m_hInstDivXLibrary);
		m_hInstDivXLibrary = NULL;

		m_fnGetRegistrationCode = NULL;
		m_fnGetDeregistrationCode = NULL;
		m_fnSetRandomSample = NULL;

	}
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
HRESULT CDivXPlayer::LoadDivXInterface()
{
	// Load the DivX DShow Interface
	HRESULT hr = E_FAIL;
	int ReturnValue = 0;

	SetRandomSample();

	if (NULL == m_pDivX)
	{
		hr = g_pPlayerWindow->FindInterfaceOnGraph(IID_DivXInterface, (void **)&m_pDivX);

		if (FAILED(hr))
		{
			DEBUGMSG(ZONE_ERROR, (TEXT("Failed to get DivX interface!!!!\r\n")));
			ReturnValue = -1;
		}
	}

	SetRandomSample();

	return ReturnValue;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
HRESULT CDivXPlayer::UnloadDivXInterface()
{
	// Unload the DivX DShow Interface
	if (NULL != m_pDivX)
	{
		m_pDivX->Release();
		m_pDivX = NULL;
	}
	return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
HRESULT CDivXPlayer::SetRandomSample()
{
	HRESULT hResult = E_FAIL;

	if (m_fnSetRandomSample)
	{
		hResult = (* m_fnSetRandomSample)();
	}

	return hResult;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
HRESULT CDivXPlayer::PreparePlayback()
{
	HRESULT hResult;
	
	if (NULL == m_pDivX)
	{
		return E_FAIL;
	}

	SetRandomSample();


	hResult = m_pDivX->PrepareDivXPlayback(&m_RentalMessageFlag, &m_UseLimit, &m_UseCount);

	return hResult;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
HRESULT	CDivXPlayer::CommitPlayback()
{
	HRESULT hResult;

	if (NULL == m_pDivX)
	{
		return E_FAIL;
	}

	hResult = m_pDivX->CommitDivXPlayback();

	return hResult;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL CDivXPlayer::IsDeviceActivated()
{
	BOOL bResult = FALSE;

	SetRandomSample();

	if (m_fnIsDeviceActivated)
	{
		bResult = (* m_fnIsDeviceActivated)();
	}

	return bResult;
	

}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
HRESULT CDivXPlayer::GetRegistrationCode(TCHAR *szRegistrationCode)
{
	HRESULT hResult = E_FAIL;

	SetRandomSample();

	if (m_fnGetRegistrationCode)
	{
		hResult = (* m_fnGetRegistrationCode)(szRegistrationCode);
	}

	return hResult;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
HRESULT CDivXPlayer::GetDeregistrationCode(TCHAR *szDeregistrationCode)
{
	HRESULT hResult = E_FAIL;

	SetRandomSample();

	if (m_fnGetDeregistrationCode)
	{
		hResult = (* m_fnGetDeregistrationCode)(szDeregistrationCode);
	}

	return hResult;
}


///////////////////////////////////////////////////////////////////////////////
//
//
///////////////////////////////////////////////////////////////////////////////
void CDivXPlayer::HandleDivXError(HWND hWndParent, HRESULT hResult)
{
	TCHAR	szErrorMsg[DIVX_ERROR_MESSAGE_SIZE];
	UINT	uType = MB_OK | MB_ICONERROR | MB_DEFBUTTON1 | MB_APPLMODAL | MB_SETFOREGROUND;


	switch(hResult)
	{
	case DIVX_DRM_E_NOT_INITIALIZED:
		MessageBox(hWndParent, TEXT("DivX DRM System is not initialized."), TEXT("RefPlayer"), uType);
		break;
	case DIVX_DRM_E_NOT_AUTHORIZED:
		MessageBox(hWndParent, TEXT("Your device is not authorized to play this DivX protected video."), TEXT("RefPlayer"), uType);
		break;
	case DIVX_DRM_E_NOT_REGISTERED:
		MessageBox(hWndParent, TEXT("You must register your device to play DivX protected videos."), TEXT("RefPlayer"), uType);
		break;
	case DIVX_DRM_E_RENTAL_EXPIRED:
		swprintf(szErrorMsg, TEXT("This DivX rental has used %d out of %d views. This DivX rental has expired."), m_UseCount, m_UseLimit);
		MessageBox(hWndParent, szErrorMsg, TEXT("CEPlayer"), uType);
		break;
	}
}
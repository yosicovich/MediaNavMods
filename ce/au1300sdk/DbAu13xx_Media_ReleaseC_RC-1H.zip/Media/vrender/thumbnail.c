#include <osal.h>
#include <logging.h>
#include <thumbnail.h>
#include <vrenderPublic.h>
#include <bmp.h>
#include <asserts.h>

static const char *thumbs_html_path = "thumbs.html";
static const char *HTML_HEADER = "<html><head><title>Thumbnails</title></head><body>\n";
static const char *HTML_FOOTER = "</html>\n";

static struct
{
    osal_file_handle_t html;
    int started;
} thumbnailConfig;

static void
vrenderThumbnailBitmapFile (VideoSample_t *bmppic)
{
    char filename[256];
    const char *path;

    path = vrenderConfig.thumbnail.path;
    if(! path)
    {
        sprintf(filename, "%s%04d.bmp",
                vrenderConfig.thumbnail.full_size ? "pic" : "thumb",
                vrenderConfig.picture_count);
        path = filename;
    }

    vsample_to_bmp(bmppic, path);

    if(vrenderConfig.thumbnail.enable_html)
    {
        const int num_columns = vrenderConfig.thumbnail.max_html_width / bmppic->width;
        int depth = colorspaceBPP(bmppic->colorSpace);
        int newline = (vrenderConfig.thumbnail.count++ % num_columns) == 0;
        char buf[256];

        if(! thumbnailConfig.html.valid)
        {
            int rcode = osal_file_open(&thumbnailConfig.html, thumbs_html_path,
                                       OSAL_FILE_FLAGS_WRITE | OSAL_FILE_FLAGS_CREATE | OSAL_FILE_FLAGS_TRUNCATE);
            ASSERTNE(rcode,0,errFileFailed,return;,"open failed: %s\n", thumbs_html_path);

            osal_file_write(&thumbnailConfig.html, HTML_HEADER, strlen(HTML_HEADER));

            sprintf(buf, "Image: %d x %d, %dbpp<br />\n", bmppic->width, bmppic->height, depth * 8);
            osal_file_write(&thumbnailConfig.html, buf, strlen(buf));

            sprintf(buf, "Image: %d x %d, %dbpp<br />\n", bmppic->width, bmppic->height, depth * 8);
            osal_file_write(&thumbnailConfig.html, buf, strlen(buf));
        }
        if(newline)
        {
            sprintf(buf, "<br />%d:<br />\n", vrenderConfig.picture_count);
            osal_file_write(&thumbnailConfig.html, buf, strlen(buf));
        }
        sprintf(buf, "<img src = '%s' width = %d height = %d/>\n",
                filename, bmppic->width, bmppic->height);
        osal_file_write(&thumbnailConfig.html, buf, strlen(buf));
        osal_file_sync(&thumbnailConfig.html);
    }
}

void vrenderThumbnailReset (void)
{
    // Set default thumbnail values
    vrenderConfig.thumbnail.interval = -1;

    vrenderConfig.thumbnail.max_width = 200;
    vrenderConfig.thumbnail.count = 0;

    vrenderConfig.thumbnail.depth = csRGB555;
    //vrenderConfig.thumbnail.depth = csRGB888;
    vrenderConfig.thumbnail.full_size = 0;

    vrenderConfig.thumbnail.enable_html = 0;
    vrenderConfig.thumbnail.max_html_width = 800;

    thumbnailConfig.started = 0;
}

// FIXME: remove outpic!
void
vrenderThumbnail (VideoSample_t *inpic, VideoSample_t *outpic,
                  void (*render)(VideoSample_t *inVs, VideoSample_t *outVs))
{
    int do_thumbnail = 0;

    if(vrenderConfig.thumbnail.interval < 0)
        return;

    if(! thumbnailConfig.started)
    {
        LOG(NOTIFY,"Storing picture thumbnails every %d pictures\n", vrenderConfig.thumbnail.interval);
    }

    if(vrenderConfig.thumbnail.pointer != 0)
    {
        do_thumbnail = 1;
    }
    else if(vrenderConfig.thumbnail.interval == 0)
    {
        do_thumbnail = ! thumbnailConfig.started;
    }
    else
    {
        do_thumbnail = (vrenderConfig.picture_count % vrenderConfig.thumbnail.interval) == 0;
    }

    thumbnailConfig.started = 1;

    if(do_thumbnail)
    {
        VideoSample_t bmppic;
        memcpy(&bmppic, outpic, sizeof(VideoSample_t));
        if(vrenderConfig.thumbnail.full_size)
        {
            bmppic.width = inpic->width;
            bmppic.height = inpic->height;
        }
        else
        {
            // TODO: handle max_height boxing as well
            if(inpic->width < vrenderConfig.thumbnail.max_width)
            {
                bmppic.width = inpic->width;
            }
            else
            {
                bmppic.width = vrenderConfig.thumbnail.max_width;
            }

            bmppic.height = (int) ((float) outpic->height * bmppic.width / outpic->width);
        }

        bmppic.colorSpace = bmppic.geometry.colorSpace = vrenderConfig.thumbnail.depth;

        render(inpic, &bmppic);

        if(vrenderConfig.thumbnail.pointer != 0)
        {
            int bytes_pp = (bmppic.colorSpace == csRGB888) ? 4 : 2;
            int num_bytes = bmppic.width * bmppic.height * bytes_pp;
            memcpy(vrenderConfig.thumbnail.pointer, bmppic.memory.rgb.virt, num_bytes);
        }
        else
        {
            vrenderThumbnailBitmapFile(&bmppic);
        }
    }
}

void
vrenderThumbnailStop (void)
{
    if(thumbnailConfig.html.valid)
    {
        char buf[256];
        sprintf(buf, "<br />Rendered %d frames\n", vrenderConfig.picture_count);
        osal_file_write(&thumbnailConfig.html, buf, strlen(buf));
        osal_file_write(&thumbnailConfig.html, HTML_FOOTER, strlen(HTML_FOOTER));
        osal_file_close(&thumbnailConfig.html);
    }
}

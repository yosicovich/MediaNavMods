
/*
 *    File: vrender/maebe.c
 *  Author: Eric DeVolder
 * Purpose: Render pictures using Alchemy BE/ITE
 *   Notes:
 *
 */

#include <osal.h>

#include <vrender.h>
#include <asserts.h>
#include <perf.h>
#include <allocator.h>

#ifdef APPCFG_VRENDER_MAEBE

#include <vcodec/alchemy/au1x00.h>

// These macros don't work under MS compile
#if !defined(__WINDOWS__) && !defined(WINCE)
#define ITE_GRAYSCALE
#endif

#define ITE_MAX_UPSCALE   4
#define ITE_MAX_DOWNSCALE 32

static struct
{
    osal_maebe_handle_t h;

    mae_be_request_t fr_req;
    mae_be_request_t fi_req;
    mae_be_request_t gray_req;
    mae_be_request_t blur_req;

    int memAvailable;
    allocator_t mem;

} maebe;

#define BLUR_THRESHOLD 3

perfContext_t bePerf;

//////////////////////////////////////////////////////////////////////
#define COEFX(A,B,C,D) ((D<<24)|(C<<16)|(B<<8)|(A<<0))

static const uint32 fr_scaler_lut[] =
{
    0x00033a03, 0x00043903, 0x00053902, 0x00063802,
    0x00073801, 0x00083701, 0x00093601, 0x000b3401,
    0x000c3400, 0x000e3200, 0x000f3100, 0x00112f00,
    0x00132d00, 0x00162a00, 0x00182800, 0x001a2600,
    0x001d2300, 0x001f2100, 0x00211f00, 0x00241c00,
    0x00261a00, 0x00291700, 0x002b1500, 0x002d1300,
    0x00301000, 0x01320d00, 0x01330c00, 0x01350a00,
    0x01360900, 0x02370700, 0x02380600, 0x03380500,
};

static const uint32 fi_scaler_lut[] =
{
    // Field coeffs courtesy of Eric Swartzendruber
    COEFX(16, 32,  16,  0 ),
    COEFX(15, 32,  17,  0 ),
    COEFX(15, 31,  17,  1 ),
    COEFX(14, 31,  18,  1 ),
    COEFX(14, 30,  18,  2 ),
    COEFX(13, 30,  19,  2 ),
    COEFX(13, 29,  19,  3 ),
    COEFX(12, 29,  20,  3 ),
    COEFX(12, 28,  20,  4 ),
    COEFX(11, 28,  21,  4 ),
    COEFX(11, 27,  21,  5 ),
    COEFX(10, 27,  22,  5 ),
    COEFX(10, 26,  22,  6 ),
    COEFX(9 , 26,  23,  6 ),
    COEFX(9 , 25,  23,  7 ),
    COEFX(8 , 25,  24,  7 ),
    COEFX(8 , 24,  24,  8 ),
    COEFX(7 , 24,  25,  8 ),
    COEFX(7 , 23,  25,  9 ),
    COEFX(6 , 23,  26,  9 ),
    COEFX(6 , 22,  26,  10),
    COEFX(5 , 22,  27,  10),
    COEFX(5 , 21,  27,  11),
    COEFX(4 , 21,  28,  11),
    COEFX(4 , 20,  28,  12),
    COEFX(3 , 20,  29,  12),
    COEFX(3 , 19,  29,  13),
    COEFX(2 , 19,  30,  13),
    COEFX(2 , 18,  30,  14),
    COEFX(1 , 18,  31,  14),
    COEFX(1 , 17,  31,  15),
    COEFX(0 , 17,  32,  15),
};

static const uint32 blur_scaler_lut[] =
{
    // Blurring coefficients, which look much better on heavily downscaled images
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
    COEFX(16, 16, 16, 16),
};
#undef COEFX
//////////////////////////////////////////////////////////////////////

typedef struct
{
    uint16 CSCXCFFA;
    uint16 CSCXCFFB;
    uint16 CSCXCFFC;
    uint16 CSCYCFFA;
    uint16 CSCYCFFB;
    uint16 CSCYCFFC;
    uint16 CSCZCFFA;
    uint16 CSCZCFFB;
    uint16 CSCZCFFC;
    uint16 CSCXOFF;
    uint16 CSCYOFF;
    uint16 CSCZOFF;
} maebe_csc_t;

static const maebe_csc_t cscs[] =
{
// Courtesy of Jeff Miller
    {
    // SMPTE170
    0x04a7,
    0x0000,
    0x0662,
    0x04a7,
    0x1191,
    0x1340,
    0x04a7,
    0x0811,
    0x0000,
    0xf211,
    0x0879,
    0xeeb3,
    },

    {
    // SMPTE240
    0x04a8,
    0x0000,
    0x072C,
    0x04a8,
    0x1107,
    0x122b,
    0x04a8,
    0x0850,
    0x0000,
    0xf07e,
    0x053c,
    0xee36,
    },

    {
    // Studio RGB
    0x0400,
    0x0000,
    0x057b,
    0x0400,
    0x1158,
    0x12ca,
    0x0400,
    0x06ee,
    0x0000,
    0xf409,
    0x0746,
    0xf124,
    },

    {
    // BT.709
    0x04a8,
    0x0000,
    0x072C,
    0x04a8,
    0x10da,
    0x1221,
    0x04aa,
    0x0873,
    0x0001,
    0xf07c,
    0x04cd,
    0xeded,
    },

    {
    // SMPTE170 no scale
    0x0400,
    0x0000,
    0x059b,
    0x0400,
    0x1160,
    0x12db,
    0x0400,
    0x0716,
    0x0000,
    0xf212,
    0x0879,
    0xeeb3,
    },

#ifdef ITE_GRAYSCALE

// Macros to generate CSC registers from floating point coefficients
#define _ABS(A)      ((A < 0) ? (-A) : (A))
#define _SCALE(A)    ((uint32) _ABS(A * (1 << 10)))

#define CSC_REG(A)   (((A) < 0) << 12) | (_SCALE(A))
#define OFF_REG(A)   ((uint32) ((A) * 16))

    // BT.601
    {
    CSC_REG(1),        // Ry
    CSC_REG(0),        // Ru
    CSC_REG(1.13983),  // Rv

    CSC_REG(1),        // Gy
    CSC_REG(-0.39465), // Gu
    CSC_REG(-0.58060), // Gv

    CSC_REG(1),        // By
    CSC_REG(2.03211),  // Bu
    CSC_REG(0),        // Bv

    OFF_REG(1 * -16 + 1.13983 * -128),
    OFF_REG(1 * -16 - 0.39465 * -128 - 0.58060 * -128),
    OFF_REG(1 * -16 + 2.03211 * -128),
    },

    {
    // Grayscale
    CSC_REG(1.164),   // Ry
    CSC_REG(0),       // Ru
    CSC_REG(0),       // Rv

    CSC_REG(1.164),   // Gy
    CSC_REG(0),       // Gu
    CSC_REG(0),       // Gv

    CSC_REG(1.164),   // By
    CSC_REG(0),       // Bu
    CSC_REG(0),       // Bv

    OFF_REG(1.164 * -16),
    OFF_REG(1.164 * -16),
    OFF_REG(1.164 * -16),
    },
#endif

};

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
#ifdef DEBUG
static void
dump_be_inputs (mae_be_request_t *req)
{
    int i;
#define R1(REG) VRLOG(NOTIFY,"%19s: %08X\n", #REG, req->REG);
#define RX(REG,SZ) for (i = 0; i < SZ; ++i) VRLOG(NOTIFY,"%15s[%2d]: %08X\n", #REG, i, req->REG[i]);

    R1(scfhsr)
    R1(scfvsr)
    R1(scfdisable)
    RX(scfhalut,32)
    RX(scfvalut,32)
    RX(scfhblut,32)
    RX(scfvblut,32)
    RX(scfhclut,32)
    RX(scfvclut,32)

    R1(cscxcffa)
    R1(cscxcffb)
    R1(cscxcffc)
    R1(cscycffa)
    R1(cscycffb)
    R1(cscycffc)
    R1(csczcffa)
    R1(csczcffb)
    R1(csczcffc)
    R1(cscxoff)
    R1(cscyoff)
    R1(csczoff)
    R1(cscalpha)

    R1(srccfg)
    R1(srcfhw)
    R1(srcaaddr)
    R1(srcastr)
    R1(srcbaddr)
    R1(srcbstr)
    R1(srccaddr)
    R1(srccstr)

    R1(dstcfg)
    R1(dstheight)
    R1(dstaddr)
    R1(dststr)

    R1(ctlenable)
    R1(ctlfpc)
    R1(ctlstat)
    R1(ctlintenable)
    R1(ctlintstat)

#undef RX
#undef R1
}
#endif

//////////////////////////////////////////////////////////////////////
#ifdef MAE
static void
mae_dma_unswizzle (uint8 *p, int length)
{
    // mae_dma does some byte swizzling that we undo here
    int i;
    for (i = 0; i < length; i += 4)
    {
        uint8 a, b, c, d;
        a = p[i+0];
        b = p[i+1];
        c = p[i+2];
        d = p[i+3];
        p[i+0] = d;
        p[i+1] = c;
        p[i+2] = b;
        p[i+3] = a;
    }
}
#endif

static void
dump_yuv (VideoSample_t *vs)
{
    // MUST NOT disturb original picture pixels (since they can be used
    // for references to other pictures, so copy them here to manipulate
    int width = vs->width;
    int height = vs->height;

    vrenderStartDump(width, height);

#ifdef MAE
    // NOTE: MAE writes out image in big endian
#if 0
    // in addition, only valid when alloc_width == width...
    if ((width & 0xF) == 0)
    {
        // Y
        memcpy(vrenderConfig.dumpY, vs->memory.yuv.y, vs->memory.yuv.y_mem_size);
        mae_dma_unswizzle(vrenderConfig.dumpY, vs->memory.yuv.y_mem_size);

        // U
        memcpy(vrenderConfig.dumpU, vs->memory.yuv.u, vs->memory.yuv.u_mem_size);
        mae_dma_unswizzle(vrenderConfig.dumpU, vs->memory.yuv.u_mem_size);

        // V
        memcpy(vrenderConfig.dumpV, vs->memory.yuv.v, vs->memory.yuv.v_mem_size);
        mae_dma_unswizzle(vrenderConfig.dumpV, vs->memory.yuv.v_mem_size);
    }
    else
#endif
    {
        int row, col, width8;
        uint8 line[MAX_WIDTH_IN_MBS * 16 * 2/*good measure*/];
        uint8 *p, *src;

        // Y
        width8 = (width + 7) & ~7;
        p = vrenderConfig.dumpY;
        for (row = 0; row < height; ++row)
        {
            src = vs->memory.yuv.y + (row * vs->memory.yuv.y_mem_width);
            for (col = 0; col < width8; ++col)
            {
                line[col] = src[col];
            }
            mae_dma_unswizzle(line, width8);
            for (col = 0; col < width; ++col)
            {
                *p++ = line[col];
            }
        }

        // U
        width8 = ((width/2) + 7) & ~7;
        p = vrenderConfig.dumpU;
        for (row = 0; row < height/2; ++row)
        {
            src = vs->memory.yuv.u + (row * vs->memory.yuv.u_mem_width);
            for (col = 0; col < width8; ++col)
            {
                line[col] = src[col];
            }
            mae_dma_unswizzle(line, width8);
            for (col = 0; col < width/2; ++col)
            {
                *p++ = line[col];
            }
        }

        // V
        width8 = ((width/2) + 7) & ~7;
        p = vrenderConfig.dumpV;
        for (row = 0; row < height/2; ++row)
        {
            src = vs->memory.yuv.v + (row * vs->memory.yuv.v_mem_width);
            for (col = 0; col < width8; ++col)
            {
                line[col] = src[col];
            }
            mae_dma_unswizzle(line, width8);
            for (col = 0; col < width/2; ++col)
            {
                *p++ = line[col];
            }
        }
    }
#endif

#ifdef MAE2
	{
    // NOTE: MPE.cfg10 writes out YUV image in same endian as CPU

    // De-apronize the YUV image
    int i, j;
    uint8 *bp, *p;

    // Do Y
    bp = vrenderConfig.dumpY;
    for (i = 0; i < height; ++i)
    {
        p = ((uint8 *)vs->memory.yuv.y) + (i * vs->memory.yuv.y_mem_width) + 0;
        for (j = 0; j < width; ++j)
            *bp++ = *p++;
    }

    if (vs->geometry.yuv.yuv_format == VS_YUV_FORMAT_Y_UV)
    {
        // Do U (de-interleave too)
        bp = vrenderConfig.dumpU;
        for (i = 0; i < height/2; ++i)
        {
            p = ((uint8 *)vs->memory.yuv.u) + (i * vs->memory.yuv.y_mem_width) + 0;
            for (j = 0; j < width; j += 2, p += 2)
                *bp++ = *p;
        }

        // Do V (de-interleave too)
        bp = vrenderConfig.dumpV;
        for (i = 0; i < height/2; ++i)
        {
            p = ((uint8 *)vs->memory.yuv.u) + (i * vs->memory.yuv.y_mem_width) + 1;
            for (j = 0; j < width; j += 2, p += 2)
                *bp++ = *p;
        }
    }
    else
    {
        // Do U
        bp = vrenderConfig.dumpU;
        for (i = 0; i < height/2; ++i) // FIX!!! need to know actual YUV format!!!! not just 420
        {
            p = ((uint8 *)vs->memory.yuv.u) + (i * vs->memory.yuv.u_mem_width) + 0;
            for (j = 0; j < width/2; ++j)
                *bp++ = *p++;
        }

        // Do V
        bp = vrenderConfig.dumpV;
        for (i = 0; i < height/2; ++i) // FIX!!! need to know actual YUV format!!!! not just 420
        {
            p = ((uint8 *)vs->memory.yuv.v) + (i * vs->memory.yuv.v_mem_width) + 0;
            for (j = 0; j < width/2; ++j)
                *bp++ = *p++;
        }
    }
	}
#endif

    vrenderWriteDump(vrenderConfig.dumpY, vrenderConfig.dumpU, vrenderConfig.dumpV, width, height);

    vrenderEndDump();
}

//////////////////////////////////////////////////////////////////////
static uint32
vrmaebe_get_scale_ratio_register(unsigned int input_size, unsigned int output_size)
{
#define ITE_SCALE_RATIO(output, input) ((input << 16) / output)

    // Scaler math is done as 16.16 fixed point of input(src) / output(dst)
    uint32 scale_ratio_register = ITE_SCALE_RATIO(output_size, input_size);

    if((scale_ratio_register & 0xffff) != 0)
    {
        // Offset and mask, per the "Note" in the Au1300 databook page 179
        scale_ratio_register += 4;
        scale_ratio_register &= 0xfffffffc;
    }

    ASSERTLT(scale_ratio_register, ITE_SCALE_RATIO(ITE_MAX_UPSCALE, 1),
            errBadGeometry, return 0x0001000,
            "Exceeded maximum ITE upscale of %dx: %0.2fx, %d => %d\n",
            ITE_MAX_UPSCALE, (float) output_size / input_size, input_size, output_size);

    ASSERTGT(scale_ratio_register, ITE_SCALE_RATIO(1, ITE_MAX_DOWNSCALE),
            errBadGeometry, return 0x0001000,
            "Exceeded maximum ITE downscale of %dx: %0.2fx, %d => %d\n",
            ITE_MAX_DOWNSCALE, (float) input_size / output_size, input_size, output_size);

    return scale_ratio_register;
}

//////////////////////////////////////////////////////////////////////
static void
vrmaebe_render (VideoSample_t *inVs, VideoSample_t *outVs)
{
    unsigned in_width   = inVs->width;
    unsigned in_height  = inVs->height;
    unsigned out_width  = outVs->width;
    unsigned out_height = outVs->height;

    unsigned yuv_top_offset = 0;
    unsigned yuv_left_offset = 0;
    unsigned rgb_top_offset = 0;

    int lr_mask = ~0;
    int tb_mask = ~0;
    int chroma_div_w = 1;
    int chroma_div_h = 1;
    int dst_format;
    int dst_bpp;
    int dst_endian;

    mae_be_request_t *req;

    /* for debug purposes only */
    if (vrenderConfig.dump || vrenderConfig.crc) dump_yuv(inVs);

    // ITE has width/height restrictions depending on the input colorspace
    switch (inVs->colorSpace)
    {
        case csYUV420:
            // Clip width/height to a multiple of 2
            lr_mask = ~1;
            tb_mask = ~1;
            chroma_div_w = (inVs->geometry.yuv.yuv_format == VS_YUV_FORMAT_Y_U_V) ? 2 : 1;
            chroma_div_h = 2;
            break;

        case csYUV422:
            // Clip width to a multiple of 2
            lr_mask = ~1;
            chroma_div_w = 2;
            break;

        case csYUV422V:
            // Clip height to a multiple of 2
            tb_mask = ~1;
            chroma_div_h = 2;
            break;

        case csYUV411:
            // Clip width to a multiple of 4
            lr_mask &= ~3;
            chroma_div_w = 4;
            break;

        case csYUV444:
        default:
            break;
    }

    if (vrenderConfig.crop)
    {
        // FIXME: merge the cropping width/height calculations with vrender.c
        unsigned crop_left   = inVs->geometry.yuv.cropping_rect.left & lr_mask;
        unsigned crop_right  = inVs->geometry.yuv.cropping_rect.right;
        unsigned crop_top    = inVs->geometry.yuv.cropping_rect.top & tb_mask;
        unsigned crop_bottom = inVs->geometry.yuv.cropping_rect.bottom;

        unsigned cropped_width  = 1 + (crop_right - crop_left);
        unsigned cropped_height = 1 + (crop_bottom - crop_top);

        ASSERTGE(crop_left, crop_right, errBadGeometry, ;, "Bad left/right crop: %d => %d\n", crop_left, crop_right);
        ASSERTGE(crop_top, crop_bottom, errBadGeometry, ;, "Bad top/bottom crop: %d => %d\n", crop_top, crop_bottom);

        if(cropped_width < in_width)
        {
            in_width = cropped_width;
        }
        if(cropped_height < in_height)
        {
            in_height = cropped_height;
        }

        yuv_left_offset = crop_left;

        rgb_top_offset = outVs->geometry.yuv.cropping_rect.top;

        if(inVs->flags & VS_FLAGS_SEGMENT)
        {
            // Segmented YUV image; scale the output height based on the YUV segment size
            out_height = in_height * ((float) outVs->height / inVs->height);

            outVs->geometry.yuv.cropping_rect.top += out_height;
        }
        else
        {
            yuv_top_offset = crop_top * inVs->memory.yuv.y_mem_width;
        }
    }

    // Crop width/height to conform to ITE restrictions
    in_height &= tb_mask;
    in_width  &= lr_mask;

    ASSERTLT(in_width,     16, errBadGeometry, ;, "Bad YUV width: %d\n",  in_width);
    ASSERTLT(in_height,    16, errBadGeometry, ;, "Bad YUV height: %d\n", in_height);
    ASSERTGE(in_width,   8192, errBadGeometry, ;, "Bad YUV width: %d\n",  in_width);
    ASSERTGE(in_height,  8192, errBadGeometry, ;, "Bad YUV height: %d\n", in_height);
    ASSERTLT(out_width,    16, errBadGeometry, ;, "Bad RGB width: %d\n",  out_width);
    ASSERTLT(out_height,    4, errBadGeometry, ;, "Bad RGB height: %d\n", out_height);
    ASSERTGE(out_width,  4096, errBadGeometry, ;, "Bad RGB width: %d\n",  out_width);
    ASSERTGE(out_height, 4096, errBadGeometry, ;, "Bad RGB height: %d\n", out_height);

    VRLOG(TRACE,"ITE %d x %d => %d x %d\n",
          in_width, in_height,
          out_width, out_height);

    if (inVs->flags & VS_FLAGS_INTERLACED)
        req = &maebe.fi_req;
    else
        req = &maebe.fr_req;

    if ((in_width / out_width >= BLUR_THRESHOLD) ||
        (in_height / out_height >= BLUR_THRESHOLD))
    {
        req = &maebe.blur_req;
    }

    if (inVs->colorSpace == csYUV422V)
    {
        LOG(NOTIFY,"WARNING: 422 vertical scan not supported correctly in MAEBE\n");
#ifdef ITE_GRAYSCALE
        // Switch to grayscale until the colors get corrected
        req = &maebe.gray_req;
#endif
    }

    if (inVs->colorSpace == csYUV400)
    {
#ifdef ITE_GRAYSCALE
        // Switch to grayscale until the colors get corrected
        req = &maebe.gray_req;
#else
        LOG(NOTIFY,"WARNING: 400 not supported correctly in MAEBE\n");
#endif
    }

    // Examine MODIFIED attribute to determine if BE/ITE must do a dcache writeback
    req->flags = (inVs->flags & VS_FLAGS_MODIFIED) ? MAEBE_FLAGS_DCWB : 0;

    req->srcfhw = (in_height << 16) | (in_width << 0);
    req->srcaaddr = inVs->memory.yuv.y_phys + yuv_left_offset + yuv_top_offset;
    req->srcbaddr = inVs->memory.yuv.u_phys + yuv_left_offset/chroma_div_w + yuv_top_offset/chroma_div_h;
    req->srccaddr = inVs->memory.yuv.v_phys + yuv_left_offset/chroma_div_w + yuv_top_offset/chroma_div_h;
    req->srcastr = inVs->memory.yuv.y_mem_width;
    req->srcbstr = inVs->memory.yuv.u_mem_width;
    req->srccstr = inVs->memory.yuv.v_mem_width;
    req->srccfg = ( 0
        //| MAEBE_SRCCFG_ILM_UYVY
        //| MAEBE_SRCCFG_ILE
        //| MAEBE_SRCCFG_BYE
        );

    switch (inVs->colorSpace)
    {
        case csYUV420:
            req->srccfg |= MAEBE_SRCCFG_IF_420;
            switch (inVs->geometry.yuv.yuv_format)
            {
                case VS_YUV_FORMAT_Y_UV:
                    req->srccfg |= (MAEBE_SRCCFG_ILCE);
                    break;

                case VS_YUV_FORMAT_Y_VU:
                    req->srccfg |= (MAEBE_SRCCFG_ILCE | MAEBE_SRCCFG_ICM);
                    break;

                default:
                    break;
            }
            break;
        case csYUV422:
            req->srccfg |= MAEBE_SRCCFG_IF_422;
            switch (inVs->geometry.yuv.yuv_format)
            {
                // Check for special 4:2:2 interleaved modes
                case VS_YUV_FORMAT_YUYV:
                    req->srccfg |= MAEBE_SRCCFG_ILM_YUYV;
                    req->srccfg |= MAEBE_SRCCFG_ILE;
                    break;

                case VS_YUV_FORMAT_YVYU:
                    req->srccfg |= MAEBE_SRCCFG_ILM_YVYU;
                    req->srccfg |= MAEBE_SRCCFG_ILE;
                    break;

                case VS_YUV_FORMAT_UYVY:
                    req->srccfg |= MAEBE_SRCCFG_ILM_UYVY;
                    req->srccfg |= MAEBE_SRCCFG_ILE;
                    break;

                case VS_YUV_FORMAT_VYUY:
                    req->srccfg |= MAEBE_SRCCFG_ILM_VYUY;
                    req->srccfg |= MAEBE_SRCCFG_ILE;
                    break;

                default:
                    break;
            }

            break;
        case csYUV422V:
            req->srccfg |= MAEBE_SRCCFG_IF_422;
            break;
        case csYUV411:
            req->srccfg |= MAEBE_SRCCFG_IF_411;
            break;
        case csYUV444:
            req->srccfg |= MAEBE_SRCCFG_IF_444;
            break;
        case csYUV400:
            req->srccfg |= MAEBE_SRCCFG_IF_411; // HACK
            break;
        default:
            ASSERTEQ(0,0,errBadColorSpace,return;,"bad input colorspace %d\n", inVs->colorSpace);
            break;
    }

#ifdef EL
    if (inVs->flags & VS_FLAGS_EL)
    {
        req->srccfg |= MAEBE_SRCCFG_EF;
    }
#endif

    // Destination RGB
    switch(outVs->colorSpace)
    {
        case csRGB555: // 16-bit 555 pixel format
            dst_bpp = 2;
            dst_format = 3;
            break;

        case csRGB565: // 16-bit 565 pixel format
            dst_bpp = 2;
            dst_format = 2;
            break;

        case csRGB888: // 32-bit 888alpha pixel format :: lcd_winnctrl1[FORM] needs to be 12 8880
            dst_bpp = 4;
            dst_format = 0;
            break;

        default:
            ASSERTEQ(0,0,errBadColorSpace,return;,"bad output colorspace %d\n", inVs->colorSpace);
            break;
    }

    dst_endian = 1;

    req->dststr = out_width * dst_bpp;
    req->dstcfg = (dst_endian<<1) | (dst_format<<2);

    req->dstaddr = outVs->memory.rgb.phys + rgb_top_offset * req->dststr;
    req->dstheight = out_height;
#ifndef NO_MAE_HW
    ASSERTEQ(0, req->dstaddr, errNullSample, ;, "ERROR: no destination buffer!\n");
#endif

    // Scaler settings
    req->ctlfpc = MAEBE_CTLFPC_STR;

    req->scfhsr = vrmaebe_get_scale_ratio_register(in_width, out_width);
    req->scfvsr = vrmaebe_get_scale_ratio_register(in_height, out_height);

    req->scfdisable =  // can skip if *not* interlaced and 1:1
        (req->scfhsr == MAEBE_SCFHSR_SRI_N(1)) &&
        (req->scfvsr == MAEBE_SCFVSR_SRI_N(1)) &&
        ((inVs->flags & VS_FLAGS_INTERLACED) == 0);

    //dump_be_inputs(req);
    req->magic = MAEBE_MAGIC;
    if (vrenderConfig.submit)
    {
        if (req->dstaddr)
        {
            osal_maebe_driver_submit(&maebe.h, req);
            perf_sample(&bePerf, req->begMipsCounter, req->endMipsCounter, 0);
        }
    }
    else
    {
#ifndef APP_PLAYER
        // Wipe the RGB
        memset(outVs->memory.rgb.virt, 128, out_width * out_height * dst_bpp);
#endif
    }
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
static void
init_csc (mae_be_request_t *req, int which, const uint32 *hlut, const uint32 *vlut)
{
    const maebe_csc_t *csc;
    int i;

    ASSERTGE(which, MAX_CSC, errBadColorSpace, return, "Bad CSC: %d\n", which);

    csc = &cscs[which];

    req->cscxcffa = csc->CSCXCFFA;
    req->cscxcffb = csc->CSCXCFFB;
    req->cscxcffc = csc->CSCXCFFC;
    req->cscycffa = csc->CSCYCFFA;
    req->cscycffb = csc->CSCYCFFB;
    req->cscycffc = csc->CSCYCFFC;
    req->csczcffa = csc->CSCZCFFA;
    req->csczcffb = csc->CSCZCFFB;
    req->csczcffc = csc->CSCZCFFC;
    req->cscxoff = csc->CSCXOFF;
    req->cscyoff = csc->CSCYOFF;
    req->csczoff = csc->CSCZOFF;

    if (req == &maebe.fr_req)
    {
        LOG(INFO,"Using colorspace #%d\n", which);
        LOG(DEBUG,"CSC R: %4x %4x %4x | %4x\n", req->cscxcffa, req->cscxcffb, req->cscxcffc, req->cscxoff);
        LOG(DEBUG,"CSC G: %4x %4x %4x | %4x\n", req->cscycffa, req->cscycffb, req->cscycffc, req->cscyoff);
        LOG(DEBUG,"CSC B: %4x %4x %4x | %4x\n", req->csczcffa, req->csczcffb, req->csczcffc, req->csczoff);
    }

    for (i = 0; i < 32; ++i)
    {
        req->scfhalut[i] = hlut[i];
        req->scfvalut[i] = vlut[i];
        req->scfhblut[i] = hlut[i];
        req->scfvblut[i] = vlut[i];
        req->scfhclut[i] = hlut[i];
        req->scfvclut[i] = vlut[i];
    }
}

//////////////////////////////////////////////////////////////////////
#ifdef APPCFG_VRENDER_MAEBE_ALLOC_SIZE
static void
vrmaebe_init_allocator (void)
{
    int yuv_size = APPCFG_VRENDER_MAEBE_ALLOC_SIZE;
    osal_maebe_mem_open(&maebe.h, yuv_size);
    allocatorInit(&maebe.mem, "YUV", maebe.h.memPhysAddr, maebe.h.memVirtAddr, maebe.h.memPhysSize, 4);
}

static void
vrmaebe_deinit_allocator (void)
{
    osal_maebe_mem_close(&maebe.h);
}
#endif

//////////////////////////////////////////////////////////////////////
static void
vrmaebe_init(void)
{
    osal_maebe_driver_open(&maebe.h);

    init_csc(&maebe.fr_req, vrenderConfig.csc, fr_scaler_lut, fr_scaler_lut);
    init_csc(&maebe.fi_req, vrenderConfig.csc, fr_scaler_lut, fi_scaler_lut);

#ifdef ITE_GRAYSCALE
    init_csc(&maebe.gray_req, CSC_GRAYSCALE, fr_scaler_lut, fr_scaler_lut);
#endif

    init_csc(&maebe.blur_req, vrenderConfig.csc, blur_scaler_lut, blur_scaler_lut);

    perf_init(&bePerf, "MAEBE", maebe.h.counterFrequency);
    perf_enable(&bePerf, vrenderConfig.enableBePerf);
}

//////////////////////////////////////////////////////////////////////
static void
vrmaebe_reset(void)
{
}

//////////////////////////////////////////////////////////////////////
static int
vrmaebe_allocBuffer (void **pVA, phys_t *pPA, unsigned int size, unsigned int alignment)
{
#ifdef APPCFG_VRENDER_MAEBE_ALLOC_SIZE
    if (!maebe.memAvailable)
    {
        maebe.memAvailable = 1;
        vrmaebe_init_allocator();
    }

    allocatorAllocBuffer(&maebe.mem, pVA, pPA, size, alignment);
    return 0;
#else
    ASSERTEQ(0,0,errAllocFailed,;,"MAEBE YUV allocation not enabled\n");
    return 1;
#endif
}

//////////////////////////////////////////////////////////////////////
static void
vrmaebe_deinit(void)
{
#ifdef DEBUG
    (void)dump_be_inputs; // make compiler warning go away
#endif

    osal_maebe_driver_close(&maebe.h);

#ifdef APPCFG_VRENDER_MAEBE_ALLOC_SIZE
    if (maebe.memAvailable)
    {
        maebe.memAvailable = 0;
        vrmaebe_deinit_allocator();
    }
#endif

    perf_dump(&bePerf);
}

//////////////////////////////////////////////////////////////////////
vrender_t maebe_vrender =
{
    STRUCT_INIT(name,           "maebe"),
#ifdef MAE
    STRUCT_INIT(description,    "Au1200 MAE BE Render"),
#endif
#ifdef MAE2
    STRUCT_INIT(description,    "Au1300 MAE ITE Render"),
#endif
    STRUCT_INIT(which,          vrender_maebe),
    STRUCT_INIT(max_upscale,    ITE_MAX_UPSCALE),
    STRUCT_INIT(max_downscale,  ITE_MAX_DOWNSCALE),
    STRUCT_INIT(init,           vrmaebe_init),
    STRUCT_INIT(reset,          vrmaebe_reset),
    STRUCT_INIT(allocBuffer,    vrmaebe_allocBuffer),
    STRUCT_INIT(render,         vrmaebe_render),
    STRUCT_INIT(deinit,         vrmaebe_deinit),
};

//////////////////////////////////////////////////////////////////////

#endif // APPCFG_VRENDER_MAEBE



/*
 *    File: vrender/soft.c
 *  Author: Eric DeVolder
 * Purpose: Render pictures using software methods
 *   Notes:
 *
 */

#include <osal.h>

#include <vrender.h>
#include <asserts.h>
#include <allocator.h>

#ifdef APPCFG_VRENDER_SOFTWARE

#define VIDEO_MEM_SIZE (32*1024*1024) // 32M is large enough for 720p

static uint8 *_mem = NULL;
static allocator_t videoMemory;

//////////////////////////////////////////////////////////////////////
static void vrsoft_init(void)
{
    _mem = vrender_alloc(VIDEO_MEM_SIZE);
    ASSERTEQ(NULL, _mem, errAllocFailed, return, "Unable to allocate %d bytes for video memory\n", VIDEO_MEM_SIZE);
    allocatorInit(&videoMemory, "VRSOFT", (uint32)&_mem[0], &_mem[0], VIDEO_MEM_SIZE, 1);
}

//////////////////////////////////////////////////////////////////////
static void vrsoft_reset(void)
{
}

//////////////////////////////////////////////////////////////////////
static int vrsoft_allocBuffer (void **pVA, phys_t *pPA, unsigned int size, unsigned int alignment)
{
    void *va;
    phys_t pa;

    ASSERTEQ(NULL, _mem, errAllocFailed, return 1, "_mem has not been allocated\n");

    allocatorAllocBuffer(&videoMemory, &va, &pa, size, alignment);

    *pVA = va;
    *pPA = pa;

    return (NULL == va);
}

static inline uint8 clamp8(int a)
{
    if(a > 255)
        return 255;
    if(a < 0)
        return 0;
    return a;
}

//////////////////////////////////////////////////////////////////////
static void vrsoft_render (VideoSample_t *inpic, VideoSample_t *outpic)
{
    //if (inpic->colorspace == output->colorspace)
    {
        if (outpic->colorSpace == csYUV420)
        {
#if 0
            if (vrenderDump)
            {
                int ofd;
                ofd = vrenderOpenDumpFile(inpic->alloc_width, inpic->alloc_height);
                write(ofd, inpic->memory.yuv.y, inpic->memory.yuv.y_size);
                write(ofd, inpic->memory.yuv.u, inpic->memory.yuv.uv_size);
                write(ofd, inpic->memory.yuv.v, inpic->memory.yuv.uv_size);
                vrenderCloseDumpFile();
            }
#endif
            memcpy(outpic->memory.yuv.y, inpic->memory.yuv.y, inpic->memory.yuv.y_mem_size);
            memcpy(outpic->memory.yuv.u, inpic->memory.yuv.u, inpic->memory.yuv.u_mem_size);
            memcpy(outpic->memory.yuv.v, inpic->memory.yuv.v, inpic->memory.yuv.v_mem_size);
        }
#ifdef LIBADHD  // yuv2rgb => Only useful for x86 debugging
        else if(inpic->colorSpace == csYUV420 &&
                (outpic->colorSpace == csRGB565 || outpic->colorSpace == csRGB888))
        {
            // I420 (aka non-interleaved) YUV => RGB software colorspace implementation
            static uint8_t background_color = 0x1;
            static int8_t  background_delta = 1;

            unsigned int yuv_width = inpic->width;
            unsigned int yuv_height = inpic->height;

            unsigned int rgb_bytes_per_pixel = outpic->memory.rgb.bpp;
            unsigned int rgb_width = outpic->width;
            unsigned int rgb_height = outpic->height;

            uint8 *rgb8 = (uint8 *) outpic->memory.rgb.virt;
            uint16 *rgb16 = (uint16 *) rgb8;
            uint8 *luma_ptr = (uint8 *) inpic->memory.yuv.y;
            uint8 *uv_ptr = inpic->memory.yuv.u;
            unsigned int luma_stride = inpic->memory.yuv.y_mem_width;
            uint8 *luma_ptr_end = luma_ptr + luma_stride * yuv_height;

            unsigned int y, u=0, v=0;
            int16 r, g, b;

            int increment_uv = 1;
            unsigned int luma;
            unsigned int xpos = 0;
            unsigned int ypos = 0;
            int16 c, d, e;
            int rgb_stride = (rgb_width - yuv_width) * rgb_bytes_per_pixel;
            unsigned int odd = 1;

            luma = 0;

            LOG(DEBUG,"software yuv2rgb; %p, rgb: %d x %d, rgb_stride: %d, bpp: %d\n",
                rgb8, rgb_width, rgb_height, rgb_stride, rgb_bytes_per_pixel);

            // Background fill
            memset(rgb8, background_color, rgb_width * rgb_height * rgb_bytes_per_pixel);
            if(background_color >= 240 || background_color == 0)
                background_delta *= -1;
            background_color += background_delta;

#ifdef NO_MAE_HW
            osal_sleep_milliseconds(25);
#endif

            if(rgb_width != yuv_width)
            {
                // Not implemented
                return;
            }

            while(luma_ptr < luma_ptr_end)
            {
                if(xpos == yuv_width)
                {
                    xpos = 0;
                    ypos++;
                    rgb8 += rgb_stride;
                    rgb16 += rgb_stride / 2;
                    luma_ptr += luma_stride - yuv_width;
                    uv_ptr += luma_stride - yuv_width;

                    if(odd)
                    {
                        uv_ptr -= luma_stride;
                    }
                    odd = !odd;
                }

                xpos++;

                y = *luma_ptr++;
                if(increment_uv == 1)
                {
                    u = *uv_ptr++;
                    v = *uv_ptr++;
                }
                increment_uv = ! increment_uv;

                if(xpos > rgb_width)
                {
                    rgb8 += 4;
                    rgb16++;
                    continue;
                }

                c = y - 16;
                d = u - 128;
                e = v - 128;
                r = ( 298 * c           + 409 * e + 128) >> 8;
                g = ( 298 * c - 100 * d - 208 * e + 128) >> 8;
                b = ( 298 * c + 516 * d           + 128) >> 8;

                if(rgb_bytes_per_pixel == 4)
                {
                    *rgb8++ = clamp8(b);
                    *rgb8++ = clamp8(g);
                    *rgb8++ = clamp8(r);
                    *rgb8++ = 0;
                }
                else
                {
                    r = clamp8(r) >> 3;
                    g = clamp8(g) >> 2;
                    b = clamp8(b) >> 3;
                    *rgb16++ = (r << 11) | (g << 5) | b;
                }
            }
        }
        else
        {
            ASSERTEQ(0, 0, errBadRenderer, ;, "software vrender not implemented for this colorspace\n");
        }
#endif
    }
}

//////////////////////////////////////////////////////////////////////
static void vrsoft_deinit(void)
{
    vrender_free(_mem);
}

//////////////////////////////////////////////////////////////////////
vrender_t software_vrender =
{
    STRUCT_INIT(name,           "vrsoft"),
    STRUCT_INIT(description,    "Software Video Render"),
    STRUCT_INIT(which,          vrender_software),
    STRUCT_INIT(max_upscale,    1),
    STRUCT_INIT(max_downscale,  1),
    STRUCT_INIT(init,           vrsoft_init),
    STRUCT_INIT(reset,          vrsoft_reset),
    STRUCT_INIT(allocBuffer,    vrsoft_allocBuffer),
    STRUCT_INIT(render,         vrsoft_render),
    STRUCT_INIT(deinit,         vrsoft_deinit),
};

//////////////////////////////////////////////////////////////////////

#endif // APPCFG_VRENDER_SOFTWARE


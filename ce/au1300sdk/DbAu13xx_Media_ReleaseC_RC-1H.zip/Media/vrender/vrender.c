
/*
 *    File: vrender/vrender.c
 *  Author: Eric DeVolder
 * Purpose: Video render infrastructure
 *   Notes:
 *
 */

#include <osal.h>

#include <vrender.h>
#include <vrenderPublic.h>
#include <vsample.h>
#include <voutput.h>
#include <asserts.h>
#include <logging.h>

#include <video_checksum.h>
#include <vsample_checksum.h>
#include <thumbnail.h>

//////////////////////////////////////////////////////////////////////
// Public vars
vrenderConfig_t vrenderConfig;

//////////////////////////////////////////////////////////////////////
// Private vars
OSAL_THREAD_HANDLE(vrender);
OSAL_QUEUE_HANDLE(VideoSample_t, vrQueue);

static vrender_t *vrenderList[MAX_VRENDERS];
static vrender_t *vrender = NULL;
static osal_file_handle_t h;

//////////////////////////////////////////////////////////////////////

static void
vrenderOpenDumpFile (void)
{
    h.valid = 0;

    vrenderConfig.dumpPart = 0;
    vrenderConfig.dumpBytes = 0;

    // NOTE: Can accomodate 4:4:4
    vrenderConfig.dumpY = (uint8 *)vrender_alloc( MAX_WIDTH_IN_MBS * MAX_HEIGHT_IN_MBS * 16 * 16 );
    vrenderConfig.dumpU = (uint8 *)vrender_alloc( MAX_WIDTH_IN_MBS * MAX_HEIGHT_IN_MBS * 16 * 16 );
    vrenderConfig.dumpV = (uint8 *)vrender_alloc( MAX_WIDTH_IN_MBS * MAX_HEIGHT_IN_MBS * 16 * 16 );
}

void
vrenderStartDump (int width, int height)
{
    if (!h.valid)
    {
        char ofn[255];
        int rcode;
        char *suffix = vrenderConfig.crc ? "crc" : "yuv";

        if (vrenderConfig.dumpPart == 0)
        {
            sprintf(ofn, "dump_%dx%d.%s", width, height, suffix);
        }
        else
        {
            sprintf(ofn, "dump_%dx%d.yuv_%04d", width, height, vrenderConfig.dumpPart);
        }
        rcode = osal_file_open(&h, ofn, OSAL_FILE_FLAGS_WRITE | OSAL_FILE_FLAGS_CREATE | OSAL_FILE_FLAGS_TRUNCATE);
        ASSERTEQ(1,rcode,errFileFailed,;,"could not open file %s\n", ofn);
    }
}

void
vrenderWriteDump (uint8 *Y, uint8 *U, uint8 *V, int width, int height)
{
    int size;
    uint8 *p;

    if (vrenderConfig.dump)
    {
        // Write out 4:2:0 planar YUV, YV12?, format, BUT CROPPED TO ACTUAL DIMENSIONS
        p = Y;
        size = width * height;
        osal_file_write(&h, p, size);
        vrenderConfig.dumpBytes += size;

        p = U;
        size = (width / 2 ) * (height / 2);
        osal_file_write(&h, p, size);
        vrenderConfig.dumpBytes += size;
        if (height & 1)
        {
            p += size;
            size = (width / 2 );
            osal_file_write(&h, p, size);
            vrenderConfig.dumpBytes += size;
        }

        p = V;
        size = (width / 2 ) * (height / 2);
        osal_file_write(&h, p, size);
        vrenderConfig.dumpBytes += size;
        if (height & 1)
        {
            p += size;
            size = (width / 2 );
            osal_file_write(&h, p, size);
            vrenderConfig.dumpBytes += size;
        }
    }
    else
    {
        char text[256];
        uint32 crcY, crcU, crcV;

        crcY = vc_crc32(Y, 1, width/1, width/1, height/1);
        crcU = vc_crc32(U, 1, width/2, width/2, height/2);
        crcV = vc_crc32(V, 1, width/2, width/2, height/2);

        sprintf(text, "Frame %6d: 0x%08X 0x%08X 0x%08X\n",
            vrenderConfig.dumpBytes, crcY, crcU, crcV);
        osal_file_write(&h, text, strlen(text));

        ++vrenderConfig.dumpBytes; // track frame number
    }
}

void
vrenderEndDump (void)
{
    osal_file_sync(&h);

    if (vrenderConfig.dump)
    {
        if (vrenderConfig.dumpBytes >= vrenderConfig.dumpLimit)
        {
            osal_file_close(&h);
            ++vrenderConfig.dumpPart;
            vrenderConfig.dumpBytes = 0;
        }
    }
}

static void
vrenderCloseDumpFile (void)
{
    vrender_free(vrenderConfig.dumpY);
    vrender_free(vrenderConfig.dumpU);
    vrender_free(vrenderConfig.dumpV);

    osal_file_close(&h);
}

static void
vrenderChecksumStart (void)
{
    if(vrenderConfig.enable_checksum)
    {
        vsample_checksum_init(vrenderConfig.codec_name,
                              vrenderConfig.yuv_checksum_path,
                              vrenderConfig.yuv_checksum_max_frames,
                              vrenderConfig.dump_components);
    }
    else if (vrenderConfig.dump || vrenderConfig.crc)
    {
        vrenderOpenDumpFile();
    }
}

static void
vrenderChecksumStop (void)
{
    if (vrenderConfig.enable_checksum)
        vsample_checksum_stop();
    else if (vrenderConfig.dump || vrenderConfig.crc)
        vrenderCloseDumpFile();

}

static void
vrenderChecksum (VideoSample_t *vs)
{
    if (vrenderConfig.enable_checksum)
    {
        vsample_checksum(vs);
    }
}

//////////////////////////////////////////////////////////////////////
static void
vrenderClampUpscale(int *dest_a, int *dest_b, int src_a)
{
    const int max_a = src_a * vrender->max_upscale;
    if((*dest_a) > max_a)
    {
        float clamp = (float) max_a / (*dest_a);
        (*dest_b) *= clamp;
        (*dest_a) = max_a;
    }
}

//////////////////////////////////////////////////////////////////////
static void
vrenderClampDownscale(int *dest_a, int *dest_b, int src_a)
{
    const int min_a = src_a / (float) vrender->max_downscale;
    if((*dest_a) < min_a)
    {
        float clamp = (float) min_a / (*dest_a);
        (*dest_b) *= clamp;
        (*dest_a) = min_a;
    }
}

//////////////////////////////////////////////////////////////////////
// Populate a cropped/scaled RGB sample from an input YUV sample
void
vrenderScaleVideoSample (VideoSample_t *yuv_sample, VideoSample_t *rgb_sample)
{
    int yuv_width = yuv_sample->width;
    int yuv_height = yuv_sample->height;
    int enable_scaling = ! (vrender->max_upscale == 1 && vrender->max_downscale == 1);
    int do_scale = enable_scaling && (vrenderConfig.maxpect || vrenderConfig.stretch);
    int max_output_width, max_output_height;
    static int prev_width = 0, prev_height = 0;

    voutputGetMaxDimensions(&max_output_width, &max_output_height);

    if(vrenderConfig.crop)
    {
        CroppingRect_t *rect = &yuv_sample->geometry.yuv.cropping_rect;
        int cropped_width  = 1 + (rect->right  - rect->left);
        int cropped_height = 1 + (rect->bottom - rect->top);

        // BZ9385: only take the cropped dimensions if they are smaller than the container dimensions.
        if(cropped_width < yuv_width)
        {
            yuv_width = cropped_width;
        }
        if(cropped_height < yuv_height)
        {
            yuv_height = cropped_height;
        }
        VRLOG(TRACE,"Cropped VS: %d x %d\n", yuv_width, yuv_height);
    }

    if(yuv_sample->flags & VS_FLAGS_SEGMENT)
    {
        // Segmented YUV => use the completed image size
        yuv_height = yuv_sample->geometry.height;
    }

    // Default is no scale
    rgb_sample->width  = yuv_width;
    rgb_sample->height = yuv_height;

    if(do_scale)
    {
        ASSERTEQ(max_output_width,0,errOutOfBounds,return;,"RGB panel width not set\n");
        ASSERTEQ(max_output_height,0,errOutOfBounds,return;,"RGB panel height not set\n");

        if(vrenderConfig.maxpect)
        {
            float pixel_aspect_ratio;
            float rgb_panel_aspect_ratio;

            if((yuv_sample->geometry.aspect_ratio_width) > 0 && (yuv_sample->geometry.aspect_ratio_height) > 0)
            {
                pixel_aspect_ratio = ((float) (yuv_sample->geometry.aspect_ratio_width) /
                                      (yuv_sample->geometry.aspect_ratio_height));

                VRLOG(TRACE,"pixel_aspect_ratio: %f %d %d\n",
                      pixel_aspect_ratio,
                      yuv_sample->geometry.aspect_ratio_width,
                      yuv_sample->geometry.aspect_ratio_height);
            }
            else
            {
                pixel_aspect_ratio = 1.0;
            }

            rgb_panel_aspect_ratio = (float) max_output_width / max_output_height;

            if(yuv_sample->geometry.aspect_ratio_type == arSample)
            {
                float original_pixel_aspect_ratio = pixel_aspect_ratio * (float) yuv_width / yuv_height;

                VRLOG(DEBUG,"OAR: %0.3f, IAR: %0.3f\n", rgb_panel_aspect_ratio, original_pixel_aspect_ratio);

                if(vrenderConfig.zoom)
                {
                    if(rgb_panel_aspect_ratio < original_pixel_aspect_ratio &&
                       yuv_sample->height >= max_output_height &&
                       original_pixel_aspect_ratio >= 1.60)
                    {
                        unsigned zoomed_width = max_output_height * rgb_panel_aspect_ratio;
                        unsigned cropped_lr = (yuv_width - zoomed_width) / 2;
                        cropped_lr &= ~1; // Make sure it's an even number
                        yuv_sample->geometry.yuv.cropping_rect.left  += cropped_lr;
                        yuv_sample->geometry.yuv.cropping_rect.right -= cropped_lr;

                        VRLOG(DEBUG,"cropped_lr: %d\n", cropped_lr);

                        pixel_aspect_ratio *= (float) (yuv_width) / max_output_height;
                    }
                }
                else
                {
                    pixel_aspect_ratio = original_pixel_aspect_ratio;
                }
            }

            VRLOG(TRACE,"YUV ar: %f, RGB ar: %f\n", pixel_aspect_ratio, rgb_panel_aspect_ratio);

            if(pixel_aspect_ratio > rgb_panel_aspect_ratio)
            {
                // Clamp to max width
                rgb_sample->width  = max_output_width;
                rgb_sample->height = (unsigned) ((float) max_output_width / pixel_aspect_ratio);
            }
            else
            {
                // Clamp to max height
                rgb_sample->width  = (unsigned) (max_output_height * pixel_aspect_ratio);
                rgb_sample->height = max_output_height;
            }
        }
        else if(vrenderConfig.stretch)
        {
            rgb_sample->width  = max_output_width;
            rgb_sample->height = max_output_height;
        }

        vrenderClampUpscale(&rgb_sample->width,  &rgb_sample->height, yuv_width);
        vrenderClampUpscale(&rgb_sample->height, &rgb_sample->width,  yuv_height);

        vrenderClampDownscale(&rgb_sample->width,  &rgb_sample->height, yuv_width);
        vrenderClampDownscale(&rgb_sample->height, &rgb_sample->width,  yuv_height);
    }

    if(enable_scaling)
    {
        if(rgb_sample->width  > max_output_width ||
           rgb_sample->height > max_output_height)
        {
            ASSERTEQ(0,0,errOutOfBounds,;,"Invalid RGB resolution: (%d x %d), max is: (%d x %d)\n",
                     rgb_sample->width, rgb_sample->height,
                     max_output_width, max_output_height);
        }
    }

    if(prev_width != yuv_width || prev_height != yuv_height)
    {
        prev_width = yuv_width;
        prev_height = yuv_height;

        VRLOG(NOTIFY,"%s %d x %d | RGB %d x %d\n",
              colorspaceName(yuv_sample->colorSpace), yuv_width, yuv_height,
              rgb_sample->width, rgb_sample->height);
    }
}

//////////////////////////////////////////////////////////////////////
static void *vrender_thread (void *ptr)
{
    VideoSample_t *inpic; // YUV
    VideoSample_t *outpic = NULL; // RGB
    int inflags;

    while (1)
    {
        // Wait for next sample to arrive
        OSAL_QUEUE_REMOVE_ELEMENT(VideoSample_t, vrQueue, inpic, qNext, qPrev, 1, 1, 0, 0, ; );

        // Capture flags
        inflags = inpic->flags;

        if (inflags & VS_FLAGS_EXIT)
        {
            // pass exit downstream
            voutputOutputVideoSample(inpic);
            break; // exit thread
        }
        else
        {
            int render = 1;

            // Accounting
            if (inflags & VS_FLAGS_INTERLACED)
                ++vrenderConfig.numInterlaced;
            else
                ++vrenderConfig.numProgressive;

#ifndef APP_PLAYER // needed for YUV dumping to still work
            render &= vrenderConfig.submit;
#endif
            render &= ! vrenderConfig.flushing;
            render &= ! (inflags & VS_FLAGS_BAD_FRAME);

            if (render)
            {
                vrenderChecksum (inpic);

                // Obtain an available output buffer
                if (! outpic)
                {
                    if (voutputAllocVideoSample(&outpic) != 0)
                    {
                        // Alloc failed
                        outpic = NULL;
                    }

                    if (outpic)
                    {
#ifdef LIBADHD
                        vrenderScaleVideoSample(inpic, outpic);
#endif

                        if (voutputInitVideoSample(inpic, outpic) != 0)
                        {
                            // Init failed
                            outpic = NULL;
                        }
                    }
                }

                if (outpic)
                {
                    vrenderThumbnail(inpic, outpic, vrender->render);

                    // Render it
                    vrender->render(inpic, outpic);
                }
            }

            if (inpic->flags & VS_FLAGS_SEGMENT)
            {
                if (inpic->geometry.yuv.cropping_rect.bottom + 1 >= inpic->height)
                {
                    outpic->flags &= ~VS_FLAGS_SEGMENT;
                }
                else
                {
                    outpic->flags |= VS_FLAGS_SEGMENT;
                }
            }

            // Notify done with input sample
            vsampleUnRef(inpic);

            // Now send finished sample for display
            if (outpic)
            {
                voutputOutputVideoSample(outpic);

                if (! (inpic->flags & VS_FLAGS_SEGMENT))
                {
                    outpic = NULL;
                }
            }
            else
            {
                VRLOG(INFO, "DROP %04X %d\n", inflags, vrenderConfig.numDropped);
                ++vrenderConfig.numDropped;
            }
            vrenderConfig.picture_count++;
        }
    }

    VRLOG(DEBUG, "VRENDER thread exiting\n");
    VRLOG(INFO, "Interlaced: %d\n", vrenderConfig.numInterlaced);
    VRLOG(INFO, "Progressiv: %d\n", vrenderConfig.numProgressive);

    return NULL;
}

//////////////////////////////////////////////////////////////////////
void
vrenderVideoSample (VideoSample_t *vs)
{
    // Place newly arrived sample on queue to be rendered
    ASSERTEQ(NULL, vs, errNullParam, return, "Cannot render null VideoSample\n");
    vsampleRef(vs);
    OSAL_QUEUE_ADD_ELEMENT(VideoSample_t, vrQueue, vs, qNext, qPrev, 0, 1, ; );
}

//////////////////////////////////////////////////////////////////////
int
vrenderAllocBuffer (void **va, phys_t *pa, unsigned int size, unsigned int alignment)
{
    *va = NULL;
    *pa = 0;
    ASSERTEQ(NULL,vrender,errBadRenderer,return 0,"vrender is NULL\n");
    return vrender->allocBuffer(va, pa, size, alignment);
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
static void
vrenderRegister (vrender_t *render)
{
    int which;
    if (render)
    {
#ifdef DEBUG
#define CHK(FLD) ASSERTEQ(NULL, render->FLD, errBadRenderer, return, "error: incomplete vrender_t %s %s\n", render->name, #FLD)
        CHK(name);
        CHK(description);
        CHK(init);
        CHK(reset);
        CHK(allocBuffer);
        CHK(render);
        CHK(deinit);
#endif

        which = render->which;
        if ((which >= 0) && (which < MAX_VRENDERS))
        {
            if (vrenderList[which] == NULL)
            {
                vrenderList[which] = render;
            }
            else
            {
                ASSERTEQ(0, 0, errBadRenderer, ;, "error: vrender for type %d already registered\n", which);
            }
        }
    }
}

//////////////////////////////////////////////////////////////////////
int
vrenderSelect (vrender_type which, int force)
{
    int result = -1;

    if ((which != vrender_reserved) && (which < MAX_VRENDERS))
    {
        if (vrenderList[which] != NULL)
        {
            if (force || vrender == NULL)
            vrender = vrenderList[which];
            result = 0;
        }
    }

    if (vrender) VRLOG(INFO, "VRENDER: %s\n", vrender->description);

    return result;
}

//////////////////////////////////////////////////////////////////////
void
vrenderConfigReset (void)
{
    // This routine must be invoked prior to the media framework
    // referencing any members in vrenderConfig.

    memset(&vrenderConfig, 0, sizeof(vrenderConfig_t));

    // Set non-zero values here...
    vrenderConfig.submit = 1;
    vrenderConfig.csc = CSC_SMPTE170;
    vrenderConfig.dumpLimit = 1 * 1024 * 1024 * 1024; // 1GB - set to 1 results in a single YUV frame per file...
    vrenderConfig.maxpect = 1;

#ifdef LIBADHD
    vrenderConfig.crop = 1;
#endif

    vrenderThumbnailReset();
}

//////////////////////////////////////////////////////////////////////
int
vrenderConfigValid (void)
{
    int rcode = 1;

    return rcode;
}

//////////////////////////////////////////////////////////////////////
void
vrenderInit (void)
{
    int i, which = vrender_reserved;

#ifdef APPCFG_DOWNSTREAM_CONTROL
    // Initialize downstream components
    voutputInit();
#endif

    OSAL_QUEUE_HANDLE_INIT(vrQueue);

    for (i = 0; i < MAX_VRENDERS; ++i)
        vrenderList[i] = NULL;

#if defined(APPCFG_VRENDER_SOFTWARE)
    vrenderRegister(&software_vrender);
    which = vrender_software;
#endif

#if defined(APPCFG_VRENDER_MAEBE)
    vrenderRegister(&maebe_vrender);
    which = vrender_maebe;
#endif

    vrenderSelect(which, 1);

    vrender->init();
}

//////////////////////////////////////////////////////////////////////
void
vrenderStart (void)
{
    ASSERTEQ(NULL, vrender, errBadRenderer, return, "vrender is NULL\n");

#ifdef APPCFG_DOWNSTREAM_CONTROL
    // Start downstream component
    voutputStart();
#endif

    vrenderChecksumStart();

    OSAL_THREAD_CREATE(vrender, "vrender", OSAL_THREAD_PRIORITY_VRENDER);
    OSAL_THREAD_START(vrender);
}

//////////////////////////////////////////////////////////////////////
void
vrenderStop (void)
{
#ifdef APPCFG_DOWNSTREAM_CONTROL
    // Stop downstream component
    voutputStop();
#endif

    OSAL_THREAD_STOP(vrender);
    OSAL_THREAD_DESTROY(vrender);

    OSAL_QUEUE_HANDLE_DEINIT(vrQueue);

    vrender->deinit();

    vrenderChecksumStop();
    vrenderThumbnailStop();
}

//////////////////////////////////////////////////////////////////////


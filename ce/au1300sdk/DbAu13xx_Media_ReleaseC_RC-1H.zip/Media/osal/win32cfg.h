
/*
 *    File: osal/win32cfg.h
 *  Author: Eric DeVolder
 * Purpose: Interface to osal/win32cfg.c
 *   Notes:
 *
 */

#ifdef MAE
#define AU1200
#define SOC_AU1200
#endif
#ifdef MAE2
#define AU13XX
#define SOC_AU13XX
#endif

//#define _FILE_OFFSET_BITS 64 // video creates large files

#ifndef _CRT_SECURE_NO_DEPRECATE
#define _CRT_SECURE_NO_DEPRECATE // allow deprecated standard C library functions
#endif

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "ctypes.h"
#include "dlcl.h"
#include "bitbuffer.h"

#ifdef UNDER_CE
#include "mem_ioctl.h" // in DbAu13xx BSP/SDK
#endif

#include "maeioctl.h"

// not sure where these are prototyped in Windows...
// => I think they're in <strings.h>
#define strcasecmp(a,b) _stricmp(a,b)
#define strncasecmp(a,b,n) _strnicmp(a,b,n)
//int strcasecmp(const char *s1, const char *s2);
//int strncasecmp(const char *s1, const char *s2, size_t n);
#define sync()

#define inline __forceinline

//////////////////////////////////////////////////////////////////////
// Windows does not do the .element = value, structure initialization
// that GNU does, so must make that the ENTIRE structure is populated,
// and IN ORDER...ugh..
#define STRUCT_INIT(ELEMENT,VALUE) VALUE

//////////////////////////////////////////////////////////////////////
// OSAL handle types
typedef struct osal_file_handle_t
{
    OSAL_FILE_HANDLE_REQUIRED_ELEMENTS
    OVERLAPPED ov;
    HANDLE fileHandle;
    uint32 fileSize;
} osal_file_handle_t;


typedef struct osal_maemem_handle_t
{
    OSAL_MAEMEM_HANDLE_REQUIRED_ELEMENTS
    HANDLE fd;
#ifdef UNDER_CE
	HANDLE hMemPool;
	MEM_IOCTL MAEMEM;
	MEM_IOCTL YUVMEM;
#endif
} osal_maemem_handle_t;


typedef struct osal_maefe_handle_t
{
    OSAL_MAEFE_HANDLE_REQUIRED_ELEMENTS
    HANDLE fd;
} osal_maefe_handle_t;


typedef struct osal_maebsa_handle_t
{
    OSAL_MAEBSA_HANDLE_REQUIRED_ELEMENTS
    HANDLE fd;
} osal_maebsa_handle_t;


typedef struct osal_maempe_handle_t
{
    OSAL_MAEMPE_HANDLE_REQUIRED_ELEMENTS
    HANDLE fd;
} osal_maempe_handle_t;


typedef struct osal_maebe_handle_t
{
    OSAL_MAEBE_HANDLE_REQUIRED_ELEMENTS
    HANDLE fd;
    HANDLE memFd;
} osal_maebe_handle_t;


typedef struct osal_maelcd_handle_t
{
    OSAL_MAELCD_HANDLE_REQUIRED_ELEMENTS
	HDC hDC;
    int win_which;
#ifdef UNDER_CE
	HANDLE hMemPool;
	MEM_IOCTL LCDMEM;
#endif
} osal_maelcd_handle_t;



//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
// Mutex

typedef struct osal_mutex_handle_t
{
	CRITICAL_SECTION _cs;
} osal_mutex_handle_t;
#define OSAL_MUTEX_HANDLE(NAME) osal_mutex_handle_t NAME

#define OSAL_MUTEX_HANDLE_INIT(NAME) \
	InitializeCriticalSection(& NAME._cs)

#define OSAL_MUTEX_HANDLE_DEINIT(NAME) \
	DeleteCriticalSection(& NAME._cs)

#define OSAL_MUTEX_CS_ENTER(NAME) \
	EnterCriticalSection(& NAME._cs)

#define OSAL_MUTEX_CS_EXIT(NAME) \
	LeaveCriticalSection(& NAME._cs)


//////////////////////////////////////////////////////////////////////
// Events

typedef struct osal_event_handle_t
{
    OSAL_EVENT_HANDLE_REQUIRED_ELEMENTS
	HANDLE _handle;
} osal_event_handle_t;
#define OSAL_EVENT_HANDLE(NAME) osal_event_handle_t NAME

#define OSAL_EVENT_CREATE(NAME) \
{ \
    NAME._handle = CreateEvent(NULL, FALSE, FALSE, NULL); \
}

#define OSAL_EVENT_RESET(NAME) \
{ \
    ResetEvent(NAME._handle); \
}

#define OSAL_EVENT_SIGNAL(NAME) \
{ \
    SetEvent(NAME._handle); \
}

#define OSAL_EVENT_TIMED_WAIT(NAME, TIMEOUT) \
{ \
	WaitForSingleObject(NAME._handle, TIMEOUT * 1000); \
}

#define OSAL_EVENT_WAIT(NAME) \
{ \
	WaitForSingleObject(NAME._handle, INFINITE); \
}

#define OSAL_EVENT_DESTROY(NAME) \
{ \
    CloseHandle(NAME._handle); \
    NAME._handle = NULL; \
}

//////////////////////////////////////////////////////////////////////
// Threads

#define OSAL_THREAD_HANDLE(TNAME) \
struct \
{ \
	DWORD _ThreadId; \
	HANDLE _handle; \
} osal_thread_##TNAME

void osalSetThreadPriority (HANDLE hThread, int nPriority);
#define OSAL_THREAD_CREATE(TNAME, DESCRIPTION, PRIORITY) \
{ \
	osal_thread_##TNAME._handle = CreateThread( \
                     NULL, \
                     0, \
					 (LPTHREAD_START_ROUTINE) TNAME ## _thread, \
                     NULL, \
                     CREATE_SUSPENDED, \
					 & osal_thread_##TNAME._ThreadId); \
    osalSetThreadPriority(osal_thread_##TNAME._handle, PRIORITY); \
}

#define OSAL_THREAD_START(TNAME) \
	ResumeThread(osal_thread_##TNAME._handle)

#define OSAL_THREAD_STOP(TNAME) \
	WaitForSingleObject(osal_thread_##TNAME._handle, INFINITE)

#define OSAL_THREAD_DESTROY(TNAME) \
{ \
    CloseHandle(osal_thread_##TNAME._handle); \
    osal_thread_##TNAME._handle = NULL; \
}

//////////////////////////////////////////////////////////////////////
// Queues

#define OSAL_QUEUE_HANDLE(TYPE, QNAME) \
struct \
{ \
	CRITICAL_SECTION _cs; \
	HANDLE _event; \
    int _cancel; \
    int _waiting; \
    volatile unsigned int _size; \
    TYPE             *Free; \
    TYPE             *InUse; \
} QNAME

#define OSAL_QUEUE_HEAD_FREE(QNAME) QNAME.Free
#define OSAL_QUEUE_HEAD_INUSE(QNAME) QNAME.InUse
#define OSAL_QUEUE_SIZE(QNAME) QNAME._size

#define OSAL_QUEUE_HANDLE_INIT(QNAME) \
{ \
    InitializeCriticalSection(& QNAME._cs); \
    QNAME._event = CreateEvent(NULL, FALSE, FALSE, NULL); \
    QNAME.Free = NULL; \
    QNAME.InUse = NULL; \
    QNAME._size = 0; \
    QNAME._waiting = 0; \
    queue_register(#QNAME, &QNAME._size); \
}

#define OSAL_QUEUE_HANDLE_DEINIT(QNAME) \
{ \
    CloseHandle(QNAME._event); \
    DeleteCriticalSection(& QNAME._cs); \
    QNAME._event = NULL; \
}

#define OSAL_QUEUE_CS_ENTER(QNAME) \
    EnterCriticalSection(& QNAME._cs)

#define OSAL_QUEUE_CS_EXIT(QNAME) \
    LeaveCriticalSection(& QNAME._cs)

// Call to cancel thread waiting on queue element
#define OSAL_QUEUE_CANCEL_BLOCKING_CALL(QNAME) \
    EnterCriticalSection(& QNAME._cs); \
    if (QNAME._waiting) \
    { \
        QNAME._cancel = 1; \
        SetEvent(QNAME._event); \
    } \
    LeaveCriticalSection(& QNAME._cs)

#define OSAL_QUEUE_MOVE_ELEMENT_FREE_TO_INUSE(TYPE, QNAME, VARIABLE, NEXT, PREV) \
    DLCL_REMOVE_NP(TYPE, QNAME.Free, VARIABLE, NEXT, PREV); \
    DLCL_APPEND_NP(TYPE, QNAME.InUse, VARIABLE, NEXT, PREV)

#define OSAL_QUEUE_MOVE_ELEMENT_INUSE_TO_FREE(TYPE, QNAME, VARIABLE, NEXT, PREV) \
    DLCL_APPEND_NP(TYPE, QNAME.InUse, VARIABLE, NEXT, PREV); \
    DLCL_REMOVE_NP(TYPE, QNAME.Free, VARIABLE, NEXT, PREV)

// Basically a waitfor_object()
#define OSAL_QUEUE_REMOVE_ELEMENT(TYPE, QNAME, VARIABLE, NEXT, PREV, EXPR, BLOCK, TIMEOUT, INUSE, CODE) \
    EnterCriticalSection(& QNAME._cs);                                      \
    VARIABLE = NULL;                                                        \
    while (1)                                                               \
    {                                                                       \
        if (QNAME._cancel && BLOCK)                                         \
        {                                                                   \
            break;                                                          \
        }                                                                   \
        if (((VARIABLE = QNAME.Free) != NULL) && (EXPR))                    \
        {                                                                   \
            --QNAME._size;                                                  \
            DLCL_REMOVE_NP(TYPE, QNAME.Free, VARIABLE, NEXT, PREV)          \
            if (INUSE) DLCL_APPEND_NP(TYPE, QNAME.InUse, VARIABLE, NEXT, PREV); \
            { CODE ; }                                                      \
            break;                                                          \
        }                                                                   \
        else                                                                \
        if (BLOCK)                                                          \
        {                                                                   \
            ++QNAME._waiting;                                               \
            if ((int)TIMEOUT > 0)                                           \
            {                                                               \
            }                                                               \
            else                                                            \
            {                                                               \
                LeaveCriticalSection(& QNAME._cs);                          \
                WaitForSingleObject(QNAME._event, INFINITE);                \
                EnterCriticalSection(& QNAME._cs);                          \
            }                                                               \
            --QNAME._waiting;                                               \
        }                                                                   \
        else break;                                                         \
    }                                                                       \
    QNAME._cancel = 0;                                                      \
    LeaveCriticalSection(& QNAME._cs)

// Basically a signal_object()
#define OSAL_QUEUE_ADD_ELEMENT(TYPE, QNAME, VARIABLE, NEXT, PREV, INUSE, EXPR, CODE)     \
    EnterCriticalSection(& QNAME._cs);                                      \
    if (EXPR)                                                               \
    {                                                                       \
        CODE                                                                \
        if (INUSE) DLCL_REMOVE_NP(TYPE, QNAME.InUse, VARIABLE, NEXT, PREV)  \
        DLCL_APPEND_NP(TYPE, QNAME.Free, VARIABLE, NEXT, PREV);             \
        SetEvent(QNAME._event);                                             \
        ++QNAME._size;                                                      \
    }                                                                       \
    LeaveCriticalSection(& QNAME._cs)

#define OSAL_QUEUE_ADD_CHAIN(TYPE, QNAME, VARIABLE, NEXT, PREV, INUSE, EXPR, CODE)       \
    EnterCriticalSection(& QNAME._cs);                                      \
    if (EXPR)                                                               \
    {                                                                       \
        TYPE *first = VARIABLE; /* snapshot before head changes */          \
        TYPE *curr, *next;                                                  \
        CODE                                                                \
        curr = VARIABLE;                                                    \
        do                                                                  \
        {                                                                   \
            next = curr->NEXT; /* capture before next/prev change */        \
            if (INUSE) DLCL_REMOVE_NP(TYPE, QNAME.InUse, curr, NEXT, PREV)  \
            DLCL_APPEND_NP(TYPE, QNAME.Free, curr, NEXT, PREV);             \
            ++QNAME._size;                                                  \
            curr = next;                                                    \
        } while (curr != first);                                            \
        SetEvent(QNAME._event);                                             \
    }                                                                       \
    LeaveCriticalSection(& QNAME._cs)

//////////////////////////////////////////////////////////////////////

extern void osal_kdprint(const char *fmt, ...);

#define OSAL_VSNPRINTF_FUNCTION  _vsnprintf
#define OSAL_PRINTF_FUNCTION     osal_kdprint
#define OSAL_LOG_FLUSH           ;

#define osal_counter_frequency() (660*1000*1000) // cheat for now


/*
 * Copyright 2008 RMI Corporation
 * Author: Kevin Hickey <khickey@rmicorp.com>
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  either version 2 of the  License, or (at your
 *  option) any later version.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef AU_MEMPOOL_H
#define AU_MEMPOOL_H

#define AU_MEMPOOL_BLOCK_MAJOR 235

#define AU_MEMPOOL_IOCTL_ALLOC	            5
#define AU_MEMPOOL_IOCTL_FREE	            6
#define AU_MEMPOOL_IOCTL_PRINT	            7
#define AU_MEMPOOL_IOCTL_SET_CACHEABLE      9
#define AU_MEMPOOL_IOCTL_SET_NONCACHEABLE   10

#define AU_MAX_MEMPOOLS 3
#define KB 1024
#define MB (1024 * KB)

#define u32 uint32_t

/*
 * A mempool region, used by ioctl to pass information between the kernel and user.
 * @name: The name of the pool configuring this region.  Set by ioctl.
 * @phys: The physical address of the allocated memory.  Set by ioctl.
 * @virt: A placeholder for the user to store the virtual address if mapped by mmap.
 * The ioctl does NOT set this to a useful value; you must mmap the memory if
 * it is to be used in user space.
 * @size: The size of the region.  Set before calling ioctl.
 * @desc: A pointer to the descriptor, used by the driver for housekeeping.
 */
struct au_mempool_region {
	const char 	*name;
	void		*phys;
	void		*virt;
	u32		size;

	void		*desc;
};

#endif /* AU_MEMPOOL_H */

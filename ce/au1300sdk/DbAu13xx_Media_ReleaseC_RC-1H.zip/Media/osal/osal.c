
//////////////////////////////////////////////////////////////////////

#if defined(WIN32) || defined(_WIN32_WCE)
#include "../osal/win32cfg.c"
#else
#include "linuxcfg.c"
#endif



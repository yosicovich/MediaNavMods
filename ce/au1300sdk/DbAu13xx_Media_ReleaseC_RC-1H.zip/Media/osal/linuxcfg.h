
/*
 *    File: osal/linuxcfg.h
 *  Author: Eric DeVolder
 * Purpose: Interface to osal/linuxcfg.c
 *   Notes:
 *
 */

#define _FILE_OFFSET_BITS 64 // video creates large files

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <ctype.h>
#include <stdint.h>

#include "ctypes.h"
#include "dlcl.h"
#include "bitbuffer.h"

#include "drivers/maeioctl.h"

#include "au_mempool.h"
#undef u32

//////////////////////////////////////////////////////////////////////
// Assuming GNU GCC
#define STRUCT_INIT(ELEMENT,VALUE) .ELEMENT = VALUE

//////////////////////////////////////////////////////////////////////
// OSAL handle types
typedef struct osal_file_handle_t
{
    OSAL_FILE_HANDLE_REQUIRED_ELEMENTS
    int fd;
    uint32 fileSize;
} osal_file_handle_t;


typedef struct osal_maemem_handle_t
{
    OSAL_MAEMEM_HANDLE_REQUIRED_ELEMENTS
    int maeFd, yuvFd;
    struct au_mempool_region maeRegion;
    struct au_mempool_region yuvRegion;
} osal_maemem_handle_t;


typedef struct osal_maefe_handle_t
{
    OSAL_MAEFE_HANDLE_REQUIRED_ELEMENTS
    int fd;
} osal_maefe_handle_t;


typedef struct osal_maebsa_handle_t
{
    OSAL_MAEBSA_HANDLE_REQUIRED_ELEMENTS
    int fd;
} osal_maebsa_handle_t;


typedef struct osal_maempe_handle_t
{
    OSAL_MAEMPE_HANDLE_REQUIRED_ELEMENTS
    int fd;
} osal_maempe_handle_t;


typedef struct osal_maebe_handle_t
{
    OSAL_MAEBE_HANDLE_REQUIRED_ELEMENTS
    int fd;
    int memFd;
    int csc;
    struct au_mempool_region region;
} osal_maebe_handle_t;


typedef struct osal_maelcd_handle_t
{
    OSAL_MAELCD_HANDLE_REQUIRED_ELEMENTS
    int fd; // /dev/fbX
#ifdef APP_PLAYER
    int fd2; // /dev/maelcd
#endif
    int win_which;
    struct au_mempool_region region;
} osal_maelcd_handle_t;



//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
// Mutex

typedef struct osal_mutex_handle_t
{
    pthread_mutex_t  _mutex;
    pthread_cond_t   _cond;
} osal_mutex_handle_t;
#define OSAL_MUTEX_HANDLE(NAME) osal_mutex_handle_t NAME

#define OSAL_MUTEX_HANDLE_INIT(NAME) \
{ \
    pthread_mutex_init(& NAME._mutex, NULL); \
    pthread_cond_init(& NAME._cond, NULL); \
}

#define OSAL_MUTEX_HANDLE_DEINIT(NAME)          \
{ \
    pthread_mutex_destroy(& NAME._mutex); \
    pthread_cond_destroy(& NAME._cond); \
}

#define OSAL_MUTEX_CS_ENTER(NAME) \
    pthread_mutex_lock(& NAME._mutex)

#define OSAL_MUTEX_CS_EXIT(NAME) \
    pthread_mutex_unlock(& NAME._mutex)


//////////////////////////////////////////////////////////////////////
// Events

typedef struct osal_event_handle_t
{
    OSAL_EVENT_HANDLE_REQUIRED_ELEMENTS
    pthread_mutex_t _mutex;
    pthread_cond_t  _cond;
    int _value;
} osal_event_handle_t;
#define OSAL_EVENT_HANDLE(NAME) osal_event_handle_t NAME

#define OSAL_EVENT_CREATE(NAME) \
{ \
    pthread_mutex_init(& NAME._mutex, NULL); \
    pthread_cond_init(& NAME._cond, NULL); \
    NAME._value = 0; \
}

#define OSAL_EVENT_RESET(NAME) \
{ \
    pthread_mutex_lock(& NAME._mutex); \
    NAME._value = 0; \
    pthread_mutex_unlock(& NAME._mutex); \
}

#define OSAL_EVENT_SIGNAL(NAME) \
{ \
    pthread_mutex_lock(& NAME._mutex); \
    NAME._value = 1; \
    pthread_cond_signal(& NAME._cond); \
    pthread_mutex_unlock(& NAME._mutex); \
}

#define OSAL_EVENT_WAIT(NAME) \
{ \
    pthread_mutex_lock(& NAME._mutex); \
    if (NAME._value) \
    { \
        /* event has already happened, reset and return */ \
        NAME._value = 0; \
    } \
    else \
    { \
        pthread_cond_wait(& NAME._cond, & NAME._mutex); \
    } \
    pthread_mutex_unlock(& NAME._mutex); \
}

#define OSAL_EVENT_TIMED_WAIT(NAME, TIMEOUT) \
{ \
    pthread_mutex_lock(& NAME._mutex); \
    if (NAME._value) \
    { \
        /* event has already happened, reset and return */ \
        NAME._value = 0; \
    } \
    else \
    { \
        struct timespec abstime;                                            \
        time(&abstime.tv_sec);                                              \
        abstime.tv_sec += TIMEOUT;                                          \
        pthread_cond_timedwait(& NAME._cond, & NAME._mutex, &abstime);      \
    } \
    pthread_mutex_unlock(& NAME._mutex); \
}

#define OSAL_EVENT_DESTROY(NAME) \
{ \
    NAME._value = -1; \
}

//////////////////////////////////////////////////////////////////////
// Threads

#define OSAL_THREAD_HANDLE(TNAME) \
struct \
{ \
    pthread_t _thread_id; \
} osal_thread_##TNAME

#define OSAL_THREAD_CREATE(TNAME, DESCRIPTION, PRIORITY)                \
    pthread_create(& osal_thread_##TNAME._thread_id, NULL, TNAME ## _thread, NULL)

#define OSAL_THREAD_START(TNAME)

#define OSAL_THREAD_STOP(TNAME)                                         \
    pthread_join(osal_thread_##TNAME._thread_id, NULL)

#define OSAL_THREAD_DESTROY(TNAME)

//////////////////////////////////////////////////////////////////////
// Queues

#define OSAL_QUEUE_HANDLE(TYPE, QNAME) \
struct \
{ \
    pthread_mutex_t  _mutex; \
    pthread_cond_t   _cond; \
    int _cancel; \
    int _waiting; \
    volatile unsigned int _size; \
    TYPE             *Free; \
    TYPE             *InUse; \
} QNAME

#define OSAL_QUEUE_HEAD_FREE(QNAME) QNAME.Free
#define OSAL_QUEUE_HEAD_INUSE(QNAME) QNAME.InUse
#define OSAL_QUEUE_SIZE(QNAME) QNAME._size

#define OSAL_QUEUE_HANDLE_INIT(QNAME) \
{ \
    pthread_mutex_init(& QNAME._mutex, NULL); \
    pthread_cond_init(& QNAME._cond, NULL); \
    QNAME.Free = NULL; \
    QNAME.InUse = NULL; \
    QNAME._size = 0; \
    QNAME._cancel = 0; \
    QNAME._waiting = 0; \
    queue_register(#QNAME, &QNAME._size); \
}

#define OSAL_QUEUE_HANDLE_DEINIT(QNAME)         \
{ \
    pthread_mutex_destroy(& QNAME._mutex); \
    pthread_cond_destroy(& QNAME._cond); \
}

#define OSAL_QUEUE_CS_ENTER(QNAME) \
    pthread_mutex_lock(& QNAME._mutex)

#define OSAL_QUEUE_CS_EXIT(QNAME) \
    pthread_mutex_unlock(& QNAME._mutex)

// Call to cancel thread waiting on queue element
#define OSAL_QUEUE_CANCEL_BLOCKING_CALL(QNAME) \
    pthread_mutex_lock(& QNAME._mutex); \
    if (QNAME._waiting) \
    { \
        QNAME._cancel = 1; \
        pthread_cond_signal(& QNAME._cond); \
    } \
    pthread_mutex_unlock(& QNAME._mutex)

#define OSAL_QUEUE_MOVE_ELEMENT_FREE_TO_INUSE(TYPE, QNAME, VARIABLE, NEXT, PREV) \
    DLCL_REMOVE_NP(TYPE, QNAME.Free, VARIABLE, NEXT, PREV); \
    DLCL_APPEND_NP(TYPE, QNAME.InUse, VARIABLE, NEXT, PREV)

#define OSAL_QUEUE_MOVE_ELEMENT_INUSE_TO_FREE(TYPE, QNAME, VARIABLE, NEXT, PREV) \
    DLCL_APPEND_NP(TYPE, QNAME.InUse, VARIABLE, NEXT, PREV); \
    DLCL_REMOVE_NP(TYPE, QNAME.Free, VARIABLE, NEXT, PREV)

// Basically a waitfor_object()
#define OSAL_QUEUE_REMOVE_ELEMENT(TYPE, QNAME, VARIABLE, NEXT, PREV, EXPR, BLOCK, TIMEOUT, INUSE, CODE) \
    pthread_mutex_lock(& QNAME._mutex);                                     \
    VARIABLE = NULL;                                                        \
    while (1)                                                               \
    {                                                                       \
        if (QNAME._cancel && BLOCK)                                         \
        {                                                                   \
            break;                                                          \
        }                                                                   \
        if (((VARIABLE = QNAME.Free) != NULL) && (EXPR))                    \
        {                                                                   \
            --QNAME._size;                                                  \
            DLCL_REMOVE_NP(TYPE, QNAME.Free, VARIABLE, NEXT, PREV)          \
            if (INUSE) DLCL_APPEND_NP(TYPE, QNAME.InUse, VARIABLE, NEXT, PREV); \
            { CODE ; }                                                      \
            break;                                                          \
        }                                                                   \
        else                                                                \
        if (BLOCK)                                                          \
        {                                                                   \
            ++QNAME._waiting;                                               \
            if ((int)TIMEOUT > 0)                                           \
            {                                                               \
                struct timespec abstime;                                    \
                int rcode;                                                  \
                time(&abstime.tv_sec);                                      \
                abstime.tv_sec += TIMEOUT;                                  \
                rcode = pthread_cond_timedwait(& QNAME._cond, & QNAME._mutex, &abstime); \
                ASSERTEQ(ETIMEDOUT, rcode, errTimedOut, ;, #QNAME " timed out after %d seconds\n", TIMEOUT); \
            }                                                               \
            else                                                            \
                pthread_cond_wait(& QNAME._cond, & QNAME._mutex);           \
            --QNAME._waiting;                                               \
        }                                                                   \
        else break;                                                         \
    }                                                                       \
    QNAME._cancel = 0;                                                      \
    pthread_mutex_unlock(& QNAME._mutex)


// Basically a signal_object()
#define OSAL_QUEUE_ADD_ELEMENT(TYPE, QNAME, VARIABLE, NEXT, PREV, INUSE, EXPR, CODE)     \
    pthread_mutex_lock(& QNAME._mutex);                                     \
    if (EXPR)                                                               \
    {                                                                       \
        CODE                                                                \
        if (INUSE) DLCL_REMOVE_NP(TYPE, QNAME.InUse, VARIABLE, NEXT, PREV)  \
        DLCL_APPEND_NP(TYPE, QNAME.Free, VARIABLE, NEXT, PREV);             \
        pthread_cond_signal(& QNAME._cond);                                 \
        ++QNAME._size;                                                      \
    }                                                                       \
    pthread_mutex_unlock(& QNAME._mutex);


#define OSAL_QUEUE_ADD_CHAIN(TYPE, QNAME, VARIABLE, NEXT, PREV, INUSE, EXPR, CODE)       \
    pthread_mutex_lock(& QNAME._mutex);                                     \
    if (EXPR)                                                               \
    {                                                                       \
        TYPE *first = VARIABLE; /* snapshot before head changes */          \
        TYPE *curr, *next;                                                  \
        CODE                                                                \
        curr = VARIABLE;                                                    \
        do                                                                  \
        {                                                                   \
            next = curr->NEXT; /* capture before next/prev change */        \
            if (INUSE) DLCL_REMOVE_NP(TYPE, QNAME.InUse, curr, NEXT, PREV)  \
            DLCL_APPEND_NP(TYPE, QNAME.Free, curr, NEXT, PREV);             \
            ++QNAME._size;                                                  \
            curr = next;                                                    \
        } while (curr != first);                                            \
        pthread_cond_signal(& QNAME._cond);                                 \
    }                                                                       \
    pthread_mutex_unlock(& QNAME._mutex);


//////////////////////////////////////////////////////////////////////

#define OSAL_VSNPRINTF_FUNCTION  vsnprintf
#define OSAL_PRINTF_FUNCTION     printf
#define OSAL_LOG_FLUSH           fflush(stdout)

#define osal_counter_frequency() (660*1000*1000) // cheat for now



/*
 *    File: osal/linuxcfg.c
 *  Author: Eric DeVolder
 * Purpose: OS abstraction for Linux
 *   Notes:
 *
 */

// This file contains all the ugly glue code

#include <osal.h>
#include <logging.h>
#include <asserts.h>

#include <stdarg.h>

#ifdef MAE
#define NODE_MAEMEM "/dev/maemem"
#define NODE_MAEFE  "/dev/maefe"
#define NODE_MAEBE  "/dev/maebe"
#define NODE_MAELCD "/dev/maelcd"
#define NO_MAE_HW_MAE_MEM_PHYSADDR 0x04000000 // Fixed address so does not vary between builds
#define NO_MAE_HW_YUV_MEM_PHYSADDR 0x08000000 // Fixed address so does not vary between builds
#define NO_MAE_HW_MAE_MEM_SIZE (16*1024*1024) // FIX!!! What are real max sizes???
#define NO_MAE_HW_YUV_MEM_SIZE (16*1024*1024) // FIX!!! What are real max sizes???
#endif

#ifdef MAE2
#include "bsa.h"
#define NODE_MAEMEM "/dev/maemem"
#define NODE_MAEBSA "/dev/maebsa"
#define NODE_MAEMPE "/dev/maempe"
#define NODE_MAEBE  "/dev/maeite"
#define NODE_MAELCD "/dev/maelcd"
// Values from doc/mae2buffers.ods spreadsheet
#if ((MAX_WIDTH_IN_MBS * MAX_HEIGHT_IN_MBS) > 1620)
// 720p
#define NO_MAE_HW_MAE_MEM_PHYSADDR 0x04000000 // Fixed address so does not vary between builds
#define NO_MAE_HW_YUV_MEM_PHYSADDR 0x08000000 // Fixed address so does not vary between builds
#define NO_MAE_HW_MAE_MEM_SIZE (64*1024*1024)
#define NO_MAE_HW_YUV_MEM_SIZE (28*1024*1024)
#else
// SD
#define NO_MAE_HW_MAE_MEM_PHYSADDR 0x04000000 // Fixed address so does not vary between builds
#define NO_MAE_HW_YUV_MEM_PHYSADDR 0x08000000 // Fixed address so does not vary between builds
#define NO_MAE_HW_MAE_MEM_SIZE (29*1024*1024)
#define NO_MAE_HW_YUV_MEM_SIZE (11*1024*1024)
#endif
#endif

#define MEMPOOL_MAE            "/dev/mempool_bsa" // FIXME: rename to MAE
#define MEMPOOL_MAE_CACHEABLE  0

#define MEMPOOL_YUV            "/dev/mempool_mpe" // FIXME: rename to YUV
#define MEMPOOL_YUV_CACHEABLE  1

#define MEMPOOL_RGB            "/dev/mempool_lcd"
#define MEMPOOL_RGB_SIZE       (1024*768*4*4)
#define MEMPOOL_RGB_CACHEABLE  1

int lcdWindowLeftJustify = 0;
int lcdWindowRightJustify = 0;

//////////////////////////////////////////////////////////////////////

void
osal_sleep_seconds (int seconds)
{
    sleep(seconds);
}

void
osal_sleep_milliseconds (int milliseconds)
{
    usleep(milliseconds * 1000);
}

int
osal_random (void)
{
    return (int)random();
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
int
osal_file_open (osal_file_handle_t *h, const char *path, int flags)
{
    int oFlags = 0;
    struct stat fdstat;

    if (flags & OSAL_FILE_FLAGS_READ) oFlags |= O_RDONLY;
    if (flags & OSAL_FILE_FLAGS_WRITE) oFlags |= O_WRONLY;
    if (flags & OSAL_FILE_FLAGS_CREATE) oFlags |= O_CREAT;
    if (flags & OSAL_FILE_FLAGS_TRUNCATE) oFlags |= O_TRUNC;

    h->fd = open(path, oFlags, 0666);
    fstat(h->fd, &fdstat);
    // FIX!!!! do stat() to determine optimal read length???
    h->fileSize = fdstat.st_size;

    h->valid = (h->fd > 0);

    return (h->fd < 0); // return value of 0 means OK
}

int
osal_file_read (osal_file_handle_t *h, unsigned int position, void *buffer, int size)
{
    int rcode = 0;

    if (h->valid)
    {
        rcode = (unsigned int)lseek(h->fd, position, SEEK_SET); //return (rcode != position); // return value of 0 means OK
        rcode = read(h->fd, buffer, size);
    }

    return rcode; // return value is number of bytes read
}

int
osal_file_write (osal_file_handle_t *h, const void *buffer, int size)
{
    int rcode = 0;

    if (h->valid)
    {
        rcode = write(h->fd, buffer, size);
    }

    return rcode;
}

void
osal_file_sync (osal_file_handle_t *h)
{
    sync();
}

void
osal_file_close (osal_file_handle_t *h)
{
    if (h->valid)
    {
        close(h->fd);
        h->valid = 0;
    }
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

#if defined(LIBADHD) // FIX!!! should be based on EJDmaeme or not
static void
mempool_init (const char *mempool_path, unsigned int size, unsigned int cacheable, int *fd, struct au_mempool_region *region)
{
    int res;

    *fd = open(mempool_path, O_RDWR);

    if (*fd < 0)
    {
        ASSERTEQ(0, 0, errFileFailed, ;, "Mempool '%s' cannot be opened: %d!\n", mempool_path, *fd);
    }

    region->size = size;
    region->phys = NULL;
    region->virt = NULL;

    res = ioctl(*fd, AU_MEMPOOL_IOCTL_ALLOC, region);
    if (res || region->phys == 0)
    {
        ASSERTEQ(0, 0, errAllocFailed, ;, "Alloc failed for %s of size %dKB: %d / %p!\n",
                 mempool_path, size/1024, res, region->phys);
    }

    res = ioctl(*fd, cacheable ? AU_MEMPOOL_IOCTL_SET_CACHEABLE : AU_MEMPOOL_IOCTL_SET_NONCACHEABLE, region);
    ASSERTNE(0, res, errAllocFailed, ;, "Alloc failed for cacheability of %s: %d!\n", mempool_path, res);

    region->virt = mmap((caddr_t)0,
                        region->size,
                        PROT_READ | PROT_WRITE,
                        MAP_SHARED,
                        *fd,
                        (uint32) region->phys);

    ASSERTEQ(NULL, region->virt, errAllocFailed, ;, "mmap failed for %s\n", mempool_path);
}

static void
mempool_deinit (int *fd, struct au_mempool_region *region)
{
    if (*fd && region->virt)
    {
        munmap(region->virt, region->size);
        ioctl(*fd, AU_MEMPOOL_IOCTL_FREE, region);
        close(*fd);
        *fd = 0;
    }
}
#endif

//////////////////////////////////////////////////////////////////////
#ifdef NO_MAE_HW
uint32 _maemem[NO_MAE_HW_MAE_MEM_SIZE/4];
uint32 _yuvmem[NO_MAE_HW_YUV_MEM_SIZE/4];
#endif

void
osal_maemem_driver_open (osal_maemem_handle_t *h, int mae_size, int yuv_size)
{
    h->counterFrequency = osal_counter_frequency();
    h->physAddr = 0;
    h->physSize = 0;
    h->virtAddr = 0;

#if defined(NO_MAE_HW)
    memset(_maemem, 0xED, sizeof(_maemem)); // filling with zeros is bad since it hides problems with detecting end of slice data
    h->physAddr = NO_MAE_HW_MAE_MEM_PHYSADDR;
    h->physSize = sizeof(_maemem);
    h->virtAddr = (void *)_maemem;

    h->YUVphysAddr = NO_MAE_HW_YUV_MEM_PHYSADDR;
    h->YUVphysSize = sizeof(_yuvmem);
    h->YUVvirtAddr = (void *)_yuvmem;

    //LOG(NOTIFY,"MAEMEM: MAE physAddr %08X, physSize %08X\n", h->physAddr, h->physSize);
    //LOG(NOTIFY,"MAEMEM: YUV physAddr %08X, physSize %08X\n", h->YUVphysAddr, h->YUVphysSize);
#else // NO_MAE_HW

#if defined(LIBADHD)
    // TODO: Need counter freq
    mempool_init(MEMPOOL_MAE, mae_size, MEMPOOL_MAE_CACHEABLE, &h->maeFd, &h->maeRegion);
    h->physAddr = (uint32)h->maeRegion.phys;
    h->physSize = h->maeRegion.size;
    h->virtAddr = h->maeRegion.virt;

    mempool_init(MEMPOOL_YUV, yuv_size, MEMPOOL_YUV_CACHEABLE, &h->yuvFd, &h->yuvRegion);
    h->YUVphysAddr = (uint32)h->yuvRegion.phys;
    h->YUVphysSize = h->yuvRegion.size;
    h->YUVvirtAddr = h->yuvRegion.virt;
#endif

#if defined(APP_PLAYER) && (defined(MAE) || defined(MAE2))
    {
    mae_mem_request_t req;

    h->maeFd = open(NODE_MAEMEM, O_RDWR);
    ASSERTLT(h->maeFd, 0, errFileFailed, ;, "open of %s failed %d\n", NODE_MAEMEM, h->maeFd);

    req.flags = 0;
    req.magic = MAEMEM_MAGIC;
    req.instance = 0;
    ioctl(h->maeFd, 0, (void *)&req);
    h->physAddr = req.physAddr;
    h->physSize = req.physSize;
    h->YUVphysAddr = req.YUVphysAddr;
    h->YUVphysSize = req.YUVphysSize;
    h->counterFrequency = req.counterFreq;
    h->virtAddr  = (void*)mmap((caddr_t)0, h->physSize, PROT_READ | PROT_WRITE, MAP_SHARED, h->maeFd, (off_t)0);
    h->YUVvirtAddr  = (void*)mmap((caddr_t)0, h->YUVphysSize, PROT_READ | PROT_WRITE, MAP_SHARED, h->maeFd, (off_t)0);
    }
#endif

#endif // NO_MAE_HW

    ASSERTEQ(0, h->physAddr, errAllocFailed, ;, "MAEMEM mem buffer not provided\n");
    ASSERTEQ(0, h->physSize, errAllocFailed, ;, "MAEMEM mem buffer not provided\n");
    ASSERTEQ(0, h->virtAddr, errAllocFailed, ;, "MAEMEM mem buffer not provided\n");
    ASSERTEQ(0, h->YUVphysAddr, errAllocFailed, ;, "MAEMEM YUV buffer not provided\n");
    ASSERTEQ(0, h->YUVphysSize, errAllocFailed, ;, "MAEMEM YUV buffer not provided\n");
    ASSERTEQ(0, h->YUVvirtAddr, errAllocFailed, ;, "MAEMEM YUV buffer not provided\n");
}

void
osal_maemem_driver_close (osal_maemem_handle_t *h)
{
#if defined(APP_PLAYER) && !defined(NO_MAE_HW) && (defined(MAE) || defined(MAE2))
    munmap(h->virtAddr, h->physSize);
    munmap(h->YUVvirtAddr, h->YUVphysSize);
    close(h->maeFd);
#endif

#if defined(LIBADHD)
    mempool_deinit(&h->maeFd, &h->maeRegion);
    mempool_deinit(&h->yuvFd, &h->yuvRegion);
#endif
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
void
osal_maefe_driver_open (osal_maefe_handle_t *h)
{
    h->counterFrequency = osal_counter_frequency();

#if defined(NO_MAE_HW)
    h->fd = 0;
#endif

#if !defined(NO_MAE_HW) && defined(MAE)
    h->fd = open(NODE_MAEFE, O_RDWR);
    ASSERTLT(h->fd, 0, errFileFailed, ;, "open of %s failed %d\n", NODE_MAEFE, h->fd);
#endif
}

void
osal_maefe_driver_submit (osal_maefe_handle_t *h, mae_fe_request_t *req)
{
#if !defined(NO_MAE_HW) && defined(MAE)
    ioctl(h->fd, MAEFE_IOCTL_SUBMIT_TRANSACTION, req);
#endif
}

void
osal_maefe_driver_close (osal_maefe_handle_t *h)
{
#if !defined(NO_MAE_HW) && defined(MAE)
    close(h->fd);
#endif
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
void
osal_maebsa_driver_open (osal_maebsa_handle_t *h)
{
    h->counterFrequency = osal_counter_frequency();

#if defined(NO_MAE_HW)
    h->fd = 0;
#endif

#if !defined(NO_MAE_HW) && defined(MAE2)
    h->fd = open(NODE_MAEBSA, O_RDWR);
    ASSERTLT(h->fd, 0, errFileFailed, ;, "open of %s failed %d\n", NODE_MAEBSA, h->fd);
#endif
}

void
osal_maebsa_driver_submit (osal_maebsa_handle_t *h, mae_bsa_request_t *req)
{
#if defined(APP_PLAYER) && defined(NO_MAE_HW)
    rsleep(32);
#endif

#if defined(NO_MAE_HW) && defined(MAE2)
    req->bsaStatus = SCB_STATUS_DONE;
#endif

#if !defined(NO_MAE_HW) && defined(MAE2)
  {
    int result;
    result = ioctl(h->fd, MAEBSA_IOCTL_SUBMIT_TRANSACTION, req);
#ifdef DEBUG
    ASSERTNE(result, 0, errMAEFailed, ;, "BSA failed: %d\n", result);
#endif
  }
#endif
}

void
osal_maebsa_driver_close (osal_maebsa_handle_t *h)
{
#if !defined(NO_MAE_HW) && defined(MAE2)
    close(h->fd);
#endif
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
void
osal_maempe_driver_open (osal_maempe_handle_t *h)
{
    h->counterFrequency = osal_counter_frequency();

#if defined(NO_MAE_HW)
    h->fd = 0;
#endif

#if !defined(NO_MAE_HW) && defined(MAE2)
    h->fd = open(NODE_MAEMPE, O_RDWR);
    ASSERTLT(h->fd, 0, errFileFailed, ;, "open of %s failed %d\n", NODE_MAEMPE, h->fd);
#endif
}

void
osal_maempe_driver_submit (osal_maempe_handle_t *h, mae_mpe_request_t *req)
{
#if defined(APP_PLAYER) && defined(NO_MAE_HW)
    rsleep(25);
#endif

#if !defined(NO_MAE_HW) && defined(MAE2)
    int result;
    result = ioctl(h->fd, MAEMPE_IOCTL_SUBMIT_TRANSACTION, req);
#ifdef DEBUG
    ASSERTNE(result, 0, errMAEFailed, ;, "%s() failed: %d\n", __FUNCTION__, result);
#endif
#endif
}

void
osal_maempe_driver_close (osal_maempe_handle_t *h)
{
#if !defined(NO_MAE_HW) && defined(MAE2)
    close(h->fd);
#endif
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

// NOTE: For Travis/MAE, about 8MB is enough for YUVs
// NOTE: For Monet/MAE2, for SD, about 10MB is enough for YUVs
// NOTE: For Monet/MAE2, for 720p, about 24MB is enough for YUVs

void
osal_maebe_driver_open (osal_maebe_handle_t *h)
{
    h->counterFrequency = osal_counter_frequency();

#ifdef NO_MAE_HW
    h->fd = 0;
#endif

#if !defined(NO_MAE_HW) && (defined(MAE) || defined(MAE2))
    h->fd = open(NODE_MAEBE, O_RDWR);
    ASSERTLT(h->fd, 0, errFileFailed, ;, "open of %s failed %d\n", NODE_MAEBE, h->fd);
#endif
}

void
osal_maebe_driver_submit (osal_maebe_handle_t *h, struct mae_be_request_t *req)
{
#if defined(APP_PLAYER) && defined(NO_MAE_HW)
    rsleep(10);
#endif

#if !defined(NO_MAE_HW) && (defined(MAE) || defined(MAE2))
    {
    int res;

    ASSERTLT(h->fd, 0, errMAEFailed, ;, "maebe not open %d\n", h->fd);
    res = ioctl(h->fd, MAEBE_IOCTL_SUBMIT_TRANSACTION, (void *)req);
    ASSERTNE(res,0,errMAEFailed, ;, "maebe failed: %d\n", res);
    }
#endif
}

void
osal_maebe_driver_close (osal_maebe_handle_t *h)
{
#if !defined(NO_MAE_HW) && (defined(MAE) || defined(MAE2))
    close(h->fd);
    h->fd = 0;
#endif
}

void
osal_maebe_mem_open (osal_maebe_handle_t *h, int yuv_size)
{
    // Obtain YUV buffers
#if defined(LIBADHD)
    mempool_init(MEMPOOL_YUV, yuv_size, MEMPOOL_YUV_CACHEABLE, &h->memFd, &h->region);

    h->memVirtAddr = h->region.virt;
    h->memPhysAddr = (uint32)h->region.phys;
    h->memPhysSize = h->region.size;
#endif
}

void
osal_maebe_mem_close (osal_maebe_handle_t *h)
{
    // Release YUV buffers
#if defined(LIBADHD)
    mempool_deinit(&h->memFd, &h->region);
#endif
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

#if (defined(APP_PLAYER) || defined(LIBADHD)) && (defined(MAE) || defined(MAE2))

#ifdef MAE
#define AU1200
#endif
#ifdef MAE2
#define AU13XX
#endif
#include "vcodec/alchemy/au1x00.h"
#include <linux/fb.h>

#define MAEHAL_LCD_WINDOW 1

void
osal_maelcd_driver_open (osal_maelcd_handle_t *h)
{
#if !defined(NO_MAE_HW)
    struct fb_fix_screeninfo fb_fix;
    char path[256];

    h->win_which = MAEHAL_LCD_WINDOW;

    sprintf(path, "/dev/fb%d", h->win_which);
    h->fd = open(path, O_RDWR);
    ASSERTLT(h->fd, 0, errFileFailed, ;, "open of %s failed %d\n", path, h->fd);

    if (ioctl(h->fd, FBIOGET_FSCREENINFO, &fb_fix) != 0)
    {
        ASSERTNE(1,0,errFileFailed,;,"ioctl(FBIOGET_FSCREENINFO failed ...)\n");
    }
    h->screen_size = fb_fix.smem_len;

    //h->virtAddr = (void*)mmap((caddr_t)0, fb_fix.smem_len, PROT_READ | PROT_WRITE, MAP_SHARED, h->fd, (off_t)0);
    // NOTE: This is the virtual mapping of the driver defaulted physical memory....

    // Get screen/panel dimensions
    {
    au1200_lcd_iodata_t iodata;
    iodata.subcmd = AU1200_LCD_GET_SCREEN;
    ioctl(h->fd, AU1200_LCD_FB_IOCTL, &iodata);
    h->screen_width = iodata.global.xsize;
    h->screen_height = iodata.global.ysize;
    LOG(DEBUG,"SCREEN %d x %d\n", h->screen_width, h->screen_height);

    // Get window color depth
    iodata.subcmd = AU1200_LCD_GET_WINDOW;
    ioctl(h->fd, AU1200_LCD_FB_IOCTL, &iodata);
    h->win_depth32 = (iodata.window.buffer_format<<25) >= LCD_WINCTRL1_FRM_24BPP;

    // After opening the fb, the overlay is automatically turned on.  Turn it off until we are configured.
    iodata.subcmd = AU1200_LCD_SET_WINDOW;
    iodata.window.enable = 0;
    iodata.window.flags = WIN_ENABLE;
    ioctl(h->fd, AU1200_LCD_FB_IOCTL, &iodata);
    }

#ifdef APP_PLAYER
    {
    mae_lcd_request_t req;
    h->fd2 = open(NODE_MAELCD, O_RDWR);
    ASSERTLT(h->fd2, 0, errFileFailed, ;, "open of %s failed %d\n", NODE_MAELCD, h->fd2);

    // Obtain the memory that will hold the RGB buffers
    req.request = MAEHAL_LCD_GET_MEMORY;
    req.memory.cached = 0;
    ioctl(h->fd2, 0, (void *)&req);

LOG(DEBUG,"LCD win0 phys %08X\n", req.memory.lcdwin0phys);
LOG(DEBUG,"LCD win1 phys %08X\n", req.memory.lcdwin1phys);
LOG(DEBUG,"LCD win2 phys %08X\n", req.memory.lcdwin2phys);
LOG(DEBUG,"LCD win3 phys %08X\n", req.memory.lcdwin3phys);
    switch (h->win_which)
    {
        case 0:
            h->win_physAddr = req.memory.lcdwin0phys;
            break;
        case 1:
            h->win_physAddr = req.memory.lcdwin1phys;
            break;
        case 2:
            h->win_physAddr = req.memory.lcdwin2phys;
            break;
        case 3:
            h->win_physAddr = req.memory.lcdwin3phys;
            break;
    }

    h->physAddr = req.memory.physAddr;
    h->physSize = req.memory.physSize;
    h->virtAddr = (void*)mmap((caddr_t)0, h->physSize, PROT_READ | PROT_WRITE, MAP_SHARED, h->fd2, (off_t)0);
    // NOTE: This is the virtual mapping of the special driver physical memory...
    }

#else

    h->physAddr = fb_fix.smem_start;
    h->physSize = fb_fix.smem_len;
    h->screen_size = h->screen_width * h->screen_height * (h->win_depth32 ? 4 : 2);
    h->virtAddr = mmap ((caddr_t) 0, fb_fix.smem_len, PROT_READ | PROT_WRITE, MAP_SHARED, h->fd, (off_t)0);
    h->win_physAddr = h->physAddr;
    memset(h->virtAddr, 0, h->physSize);
#endif

    h->win_width = 0;
    h->win_height = 0;

#endif
}

void
osal_maelcd_set_output_window (osal_maelcd_handle_t *h, int width, int height, int xpos, int ypos)
{
#if !defined(NO_MAE_HW)
    au1200_lcd_iodata_t iodata;

    ASSERTGT(width, h->screen_width, errWidthTooLarge, return, "video window width %d exceeeds screen width %d\n", width, h->screen_width);
    ASSERTGT(height, h->screen_height, errHeightTooLarge, return, "video window height %d exceeeds screen height %d\n", height, h->screen_height);

    // disable
    iodata.subcmd = AU1200_LCD_SET_WINDOW;
    iodata.window.flags = WIN_ENABLE;
    iodata.window.enable = 1;
    ioctl(h->fd, AU1200_LCD_FB_IOCTL, &iodata);

    // window dimensions
    iodata.subcmd = AU1200_LCD_SET_WINDOW;
    iodata.window.flags = WIN_SIZE;
    iodata.window.xsize = width;
    iodata.window.ysize = height;
    ioctl(h->fd, AU1200_LCD_FB_IOCTL, &iodata);

    // window position - center on screen
    iodata.subcmd = AU1200_LCD_SET_WINDOW;
    iodata.window.flags = WIN_POSITION;
    if (lcdWindowLeftJustify)
    {
        iodata.window.xpos = 0;
    }
    else
    if (lcdWindowRightJustify)
    {
        iodata.window.xpos = (h->screen_width - width - 1);
    }
    else
    {
        iodata.window.xpos = xpos;
    }
    iodata.window.ypos = ypos;
    ioctl(h->fd, AU1200_LCD_FB_IOCTL, &iodata);

    // single buffering
    iodata.subcmd = AU1200_LCD_SET_WINDOW;
    iodata.window.flags = WIN_DOUBLE_BUFFER_MODE;
    iodata.window.double_buffer_mode = 0;
    ioctl(h->fd, AU1200_LCD_FB_IOCTL, &iodata);

    // brightness
    iodata.subcmd = AU1200_LCD_SET_SCREEN;
    iodata.global.flags = SCREEN_BRIGHTNESS;
    iodata.global.brightness = 255;
    ioctl(h->fd, AU1200_LCD_FB_IOCTL, &iodata);

    // format
    iodata.subcmd = AU1200_LCD_SET_WINDOW;
    iodata.window.flags = WIN_BUFFER_FORMAT | WIN_COLOR_ORDER | WIN_PIXEL_ORDER;
    if (h->win_depth32)
    {
        iodata.window.buffer_format = 12; // see databook
        iodata.window.color_order = 0;
        iodata.window.pixel_order = 1;
    }
    else
    {
        iodata.window.buffer_format = 6; // see databook
        iodata.window.color_order = 0;
        iodata.window.pixel_order = 1;
    }
    ioctl(h->fd, AU1200_LCD_FB_IOCTL, &iodata);

    // enable
    iodata.subcmd = AU1200_LCD_SET_WINDOW;
    iodata.window.flags = WIN_ENABLE;
    iodata.window.enable = 1;
    ioctl(h->fd, AU1200_LCD_FB_IOCTL, &iodata);

    h->win_width = width;
    h->win_height = height;
#endif
}

void
osal_maelcd_flip_window_pointer (osal_maelcd_handle_t *h, uint32 physAddr)
{
#if !defined(NO_MAE_HW)

#ifdef APP_PLAYER
    mae_lcd_request_t req;

    req.request = MAEHAL_LCD_UPDATE_WINDOW;
    req.update.window = MAEHAL_LCD_WINDOW;
    req.update.physAddr = physAddr;
    ioctl(h->fd2, 0, &req);
#else
    int window_num = (physAddr - h->physAddr) / h->screen_size;
    struct fb_var_screeninfo varinfo;

    if (ioctl (h->fd, FBIOGET_VSCREENINFO, &varinfo))
    {
        ASSERTNE(1,0,errFileFailed,;,"ioctl(FBIOGET_VSCREENINFO failed ...)\n");
    }

    varinfo.yoffset = window_num * h->screen_height;
    varinfo.activate = FB_ACTIVATE_VBL;

    ioctl(h->fd, FBIOPAN_DISPLAY, &varinfo);
#endif

#endif
}

void
osal_maelcd_driver_close (osal_maelcd_handle_t *h)
{
#if !defined(NO_MAE_HW)
    munmap(h->virtAddr, h->physSize);
    close(h->fd);
#ifdef APP_PLAYER
    close(h->fd2);
#endif

#endif
}

#endif // APP_PLAYER

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

int
osal_get_video_caps()
{
	return OSAL_VIDEO_CAPS_720P;
}

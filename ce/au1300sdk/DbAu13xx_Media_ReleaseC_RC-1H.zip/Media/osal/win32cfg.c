
/*
 *    File: osal/win32cfg.c
 *  Author: Eric DeVolder
 * Purpose: OS abstraction for Windows and WinCE
 *   Notes:
 *
 */

// This file contains all the ugly glue code

#ifdef MAE
#define AU1200
#define SOC_AU1200
#endif
#ifdef MAE2
#define AU13XX
#define SOC_AU13XX
#endif

#include <osal.h>
#include <logging.h>
#include <asserts.h>

#include <stdarg.h>

#ifdef UNDER_CE
#define SOC_AU13XX // FIX!!! or SOC_AU1200
#include <pkfuncs.h>
#include <oemioctl.h>
//#include "mem_ioctl.h" // in DbAu13xx BSP/SDK
//#include "mae_ioctl.h" // in DBAu13xx BSP/SDK
#include "db13xx.h" // in DBAu13xx BSP/SDK
#include "lcd_ioctl.h" // in DbAu13xx BSP/SDK
#include "au1x00.h"
#include "windev.h"
#endif

#ifdef MAE
#define NO_MAE_HW_MEM_SIZE 0x01000000 // 16MB
#endif

#ifdef MAE2

#include "bsa.h"
#ifdef MAEHAL_720P
#define NO_MAE_HW_MEM_SIZE 0x06000000 // 96MB
#else
#define NO_MAE_HW_MEM_SIZE 0x04000000 // 64MB
#endif
#endif

int lcdWindowLeftJustify = 0;
int lcdWindowRightJustify = 0;

//////////////////////////////////////////////////////////////////////

void
osal_sleep_seconds (int seconds)
{
    Sleep(seconds * 1000);
}

void
osal_sleep_milliseconds (int milliseconds)
{
    Sleep(milliseconds);
}

int
osal_random (void)
{
    // From: http://en.wikipedia.org/wiki/Random_number_generation
    static unsigned int m_w = 0x12345678; //<choose-initializer>;    /* must not be zero */
    static unsigned int m_z = 0xABCDF012; //<choose-initializer>;    /* must not be zero */

    m_z = 36969 * (m_z & 65535) + (m_z >> 16);
    m_w = 18000 * (m_w & 65535) + (m_w >> 16);
    return (int)((m_z << 16) + m_w);  /* 32-bit result */
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
int
osal_file_open (osal_file_handle_t *h, const char *path, int flags)
{
    DWORD LastError;
    WCHAR wpath[256];
    DWORD dwDesiredAccess = 0;
    DWORD dwShareMode = 0;
    LPSECURITY_ATTRIBUTES lpSecurityAttributes = NULL;
    DWORD dwCreationDisposition = 0;
    DWORD dwFlagsAndAttributes = FILE_ATTRIBUTE_NORMAL | FILE_FLAG_NO_BUFFERING/*bypass File Cache manager*/;
    HANDLE hTemplateFile = 0;

    MultiByteToWideChar(CP_ACP, 0, path, -1, wpath,  (sizeof(wpath)/sizeof(wpath[0])));
    //wprintf(TEXT("%s\r\n"), wpath);

    if (flags & OSAL_FILE_FLAGS_READ) dwDesiredAccess |= GENERIC_READ;
    if (flags & OSAL_FILE_FLAGS_WRITE) dwDesiredAccess |= GENERIC_WRITE;

    if (flags & OSAL_FILE_FLAGS_CREATE)
        dwCreationDisposition = CREATE_ALWAYS;
    else
        dwCreationDisposition = OPEN_EXISTING;

    //dwFlagsAndAttributes = FILE_FLAG_NO_BUFFERING;

    h->fileHandle = CreateFile(
            wpath,
            dwDesiredAccess,
            dwShareMode,
            lpSecurityAttributes,
            dwCreationDisposition,
            dwFlagsAndAttributes,
            hTemplateFile
            );
    LastError = GetLastError();
    //FormatMessage(LastError);
    //printf("OPEN Last Error: %d\r\n", LastError);

    h->fileSize = GetFileSize(h->fileHandle, NULL);
    h->valid = (h->fileHandle != INVALID_HANDLE_VALUE);

    return (h->fileHandle == INVALID_HANDLE_VALUE); // return value of 0 means OK
}

int
osal_file_read (osal_file_handle_t *h, unsigned int position, void *buffer, int size)
{
    DWORD LastError;
    DWORD numRead = 0;
    BOOL success;

    if (h->valid)
    {
        // FIX!!! only supporting 32-bit file sizes
#if 0
        h->ov.Offset = position;
        h->ov.OffsetHigh = 0;
#else
#if 0 //ndef UNDER_CE
        LARGE_INTEGER li;
        li.LowPart = position;
        li.HighPart = 0;
        success = SetFilePointerEx(h->fileHandle, li, NULL, FILE_BEGIN);
        if (!success)
        {
        LastError = GetLastError();
        printf("SEEK @ %d Last Error: %d\r\n", position, LastError);
        }
#else
        success = SetFilePointer(h->fileHandle, position, NULL, FILE_BEGIN);
        if (INVALID_SET_FILE_POINTER == success)
        {
        LastError = GetLastError();
        printf("SEEK @ %d Last Error: %d\r\n", position, LastError);
        }
#endif
#endif
        success = ReadFile(h->fileHandle, buffer, size, &numRead, NULL/*&h->ov*/);
        if (!success)
        {
        LastError = GetLastError();
        printf("READ @ %d Last Error: %d (sz %d numRead %d)\r\n", position, LastError, size, numRead);
        }
    }

    return (int)numRead;
}

int
osal_file_write (osal_file_handle_t *h, const void *buffer, int size)
{
	DWORD numWritten;
	DWORD LastError;
	BOOL success;

	success = WriteFile(h->fileHandle, buffer, size, &numWritten, NULL);

	if (!success)
	{
		LastError = GetLastError();
		printf("WRITE Last Error: %d (sz %d numRead %d)\r\n", LastError, size, numWritten);
	}


	return numWritten;
}

void
osal_file_sync (osal_file_handle_t *h)
{
    if (h->valid)
    {
        //FlushFileBuffers(h->fileHandle);
    }
}

void
osal_file_close (osal_file_handle_t *h)
{
    if (h->valid)
    {
        CloseHandle(h->fileHandle);
        h->valid = 0;
    }
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
void osalSetThreadPriority (HANDLE hThread, int nPriority)
{
#ifdef UNDER_CE
    // See http://msdn.microsoft.com/en-us/library/aa450596.aspx
    // Priorities 0..96 Reserved for real-time above drivers.
#define CE_THREAD_PRIORITY_BASE 40

    // NOTE: The base priority could come from a registry entry.

    // NOTE: All the OSAL_THREAD_PRIORITY values are relative to
    // each other, with higher values indicating higher priority.
    // In CE, the value 0 is the highest priority.
    // Thus by subtracting the OSAL_THREAD_PRIORITY from the base
    // achieves the desired higher priority.
    CeSetThreadPriority(hThread, CE_THREAD_PRIORITY_BASE - nPriority);
    //RETAILMSG(1,(TEXT("CeGetThreadPriority: %d\r\n"), CeGetThreadPriority(hThread)));
#else
    //SetPriorityClass(hThread, REALTIME_PRIORITY_CLASS);
    //SetThreadPriority(hThread, nPriority);
#endif
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
#if !defined(UNDER_CE) && defined(NO_MAE_HW)
uint32 _maemem[NO_MAE_HW_MEM_SIZE/4];
#define NO_MAE_HW_MEM_PHYSADDR 0x04000000
uint32 _yuvmem[32*1024*1024/4];
#endif

void
osal_maemem_driver_open (osal_maemem_handle_t *h, int mae_size, int yuv_size)
{
#if !defined(UNDER_CE) && defined(NO_MAE_HW)
    memset(_maemem, 0xED, sizeof(_maemem)); // filling with zeros is bad since it hides problems with detecting end of slice data
    h->virtAddr = (void *)_maemem;
    h->physAddr = NO_MAE_HW_MEM_PHYSADDR;
    h->physSize = sizeof(_maemem);

    h->YUVvirtAddr = (void *)_yuvmem;
    h->YUVphysAddr = (uint32)_yuvmem;
    h->YUVphysSize = sizeof(_yuvmem);
#endif

#if defined(UNDER_CE)
    DWORD RegionSize = 0;

    h->hMemPool = CreateFile(L"MEM1:", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    ASSERTEQ(h->hMemPool, INVALID_HANDLE_VALUE, errFileFailed, return, "Cannot open MAE MEMPOOL: %d\r\n", GetLastError());

    // MAE
    memset((void *)&h->MAEMEM, 0x00, sizeof(MEM_IOCTL));
    h->MAEMEM.dwRegion = REGION_MAE;

    if (!DeviceIoControl(h->hMemPool, MEM_GET_REGION_SIZE, &h->MAEMEM, sizeof(MEM_IOCTL), &RegionSize, sizeof(RegionSize), NULL, NULL))
    {
        // TODO:
        // Add Error Message
    }

    //RETAILMSG(1, (TEXT("**** VCodec: MAE Size: 0x%x\r\n"), RegionSize));

    h->MAEMEM.dwSize = RegionSize;
    h->MAEMEM.dwFlags = MEM_FLAG_NO_CACHE;
    if (!DeviceIoControl(h->hMemPool, MEM_REQUEST_BLOCK, &h->MAEMEM, sizeof(MEM_IOCTL), NULL, 0, NULL, NULL))
    {
        ASSERTEQ(0,0,errFileFailed,return,"Cannot get MAE memory: size:%d\r\n", h->MAEMEM.dwSize);
    }
    h->physAddr = (uint32)h->MAEMEM.pPhysical;
    h->physSize = (uint32)h->MAEMEM.dwSize;
    h->virtAddr = (uint8 *)h->MAEMEM.pVirtual;
    LOG(NOTIFY,"MAE memory va %p pa %08X sz %08X %d\r\n", h->MAEMEM.pVirtual, h->MAEMEM.pPhysical, h->MAEMEM.dwSize, h->MAEMEM.dwSize);


    // YUV
    memset((void *)&h->YUVMEM, 0x00, sizeof(MEM_IOCTL));
    h->YUVMEM.dwRegion = REGION_ITE;

    if (!DeviceIoControl(h->hMemPool, MEM_GET_REGION_SIZE, &h->YUVMEM, sizeof(MEM_IOCTL), &RegionSize, sizeof(RegionSize), NULL, NULL))
    {
        // TODO:
        // Add Error Message
    }

    //RETAILMSG(1, (TEXT("**** VCodec: ITE Size: 0x%x\r\n"), RegionSize));

    h->YUVMEM.dwSize = RegionSize;
    h->YUVMEM.dwFlags = 0; // NOTE: Want CACHEABLE
    if (!DeviceIoControl(h->hMemPool, MEM_REQUEST_BLOCK, &h->YUVMEM, sizeof(MEM_IOCTL), NULL, 0, NULL, NULL))
    {
        ASSERTEQ(0,0,errFileFailed,return,"Cannot get YUV memory: size:%d\r\n", h->YUVMEM.dwSize);
    }
    h->YUVphysAddr = (uint32)h->YUVMEM.pPhysical;
    h->YUVphysSize = (uint32)h->YUVMEM.dwSize;
    h->YUVvirtAddr = (uint8 *)h->YUVMEM.pVirtual;
    LOG(NOTIFY,"YUV memory va %p pa %08X sz %08X %d\r\n", h->YUVMEM.pVirtual, h->YUVMEM.pPhysical, h->YUVMEM.dwSize, h->YUVMEM.dwSize);
#endif

    ASSERTEQ(0, h->virtAddr, errAllocFailed, ;, "MAEMEM mem buffer not provided\n");
    ASSERTEQ(0, h->physAddr, errAllocFailed, ;, "MAEMEM mem buffer not provided\n");
    ASSERTEQ(0, h->physSize, errAllocFailed, ;, "MAEMEM mem buffer not provided\n");
    ASSERTEQ(0, h->YUVvirtAddr, errAllocFailed, ;, "MAEMEM YUV buffer not provided\n");
    ASSERTEQ(0, h->YUVphysAddr, errAllocFailed, ;, "MAEMEM YUV buffer not provided\n");
    ASSERTEQ(0, h->YUVphysSize, errAllocFailed, ;, "MAEMEM YUV buffer not provided\n");

    h->counterFrequency = osal_counter_frequency();
}

void
osal_maemem_driver_close (osal_maemem_handle_t *h)
{
#if defined(UNDER_CE)
    if (!DeviceIoControl(h->hMemPool, MEM_FREE_BLOCK,
                         &h->MAEMEM, sizeof(MEM_IOCTL), NULL, 0, NULL, NULL)) {
		ASSERTEQ(0,0,errFileFailed,;,"Cannot free MAE memory: %d\r\n", GetLastError());
    }
    if (!DeviceIoControl(h->hMemPool, MEM_FREE_BLOCK,
                         &h->YUVMEM, sizeof(MEM_IOCTL), NULL, 0, NULL, NULL)) {
		ASSERTEQ(0,0,errFileFailed,;,"Cannot free YUV memory: %d\r\n", GetLastError());
    }
    CloseHandle(h->hMemPool);
#endif
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
void
osal_maefe_driver_open (osal_maefe_handle_t *h)
{
    h->counterFrequency = osal_counter_frequency();

#if defined(UNDER_CE) && !defined(NO_MAE_HW) && defined(MAE)
    ASSERTEQ(0,0,errNotImpl,;,"not yet impl\n");
#endif
}

void
osal_maefe_driver_submit (osal_maefe_handle_t *h, struct mae_fe_request_t *req)
{
#if defined(UNDER_CE) && !defined(NO_MAE_HW) && defined(MAE)
    ASSERTEQ(0,0,errNotImpl,;,"not yet impl\n");
#endif
}

void
osal_maefe_driver_close (osal_maefe_handle_t *h)
{
#if defined(UNDER_CE) && !defined(NO_MAE_HW) && defined(MAE)
    ASSERTEQ(0,0,errNotImpl,;,"not yet impl\n");
#endif
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
void
osal_maebsa_driver_open (osal_maebsa_handle_t *h)
{
    h->counterFrequency = osal_counter_frequency();

#if defined(UNDER_CE) && !defined(NO_MAE_HW) && defined(MAE2)
    h->fd = CreateFile(L"BSA1:", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (h->fd == INVALID_HANDLE_VALUE) {
        ASSERTEQ(0,0,errFileFailed,;,"Cannot open BSA: %d\r\n", GetLastError());
    }
#endif
}

void
osal_maebsa_driver_submit (osal_maebsa_handle_t *h, struct mae_bsa_request_t *req)
{
#if defined(APP_PLAYER) && defined(NO_MAE_HW)
    rsleep(32);
#endif

#if defined(NO_MAE_HW) && defined(MAE2)
    req->bsaStatus = SCB_STATUS_DONE;
#endif

#if defined(UNDER_CE) && !defined(NO_MAE_HW) && defined(MAE2)
    if (!DeviceIoControl(h->fd, MAEBSA_IOCTL_SUBMIT_TRANSACTION,
                         req, sizeof(mae_bsa_request_t), NULL, 0, NULL, NULL))
    {
        ASSERTEQ(0,0,errFileFailed,;,"BSA Failed!: %d\r\n", GetLastError());
    }
#endif
}

void
osal_maebsa_driver_close (osal_maebsa_handle_t *h)
{
#if defined(UNDER_CE) && !defined(NO_MAE_HW) && defined(MAE2)
    CloseHandle(h->fd);
#endif
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
void
osal_maempe_driver_open (osal_maempe_handle_t *h)
{
    h->counterFrequency = osal_counter_frequency();

#if defined(UNDER_CE) && !defined(NO_MAE_HW) && defined(MAE2)
    h->fd = CreateFile(L"MPE1:", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (h->fd == INVALID_HANDLE_VALUE) {
        ASSERTEQ(0,0,errFileFailed,;,"Cannot open MPE: %d\r\n", GetLastError());
    }
#endif
}

void
osal_maempe_driver_submit (osal_maempe_handle_t *h, struct mae_mpe_request_t *req)
{
#if defined(APP_PLAYER) && defined(NO_MAE_HW)
    rsleep(25);
#endif

#if defined(UNDER_CE) && !defined(NO_MAE_HW) && defined(MAE2)
    if (!DeviceIoControl(h->fd, MAEMPE_IOCTL_SUBMIT_TRANSACTION,
                         req, sizeof(mae_mpe_request_t), NULL, 0, NULL, NULL))
    {
        ASSERTEQ(0,0,errFileFailed,;,"MPE Failed!: %d\r\n", GetLastError());
    }
#endif
}

void
osal_maempe_driver_close (osal_maempe_handle_t *h)
{
#if defined(UNDER_CE) && !defined(NO_MAE_HW) && defined(MAE2)
    CloseHandle(h->fd);
#endif
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

// NOTE: For Travis/MAE, about 8MB is enough for YUVs
// NOTE: For Monet/MAE2, for SD, about 10MB is enough for YUVs
// NOTE: For Monet/MAE2, for 720p, about 24MB is enough for YUVs

void
osal_maebe_driver_open (osal_maebe_handle_t *h)
{
    h->counterFrequency = osal_counter_frequency();

#if !defined(UNDER_CE) && defined(NO_MAE_HW)
    h->fd = 0;
#endif

#if defined(UNDER_CE) && !defined(NO_MAE_HW) && (defined(MAE) || defined(MAE2))
    h->fd = CreateFile(L"ITE1:", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    if (h->fd == INVALID_HANDLE_VALUE)
    {
        ASSERTEQ(0,0,errFileFailed,return,"Cannot open BE/ITE: %d\r\n", GetLastError());
    }
#endif
}

void
osal_maebe_driver_submit (osal_maebe_handle_t *h, struct mae_be_request_t *req)
{
#if defined(APP_PLAYER) && defined(NO_MAE_HW)
    rsleep(10);
#endif

#if defined(UNDER_CE) && !defined(NO_MAE_HW) && (defined(MAE) || defined(MAE2))
    if (!DeviceIoControl(h->fd, MAEBE_IOCTL_SUBMIT_TRANSACTION,
                         req, sizeof(mae_be_request_t), NULL, 0, NULL, NULL))
    {
        ASSERTEQ(0,0,errFileFailed,;,"BE Failed!: %d\r\n", GetLastError());
    }
#endif
}

void
osal_maebe_driver_close (osal_maebe_handle_t *h)
{
#if defined(UNDER_CE) && !defined(NO_MAE_HW) && (defined(MAE) || defined(MAE2))
    CloseHandle(h->fd);
#endif
}

void
osal_maebe_mem_open (osal_maebe_handle_t *h, int yuv_size)
{
}

void
osal_maebe_mem_close (osal_maebe_handle_t *h)
{
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

#if defined(APP_PLAYER) && (defined(MAE) || defined(MAE2))

void
osal_maelcd_driver_open (osal_maelcd_handle_t *h)
{
#if defined(UNDER_CE) && !defined(NO_MAE_HW)
    h->hDC = GetDC(NULL);

    h->screen_width = GetSystemMetrics(SM_CXSCREEN);
    h->screen_height = GetSystemMetrics(SM_CYSCREEN);
    h->screen_size = h->screen_width * h->screen_height * 2; // 16bpp // FIX!!! See GetDeviceCaps(hdC, BITSPIXEL)
    h->win_depth32 = 0;
    h->win_width = 0;
    h->win_height = 0;
    h->win_which = MAE_PLANE;

    {
    memset((void *)&h->LCDMEM, 0x00, sizeof(MEM_IOCTL));
    h->hMemPool = CreateFile(L"MEM1:", GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
    ASSERTEQ(h->hMemPool, INVALID_HANDLE_VALUE, errFileFailed, return, "Cannot open LCD MEMPOOL: %d\r\n", GetLastError());
    h->LCDMEM.dwRegion  = REGION_LCD;
    h->LCDMEM.dwSize = (h->screen_size + 2048) * 3; // FIX!!! magic numbers from voutput.c and maelcd.c
    if (!DeviceIoControl(h->hMemPool, MEM_REQUEST_BLOCK,
                         &h->LCDMEM, sizeof(MEM_IOCTL), NULL, 0, NULL, NULL)) {
        ASSERTEQ(0,0,errFileFailed,return,"Cannot get LCD memory: size:%d\r\n", h->LCDMEM.dwSize);
    }
    //printf("LCD memory va %p pa %08X sz %08X %d\r\n", h->LCDMEM.pVirtual, h->LCDMEM.pPhysical, h->LCDMEM.dwSize, h->LCDMEM.dwSize);
    h->physAddr = (uint32)h->LCDMEM.pPhysical;
    h->physSize = (uint32)h->LCDMEM.dwSize;
    h->virtAddr = (uint8 *)h->LCDMEM.pVirtual;
    h->win_physAddr = h->physAddr; // HACK
    }
#endif
}

void
osal_maelcd_set_output_window (osal_maelcd_handle_t *h, int width, int height, int xpos, int ypos)
{
#if defined(UNDER_CE) && !defined(NO_MAE_HW)
    unsigned int nOverlayIndex;
    OVERLAY_IOCTL ovlIoctl;

    ASSERTGT(width, (int)h->screen_width, errWidthTooLarge, return, "video window width %d exceeeds screen width %d\n", width, h->screen_width);
    ASSERTGT(height, (int)h->screen_height, errHeightTooLarge, return, "video window height %d exceeeds screen height %d\n", height, h->screen_height);

    ovlIoctl.ndx =
    nOverlayIndex = h->win_which;

    ExtEscape(h->hDC, LCD_OVERLAY_CREATE, sizeof(ovlIoctl), (LPCSTR)&ovlIoctl, 0, NULL);
    ovlIoctl.flags = OVERLAY_CONFIG_GET;
    ExtEscape(h->hDC, LCD_OVERLAY_CONFIG, sizeof(ovlIoctl), (LPCSTR)&ovlIoctl, 0, NULL);
//RETAILMSG(1, (TEXT("+LCD WINCTRL0 %08X (x %d y %d)\r\n"), ovlIoctl.winctrl0, xpos, ypos));
//RETAILMSG(1, (TEXT("+LCD WINCTRL1 %08X\r\n"), ovlIoctl.winctrl1));
//RETAILMSG(1, (TEXT("+LCD WINCTRL2 %08X\r\n"), ovlIoctl.winctrl2));

    // Set window overlay origin
    ovlIoctl.winctrl0 &= ~(LCD_WINCTRL0_OX | LCD_WINCTRL0_OY);
    ovlIoctl.winctrl0 |= LCD_WINCTRL0_OX_N(xpos);
    ovlIoctl.winctrl0 |= LCD_WINCTRL0_OY_N(ypos);

    // Set window overlay dimensions
    ovlIoctl.winctrl1 &= ~(LCD_WINCTRL1_SZX | LCD_WINCTRL1_SZY);
    ovlIoctl.winctrl1 |= LCD_WINCTRL1_SZX_N(width);
    ovlIoctl.winctrl1 |= LCD_WINCTRL1_SZY_N(height);

    // Set buffer format and pixel ordering
    ovlIoctl.winctrl1 &= ~LCD_WINCTRL1_FRM;
    ovlIoctl.winctrl1 |= LCD_WINCTRL1_FRM_16BPP565;
    ovlIoctl.winctrl1 &= ~LCD_WINCTRL1_PO;
    ovlIoctl.winctrl1 |= LCD_WINCTRL1_PO_01;
    ovlIoctl.winctrl1 &= ~LCD_WINCTRL1_CCO;

    // Set misc
    ovlIoctl.winctrl2 &= ~(LCD_WINCTRL2_CKMODE | LCD_WINCTRL2_DBM | LCD_WINCTRL2_RAM | LCD_WINCTRL2_BX | LCD_WINCTRL2_SCX | LCD_WINCTRL2_SCY);
    ovlIoctl.winctrl2 |= LCD_WINCTRL2_BX_N(width*2);

    ovlIoctl.flags = 0; // OVERLAY_CONFIG_SET
    ExtEscape(h->hDC, LCD_OVERLAY_CONFIG, sizeof(ovlIoctl), (LPCSTR)&ovlIoctl, 0, NULL);

    ExtEscape(h->hDC, LCD_OVERLAY_ENABLE, sizeof(nOverlayIndex), (char*)&nOverlayIndex, 0, NULL);

//RETAILMSG(1, (TEXT("-LCD WINCTRL0 %08X\r\n"), ovlIoctl.winctrl0));
//RETAILMSG(1, (TEXT("-LCD WINCTRL1 %08X\r\n"), ovlIoctl.winctrl1));
//RETAILMSG(1, (TEXT("-LCD WINCTRL2 %08X\r\n"), ovlIoctl.winctrl2));

    osal_maelcd_flip_window_pointer(h, h->physAddr); // for -lcdSubmit to work
#endif

    h->win_width = width;
    h->win_height = height;
}

void
osal_maelcd_flip_window_pointer (osal_maelcd_handle_t *h, uint32 physAddr)
{
#if defined(UNDER_CE) && !defined(NO_MAE_HW)
    OVERLAY_UPDATE_IOCTL ovlIoctl;

    ovlIoctl.ndx = h->win_which;
    ovlIoctl.flags = OVERLAY_UPDATE_VBLANKWAIT | OVERLAY_UPDATE_OVERRIDE;
    ovlIoctl.phys = (void *)physAddr;

    ExtEscape(h->hDC, LCD_OVERLAY_UPDATE, sizeof(ovlIoctl), (LPCSTR)&ovlIoctl, 0, NULL);
#endif
}

void
osal_maelcd_driver_close (osal_maelcd_handle_t *h)
{
#if defined(UNDER_CE) && !defined(NO_MAE_HW)
    unsigned int nOverlayIndex;
    OVERLAY_IOCTL ovlIoctl;

    ovlIoctl.ndx =
    nOverlayIndex = h->win_which;

    ExtEscape(h->hDC, LCD_OVERLAY_DISABLE, sizeof(nOverlayIndex), (char*)&nOverlayIndex, 0, NULL);
    ExtEscape(h->hDC, LCD_OVERLAY_DESTROY, sizeof(ovlIoctl), (LPCSTR)&ovlIoctl, 0, NULL);

    ReleaseDC(NULL, h->hDC);

    {
    if (!DeviceIoControl(h->hMemPool, MEM_FREE_BLOCK,
                         &h->LCDMEM, sizeof(MEM_IOCTL), NULL, 0, NULL, NULL)) {
        printf("Cannot free LCD memory\r\n");
    }
    CloseHandle(h->hMemPool);
    }
#endif
}

#endif // APP_PLAYER

void osal_kdprint(const char *fmt, ...)
{
    char message[1024];
    va_list ptr;

    va_start(ptr, fmt);
    _vsnprintf(message, sizeof(message), fmt, ptr);
    va_end(ptr);

#ifdef UNDER_CE
    {
        // use NKDbgPrintfW with char
        wchar_t wmsg[1024];
        MultiByteToWideChar(CP_ACP, 0, message, -1, wmsg,  (sizeof(wmsg)/sizeof(wmsg[0])));
        NKDbgPrintfW(wmsg);
    }
#else
    printf(message);
#endif
}

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

int
osal_get_video_caps (void)
{
#if !defined(APP_PLAYER) && !defined(NO_MAE_HW)
    SYSTEMID    SysID;
    ULONG        ResultSize;
    OTP            *pOtp;
    int            VideoCaps;

    /*
    * Use the kernel IOCTL to retrieve PRID/BRDID/SCRATCH/GUID
    */
    KernelIoControl(
        IOCTL_OEM_GET_SYSTEMID,
        NULL,
        0,
        &SysID,
        sizeof(SysID),
        &ResultSize
        );


    pOtp = (OTP *)SysID.guid;

    if (pOtp->config0 & OTP_CONFIG0_SDR)
    {
        VideoCaps = OSAL_VIDEO_CAPS_WCIF;
    }
    else if (pOtp->config0 & OTP_CONFIG0_HDR)
    {
        VideoCaps = OSAL_VIDEO_CAPS_D1;
    }
    else
    {
        VideoCaps = OSAL_VIDEO_CAPS_720P;
    }

    return VideoCaps;
#else
    return OSAL_VIDEO_CAPS_720P;
#endif
}

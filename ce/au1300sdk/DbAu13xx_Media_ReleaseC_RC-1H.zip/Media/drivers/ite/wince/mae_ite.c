/**********************************************************************
* Copyright 2007 RMI Corp. All Rights Reserved.
*
* Unless otherwise designated in writing, this software and any related
* documentation are the confidential proprietary information of RMI
* Corp.
*
* THESE MATERIALS ARE PROVIDED "AS IS" WITHOUT ANY
* UNLESS OTHERWISE NOTED IN WRITING, EXPRESS OR IMPLIED WARRANTY OF ANY
* KIND, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* NONINFRINGEMENT, TITLE, FITNESS FOR ANY PARTICULAR PURPOSE AND IN NO
* EVENT SHALL RMI COPR. OR ITS LICENSORS BE LIABLE FOR ANY DAMAGES
* WHATSOEVER.
*
* RMI Corp. does not assume any responsibility for any errors which may
* appear in the Materials nor any responsibility to support or update
* the Materials. RMI Corp. retains the right to modify the Materials
* at any time, without notice, and is not obligated to provide such
* modified Materials to you. RMI Corp. is not obligated to furnish,
* support, or make any further information available to you.
***********************************************************************/
//------------------------------------------------------------------------------
// File: mae_ite.cpp
//------------------------------------------------------------------------------
#include <windows.h>
#include <platform.h>
#include <bceddk.h>
#include <dbgapi.h>
#include "maeioctl.h"
#include "ite.h"

#define	kVersion_Main		      1		// Main version number
#define kVersion_Sub		      0		// Sub version number
#define	kVersion_Build		    TEXT(__DATE__)		// Major Build number
#define	kVersion_BuildSub	    TEXT(__TIME__)		// Minor Build number

typedef struct
{
	DWORD dwSize;
	CRITICAL_SECTION CriticalSection;
	INT nNumOpens;
	HANDLE hDoneEvent;
	HANDLE hCloseEvent;
	HANDLE hIntrEvent;
	HANDLE hIntrThread;
	INT nIrqlMae;
	AU1200_MAEBE *regs;
	uint32	endMipsCounter;
} DRVCONTEXT, *PDRVCONTEXT;


#define EnterCS(x) EnterCriticalSection(&x)
#define LeaveCS(x) LeaveCriticalSection(&x)

int VerifyContextHandle(PDRVCONTEXT pDrv);
void ShowVersion(void);
DWORD InitEventsAndThreads(DWORD dwContext);
ULONG InterruptThread(LPVOID dwContext);

#define ITE_THREAD_PRIORITY   THREAD_PRIORITY_TIME_CRITICAL


// Debug zone support
#define DTAG TEXT("ITE: ")
#define ZONE_ERROR  DEBUGZONE(0)
#define ZONE_INIT   DEBUGZONE(1)
#define ZONE_FUNC   DEBUGZONE(2)
#define ZONE_DRVCALLS  DEBUGZONE(3)
#define ZONE_INFO   DEBUGZONE(4)
#define ZONE_INT	DEBUGZONE(5)
#define ZONE_REGISTERS DEBUGZONE(6)
#define ZONE_EXENTRY  (ZONE_FUNC | ZONE_DRVCALLS)

DBGPARAM dpCurSettings =
{
  TEXT("ite"),
  {
    TEXT("Errors"), TEXT("Init"), TEXT("Functions"),
    TEXT("DriverCalls"), TEXT("Info"), TEXT("INT"),
    TEXT("Registers"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined")
  },
  0x0001
};

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
static void be_submit (PDRVCONTEXT pDrv, mae_be_request_t *tr)
{
	AU1200_MAEBE *be = pDrv->regs;
    int i;

    tr->begMipsCounter = 0;

	if(tr->flags & MAEBE_FLAGS_DCWB)
	{
		CacheRangeFlush(tr, (16*1024), CACHE_SYNC_WRITEBACK);
	}

	//if ((be->scfdisable = tr->scfdisable) == 0)
	//{
		for (i = 0; i < 32; ++i)
		{
			be->scfhalut[i] = tr->scfhalut[i];
			be->scfvalut[i] = tr->scfvalut[i];
			be->scfhblut[i] = tr->scfhblut[i];
			be->scfvblut[i] = tr->scfvblut[i];
			be->scfhclut[i] = tr->scfhclut[i];
			be->scfvclut[i] = tr->scfvclut[i];
		}
	//}

    be->cscxcffa = tr->cscxcffa;
    be->cscxcffb = tr->cscxcffb;
    be->cscxcffc = tr->cscxcffc;
    be->cscycffa = tr->cscycffa;
    be->cscycffb = tr->cscycffb;
    be->cscycffc = tr->cscycffc;
    be->csczcffa = tr->csczcffa;
    be->csczcffb = tr->csczcffb;
    be->csczcffc = tr->csczcffc;
    be->cscxoff  = tr->cscxoff;
    be->cscyoff  = tr->cscyoff;
    be->csczoff  = tr->csczoff;
	be->cscalpha = tr->cscalpha;

    be->scfhsr   = tr->scfhsr;
    be->scfvsr   = tr->scfvsr;
	be->scfdisable = tr->scfdisable;

    be->srccfg = tr->srccfg;
    be->srcfhw = tr->srcfhw;
    be->srcaaddr = tr->srcaaddr;
    be->srcbaddr = tr->srcbaddr;
    be->srccaddr = tr->srccaddr;
    be->srcastr = tr->srcastr;
    be->srcbstr = tr->srcbstr;
    be->srccstr = tr->srccstr;

    be->dstaddr = tr->dstaddr;
    be->dststr = tr->dststr;
    be->dstheight = tr->dstheight;
    be->dstcfg = tr->dstcfg;

    be->ctlintstat = ~0;
    be->ctlintenable = MAEBE_CTLINTSTAT_FC;

	be->ctlfpc = MAEBE_CTLFPC_STR; // This starts the transaction; potential RACE!!!!!
	//RETAILMSG(1,(TEXT("+BE WaitForSingleObject\r\n")));
	WaitForSingleObject(pDrv->hDoneEvent, INFINITE);
	//RETAILMSG(1,(TEXT("-BE WaitForSingleObject\r\n")));
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void enable_ite_power(PDRVCONTEXT pDrv)
{
	AU1200_MAEBE *be = pDrv->regs;
#if 0
	UINT32	tmp;
	PULONG	pSysPowerCtrl = (PULONG)(SYS_PHYS_ADDR + SYS_POWERCTRL + KSEG1_OFFSET);

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+enable_ite_power\r\n")));

	// TODO: FIX POWER ENABLE
	tmp = READ_REGISTER_ULONG(pSysPowerCtrl);
	tmp &= ~(1 << 17);  // Clear to Enable.
	WRITE_REGISTER_ULONG(pSysPowerCtrl, tmp);
#endif // Au1200 only
	// writing this bit resets the BE and enables it for config and use
    be->ctlenable    = MAEBE_CTLENABLE_EN; // enable clocks to BE
    be->ctlfpc       = MAEBE_CTLFPC_FRST; // reset the BE
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void disable_ite_power(PDRVCONTEXT pDrv)
{
	AU1200_MAEBE *be = pDrv->regs;

#if 0
	UINT32	tmp;
	PULONG	pSysPowerCtrl = (PULONG)(SYS_PHYS_ADDR + SYS_POWERCTRL + KSEG1_OFFSET);
return;
	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+disable_ite_power\r\n")));

	// TODO: FIX POWER DISABLE
	tmp = READ_REGISTER_ULONG(pSysPowerCtrl);
	tmp |= (1 << 17);  //  Set to Disable.
	WRITE_REGISTER_ULONG(pSysPowerCtrl, tmp);
#endif // Au1200 only

	be->ctlenable = 0; // disable clocks
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void enable_ite_interrupt(PDRVCONTEXT pDrv)
{
#if 0
	AU1200_MAEBE *be = pDrv->regs;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+enable_ite_interrupt\r\n")));
	// clear the interrupt status bits to prevent spurious ones at init
	be->ctlintstat = MAEBE_CTLINTSTAT_FC;

	be->ctlintenable = 1;
#endif
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void disable_ite_interrupt(PDRVCONTEXT pDrv)
{
#if 0
	AU1200_MAEBE *be = pDrv->regs;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+disable_ite_interrupt\r\n")));
  // disable the peripheral interrupt bits
  be->ctlintenable = 0;

  // clear the interrupt status bits to prevent spurious ones at init
  be->ctlintstat = MAEBE_CTLINTSTAT_FC;
#endif
}

///////////////////////////////////////////////////////////////////////////////
// ITE_IOControl
//
// This routine handles all IOCTLs for MAE related activities. It will dispatch
// to include library IOCTL handlers.
//
// Parameters :
//		dwContext   		pointer to driver instance structure
//      dwIoControlCode		IOCTL command
//		pInBuf				Pointer to input data from caller
//      nInBufSize			Size of input data
//      pOutBuf				Pointer to output memory in caller's memory space
//		nOutBufSize			Size of memory available for output
//      pBytesReturned		Pointer to DWORD that will contain the number of 
//								bytes placed in caller's output buffer
//
// Returns :
//      TRUE				Handled IOCTL successfuly
//      FALSE				Failed to handle IOCTL
//
///////////////////////////////////////////////////////////////////////////////
DWORD ITE_IOControl(DWORD dwContext, DWORD dwIoControlCode, PBYTE pInBuf, DWORD dwInBufSize, PBYTE pOutBuf,
                    DWORD dwOutBufSize, PDWORD pdwBytesReturned)
{
	PDRVCONTEXT pDrv    = (PDRVCONTEXT) dwContext;
	BOOL RetVal         = TRUE;
	mae_be_request_t *tr = (mae_be_request_t *)pInBuf;

	DEBUGCHK(pDrv);
	DEBUGMSG (ZONE_EXENTRY, (DTAG TEXT("+ITE_IOControl dwContext: 0x08%x  dwCode: 0x08%x\r\n"), dwContext, dwIoControlCode));

	if ( (NULL == tr) || (NULL == pDrv) )
	{
		return FALSE;
	}

    if (tr->magic != MAEBE_MAGIC)
    {
        RETAILMSG(1,(TEXT("maebe: bad magic %08X\n"), tr->magic));
    }

	switch (dwIoControlCode)
	{
		case MAEBE_IOCTL_SUBMIT_TRANSACTION:
			be_submit(pDrv, tr);
			break;

		default :
			DEBUGMSG (ZONE_ERROR, (DTAG TEXT("ITE_IOControl: unknown code 0x%x\r\n"), dwIoControlCode));
			return FALSE;
			break;
	}
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD ITE_Init (DWORD dwContext)
{
	PHYSICAL_ADDRESS    PhysAddr;
	PDRVCONTEXT pDrv;

	DEBUGMSG(ZONE_INIT | ZONE_EXENTRY,
		(DTAG TEXT("+ITE_Init dwContext:0x%08x\r\n"), dwContext));

	// Allocate a device instance structure from the heap
	pDrv = (PDRVCONTEXT)LocalAlloc(LPTR, sizeof(DRVCONTEXT));
	if (pDrv)
	{
		memset((PBYTE)pDrv, 0, sizeof(DRVCONTEXT));
		pDrv->dwSize = sizeof(DRVCONTEXT);
	} else
	{
		DEBUGMSG(ZONE_INIT | ZONE_ERROR,
		  (DTAG TEXT("ITE_Init failure. Out of memory\r\n")));
		return 0;
	}

	// Map the BE/ITE physical register space
	PhysAddr.HighPart = 0;
	PhysAddr.LowPart  = MAEBE_PHYS_ADDR;
	pDrv->regs = (AU1200_MAEBE*)MmMapIoSpace(PhysAddr, sizeof(AU1200_MAEBE), FALSE);
	if (NULL == pDrv->regs) 	{
		DEBUGMSG(ZONE_ERROR, (TEXT("ITE_Init failed to map memory: 0x%08X\r\n"),MAEBE_PHYS_ADDR));
		LocalFree(pDrv);
		return 0;
	}

	ShowVersion();
	InitializeCriticalSection(&(pDrv->CriticalSection));

	// save power until we are actively using this hardware
	enable_ite_power(pDrv);

	// Connect and initialize interrupt
	pDrv->nIrqlMae = InterruptConnect(Internal, 0, ((HWINTR_SCF)), 0);
	InterruptDone(pDrv->nIrqlMae); // clear spurious intrs at init

	return (DWORD)pDrv;
}


///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD  ITE_Deinit (DWORD dwContext)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_EXENTRY,	(DTAG TEXT("+ITE_Deinit dwContext:0x%08x\r\n"), dwContext));

	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	// Cleanup everything we did in init
	InterruptDisconnect(pDrv->nIrqlMae);
	DeleteCriticalSection(&(pDrv->CriticalSection));
	MmUnmapIoSpace((PVOID)pDrv->regs, sizeof(AU1200_MAEBE));
	LocalFree(pDrv);

	//disable_ite_power(pDrv);

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("-ITE_Deinit\r\n")));

	return (DWORD)pDrv;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD ITE_Open(DWORD dwContext, DWORD dwAccess, DWORD dwShare)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_EXENTRY,
	(DTAG TEXT("+ITE_Open dwContext:0x%08x\r\n"), dwContext));

	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	EnterCS(pDrv->CriticalSection);
	if (pDrv->nNumOpens == 0)
	{
		//enable_ite_power(pDrv);
		(DWORD)pDrv = InitEventsAndThreads(dwContext);
		enable_ite_interrupt(pDrv);
	}

	// Count the number of open instances
	InterlockedIncrement ((long *)&pDrv->nNumOpens);
	LeaveCS(pDrv->CriticalSection);

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("-ITE_Open: pDrv->nNumOpens %d\r\n"),pDrv->nNumOpens));

	return (DWORD)pDrv;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL  ITE_Close (DWORD dwContext, DWORD dwOpen)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_EXENTRY,
		(DTAG TEXT("+ITE_Close dwOpen: 0x%08x\r\n"), dwOpen));

	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	EnterCS(pDrv->CriticalSection);
	if (pDrv->nNumOpens)
		InterlockedDecrement((long *)&pDrv->nNumOpens);

	if (pDrv->nNumOpens == 0)
	{
		disable_ite_interrupt(pDrv);
		// Un-register the interrupts with OS
		InterruptDisable(pDrv->nIrqlMae);
		//disable_ite_power(pDrv);

		// Wait for the interrupt handler to close
		WaitForSingleObject(pDrv->hCloseEvent, 100);

		// Close all handles
		CloseHandle(pDrv->hIntrEvent);
		CloseHandle(pDrv->hIntrThread);
		CloseHandle(pDrv->hDoneEvent);
		CloseHandle(pDrv->hCloseEvent);
	}

	LeaveCS(pDrv->CriticalSection);

	DEBUGMSG (ZONE_FUNC,
		(DTAG TEXT("-ITE_Close: pDrv->nNumOpens %d\r\n"),pDrv->nNumOpens));\

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD InitEventsAndThreads(DWORD dwContext)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+InitEventsAndThreads\r\n")));
	
	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	if ((pDrv->hDoneEvent = CreateEvent(NULL, FALSE, FALSE, NULL) )== NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateEvent failed for hDoneEvent\r\n")));
		return 1;
	}

	if ((pDrv->hCloseEvent = CreateEvent(NULL, FALSE, FALSE, NULL) )== NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateEvent failed for hCloseEvent\r\n")));
		return 1;
	}

	if ((pDrv->hIntrEvent = CreateEvent(NULL, FALSE, FALSE, NULL) )== NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateEvent failed for hIntrEvent\r\n")));
		return 1;
	}

	pDrv->hIntrThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)InterruptThread,
									  (LPVOID)(dwContext), 0, NULL);

	if (pDrv->hIntrThread == NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateThread failed\r\n")));
		return 1;
	}

	if (FALSE == CeSetThreadPriority(pDrv->hIntrThread, ITE_THREAD_PRIORITY))
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("SetThreadPriority failed\r\n")));
	}

	return (DWORD)pDrv;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
inline BOOL DriverIsOpen(LPVOID dwContext)
{
	BOOL bIsOpen = FALSE;

	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	EnterCS(pDrv->CriticalSection);
	if (pDrv->nNumOpens > 0)
	{	
		bIsOpen = TRUE;
	}
	LeaveCS(pDrv->CriticalSection);

	return bIsOpen;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
ULONG InterruptThread(LPVOID dwContext)
{
	ULONG ulWaitResult = 0;
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;
	AU1200_MAEBE *be = pDrv->regs;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+InterruptThread\r\n")));
  
	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	CeSetThreadPriority(GetCurrentThread(),ITE_THREAD_PRIORITY);

	if (InterruptInitialize(pDrv->nIrqlMae, pDrv->hIntrEvent, NULL, 0) != TRUE)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("InterruptInitialize failed\r\n")));
		return 1;
	}


	while (DriverIsOpen(dwContext)) // loop till driver close is called or an error happens
	{
		InterruptDone(pDrv->nIrqlMae);

		ulWaitResult = WaitForSingleObject(pDrv->hIntrEvent, INFINITE);

		EnterCS(pDrv->CriticalSection);
		be->ctlintstat = ~0; //MAEBE_CTLINTSTAT_FC;
		SetEvent(pDrv->hDoneEvent);
		LeaveCS(pDrv->CriticalSection);

	}

	SetEvent(pDrv->hCloseEvent);

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void ITE_PowerDown (DWORD dwContext)
{
#if 0
	ULONG ulWaitResult;
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+ITE_PowerDown\r\n")));

	// Verify that the context handle is valid.
	VerifyContextHandle(pDrv);

	// wait for ITE to finish if running
	// TODO: FIX THIS!
	if(pDrv->hIntrEvent)
		ulWaitResult = WaitForSingleObject(pDrv->hIntrEvent, 50);

	disable_ite_interrupt(pDrv);
	disable_ite_power(pDrv);
#endif
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void ITE_PowerUp (DWORD dwContext)
{
#if 0
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+ITE_PowerUp\r\n")));
	
	// Verify that the context handle is valid.
	VerifyContextHandle(pDrv);

	if (pDrv->nNumOpens > 0)
		enable_ite_power(pDrv);

	enable_ite_interrupt(pDrv);
#endif
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL WINAPI ITE_DllMain(HINSTANCE hInstDLL, DWORD dwReason, LPVOID pReserved)
{
	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
		DEBUGREGISTER(hInstDLL);
		DisableThreadLibraryCalls(hInstDLL);
		DEBUGMSG(ZONE_INFO, (TEXT("ITE_DllMain: DLL_PROCESS_ATTACH\r\n")));
		break;

	case DLL_PROCESS_DETACH:
		DEBUGMSG(ZONE_INFO, (TEXT("ITE_DllMain: DLL_PROCESS_DETACH\r\n")));
		break;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void ShowVersion(void)
{
	DEBUGMSG (ZONE_ERROR, (DTAG TEXT("Driver, v%d.%d %s.%s\r\n"), kVersion_Main,kVersion_Sub,kVersion_Build,kVersion_BuildSub));
	RETAILMSG(1, (DTAG TEXT("Driver, v%d.%d %s.%s\r\n"), kVersion_Main,kVersion_Sub,kVersion_Build,kVersion_BuildSub));
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
int VerifyContextHandle(PDRVCONTEXT pDrv)
{
	DEBUGCHK(pDrv);
	if (pDrv->dwSize != sizeof (DRVCONTEXT)) 
	{
		DEBUGMSG (ZONE_ERROR, (DTAG TEXT("Invalid driver context!\r\n")));
		return 0;
	}

	return 1;
}
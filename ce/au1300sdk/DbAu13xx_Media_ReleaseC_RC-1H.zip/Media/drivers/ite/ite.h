#ifndef __ITE_H
#define __ITE_H

/*
TODO:
Remove ITE stuff from au1xx.h and put it here in one central location.
*/

#define MAEBE_PHYS_ADDR		0x14010000


/*
################################################################################################
#####                    AU1200 MAE Back End Register Definitions                          #####
################################################################################################
*/
/* SCF Registers */
#define MAEBE_SCFHSR			0x0000
#define MAEBE_SCFVSR			0x0004
#define MAEBE_SCFDISABLE		0x0008
#define MAEBE_SCFHALUT			0x0100
#define MAEBE_SCFVALUT			0x0180
#define MAEBE_SCFHBLUT			0x0200
#define MAEBE_SFCVBLUT			0x0280
#define MAEBE_SCFHCLUT			0x0300
#define MAEBE_SCFVCLUT			0x0380

/* CSC Registers */
#define MAEBE_CSCXCFFA			0x0400
#define MAEBE_CSCXCFFB			0x0404
#define MAEBE_CSCXCFFC			0x0408
#define MAEBE_CSCYCFFA			0x040C
#define MAEBE_CSCYCFFB			0x0410
#define MAEBE_CSCYCFFC			0x0414
#define MAEBE_CSCZCFFA			0x0418
#define MAEBE_CSCZCFFB			0x041C
#define MAEBE_CSCZCFFC			0x0420
#define MAEBE_CSCXOFF			0x0424
#define MAEBE_CSCYOFF			0x0428
#define MAEBE_CSCZOFF			0x042C
#define MAEBE_CSCALPHA			0x0430

/* SRC Registers */
#define MAEBE_SRCCFG			0x0500
#define MAEBE_SRCFHW			0x0504
#define MAEBE_SRCAADDR			0x0508
#define MAEBE_SRCASTR			0x050C
#define MAEBE_SRCBADDR			0x0510
#define MAEBE_SRCBSTR			0x0514
#define MAEBE_SRCCADDR			0x0518
#define MAEBE_SRCCSTR			0x051C

/* DST Registers */
#define MAEBE_DSTCFG			0x0600
#define MAEBE_DSTHEIGHT			0x0604
#define MAEBE_DSTADDR			0x0608
#define MAEBE_DSTSTR			0x060C

/* CTL Registers */
#define MAEBE_CTLENABLE			0x0700
#define MAEBE_CTLFPC			0x0704
#define MAEBE_CTLSTAT			0x0708
#define MAEBE_CTLINTENABLE		0x070C
#define MAEBE_CTLINTSTAT		0x0710

#define MAEBE_CTLENABLE_EN		(1 << 0)

#define MAEBE_CTLFPC_FRST		(1 << 1)
#define MAEBE_CTLFPC_STR		(1 << 0)

#define MAEBE_CTLSTAT_FP		(1 << 1)
#define MAEBE_CTLSTAT_FB		(1 << 0)

#define MAEBE_CTLINTSTAT_FC		(1 << 0)

#define MAEBE_SRCCFG_ICM        (1 << 0) // Au1300
#define MAEBE_SRCCFG_ILCE       (1 << 1) // Au1300
#define MAEBE_SRCCFG_IF         (3 << 2)
#define MAEBE_SRCCFG_IF_420     (0 << 2)
#define MAEBE_SRCCFG_IF_422     (1 << 2)
#define MAEBE_SRCCFG_IF_411     (2 << 2)
#define MAEBE_SRCCFG_IF_444     (3 << 2)
#define MAEBE_SRCCFG_ILM        (3 << 4)
#define MAEBE_SRCCFG_ILM_UYVY   (0 << 4)
#define MAEBE_SRCCFG_ILM_VYUY   (1 << 4)
#define MAEBE_SRCCFG_ILM_YUYV   (2 << 4)
#define MAEBE_SRCCFG_ILM_YVYU   (3 << 4)
#define MAEBE_SRCCFG_ILE        (1 << 6)
#define MAEBE_SRCCFG_BM         (3 << 7)
#define MAEBE_SRCCFG_BM_RG_GB   (0 << 7)
#define MAEBE_SRCCFG_BM_GR_BG   (1 << 7)
#define MAEBE_SRCCFG_BM_BG_GR   (2 << 7)
#define MAEBE_SRCCFG_BM_GB_RG   (3 << 7)
#define MAEBE_SRCCFG_BYE        (1 << 9)
#define MAEBE_SRCCFG_EF         (1 << 10)

#define MAEBE_DSTCFG_EF_SHIFT		(1)
#define MAEBE_DSTCFG_OF_SHIFT		(2)
#define MAEBE_DSTCFG_BGR_SHIFT		(4)
#define MAEBE_DSTCFG_ROT_SHIFT		(5)
#define MAEBE_DSTCFG_R_SHIFT		(7)
#define MAEBE_DSTCFG_EF			(1 << MAEBE_DSTCFG_EF_SHIFT)
#define MAEBE_DSTCFG_OF			(3 << MAEBE_DSTCFG_OF_SHIFT)
#define MAEBE_DSTCFG_BGR		(1 << MAEBE_DSTCFG_BGR_SHIFT)
#define MAEBE_DSTCFG_ROT		(3 << MAEBE_DSTCFG_ROT_SHIFT)
#define MAEBE_DSTCFG_R			(1 << MAEBE_DSTCFG_R_SHIFT)

#define MAEBE_SCFHSR_SRI_N(N) (N<<16)
#define MAEBE_SCFVSR_SRI_N(N) (N<<16)



typedef volatile struct
{
  uint32		scfhsr;		// 0x0000
  uint32		scfvsr;		// 0x0004
  uint32		scfdisable;	// 0x0008
  uint32		reserved0[((MAEBE_SCFHALUT - MAEBE_SCFDISABLE) - 4)/sizeof(uint32)];	// 0x000C 0xF4
  uint32		scfhalut[32];	// 0x0100
  uint32		scfvalut[32];	// 0x0180
  uint32		scfhblut[32];	// 0x0200
  uint32		scfvblut[32];	// 0x0280
  uint32		scfhclut[32];	// 0x0300
  uint32		scfvclut[32];	// 0x0380

  uint32		cscxcffa;	// 0x0400
  uint32		cscxcffb;	// 0x0404
  uint32		cscxcffc;	// 0x0408
  uint32		cscycffa;	// 0x040C
  uint32		cscycffb;	// 0x0410
  uint32		cscycffc;	// 0x0414
  uint32		csczcffa;	// 0x0418
  uint32		csczcffb;	// 0x041C
  uint32		csczcffc;	// 0x0420
  uint32		cscxoff;	// 0x0424
  uint32		cscyoff;	// 0x0428
  uint32		csczoff;	// 0x042C
  uint32		cscalpha;	// 0x0430

  uint8 		 reserved1[(MAEBE_SRCCFG - MAEBE_CSCALPHA) - 4];	// 0x0434 +0xCC
  uint32		srccfg;		// 0x0500
  uint32		srcfhw;		// 0x0504
  uint32		srcaaddr;	// 0x0508
  uint32		srcastr;	// 0x050C
  uint32		srcbaddr;	// 0x0510
  uint32		srcbstr;	// 0x0514
  uint32		srccaddr;	// 0x0518
  uint32		srccstr;	// 0x051C

  uint8 		 reserved2[(MAEBE_DSTCFG - MAEBE_SRCCSTR) - 4]; 	// 0x0520 +0xE0
  uint32		dstcfg;		// 0x0600
  uint32		dstheight;	// 0x0604
  uint32		dstaddr;	// 0x0608
  uint32		dststr;		// 0x060C

  uint8 		 reserved3[(MAEBE_CTLENABLE - MAEBE_DSTSTR) - 4];	// 0x0610 +0xF0
  uint32		ctlenable;	// 0x0700
  uint32		ctlfpc;		// 0x0704
  uint32		ctlstat;	// 0x0708
  uint32		ctlintenable;	// 0x070C
  uint32		ctlintstat;	// 0x0710
} AU1200_MAEBE;

#endif // __ITE_H

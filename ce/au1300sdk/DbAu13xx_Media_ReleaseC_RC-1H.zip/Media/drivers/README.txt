From Bryant's email:

Linux build steps:
1.) Install the db1300 Linux SDK.
2.) > sudo ln -s /opt/rmi-linux/db1300/src/linux-2.6.29 /opt/rmi-linux/db1300/src/linux
3.) > source /opt/rmi-linux/db1300/environment-setup
4.) > cd media/trunk/drivers/bsa/linux
5.) > make
6.) Repeat steps 4 and 5 for each driver.

WinCE build steps:
1.) Install the DB1300 WinCE SDK
2.) Copy \WINCE600\PLATFORM\DbAu13xx\lib\MIPSII\retail\CEDDK.lib to \Program Files\Windows CE Tools\wce600\DbAu13xx\Lib\MIPSII
3.) Open project files
4.) Build


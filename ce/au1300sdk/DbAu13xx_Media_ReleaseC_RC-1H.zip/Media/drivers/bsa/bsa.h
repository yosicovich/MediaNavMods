/**********************************************************************
* Copyright 2008 RMI Corp. All Rights Reserved.
*
* Unless otherwise designated in writing, this software and any related
* documentation are the confidential proprietary information of RMI
* Corp.
*
* THESE MATERIALS ARE PROVIDED "AS IS" WITHOUT ANY
* UNLESS OTHERWISE NOTED IN WRITING, EXPRESS OR IMPLIED WARRANTY OF ANY
* KIND, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* NONINFRINGEMENT, TITLE, FITNESS FOR ANY PARTICULAR PURPOSE AND IN NO
* EVENT SHALL RMI COPR. OR ITS LICENSORS BE LIABLE FOR ANY DAMAGES
* WHATSOEVER.
*
* RMI Corp. does not assume any responsibility for any errors which may
* appear in the Materials nor any responsibility to support or update
* the Materials. RMI Corp. retains the right to modify the Materials
* at any time, without notice, and is not obligated to provide such
* modified Materials to you. RMI Corp. is not obligated to furnish,
* support, or make any further information available to you.
***********************************************************************/

/* Generated: monet 13344, Fri Feb 12 13:11:12 CST 2010 */

#ifndef __bsa_h__
#define __bsa_h__

#ifdef __cplusplus
extern "C" {
#endif

//////////////////////////////////////////////////////////////////////

// Absolute maximum number of macroblocks per picture the BSA can handle
#define MAX_PICWIDTHINMBS   (1280/16)
#define MAX_PICHEIGHTINMBS  (720/16)
#define MAX_PICSIZEINMBS    (MAX_PICWIDTHINMBS*MAX_PICHEIGHTINMBS)

// Absolute maximum values per macroblock
#define PMM_BYTES_PER_MB    (16)
#define COEFF_BYTES_PER_MB  ((13589/*bits*/+7)/8)
#define MV_BYTES_PER_MB     ((8827/*bits*/+7)/8)
#define NEIGH_BYTES_PER_MB  ((76/*dwords*/*8))

#define IRAM_SIZE       12800 // 12.5KB
#define DRAM_SIZE       12288 // 12.0KB

//////////////////////////////////////////////////////////////////////

#ifndef ASSEMBLER
typedef volatile union
{
    unsigned int    _word;       // 32-bit Au1 accesses
    unsigned short  _hword[2];   // 16-bit SCB accesses
    unsigned char   _byte[4];

#define WD32 _word
#define LO16 _hword[0] // SCB is EL
#define HI16 _hword[1]

} bsaReg;
#endif

#define HI16_MASK(X)  (((X)>>16)&0x0000FFFF)
#define LO16_MASK(X)  (((X)>> 0)&0x0000FFFF)

//////////////////////////////////////////////////////////////////////

#define CABAC_RESET          0 // 0x0000
#define CABAC_INIT           4 // 0x0004
#define CABAC_CODIRANGE      8 // 0x0008
#define CABAC_CODIOFFSET    12 // 0x000C
#define CABAC_SLICEINFO     16 // 0x0010
#define CABAC_MBINFO        20 // 0x0014
#define CABAC_CBP           24 // 0x0018
#define CABAC_SUBMBINFO     28 // 0x001C
#define CABAC_MFDF          32 // 0x0020

#ifndef ASSEMBLER
typedef volatile struct
{
    bsaReg reset;
    bsaReg init;
    bsaReg codIRange;
    bsaReg codIOffset;
    bsaReg sliceinfo;
    bsaReg mbinfo;
    bsaReg cbp;
    bsaReg submbinfo;
    bsaReg mfdf;
    bsaReg _pad[16-9];

} bsa_cabac_t;
#endif

#define CABAC_SLICEINFO_CIPF_BITPOS 0
#define CABAC_SLICEINFO_SDP_BITPOS  1
#define CABAC_SLICEINFO_ST_BITPOS   2
#define CABAC_SLICEINFO_MFF_BITPOS  5
#define CABAC_SLICEINFO_FPF_BITPOS  6
#define CABAC_SLICEINFO_CIPF        (1<<CABAC_SLICEINFO_CIPF_BITPOS)
#define CABAC_SLICEINFO_SDP         (1<<CABAC_SLICEINFO_SDP_BITPOS)
#define CABAC_SLICEINFO_ST          (7<<CABAC_SLICEINFO_ST_BITPOS)
#define CABAC_SLICEINFO_MFF         (1<<CABAC_SLICEINFO_MFF_BITPOS)
#define CABAC_SLICEINFO_FPF         (1<<CABAC_SLICEINFO_FPF_BITPOS)

#define CABAC_MBINFO_MPPM0_BITPOS   0
#define CABAC_MBINFO_INTRA_BITPOS   3
#define CABAC_MBINFO_INTER_BITPOS   4
#define CABAC_MBINFO_MFDF_BITPOS    5
#define CABAC_MBINFO_PT_BITPOS      7
#define CABAC_MBINFO_MPPM1_BITPOS   9
#define CABAC_MBINFO_MPPM0          (7<<CABAC_MBINFO_MPPM0_BITPOS)
#define CABAC_MBINFO_INTRA          (1<<CABAC_MBINFO_INTRA_BITPOS)
#define CABAC_MBINFO_INTER          (1<<CABAC_MBINFO_INTER_BITPOS)
#define CABAC_MBINFO_MFDF           (1<<CABAC_MBINFO_MFDF_BITPOS)
#define CABAC_MBINFO_PT             (3<<CABAC_MBINFO_PT_BITPOS)
#define CABAC_MBINFO_MPPM1          (7<<CABAC_MBINFO_MPPM1_BITPOS)

#define CABAC_CBP_CBPL_BITPOS       0
#define CABAC_CBP_CBPC_BITPOS       4
#define CABAC_CBP_CBPL              (15<<CABAC_CBP_CBPL_BITPOS)
#define CABAC_CBP_CBPC              (3<<CABAC_CBP_CBPC_BITPOS)

#define CABAC_SUBMBINFO_SPT0_BITPOS     0
#define CABAC_SUBMBINFO_SPT1_BITPOS     2
#define CABAC_SUBMBINFO_SPT2_BITPOS     4
#define CABAC_SUBMBINFO_SPT3_BITPOS     6
#define CABAC_SUBMBINFO_SPPM0_BITPOS    16
#define CABAC_SUBMBINFO_SPPM1_BITPOS    19
#define CABAC_SUBMBINFO_SPPM2_BITPOS    22
#define CABAC_SUBMBINFO_SPPM3_BITPOS    25
#define CABAC_SUBMBINFO_SPT0            (3<<CABAC_SUBMBINFO_SPT0_BITPOS)
#define CABAC_SUBMBINFO_SPT1            (3<<CABAC_SUBMBINFO_SPT1_BITPOS)
#define CABAC_SUBMBINFO_SPT2            (3<<CABAC_SUBMBINFO_SPT2_BITPOS)
#define CABAC_SUBMBINFO_SPT3            (3<<CABAC_SUBMBINFO_SPT3_BITPOS)
#define CABAC_SUBMBINFO_SPPM0           (7<<CABAC_SUBMBINFO_SPPM0_BITPOS)
#define CABAC_SUBMBINFO_SPPM1           (7<<CABAC_SUBMBINFO_SPPM1_BITPOS)
#define CABAC_SUBMBINFO_SPPM2           (7<<CABAC_SUBMBINFO_SPPM2_BITPOS)
#define CABAC_SUBMBINFO_SPPM3           (7<<CABAC_SUBMBINFO_SPPM3_BITPOS)

#define CABAC_MFDF_MFDF                 (1<<0)

//////////////////////////////////////////////////////////////////////

#define CAVLC_SLICEINFO                      0 // 0x0000
#define CAVLC_COEFVLDTABLE                   4 // 0x0004
#define CAVLC_TOTALZEROS4X4VLDTABLE          8 // 0x0008
#define CAVLC_TOTALZEROSCHROMA2X2VLDTABLE   12 // 0x000C
#define CAVLC_RUNBEFOREVLDTABLE             16 // 0x0010

#ifndef ASSEMBLER
typedef volatile struct
{
    bsaReg sliceinfo;
    bsaReg coefvldtable;
    bsaReg totalzeros4x4vldtable;
    bsaReg totalzeroschroma2x2vldtable;
    bsaReg runbeforevldtable;
    bsaReg _pad[16-5];

} bsa_cavlc_t;
#endif

#define CAVLC_SLICEINFO_CIPF_BITPOS 0
#define CAVLC_SLICEINFO_SDP_BITPOS  1
#define CAVLC_SLICEINFO_ST_BITPOS   2
#define CAVLC_SLICEINFO_MFF_BITPOS  5
#define CAVLC_SLICEINFO_FPF_BITPOS  6
#define CAVLC_SLICEINFO_CIPF        (1<<CAVLC_SLICEINFO_CIPF_BITPOS)
#define CAVLC_SLICEINFO_SDP         (1<<CAVLC_SLICEINFO_SDP_BITPOS)
#define CAVLC_SLICEINFO_ST          (7<<CAVLC_SLICEINFO_ST_BITPOS)
#define CAVLC_SLICEINFO_MFF         (1<<CAVLC_SLICEINFO_MFF_BITPOS)
#define CAVLC_SLICEINFO_FPF         (1<<CAVLC_SLICEINFO_FPF_BITPOS)

//////////////////////////////////////////////////////////////////////

#define GLOBPERFCTRL    68 // 0x0044
#define PERFCTRL0       72 // 0x0048
#define PERFCTRL1       76 // 0x004c
#define PERFCNT0        80 // 0x0050
#define PERFCNT1        84 // 0x0054
#define PERFFRAME       88 // 0x0058

//////////////////////////////////////////////////////////////////////

#define Port0ByteCnt      92 // 0x005c
#define Port1ByteCnt      96 // 0x0060
#define Port2ByteCnt     100 // 0x0064
#define Port3ByteCnt     104 // 0x0068
#define Port4ByteCnt     108 // 0x006c
#define Port5ByteCnt     112 // 0x0070
#define Port6ByteCnt     116 // 0x0074
#define Port7ByteCnt     120 // 0x0078
#define Port8ByteCnt     124 // 0x007c

//////////////////////////////////////////////////////////////////////

#define SCB_ADDR         0 // 0x0000
#define SCB_GO           4 // 0x0004
#define SCB_CONTROL      8 // 0x0008
#define SCB_STATUS      12 // 0x000C
#define SCB_MASK        16 // 0x0010
#define SCB_MAILBOX0    20 // 0x0014
#define SCB_MAILBOX1    24 // 0x0018
#define SCB_MAILBOX2    28 // 0x001C
#define SCB_MAILBOX3    32 // 0x0020
#define SCB_REMAINDER   36 // 0x0024
#define SCB_WATCHDOG    40 // 0x0028
#define SCB_SLICECNT    44 // 0x002C

#ifndef ASSEMBLER
typedef volatile struct
{
    bsaReg addr;
    bsaReg go;
    bsaReg control;
    bsaReg status;
    bsaReg mask;
    bsaReg mailbox0; // NOTE: used for Parsed Macroblock Map pointer
    bsaReg mailbox1;
    bsaReg mailbox2;
    bsaReg mailbox3;
    bsaReg remainder;
    bsaReg watchdog;
    bsaReg slicecnt;
    bsaReg _pad[16-12];

} bsa_scb_t;
#endif

#define SCB_GO_GO       (1<<0)

#define SCB_STATUS_VE   (1<<0)
#define SCB_STATUS_WE   (1<<1)
#define SCB_STATUS_O0E  (1<<2)
#define SCB_STATUS_O1E  (1<<3)
#define SCB_STATUS_FE   (1<<4)
#define SCB_STATUS_IE   (1<<5)
#define SCB_STATUS_BE   (1<<6)
#define SCB_STATUS_DONE (1<<7)

//////////////////////////////////////////////////////////////////////

#define MVFIFO0_WIDTH 16
#define MVFIFO1_WIDTH 16
#define MVFIFO2_WIDTH 13

#ifndef ASSEMBLER
typedef volatile struct
{
    bsaReg config0; 
    bsaReg config1;
    bsaReg config2;
    bsaReg config3;
    bsaReg config4;
    bsaReg config5;
    bsaReg config6;
    bsaReg hybridpredout;
    bsaReg hybridpredin;
    bsaReg picordercntcurrbottom;
    bsaReg config10;
    bsaReg config11;
    bsaReg config12;
    bsaReg reserved[19];
    bsaReg picidl0[32];
    bsaReg picidl1[32];
    bsaReg _pad[128-96];
} bsa_mvpred_t;
#endif

#define MVPRED_CONFIG0           0 // 0x0000
#define MVPRED_CONFIG1           4 // 0x0004
#define MVPRED_CONFIG2           8 // 0x0008
#define MVPRED_CONFIG3          12 // 0x000C
#define MVPRED_CONFIG4          16 // 0x0010
#define MVPRED_CONFIG5          20 // 0x0014
#define MVPRED_CONFIG6          24 // 0x0018
#define MVPRED_CONFIG7          28 // 0x001C
#define MVPRED_CONFIG8          32 // 0x0020
#define MVPRED_CONFIG9          36 // 0x0024
#define MVPRED_CONFIG10         40 // 0x0028
#define MVPRED_CONFIG11         44 // 0x002C
#define MVPRED_CONFIG12         48 // 0x0030

#define MVPRED_CONFIG0_PICWIDTH_BITPOS              0
#define MVPRED_CONFIG0_PICWIDTH_N(N)                ((N) << MVPRED_CONFIG0_PICWIDTH_BITPOS)
#define MVPRED_CONFIG0_PICHEIGHT_BITPOS             0
#define MVPRED_CONFIG0_PICHEIGHT_N(N)               ((N) << MVPRED_CONFIG0_PICHEIGHT_BITPOS)
#define MVPRED_CONFIG0_BOTFLD_BITPOS                9 
#define MVPRED_CONFIG0_BOTFLD                       (0x1 << MVPRED_CONFIG0_BOTFLD_BITPOS)
#define MVPRED_CONFIG0_BOTFLD_N(N)                  ((N) << MVPRED_CONFIG0_BOTFLD_BITPOS)
#define MVPRED_CONFIG0_REFDIST_BITPOS               10
#define MVPRED_CONFIG0_REFDIST_N(N)                 ((N) << MVPRED_CONFIG0_REFDIST_BITPOS)
#define MVPRED_CONFIG0_REFFLD_BITPOS                15
#define MVPRED_CONFIG0_REFFLD_N(N)                  ((N) << MVPRED_CONFIG0_REFFLD_BITPOS)
#define MVPRED_CONFIG0_REFBOT_BITPOS                15
#define MVPRED_CONFIG0_REFBOT                       (1<<MVPRED_CONFIG0_REFBOT_BITPOS)
#define MVPRED_CONFIG0_DIRECT8X8_BITPOS             9
#define MVPRED_CONFIG0_DIRECT8X8                    (1<<MVPRED_CONFIG0_DIRECT8X8_BITPOS)

#define MVPRED_CONFIG1_CODECTYPE_BITPOS             0
#define MVPRED_CONFIG1_CODECTYPE                    (7<<MVPRED_CONFIG1_CODECTYPE_BITPOS)
#define MVPRED_CONFIG1_CODECTYPE_MPEG2              (0<<MVPRED_CONFIG1_CODECTYPE_BITPOS)
#define MVPRED_CONFIG1_CODECTYPE_MPEG4              (1<<MVPRED_CONFIG1_CODECTYPE_BITPOS)
#define MVPRED_CONFIG1_CODECTYPE_VC1                (2<<MVPRED_CONFIG1_CODECTYPE_BITPOS)
#define MVPRED_CONFIG1_CODECTYPE_VC1_ADV            (3<<MVPRED_CONFIG1_CODECTYPE_BITPOS)
#define MVPRED_CONFIG1_CODECTYPE_H264_CABAC         (4<<MVPRED_CONFIG1_CODECTYPE_BITPOS)
#define MVPRED_CONFIG1_CODECTYPE_H264_CAVLC         (5<<MVPRED_CONFIG1_CODECTYPE_BITPOS)
#define MVPRED_CONFIG1_CODECTYPE_RESERVED           (6<<MVPRED_CONFIG1_CODECTYPE_BITPOS)
#define MVPRED_CONFIG1_CODECTYPE_JPEG               (7<<MVPRED_CONFIG1_CODECTYPE_BITPOS)
#define MVPRED_CONFIG1_CURRPICTURETYPE_BITPOS       3
#define MVPRED_CONFIG1_CURRPICTURETYPE              (3<<MVPRED_CONFIG1_CURRPICTURETYPE_BITPOS)
#define MVPRED_CONFIG1_CURRPICTURETYPE_PROGRESSIVE  (0<<MVPRED_CONFIG1_CURRPICTURETYPE_BITPOS)
#define MVPRED_CONFIG1_CURRPICTURETYPE_RESERVED     (1<<MVPRED_CONFIG1_CURRPICTURETYPE_BITPOS)
#define MVPRED_CONFIG1_CURRPICTURETYPE_MBAFF        (2<<MVPRED_CONFIG1_CURRPICTURETYPE_BITPOS)
#define MVPRED_CONFIG1_CURRPICTURETYPE_FIELD        (3<<MVPRED_CONFIG1_CURRPICTURETYPE_BITPOS)
#define MVPRED_CONFIG1_RNDCTL_BITPOS                5
#define MVPRED_CONFIG1_RNDCTL                       (1<<MVPRED_CONFIG1_RNDCTL_BITPOS)
#define MVPRED_CONFIG1_PLMB_BITPOS                  6
#define MVPRED_CONFIG1_PLMB_N(N)                    ((N) << MVPRED_CONFIG1_PLMB_BITPOS)
#define MVPRED_CONFIG1_PLMB_INTRA                   (0<<MVPRED_CONFIG1_PLMB_BITPOS)
#define MVPRED_CONFIG1_PLMB_FORWARD                 (1<<MVPRED_CONFIG1_PLMB_BITPOS)
#define MVPRED_CONFIG1_PLMB_BACKWARD                (2<<MVPRED_CONFIG1_PLMB_BITPOS)
#define MVPRED_CONFIG1_PLMB_BIDIR                   (3<<MVPRED_CONFIG1_PLMB_BITPOS)
#define MVPRED_CONFIG1_COLPICTURETYPE_BITPOS        12
#define MVPRED_CONFIG1_COLPICTURETYPE               (3<<MVPRED_CONFIG1_COLPICTURETYPE_BITPOS)
#define MVPRED_CONFIG1_COLPICTURETYPE_PROGRESSIVE   (0<<MVPRED_CONFIG1_COLPICTURETYPE_BITPOS)
#define MVPRED_CONFIG1_COLPICTURETYPE_RESERVED      (1<<MVPRED_CONFIG1_COLPICTURETYPE_BITPOS)
#define MVPRED_CONFIG1_COLPICTURETYPE_MBAFF         (2<<MVPRED_CONFIG1_COLPICTURETYPE_BITPOS)
#define MVPRED_CONFIG1_COLPICTURETYPE_FIELD         (3<<MVPRED_CONFIG1_COLPICTURETYPE_BITPOS)
#define MVPRED_CONFIG1_SHORTTERM_BITPOS             8 
#define MVPRED_CONFIG1_SHORTTERM                    (1<<MVPRED_CONFIG1_SHORTTERM_BITPOS)
#define MVPRED_CONFIG1_SPATIAL_BITPOS               9
#define MVPRED_CONFIG1_SPATIAL                      (1<<MVPRED_CONFIG1_SPATIAL)
#define MVPRED_CONFIG1_SWIZZLE_BITPOS               10
#define MVPRED_CONFIG1_SWIZZLE                      (3<<MVPRED_CONFIG1_SWIZZLE_BITPOS)
#define MVPRED_CONFIG1_SWIZZLE_00                   (0<<MVPRED_CONFIG1_SWIZZLE_BITPOS)
#define MVPRED_CONFIG1_SWIZZLE_01                   (1<<MVPRED_CONFIG1_SWIZZLE_BITPOS)
#define MVPRED_CONFIG1_SWIZZLE_10                   (2<<MVPRED_CONFIG1_SWIZZLE_BITPOS)
#define MVPRED_CONFIG1_SWIZZLE_11                   (3<<MVPRED_CONFIG1_SWIZZLE_BITPOS)
#define MVPRED_CONFIG1_COL_PICTURE_TYPE_BITPOS      12
#define MVPRED_CONFIG1_COL_PICTURE_TYPE_N(N)        ((N) << MVPRED_CONFIG1_COL_PICTURE_TYPE_BITPOS)
#define MVPRED_CONFIG1_NUMREF_BITPOS                14
#define MVPRED_CONFIG1_NUMREF_N(N)                  ((N) << MVPRED_CONFIG1_NUMREF_BITPOS)
#define MVPRED_CONFIG1_NUMREF                       MVPRED_CONFIG1_NUMREF_N(3)
#define MVPRED_CONFIG1_NUMREF_ONE                   MVPRED_CONFIG1_NUMREF_N(1)
#define MVPRED_CONFIG1_NUMREF_TWO                   MVPRED_CONFIG1_NUMREF_N(2)
#define MVPRED_CONFIG1_NUMREF_INTERLACE_B           MVPRED_CONFIG1_NUMREF_N(2)
#define MVPRED_CONFIG1_PICORDERCNTCURR_BITPOS       0

#define MVPRED_CONFIG2_PICORDERCNTBOTTOM_BITPOS     0
#define MVPRED_CONFIG2_PICORDERCNTTOP_BITPOS        0

#define MVPRED_CONFIG3_COLPICRDPTR0_BITPOS          0

#define MVPRED_CONFIG4_COLPICRDPTR1_BITPOS          0

#define MVPRED_CONFIG5_IDLE_BITPOS                  0
#define MVPRED_CONFIG5_IDLE                         (1<<MVPRED_CONFIG5_IDLE_BITPOS)

#define MVPRED_CONFIG6_WEIGHTMODE_BITPOS            0
#define MVPRED_CONFIG6_WEIGHTMODE                   (3<<MVPRED_CONFIG6_WEIGHTMODE_BITPOS)
#define MVPRED_CONFIG6_WEIGHTMODE_NONE              (0<<MVPRED_CONFIG6_WEIGHTMODE_BITPOS)
#define MVPRED_CONFIG6_WEIGHTMODE_EXPLICIT          (1<<MVPRED_CONFIG6_WEIGHTMODE_BITPOS)
#define MVPRED_CONFIG6_WEIGHTMODE_IMPLICIT          (2<<MVPRED_CONFIG6_WEIGHTMODE_BITPOS)
#define MVPRED_CONFIG6_LUMALOG2_BITPOS              2
#define MVPRED_CONFIG6_LUMALOG2                     (7<<MVPRED_CONFIG6_LUMALOG2_BITPOS)
#define MVPRED_CONFIG6_CHROMALOG2_BITPOS            5
#define MVPRED_CONFIG6_CHROMALOG2                   (7<<MVPRED_CONFIG6_CHROMALOG2_BITPOS)
#define MVPRED_CONFIG6_HPEL_BITPOS                  8
#define MVPRED_CONFIG6_HPEL_N(N)                    ((N) << MVPRED_CONFIG6_HPEL_BITPOS)
#define MVPRED_CONFIG6_COLHPEL_BITPOS               9
#define MVPRED_CONFIG6_COLHPEL_N(N)                 ((N) << MVPRED_CONFIG6_COLHPEL_BITPOS)
#define MVPRED_CONFIG6_TFF_BITPOS                   10
#define MVPRED_CONFIG6_TFF_N(N)                     ((N) << MVPRED_CONFIG6_TFF_BITPOS)
#define MVPRED_CONFIG6_DISTSCALEFACTOR_BITPOS       0
#define MVPRED_CONFIG6_DISTSCALEFACTOR_N(N)         ((N) << MVPRED_CONFIG6_DISTSCALEFACTOR_BITPOS)
#define MVPRED_CONFIG6_VC1FRFD_BITPOS               11
#define MVPRED_CONFIG6_VC1FRFD_N(N)                 ((N) << MVPRED_CONFIG6_VC1FRFD_BITPOS)

#define MVPRED_HYBRIDPREDOUT_GET_BITPOS             0
#define MVPRED_HYBRIDPREDOUT_GET                    (1<<MVPRED_HYBRIDPREDOUT_GET_BITPOS)
#define MVPRED_HYBRIDPREDOUT_VALID_BITPOS           1
#define MVPRED_HYBRIDPREDOUT_VALID                  (1<<MVPRED_HYBRIDPREDOUT_VALID_BITPOS)

#define MVPRED_HYBRIDPREDIN_SET_BITPOS              0
#define MVPRED_HYBRIDPREDIN_SET                     (1<<MVPRED_HYBRIDPREDIN_HPRED_BITPOS)
#define MVPRED_HYBRIDPREDIN_VALID_BITPOS            1
#define MVPRED_HYBRIDPREDIN_VALID                   (1<<MVPRED_HYBRIDPREDIN_VALID_BITPOS)


//////////////////////////////////////////////////////////////////////

#define IFIFO_LISTADDR       0 // 0x0000
#define IFIFO_NUMENTRIES     4 // 0x0004
#define IFIFO_CONTROL        8 // 0x0008
#define IFIFO_STATUS        12 // 0x000C
#define IFIFO_PATTERN       16 // 0x0010
#define IFIFO_BYTEALIGNED   20 // 0x0014
#define IFIFO_BITSLEFT      24 // 0x0018
#define IFIFO_NEXTBITS1500  28 // 0x001C
#define IFIFO_NEXTBITS3116  32 // 0x0020
#define IFIFO_BITCOUNTER    36 // 0x0024

#ifndef ASSEMBLER
typedef volatile struct
{
    bsaReg listaddr;
    bsaReg numentries;
    bsaReg control;
    bsaReg status;
    bsaReg pattern;
    bsaReg bytealigned;
    bsaReg bitsleft;
    bsaReg nextbits1500;
    bsaReg nextbits3116;
    bsaReg bitcounter;

    bsaReg _pad[16-10];
} bsa_ififo_t;

typedef volatile struct
{
    bsaReg descw0;
    bsaReg descw1;

} bsa_ififo_desc_t;
#endif

#define IFIFO_CONTROL_SD_BITPOS     0
#define IFIFO_CONTROL_SD            (7<<IFIFO_CONTROL_SD_BITPOS)
#define IFIFO_CONTROL_SD_000        (0<<IFIFO_CONTROL_SD_BITPOS)
#define IFIFO_CONTROL_SD_001        (1<<IFIFO_CONTROL_SD_BITPOS)
#define IFIFO_CONTROL_SD_010        (2<<IFIFO_CONTROL_SD_BITPOS)
#define IFIFO_CONTROL_SD_100        (4<<IFIFO_CONTROL_SD_BITPOS)
#define IFIFO_CONTROL_SD_101        (5<<IFIFO_CONTROL_SD_BITPOS)
#define IFIFO_CONTROL_SD_110        (6<<IFIFO_CONTROL_SD_BITPOS)
#define IFIFO_CONTROL_SB_BITPOS     3
#define IFIFO_CONTROL_SB            (7<<IFIFO_CONTROL_SB_BITPOS)
#define IFIFO_CONTROL_SB_000        (0<<IFIFO_CONTROL_SB_BITPOS)
#define IFIFO_CONTROL_SB_001        (1<<IFIFO_CONTROL_SB_BITPOS)
#define IFIFO_CONTROL_SB_010        (2<<IFIFO_CONTROL_SB_BITPOS)
#define IFIFO_CONTROL_SB_011        (3<<IFIFO_CONTROL_SB_BITPOS)
#define IFIFO_CONTROL_SB_100        (4<<IFIFO_CONTROL_SB_BITPOS)
#define IFIFO_CONTROL_SB_101        (5<<IFIFO_CONTROL_SB_BITPOS)
#define IFIFO_CONTROL_SB_110        (6<<IFIFO_CONTROL_SB_BITPOS)
#define IFIFO_CONTROL_PV            (0xF<<6)
#define IFIFO_CONTROL_PV_0000       (0x0<<6)
#define IFIFO_CONTROL_PV_1000       (0x8<<6)
#define IFIFO_CONTROL_PV_1100       (0xC<<6)
#define IFIFO_CONTROL_PV_1110       (0xE<<6)
#define IFIFO_CONTROL_PV_1111       (0xF<<6)
#define IFIFO_CONTROL_SM_OFFSET     10
#define IFIFO_CONTROL_SM            (0xF<<10)
#define IFIFO_CONTROL_SM_1000       (0x8<<10)
#define IFIFO_CONTROL_SM_0100       (0x4<<10)
#define IFIFO_CONTROL_SM_1100       (0xc<<10)
#define IFIFO_CONTROL_SM_0010       (0x2<<10)
#define IFIFO_CONTROL_SM_1010       (0xa<<10)
#define IFIFO_CONTROL_SM_1110       (0xe<<10)
#define IFIFO_CONTROL_SM_0001       (0x1<<10)
#define IFIFO_CONTROL_SM_0011       (0x3<<10)
#define IFIFO_CONTROL_SM_0111       (0x7<<10)
#define IFIFO_CONTROL_SM_0101       (0x5<<10)
#define IFIFO_CONTROL_SM_1111       (0xf<<10)
#define IFIFO_CONTROL_SM_1011       (0xb<<10)
#define IFIFO_CONTROL_SM_1101       (0xd<<10)
#define IFIFO_CONTROL_SM_1001       (0x9<<10)

#define IFIFO_STATUS_STARTED        (1<<0)
#define IFIFO_STATUS_STALLED        (1<<1)
#define IFIFO_STATUS_COMPLETED      (1<<2)

#define IFIFO_DESCW1_LAST   0x80000000
#define IFIFO_DESCW1_INT    0x40000000

//////////////////////////////////////////////////////////////////////

#define OFIFO_ADDR       0 // 0x0000
#define OFIFO_ENDADDR    4 // 0x0004
#define OFIFO_CONTROL    8 // 0x0008
#define OFIFO_STATUS    12 // 0x000C
#define OFIFO_NUMWORDS  16 // 0x0010

#ifndef ASSEMBLER
typedef volatile struct
{
    bsaReg addr;
    bsaReg endaddr;
    bsaReg control;
    bsaReg status;
    bsaReg numwords;

    bsaReg _pad[16-5];
} bsa_ofifo_t;
#endif

#define OFIFO_CONTROL_F         (1<<0)
#define OFIFO_CONTROL_S         (1<<1)
#define OFIFO_CONTROL_SD_BITPOS 2
#define OFIFO_CONTROL_SD        (7<<OFIFO_CONTROL_SD_BITPOS)
#define OFIFO_CONTROL_SD_000    (0<<OFIFO_CONTROL_SD_BITPOS)
#define OFIFO_CONTROL_SD_001    (1<<OFIFO_CONTROL_SD_BITPOS)
#define OFIFO_CONTROL_SD_010    (2<<OFIFO_CONTROL_SD_BITPOS)
#define OFIFO_CONTROL_SD_100    (4<<OFIFO_CONTROL_SD_BITPOS)
#define OFIFO_CONTROL_SD_101    (5<<OFIFO_CONTROL_SD_BITPOS)
#define OFIFO_CONTROL_SD_110    (6<<OFIFO_CONTROL_SD_BITPOS)

#define OFIFO_STATUS_FC         (1<<0)
#define OFIFO_STATUS_ERR        (1<<1)

//////////////////////////////////////////////////////////////////////

#define GPDMA_RAMADDR    0 // 0x0000
#define GPDMA_MEMADDR    4 // 0x0004
#define GPDMA_CONTROL    8 // 0x0008
#define GPDMA_STATUS    12 // 0x000C
#define GPDMA_NUMWORDS  16 // 0x0010

#ifndef ASSEMBLER
typedef volatile struct
{
    bsaReg ramaddr;
    bsaReg memaddr;
    bsaReg control; 
    bsaReg status;
    bsaReg numwords;

    bsaReg _pad[16-5];
} bsa_gpdma_t;
#endif

#define GPDMA_RAMADDR_RAMSEL        (1<<15)
#define GPDMA_RAMADDR_RAMSEL_DRAM   (0<<15)
#define GPDMA_RAMADDR_RAMSEL_IRAM   (1<<15)
#define GPDMA_RAMADDR_ADDR_BITPOS   2
#define GPDMA_RAMADDR_ADDR          (0x1FFF << GPDMA_RAMADDR_ADDR_BITPOS)

#define GPDMA_MEMADDR_ADDR          0xFFFFFFFC

#define GPDMA_CONTROL_START         (1<<0)
#define GPDMA_CONTROL_DIRECTION     (1<<1)
#define GPDMA_CONTROL_DIRECTION_R2M (0<<1)
#define GPDMA_CONTROL_DIRECTION_M2R (1<<1)
#define GPDMA_CONTROL_SD_BITPOS     2
#define GPDMA_CONTROL_SD            (7<<GPDMA_CONTROL_SD_BITPOS)
#define GPDMA_CONTROL_SD_000        (0<<GPDMA_CONTROL_SD_BITPOS)
#define GPDMA_CONTROL_SD_001        (1<<GPDMA_CONTROL_SD_BITPOS)
#define GPDMA_CONTROL_SD_010        (2<<GPDMA_CONTROL_SD_BITPOS)
#define GPDMA_CONTROL_SD_100        (4<<GPDMA_CONTROL_SD_BITPOS)
#define GPDMA_CONTROL_SD_101        (5<<GPDMA_CONTROL_SD_BITPOS)
#define GPDMA_CONTROL_SD_110        (6<<GPDMA_CONTROL_SD_BITPOS)

#define GPDMA_STATUS_TC             (1<<0)

#define GPDMA_NUMWORDS_NUMWORDS_BITPOS 2
#define GPDMA_NUMWORDS_NUMWORDS     (0x0FFF << GPDMA_NUMWORDS_NUMWORDS_BITPOS)

//////////////////////////////////////////////////////////////////////

#define VLC_VALUE1  0x03EC
#define VLC_VALUE0  0x03F0
#define VLC_DONE    0x03F4
#define VLC_LPCNT   0x03F8
#define VLC_STATUS  0x03FC

#define MAX_VLCCFG_REGS 45

#ifndef ASSEMBLER
typedef volatile struct
{
    struct
    {
        bsaReg cfg;
        bsaReg descw0;
        bsaReg descw1;
        bsaReg _pad;
    } vlccfg[62]; // NOTE: Only MAX_VLCCFG_REGS are implemented
    bsaReg _reserved[3];
    bsaReg value1;
    bsaReg value0;
    bsaReg done;
    bsaReg lpcnt;
    bsaReg status;
} bsa_vlc_t;
#endif

// These are the DONE encodings in a table entry
#define VLC_NOT_DONE        0
#define VLC_DONE_NORMAL     1
#define VLC_ESCAPE_SEQUENCE 2
#define VLC_LOOP_DONE       3
#define VLC_DONE_UNUSED4    4
#define VLC_DONE_UNUSED5    5
#define VLC_DONE_UNUSED6    6
#define VLC_DONE_UNUSED7    7

// field positions and masks (from the 32-bit Au1 perspective)
#define VLCCFG_ADDR_BITPOS 2
#define VLCCFG_DO0_BITPOS  17
#define VLCCFG_DO1_BITPOS  18
#define VLCCFG_DM0_BITPOS  19
#define VLCCFG_DM1_BITPOS  20
#define VLCCFG_DM2_BITPOS  21
#define VLCCFG_SE0_BITPOS  22
#define VLCCFG_PS0_BITPOS  23
#define VLCCFG_LDV_BITPOS  24
#define VLCCFG_MAX_BITPOS  25

#define VLCCFG_ADDR        (0x0FFF << VLCCFG_ADDR_BITPOS)
#define VLCCFG_DO0         (1 << VLCCFG_DO0_BITPOS)
#define VLCCFG_DO1         (1 << VLCCFG_DO1_BITPOS)
#define VLCCFG_DM0         (1 << VLCCFG_DM0_BITPOS)
#define VLCCFG_DM1         (1 << VLCCFG_DM1_BITPOS)
#define VLCCFG_DM2         (1 << VLCCFG_DM2_BITPOS)
#define VLCCFG_SE0         (1 << VLCCFG_SE0_BITPOS)
#define VLCCFG_PS0         (1 << VLCCFG_PS0_BITPOS)
#define VLCCFG_LDV         (1 << VLCCFG_LDV_BITPOS)
#define VLCCFG_MAX         (0x7F << VLCCFG_MAX_BITPOS)

#define VLCDESCW0_V0W_BITPOS    0
#define VLCDESCW0_V1W_BITPOS    4
#define VLCDESCW0_V0FW_BITPOS   8
#define VLCDESCW0_V1FW_BITPOS   12
#define VLCDESCW0_DNL1_BITPOS   16
#define VLCDESCW0_OFW1_BITPOS   21
#define VLCDESCW0_TBW1_BITPOS   25
#define VLCDESCW0_LB_BITPOS     28
#define VLCDESCW0_SE1_BITPOS    29
#define VLCDESCW0_PS1_BITPOS    30
#define VLCDESCW0_V1P_BITPOS    31
#define VLCDESCW1_DNL2_BITPOS   0
#define VLCDESCW1_OFW2_BITPOS   5
#define VLCDESCW1_TBW2_BITPOS   9
#define VLCDESCW1_DNLX_BITPOS   12
#define VLCDESCW1_OFWX_BITPOS   17
#define VLCDESCW1_TBWX_BITPOS   21

#define VLCDESCW0_V0W       (0xF << VLCDESCW0_V0W_BITPOS)
#define VLCDESCW0_V1W       (0xF << VLCDESCW0_V1W_BITPOS)
#define VLCDESCW0_V0FW      (0xF << VLCDESCW0_V0FW_BITPOS)
#define VLCDESCW0_V1FW      (0xF << VLCDESCW0_V1FW_BITPOS)
#define VLCDESCW0_DNL1      (0x1F << VLCDESCW0_DNL1_BITPOS)
#define VLCDESCW0_OFW1      (0xF << VLCDESCW0_OFW1_BITPOS)
#define VLCDESCW0_TBW1      (0x7 << VLCDESCW0_TBW1_BITPOS)
#define VLCDESCW0_LB        (0x1 << VLCDESCW0_LB_BITPOS)
#define VLCDESCW0_SE1       (0x1 << VLCDESCW0_SE1_BITPOS)
#define VLCDESCW0_PS1       (0x1 << VLCDESCW0_PS1_BITPOS)
#define VLCDESCW0_V1P       (0x1 << VLCDESCW0_V1P_BITPOS)
#define VLCDESCW1_DNL2      (0x1F << VLCDESCW1_DNL2_BITPOS)
#define VLCDESCW1_OFW2      (0xF << VLCDESCW1_OFW2_BITPOS)
#define VLCDESCW1_TBW2      (0x7 << VLCDESCW1_TBW2_BITPOS)
#define VLCDESCW1_DNLX      (0x1F << VLCDESCW1_DNLX_BITPOS)
#define VLCDESCW1_OFWX      (0xF << VLCDESCW1_OFWX_BITPOS)
#define VLCDESCW1_TBWX      (0x7 << VLCDESCW1_TBWX_BITPOS)

#define VLC_STATUS_ESC_BITPOS   0
#define VLC_STATUS_ERR_BITPOS   1
#define VLC_STATUS_MAX_BITPOS   2
#define VLC_STATUS_ESC          (1 << VLC_STATUS_ESC_BITPOS)
#define VLC_STATUS_ERR          (1 << VLC_STATUS_ERR_BITPOS)
#define VLC_STATUS_MAX          (1 << VLC_STATUS_MAX_BITPOS)

#define VLC_LPCNT_LPCNT_BITPOS  0
#define VLC_LPCNT_LPCNT         (0xFF << VLC_LPCNT_LPCNT_BITPOS)

#define VLCTAB_DONE_BITPOS      0
#define VLCTAB_SA_BITPOS        3
#define VLCTAB_VALUE0_BITPOS    6
#define VLCTAB_OFFSET_BITPOS    3

//////////////////////////////////////////////////////////////////////

#define NEIGH_PICSIZE            0 // 0x0000
#define NEIGH_SPADDR             4 // 0x0004
#define NEIGH_SPSIZE             8 // 0x0008
#define NEIGH_CONTROL           12 // 0x000c
#define NEIGH_MBINFO            16 // 0x0010
#define NEIGH_PICINFO           20 // 0x0014
#define NEIGH_SLICEGRPMAPPTR    24 // 0x0018
#define NEIGH_STARTMAPVAL       28 // 0x001C
#define NEIGH_STARTMAPPOS       32 // 0x0020
#define NEIGH_STARTMAPMBADDR    36 // 0x0024
#define NEIGH_DMACURRPOS        40 // 0x0028
#define NEIGH_DMAMBADDR         44 // 0x002C
#define NEIGH_PORT0CURRPOS      48 // 0x0030
#define NEIGH_PORT0MBADDR       52 // 0x0034
#define NEIGH_SGMEND            56 // 0x0038

#ifndef ASSEMBLER
typedef struct
{
    bsaReg picsize;
    bsaReg spaddr;
    bsaReg spsize;
    bsaReg control;
    bsaReg mbinfo;
    bsaReg picinfo;
    bsaReg slicegrpmapptr;
    bsaReg startmapval;
    bsaReg startmappos;
    bsaReg startmapmbaddr;
    bsaReg dmacurrpos;
    bsaReg dmambaddr;
    bsaReg port0currpos;
    bsaReg port0mbaddr;
    bsaReg sgmend;
    bsaReg _pad[16-15];
} bsa_neigh_t;
#endif

#define NEIGH_PICSIZE_VERT_BITPOS   0
#define NEIGH_PICSIZE_HORZ_BITPOS   16
#define NEIGH_PICSIZE_VERT          (0x01FF << NEIGH_PICSIZE_VERT_BITPOS)
#define NEIGH_PICSIZE_HORZ          (0x01FF << NEIGH_PICSIZE_HORZ_BITPOS)

#define NEIGH_SPSIZE_IDLE_BITPOS        (0) // within HI16
#define NEIGH_SPSIZE_IDLE               (1<<NEIGH_SPSIZE_IDLE_BITPOS)

#define NEIGH_CONTROL_ENABLE            (1<<0)
#define NEIGH_CONTROL_PORT0ACTIVE       (1<<1)
#define NEIGH_CONTROL_PORT1ACTIVE       (1<<2)
#define NEIGH_CONTROL_CODECTYPE_BITPOS  3
#define NEIGH_CONTROL_CODECTYPE         (15<<NEIGH_CONTROL_CODECTYPE_BITPOS)
#define NEIGH_CONTROL_CODECTYPE_MPEG2   (0<<NEIGH_CONTROL_CODECTYPE_BITPOS)
#define NEIGH_CONTROL_CODECTYPE_MPEG4   (1<<NEIGH_CONTROL_CODECTYPE_BITPOS)
#define NEIGH_CONTROL_CODECTYPE_VC1     (2<<NEIGH_CONTROL_CODECTYPE_BITPOS)
#define NEIGH_CONTROL_CODECTYPE_VC1AP   (3<<NEIGH_CONTROL_CODECTYPE_BITPOS)
#define NEIGH_CONTROL_CODECTYPE_CABAC   (4<<NEIGH_CONTROL_CODECTYPE_BITPOS)
#define NEIGH_CONTROL_CODECTYPE_CAVLC   (5<<NEIGH_CONTROL_CODECTYPE_BITPOS)
#define NEIGH_CONTROL_CODECTYPE_JPEG    (7<<NEIGH_CONTROL_CODECTYPE_BITPOS)
#define NEIGH_CONTROL_SGMEN_BITPOS      7
#define NEIGH_CONTROL_SGMEN             (1<<NEIGH_CONTROL_SGMEN_BITPOS)
#define NEIGH_CONTROL_W_BITPOS          0
#define NEIGH_CONTROL_W                 (1<<NEIGH_CONTROL_W_BITPOS)

#define NEIGH_MBINFO_MBTYPE_BITPOS      0
#define NEIGH_MBINFO_MBTYPE             (0x3F<<NEIGH_MBINFO_MBTYPE_BITPOS)
#define NEIGH_MBINFO_PM_BITPOS          6
#define NEIGH_MBINFO_PM_INTER           (1<<NEIGH_MBINFO_PM_BITPOS)

#define NEIGH_PICINFO_PICSIZEINMBS      (0xFFFF)
#define NEIGH_PICINFO_MFF_BITPOS        16
#define NEIGH_PICINFO_MFF               (1<<NEIGH_PICINFO_MFF_BITPOS)

//////////////////////////////////////////////////////////////////////

#ifndef ASSEMBLER
typedef struct
{
    bsaReg gpr0001;
    bsaReg gpr0203;
    bsaReg gpr0405;
    bsaReg gpr0607;
    bsaReg gpr0809;
    bsaReg gpr1011;
    bsaReg gpr1213;
    bsaReg gpr1415;
    bsaReg gpr1617;
    bsaReg gpr1819;
    bsaReg gpr2021;
    bsaReg gpr2223;
    bsaReg gpr2425;
    bsaReg gpr2627;
    bsaReg gpr2829;
    bsaReg gpr3031;
    bsaReg pc;
    bsaReg globperfctrl;
    bsaReg perfctrl0;
    bsaReg perfctrl1;
    bsaReg perfcnt0;
    bsaReg perfcnt1;
    bsaReg _pad[32-22];
} bsa_perf_t;
#endif

//////////////////////////////////////////////////////////////////////

/*
 * This structure brings together all the BSA resources visible to the
 * Au1 (and SCB) into one neat little data structure.
 */
#ifndef ASSEMBLER
typedef volatile struct
{
    bsa_vlc_t       vlc;
    bsa_ififo_t     ififo;
    bsa_ofifo_t     ofifo0;
    bsa_ofifo_t     ofifo1;
    bsa_gpdma_t     gpdma;
    bsa_cabac_t     cabac;
    bsa_cavlc_t     cavlc;
    bsa_neigh_t     neigh;
    bsaReg          _reserved0[16];
    bsaReg          _mae_dma[16];
    bsa_scb_t       scb;
    bsaReg          _reserved1[16*2];
    bsaReg          mae_dma[16*4];
    bsaReg          _reserved8[16*4];
    bsaReg          _reserved9[16*4];
    bsaReg          _reservedA[16*4];
    bsaReg          _reservedB[16*4];
    bsaReg          _reservedC[16*4];
    bsaReg          _reservedD[16*4];
    bsa_mvpred_t    mvpred;

} bsa_regs_t;
#endif

// Base addresses from the BSA/SCB perspective.
// Note that it is intended that all BSA peripherals which may need to be
// exposed to the Au1 be contained within a single 4KB address space which
// can then easily be mapped into the codec space on the Au1.
#define BSA_REGS_ADDR   0x7000
#define VLC_BSA_ADDR    (BSA_REGS_ADDR+0x0000)
#define IFIFO_BSA_ADDR  (BSA_REGS_ADDR+0x0400)
#define OFIFO0_BSA_ADDR (BSA_REGS_ADDR+0x0440)
#define OFIFO1_BSA_ADDR (BSA_REGS_ADDR+0x0480)
#define GPDMA_BSA_ADDR  (BSA_REGS_ADDR+0x04C0)
#define CABAC_BSA_ADDR  (BSA_REGS_ADDR+0x0500)
#define CAVLC_BSA_ADDR  (BSA_REGS_ADDR+0x0540)
#define NEIGH_BSA_ADDR  (BSA_REGS_ADDR+0x0580)
#define SCB_BSA_ADDR    (BSA_REGS_ADDR+0x0640)
#define GPR_BSA_ADDR    (BSA_REGS_ADDR+0x0700)
#define MVPRED_BSA_ADDR (BSA_REGS_ADDR+0x0E00)

// Base addresses from the Au1 perspective
#define BSA_PHYS_ADDR       0x14030000 

#ifndef ASSEMBLER
typedef volatile struct
{
    unsigned int    dram[(28*1024)/sizeof(unsigned int)];
    bsa_regs_t  regs;
    unsigned int    iram[(32*1024)/sizeof(unsigned int)];
} bsa_t;
#endif

//////////////////////////////////////////////////////////////////////

#ifdef __cplusplus
}
#endif

#endif // __bsa_h__


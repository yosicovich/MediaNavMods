/**********************************************************************
* Copyright 2007 RMI Corp. All Rights Reserved.
*
* Unless otherwise designated in writing, this software and any related
* documentation are the confidential proprietary information of RMI
* Corp.
*
* THESE MATERIALS ARE PROVIDED "AS IS" WITHOUT ANY
* UNLESS OTHERWISE NOTED IN WRITING, EXPRESS OR IMPLIED WARRANTY OF ANY
* KIND, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* NONINFRINGEMENT, TITLE, FITNESS FOR ANY PARTICULAR PURPOSE AND IN NO
* EVENT SHALL RMI COPR. OR ITS LICENSORS BE LIABLE FOR ANY DAMAGES
* WHATSOEVER.
*
* RMI Corp. does not assume any responsibility for any errors which may
* appear in the Materials nor any responsibility to support or update
* the Materials. RMI Corp. retains the right to modify the Materials
* at any time, without notice, and is not obligated to provide such
* modified Materials to you. RMI Corp. is not obligated to furnish,
* support, or make any further information available to you.
***********************************************************************/
//------------------------------------------------------------------------------
// File: mae_bsa.cpp
//------------------------------------------------------------------------------
#include <windows.h>
#include <platform.h>
#include <bceddk.h>
#include <dbgapi.h>
#include <au1x00.h>
#include "maeioctl.h"
#include "bsa.h"

#define BSA_THREAD_PRIORITY THREAD_PRIORITY_TIME_CRITICAL

#define	kVersion_Main		      1		// Main version number
#define kVersion_Sub		      2		// Sub version number
#define	kVersion_Build		    TEXT(__DATE__)		// Major Build number
#define	kVersion_BuildSub	    TEXT(__TIME__)		// Minor Build number

typedef struct
{
	DWORD	dwSize;
	CRITICAL_SECTION CriticalSection;
	INT		nNumOpens;
	HANDLE	hDoneEvent;
	HANDLE	hCloseEvent;
	HANDLE	hIntrEvent;
	HANDLE	hIntrThread;
	INT		nIrqlMae;
  	bsa_t	*bsa;
	AU13XX_VSSCTRL *vss;
	DWORD	timeoutMilliseconds;
	uint32  endScbStatus;
	uint32  endOfifo0PhysAddr;
	uint32  endOfifo1PhysAddr;
	uint32  endMailbox0;
	uint32  endMailbox1;
	uint32  endMailbox2;
	uint32  endMailbox3;
	uint32  endBitcounter;
	uint32	endMipsCounter;
} DRVCONTEXT, *PDRVCONTEXT;

#define EnterCS(x) EnterCriticalSection(&x)
#define LeaveCS(x) LeaveCriticalSection(&x)
//////////////////////////////////////////////////////////////////////
//	Add this to your project environment variables to use these drivers:
//	BSP_MEDIA_V20
//
//////////////////////////////////////////////////////////////////////

int VerifyContextHandle(PDRVCONTEXT pDrv);
void ShowVersion(void);
DWORD InitEventsAndThreads(DWORD dwContext);
ULONG InterruptThread(LPVOID dwContext);

// Debug zone support
#define DTAG TEXT("BSA: ")
#define ZONE_ERROR  DEBUGZONE(0)
#define ZONE_INIT   DEBUGZONE(1)
#define ZONE_FUNC   DEBUGZONE(2)
#define ZONE_DRVCALLS  DEBUGZONE(3)
#define ZONE_INFO   DEBUGZONE(4)
#define ZONE_INT	DEBUGZONE(5)
#define ZONE_REGISTERS DEBUGZONE(6)
#define ZONE_EXENTRY  (ZONE_FUNC | ZONE_DRVCALLS)

DBGPARAM dpCurSettings =
{
  TEXT("bsa"),
  {
    TEXT("Errors"), TEXT("Init"), TEXT("Functions"),
    TEXT("DriverCalls"), TEXT("Info"), TEXT("INT"),
    TEXT("Registers"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined")
  },
  0x0001
};


///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
static void
maebsa_reset (PDRVCONTEXT pDrv, int reset)
{
    AU13XX_VSSCTRL *vss = pDrv->vss;
    volatile uint32 junk;

    if (reset)
    {
        vss->bsa.clkrst = 3;
    }
    else
    {
        vss->bsa.clkrst = 2;
    }

    // Read-back to force write to go out, provides more time when cycling reset
    junk = vss->bsa.clkrst;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
static void
maebsa_power (PDRVCONTEXT pDrv, int up)
{
	VSSREQ vss_req;

	if (up)
	{
		DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+enable_bsa_power\r\n")));

		maebsa_reset(pDrv, 1);

		vss_req.block  = VSS_BSA;
		vss_req.enable = TRUE;

		KernelIoControl(
			IOCTL_HAL_VSS,
			&vss_req,
			sizeof(vss_req),
			NULL,
			0,
			NULL
			);

		maebsa_reset(pDrv, 0);
	}
	else
	{
		DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+disable_bsa_power\r\n")));

		vss_req.block  = VSS_BSA;
		vss_req.enable = FALSE;

		KernelIoControl(
			IOCTL_HAL_VSS,
			&vss_req,
			sizeof(vss_req),
			NULL,
			0,
			NULL
		);

		maebsa_reset(pDrv, 1);
	}
}

///////////////////////////////////////////////////////////////////////////////
static int
maebsa_transaction (PDRVCONTEXT pDrv, mae_bsa_request_t *tr)
{
	bsa_t *bsa = pDrv->bsa;
    int timeout, OK = 1;

// TODO:
// Add microseconds
//    tr->begMipsCounter = read_c0_count();

    // Sanity checks
    if (tr->iramPhysAddr == 0x00000000) OK = 0;
    if (tr->dramPhysAddr == 0x00000000) OK = 0;
    if (tr->pmmPhysAddr == 0x00000000) OK = 0;
    if (tr->ofifo0StartPhysAddr == 0x00000000) OK = 0;
    if (tr->ofifo1StartPhysAddr == 0x00000000) OK = 0;
    if (tr->ofifo0EndPhysAddr == 0x00000000) OK = 0;
    if (tr->ofifo1EndPhysAddr == 0x00000000) OK = 0;
    if (tr->neighPhysAddr == 0x00000000) OK = 0;
    if (tr->descPhysAddr == 0x00000000) OK = 0;
    if (tr->numEntries == 0) OK = 0;
    if (!OK)
    {
        RETAILMSG(1, (TEXT("Problem with BSA request\r\n")));
        return 0;
    }

	maebsa_reset(pDrv, 1);
	maebsa_reset(pDrv, 0);

    // Configure OFIFOs
    bsa->regs.ofifo0.addr.WD32 = tr->ofifo0StartPhysAddr;
    bsa->regs.ofifo0.endaddr.WD32 = tr->ofifo0EndPhysAddr;
    bsa->regs.ofifo1.addr.WD32 = tr->ofifo1StartPhysAddr;
    bsa->regs.ofifo1.endaddr.WD32 = tr->ofifo1EndPhysAddr;
    bsa->regs.ofifo0.control.WD32 = OFIFO_CONTROL_S | tr->ofifo0Control;
    bsa->regs.ofifo1.control.WD32 = OFIFO_CONTROL_S | tr->ofifo1Control;

    // Configure Parsed Macroblock Map
    bsa->regs.scb.mailbox0.WD32 = tr->pmmPhysAddr;

    // Load IRAM (using GPDMA)
    bsa->regs.gpdma.ramaddr.WD32 = 0x00008000;
    bsa->regs.gpdma.memaddr.WD32 = tr->iramPhysAddr;
    bsa->regs.gpdma.numwords.WD32 = tr->iramSize;
    bsa->regs.gpdma.control.WD32 = GPDMA_CONTROL_DIRECTION_M2R|GPDMA_CONTROL_START|tr->gpdmaControl;
    // Wait for it to finish
    timeout = 0x00100000;
    do
    {
        if (bsa->regs.gpdma.status.WD32 & GPDMA_STATUS_TC)
            break;
    } while (--timeout > 0);
    if (timeout == 0) 
	{ 
		OK = 0; 
		RETAILMSG(1, (TEXT("error: IRAM load failed\n"))); 
	}

    // Load DRAM (using GPDMA)
    bsa->regs.gpdma.ramaddr.WD32 = 0x00000000;
    bsa->regs.gpdma.memaddr.WD32 = tr->dramPhysAddr;
    bsa->regs.gpdma.numwords.WD32 = tr->dramSize;
    bsa->regs.gpdma.control.WD32 = GPDMA_CONTROL_DIRECTION_M2R|GPDMA_CONTROL_START|tr->gpdmaControl;
    // Wait for it to finish
    timeout = 0x00100000;
    do
    {
        if (bsa->regs.gpdma.status.WD32 & GPDMA_STATUS_TC)
            break;
    } while (--timeout > 0);
    if (timeout == 0) 
	{ 
		OK = 0; 
		RETAILMSG(1, (TEXT("error: DRAM load failed\n"))); 
	}

    // Configure IFIFO
    bsa->regs.ififo.control.WD32 = tr->ififoControl;
    bsa->regs.ififo.pattern.WD32 = tr->ififoPattern;
    bsa->regs.ififo.numentries.WD32 = 0;
    bsa->regs.ififo.listaddr.WD32 = tr->descPhysAddr;
    bsa->regs.ififo.numentries.WD32 = tr->numEntries;

    // Configure Neighbor
    bsa->regs.neigh.spaddr.WD32 = tr->neighPhysAddr;

    // Configure SCB
    bsa->regs.scb.status.WD32 = 0;
    bsa->regs.scb.mailbox1.WD32 = tr->mailbox1;
    bsa->regs.scb.mailbox2.WD32 = tr->mailbox2;
    bsa->regs.scb.mailbox3.WD32 = tr->mailbox3;
    bsa->regs.scb.watchdog.WD32 = tr->watchdog;
    bsa->regs.scb.status.WD32 = 0;
    bsa->regs.scb.mask.WD32 = tr->irqMask;
    bsa->regs.scb.addr.WD32 = tr->initPC;

    if (OK)
    {
		DWORD result;

        // Now block waiting for BSA to finish - solves race of BSA IRQ occuring before
        // kernel has a chance to put process to sleep (think a few byte slice finishing really fast)
		bsa->regs.scb.go.WD32 = SCB_GO_GO;
		//RETAILMSG(1, (TEXT(" +BSA WaitForDoneEvent\r\n")));
		result = WaitForSingleObject(pDrv->hDoneEvent, pDrv->timeoutMilliseconds);
		//RETAILMSG(1, (TEXT(" -BSA WaitForDoneEvent\r\n")));

		// If an error occured, place BSA in reset to clear out any bad state
		if ((result == WAIT_TIMEOUT) || (bsa->regs.scb.status.WD32 != SCB_STATUS_DONE))
			maebsa_reset(pDrv, 1);
    }

    // Provide feedback from BSA run
    tr->bsaStatus = pDrv->endScbStatus;
    tr->endOfifo0PhysAddr = pDrv->endOfifo0PhysAddr;
    tr->endOfifo1PhysAddr = pDrv->endOfifo1PhysAddr;
    tr->endMailbox0 = pDrv->endMailbox0;
    tr->endMailbox1 = pDrv->endMailbox1;
    tr->endMailbox2 = pDrv->endMailbox2;
    tr->endMailbox3 = pDrv->endMailbox3;
    tr->endBitcounter = pDrv->endBitcounter;
    //tr->endMipsCounter = pDrv->endMipsCounter;

	return OK;
}

///////////////////////////////////////////////////////////////////////////////
// BSA_IOControl
//
// This routine handles all IOCTLs for MAE related activities. It will dispatch
// to include library IOCTL handlers.
//
// Parameters :
//		dwContext   		pointer to driver instance structure
//      dwIoControlCode		IOCTL command
//		pInBuf				Pointer to input data from caller
//      nInBufSize			Size of input data
//      pOutBuf				Pointer to output memory in caller's memory space
//		nOutBufSize			Size of memory available for output
//      pBytesReturned		Pointer to DWORD that will contain the number of 
//								bytes placed in caller's output buffer
//
// Returns :
//      TRUE				Handled IOCTL successfuly
//      FALSE				Failed to handle IOCTL
//
///////////////////////////////////////////////////////////////////////////////
DWORD BSA_IOControl(DWORD dwContext, DWORD dwIoControlCode, PBYTE pInBuf, DWORD dwInBufSize, PBYTE pOutBuf,
                    DWORD dwOutBufSize, PDWORD pdwBytesReturned)
{
	PDRVCONTEXT		pDrv = (PDRVCONTEXT) dwContext;
	mae_bsa_request_t *tr  = (mae_bsa_request_t *) pInBuf;
	BOOL			RetVal = TRUE;
	int rcode;

	DEBUGMSG (ZONE_FUNC, (TEXT("+BSA_IOControl dwContext: 0x08%x  dwCode: 0x08%x\r\n"), dwContext, dwIoControlCode));

	if ( (NULL == tr) || (NULL == pDrv) )
	{
		return FALSE;
	}

	if (tr->magic != MAEBSA_MAGIC)
	{
		RETAILMSG(1, (TEXT("BAD BSA_IOControl %08X\r\n"), tr->magic));
		return FALSE;
	}

	switch (dwIoControlCode)
	{
		case MAEBSA_IOCTL_SUBMIT_TRANSACTION:
			rcode = maebsa_transaction (pDrv, tr);
			return rcode;
			break;

		default :
			RETAILMSG(1, (TEXT("BAD BSA_IOControl request %08X\r\n"), dwIoControlCode));
			return FALSE;
			break;
	}

	return TRUE;
}



///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void enable_bsa_interrupt(PDRVCONTEXT pDrv)
{
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void disable_bsa_interrupt(PDRVCONTEXT pDrv)
{
}



///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD BSA_Init (DWORD dwContext)
{
	PHYSICAL_ADDRESS    PhysAddr;
	PDRVCONTEXT pDrv;

	DEBUGMSG(ZONE_INIT | ZONE_EXENTRY,
		(DTAG TEXT("+BSA_Init dwContext:0x%08x\r\n"), dwContext));

	// Allocate a device instance structure from the heap
	pDrv = (PDRVCONTEXT)LocalAlloc(LPTR, sizeof(DRVCONTEXT));
	if (pDrv)
	{
		memset((PBYTE)pDrv, 0, sizeof(DRVCONTEXT));
		pDrv->dwSize = sizeof(DRVCONTEXT);
	} else
	{
		DEBUGMSG(ZONE_INIT | ZONE_ERROR,
		  (DTAG TEXT("BSA_Init failure. Out of memory\r\n")));
		return 0;
	}

	// Map the BSA physical register space
	PhysAddr.HighPart = 0;
	PhysAddr.LowPart  = BSA_PHYS_ADDR;
	pDrv->bsa = (bsa_t *)MmMapIoSpace(PhysAddr, sizeof(bsa_t), FALSE);
	if (NULL == pDrv->bsa) 	{
		DEBUGMSG(ZONE_ERROR, (TEXT("BSA_Init failed to map memory: 0x%08X\r\n"), PhysAddr.LowPart));
		LocalFree(pDrv);
		return 0;
	}

	// Map the VSS physical register space
	PhysAddr.HighPart = 0;
	PhysAddr.LowPart  = VSS_PHYS_ADDR;
	pDrv->vss = (AU13XX_VSSCTRL *)MmMapIoSpace(PhysAddr, sizeof(AU13XX_VSSCTRL), FALSE);
	if (NULL == pDrv->vss) 	{
		DEBUGMSG(ZONE_ERROR, (TEXT("BSA_Init failed to map memory: 0x%08X\r\n"), PhysAddr.LowPart));
		LocalFree(pDrv);
		return 0;
	}

	// NOTE: This timeout value must be LARGER than the BSA.SCB.WATCHDOG value
	// (as interpreted in milliseconds); otherwise this could result in asserting
	// BSA RESET while the BSA in in the middle of an active transaction, and
	// putting the DMA engines in an unrecoverable state.
	pDrv->timeoutMilliseconds = 300; // INFINITE, or non-zero value (preferrably from registry)

	InitializeCriticalSection(&(pDrv->CriticalSection));

	// save power until we are actively using this hardware
	maebsa_power(pDrv, 0);

	// Connect and initialize interrupt
	pDrv->nIrqlMae = InterruptConnect(Internal, 0, ((HWINTR_BSA)), 0);
	InterruptDone(pDrv->nIrqlMae); // clear spurious intrs at init

	ShowVersion();

	return (DWORD)pDrv;
}


///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD  BSA_Deinit (DWORD dwContext)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_EXENTRY,	(DTAG TEXT("+BSA_Deinit dwContext:0x%08x\r\n"), dwContext));

	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	// Cleanup everything we did in init
	InterruptDisconnect(pDrv->nIrqlMae);
	DeleteCriticalSection(&(pDrv->CriticalSection));
	MmUnmapIoSpace((PVOID)pDrv->bsa, sizeof(bsa_t));
	LocalFree(pDrv);

	maebsa_power(pDrv, 0);

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("-BSA_Deinit\r\n")));

	return (DWORD)pDrv;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD BSA_Open(DWORD dwContext, DWORD dwAccess, DWORD dwShare)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_EXENTRY,
	(DTAG TEXT("+BSA_Open dwContext:0x%08x\r\n"), dwContext));
	//RETAILMSG(1, (TEXT("+BSA_Open dwContext:0x%08x\r\n"), dwContext));

	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	EnterCS(pDrv->CriticalSection);
	if (pDrv->nNumOpens == 0)
	{
		maebsa_power(pDrv, 1);
		(DWORD)pDrv = InitEventsAndThreads(dwContext);
		enable_bsa_interrupt(pDrv);
	}

	// Count the number of open instances
	InterlockedIncrement ((long *)&pDrv->nNumOpens);
	LeaveCS(pDrv->CriticalSection);

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("-BSA_Open: pDrv->nNumOpens %d\r\n"),pDrv->nNumOpens));

	return (DWORD)pDrv;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL  BSA_Close (DWORD dwContext, DWORD dwOpen)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_EXENTRY,
		(DTAG TEXT("+BSA_Close dwOpen: 0x%08x\r\n"), dwOpen));

	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	EnterCS(pDrv->CriticalSection);
	if (pDrv->nNumOpens)
		InterlockedDecrement((long *)&pDrv->nNumOpens);

	if (pDrv->nNumOpens == 0)
	{
		disable_bsa_interrupt(pDrv);
		// Un-register the interrupts with OS
		InterruptDisable(pDrv->nIrqlMae);
		maebsa_power(pDrv, 0);

		// Wait for the interrupt handler to close
		WaitForSingleObject(pDrv->hCloseEvent, 100);

		// Close all handles
		CloseHandle(pDrv->hIntrEvent);
		CloseHandle(pDrv->hIntrThread);
		CloseHandle(pDrv->hDoneEvent);
		CloseHandle(pDrv->hCloseEvent);
	}

	LeaveCS(pDrv->CriticalSection);

	DEBUGMSG (ZONE_FUNC,
		(DTAG TEXT("-BSA_Close: pDrv->nNumOpens %d\r\n"),pDrv->nNumOpens));\

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD InitEventsAndThreads(DWORD dwContext)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+InitEventsAndThreads\r\n")));
	
	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	if ((pDrv->hDoneEvent = CreateEvent(NULL, FALSE, FALSE, NULL) )== NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateEvent failed for hDoneEvent\r\n")));
		return 1;
	}

	if ((pDrv->hCloseEvent = CreateEvent(NULL, FALSE, FALSE, NULL) )== NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateEvent failed for hCloseEvent\r\n")));
		return 1;
	}

	if ((pDrv->hIntrEvent = CreateEvent(NULL, FALSE, FALSE, NULL) )== NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateEvent failed for hIntrEvent\r\n")));
		return 1;
	}

	pDrv->hIntrThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)InterruptThread,
									  (LPVOID)(dwContext), 0, NULL);

	if (pDrv->hIntrThread == NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateThread failed\r\n")));
		return 1;
	}

	if (FALSE == CeSetThreadPriority(pDrv->hIntrThread, BSA_THREAD_PRIORITY))
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("SetThreadPriority failed\r\n")));
	}

	return (DWORD)pDrv;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
inline BOOL DriverIsOpen(LPVOID dwContext)
{
	BOOL bIsOpen = FALSE;

	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	EnterCS(pDrv->CriticalSection);
	if (pDrv->nNumOpens > 0)
	{	
		bIsOpen = TRUE;
	}
	LeaveCS(pDrv->CriticalSection);

	return bIsOpen;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
ULONG InterruptThread(LPVOID dwContext)
{
	ULONG ulWaitResult = 0;
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;
	bsa_t *bsa = pDrv->bsa;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+InterruptThread\r\n")));
  
	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	CeSetThreadPriority(GetCurrentThread(),BSA_THREAD_PRIORITY);


	if (InterruptInitialize(pDrv->nIrqlMae, pDrv->hIntrEvent, NULL, 0) != TRUE)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("InterruptInitialize failed\r\n")));
		return 1;
	}

	while (DriverIsOpen(dwContext)) // loop till driver close is called or an error happens
	{
		InterruptDone(pDrv->nIrqlMae);

		ulWaitResult = WaitForSingleObject(pDrv->hIntrEvent, INFINITE);

		// Save regs for return to caller
		pDrv->endScbStatus = bsa->regs.scb.status.WD32;
		pDrv->endOfifo0PhysAddr = bsa->regs.ofifo0.addr.WD32;
		pDrv->endOfifo1PhysAddr = bsa->regs.ofifo1.addr.WD32;
		pDrv->endMailbox0 = bsa->regs.scb.mailbox0.WD32;
		pDrv->endMailbox1 = bsa->regs.scb.mailbox1.WD32;
		pDrv->endMailbox2 = bsa->regs.scb.mailbox2.WD32;
		pDrv->endMailbox3 = bsa->regs.scb.mailbox3.WD32;
		pDrv->endBitcounter = bsa->regs.ififo.bitcounter.WD32;

		//RETAILMSG(1, (TEXT(" BSA IREQ %08x\r\n"), pDrv->endScbStatus));

		EnterCS(pDrv->CriticalSection);
// TODO:
// Clear status bit
//		pDrv->endMipsCounter = read_c0_count();
		bsa->regs.scb.status.WD32 = 0; // ack interrupts
		SetEvent(pDrv->hDoneEvent);
		LeaveCS(pDrv->CriticalSection);

	}

	SetEvent(pDrv->hCloseEvent);

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void BSA_PowerDown (DWORD dwContext)
{
	ULONG ulWaitResult;
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+BSA_PowerDown\r\n")));

	// Verify that the context handle is valid.
	VerifyContextHandle(pDrv);

	// wait for BSA to finish if running
	// TODO: FIX THIS!
	if(pDrv->hIntrEvent)
		ulWaitResult = WaitForSingleObject(pDrv->hIntrEvent, 50);

	disable_bsa_interrupt(pDrv);
	maebsa_power(pDrv, 0);
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void BSA_PowerUp (DWORD dwContext)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+BSA_PowerUp\r\n")));
	
	// Verify that the context handle is valid.
	VerifyContextHandle(pDrv);

	EnterCS(pDrv->CriticalSection);

	if (pDrv->nNumOpens > 0)
		maebsa_power(pDrv, 1);

	enable_bsa_interrupt(pDrv);

	LeaveCS(pDrv->CriticalSection);
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL WINAPI BSA_DllMain(HINSTANCE hInstDLL, DWORD dwReason, LPVOID pReserved)
{
	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
		DEBUGREGISTER(hInstDLL);
		DisableThreadLibraryCalls(hInstDLL);
		DEBUGMSG(ZONE_INFO, (TEXT("BSA_DllMain: DLL_PROCESS_ATTACH\r\n")));
		break;

	case DLL_PROCESS_DETACH:
		DEBUGMSG(ZONE_INFO, (TEXT("BSA_DllMain: DLL_PROCESS_DETACH\r\n")));
		break;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void ShowVersion(void)
{
	DEBUGMSG (ZONE_ERROR, (DTAG TEXT("Driver, v%d.%d %s.%s\r\n"),kVersion_Main,kVersion_Sub,kVersion_Build,kVersion_BuildSub));
	RETAILMSG(1, (DTAG TEXT("Driver, v%d.%d %s.%s\r\n"), kVersion_Main,kVersion_Sub,kVersion_Build,kVersion_BuildSub));
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
int VerifyContextHandle(PDRVCONTEXT pDrv)
{
	DEBUGCHK(pDrv);
	if (pDrv->dwSize != sizeof (DRVCONTEXT)) 
	{
		DEBUGMSG (ZONE_ERROR, (DTAG TEXT("Invalid driver context!\r\n")));
		return 0;
	}

	return 1;
}

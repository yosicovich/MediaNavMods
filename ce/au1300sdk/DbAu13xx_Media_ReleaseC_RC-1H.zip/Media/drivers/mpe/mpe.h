
#ifndef __mpe_h__
#define __mpe_h__

#ifdef __cplusplus
extern "C" {
#endif

//////////////////////////////////////////////////////////////////////

#define MPE_CFG0    0x0000
#define MPE_CFG1    0x0004
#define MPE_CFG2    0x0008
#define MPE_CFG3    0x000C
#define MPE_CFG4    0x0010
#define MPE_CFG5    0x0014
#define MPE_CFG6    0x0018
#define MPE_CFG7    0x001C
#define MPE_CFG8    0x0020
#define MPE_CFG9    0x0024
#define MPE_CFG10   0x0028
#define MPE_CFG11   0x002C
#define MPE_CFG12   0x0030
#define MPE_CFG13   0x0034
#define MPE_CFG14   0x0038
#define MPE_CFG15   0x003C
#define MPE_CFG16   0x0040
#define MPE_CFG17   0x0044
#define MPE_CFG18   0x0048

#ifndef ASSEMBLER
typedef volatile struct
{
    uint32 cfg0;
    uint32 cfg1;
    uint32 cfg2;
    uint32 cfg3;
    uint32 cfg4;
    uint32 cfg5;
    uint32 cfg6;
    uint32 cfg7;
    uint32 cfg8;
    uint32 cfg9;
    uint32 cfg10;
    uint32 cfg11;
    uint32 cfg12;
    uint32 cfg13;
    uint32 cfg14;
    uint32 cfg15;
    uint32 cfg16;
    uint32 cfg17;
    uint32 cfg18;
    uint32 cfg19;

} mpe_t;

typedef volatile struct
{
    uint32 pri0;
    uint32 pri1;
} mpe_dma_t;
#endif

#define MPE_CFG0_START              (1<<0)

#define MPE_CFG4_MEMORYSTRIDE(X)    ((X)<<0)

#define MPE_CFG5_PICSIZEVERT(X)     ((X)<<9)
#define MPE_CFG5_PICSIZEHORIZ(X)    ((X)<<0)

#define MPE_CFG6_ODDEN              (1<<21)
#define MPE_CFG6_IQADD1             (1<<20)
#define MPE_CFG6_IQMUL1             (1<<19)
#define MPE_CFG6_CHROMAQP(X)        (((X)&0x1F)<<14)
#define MPE_CFG6_PICINITQP(X)       (((X)&0x3F)<<8)
#define MPE_CFG6_PICINITQS(X)       (((X)&0x3F)<<2)
#define MPE_CFG6_MMCEN              (1<<1)
#define MPE_CFG6_SATEN              (1<<0)

#define MPE_CFG7_DYNAMICAPRONEN     (1<<11)
#define MPE_CFG7_APRONMODE_DISABLE  (0<<8)
#define MPE_CFG7_APRONMODE_FRAME    (1<<8)
#define MPE_CFG7_APRONMODE_FIELD    (2<<8)
#define MPE_CFG7_APRONMODE_FIXED    (3<<8)
#define MPE_CFG7_APRONFIXEDVALUE(X) ((X)<<0)

#define MPE_CFG8_VC1MAINPROFILE                 (1<<10)
#define MPE_CFG8_CONINTRAPREDFLAG(X)            (X<<9)
#define MPE_CFG8_PICTURETYPE_PROGRESSIVE_FRAME  (0<<7)
#define MPE_CFG8_PICTURETYPE_INTERLACED_FRAME   (2<<7)
#define MPE_CFG8_PICTURETYPE_INTERLACED_FIELD   (3<<7)
#define MPE_CFG8_CODECTYPE_MPEG1_MPEG2          (0<<3)
#define MPE_CFG8_CODECTYPE_MPEG4                (1<<3)
#define MPE_CFG8_CODECTYPE_VC1_WMV9_SIMPLE_MAIN (2<<3)
#define MPE_CFG8_CODECTYPE_VC1_WMV9_ADVANCED    (3<<3)
#define MPE_CFG8_CODECTYPE_H264_CABAC           (4<<3)
#define MPE_CFG8_CODECTYPE_H264_CAVLC           (5<<3)
#define MPE_CFG8_CODECTYPE_JPEG                 (7<<3)
#define MPE_CFG8_BLOCKCOUNT_420                 (0<<1)
#define MPE_CFG8_BLOCKCOUNT_422                 (1<<1)
#define MPE_CFG8_BLOCKCOUNT_444                 (2<<1)
#define MPE_CFG8_BLOCKCOUNT_411                 (3<<1)
#define MPE_CFG8_QUANTTYPE(X)                   (X<<0)

#define MPE_CFG9_CONDOVER(X)                    ((X)<<17)
#define MPE_CFG9_VC1ICOMPEN                     (1<<16)
#define MPE_CFG9_VC1LUMSCALE(X)                 (((X)&0x3F)<<10)
#define MPE_CFG9_VC1LUMSHIFT(X)                 (((X)&0x3F)<<4)
#define MPE_CFG9_ILFILTEN                       (1<<3)
#define MPE_CFG9_LOOP                           (1<<2)
#define MPE_CFG9_OVERLAP                        (1<<0)

#define MPE_CFG12_SCRATCHPADSIZE(X)             ((X)<<0)

#define MAE2_LUMA_APRON_HEIGHT      48
#define MAE2_LUMA_APRON_WIDTH       24
#define MAE2_CHROMA_APRON_HEIGHT    24
#define MAE2_CHROMA_APRON_WIDTH     24

// Base addresses from the Au1 perspective
#define MPE_PHYS_ADDR   0x14014000

#define SCRATCH_BYTES_PER_MB                    (372*4)

// DMA configuration offsets
#define MPE_DMA_PHYS_ADDR (MPE_PHYS_ADDR | 0x2C0C)

//////////////////////////////////////////////////////////////////////

#ifdef __cplusplus
}
#endif

#endif // __mpe_h__


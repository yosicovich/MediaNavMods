/**********************************************************************
* Copyright 2007 RMI Corp. All Rights Reserved.
*
* Unless otherwise designated in writing, this software and any related
* documentation are the confidential proprietary information of RMI
* Corp.
*
* THESE MATERIALS ARE PROVIDED "AS IS" WITHOUT ANY
* UNLESS OTHERWISE NOTED IN WRITING, EXPRESS OR IMPLIED WARRANTY OF ANY
* KIND, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* NONINFRINGEMENT, TITLE, FITNESS FOR ANY PARTICULAR PURPOSE AND IN NO
* EVENT SHALL RMI COPR. OR ITS LICENSORS BE LIABLE FOR ANY DAMAGES
* WHATSOEVER.
*
* RMI Corp. does not assume any responsibility for any errors which may
* appear in the Materials nor any responsibility to support or update
* the Materials. RMI Corp. retains the right to modify the Materials
* at any time, without notice, and is not obligated to provide such
* modified Materials to you. RMI Corp. is not obligated to furnish,
* support, or make any further information available to you.
***********************************************************************/
//------------------------------------------------------------------------------
// File: mae_mpe.cpp
//------------------------------------------------------------------------------

//////////////////////////////////////////////////////////////////////
//	Add this to your project environment variables to use these drivers:
//	BSP_MEDIA_V20
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <platform.h>
#include <bceddk.h>
#include <dbgapi.h>
#include <au1x00.h>
#include "maeioctl.h"
#include "mpe.h"

#define MPE_THREAD_PRIORITY THREAD_PRIORITY_TIME_CRITICAL

#define	kVersion_Main		      1		// Main version number
#define kVersion_Sub		      2		// Sub version number
#define	kVersion_Build		    TEXT(__DATE__)		// Major Build number
#define	kVersion_BuildSub	    TEXT(__TIME__)		// Minor Build number

typedef struct
{
	DWORD	dwSize;
	CRITICAL_SECTION CriticalSection;
	INT		nNumOpens;
	HANDLE	hDoneEvent;
	HANDLE	hCloseEvent;
	HANDLE	hIntrEvent;
	HANDLE	hIntrThread;
	INT		nIrqlMae;
	mpe_t	*mpe;
	AU13XX_VSSCTRL *vss;
	DWORD	timeoutMilliseconds;
	uint32	endMipsCounter;

	// for multi-segment jpeg decode
	uint32 prev_cfg8;
	HANDLE hIntrStartEvent;
} DRVCONTEXT, *PDRVCONTEXT;

#define EnterCS(x) EnterCriticalSection(&x)
#define LeaveCS(x) LeaveCriticalSection(&x)
int VerifyContextHandle(PDRVCONTEXT pDrv);
void ShowVersion(void);
DWORD InitEventsAndThreads(DWORD dwContext);
ULONG InterruptThread(LPVOID dwContext);

// Maximum decode resolution
DWORD g_dwWidth = 0;
DWORD g_dwHeight = 0;

// Debug zone support
#define DTAG TEXT("MPE: ")
#define ZONE_ERROR  DEBUGZONE(0)
#define ZONE_INIT   DEBUGZONE(1)
#define ZONE_FUNC   DEBUGZONE(2)
#define ZONE_DRVCALLS  DEBUGZONE(3)
#define ZONE_INFO   DEBUGZONE(4)
#define ZONE_INT	DEBUGZONE(5)
#define ZONE_REGISTERS DEBUGZONE(6)
#define ZONE_EXENTRY  (ZONE_FUNC | ZONE_DRVCALLS)

DBGPARAM dpCurSettings =
{
  TEXT("mpe"),
  {
    TEXT("Errors"), TEXT("Init"), TEXT("Functions"),
    TEXT("DriverCalls"), TEXT("Info"), TEXT("INT"),
    TEXT("Registers"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined"),TEXT("Undefined"),TEXT("Undefined"),
    TEXT("Undefined")
  },
  0x0001
};

//////////////////////////////////////////////////////////////////////
static void
maempe_reset (PDRVCONTEXT pDrv, int reset)
{
    AU13XX_VSSCTRL *vss = pDrv->vss;
	volatile uint32 junk;

    if (reset)
    {
        vss->mpe.clkrst = 3;
    }
    else
    {
        vss->mpe.clkrst = 2;
    }

	// Read-back force write to go out, provides more time when cycling reset
    junk = vss->mpe.clkrst;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
static void
maempe_power (PDRVCONTEXT pDrv, int up)
{
	VSSREQ vss_req;

	if (up)
	{
		DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+enable_mpe_power\r\n")));

		maempe_reset(pDrv, 1);

		vss_req.block  = VSS_MPE;
		vss_req.enable = TRUE;

		KernelIoControl(
			IOCTL_HAL_VSS,
			&vss_req,
			sizeof(vss_req),
			NULL,
			0,
			NULL
			);

		maempe_reset(pDrv, 0);
	}
	else
	{
		DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+disable_mpe_power\r\n")));

		vss_req.block  = VSS_MPE;
		vss_req.enable = FALSE;

		KernelIoControl(
			IOCTL_HAL_VSS,
			&vss_req,
			sizeof(vss_req),
			NULL,
			0,
			NULL
			);

		maempe_reset(pDrv, 1);
	}
}

//////////////////////////////////////////////////////////////////////
static void
maempe_transaction (PDRVCONTEXT pDrv, mae_mpe_request_t *tr)
{
    mpe_t *mpe = pDrv->mpe;

	// ensure thread has started
	DWORD dw = WaitForSingleObject(pDrv->hIntrStartEvent, INFINITE);

	if( tr->flags & MAEMPE_FLAGS_DCWB)
	{
		CacheRangeFlush(tr, (16*1024), CACHE_SYNC_WRITEBACK);
	}

// TODO:
// Add microseconds
//    tr->begMipsCounter = read_c0_count();

	// to support multi-segment decode, only reset MPE when codec changes
	if (pDrv->prev_cfg8 != tr->cfg8)
	{
		// Toggle reset before each frame.
		// Especially needed when doing dual-decode with different codecs.
		maempe_reset(pDrv, 1);
		pDrv->prev_cfg8 = tr->cfg8;
	}
    maempe_reset(pDrv, 0);

#define WRREG(REG) { mpe->REG = tr->REG; /*WBSYNC();*/ /*RETAILMSG(1, (TEXT("+MPE %08X %08X\r\n"), mpe->REG, tr->REG));*/ }

    // Write the registers
    WRREG(cfg1);
    WRREG(cfg2);
    WRREG(cfg3);
    WRREG(cfg4);
    WRREG(cfg5);
    WRREG(cfg6);
    WRREG(cfg7);
    WRREG(cfg8);
    WRREG(cfg9);
    WRREG(cfg10);
    WRREG(cfg11);
    WRREG(cfg12);
    WRREG(cfg13);
    WRREG(cfg14);
    WRREG(cfg15);
    WRREG(cfg18);

    mpe->cfg19 = 1; // interrupt mask enable

	{
		DWORD result;
		mpe->cfg0 = MPE_CFG0_START; // start MPE, FIX!!! potential RACE!!
		//RETAILMSG(1,(TEXT("+MPE WaitForSingleObject\r\n")));
		result = WaitForSingleObject(pDrv->hDoneEvent, pDrv->timeoutMilliseconds);
		//RETAILMSG(1,(TEXT("-MPE WaitForSingleObject\r\n")));

		// If an error occured, place MPE in reset to clear out any bad state
		if (result == WAIT_TIMEOUT)
			maempe_reset(pDrv, 1);
	}

// TODO:
// Add microseconds
//    tr->endMipsCounter = maempe_state.endMipsCounter;
}



///////////////////////////////////////////////////////////////////////////////
// MPE_IOControl
//
// This routine handles all IOCTLs for MAE related activities. It will dispatch
// to include library IOCTL handlers.
//
// Parameters :
//		dwContext   		pointer to driver instance structure
//      dwIoControlCode		IOCTL command
//		pInBuf				Pointer to input data from caller
//      nInBufSize			Size of input data
//      pOutBuf				Pointer to output memory in caller's memory space
//		nOutBufSize			Size of memory available for output
//      pBytesReturned		Pointer to DWORD that will contain the number of
//								bytes placed in caller's output buffer
//
// Returns :
//      TRUE				Handled IOCTL successfuly
//      FALSE				Failed to handle IOCTL
//
///////////////////////////////////////////////////////////////////////////////
DWORD MPE_IOControl(DWORD dwContext, DWORD dwIoControlCode, PBYTE pInBuf, DWORD dwInBufSize, PBYTE pOutBuf,
                    DWORD dwOutBufSize, PDWORD pdwBytesReturned)
{
	PDRVCONTEXT		pDrv = (PDRVCONTEXT) dwContext;
	mae_mpe_request_t *tr  = (mae_mpe_request_t *) pInBuf;
	BOOL			RetVal = TRUE;

	DEBUGMSG (ZONE_FUNC, (TEXT("+MPE_IOControl dwContext: 0x08%x  dwCode: 0x08%x\r\n"), dwContext, dwIoControlCode));

	if ( (NULL == tr) || (NULL == pDrv) )
	{
		return FALSE;
	}

	if (tr->magic != MAEMPE_MAGIC)
	{
		RETAILMSG(1, (TEXT("BAD MPE_IOControl %08X\r\n"), tr->magic));
		return FALSE;
	}

	switch (dwIoControlCode)
	{
		case MAEMPE_IOCTL_SUBMIT_TRANSACTION:
			maempe_transaction (pDrv, tr);
			break;

		default :
			RETAILMSG(1, (TEXT("BAD MPE IOCODE %08X\r\n"), dwIoControlCode));
			return FALSE;
			break;
	}

	return TRUE;
}



///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void enable_mpe_interrupt(PDRVCONTEXT pDrv)
{
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void disable_mpe_interrupt(PDRVCONTEXT pDrv)
{
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD MPE_Init (DWORD dwContext)
{
	PHYSICAL_ADDRESS    PhysAddr;
	PDRVCONTEXT pDrv;

	DEBUGMSG(ZONE_INIT | ZONE_EXENTRY,
		(DTAG TEXT("+MPE_Init dwContext:0x%08x\r\n"), dwContext));

	// Allocate a device instance structure from the heap
	pDrv = (PDRVCONTEXT)LocalAlloc(LPTR, sizeof(DRVCONTEXT));
	if (pDrv)
	{
		memset((PBYTE)pDrv, 0, sizeof(DRVCONTEXT));
		pDrv->dwSize = sizeof(DRVCONTEXT);
	} else
	{
		DEBUGMSG(ZONE_INIT | ZONE_ERROR,
		  (DTAG TEXT("MPE_Init failure. Out of memory\r\n")));
		return 0;
	}

	// Map the MPE physical register space
	PhysAddr.HighPart = 0;
	PhysAddr.LowPart  = MPE_PHYS_ADDR;
	pDrv->mpe = (mpe_t *)MmMapIoSpace(PhysAddr, sizeof(mpe_t), FALSE);
	if (NULL == pDrv->mpe) 	{
		DEBUGMSG(ZONE_ERROR, (TEXT("MPE_Init failed to map memory: 0x%08X\r\n"), PhysAddr.LowPart));
		LocalFree(pDrv);
		return 0;
	}

	// Map the VSS physical register space
	PhysAddr.HighPart = 0;
	PhysAddr.LowPart  = VSS_PHYS_ADDR;
	pDrv->vss = (AU13XX_VSSCTRL *)MmMapIoSpace(PhysAddr, sizeof(AU13XX_VSSCTRL), FALSE);
	if (NULL == pDrv->vss) 	{
		DEBUGMSG(ZONE_ERROR, (TEXT("MPE_Init failed to map memory: 0x%08X\r\n"), PhysAddr.LowPart));
		LocalFree(pDrv);
		return 0;
	}

#if 0
	{
	AU1X00_SYS *sys;
	// Map the SYS physical register space
	PhysAddr.HighPart = 0;
	PhysAddr.LowPart  = SYS_PHYS_ADDR;
	sys = (AU1X00_SYS *)MmMapIoSpace(PhysAddr, sizeof(AU1X00_SYS), FALSE);
	RETAILMSG(1, (TEXT("AUXPLL2 %08X FREQCTRL0 %08X FREQCTRL1 %08X CLKSRC %08X\r\n"), sys->auxpll2, sys->freqctrl0, sys->freqctrl1, sys->clksrc));
	}
#endif

	pDrv->timeoutMilliseconds = 300; // INFINITE, or non-zero value (preferrably from registry)

	InitializeCriticalSection(&(pDrv->CriticalSection));

	// save power until we are actively using this hardware
	maempe_power(pDrv, 0);

	// Connect and initialize interrupt
	pDrv->nIrqlMae = InterruptConnect(Internal, 0, ((HWINTR_MPE)), 0);
	InterruptDone(pDrv->nIrqlMae); // clear spurious intrs at init

	ShowVersion();

	return (DWORD)pDrv;
}


///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD  MPE_Deinit (DWORD dwContext)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_EXENTRY,	(DTAG TEXT("+MPE_Deinit dwContext:0x%08x\r\n"), dwContext));

	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	// Cleanup everything we did in init
	InterruptDisconnect(pDrv->nIrqlMae);
	DeleteCriticalSection(&(pDrv->CriticalSection));
	MmUnmapIoSpace((PVOID)pDrv->mpe, sizeof(mpe_t));
	LocalFree(pDrv);

	maempe_power(pDrv, 0);

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("-MPE_Deinit\r\n")));

	return (DWORD)pDrv;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD MPE_Open(DWORD dwContext, DWORD dwAccess, DWORD dwShare)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_EXENTRY,
	(DTAG TEXT("+MPE_Open dwContext:0x%08x\r\n"), dwContext));
	//RETAILMSG(1, (TEXT("+MPE_Open dwContext:0x%08x\r\n"), dwContext));

	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	EnterCS(pDrv->CriticalSection);
	if (pDrv->nNumOpens == 0)
	{
		maempe_power(pDrv, 1);
		(DWORD)pDrv = InitEventsAndThreads(dwContext);
		enable_mpe_interrupt(pDrv);
	}

	// Count the number of open instances
	InterlockedIncrement ((long *)&pDrv->nNumOpens);
	LeaveCS(pDrv->CriticalSection);

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("-MPE_Open: pDrv->nNumOpens %d\r\n"),pDrv->nNumOpens));

	return (DWORD)pDrv;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL  MPE_Close (DWORD dwContext, DWORD dwOpen)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_EXENTRY,
		(DTAG TEXT("+MPE_Close dwOpen: 0x%08x\r\n"), dwOpen));

	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	EnterCS(pDrv->CriticalSection);
	if (pDrv->nNumOpens)
		InterlockedDecrement((long *)&pDrv->nNumOpens);

	if (pDrv->nNumOpens == 0)
	{
		disable_mpe_interrupt(pDrv);
		// Un-register the interrupts with OS
		InterruptDisable(pDrv->nIrqlMae);
		maempe_power(pDrv, 0);

		// Wait for the interrupt handler to close
		WaitForSingleObject(pDrv->hCloseEvent, 100);

		// Close all handles
		CloseHandle(pDrv->hIntrEvent);
		CloseHandle(pDrv->hIntrThread);
		CloseHandle(pDrv->hDoneEvent);
		CloseHandle(pDrv->hCloseEvent);
		CloseHandle(pDrv->hIntrStartEvent);
	}
	LeaveCS(pDrv->CriticalSection);

	DEBUGMSG (ZONE_FUNC,
		(DTAG TEXT("-MPE_Close: pDrv->nNumOpens %d\r\n"),pDrv->nNumOpens));\

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
DWORD InitEventsAndThreads(DWORD dwContext)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+InitEventsAndThreads\r\n")));

	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	if ((pDrv->hDoneEvent = CreateEvent(NULL, FALSE, FALSE, NULL) )== NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateEvent failed for hDoneEvent\r\n")));
		return 1;
	}

	if ((pDrv->hCloseEvent = CreateEvent(NULL, FALSE, FALSE, NULL) )== NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateEvent failed for hCloseEvent\r\n")));
		return 1;
	}

	if ((pDrv->hIntrEvent = CreateEvent(NULL, FALSE, FALSE, NULL) )== NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateEvent failed for hIntrEvent\r\n")));
		return 1;
	}

	if ((pDrv->hIntrStartEvent = CreateEvent(NULL, TRUE, FALSE, NULL) )== NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateEvent failed for hIntrStartEvent\r\n")));
		return 1;
	}
	ResetEvent(pDrv->hIntrStartEvent);

	pDrv->hIntrThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)InterruptThread,
									  (LPVOID)(dwContext), 0, NULL);

	if (pDrv->hIntrThread == NULL)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("CreateThread failed\r\n")));
		return 1;
	}
	if(FALSE == CeSetThreadPriority(pDrv->hIntrThread, MPE_THREAD_PRIORITY))
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("SetThreadPriority failed\r\n")));
	}

	return (DWORD)pDrv;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
inline BOOL DriverIsOpen(LPVOID dwContext)
{
	BOOL bIsOpen = FALSE;

	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	EnterCS(pDrv->CriticalSection);
	if (pDrv->nNumOpens > 0)
	{	
		bIsOpen = TRUE;
	}
	LeaveCS(pDrv->CriticalSection);

	return bIsOpen;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
ULONG InterruptThread(LPVOID dwContext)
{
	ULONG ulWaitResult = 0;
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;
	BOOL bFirst = TRUE;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+InterruptThread\r\n")));

	// Verify that the context handle is valid.
	if (!VerifyContextHandle(pDrv))
	{
		return 0;
	}

	CeSetThreadPriority(GetCurrentThread(),MPE_THREAD_PRIORITY);

	if (InterruptInitialize(pDrv->nIrqlMae, pDrv->hIntrEvent, NULL, 0) != TRUE)
	{
		DEBUGMSG(ZONE_ERROR, (DTAG TEXT("InterruptInitialize failed\r\n")));
		return 1;
	}

	while (DriverIsOpen(dwContext)) // loop till driver close is called or an error happens
	{
		InterruptDone(pDrv->nIrqlMae);
		if (bFirst)
		{
			SetEvent(pDrv->hIntrStartEvent);
		}

		//RETAILMSG(1, (TEXT("+MPE WaitForSingleObject\r\n")));
		ulWaitResult = WaitForSingleObject(pDrv->hIntrEvent, INFINITE);
		//RETAILMSG(1, (TEXT("-MPE WaitForSingleObject\r\n")));

		EnterCS(pDrv->CriticalSection);
// TODO:
// Add microseconds
//		pDrv->endMipsCounter = read_c0_count();
		SetEvent(pDrv->hDoneEvent);
		LeaveCS(pDrv->CriticalSection);

	}

	SetEvent(pDrv->hCloseEvent);

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void MPE_PowerDown (DWORD dwContext)
{
	ULONG ulWaitResult;
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;

	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+MPE_PowerDown\r\n")));

	// Verify that the context handle is valid.
	VerifyContextHandle(pDrv);

	// wait for MPE to finish if running
	// TODO: FIX THIS!
	if(pDrv->hIntrEvent)
		ulWaitResult = WaitForSingleObject(pDrv->hIntrEvent, 50);

	disable_mpe_interrupt(pDrv);
	maempe_power(pDrv, 0);
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void MPE_PowerUp (DWORD dwContext)
{
	PDRVCONTEXT pDrv = (PDRVCONTEXT) dwContext;
	DEBUGMSG (ZONE_FUNC, (DTAG TEXT("+MPE_PowerUp\r\n")));

	// Verify that the context handle is valid.
	VerifyContextHandle(pDrv);

	EnterCS(pDrv->CriticalSection);

	if (pDrv->nNumOpens > 0)
		maempe_power(pDrv, 1);

	enable_mpe_interrupt(pDrv);

	LeaveCS(pDrv->CriticalSection);
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
BOOL WINAPI MPE_DllMain(HINSTANCE hInstDLL, DWORD dwReason, LPVOID pReserved)
{
	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
		DEBUGREGISTER(hInstDLL);
		DisableThreadLibraryCalls(hInstDLL);
		DEBUGMSG(ZONE_INFO, (TEXT("MPE_DllMain: DLL_PROCESS_ATTACH\r\n")));
		break;

	case DLL_PROCESS_DETACH:
		DEBUGMSG(ZONE_INFO, (TEXT("MPE_DllMain: DLL_PROCESS_DETACH\r\n")));
		break;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
void ShowVersion(void)
{
	DEBUGMSG (ZONE_ERROR, (DTAG TEXT("Driver, v%d.%d %s.%s\r\n"),kVersion_Main,kVersion_Sub,kVersion_Build,kVersion_BuildSub));
	RETAILMSG(1, (DTAG TEXT("Driver, v%d.%d %s.%s\r\n"), kVersion_Main,kVersion_Sub,kVersion_Build,kVersion_BuildSub));
	//RETAILMSG(1, (TEXT("MAE_MPE: Maximum Decode Resolution (%d x %d)\r\n"), g_dwWidth, g_dwHeight));
}

///////////////////////////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////////////////////////
int VerifyContextHandle(PDRVCONTEXT pDrv)
{
	DEBUGCHK(pDrv);
	if (pDrv->dwSize != sizeof (DRVCONTEXT))
	{
		DEBUGMSG (ZONE_ERROR, (DTAG TEXT("Invalid driver context!\r\n")));
		return 0;
	}

	return 1;
}

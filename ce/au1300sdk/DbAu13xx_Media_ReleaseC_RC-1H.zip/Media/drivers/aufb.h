/*****************************************************************************
 * Copyright 2003-2008 RMI Corporation. All rights reserved.
 *
 * Any transfer or redistribution of the source code, with or without modification,
 * IS PROHIBITED, unless prior written consent was obtained. Any transfer or
 * redistribution of the binary code for use on the RMI Alchemy Family ,
 * with or without modification, is permitted, provided that the following
 * condition is met:
 *
 * Redistributions in binary form must reproduce the above copyright notice,
 *
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution:
 *
 * THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/*   AU FB ioctl structures */

#ifndef __AUFB_H_
#define __AUFB_H_

#include <stdint.h>

struct au1200_lcd_window_regs_t {
        unsigned int flags;
        unsigned int xpos;
        unsigned int ypos;
        unsigned int alpha_color;
        unsigned int alpha_mode;
        unsigned int priority;
        unsigned int channel;
        unsigned int buffer_format;
        unsigned int color_order;
        unsigned int pixel_order;
        unsigned int xsize;
        unsigned int ysize;
        unsigned int colorkey_mode;
        unsigned int double_buffer_mode;
        unsigned int ram_array_mode;
        unsigned int xscale;
        unsigned int yscale;
        unsigned int enable;
};


struct au1200_lcd_global_regs_t {
        unsigned int flags;
        unsigned int xsize;
        unsigned int ysize;
        unsigned int backcolor;
        unsigned int brightness;
        unsigned int colorkey;
        unsigned int mask;
        unsigned int panel_choice;
        char panel_desc[80];

};

struct au1200_lcd_iodata_t {
        unsigned int subcmd;
        struct au1200_lcd_global_regs_t global;
        struct au1200_lcd_window_regs_t window;
};

struct au1200_alt_buffer {
	unsigned char*		mem;
	unsigned int		len;
	unsigned long long	phys;
};

struct au1200_lcd_buf_update {
	unsigned long 	addr;
	/*
	 * Set to true to block until the next V Sync
	 */
	/*bool		wait_vsync;*/
	uint8_t		wait_vsync;
};

#define AU1200_LCD_BUF_IOCTL 	0x4701

#define AU1250_IOCTL_CMD	0x46FF

#define AU1200_LCD_SET_SCREEN 1
#define AU1200_LCD_GET_SCREEN 2
#define AU1200_LCD_SET_WINDOW 3
#define AU1200_LCD_GET_WINDOW 4
#define AU1200_LCD_SET_PANEL  5
#define AU1200_LCD_GET_PANEL  6


/* window operation  flags*/
#define WIN_POSITION            (1<< 0)
#define WIN_ALPHA_COLOR         (1<< 1)
#define WIN_ALPHA_MODE          (1<< 2)
#define WIN_PRIORITY            (1<< 3)
#define WIN_CHANNEL             (1<< 4)
#define WIN_BUFFER_FORMAT       (1<< 5)
#define WIN_COLOR_ORDER         (1<< 6)
#define WIN_PIXEL_ORDER         (1<< 7)
#define WIN_SIZE                (1<< 8)
#define WIN_COLORKEY_MODE       (1<< 9)
#define WIN_DOUBLE_BUFFER_MODE  (1<< 10)
#define WIN_RAM_ARRAY_MODE      (1<< 11)
#define WIN_BUFFER_SCALE        (1<< 12)
#define WIN_ENABLE                  (1<< 13)

#define SCREEN_SIZE		    (1<< 1)
#define SCREEN_BACKCOLOR    (1<< 2)
#define SCREEN_BRIGHTNESS   (1<< 3)
#define SCREEN_COLORKEY     (1<< 4)
#define SCREEN_MASK         (1<< 5)

/*
static inline void dump_fixinfo(struct fb_fix_screeninfo *finfo)
{
    printf("*** Fix info ***\n");
    printf("id %s \n",finfo->id);
    printf("type %u \n",finfo->type);
}


static inline void dump_varinfo(struct fb_var_screeninfo *vinfo)
{
    printf("*** Var info ***\n");
    printf("xres %u \n",vinfo->xres);
    printf("yres %u \n",vinfo->yres);
    printf("xres virtual %u \n",vinfo->xres_virtual);
    printf("xres %u \n",vinfo->yres_virtual);
    printf("xoffset %u \n",vinfo->xoffset);
    printf("yoffset %u \n",vinfo->yoffset);
    printf("bits_per_pixel %u \n",vinfo->bits_per_pixel);
    printf("nonstd %u \n",vinfo->nonstd);
    printf("activate %u \n",vinfo->activate);
}

static inline void dump_wininfo(struct au1200_lcd_window_regs_t *win)
{
    printf("*** win info ***\n");
    printf("xpos %u \n",win->xpos);
    printf("ypos %u \n",win->ypos);
    printf("alpha_color %u \n",win->alpha_color);
    printf("alpha_mode %u \n",win->alpha_mode);
    printf("priority %u \n",win->priority);
    printf("buffer_format %u \n",win->buffer_format);
    printf("pixel_order %u \n",win->pixel_order);
    printf("xsize %u \n",win->xsize);
    printf("ysize %u \n",win->ysize);
    printf("enable %u \n",win->enable);
}
*/

#endif // __AUFB_H_

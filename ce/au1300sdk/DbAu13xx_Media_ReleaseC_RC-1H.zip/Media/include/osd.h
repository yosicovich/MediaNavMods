#ifndef __OSD_H__
#define __OSD_H__

struct VideoSample;
void osd_apply(struct VideoSample *rgb_sample);

#endif

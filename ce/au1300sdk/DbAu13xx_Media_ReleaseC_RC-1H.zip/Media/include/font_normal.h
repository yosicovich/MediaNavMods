#ifndef __FONT_NORMAL__
#define __FONT_NORMAL__

#include "bitmap_font.h"

extern BitmapFont FONT_NORMAL;

#endif


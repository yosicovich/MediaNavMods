/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef TEST_H
#define TEST_H

typedef int (*TEST_ENTRYPOINT)();

#define TEST_ENTRY(entry) \
static const TEST_ENTRYPOINT __test_entry_point __attribute__((section(".text.testentry"))) = entry; \
static int __test_result __attribute__((section(".text.testresult"))) = 0

#define TEST_DESCRIPTION(desc)        \
static const char* __test_description __attribute__((section(".text.testdesc"))) = desc


#define TEST_DIVIDER  printf("----------------------------------------------------------------\n")
#define TESTCASE_DIVIDER printf("-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -\n")
#define TEST_MAIN_DIVIDER printf("================================================================\n")

#define TEST_PASSED 1
#define TEST_FAILED 0

#define TEST_PASSED_STRING  "\e[32m PASSED\e[0m"
#define TEST_FAILED_STRING  "\e[31m FAILED\e[0m"
#define TEST_DISABLED_STRING  "\e[33mDISABLED\e[0m"

#define PRINT_TEST_RESULT(enabled, description, status) printf("%50s...\t%s\n", description, ((enabled) == TRUE ? ((status) == TEST_PASSED ? TEST_PASSED_STRING : TEST_FAILED_STRING) : TEST_DISABLED_STRING))

#define PRINT_ERROR_COUNT(errors) printf("%s%d error%s\e[0m\n", errors ? "\e[31m" : "", errors, ((errors) == 1 ? "" : "s"))

static
const
int TEST_RESPONSE()
{
    char ans;
    printf(" (y or n) ");
    ans = getc();
    if (ans != '\n')
        printf("\n");
    return (ans == 'y' || ans == 'Y');
}

#endif //TEST_H

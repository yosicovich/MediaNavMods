/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifdef USE_COLOR
#define COLORIZE(c)  printf(c)

#define COLOR_NONE  "\e[0m"
#define COLOR_BOLD  "\e[1m"
#define COLOR_UNDERLINE "\e[4m"
#define COLOR_BLINK  "\e[5m"
#define COLOR_REVERSE  "\e[7m"
#define COLOR_INVISIBLE "\e[8m"

#define FGCOLOR_BLACK  "\e[30m"
#define FGCOLOR_RED  "\e[31m"
#define FGCOLOR_GREEN  "\e[32m"
#define FGCOLOR_YELLOW "\e[33m"
#define FGCOLOR_BLUE  "\e[34m"
#define FGCOLOR_MAGENTA "\e[35m"
#define FGCOLOR_CYAN  "\e[36m"
#define FGCOLOR_WHITE  "\e[37m"

#define BGCOLOR_BLACK  "\e[40m"
#define BGCOLOR_RED  "\e[41m"
#define BGCOLOR_GREEN  "\e[42m"
#define BGCOLOR_YELLOW "\e[43m"
#define BGCOLOR_BLUE  "\e[44m"
#define BGCOLOR_MAGENTA "\e[45m"
#define BGCOLOR_CYAN  "\e[46m"
#define BGCOLOR_WHITE  "\e[47m"

#else
#define COLORIZE(c)

#define COLOR_NONE
#define COLOR_BOLD
#define COLOR_UNDERLINE
#define COLOR_BLINK
#define COLOR_REVERSE
#define COLOR_INVISIBLE

#define FGCOLOR_BLACK
#define FGCOLOR_RED
#define FGCOLOR_GREEN
#define FGCOLOR_YELLOW
#define FGCOLOR_BLUE
#define FGCOLOR_MAGENTA
#define FGCOLOR_CYAN
#define FGCOLOR_WHITE

#define BGCOLOR_BLACK
#define BGCOLOR_RED
#define BGCOLOR_GREEN
#define BGCOLOR_YELLOW
#define BGCOLOR_BLUE
#define BGCOLOR_MAGENTA
#define BGCOLOR_CYAN
#define BGCOLOR_WHITE
#endif


/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef __DDMA_API_H_
#define __DDMA_API_H_

typedef void (*DDMA_CALLBACK)( void *channel, DDMA_DESCRIPTOR *head, int completed, void *arg );

#define VIRT_TO_NXTPTR(x)    (uint32)((KUSEG(x))>>5)
// get the cacheabilty bits from the ring buffer OR in the shifted nxt_ptr
#define NXTPTR_TO_VIRT(ring,pDesc)  (DDMA_DESCRIPTOR*)( ((uint32)ring & KSEG_MSK) | ((uint32)(pDesc->u.std.nxt_ptr<<5)) )
#define SRCPTR_TO_VIRT(ring,pDesc)  (DDMA_DESCRIPTOR*)( ((uint32)ring & KSEG_MSK) | ((uint32)(pDesc->u.std.source0)) )
#define DSTPTR_TO_VIRT(ring,pDesc)  (DDMA_DESCRIPTOR*)( ((uint32)ring & KSEG_MSK) | ((uint32)(pDesc->u.std.dest0)) )

/*
 * This structure allows the "driver" to keep track of local information.
 * It is not the actual CHANNEL structure, but it does contain a pointer
 *  to the Au1x's DDMA channel it points to.
 */
typedef struct
{
    DDMA_CHANNEL  *ptr;                 // Pointer to physical channel
    int    avail;                       // Available?
    int    src_id,dst_id;               // What peripheral is this connected to
    uint32 fifo_addr;                   // Addressof the device's fifo -- specific to dev_id
    int    xfer_size;                   // Transfer size for dma requests
    DDMA_DESCRIPTOR *ring,*dh,*dt;      // Descriptor ring/head/tail ptrs
    DDMA_CALLBACK callback;             // User's Callback routine
    void   *arg;                        // User's callback argument
} CHANNEL;

typedef struct
{
    DDMA_CALLBACK callback;
    void   *arg;

    uint32   channel;           // Requested channel
    void   *descriptors;        // Pointer to pre-allocated descriptors
    uint32   num_descriptors;   // Number of descriptors that were allocated

    uint32   chan_cfg;          // Channel configuration
    uint32   chan_irq;          // Channel interrupt requests
    uint32   chan_stat;         // Channel status register -- Physical address

} CHANNEL_CONFIG;

int   ddma_init( uint32 config );
void *  ddma_get_channel( CHANNEL_CONFIG *config );
int   ddma_free_channel( void *channel );
void ddma_init_descriptors( DDMA_DESCRIPTOR *list, uint32 count );
DDMA_DESCRIPTOR * ddma_next_descriptor( void *c );
int ddma_lit_wr( void *channel, void *dst, uint32 size );
int ddma_tx( void *channel, void *src, void *dst, uint32 size );
int ddma_rx( void *channel, void *dst, uint32 size );
void ddma_dump_regs( void);

#endif // #define __DDMA_API_H_

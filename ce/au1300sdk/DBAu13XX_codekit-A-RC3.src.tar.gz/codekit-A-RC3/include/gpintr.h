/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef __GPINTR_H_
#define __GPINTR_H_

#ifdef AU13XX

/************************************************************************
							Macros/Defines
************************************************************************/
#define GPIO_INPUT			GPINT_PINCTL_GPIOINPUT
#define GPIO_LOW			GPINT_PINCTL_GPIOOUT_0
#define GPIO_HIGH			GPINT_PINCTL_GPIOOUT_1
#define GPIO_IS_DEVICE		GPINT_PINCTL_DEVICE
#define CPU_INT0			GPINT_INTLINE_CPUINT_0
#define CPU_INT1			GPINT_INTLINE_CPUINT_1
#define CPU_INT2			GPINT_INTLINE_CPUINT_2
#define CPU_INT3			GPINT_INTLINE_CPUINT_3
#define WAKE_ENABLE			GPINT_INTWAKE_ENABLE
#define IRQ_DISABLED   		GPINT_INTCFG_DISABLE

// default is low priority
#define irqLL				GPINT_INTCFG_LL | GPINT_INTWAKE_ENABLE
#define irqHL				GPINT_INTCFG_HL | GPINT_INTWAKE_ENABLE
#define irqFE				GPINT_INTCFG_FE | GPINT_INTWAKE_ENABLE
#define irqRE				GPINT_INTCFG_RE | GPINT_INTWAKE_ENABLE

#define irqRE_NOWAKE		GPINT_INTCFG_RE

#define irqNA				0

#if defined(SOC_AU13XX)
#define IRQ_UART1		17
#define IRQ_UART2		25
#define IRQ_UART3		27
#define IRQ_SD1			32
#define IRQ_SD2			38
#define IRQ_PSC0	    48
#define IRQ_PSC1		52
#define IRQ_PSC2		56
#define IRQ_PSC3		60
#define IRQ_NAND		62
#define IRQ_DDMA		75
#define IRQ_MMU			76
#define IRQ_MGP			77
#define IRQ_GPU			78
#define IRQ_UDMA		79
#define IRQ_TOYTICK     80
#define IRQ_TOYMATCH0   81
#define IRQ_TOYMATCH1   82
#define IRQ_TOYMATCH2   83
#define IRQ_RTCTICK     84
#define IRQ_RTCMATCH0   85
#define IRQ_RTCMATCH1   86
#define IRQ_RTCMATCH2   87
#define IRQ_UART0		88
#define IRQ_SD0			89
#define IRQ_USB			90
#define IRQ_LCD			91
#define IRQ_SCF			92
#define IRQ_MPE			93
#define IRQ_BSA			94
#define IRQ_AES			95
#define IRQ_CIM			96
#else  // not Au13xx
#define IRQ_UART0		0
#define IRQ_SWC			1
#define IRQ_SD			2
#define IRQ_DDMA		3
#define IRQ_MAEBE		4
#define IRQ_GPIO200		5
#define IRQ_GPIO201		6
#define IRQ_GPIO202		7
#define IRQ_UART1		8
#define IRQ_MAEFE		9
#define IRQ_PSC0		10
#define IRQ_PSC1		11
#define IRQ_AES			12
#define IRQ_CIM			13
#define IRQ_TOYTICK     14
#define IRQ_TOYMATCH0   15
#define IRQ_TOYMATCH1   16
#define IRQ_TOYMATCH2   17
#define IRQ_RTCTICK     18
#define IRQ_RTCMATCH0   19
#define IRQ_RTCMATCH1   20
#define IRQ_RTCMATCH2   21
#define IRQ_GPIO203		22
#define IRQ_NAND		23
#define IRQ_GPIO204		24
#define IRQ_GPIO205		25
#define IRQ_GPIO206		26
#define IRQ_GPIO207		27
#define IRQ_GPIO208215	28
#define IRQ_USB			29
#define IRQ_USBHOST		29
#define IRQ_LCD			30
#define IRQ_MAEDONE		31
#endif

/* GPIOs are Platform Specific -- start other interupts after GPINT count */
#define IRQ_SWI0		GPINT_MAX_INTS
#define IRQ_SWI1		IRQ_SWI0 + 1
#define IRQ_PERFCNT		IRQ_SWI1 + 1
#define IRQ_COUNTER		IRQ_PERFCNT + 1

#define NUM_IRQS		IRQ_COUNTER + 1


/*
 * Prototypes for interrupt handling infrastructure
 */
BOOL
cpuIrqConfigure( int irq, int mode );

int
cpuIrqQuery( int irq );


void
cpuIrqInit (void);

int
cpuIrqEnable (int irq, int polarity, void (*handler)(int, void *), void *arg);

void
cpuIrqDisable (int irq);

void
cpuIrqDisable (int irq);

uint32
cpuDisableIrqs (void);

void
cpuEnableIrqs (uint32 status);

#endif // AU13XX
#endif // __GPINTR_H_

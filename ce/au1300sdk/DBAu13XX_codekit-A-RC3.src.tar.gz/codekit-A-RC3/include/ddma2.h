/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef DDMA2_H
#define DDMA2_H
#include "example.h"

#define CPHYSADDR(x)    (unsigned long)((~0xA0000000) & ((unsigned long)x))
#define VIRTUAL_TO_NXTPTR(x)   (unsigned long)((CPHYSADDR(x))>>5)
#define NXTPTR_TO_PHYS(x)   (unsigned long)(x<<5)

#define CHANNEL_INVALID -1
typedef int CHANNEL_ID;
typedef void (*DDMA2_CALLBACK)( CHANNEL_ID id, unsigned int arg );

// Function Prototypes
CHANNEL_ID ddma2_request_channel(DDMA2_CALLBACK callback, unsigned int callback_arg);
int ddma2_insert_descriptor(CHANNEL_ID id, DDMA_DESCRIPTOR* ddma_desc);
void ddma2_enable_descriptor_interrupt(DDMA_DESCRIPTOR* desc);
void ddma2_enable_channel(CHANNEL_ID id);
int ddma2_free_channel(CHANNEL_ID id);


#endif //DDMA2_H

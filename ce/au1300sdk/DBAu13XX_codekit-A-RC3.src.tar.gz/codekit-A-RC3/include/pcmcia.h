/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef PCMCIA_H
#define PCMCIA_H

/*
 * Function Control Registers located in Atribute Memory (Release 5.0)
 */
#define FCR_COR  0 /* Configuration Option Register */
#define FCR_FCSR 2 /* Function Configuration and Status Register */
#define FCR_PRR  4 /* Pin Replacement Register */
#define FCR_SCR  6 /* Socket and Copy Register */
#define FCR_ESR  8 /* Extended Status Register */
#define FCR_IOBR0 10 /* I/O Base Register 0 */
#define FCR_IOBR1 12 /* I/O Base Register 1 */
#define FCR_IOBR2 14 /* I/O Base Register 2 */
#define FCR_IOBR3 16 /* I/O Base Register 3 */
#define FCR_IOSR 18 /* I/O Size Register */


/*
 * Configuration Option Register (COR)
 */
#define FCR_COR_CFGIDX 0x3F /* config index */
#define FCR_COR_LEVLREQ 0x40 /* 1=level irqs */
#define FCR_COR_SRESET 0x80 /* 1=reset */

/*
 * Function Configuration and Status Register (FCSR)
 */
#define FCR_FCSR_INTRACK 0x01
#define FCR_FCSR_INTR  0x02
#define FCR_FCSR_PWRDWN  0x04
#define FCR_FCSR_AUDIO  0x08
#define FCR_FCSR_IOIS8  0x20
#define FCR_FCSR_SIGCHG  0x40
#define FCR_FCSR_CHANGED 0x80

/*
 * Pin Replacement Register (PRR)
 */
#define FCR_PRR_RWPROT  0x01
#define FCR_PRR_READY  0x02
#define FCR_PRR_RBVD2  0x04
#define FCR_PRR_RBVD1  0x08
#define FCR_PRR_CWPROT  0x10
#define FCR_PRR_CREADY  0x20
#define FCR_PRR_CBVD2  0x40
#define FCR_PRR_CBVD1  0x80

/*
 * Socket and Copy Register (SCR)
 */
#define FCR_SCR_SOCKET  0x0F
#define FCR_SCR_COPY  0x70

/*
 * Extended Status Register (ESR)
 */
#define FCR_ESR_REQATTNENAB 0x01
#define FCR_ESR_REQATTN  0x10


/*
 * Tuple codes
 */
#define CISTPL_NULL  0x00
#define CISTPL_DEVICE 0x01
#define CISTPL_VERS_1 0x15
#define CISTPL_JEDEC_C 0x18
#define CISTPL_JEDEC_A 0x19
#define CISTPL_MANFID 0x20
#define CISTPL_FUNCID 0x21
#define CISTPL_CONFIG 0x1A
#define CISTPL_CFTABLE_ENTRY 0x1B
#define CISTPL_DEVICE_OC 0x1C
#define CISTPL_DEVICE_OA 0x1D

#define CISTPL_FUNCID_MULTIFUNC  0x00
#define CISTPL_FUNCID_MEMORY  0x01
#define CISTPL_FUNCID_SERIAL  0x02
#define CISTPL_FUNCID_PARALLEL  0x03
#define CISTPL_FUNCID_FIXEDISK  0x04
#define CISTPL_FUNCID_VIDEO   0x05
#define CISTPL_FUNCID_LAN   0x06
#define CISTPL_FUNCID_AIMS   0x07
#define CISTPL_FUNCID_SCSI   0x08
#define CISTPL_FUNCID_CARDBUS  0x09
#define CISTPL_FUNCID_SECURITY  0x09
#define CISTPL_FUNCID_INSTRUMENT 0x0A
#define CISTPL_FUNCID_SERIALIO  0x0B
#define CISTPL_FUNCID_VENDOR  0xFE

#define PCMCIA_WINDOW_ATTR   0
#define PCMCIA_WINDOW_IO   1
#define PCMCIA_WINDOW_MEM   2

#define SECTOR_SIZE   512

int pcmciaOpen(int slot);
int pcmciaRead(int sect, int n, void *buf);
int pcmciaEject();
void * pcmciaMapWindow (int socket, int window, int size);


#endif


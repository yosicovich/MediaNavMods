/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#if !defined(ATA_H)
#define ATA_H

/*
 * ATA registers interface
 */
typedef enum
{
    CMD_RESET=0,
    CMD_IDENTIFY_DEVICE,
    CMD_MEDIA_STATUS,
    CMD_DUMP_ATA_REGS,
    CMD_READ,
    CMD_WRITE,
    CMD_VERIFY,
    CMD_DMA_TEST,
    CMD_READ_ONLY,
    CMD_WRITE_ONLY,
    CMD_DEBUG_IDENT,
    CMD_DEBUG
} cmd;

typedef enum
{
    ATA_REG_DATA=0,
    ATA_REG_ERROR=1,
    ATA_REG_FEATURES=1,  /* write */
    ATA_REG_SECTOR_COUNT=2,
    ATA_REG_SECTOR_NUMBER=3,
    ATA_REG_CYLINDER_LOW=4,
    ATA_REG_CYLINDER_HIGH=5,
    ATA_REG_DEVICE=6,
    ATA_REG_HEAD=6,
    ATA_REG_DEVICE_HEAD=6,
    ATA_REG_STATUS=7,
    ATA_REG_COMMAND=7,   /* write */
    ATA_REG_ALL=255
} ata_regs;

typedef enum
{
    /* Non-data Command */
    ATA_CMD_ND_ID=0xec,
    ATA_CMD_ND_ERROR=1,
    ATA_CMD_ND_FEATURES=1,  /* write */
    ATA_CMD_ND_SECTOR_COUNT=2,
    ATA_CMD_ND_SECTOR_NUMBER=3,
    ATA_CMD_ND_CYLINDER_LOW=4,
    ATA_CMD_ND_CYLINDER_HIGH=5,
    ATA_CMD_ND_DEVICE=6,
    /* PIO data-in Command */
    ATA_CMD_PI_HEAD=6,
    ATA_CMD_PI_HEA=6,
    ATA_CMD_PI_DEVICE_HEAD=6,
    /* PIO data-out Command */
    ATA_CMD_PO_HEAD=6,
    ATA_CMD_PO_HEA=6,
    ATA_CMD_PO_DEVICE_HEAD=6,
    /* DMA Command */
    ATA_CMD_DM_HEAD=6,
    ATA_CMD_DM_HEA=6,
    ATA_CMD_DM_DEVICE_HEAD=6,
    ATA_CMD_STATUS=7,
    ATA_CMD_COMMAND=7,   /* write */
    ATA_CMD_ALL=255
} ata_cmd;

#define ATA_STATUS_BSY  0x80
#define ATA_STATUS_ERR  0x01
#define ATA_STATUS_DWF  0x20
#define ATA_STATUS_DRQ  0x08

/*
 * Set features command
 */
/* Non-data Command */
#define SUB_CMD_ENABLE_8BIT_PIO     (0x01)
#define SUB_CMD_ENABLE_WRITE_CACHE     (0x02)
#define SUB_CMD_SET_TRANSFER_MODE     (0x03)
#define SUB_CMD_ENABLE_ADVANCED_OPWER_MANAGEMENT  (0x05)
#define SUB_CMD_ENABLE_POWERUP_STANDBY    (0x06)
#define SUB_CMD_POWERUP_IN_STANDBY     (0x07)
#define SUB_CMD_ENABLE_CFA_POWER_MODE    (0x0a)
#define SUB_CMD_DISABLE_MEDIA_STATUS_NOTIFICATION  (0x31)
#define SUB_CMD_DISABLE_READ_LOOKAHEAD    (0x55)
#define SUB_CMD_ENABLE_READ_LOOKAHEAD    (0xaa)

#define SET_FEATURES_AFTER_ID_FAILED    (0x37c8)
#define SET_FEATURES_AFTER_ID_OKED     (0x738c)
#define NO_SET_FEATURES_AFTER_ID_FAILED    (0x8c73)
#define NO_SET_FEATURES_AFTER_ID_OKED    (0xc837)

#endif // ATA_H

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef WINDOW_H
#define WINDOW_H

#define WINDOW_COUNT 4
#define WINDOW_INVALID 0xF

#include "frame_buffer.h"

typedef enum
{
    PRIORITY_LOW,
    PRIORITY_MEDIUM,
    PRIORITY_HIGH,
    PRIORITY_HIGHEST
} PRIORITY;

typedef enum
{
    PIPE_LEFT,
    PIPE_RIGHT
} PIPE;

typedef enum
{
    CCO_RGB,
    CCO_BGR
} CCO;

typedef enum
{
    CKMODE_DISABLE,
    CKMODE_MATCH_PIPE,
    CKMODE_VIDEOMAN,
    CKMODE_WEATHERMAN
} CKMODE;

typedef enum
{
    DBMODE_STATIC,
    DBMODE_RETRACE
} DBMODE;

typedef enum
{
    RAM_NONE,
    PALETTE_LOOKUP,
    GAMMA_LOOKUP,
    ONCHIP_FB
} RAM_ARRAY_USAGE;

typedef enum
{
    SCALE_NONE,
    SCALE_2X,
    SCALE_4X
} SCALE;

typedef enum
{
    BUFFER_0,
    BUFFER_1,
    BUFFER_ON_CHIP
} BUFFER_ID;

typedef enum
{
    WINDOW_0,
    WINDOW_1,
    WINDOW_2,
    WINDOW_3
} WINDOW_ID;

typedef struct
{
    uint32 ctrl0;
    uint32 ctrl1;
    uint32 ctrl2;
    uint32 buf0;
    uint32 buf1;
    uint32 bufctrl;
}
WINDOW_REGS;


typedef struct
{
    SCALE wscale;
    SCALE hscale;
    BOOL enabled;
}
OCFB_INFO;

typedef struct
{
    WINDOW_REGS* regs;
    FRAME_BUFFER_INFO fb_info;
    FRAME_BUFFER_ADDRESS fb_address[2];
    BUFFER_ID buffer_selected;
    OCFB_INFO ocfb;
}
WINDOW_INFO;

#define ALPHA_TRANSPARENT  0
#define ALPHA_OPAQUE   255

#endif //WINDOW_H

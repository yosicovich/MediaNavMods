/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*
 * File:  au1000/cp0.h
 *
 * Purpose:  Definitions for CP0 resources
 *
 * Notes:
 *
 * Author:  Eric DeVolder
 * Date:  Jan-07-2002
 *
 * Modifications:
 *
 */

#ifndef _AU1000_CP0_H
#define _AU1000_CP0_H

/***********************************************************************/

#if 0
/*
 * CP0 registers
 */
#define CP0_Index  0
#define CP0_Random  1
#define CP0_EntryLo0 2
#define CP0_EntryLo1 3
#define CP0_Context  4
#define CP0_PageMask 5
#define CP0_Wired  6
#define CP0_BadVAddr 8
#define CP0_Count  9
#define CP0_EntryHi  10
#define CP0_Compare  11
#define CP0_Status  12
#define CP0_Cause  13
#define CP0_EPC   14
#define CP0_PRId  15
#define CP0_Config  16
#define CP0_Config0  16
#define CP0_Config1  16,1
#define CP0_LLAddr  17
#define CP0_WatchLo  18
#define CP0_IWatchLo 18,1
#define CP0_WatchHi  19
#define CP0_IWatchHi 19,1
#define CP0_Scratch  22
#define CP0_Debug  23
#define CP0_DEPC  24
#define CP0_PerfCnt  25
#define CP0_PerfCtrl 25,1
#define CP0_DTag  28
#define CP0_DData  28,1
#define CP0_ITag  29
#define CP0_IData  29,1
#define CP0_ErrorEPC 30
#define CP0_DESave  31
#endif

/***********************************************************************/

#if 0
/*
 * CP0 register accessors
 */

#define CP0(REG) \
uint32 cp0Rd ## REG (void); \
void cp0Wr ## REG (uint32);

CP0(Index)
CP0(Random)
CP0(EntryLo0)
CP0(EntryLo1)
CP0(Context)
CP0(PageMask)
CP0(Wired)
CP0(BadVAddr)
CP0(Count)
CP0(EntryHi)
CP0(Compare)
CP0(Status)
CP0(Cause)
CP0(EPC)
CP0(PRId)
CP0(Config)
CP0(Config0)
CP0(Config1)
CP0(LLAddr)
CP0(WatchLo)
CP0(IWatchLo)
CP0(WatchHi)
CP0(IWatchHi)
CP0(Scratch)
CP0(Debug)
CP0(DEPC)
CP0(PerfCnt)
CP0(PerfCtrl)
CP0(DTag)
CP0(DData)
CP0(ITag)
CP0(IData)
CP0(ErrorEPC)
CP0(DESave)
#endif

#undef CP0

/***********************************************************************/

/* Convert physical address to KSEG0 address */
#define KSEG0(ADDR) ((uint32)(ADDR) + 0x80000000)

/* Convert physical address to KSEG1 address */
#define KSEG1(ADDR) ((uint32)(ADDR) + 0xA0000000)

#define KSEG_MSK      0xE0000000
#define KUSEG(addr)               ( (uint32)(addr) & ~KSEG_MSK)

/*
 * CP0 Status register contents
 */
#define STATUS_IE  (1 << 0)
#define STATUS_EXL  (1 << 1)
#define STATUS_ERL  (1 << 2)
#define STATUS_SWI0  (1 << 8)
#define STATUS_SWI1  (1 << 9)
#define STATUS_IC0R0 (1 << 10)
#define STATUS_IC0R1 (1 << 11)
#define STATUS_IC1R0 (1 << 12)
#define STATUS_IC1R1 (1 << 13)
#define STATUS_PERFCNT (1 << 14)
#define STATUS_COUNTER (1 << 15)
#define STATUS_BEV  (1 << 22)

#define CAUSE_IV  (1 << 23)

/***********************************************************************/

/*
 * Cache routines
 */

void
icacheFlush (void);

void
dcacheFlush (void);

/*
 * TLB routines
 */
void
tlbInit (void);

typedef struct
{
    uint32 EntryLo0;
    uint32 PageMask;
    uint32 EntryLo1;
    uint32 EntryHi;

}
TLBEntry;

void
tlbWrite (int index, TLBEntry *tlb);


/*
 * Au1 core Idle routine
 */
void
au1_wait (void);

/***********************************************************************/

#endif /* _AU1000_CP0_H */


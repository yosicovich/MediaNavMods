/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef _AU1X00_H
#define _AU1X00_H

/***********************************************************************/

/*
 * CP0 registers
 */
#define CP0_Index  $0
#define CP0_Random  $1
#define CP0_EntryLo0 $2
#define CP0_EntryLo1 $3
#define CP0_Context  $4
#define CP0_PageMask $5
#define CP0_Wired  $6
#define CP0_BadVAddr $8
#define CP0_Count  $9
#define CP0_EntryHi  $10
#define CP0_Compare  $11
#define CP0_Status  $12
#define CP0_Cause  $13
#define CP0_EPC   $14
#define CP0_PRId  $15
#define CP0_Config  $16
#define CP0_Config0  $16
#define CP0_Config1  $16,1
#define CP0_LLAddr  $17
#define CP0_WatchLo  $18
#define CP0_IWatchLo $18,1
#define CP0_WatchHi  $19
#define CP0_IWatchHi $19,1
#define CP0_Scratch  $22
#define CP0_Debug  $23
#define CP0_DEPC  $24
#define CP0_PerfCnt  $25
#define CP0_PerfCtrl $25,1
#define CP0_DTag  $28
#define CP0_DData  $28,1
#define CP0_ITag  $29
#define CP0_IData  $29,1
#define CP0_ErrorEPC $30
#define CP0_DESave  $31

#define CP0_PRID_REV    0x0000000F
#define CP0_PRID_IMP    0x000000F0
#define CP0_SR_IE       0x00000001

/***********************************************************************/

/*
 * Static Controller Register Offsets
 */

#define MEM_STCFG0      (0x1000)
#define MEM_STTIME0     (0x1004)
#define MEM_STADDR0     (0x1008)
#define MEM_STCFG1      (0x1010)
#define MEM_STTIME1     (0x1014)
#define MEM_STADDR1     (0x1018)
#define MEM_STCFG2      (0x1020)
#define MEM_STTIME2     (0x1024)
#define MEM_STADDR2     (0x1028)
#define MEM_STCFG3      (0x1030)
#define MEM_STTIME3     (0x1034)
#define MEM_STADDR3     (0x1038)
#define MEM_STNDCTL     (0x1100)
#define MEM_STSTAT      (0x1104)

#ifndef ASSEMBLER
typedef volatile struct
{
    uint32 stcfg0;
    uint32 sttime0;
    uint32 staddr0;
    uint32 reserved0;
    uint32 stcfg1;
    uint32 sttime1;
    uint32 staddr1;
    uint32 reserved1;
    uint32 stcfg2;
    uint32 sttime2;
    uint32 staddr2;
    uint32 reserved2;
    uint32 stcfg3;
    uint32 sttime3;
    uint32 staddr3;
    uint32 reserved3[(0x1100-0x103c)/4];
    uint32 stndctl;
    uint32 ststat;
}
AU1X00_STATIC;
#endif

/*
 * Register content definitions
 */
#define MEM_STCFG_NW            (1<<22)
#define MEM_STCFG_AS            (1<<21)
#define MEM_STCFG_S             (1<<20)
#define MEM_STCFG_DE            (1<<19)
#define MEM_STCFG_BEB_N(N)      ((N&0x03)<<17)
#define MEM_STCFG_TA            (1<<16)
#define MEM_STCFG_DIV_N(N)      ((N&0x07)<<13)
#define MEM_STCFG_ALD           (1<<12)
#define MEM_STCFG_AV            (1<<10)
#define MEM_STCFG_BE            (1<<9)
#define MEM_STCFG_TS            (1<<8)
#define MEM_STCFG_EW            (1<<7)
#define MEM_STCFG_BS            (1<<5)
#define MEM_STCFG_PM            (1<<4)
#define MEM_STCFG_RO            (1<<3)
#define MEM_STCFG_DTY           (7<<0)

#define MEM_STCFG_DTY_SRAM      (0<<0)
#define MEM_STCFG_DTY_IO        (1<<0)
#define MEM_STCFG_DTY_PCMCIA    (2<<0)
#define MEM_STCFG_DTY_FLASH     (3<<0)
#define MEM_STCFG_DTY_NAND      (5<<0)
#define MEM_STCFG_DTY_IDE       (6<<0)

/*
 * MEM_STTIME register definitions for use with
 * DTY=IO, Flash, SRAM or IDE.
 */
#define MEM_STTIME_TWCS         (3<<28)
#define MEM_STTIME_TCSH         (15<<24)
#define MEM_STTIME_TCSOFF       (7<<20)
#define MEM_STTIME_TWP          (63<<14)
#define MEM_STTIME_TCSW         (15<<10)
#define MEM_STTIME_TPM          (15<<6)
#define MEM_STTIME_TA           (63<<0)
#define MEM_STTIME_TWCS_N(N)    (N<<28)
#define MEM_STTIME_TCSH_N(N)    (N<<24)
#define MEM_STTIME_TCSOFF_N(N)  (N<<20)
#define MEM_STTIME_TWP_N(N)     (N<<14)
#define MEM_STTIME_TCSW_N(N)    (N<<10)
#define MEM_STTIME_TPM_N(N)     (N<<6)
#define MEM_STTIME_TA_N(N)      (N<<0)

/*
 * MEM_STTIME register definitions for use with
 * PCMCIA.
 */
#define MEM_STTIME_TMST         (255<<24)
#define MEM_STTIME_TMSU         (127<<17)
#define MEM_STTIME_TMIH         (63<<11)
#define MEM_STTIME_TIST         (63<<5)
#define MEM_STTIME_TISU         (31<<0)
#define MEM_STTIME_TMST_N(N)    (N<<24)
#define MEM_STTIME_TMSU_N(N)    (N<<17)
#define MEM_STTIME_TMIH_N(N)    (N<<11)
#define MEM_STTIME_TIST_N(N)    (N<<5)
#define MEM_STTIME_TISU_N(N)    (N<<0)

/*
 * MEM_STTIME register definitions for use with
 * NAND.
 */
#define MEM_STTIME_TSU          (15<<8)
#define MEM_STTIME_TPUL         (15<<4)
#define MEM_STTIME_TH           (15<<0)
#define MEM_STTIME_TSU_N(N)     (N<<8)
#define MEM_STTIME_TPUL_N(N)    (N<<4)
#define MEM_STTIME_TH_N(N)      (N<<0)

#define MEM_STADDR_E            (1<<28)
#define MEM_STADDR_CSBA         (0x3FFF<<14)
#define MEM_STADDR_CSMASK       (0x3FFF<<0)
#define MEM_STADDR_CSBA_N(N)    ((N)&(0x3FFF<<18)>>4)
#define MEM_STADDR_CSMASK_N(N)  ((N)&(0x3FFF<<18)>>18)

#define MEM_STALTIME_TAH        (7<<6)
#define MEM_STALTIME_TLW        (7<<3)
#define MEM_STALTIME_TASU       (7<<0)
#define MEM_STALTIME_TAH_N(N)   (N<<6)
#define MEM_STALTIME_TLW_N(N)   (N<<3)
#define MEM_STALTIME_TASU_N(N)  (N<<0)

#define MEM_STNDCTRL_ECR        (1<<28)
#define MEM_STNDCTRL_WFRD       (1<<26)
#define MEM_STNDCTRL_WFRI       (1<<25)
#define MEM_STNDCTRL_FFDM       (1<<24)
#define MEM_STNDCTRL_NEIM       (1<<23)
#define MEM_STNDCTRL_FIM        (1<<22)
#define MEM_STNDCTRL_SNIM       (1<<21)
#define MEM_STNDCTRL_DFIM       (1<<20)
#define MEM_STNDCTRL_DFS        (1<<19)
#define MEM_STNDCTRL_RECE       (1<<17)
#define MEM_STNDCTRL_ECE        (1<<16)
#define MEM_STNDCTRL_IE         (1<<8)
#define MEM_STNDCTRL_CS3O       (1<<7)
#define MEM_STNDCTRL_CS2O       (1<<6)
#define MEM_STNDCTRL_CS1O       (1<<5)
#define MEM_STNDCTRL_CS0O       (1<<4)
#define MEM_STNDCTRL_BOOT       (1<<0)

#define MEM_STSTAT_RFNE         (1<<23)
#define MEM_STSTAT_RFF          (1<<22)
#define MEM_STSTAT_SN           (1<<21)
#define MEM_STSTAT_DF           (1<<20)
#define MEM_STSTAT_NEC          (31<<8)
#define MEM_STSTAT_PWT          (1<<5)
#define MEM_STSTAT_EWT          (1<<4)
#define MEM_STSTAT_BOOT         (3<<1)
#define MEM_STSTAT_BSY          (1<<0)

/***********************************************************************/

/*
 * SYStem Register Offsets
 */

/* Clocks  */
#define SYS_FREQCTRL0       (0x0020)
#define SYS_FREQCTRL1       (0x0024)
#define SYS_CLKSRC          (0x0028)
#define SYS_CLKCTRL         (0x002C)
#define SYS_CPUPLL          (0x0060)
#define SYS_AUXPLL          (0x0064)
#define SYS_AUXPLL2         (0x0068)

/* TOY & RTC */
#define SYS_TOYTRIM         (0x0000)
#define SYS_TOYWRITE        (0x0004)
#define SYS_TOYMATCH0       (0x0008)
#define SYS_TOYMATCH1       (0x000C)
#define SYS_TOYMATCH2       (0x0010)
#define SYS_CNTRCTRL        (0x0014)
#define SYS_TOYREAD         (0x0040)
#define SYS_RTCTRIM         (0x0044)
#define SYS_RTCWRITE        (0x0048)
#define SYS_RTCMATCH0       (0x004C)
#define SYS_RTCMATCH1       (0x0050)
#define SYS_RTCMATCH2       (0x0054)
#define SYS_RTCREAD         (0x0058)

/* Power Management */
#define SYS_SCRATCH0        (0x0018)
#define SYS_SCRATCH1        (0x001C)
#define SYS_SCRATCH2        (0x002C)
#define SYS_SCRATCH3        (0x0030)
#define SYS_WAKEMSK         (0x0034)
#define SYS_ENDIAN          (0x0038)
#define SYS_POWERCTRL       (0x003C)
#define SYS_WAKESRC         (0x005C)
#define SYS_SLPPWR          (0x0078)
#define SYS_SLEEP           (0x007C)

#ifndef ASSEMBLER
typedef volatile struct
{
    /* 0x0000 */
    uint32 toytrim;
    /* 0x0004 */
    uint32 toywrite;
    /* 0x0008 */
    uint32 toymatch0;
    /* 0x000C */
    uint32 toymatch1;
    /* 0x0010 */
    uint32 toymatch2;
    /* 0x0014 */
    uint32 cntrctrl;
    /* 0x0018 */
    uint32 scratch0;
    /* 0x001C */
    uint32 scratch1;
    /* 0x0020 */
    uint32 freqctrl0;
    /* 0x0024 */
    uint32 freqctrl1;
    /* 0x0028 */
    uint32 clksrc;
    /* 0x002C */
    uint32 scratch2;
    /* 0x0030 */
    uint32 scratch3;
    /* 0x0034 */
    uint32 wakemsk;
    /* 0x0038 */
    uint32 endian;
    /* 0x003C */
    uint32 powerctrl;
    /* 0x0040 */
    uint32 toyread;
    /* 0x0044 */
    uint32 rtctrim;
    /* 0x0048 */
    uint32 rtcwrite;
    /* 0x004C */
    uint32 rtcmatch0;
    /* 0x0050 */
    uint32 rtcmatch1;
    /* 0x0054 */
    uint32 rtcmatch2;
    /* 0x0058 */
    uint32 rtcread;
    /* 0x005C */
    uint32 wakesrc;
    /* 0x0060 */
    uint32 cpupll;
    /* 0x0064 */
    uint32 auxpll;
    /* 0x0068 */
    uint32 auxpll2;
    /* 0x006C */
    uint32 reserved2;
    /* 0x0070 */
    uint32 reserved3;
    /* 0x0074 */
    uint32 reserved4;
    /* 0x0078 */
    uint32 slppwr;
    /* 0x007C */
    uint32 sleep;
}
AU1X00_SYS;
#endif

/*
 * Register content definitions
 */

/* Clocks */
#define SYS_FREQCTRL0_SCALE         (1<<30)
#define SYS_FREQCTRL0_FRDIV2        (255<<22)
#define SYS_FREQCTRL0_FE2           (1<<21)
#define SYS_FREQCTRL0_FS2           (1<<20)
#define SYS_FREQCTRL0_FRDIV1        (255<<12)
#define SYS_FREQCTRL0_FE1           (1<<11)
#define SYS_FREQCTRL0_FS1           (1<<10)
#define SYS_FREQCTRL0_FRDIV0        (255<<2)
#define SYS_FREQCTRL0_FE0           (1<<1)
#define SYS_FREQCTRL0_FS0           (1<<0)
#define SYS_FREQCTRL0_FRDIV2_N(N)   ((N/2)-1<<22)
#define SYS_FREQCTRL0_FRDIV1_N(N)   ((N/2)-1<<12)
#define SYS_FREQCTRL0_FRDIV0_N(N)   ((N/2)-1<<2)

#define SYS_FREQCTRL0_SCALE         (1<<30)
#define SYS_FREQCTRL1_FRDIV5        (255<<22)
#define SYS_FREQCTRL1_FE5           (1<<21)
#define SYS_FREQCTRL1_FS5           (1<<20)
#define SYS_FREQCTRL1_FRDIV4        (255<<12)
#define SYS_FREQCTRL1_FE4           (1<<11)
#define SYS_FREQCTRL1_FS4           (1<<10)
#define SYS_FREQCTRL1_FRDIV3        (255<<2)
#define SYS_FREQCTRL1_FE3           (1<<1)
#define SYS_FREQCTRL1_FS3           (1<<0)
#define SYS_FREQCTRL1_FRDIV5_N(N)   ((N/2)-1<<22)
#define SYS_FREQCTRL1_FRDIV4_N(N)   ((N/2)-1<<12)
#define SYS_FREQCTRL1_FRDIV3_N(N)   ((N/2)-1<<2)

#define SYS_CLKSRC_ME5              (7<<27)
#define SYS_CLKSRC_MD5              (3<<25)
#define SYS_CLKSRC_ME4              (7<<22)
#define SYS_CLKSRC_MD4              (3<<20)
#define SYS_CLKSRC_ME3              (7<<17)
#define SYS_CLKSRC_MD3              (3<<15)
#define SYS_CLKSRC_ME2              (7<<12)
#define SYS_CLKSRC_MD2              (3<<10)
#define SYS_CLKSRC_ME1              (7<<7)
#define SYS_CLKSRC_MD1              (3<<5)
#define SYS_CLKSRC_ME0              (7<<2)
#define SYS_CLKSRC_MD0              (3<<0)
#define SYS_CLKSRC_ME5_N(N)         (N<<27)
#define SYS_CLKSRC_MD5_N(N)         (N<<25)
#define SYS_CLKSRC_ME4_N(N)         (N<<22)
#define SYS_CLKSRC_MD4_N(N)         (N<<20)
#define SYS_CLKSRC_ME3_N(N)         (N<<17)
#define SYS_CLKSRC_MD3_N(N)         (N<<15)
#define SYS_CLKSRC_ME2_N(N)         (N<<12)
#define SYS_CLKSRC_MD2_N(N)         (N<<10)
#define SYS_CLKSRC_ME1_N(N)         (N<<7)
#define SYS_CLKSRC_MD1_N(N)         (N<<5)
#define SYS_CLKSRC_ME0_N(N)         (N<<2)
#define SYS_CLKSRC_MD0_N(N)         (N<<0)

#define SYS_CLKCTRL_AT              (1<<31)
#define SYS_CLKCTRL_CS              (1<<8)
#define SYS_CLKCTRL_AE              (1<<7)
#define SYS_CLKCTRL_A2E             (1<<6)
#define SYS_CLKCTRL_KT              (63<<0)

#define SYS_CPUPLL_PLL              (127<<0)
#define SYS_AUXPLL_PLL              (63<<0)
#define SYS_AUXPLL2_PLL             (63<<0)

/* TOY & RTC */
#define SYS_CNTRCTRL_ERS            (1<<23)
#define SYS_CNTRCTRL_RTS            (1<<20)
#define SYS_CNTRCTRL_RM2            (1<<19)
#define SYS_CNTRCTRL_RM1            (1<<18)
#define SYS_CNTRCTRL_RM0            (1<<17)
#define SYS_CNTRCTRL_RS             (1<<16)
#define SYS_CNTRCTRL_BP             (1<<14)
#define SYS_CNTRCTRL_REN            (1<<13)
#define SYS_CNTRCTRL_BRT            (1<<12)
#define SYS_CNTRCTRL_TEN            (1<<11)
#define SYS_CNTRCTRL_BTT            (1<<10)
#define SYS_CNTRCTRL_EO             (1<<8)
#define SYS_CNTRCTRL_ETS            (1<<7)
#define SYS_CNTRCTRL_32S            (1<<5)
#define SYS_CNTRCTRL_TTS            (1<<4)
#define SYS_CNTRCTRL_TM2            (1<<3)
#define SYS_CNTRCTRL_TM1            (1<<2)
#define SYS_CNTRCTRL_TM0            (1<<1)
#define SYS_CNTRCTRL_TS             (1<<0)


/***********************************************************************/


/*********************************************************************************************
****                         Au1XXX GPINT Register Definitions                            ****
*********************************************************************************************/
/*
 *	There are a total 128 'channels' defined by the Au13xx databook. However, this requires
 *  4 sperate 32bit registers for programming. Each register is called a 'bank' for ease
 *  of use.
 */

#define GPINT_BANK0		0
#define GPINT_BANK1		1
#define GPINT_BANK2		2
#define GPINT_BANK3		3

#define GPINT_NUM_BANKS	4 /* 0-3 */
#define GPINT_MAX_BANK	(GPINT_BANK3)

#define GPINT_GPIO_PER_BANK		32
#define GPINT_INTS_PER_BANK		GPINT_GPIO_PER_BANK

/* Total number of interrupts our architecture allows */
#define GPINT_MAX_INTS				(GPINT_NUM_BANKS*GPINT_INTS_PER_BANK)

/* Current maximum supported GPIO/INTERRUPTs */
#define GPINT_NUM_GPIO				GPINT_MAX_INTS
#define GPINT_NUM_INTERRUPTS		GPINT_MAX_INTS

/* Starting GPIO/INTERRUPT for each channel
	-- channels 3,4 not used at this time
*/
#define GPINT_BANK0_START		0
#define GPINT_BANK1_START		32
#define GPINT_BANK2_START		64
#define GPINT_BANK3_START		96

#define GPINT_BANK_FROM_GPIO(n)		(n>>5)	// divide by 32 to get bank
#define GPINT_BANK_FROM_INT(n)		GPINT_BANK_FROM_GPIO(n)
#define GPINT_BIT_FROM_GPIO(b,n) 	(1<<(n-(b<<5))) // multiply by 32 to get base
#define GPINT_BIT_FROM_INT(b,n) 	GPINT_BIT_FROM_GPIO(b,n)

#ifndef ASSEMBLER
typedef volatile struct
{
    /* R/W1S */
// unsigned int pin_val0;  // 0x00
// unsigned int pin_val1;  // 0x04
// unsigned int pin_val2;  // 0x08
// unsigned int pin_val3;  // 0x0C
    unsigned int    pin_val[GPINT_NUM_BANKS];

    /* W1C */
// unsigned int pin_valclr0  // 0x10
// unsigned int pin_valclr1; // 0x14
// unsigned int pin_valclr2; // 0x18
// unsigned int pin_valclr3; // 0x1C
    unsigned int    pin_valclr[GPINT_NUM_BANKS];

    /* R/W1C */
// unsigned int int_pend0;  // 0x20
// unsigned int int_pend1;  // 0x24
// unsigned int int_pend2;  // 0x28
// unsigned int int_pend3;  // 0x2c
    unsigned int int_pend[GPINT_NUM_BANKS];

    unsigned int pri_enc;  // 0x30
    unsigned int _resvd0[3];  // 0x34-0x3c

    /* R/W1S */
// unsigned int int_mask0;  // 0x40
// unsigned int int_mask1;  // 0x44
// unsigned int int_mask2;  // 0x48
// unsigned int int_mask3;  // 0x4c
    unsigned int int_mask[GPINT_NUM_BANKS];

    /* W1C */
// unsigned int int_maskclr0; // 0x50
// unsigned int int_maskclr1; // 0x54
// unsigned int int_maskclr2; // 0x58
// unsigned int int_maskclr3; // 0x5C
    unsigned int int_maskclr[GPINT_NUM_BANKS];

    /* R/W */
    unsigned int dma_sel;  // 0x60
    unsigned int _resvd1[(0x80-0x64)/4];  // 0x64-0x7C

    /* W */
// unsigned int    dev_sel0;  // 0x80
// unsigned int    dev_sel1;  // 0x84
// unsigned int    dev_sel2;  // 0x88
// unsigned int    dev_sel3;  // 0x8C
    unsigned int    dev_sel[GPINT_NUM_BANKS];

    /* W */
// unsigned int    dev_selclr0; // 0x90
// unsigned int    dev_selclr1; // 0x94
// unsigned int    dev_selclr2; // 0x98
// unsigned int    dev_selclr3; // 0x9C
    unsigned int    dev_selclr[GPINT_NUM_BANKS];

    /* R */
// unsigned int    reset_val0;  // 0xA0
// unsigned int    reset_val1;  // 0xA4
// unsigned int    reset_val2;  // 0xA8
// unsigned int    reset_val3;  // 0xAC
    unsigned int    reset_val[GPINT_NUM_BANKS];

    unsigned int _resvd2[(0x1000-0xB0)/4]; // 0xB0-0xFFC

    /* R/W -- when interrupt mask is clear */
    /* R   -- when interrupt mask is set */
// unsigned int gp_int0;  // 0x1000
// unsigned int gp_int1;  // 0x1004
// unsigned int gp_int2;  // 0x1008
// unsigned int gp_int2;  // 0x100C
// unsigned int gp_intN;  // 0x1000 + (N*4)
    unsigned int gp_int[GPINT_MAX_INTS];
} AU13XX_GPINT, *PAU13XX_GPINT;

#endif // ASSEMBLER
#define INTR_AU13XX_GPINT 1

#define GPINT_DMASEL_DMA0			(8)
#define GPINT_DMASEL_DMA0_N(n)		(((n)&0xFF)<<GPINT_DMASEL_DMA0)
#define GPINT_DMASEL_DMA1			(0)
#define GPINT_DMASEL_DMA1_N(n)		(((n)&0xFF)<<GPINT_DMASEL_DMA1)

#define GPINT_PINCTL				(0)
#define GPINT_PINCTL_N(n)			(((n)&0x3)<<GPINT_PINCTL)
#define GPINT_PINCTL_GPIOINPUT		GPINT_PINCTL_N(0)
#define GPINT_PINCTL_DEVICE  		GPINT_PINCTL_N(1)
#define GPINT_PINCTL_GPIOOUT_0 		GPINT_PINCTL_N(2)
#define GPINT_PINCTL_GPIOOUT_1		GPINT_PINCTL_N(3)

#define GPINT_INTLINE				(2)
#define GPINT_INTLINE_N(n)			(((n)&0x3)<<GPINT_INTLINE)
#define GPINT_INTLINE_CPUINT_0		GPINT_INTLINE_N(0)
#define GPINT_INTLINE_CPUINT_1		GPINT_INTLINE_N(1)
#define GPINT_INTLINE_CPUINT_2		GPINT_INTLINE_N(2)
#define GPINT_INTLINE_CPUINT_3		GPINT_INTLINE_N(3)

#define GPINT_INTCFG				(4)
#define GPINT_INTCFG_N(n)			(((n)&0x7)<<GPINT_INTCFG)
#define GPINT_INTCFG_DISABLE		GPINT_INTCFG_N(0)
#define GPINT_INTCFG_LL				GPINT_INTCFG_N(1)
#define GPINT_INTCFG_HL				GPINT_INTCFG_N(2)
#define GPINT_INTCFG_FE				GPINT_INTCFG_N(5)
#define GPINT_INTCFG_RE				GPINT_INTCFG_N(6)
#define GPINT_INTCFG_CHANGE			GPINT_INTCFG_N(7)

#define GPINT_INTWAKE				(7)
#define GPINT_INTWAKE_ENABLE		((1)<<GPINT_INTWAKE)

/* GPIO */
#define GPIO_N(N)                   (N)
#define CHANNEL_N(N)				(N)

/***********************************************************************/

/*
 * UART Register Offsets
 */
#define UART_RXDATA  (0x0000)
#define UART_TXDATA  (0x0004)
#define UART_INTEN  (0x0008)
#define UART_INTCAUSE (0x000C)
#define UART_FIFOCTRL (0x0010)
#define UART_LINECTRL (0x0014)
#define UART_MDMCTRL (0x0018)
#define UART_LINESTAT (0x001C)
#define UART_MDMSTAT (0x0020)
#define UART_CLKDIV  (0x0028)
#define UART_ENABLE  (0x0100)
#define UART_MDMDEN (0x0104)
#define UART_BIDIR (0x0108)

#ifndef ASSEMBLER
typedef volatile struct
{
    uint32 rxdata;
    uint32 txdata;
    uint32 inten;
    uint32 intcause;
    uint32 fifoctrl;
    uint32 linectrl;
    uint32 mdmctrl;
    uint32 linestat;
    uint32 mdmstat;
    uint32 reserved0;
    uint32 clkdiv;
    uint32 reserved1[53];
    uint32 enable;
    uint32 mdmen;
    uint32 bidir;
}
AU1X00_UART;
#endif

/*
 * Register content definitions
 */
#define UART_INTEN_MIE                  (1<<3)
#define UART_INTEN_LIE                  (1<<2)
#define UART_INTEN_TIE                  (1<<1)
#define UART_INTEN_RIE                  (1<<0)

#define UART_INTCAUSE_IID               (7<<1)
#define UART_INTCAUSE_IP                (1<<0)
#define UART_INTCAUSE_IID_MS            (0<<1)
#define UART_INTCAUSE_IID_TBA           (1<<1)
#define UART_INTCAUSE_IID_RDA           (2<<1)
#define UART_INTCAUSE_IID_RLS           (3<<1)
#define UART_INTCAUSE_IID_CTO           (6<<1)

#define UART_FIFOCTRL_RFT               (3<<6)
#define UART_FIFOCTRL_TFT               (3<<4)
#define UART_FIFOCTRL_MS                (1<<3)
#define UART_FIFOCTRL_TR                (1<<2)
#define UART_FIFOCTRL_RR                (1<<1)
#define UART_FIFOCTRL_FE                (1<<0)
#define UART_FIFOCTRL_RFT_1             (0<<6)
#define UART_FIFOCTRL_RFT_4             (1<<6)
#define UART_FIFOCTRL_RFT_8             (2<<6)
#define UART_FIFOCTRL_RFT_14            (3<<6)
#define UART_FIFOCTRL_TFT_0             (0<<4)
#define UART_FIFOCTRL_TFT_4             (1<<4)
#define UART_FIFOCTRL_TFT_8             (2<<4)
#define UART_FIFOCTRL_TFT_12            (3<<4)

#define UART_LINECTRL_SB                (1<<6)
#define UART_LINECTRL_PAR               (3<<4)
#define UART_LINECTRL_PE                (1<<3)
#define UART_LINECTRL_ST                (1<<2)
#define UART_LINECTRL_WLS               (3<<0)
#define UART_LINECTRL_PAR_O             (0<<4)
#define UART_LINECTRL_PAR_E             (1<<4)
#define UART_LINECTRL_PAR_M             (2<<4)
#define UART_LINECTRL_PAR_Z             (3<<4)
#define UART_LINECTRL_WLS_5             (0<<0)
#define UART_LINECTRL_WLS_6             (1<<0)
#define UART_LINECTRL_WLS_7             (2<<0)
#define UART_LINECTRL_WLS_8             (3<<0)

#define UART_MDMCTRL_LB                 (1<<4)
#define UART_MDMCTRL_I1                 (1<<3)
#define UART_MDMCTRL_I0                 (1<<2)
#define UART_MDMCTRL_RT                 (1<<1)
#define UART_MDMCTRL_DT                 (1<<0)

#define UART_LINESTAT_RF                (1<<7)
#define UART_LINESTAT_TE                (1<<6)
#define UART_LINESTAT_TT                (1<<5)
#define UART_LINESTAT_BI                (1<<4)
#define UART_LINESTAT_FE                (1<<3)
#define UART_LINESTAT_PE                (1<<2)
#define UART_LINESTAT_OE                (1<<1)
#define UART_LINESTAT_DR                (1<<0)

#define UART_MDMSTAT_CD                 (1<<7)
#define UART_MDMSTAT_RI                 (1<<6)
#define UART_MDMSTAT_DS                 (1<<5)
#define UART_MDMSTAT_CT                 (1<<4)
#define UART_MDMSTAT_DD                 (1<<3)
#define UART_MDMSTAT_TRI                (1<<2)
#define UART_MDMSTAT_DR                 (1<<1)
#define UART_MDMSTAT_DC                 (1<<0)

#define UART_ENABLE_E                   (1<<1)
#define UART_ENABLE_CE                  (1<<0)

#define UART_MDMEN_DRI                  (1<<3)
#define UART_MDMEN_DDSR                 (1<<2)
#define UART_MDMEN_DDCD                 (1<<1)
#define UART_MDMEN_DCTS                 (1<<0)

#define UART_BIDIR_GT                   (1<<2)
#define UART_BIDIR_OD                   (1<<1)
#define UART_BIDIR_GE                   (1<<0)

/***********************************************************************/

/*
 * Secure Digital Register Offsets
 */
#define SD_TXPORT  (0x0000)
#define SD_RXPORT  (0x0004)
#define SD_CONFIG  (0x0008)
#define SD_ENABLE  (0x000C)
#define SD_CONFIG2 (0x0010)
#define SD_BLKSIZE (0x0014)
#define SD_STATUS  (0x0018)
#define SD_DEBUG   (0x001C)
#define SD_CMD     (0x0020)
#define SD_CMDARG  (0x0024)
#define SD_RESP3   (0x0028)
#define SD_RESP2   (0x002C)
#define SD_RESP1   (0x0030)
#define SD_RESP0   (0x0034)
#define SD_TIMEOUT (0x0038)

#ifndef ASSEMBLER
typedef volatile struct
{
    uint32 txport;
    uint32 rxport;
    uint32 config;
    uint32 enable;
    uint32 config2;
    uint32 blksize;
    uint32 status;
    uint32 debug;
    uint32 cmd;
    uint32 cmdarg;
    uint32 resp3;
    uint32 resp2;
    uint32 resp1;
    uint32 resp0;
    uint32 timeout;

}
AU1X00_SD;
#endif

/*
 * Register content definitions
 */
#define SD_CONFIG_SI                    (1<<31)
#define SD_CONFIG_CD                    (1<<30)
#define SD_CONFIG_RF                    (1<<29)
#define SD_CONFIG_RA                    (1<<28)
#define SD_CONFIG_RH                    (1<<27)
#define SD_CONFIG_TA                    (1<<26)
#define SD_CONFIG_TE                    (1<<25)
#define SD_CONFIG_TH                    (1<<24)
#define SD_CONFIG_WC                    (1<<22)
#define SD_CONFIG_RC                    (1<<21)
#define SD_CONFIG_SC                    (1<<20)
#define SD_CONFIG_DT                    (1<<19)
#define SD_CONFIG_DD                    (1<<18)
#define SD_CONFIG_RAT                   (1<<17)
#define SD_CONFIG_CR                    (1<<16)
#define SD_CONFIG_I                     (1<<15)
#define SD_CONFIG_RO                    (1<<14)
#define SD_CONFIG_RU                    (1<<13)
#define SD_CONFIG_TO                    (1<<12)
#define SD_CONFIG_TU                    (1<<11)
#define SD_CONFIG_NE                    (1<<10)
#define SD_CONFIG_DE                    (1<<9)
#define SD_CONFIG_DIV                   (511<<0)
#define SD_CONFIG_DIV_N(n)              (n & SD_CONFIG_DIV)

#define SD_ENABLE_R                     (1<<1)
#define SD_ENABLE_CE                    (1<<0)

#define SD_CONFIG2_DP                   (1<<10)
#define SD_CONFIG2_RW                   (1<<9)
#define SD_CONFIG2_WB                   (1<<8)
#define SD_CONFIG2_BB                   (1<<7)
#define SD_CONFIG2_DC                   (1<<4)
#define SD_CONFIG2_DF                   (1<<3)
#define SD_CONFIG2_FF                   (1<<1)
#define SD_CONFIG2_EN                   (1<<0)

#define SD_BLKSIZE_BC                   (511<<16)
#define SD_BLKSIZE_BS                   (1023<<0)
#define SD_BLKSIZE_BC_N(N)              ((N-1)<<16)
#define SD_BLKSIZE_BS_N(N)              ((N-1)<<0)

#define SD_STATUS_SI                    (1<<31)
#define SD_STATUS_CD                    (1<<30)
#define SD_STATUS_RF                    (1<<29)
#define SD_STATUS_RA                    (1<<28)
#define SD_STATUS_RH                    (1<<27)
#define SD_STATUS_TA                    (1<<26)
#define SD_STATUS_TE                    (1<<25)
#define SD_STATUS_TH                    (1<<24)
#define SD_STATUS_WC                    (1<<22)
#define SD_STATUS_RC                    (1<<21)
#define SD_STATUS_SC                    (1<<20)
#define SD_STATUS_DT                    (1<<19)
#define SD_STATUS_DD                    (1<<18)
#define SD_STATUS_RAT                   (1<<17)
#define SD_STATUS_CR                    (1<<16)
#define SD_STATUS_I                     (1<<15)
#define SD_STATUS_RO                    (1<<14)
#define SD_STATUS_RU                    (1<<13)
#define SD_STATUS_TO                    (1<<12)
#define SD_STATUS_TU                    (1<<11)
#define SD_STATUS_NE                    (1<<10)
#define SD_STATUS_D3                    (1<<7)
#define SD_STATUS_CF                    (1<<6)
#define SD_STATUS_DB                    (1<<5)
#define SD_STATUS_CB                    (1<<4)
#define SD_STATUS_DCRCW                 (7<<0)
#define SD_STATUS_DCRCW_NONE            (2<<0)
#define SD_STATUS_DCRCW_TXERR           (5<<0)
#define SD_STATUS_DCRCW_CRCERR          (7<<0)

#define SD_CMD_RT                       (255<<16)
#define SD_CMD_CI                       (255<<8)
#define SD_CMD_CT                       (15<<4)
#define SD_CMD_RY                       (1<<1)
#define SD_CMD_GO                       (1<<0)
#define SD_CMD_BUSY                     (1<<0)
#define SD_CMD_RT_NONE                  (0<<16)
#define SD_CMD_RT_R1                    (1<<16)
#define SD_CMD_RT_R2                    (2<<16)
#define SD_CMD_RT_R3                    (3<<16)
#define SD_CMD_RT_R4                    (4<<16)
#define SD_CMD_RT_R5                    (5<<16)
#define SD_CMD_RT_R6                    (6<<16)
#define SD_CMD_RT_R1b                   (0x81<<16)
#define SD_CMD_RT_N(N)                  ((N)<<16)
#define SD_CMD_CI_N(N)                  ((N)<<8)
#define SD_CMD_CT_NONE                  (0<<4)  /* IDLE ? */
#define SD_CMD_CT_SBW                   (1<<4)  /* Single block write */
#define SD_CMD_CT_SBR                   (2<<4)  /* Single block read */
#define SD_CMD_CT_MBW                   (3<<4)  /* Multiple block write */
#define SD_CMD_CT_MBR                   (4<<4)  /* Multiple block read */
#define SD_CMD_CT_MBIOW                 (5<<4)  /* Multi block IO write */
#define SD_CMD_CT_MBIOR                 (6<<4)  /* Multi block IO read */
#define SD_CMD_CT_TERM                  (7<<4)
#define SD_CMD_CT_TERMIO                (8<<4)
#define SD_CMD_CT_N(n)                  (n<<4)


/***********************************************************************/

#define  DDMA_NUM_CHANNELS  16    // general registers follow channels at 0x14003000

#ifndef ASSEMBLER
typedef volatile struct
{
    uint32 cfg;   // config
    uint32 des_ptr;  // descriptor pointer
    uint32 stat_ptr;  // status pointer
    uint32 dbell;   // doorbell
    uint32 irq;   // Interrupt
    uint32 stat;   // Status
    uint32 bytecnt;  // Remaining byte count
    uint32 reserved0[16]; //
    uint8 reserved1[0xA4];// Padding to make channels line up on 0x100 boundry
}
DDMA_CHANNEL;
#endif

/*
 * Bit definitions for Channel Config
 */
#define  DDMA_CHANCFG_EN                (1<<0)
#define  DDMA_CHANCFG_DBE               (1<<1)
#define  DDMA_CHANCFG_SBE               (1<<2)
#define  DDMA_CHANCFG_DFN               (1<<3)
#define  DDMA_CHANCFG_PPR               (1<<4)
#define  DDMA_CHANCFG_SYNC              (1<<5)
#define  DDMA_CHANCFG_DP                (1<<6)
#define  DDMA_CHANCFG_DED               (1<<7)
#define  DDMA_CHANCFG_SP                (1<<8)
#define  DDMA_CHANCFG_SED               (1<<9)

/*
 * Bit definitions for Channel Interrupt
 */
#define  DDMA_CHANINT_IN                (1<<0)

/*
 * Bit definitions for Channel Status
 */
#define  DDMA_CHANSTATUS_H              (1<<0)
#define  DDMA_CHANSTATUS_V              (1<<1)
#define  DDMA_CHANSTATUS_DB             (1<<2)

#ifndef ASSEMBLER
typedef volatile struct
{
    uint32 cmd0;        // Command
    uint32 cmd1;        // Byte count/cmd1
    uint32 source0;     // Source pointer
    uint32  source1;    // Source pointer
    uint32 dest0;       // Destination pointer
    uint32 dest1;       // Destination stride/block
    uint32 stat;        // Status / Subroutine pointer
    uint32 nxt_ptr;     // next descriptor
}
DDMA_DESCRIPTOR_STD;

typedef volatile struct
{
    uint32 cmd;         // Command
    uint32 byte_cnt;    // Byte count
    uint32 src_data0;   // Source data low
    uint32  src_data1;  // Source data high
    uint32 dst_ptr;     // Destination pointer
    uint32 dst_strblk;  // Destination stride/block
    uint32 stat;        // Status / Subroutine pointer
    uint32 nxt_ptr;     // next descriptor
}
DDMA_DESCRIPTOR_WRITEDMA;

typedef volatile struct
{
    uint32 cmd;         // Command
    uint32 branch_ptr;  // Branch pointer
    uint32 src_ptr;     // Source pointer
    uint32  reserved;
    uint32 compare_data;// Compare data
    uint32 data_mask;   // Data mask
    uint32 stat;        // Status / Subroutine pointer
    uint32 nxt_ptr;     // next descriptor
}
DDMA_DESCRIPTOR_COMPARE_BRANCH;

typedef volatile struct
{
    union
    {
        DDMA_DESCRIPTOR_STD    std;
        DDMA_DESCRIPTOR_WRITEDMA  wr;
        DDMA_DESCRIPTOR_COMPARE_BRANCH cb;
    } u; //descriptor union

    union
    {
        uint8       u8[32];
        uint16       u16[16];
        uint32       u32[8];
        void *       p;
    }c; // context
}
DDMA_DESCRIPTOR;
#endif

/*
 * Bit definitions for descriptor command
 */
#define  DDMA_DESCCMD_ST                (0)
#define  DDMA_DESCCMD_ST_N(n)           ((n&3)<<DDMA_DESCCMD_ST)
#define   DDMA_DESCCMD_ST_WRSTAT         DDMA_DESCCMD_ST_N(1)
#define   DDMA_DESCCMD_ST_CLEAR          DDMA_DESCCMD_ST_N(2)
#define   DDMA_DESCCMD_ST_WRCNT          DDMA_DESCCMD_ST_N(3)
#define  DDMA_DESCCMD_CV                (1<<2)
#define  DDMA_DESCCMD_RP                (1<<3)
#define  DDMA_DESCCMD_SP                (1<<4)
#define  DDMA_DESCCMD_NR                (1<<5)
#define  DDMA_DESCCMD_SR                (1<<6)
#define  DDMA_DESCCMD_SRS               (1<<7)
#define  DDMA_DESCCMD_IE                (1<<8)      // Set interrupt bit upon completion
#define  DDMA_DESCCMD_RES               (1<<9)
#define  DDMA_DESCCMD_SM                (1<<10)
#define  DDMA_DESCCMD_DN                (1<<11)
#define  DDMA_DESCCMD_SN                (1<<12)
#define  DDMA_DESCCMD_DT                (13)
#define  DDMA_DESCCMD_DT_N(n)           ((n&3)<<DDMA_DESCCMD_DT)
#define   DDMA_DESCCMD_DT_REG            DDMA_DESCCMD_DT_N(0)
#define   DDMA_DESCCMD_DT_WR             DDMA_DESCCMD_DT_N(1)
#define   DDMA_DESCCMD_DT_COMPWR         DDMA_DESCCMD_DT_N(2)
#define   DDMA_DESCCMD_DT_RES            DDMA_DESCCMD_DT_N(3)
#define  DDMA_DESCCMD_ARB               (1<<15)
#define  DDMA_DESCCMD_DW                (16)
#define  DDMA_DESCCMD_DW_N(n)           ((n&3)<<DDMA_DESCCMD_DW)
#define   DDMA_DESCCMD_DW_BYTE           DDMA_DESCCMD_DW_N(0)
#define   DDMA_DESCCMD_DW_HWORD          DDMA_DESCCMD_DW_N(1)
#define   DDMA_DESCCMD_DW_WORD           DDMA_DESCCMD_DW_N(2)
#define  DDMA_DESCCMD_SW                (18)
#define  DDMA_DESCCMD_SW_N(n)           ((n&3)<<DDMA_DESCCMD_SW)
#define   DDMA_DESCCMD_SW_BYTE           DDMA_DESCCMD_SW_N(0)
#define   DDMA_DESCCMD_SW_HWORD          DDMA_DESCCMD_SW_N(1)
#define   DDMA_DESCCMD_SW_WORD           DDMA_DESCCMD_SW_N(2)
#define  DDMA_DESCCMD_DID               (20)
#define  DDMA_DESCCMD_DID_N(n)          ((n&0x1F)<<DDMA_DESCCMD_DID)
#define  DDMA_DESCCMD_SID               (25)
#define  DDMA_DESCCMD_SID_N(n)          ((n&0x1F)<<DDMA_DESCCMD_SID)
#define  DDMA_DESCCMD_M                 (1<<30)
#define  DDMA_DESCCMD_V                 (1<<31)

/*
 * Bit masks for descriptor count
 */
#define  DDMA_DESCCNT_BC                (0)
#define  DDMA_DESCCNT_BC_N(n)           ((n&0x1FFFF)<<DDMA_DESCCNT_BC)
#define  DDMA_DESCCNT_FL                (22)
#define  DDMA_DESCCNT_FL_N(n)           ((n&3)<<DDMA_DESCCNT_FL)
#define  DDMA_DESCCNT_DUPTR             (24)
#define  DDMA_DESCCNT_DUPTR_N(n)        ((n&0x0f)<<DDMA_DESCCNT_DUPTR)
#define  DDMA_DESCCNT_SUPTR             (28)
#define  DDMA_DESCCNT_SUPTR_N(n)        ((n&0x0f)<<DDMA_DESCCNT_SUPTR)

/*
 * Bit definitions for branch pointer
 */
#define  DDMA_DESCDSRC_BP               (0)
#define  DDMA_DESCDSRC_BP_N(n)          ((n&0x7ffffff)<<DDMA_DESCDSRC_BP)
#define  DDMA_DESCDSRC_SUPTR            (28)
#define  DDMA_DESCDSRC_SUPTR_N(n)       ((n&0x0f)<<DDMA_DESCDSRC_SUPTR)

/*
 * Bit definitions for source stride/block 1 dimensional
 */
#define  DDMA_DESCSRC_STRIDE_SS             (0)
#define  DDMA_DESCSRC_STRIDE_SS_N(n)        ((n&0x3fff)<<DDMA_DESCSRC_STRIDE_SS)
#define  DDMA_DESCSRC_STRIDE_SB             (14)
#define  DDMA_DESCSRC_STRIDE_SB_N(n)        ((n&0x3fff)<<DDMA_DESCSRC_STRIDE_SB)
#define  DDMA_DESCSRC_STRIDE_SAM            (28)
#define  DDMA_DESCSRC_STRIDE_SAM_N(n)       ((n&3)<<DDMA_DESCSRC_STRIDE_SAM)
#define  DDMA_DESCSRC_STRIDE_SAM_INC        DDMA_DESCSRC_STRIDE_SAM_N(0)
#define  DDMA_DESCSRC_STRIDE_SAM_DEC        DDMA_DESCSRC_STRIDE_SAM_N(1)
#define  DDMA_DESCSRC_STRIDE_SAM_STATIC     DDMA_DESCSRC_STRIDE_SAM_N(2)
#define  DDMA_DESCSRC_STRIDE_SAM_BURST      DDMA_DESCSRC_STRIDE_SAM_N(3)
#define  DDMA_DESCSRC_STRIDE_STS            (30)
#define  DDMA_DESCSRC_STRIDE_STS_N(n)       ((n&3)<<DDMA_DESCSRC_STRIDE_STS)
#define  DDMA_DESCSRC_STRIDE_STS_1          DDMA_DESCSRC_STRIDE_STS_N(0)
#define  DDMA_DESCSRC_STRIDE_STS_2          DDMA_DESCSRC_STRIDE_STS_N(1)
#define  DDMA_DESCSRC_STRIDE_STS_4          DDMA_DESCSRC_STRIDE_STS_N(2)
#define  DDMA_DESCSRC_STRIDE_STS_8          DDMA_DESCSRC_STRIDE_STS_N(3)

/*
 * Bit definitions for source stride/block 2 dimensional
 */
#define  DDMA_DESCSRC_STRIDE2DIM_SC         (0)
#define  DDMA_DESCSRC_STRIDE2DIM_SC_N(n)    ((n&0x7ff)<<DDMA_DESCSRC_STRIDE2DIM_SC)
#define  DDMA_DESCSRC_STRIDE2DIM_SS         (11)
#define  DDMA_DESCSRC_STRIDE2DIM_SS_N(n)    ((n&0x3ff)<<DDMA_DESCSRC_STRIDE2DIM_SS)
#define  DDMA_DESCSRC_STRIDE2DIM_SB         (21)
#define  DDMA_DESCSRC_STRIDE2DIM_SB_N(n)    ((n&0x07f)<<DDMA_DESCSRC_STRIDE2DIM_SB)
#define  DDMA_DESCSRC_STRIDE2DIM_SAM        (28)
#define  DDMA_DESCSRC_STRIDE2DIM_SAM_N(n)   ((n&3)<<DDMA_DESCSRC_STRIDE2DIM_SAM)
#define   DDMA_DESCSRC_STRIDE2DIM_SAM_INC    DDMA_DESCSRC_STRIDE2DIM_SAM_N(0)
#define   DDMA_DESCSRC_STRIDE2DIM_SAM_DEC    DDMA_DESCSRC_STRIDE2DIM_SAM_N(1)
#define   DDMA_DESCSRC_STRIDE2DIM_SAM_STATIC DDMA_DESCSRC_STRIDE2DIM_SAM_N(2)
#define   DDMA_DESCSRC_STRIDE2DIM_SAM_BURST  DDMA_DESCSRC_STRIDE2DIM_SAM_N(3)
#define  DDMA_DESCSRC_STRIDE2DIM_STS    (30)
#define  DDMA_DESCSRC_STRIDE2DIM_STS_N(n)   ((n&3)<<DDMA_DESCSRC_STRIDE2DIM_STS)
#define   DDMA_DESCSRC_STRIDE2DIM_STS_1      DDMA_DESCSRC_STRIDE2DIM_STS_N(0)
#define   DDMA_DESCSRC_STRIDE2DIM_STS_2      DDMA_DESCSRC_STRIDE2DIM_STS_N(1)
#define   DDMA_DESCSRC_STRIDE2DIM_STS_4      DDMA_DESCSRC_STRIDE2DIM_STS_N(2)
#define   DDMA_DESCSRC_STRIDE2DIM_STS_8      DDMA_DESCSRC_STRIDE2DIM_STS_N(3)


/*
 * Bit definitions for dest  stride/block 1 dimensional
 */
#define  DDMA_DESCDST_STRIDE_DS             (0)
#define  DDMA_DESCDST_STRIDE_DS_N(n)        ((n&0x3fff)<<DDMA_DESCDST_STRIDE_DS)
#define  DDMA_DESCDST_STRIDE_DB             (14)
#define  DDMA_DESCDST_STRIDE_DB_N(n)        ((n&0x3fff)<<DDMA_DESCDST_STRIDE_DB)
#define  DDMA_DESCDST_STRIDE_DAM            (28)
#define  DDMA_DESCDST_STRIDE_DAM_N(n)       ((n&3)<<DDMA_DESCDST_STRIDE_DAM)
#define   DDMA_DESCDST_STRIDE_DAM_INC        DDMA_DESCDST_STRIDE_DAM_N(0)
#define   DDMA_DESCDST_STRIDE_DAM_DEC        DDMA_DESCDST_STRIDE_DAM_N(1)
#define   DDMA_DESCDST_STRIDE_DAM_STATIC     DDMA_DESCDST_STRIDE_DAM_N(2)
#define   DDMA_DESCDST_STRIDE_DAM_BURST      DDMA_DESCDST_STRIDE_DAM_N(3)
#define  DDMA_DESCDST_STRIDE_DTS            (30)
#define  DDMA_DESCDST_STRIDE_DTS_N(n)       ((n&3)<<DDMA_DESCDST_STRIDE_DTS)
#define   DDMA_DESCDST_STRIDE_DTS_1          DDMA_DESCDST_STRIDE_DTS_N(0)
#define   DDMA_DESCDST_STRIDE_DTS_2          DDMA_DESCDST_STRIDE_DTS_N(1)
#define   DDMA_DESCDST_STRIDE_DTS_4          DDMA_DESCDST_STRIDE_DTS_N(2)
#define   DDMA_DESCDST_STRIDE_DTS_8          DDMA_DESCDST_STRIDE_DTS_N(3)

/*
 * Bit definitions for dest  stride/block 2 dimensional
 */
#define  DDMA_DESCDST_STRIDE2DIM_DC         (0)
#define  DDMA_DESCDST_STRIDE2DIM_DC_N(n)    ((n&0x7ff)<<DDMA_DESCDST_STRIDE2DIM_DC)
#define  DDMA_DESCDST_STRIDE2DIM_DS         (11)
#define  DDMA_DESCDST_STRIDE2DIM_DS_N(n)    ((n&0x3ff)<<DDMA_DESCDST_STRIDE2DIM_DS)
#define  DDMA_DESCDST_STRIDE2DIM_DB         (21)
#define  DDMA_DESCDST_STRIDE2DIM_DB_N(n)    ((n&0x7f)<<DDMA_DESCDST_STRIDE2DIM_DB)
#define  DDMA_DESCDST_STRIDE2DIM_DAM        (28)
#define  DDMA_DESCDST_STRIDE2DIM_DAM_N(n)   ((n&3)<<DDMA_DESCDST_STRIDE2DIM_DAM)
#define   DDMA_DESCDST_STRIDE2DIM_DAM_INC    DDMA_DESCDST_STRIDE2DIM_DAM_N(0)
#define   DDMA_DESCDST_STRIDE2DIM_DAM_DEC    DDMA_DESCDST_STRIDE2DIM_DAM_N(1)
#define   DDMA_DESCDST_STRIDE2DIM_DAM_STATIC DDMA_DESCDST_STRIDE2DIM_DAM_N(2)
#define   DDMA_DESCDST_STRIDE2DIM_DAM_BURST  DDMA_DESCDST_STRIDE2DIM_DAM_N(3)
#define  DDMA_DESCDST_STRIDE2DIM_DTS        (30)
#define  DDMA_DESCDST_STRIDE2DIM_DTS_N(n)   ((n&3)<<DDMA_DESCDST_STRIDE2DIM_DTS)
#define  DDMA_DESCDST_STRIDE2DIM_DTS_1       DDMA_DESCDST_STRIDE2DIM_DTS_N(0)
#define  DDMA_DESCDST_STRIDE2DIM_DTS_2       DDMA_DESCDST_STRIDE2DIM_DTS_N(1)
#define  DDMA_DESCDST_STRIDE2DIM_DTS_4       DDMA_DESCDST_STRIDE2DIM_DTS_N(2)
#define  DDMA_DESCDST_STRIDE2DIM_DTS_8       DDMA_DESCDST_STRIDE2DIM_DTS_N(3)

/*
 * Bit definitions for descriptor "next" pointer
 */
#define  DDMA_DESCNEXTPTR_NPTR          (0)
#define  DDMA_DESCNEXTPTR_NPTR_N(n)     ((n&0x1ffffff)<<DDMA_DESCNEXTPTR_NPTR)
#define  DDMA_DESCNEXTPTR_MS            (1<<27)
#define  DDMA_DESCNEXTPTR_BBC           (28)
#define  DDMA_DESCNEXTPTR_BBC_N(n)      ((n&3)<<DDMA_DESCNEXTPTR_BBC)
#define   DDMA_DESCNEXTPTR_BBC_1         DDMA_DESCNEXTPTR_BBC_N(0)
#define   DDMA_DESCNEXTPTR_BBC_2         DDMA_DESCNEXTPTR_BBC_N(1)
#define   DDMA_DESCNEXTPTR_BBC_3         DDMA_DESCNEXTPTR_BBC_N(2)
#define   DDMA_DESCNEXTPTR_BBC_4         DDMA_DESCNEXTPTR_BBC_N(3)

/*
 *  DDMA Controller register offsets
 */
#define DDMA_CONFIG   (0x0000)
#define DDMA_INTSTAT  (0x0004)
#define DDMA_THROTTLE (0x0008)
#define DDMA_INTEN    (0x000C)

#ifndef ASSEMBLER
typedef volatile struct
{
    DDMA_CHANNEL channel[DDMA_NUM_CHANNELS];   // Start at offset 1400 2000 -- 1400 2f00
    uint32 config;    // 0x1400 3000
    uint32 intstat;   // 0x1400 3004
    uint32 throttle;  // 0x1400 3008
    uint32 inten;     // 0x1400 300c
}
AU1X00_DDMA;
#endif

/*
 * Bit definitions for General Configuration
 */
#define  DDMA_CONFIG_AL                 (1<<0)
#define  DDMA_CONFIG_AH                 (1<<1)
#define  DDMA_CONFIG_AF                 (1<<2)
#define  DDMA_CONFIG_C64                (1<<8)

/*
 * Bit definitions for Interrupt Status
 */
#define  DDMA_INTSTAT_CHAN0             (1<<0)
#define  DDMA_INTSTAT_CHAN1             (1<<1)
#define  DDMA_INTSTAT_CHAN2             (1<<2)
#define  DDMA_INTSTAT_CHAN3             (1<<3)
#define  DDMA_INTSTAT_CHAN4             (1<<4)
#define  DDMA_INTSTAT_CHAN5             (1<<5)
#define  DDMA_INTSTAT_CHAN6             (1<<6)
#define  DDMA_INTSTAT_CHAN7             (1<<7)
#define  DDMA_INTSTAT_CHAN8             (1<<8)
#define  DDMA_INTSTAT_CHAN9             (1<<9)
#define  DDMA_INTSTAT_CHAN10            (1<<10)
#define  DDMA_INTSTAT_CHAN11            (1<<11)
#define  DDMA_INTSTAT_CHAN12            (1<<12)
#define  DDMA_INTSTAT_CHAN13            (1<<13)
#define  DDMA_INTSTAT_CHAN14            (1<<14)
#define  DDMA_INTSTAT_CHAN15            (1<<15)

/*
 * Bit definitions for Throttle
 */
#define DDMA_THROTTLE_EN                (1<<31)
#define DDMA_THROTTLE_DIV(n)            ((n)&0xFFFF))

/*
 * Bit definitions for Interrupt Enable
 */
#define  DDMA_INTEN_CHAN0               (1<<0)
#define  DDMA_INTEN_CHAN1               (1<<1)
#define  DDMA_INTEN_CHAN2               (1<<2)
#define  DDMA_INTEN_CHAN3               (1<<3)
#define  DDMA_INTEN_CHAN4               (1<<4)
#define  DDMA_INTEN_CHAN5               (1<<5)
#define  DDMA_INTEN_CHAN6               (1<<6)
#define  DDMA_INTEN_CHAN7               (1<<7)
#define  DDMA_INTEN_CHAN8               (1<<8)
#define  DDMA_INTEN_CHAN9               (1<<9)
#define  DDMA_INTEN_CHAN10              (1<<10)
#define  DDMA_INTEN_CHAN11              (1<<11)
#define  DDMA_INTEN_CHAN12              (1<<12)
#define  DDMA_INTEN_CHAN13              (1<<13)
#define  DDMA_INTEN_CHAN14              (1<<14)
#define  DDMA_INTEN_CHAN15              (1<<15)


/*
 * DDMA Peripheral Addresses
 */
#define  DDMA_UART0_TX_ID               (0)
#define  DDMA_UART0_RX_ID               (1)
#define  DDMA_UART1_TX_ID               (2)
#define  DDMA_UART1_RX_ID               (3)
#define  DDMA_UART2_TX_ID               (4)
#define  DDMA_UART2_RX_ID               (5)
#define  DDMA_UART3_TX_ID               (6)
#define  DDMA_UART3_RX_ID               (7)
#define  DDMA_SDMS0_TX_ID               (8)
#define  DDMA_SDMS0_RX_ID               (9)
#define  DDMA_SDMS1_TX_ID               (10)
#define  DDMA_SDMS1_RX_ID               (11)
#define  DDMA_AES_TX_ID                 (12)
#define  DDMA_AES_RX_ID                 (13)
#define  DDMA_PSC0_TX_ID                (14)
#define  DDMA_PSC0_RX_ID                (15)
#define  DDMA_PSC1_TX_ID                (16)
#define  DDMA_PSC1_RX_ID                (17)
#define  DDMA_PSC2_TX_ID                (18)
#define  DDMA_PSC2_RX_ID                (19)
#define  DDMA_PSC3_TX_ID                (20)
#define  DDMA_PSC3_RX_ID                (21)
#define  DDMA_LCD_RETRACE_ID            (22)
#define  DDMA_NAND_FLASH_ID             (23)
#define  DDMA_SDMS2_TX_ID               (24)
#define  DDMA_SDMS2_RX_ID               (25)
#define  DDMA_CIM_FRAME_SYNC_ID         (26)
#define  DDMA_UDMA                      (27)
#define  DDMA_REQ0_ID                   (28)
#define  DDMA_REQ1_ID                   (29)
#define  DDMA_MEMORY_THROTTLE_ID        (30)
#define  DDMA_ALWAYS_HIGH_ID            (31)

/*
 * Physical address of ddma peripherals
 */
#define  DDMA_UART0_TX_ADDR             (0x10100004)
#define  DDMA_UART0_RX_ADDR             (0x10101000)
#define  DDMA_UART1_TX_ADDR             (0x10101004)
#define  DDMA_UART1_RX_ADDR             (0x10101000)
#define  DDMA_UART2_TX_ADDR             (0x10102004)
#define  DDMA_UART2_RX_ADDR             (0x10102000)
#define  DDMA_UART3_TX_ADDR             (0x10103004)
#define  DDMA_UART3_RX_ADDR             (0x10103000)
#define  DDMA_SDMS0_TX_ADDR             (0x10600000)
#define  DDMA_SDMS0_RX_ADDR             (0x10600004)
#define  DDMA_SDMS1_TX_ADDR             (0x10601000)
#define  DDMA_SDMS1_RX_ADDR             (0x10601004)
#define  DDMA_AES_TX_ADDR               (0x10300008)
#define  DDMA_AES_RX_ADDR               (0x10300004)
#define  DDMA_PSC0_TX_ADDR              (0x10a0001c)
#define  DDMA_PSC0_RX_ADDR              (0x10a0001c)
#define  DDMA_PSC1_TX_ADDR              (0x10a0101c)
#define  DDMA_PSC1_RX_ADDR              (0x10a0101c)
#define  DDMA_PSC2_TX_ADDR              (0x10a0201c)
#define  DDMA_PSC2_RX_ADDR              (0x10a0201c)
#define  DDMA_PSC3_TX_ADDR              (0x10a0301c)
#define  DDMA_PSC3_RX_ADDR              (0x10a0301c)
#define  DDMA_SDMS2_TX_ADDR             (0x10602000)
#define  DDMA_SDMS2_RX_ADDR             (0x10602004)
#define  DDMA_UDMA_ADDR                 (0x14001810)

/***********************************************************************/

#define PSC_SEL     0x00000000
#define PSC_CTL     0x00000004

#ifndef ASSEMBLER
typedef volatile struct
{
    uint32  sel;       // PSC Select
    uint32 ctl;       // PSC control
}
PSC_SELECT;
#endif

#define PSC_SEL_PS                      (0x7<<0) // Protocol select
#define PSC_SEL_PS_N(n)                 ((n&0x7)<<0)
#define PSC_SEL_CLK                     (0x3<<4) // Clock Source
#define PSC_SEL_CLK_N(n)                ((n&0x3)<<4)
#define  PSC_SEL_CLK_TOY                 PSC_SEL_CLK_N(0)
#define  PSC_SEL_CLK_OFFCHIP             PSC_SEL_CLK_N(1)
#define  PSC_SEL_CLK_SERIAL              PSC_SEL_CLK_N(2)
#define PSC_CTL_CE                      (1<<0)  // Clock Enable
#define PSC_CTL_EN                      (1<<1)  // PSC Enable

#define PSC_SEL_PS_SPI                  (PSC_SEL_PS_N(2))
#define PSC_SEL_PS_I2S                  (PSC_SEL_PS_N(3))
#define PSC_SEL_PS_AC97                 (PSC_SEL_PS_N(4))
#define PSC_SEL_PS_SMB                  (PSC_SEL_PS_N(5))

/*
 * Some simple defines for passing to functions
 */
#define _PSC_SPI                        PSC_SEL_PS_SPI
#define _PSC_I2S                        PSC_SEL_PS_I2S
#define _PSC_AC97                       PSC_SEL_PS_AC97
#define _PSC_SMB                        PSC_SEL_PS_SMB


/*
################################################################################################
#####                         SPI  Register Definitions                                    #####
################################################################################################
*/

#define PSC_SPI_SEL   PSC_SEL
#define PSC_SPI_CTL   PSC_CTL
#define PSC_SPI_CFG   0x00000008
#define PSC_SPI_MSK   0x0000000C
#define PSC_SPI_PCR   0x00000010
#define PSC_SPI_STS   0x00000014
#define PSC_SPI_EVNT  0x00000018
#define PSC_SPI_TXRX  0x0000001C

#ifndef ASSEMBLER
typedef volatile struct
{
    PSC_SELECT psc;  //00,04
    uint32  cfg;  //08
    uint32  msk;  //0C
    uint32  pcr;  //10
    uint32  sts;  //14
    uint32  evnt;  //18
    uint32  txrx;  //1C
}
PSC_SPI;
#endif

#define PSC_SPI_CFG_MO   (1<<0)  // Master Only Mode
#define PSC_SPI_CFG_MLF   (1<<1)  // MSB/LSB Data First
#define PSC_SPI_CFG_LB   (1<<3)  // Loopback mode
#define PSC_SPI_CFG_LEN   (0x1F<<4) // Length mask
#define PSC_SPI_CFG_LEN_N(n) ((n&0x1F)<<4) // Length 'n'
#define PSC_SPI_CFG_CDE   (1<<9)  // Clock Phase Delay
#define PSC_SPI_CFG_CCE   (1<<10)  // Clock Chop Enable
#define PSC_SPI_CFG_PSE   (1<<11)  // Port Swap Enable
#define PSC_SPI_CFG_BI   (1<<12)  // Bit Clock Invert
#define PSC_SPI_CFG_DIV   (0x3<<13) // Clock Divider
#define PSC_SPI_CFG_DIV_N(n) ((n&0x3)<<13)
#define PSC_SPI_CFG_BRG   (0x3F<<15) // Baud Rate Generator
#define PSC_SPI_CFG_BRG_N(n) ((n&0x3F)<<15)
#define PSC_SPI_CFG_DE   (1<<26)  //Device Enable
#define PSC_SPI_CFG_DD   (1<<27)  // Diable DMA
#define PSC_SPI_CFG_TRD   (0x3<<28) // TX Request Depth
#define PSC_SPI_CFG_TRD_N(n) ((n&0x3)<<28)
#define PSC_SPI_CFG_RRD   (0x3<<30) // Rx Request Depth
#define PSC_SPI_CFG_RRD_N(n) ((n&0x3)<<30)

#define PSC_SPI_MSK_MD   (1<<4)  // Master Done
#define PSC_SPI_MSK_SD   (1<<5)  // Slave done
#define PSC_SPI_MSK_TU   (1<<8)  // TX Fifo underflow
#define PSC_SPI_MSK_TO   (1<<9)  // TX fifo overflow
#define PSC_SPI_MSK_TR   (1<<10)  // TX Fifo request
#define PSC_SPI_MSK_RU   (1<<11)  // RX Fifo underflow
#define PSC_SPI_MSK_RO   (1<<12)  // RX fifo overflow
#define PSC_SPI_MSK_RR   (1<<13)  // RX Fifo request
#define PSC_SPI_MSK_MM   (1<<16)  // Multiple Master Error

#define PSC_SPI_PCR_MS   (1<<0)  // Master Start
#define PSC_SPI_PCR_TC   (1<<2)  // Tx Data Clear
#define PSC_SPI_PCR_SS   (1<<4)  // Slave Start
#define PSC_SPI_PCR_SP   (1<<5)  // Slave Stop
#define PSC_SPI_PCR_RC   (1<<6)  // Rx Data Clear

// Status Register is Read Only //
#define PSC_SPI_STS_SR   (1<<0)  // PSC Ready
#define PSC_SPI_STS_DR   (1<<1)   // Device Ready
#define PSC_SPI_STS_DI   (1<<2)  // Device INterrupt
#define PSC_SPI_STS_MB   (1<<4)  // Master BUsy
#define PSC_SPI_STS_SB   (1<<5)  // Slave Busy
#define PSC_SPI_STS_TR   (1<<8)  // Tx Rrequest
#define PSC_SPI_STS_TE   (1<<9)  // Tx Fifo Empty
#define PSC_SPI_STS_TF   (1<<10)  // Tx Fifo Full
#define PSC_SPI_STS_RR   (1<<11)  // Rx Rrequest
#define PSC_SPI_STS_RE   (1<<12)  // Rx Fifo Empty
#define PSC_SPI_STS_RF   (1<<13)  // Rx Fifo Full

#define PSC_SPI_EVNT_MD   (1<<4)  // Master Done
#define PSC_SPI_EVNT_SD   (1<<5)  // Slave done
#define PSC_SPI_EVNT_TU   (1<<8)  // TX Fifo underflow
#define PSC_SPI_EVNT_TO   (1<<9)  // TX fifo overflow
#define PSC_SPI_EVNT_TR   (1<<10)  // TX Fifo request
#define PSC_SPI_EVNT_RU   (1<<11)  // RX Fifo underflow
#define PSC_SPI_EVNT_RO   (1<<12)  // RX fifo overflow
#define PSC_SPI_EVNT_RR   (1<<13)  // RX Fifo request
#define PSC_SPI_EVNT_MM   (1<<16)  // Multiple Master Error

#define PSC_SPI_TXRX_DATA  (0xFFFFFF<<0) // Data
#define PSC_SPI_TXRX_DATA_N(n) ((n&0xFFFFFF)<<0)
#define PSC_SPI_TXRX_ST   (1<<28)  // Slave Select Toggle
#define PSC_SPI_TXRX_LC   (1<<29)  // Last Character -- Non-DMA only


/*
################################################################################################
#####                          I2S Register Definitions                                    #####
################################################################################################
*/

#define PSC_I2S_SEL   PSC_SEL
#define PSC_I2S_CTL   PSC_CTL
#define PSC_I2S_CFG   0x00000008
#define PSC_I2S_MSK   0x0000000C
#define PSC_I2S_PCR   0x00000010
#define PSC_I2S_STS   0x00000014
#define PSC_I2S_EVNT  0x00000018
#define PSC_I2S_TXRX  0x0000001C

#ifndef ASSEMBLER
typedef volatile struct
{
    PSC_SELECT psc;  //00,04
    uint32  cfg;  //08
    uint32  msk;  //0C
    uint32  pcr;  //10
    uint32  sts;  //14
    uint32  evnt;  //18
    uint32  txrx;  //1C
}
PSC_I2S;
#endif

#define PSC_I2S_CFG_MS   (1<<0)  // Master/Slafe
#define PSC_I2S_CFG_MLF   (1<<1)  // MSB/LSB first
#define PSC_I2S_CFG_LB   (1<<2)  // Loopback Mode
#define PSC_I2S_CFG_LEN   (0x1F<<4) // Length mask
#define PSC_I2S_CFG_LEN_N(n) ((n&0x1F)<<4) // Length 'n'
#define PSC_I2S_CFG_XM   (1<<9)  // Transfer Mode
#define PSC_I2S_CFG_MLJ   (1<<10)  // MSB/LSB Justified
#define PSC_I2S_CFG_BUF   (1<<11)  // L/R Channel Buffer
#define PSC_I2S_CFG_BI   (1<<12)  // Bit clock invert
#define PSC_I2S_CFG_BDIV    (0x3<<13) // Bit Clock Divider
#define PSC_I2S_CFG_BDIV_N(n) ((n&0x3)<<13)
#define PSC_I2S_CFG_WI   (1<<15)  // Word Strobe Invert
#define PSC_I2S_CFG_WS   (1<<16)  // Word Strobe
#define PSC_I2S_CFG_WS_N(n)  ((n&0xFF)<<16)
#define PSC_I2S_CFG_DE   (1<<26)  // Device Enable
#define PSC_I2S_CFG_TBS   (0x3<<28) // TX Burst Size
#define PSC_I2S_CFG_TBS_N(n) ((n&0x3)<<28)
#define PSC_I2S_CFG_RBS   (0x3<<30) // Rx Burst Size
#define PSC_I2S_CFG_RBS_N(n) ((n&0x3)<<30)

#define PSC_I2S_MSK_TD   (1<<4)  // Tx Done
#define PSC_I2S_MSK_RD   (1<<5)  // Rx Done
#define PSC_I2S_MSK_TU   (1<<8)  // TX Fifo underflow
#define PSC_I2S_MSK_TO   (1<<9)  // TX fifo overflow
#define PSC_I2S_MSK_TR   (1<<10)  // TX Fifo request
#define PSC_I2S_MSK_RU   (1<<11)  // RX Fifo underflow
#define PSC_I2S_MSK_RO   (1<<12)  // RX fifo overflow
#define PSC_I2S_MSK_RR   (1<<13)  // RX Fifo request

#define PSC_I2S_PCR_TS   (1<<0)  // Tx start
#define PSC_I2S_PCR_TP   (1<<1)  // Tx Stop
#define PSC_I2S_PCR_TC   (1<<2)  // Tx Data Clear
#define PSC_I2S_PCR_RS   (1<<4)  // Rx Start
#define PSC_I2S_PCR_RP   (1<<5)  // Rx Stop
#define PSC_I2S_PCR_RC   (1<<6)  // Rx Data Clear

// Status Register is Read Only //
#define PSC_I2S_STS_SR   (1<<0)  // PSC Ready
#define PSC_I2S_STS_DR   (1<<1)   // Device Ready
#define PSC_I2S_STS_DI   (1<<2)  // Device INterrupt
#define PSC_I2S_STS_TB   (1<<4)  // Tx BUsy
#define PSC_I2S_STS_RB   (1<<5)  // Rx Busy
#define PSC_I2S_STS_TR   (1<<8)  // Tx Rrequest
#define PSC_I2S_STS_TE   (1<<9)  // Tx Fifo Empty
#define PSC_I2S_STS_TF   (1<<10)  // Tx Fifo Full
#define PSC_I2S_STS_RR   (1<<11)  // Rx Rrequest
#define PSC_I2S_STS_RE   (1<<12)  // Rx Fifo Empty
#define PSC_I2S_STS_RF   (1<<13)  // Rx Fifo Full

#define PSC_I2S_EVNT_TD   (1<<4)  // Tx Done
#define PSC_I2S_EVNT_RD   (1<<5)  // Rx Done
#define PSC_I2S_EVNT_TU   (1<<8)  // TX Fifo underflow
#define PSC_I2S_EVNT_TO   (1<<9)  // TX fifo overflow
#define PSC_I2S_EVNT_TR   (1<<10)  // TX Fifo request
#define PSC_I2S_EVNT_RU   (1<<11)  // RX Fifo underflow
#define PSC_I2S_EVNT_RO   (1<<12)  // RX fifo overflow
#define PSC_I2S_EVNT_RR   (1<<13)  // RX Fifo request

#define PSC_I2S_TXRX_DATA  (0xFFFFFF<<0) // Data
#define PSC_I2S_TXRX_DATA_N(n) ((n&0xFFFFFF)<<0)

/*
################################################################################################
#####                         AC97 Register Definitions                                    #####
################################################################################################
*/

#define PSC_AC97_SEL   PSC_SEL
#define PSC_AC97_CTL   PSC_CTL
#define PSC_AC97_CFG   0x00000008
#define PSC_AC97_MSK   0x0000000C
#define PSC_AC97_PCR   0x00000010
#define PSC_AC97_STS   0x00000014
#define PSC_AC97_EVNT   0x00000018
#define PSC_AC97_TXRX   0x0000001C
#define PSC_AC97_CDC  0x00000020
#define PSC_AC97_RST  0x00000024
#define PSC_AC97_GPO  0x00000028
#define PSC_AC97_GPI  0x0000002C

#ifndef ASSEMBLER
typedef volatile struct
{
    PSC_SELECT psc;  //00,04
    uint32  cfg;  //08
    uint32  msk;  //0C
    uint32  pcr;  //10
    uint32  sts;  //14
    uint32  evnt;  //18
    uint32  txrx;  //1C
    uint32  cdc;  //20
    uint32  rst;  //24
    uint32  gpo;  //28
    uint32  gpi;  //2C
}
PSC_AC97;
#endif

#define PSC_AC97_CFG_GE   (1<<0)  // GPIO Register Enable
#define PSC_AC97_CFG_RXSLOT  (0x3FF<<1) // Valid Rx slots
#define PSC_AC97_CFG_RXSLOT_N(n) ((n&0x3FF)<<1)
#define PSC_AC97_CFG_TXSLOT  (0x3FF<<11) // Valid Tx slots
#define PSC_AC97_CFG_TXSLOT_N(n) ((n&0x3FF)<<11)
#define PSC_AC97_CFG_LEN  (0x1F<<21) // Data Length
#define PSC_AC97_CFG_LEN_N(n) ((n&0x1F)<<21)
#define PSC_AC97_CFG_DE   (1<<26)  // Device Enable
#define PSC_AC97_CFG_DD   (1<<27)  // DMA Disable
#define PSC_AC97_CFG_TRD    (0x3<<28) // TX Request Depth
#define PSC_AC97_CFG_TRD_N(n) ((n&0x3)<<28)
#define PSC_AC97_CFG_RRD    (0x3<<30) // Rx Request Depth
#define PSC_AC97_CFG_RRD_N(n) ((n&0x3)<<30)

#define PSC_AC97_MSK_TD   (1<<4)  // Tx Done
#define PSC_AC97_MSK_RD   (1<<5)  // Rx Done
#define PSC_AC97_MSK_TU   (1<<8)  // TX Fifo underflow
#define PSC_AC97_MSK_TO   (1<<9)  // TX fifo overflow
#define PSC_AC97_MSK_TR   (1<<10)  // TX Fifo request
#define PSC_AC97_MSK_RU   (1<<11)  // RX Fifo underflow
#define PSC_AC97_MSK_RO   (1<<12)  // RX fifo overflow
#define PSC_AC97_MSK_RR   (1<<13)  // RX Fifo request
#define PSC_AC97_MSK_CD   (1<<24)  // CODEC Command done
#define PSC_AC97_MSK_GR   (1<<25)  // GPI Data Ready Interrupt

#define PSC_AC97_PCR_TS   (1<<0)  // Tx start
#define PSC_AC97_PCR_TP   (1<<1)  // Tx Stop
#define PSC_AC97_PCR_TC   (1<<2)  // Tx Data Clear
#define PSC_AC97_PCR_RS   (1<<4)  // Rx Start
#define PSC_AC97_PCR_RP   (1<<5)  // Rx Stop
#define PSC_AC97_PCR_RC   (1<<6)  // Rx Data Clear

// Status Register is Read Only //
#define PSC_AC97_STS_SR   (1<<0)  // PSC Ready
#define PSC_AC97_STS_DR   (1<<1)   // Device Ready
#define PSC_AC97_STS_DI   (1<<2)  // Device INterrupt
#define PSC_AC97_STS_TB   (1<<4)  // Tx BUsy
#define PSC_AC97_STS_RB   (1<<5)  // Rx Busy
#define PSC_AC97_STS_TR   (1<<8)  // Tx Rrequest
#define PSC_AC97_STS_TE   (1<<9)  // Tx Fifo Empty
#define PSC_AC97_STS_TF   (1<<10)  // Tx Fifo Full
#define PSC_AC97_STS_RR   (1<<11)  // Rx Rrequest
#define PSC_AC97_STS_RE   (1<<12)  // Rx Fifo Empty
#define PSC_AC97_STS_RF   (1<<13)  // Rx Fifo Full
#define PSC_AC97_STS_CR   (1<<24)  // Codec ready
#define PSC_AC97_STS_CP   (1<<25)  // Command Pending
#define PSC_AC97_STS_CB   (1<<26)  // Codec Bit Clock detected

#define PSC_AC97_EVNT_TD     (1<<4)  // Tx Done
#define PSC_AC97_EVNT_RD     (1<<5)  // Rx Done
#define PSC_AC97_EVNT_TU     (1<<8)  // TX Fifo underflow
#define PSC_AC97_EVNT_TO     (1<<9)  // TX fifo overflow
#define PSC_AC97_EVNT_TR     (1<<10)  // TX Fifo request
#define PSC_AC97_EVNT_RU     (1<<11)  // RX Fifo underflow
#define PSC_AC97_EVNT_RO     (1<<12)  // RX fifo overflow
#define PSC_AC97_EVNT_RR     (1<<13)  // RX Fifo request
#define PSC_AC97_EVNT_CD     (1<<24)  // CODEC Command done
#define PSC_AC97_EVNT_GR     (1<<25)  // GPI Data Ready Interrupt

#define PSC_AC97_TXRX_DATA  (0xFFFFF<<0) // Data
#define PSC_AC97_TXRX_DATA_N(n) ((n&0xFFFFF)<<0)

#define PSC_AC97_CDC_DATA  (0xFFFF<<0) // data
#define PSC_AC97_CDC_DATA_N(n)  ((n&0xFFFF)<<0)
#define PSC_AC97_CDC_INDX  (0x7F<<16) // register index
#define PSC_AC97_CDC_INDX_N(n)  ((n&0x7F)<<16)
#define PSC_AC97_CDC_ID   (0x3<<23) // 2bit id for codec
#define PSC_AC97_CDC_ID_N(n)  ((n&0x3)<<23)
#define PSC_AC97_CDC_RD   (1<<25)  // Codec Read/Write

#define PSC_AC97_RST_SNC  (1<<0)  // Sync signal control
#define PSC_AC97_RST_RST  (1<<1)  // AC link reset

#define PSC_AC97_GPO_DATA  (0xFFFFF<<0)
#define PSC_AC97_GPO_DATA_N(n) ((n&0xFFFFF)<<0)

#define PSC_AC97_GPI_DATA  (0xFFFFF<<0)
#define PSC_AC97_GPI_DATA_N(n) ((n&0xFFFFF)<<0)


/*
################################################################################################
#####                        SMBus Register Definitions                                    #####
################################################################################################
*/

#define PSC_SMB_SEL    PSC_SEL
#define PSC_SMB_CTL    PSC_CTL
#define PSC_SMB_CFG    0x00000008
#define PSC_SMB_MSK    0x0000000C
#define PSC_SMB_PCR    0x00000010
#define PSC_SMB_STS    0x00000014
#define PSC_SMB_EVNT   0x00000018
#define PSC_SMB_TXRX   0x0000001C
#define PSC_SMB_TMR   0x00000030

#ifndef ASSEMBLER
typedef volatile struct
{
    PSC_SELECT psc;  //00,04
    uint32  cfg;  //08
    uint32  msk;  //0C
    uint32  pcr;  //10
    uint32  sts;  //14
    uint32  evnt;  //18
    uint32  txrx;  //1C
    uint32  tmr;  //20
}
PSC_SMB;
#endif

#define PSC_SMB_CFG_SLV   (0x7F<<4) // Slave Address
#define PSC_SMB_CFG_SLV_N(n) ((n&0x7F)<<1)
#define PSC_SMB_CFG_SFM   (1<<8)  // Standard or Fast Mode
#define PSC_SMB_CFG_CGE   (1<<9)  // General Call Enable
#define PSC_SMB_CFG_SDIV  (0x3<<13) // Clock Divider
#define PSC_SMB_CFG_SDIV_N(n) ((n&0x3)<<13)
#define PSC_SMB_CFG_DE   (1<<26)  // Device Enable
#define PSC_SMB_CFG_DD   (1<<27)  // DMA Disable
#define PSC_SMB_CFG_TRD   (0x3<<28) // TX Request Depth
#define PSC_SMB_CFG_TRD_N(n) ((n&0x3)<<28)
#define PSC_SMB_CFG_RRD   (0x3<<30) // Rx Request Depth
#define PSC_SMB_CFG_RRD_N(n) ((n&0x3)<<30)


#define PSC_SMB_MSK_MD   (1<<4)  // Master Done
#define PSC_SMB_MSK_SD   (1<<5)  // Slave done
#define PSC_SMB_MSK_TU   (1<<8)  // TX Fifo underflow
#define PSC_SMB_MSK_TO   (1<<9)  // TX fifo overflow
#define PSC_SMB_MSK_TR   (1<<10)  // TX fifo request
#define PSC_SMB_MSK_RU   (1<<11)  // RX Fifo underflow
#define PSC_SMB_MSK_RO   (1<<12)  // RX fifo overflow
#define PSC_SMB_MSK_RR   (1<<13)  // RX fifo request
#define PSC_SMB_MSK_MM   (1<<16)  // Multiple Master Error FIXME!! this bit does not exist!!! kcn
#define PSC_SMB_MSK_AL   (1<<28)  // Arbitration Lost (MasterOnly)
#define PSC_SMB_MSK_AN   (1<<29)  // Address not ack'd
#define PSC_SMB_MSK_DN   (1<<30)  // Data nont ack'd

#define PSC_SMB_PCR_MS   (1<<0)  // Master Start
#define PSC_SMB_PCR_DC   (1<<2)  // Tx Data Clear

// Status Register is Read Only //
#define PSC_SMB_STS_SR   (1<<0)  // PSC Ready
#define PSC_SMB_STS_DR   (1<<1)   // Device Ready
#define PSC_SMB_STS_DI   (1<<2)  // Device INterrupt
#define PSC_SMB_STS_MB   (1<<4)  // Master BUsy
#define PSC_SMB_STS_SB   (1<<5)  // Slave Busy
#define PSC_SMB_STS_TR   (1<<8)   // Tx Rrequest
#define PSC_SMB_STS_TE   (1<<9)  // Tx Fifo Empty
#define PSC_SMB_STS_TF   (1<<10)  // Tx Fifo Full
#define PSC_SMB_STS_RR   (1<<11)  // Rx Rrequest
#define PSC_SMB_STS_RE   (1<<12)  // Rx Fifo Empty
#define PSC_SMB_STS_RF   (1<<13)  // Rx Fifo Full
#define PSC_SMB_STS_BB   (1<<28)  // Bus Busy

#define PSC_SMB_EVNT_MD   (1<<4)  // Master Done
#define PSC_SMB_EVNT_SD   (1<<5)  // Slave done
#define PSC_SMB_EVNT_TU   (1<<8)  // TX Fifo underflow
#define PSC_SMB_EVNT_TO   (1<<9)  // TX fifo overflow
#define PSC_SMB_EVNT_RU   (1<<11)  // RX Fifo underflow
#define PSC_SMB_EVNT_RO   (1<<12)  // RX fifo overflow
#define PSC_SMB_EVNT_MM   (1<<16)  // Multiple Master Error
#define PSC_SMB_EVNT_AL   (1<<28)  // Arbitration Lost (MasterOnly)
#define PSC_SMB_EVNT_AN   (1<<29)  // Address not ack'd
#define PSC_SMB_EVNT_DN   (1<<30)  // Data nont ack'd

#define PSC_SMB_TXRX_AD   (0xFF<<0) // Addr/Data
#define PSC_SMB_TXRX_AD_N(n) ((n&0xFF)<<0)
#define PSC_SMB_TXRX_STP  (1<<29)  // Stop
#define PSC_SMB_TXRX_RSR  (1<<28)  // Restart

#define PSC_SMB_TMR_CH   (0x1F<<0) // Clock High
#define PSC_SMB_TMR_CH_N(n)  ((n&0x1F)<<0)
#define PSC_SMB_TMR_CL   (0x1F<<5) // Clock Low
#define PSC_SMB_TMR_CL_N(n)  ((n&0x1F)<<5)
#define PSC_SMB_TMR_SU   (0x1F<<10) // Start Setup
#define PSC_SMB_TMR_SU_N(n)  ((n&0x1F)<<10)
#define PSC_SMB_TMR_SH   (0x1F<<15) // Start Hold
#define PSC_SMB_TMR_SH_N(n)  ((n&0x1F)<<15)
#define PSC_SMB_TMR_PU   (0x1F<<20) // Stop Setup
#define PSC_SMB_TMR_PU_N(n)  ((n&0x1F)<<20)
#define PSC_SMB_TMR_PS   (0x1F<<25) // Stop Start Buffer
#define PSC_SMB_TMR_PS_N(n)  ((n&0x1F)<<25)
#define PSC_SMB_TMR_TH   (0x3<<30) // Transmit Hold
#define PSC_SMB_TMR_TH_N(n)  ((n&0x3)<<30)

/***********************************************************************/
/*
 * LCD controller
 */
#ifndef ASSEMBLER
typedef volatile struct
{
    uint32 reserved0;
    uint32 screen;
    uint32 backcolor;
    uint32 horztiming;
    uint32 verttiming;
    uint32 clkcontrol;
    uint32 pwmdiv;
    uint32 pwmhi;
    uint32 reserved1;
    uint32 winenable;
    uint32 colorkey;
    uint32 colorkeymsk;
    struct
    {
        uint32 cursorctrl;
        uint32 cursorpos;
        uint32 cursorcolor0;
        uint32 cursorcolor1;
        uint32 cursorcolor2;
        uint32 cursorcolor3;
    }
    hwc;
    uint32 intstatus;
    uint32 intenable;
    uint32 outmask;
    uint32 fifoctrl;
    uint32 reserved2[(0x0100-0x0058)/4];
    struct
    {
        uint32 winctrl0;
        uint32 winctrl1;
        uint32 winctrl2;
        uint32 winbuf0;
        uint32 winbuf1;
        uint32 winbufctrl;
        uint32 winreserved0;
        uint32 winreserved1;
    }
    window[4];

    uint32 reserved3[(0x0400-0x0180)/4];

    uint32 palette[(0x0800-0x0400)/4];

    uint32 cursorpattern[(0x0900-0x0800)/4];

}
AU1200_LCD;
#endif

/* lcd_screen */
#define LCD_SCREEN_SEN  (1<<31)
#define LCD_SCREEN_SX  (0x07FF<<19)
#define LCD_SCREEN_SY  (0x07FF<< 8)
#define LCD_SCREEN_SWP  (1<<7)
#define LCD_SCREEN_SWD  (1<<6)
#define LCD_SCREEN_ST  (7<<0)
#define LCD_SCREEN_ST_TFT (0<<0)
#define LCD_SCREEN_SX_N(WIDTH) ((WIDTH-1)<<19)
#define LCD_SCREEN_SY_N(HEIGHT) ((HEIGHT-1)<<8)
#define LCD_SCREEN_ST_CSTN (1<<0)
#define LCD_SCREEN_ST_CDSTN (2<<0)
#define LCD_SCREEN_ST_M8STN (3<<0)
#define LCD_SCREEN_ST_M4STN (4<<0)

/* lcd_backcolor */
#define LCD_BACKCOLOR_SBGR  (0xFF<<16)
#define LCD_BACKCOLOR_SBGG  (0xFF<<8)
#define LCD_BACKCOLOR_SBGB  (0xFF<<0)
#define LCD_BACKCOLOR_SBGR_N(N) ((N)<<16)
#define LCD_BACKCOLOR_SBGG_N(N) ((N)<<8)
#define LCD_BACKCOLOR_SBGB_N(N) ((N)<<0)

/* lcd_winenable */
#define LCD_WINENABLE_WEN3  (1<<3)
#define LCD_WINENABLE_WEN2  (1<<2)
#define LCD_WINENABLE_WEN1  (1<<1)
#define LCD_WINENABLE_WEN0  (1<<0)
#define LCD_WINENABLE_N(N)  (1<<N)

/* lcd_colorkey */
#define LCD_COLORKEY_CKR  (0xFF<<16)
#define LCD_COLORKEY_CKG  (0xFF<<8)
#define LCD_COLORKEY_CKB  (0xFF<<0)
#define LCD_COLORKEY_CKR_N(N) ((N)<<16)
#define LCD_COLORKEY_CKG_N(N) ((N)<<8)
#define LCD_COLORKEY_CKB_N(N) ((N)<<0)

/* lcd_colorkeymsk */
#define LCD_COLORKEYMSK_CKMR  (0xFF<<16)
#define LCD_COLORKEYMSK_CKMG  (0xFF<<8)
#define LCD_COLORKEYMSK_CKMB  (0xFF<<0)
#define LCD_COLORKEYMSK_CKMR_N(N) ((N)<<16)
#define LCD_COLORKEYMSK_CKMG_N(N) ((N)<<8)
#define LCD_COLORKEYMSK_CKMB_N(N) ((N)<<0)

/* lcd windows control 0 */
#define LCD_WINCTRL0_OX  (0x07FF<<21)
#define LCD_WINCTRL0_OY  (0x07FF<<10)
#define LCD_WINCTRL0_A  (0x00FF<<2)
#define LCD_WINCTRL0_AEN (1<<1)
#define LCD_WINCTRL0_OX_N(N) ((N)<<21)
#define LCD_WINCTRL0_OY_N(N) ((N)<<10)
#define LCD_WINCTRL0_A_N(N) ((N)<<2)

/* lcd windows control 1 */
#define LCD_WINCTRL1_PRI (3<<30)
#define LCD_WINCTRL1_PIPE (1<<29)
#define LCD_WINCTRL1_FRM (0xF<<25)
#define LCD_WINCTRL1_CCO (1<<24)
#define LCD_WINCTRL1_PO  (3<<22)
#define LCD_WINCTRL1_SZX (0x07FF<<11)
#define LCD_WINCTRL1_SZY (0x07FF<<0)
#define LCD_WINCTRL1_FRM_1BPP (0<<25)
#define LCD_WINCTRL1_FRM_2BPP (1<<25)
#define LCD_WINCTRL1_FRM_4BPP (2<<25)
#define LCD_WINCTRL1_FRM_8BPP (3<<25)
#define LCD_WINCTRL1_FRM_12BPP (4<<25)
#define LCD_WINCTRL1_FRM_16BPP655 (5<<25)
#define LCD_WINCTRL1_FRM_16BPP565 (6<<25)
#define LCD_WINCTRL1_FRM_16BPP556 (7<<25)
#define LCD_WINCTRL1_FRM_16BPPI1555 (8<<25)
#define LCD_WINCTRL1_FRM_16BPPI5551 (9<<25)
#define LCD_WINCTRL1_FRM_16BPPA1555 (10<<25)
#define LCD_WINCTRL1_FRM_16BPPA5551 (11<<25)
#define LCD_WINCTRL1_FRM_24BPP  (12<<25)
#define LCD_WINCTRL1_FRM_32BPP  (13<<25)
#define LCD_WINCTRL1_FRM_N(N) (N<<25)
#define LCD_WINCTRL1_SZX_N(N) ((N-1)<<11)
#define LCD_WINCTRL1_SZY_N(N) ((N-1)<<0)
#define LCD_WINCTRL1_PRI_N(N) ((N)<<30)
#define LCD_WINCTRL1_PRI_U(N) (((N)>>30)&0x3)
#define LCD_WINCTRL1_PO_00    (0<<22)
#define LCD_WINCTRL1_PO_01    (1<<22)
#define LCD_WINCTRL1_PO_10    (2<<22)
#define LCD_WINCTRL1_PO_11    (3<<22)
#define LCD_WINCTRL1_PO_N(N) (N<<22)

/* lcd windows control 2 */
#define LCD_WINCTRL2_CKMODE  (3<<24)
#define LCD_WINCTRL2_DBM  (1<<23)
#define LCD_WINCTRL2_RAM  (3<<21)
#define LCD_WINCTRL2_BX   (0x1FFF<<8)
#define LCD_WINCTRL2_SCX  (0xF<<4)
#define LCD_WINCTRL2_SCY  (0xF<<0)
#define LCD_WINCTRL2_RAM_NONE  (0<<21)
#define LCD_WINCTRL2_RAM_PALETTE (1<<21)
#define LCD_WINCTRL2_RAM_GAMMA  (2<<21)
#define LCD_WINCTRL2_RAM_BUFFER  (3<<21)
#define LCD_WINCTRL2_RAM_N(N)  (N<<21)
#define LCD_WINCTRL2_CKMODE_00                (0<<24)
#define LCD_WINCTRL2_CKMODE_01                (1<<24)
#define LCD_WINCTRL2_CKMODE_10                (2<<24)
#define LCD_WINCTRL2_CKMODE_11                (3<<24)
#define LCD_WINCTRL2_CKMODE_N(N) (N<<24)
#define LCD_WINCTRL2_BX_N(N)  ((N)<<8)
#define LCD_WINCTRL2_SCX_1    (0<<4)
#define LCD_WINCTRL2_SCX_2    (1<<4)
#define LCD_WINCTRL2_SCX_4    (2<<4)
#define LCD_WINCTRL2_SCX_N(N) (N<<4)
#define LCD_WINCTRL2_SCY_1    (0<<0)
#define LCD_WINCTRL2_SCY_2    (1<<0)
#define LCD_WINCTRL2_SCY_4    (2<<0)
#define LCD_WINCTRL2_SCY_N(N) (N<<0)

/* lcd windows buffer control */
#define LCD_WINBUFCTRL_DB  (1<<1)
#define LCD_WINBUFCTRL_DBN  (1<<0)

/* lcd_intstatus, lcd_intenable */
#define LCD_INT_IFO    (0xF<<14)
#define LCD_INT_IFU    (0xF<<10)
#define LCD_INT_IFU0   (1<<10)
#define LCD_INT_IFU1   (1<<11)
#define LCD_INT_IFU2   (1<<12)
#define LCD_INT_IFU3   (1<<13)
#define LCD_INT_OFO    (1<<9)
#define LCD_INT_OFU    (1<<8)
#define LCD_INT_WAIT   (1<<3)
#define LCD_INT_SD    (1<<2)
#define LCD_INT_SA    (1<<1)
#define LCD_INT_SS    (1<<0)

/* lcd_horztiming */
#define LCD_HORZTIMING_HND2  (0x1FF<<18)
#define LCD_HORZTIMING_HND1  (0x1FF<<9)
#define LCD_HORZTIMING_HPW  (0x1FF<<0)
#define LCD_HORZTIMING_HND2_N(N)(((N)-1)<<18)
#define LCD_HORZTIMING_HND1_N(N)(((N)-1)<<9)
#define LCD_HORZTIMING_HPW_N(N) (((N)-1)<<0)

/* lcd_verttiming */
#define LCD_VERTTIMING_VND2  (0x1FF<<18)
#define LCD_VERTTIMING_VND1  (0x1FF<<9)
#define LCD_VERTTIMING_VPW  (0x1FF<<0)
#define LCD_VERTTIMING_VND2_N(N)(((N)-1)<<18)
#define LCD_VERTTIMING_VND1_N(N)(((N)-1)<<9)
#define LCD_VERTTIMING_VPW_N(N) (((N)-1)<<0)

/* lcd_clkcontrol */
#define LCD_CLKCONTROL_EXT  (1<<22)
#define LCD_CLKCONTROL_DELAY (3<<20)
#define LCD_CLKCONTROL_CDD  (1<<19)
#define LCD_CLKCONTROL_IB  (1<<18)
#define LCD_CLKCONTROL_IC  (1<<17)
#define LCD_CLKCONTROL_IH  (1<<16)
#define LCD_CLKCONTROL_IV  (1<<15)
#define LCD_CLKCONTROL_BF  (0x1F<<10)
#define LCD_CLKCONTROL_PCD  (0x3FF<<0)
#define LCD_CLKCONTROL_BF_N(N) (((N)-1)<<10)
#define LCD_CLKCONTROL_PCD_N(N) ((N)<<0)

/* lcd_pwmdiv */
#define LCD_PWMDIV_EN   (1<<31)
#define LCD_PWMDIV_PWMDIV  (0x1FFFF<<0)
#define LCD_PWMDIV_PWMDIV_N(N) ((N)<<0)

/* lcd_pwmhi */
#define LCD_PWMHI_PWMHI1  (0xFFFF<<16)
#define LCD_PWMHI_PWMHI0  (0xFFFF<<0)
#define LCD_PWMHI_PWMHI1_N(N) ((N)<<16)
#define LCD_PWMHI_PWMHI0_N(N) ((N)<<0)

/* lcd_hwccon */
#define LCD_HWCCON_EN   (1<<0)

/* lcd_cursorpos */
#define LCD_CURSORPOS_HWCXOFF  (0x1F<<27)
#define LCD_CURSORPOS_HWCXPOS  (0x07FF<<16)
#define LCD_CURSORPOS_HWCYOFF  (0x1F<<11)
#define LCD_CURSORPOS_HWCYPOS  (0x07FF<<0)
#define LCD_CURSORPOS_HWCXOFF_N(N) ((N)<<27)
#define LCD_CURSORPOS_HWCXPOS_N(N) ((N)<<16)
#define LCD_CURSORPOS_HWCYOFF_N(N) ((N)<<11)
#define LCD_CURSORPOS_HWCYPOS_N(N) ((N)<<0)

/* lcd_cursorcolor */
#define LCD_CURSORCOLOR_HWCA  (0xFF<<24)
#define LCD_CURSORCOLOR_HWCR  (0xFF<<16)
#define LCD_CURSORCOLOR_HWCG  (0xFF<<8)
#define LCD_CURSORCOLOR_HWCB  (0xFF<<0)
#define LCD_CURSORCOLOR_HWCA_N(N) ((N)<<24)
#define LCD_CURSORCOLOR_HWCR_N(N) ((N)<<16)
#define LCD_CURSORCOLOR_HWCG_N(N) ((N)<<8)
#define LCD_CURSORCOLOR_HWCB_N(N) ((N)<<0)

/* lcd_fifoctrl */
#define LCD_FIFOCTRL_F3IF  (1<<29)
#define LCD_FIFOCTRL_F3REQ  (0x1F<<24)
#define LCD_FIFOCTRL_F2IF  (1<<29)
#define LCD_FIFOCTRL_F2REQ  (0x1F<<16)
#define LCD_FIFOCTRL_F1IF  (1<<29)
#define LCD_FIFOCTRL_F1REQ  (0x1F<<8)
#define LCD_FIFOCTRL_F0IF  (1<<29)
#define LCD_FIFOCTRL_F0REQ  (0x1F<<0)
#define LCD_FIFOCTRL_F3REQ_N(N) ((N-1)<<24)
#define LCD_FIFOCTRL_F2REQ_N(N) ((N-1)<<16)
#define LCD_FIFOCTRL_F1REQ_N(N) ((N-1)<<8)
#define LCD_FIFOCTRL_F0REQ_N(N) ((N-1)<<0)

/* lcd_outmask */
#define LCD_OUTMASK_MASK  (0x00FFFFFF)

/*
################################################################################################
#####                         AES Block Register Definitions                               #####
################################################################################################
*/
#define AES_STATUS                         0x0000
#define AES_INDATA                         0x0004
#define AES_OUTDATA                        0x0008
#define AES_INTCAUSE                       0x000C
#define AES_CONFIG                         0x0010

#ifndef ASSEMBLER
typedef volatile struct
{
    uint32         status;                /* 0x00 */
    uint32         indata;                /* 0x04 */
    uint32         outdata;               /* 0x08 */
    uint32         intcause;              /* 0x0C */
    uint32         config;                /* 0x10 */
}
AU1200_AES;
#endif


#define AES_STATUS_PS                (1<<0)                /* AES Process start/stop */
#define AES_STATUS_IE                (1<<1)                /* Interrupt Enable */
#define AES_STATUS_CR_N(n)           ((n&0x03)<<2)         /* clock ratio/divider */
#define AES_STATUS_OUT               (1<<4)                /* TX FIFO ready (at least 16 bytes) */
#define AES_STATUS_IN                (1<<5)                /* RX FIFO ready (at least 16 bytes) */

#define AES_INT_RDY                  (1<<0)                /* En/Decryption Completion */
#define AES_INT_OVR                  (1<<1)                /* Input data FIFO underflow */
#define AES_INT_UND                  (1<<2)                /* Output data FIFO overflow */

#define AES_CONFIG_ED                (1<<0)                /* En/Decryption Select */
#define AES_CONFIG_IKG               (1<<1)                /* Internal Key Generation */
#define AES_CONFIG_RPK               (1<<2)                /* Software Replay Key */
#define AES_CONFIG_RK                (1<<3)                /* Internal reuse key */
#define AES_CONFIG_UC                (1<<4)                /* Undefined block count */
#define AES_CONFIG_OP_N(n)           ((n&0x03)<<5)         /* Mode of operation */

/*
################################################################################################
#####                       CIM Block Register Definitions                                 #####
################################################################################################
*/

#define CIM_ENABLE    0x00000000
#define CIM_CONFIG       0x00000004
#define CIM_CAPTURE    0x00000010
#define CIM_STAT    0x00000014
#define CIM_INTEN    0x00000018
#define CIM_INSTAT    0x0000001C
#define CIM_FIFOA    0x00000020
#define CIM_FIFOB    0x00000040
#define CIM_FIFOC    0x00000060

#ifndef ASSEMBLER
typedef volatile struct
{
    uint32         enable;                /* 00 */
    uint32         config;                /* 04 */
    uint32         rsv0[2];
    uint32         capture;               /* 10 */
    uint32         stat;              /* 14 */
    uint32         inten;                 /* 18 */
    uint32         instat;                /* 1C */
    uint32         fifoa;                 /* 20 */
    uint32         reserved1[7];
    uint32         fifob;                 /* 40 */
    uint32         reserved2[7];
    uint32         fifoc;                 /* 60 */
}
AU1200_CIM;
#endif

#define   CIM_ENABLE_EN   (1<<0) /* enable/disable/reset the block*/

/* CIM Configuration Register */

#define   CIM_CONFIG_PM   (1<<0)
#define   CIM_CONFIG_CLK     (1<<1)
#define   CIM_CONFIG_LS   (1<<2)
#define   CIM_CONFIG_FS   (1<<3)
#define   CIM_CONFIG_DPS     (3<<6)
#define   CIM_CONFIG_DPS_N(n)   ((n&0x03)<<6)
#define   CIM_CONFIG_BAY  (3<<8)
#define   CIM_CONFIG_BAY_N(n)   ((n&0x03)<<8)
#define   CIM_CONFIG_LEN_N(n) ((n&0x0f)<<10)
#define   CIM_CONFIG_BYT  (1<<14)
#define   CIM_CONFIG_SF   (1<<15)
#define   CIM_CONFIG_FSEL  (3<<16)
#define   CIM_CONFIG_FS_N(n) ((n&0x03)<<16)
#define   CIM_CONFIG_SI   (1<<18)

/* CIM Capture Control Register */

#define CIM_CAPTURE_VCE   (1<<0)
#define CIM_CAPTURE_SCE   (1<<1)
#define CIM_CAPTURE_CLR   (1<<2)

/* CIM Status Register */

#define CIM_STATUS_VC   (1<<0)
#define CIM_STATUS_SC   (1<<1)
#define CIM_STATUS_AF   (1<<2)
#define CIM_STATUS_AE   (1<<3)
#define CIM_STATUS_AR   (1<<4)
#define CIM_STATUS_BF   (1<<5)
#define CIM_STATUS_BE   (1<<6)
#define CIM_STATUS_BR   (1<<7)
#define CIM_STATUS_CF   (1<<8)
#define CIM_STATUS_CE   (1<<9)
#define CIM_STATUS_CR   (1<<10)

/* Interrupt Status Rgister */

#define CIM_INSTAT_CD   (1<<0)
#define CIM_INSTAT_FD   (1<<1)
#define CIM_INSTAT_UFA   (1<<2)
#define CIM_INSTAT_OFA   (1<<3)
#define CIM_INSTAT_UFB   (1<<4)
#define CIM_INSTAT_OFB   (1<<5)
#define CIM_INSTAT_UFC   (1<<6)
#define CIM_INSTAT_OFC   (1<<7)
#define CIM_INSTAT_ERR   (1<<8)


/*********************************************************************************************
****                         Au13XX USB Register Definitions                              ****
*********************************************************************************************/
#if defined(SOC_AU13XX)

#if !defined(ASSEMBLER)
typedef volatile struct
{
    // setup registers
    uint32 dwc_ctrl1;			//0x0000
    uint32 dwc_ctrl2;			//0x0004
    uint32 reserved0[2];		//0x08 - 0x0C

    uint32 vbus_timer;			//0x0010
    uint32 sbus_ctrl;			//0x0014
    uint32 msr_err;				//0x0018
    uint32 dwc_ctrl3;           //0x001C

    uint32 dwc_ctrl4;           //0x0020
    uint32 reserved1;			//0x0024
    uint32 otg_status;			//0x0028
    uint32 dwc_ctrl5;			//0x002C

    uint32 dwc_ctrl6;			//0x0030
    uint32 dwc_ctrl7;			//0x0034

    uint32 reserved2[(0xC0-0x38)/4]; // 0x0038 -- 0x00C0

    uint32 phy_status;			//0x00C0
    uint32 intr_status;			//0x00C4
    uint32 intr_enable;			//0x00C8

} AU13XX_USB;
#endif // ASSEMBLER

#define	USB_DWC_CTRL1_OTGD				(1<<2)
#define	USB_DWC_CTRL1_HSTRS				(1<<1)
#define	USB_DWC_CTRL1_DCRS				(1<<0)

#define	USB_DWC_CTRL2_HTBSE1			(1<<11)
#define	USB_DWC_CTRL2_HTBSE0			(1<<10)
#define	USB_DWC_CTRL2_LTBSE1			(1<<9)
#define	USB_DWC_CTRL2_LTBSE0			(1<<8)
#define	USB_DWC_CTRL2_LPBKE1			(1<<5)
#define	USB_DWC_CTRL2_LPBKE0			(1<<4)
#define	USB_DWC_CTRL2_VBUSD				(1<<3)
#define	USB_DWC_CTRL2_PH1RS				(1<<2)
#define	USB_DWC_CTRL2_PHY0RS			(1<<1)
#define	USB_DWC_CTRL2_PHYRS				(1<<0)

#define USB_VBUS_TIMER(n)				(n)

#define	USB_SBUS_CTRL_SBCA				(1<<2)
#define	USB_SBUS_CTRL_HWSZ				(1<<1)
#define	USB_SBUS_CTRL_BSZ				(1<<0)

#define USB_MSR_ERR_ILLBM				(1<<18)
#define USB_MSR_ERR_ILLBRST				(1<<17)
#define USB_MSR_ERR_UADDRSTS			(1<<16)
#define USB_MSR_ERR_BMMSK				(1<<2)
#define USB_MSR_ERR_BRSTMSK				(1<<1)
#define USB_MSR_ERR_UADMK				(1<<0)

#define	USB_DWC_CTRL3_VATEST_EN			(1<<20)
#define	USB_DWC_CTRL3_OHC1_CLKEN		(1<<19)
#define	USB_DWC_CTRL3_OHC0_CLKEN		(1<<18)
#define	USB_DWC_CTRL3_EHC_CLKEN			(1<<17)
#define	USB_DWC_CTRL3_OTG_CLKEN			(1<<16)
#define	USB_DWC_CTRL3_OHCI_SUSP			(1<<3)
#define	USB_DWC_CTRL3_VBUS_VALID_PORT1	(1<<2)
#define	USB_DWC_CTRL3_VBUS_VALID_PORT0	(1<<1)
#define	USB_DWC_CTRL3_VBUS_VALID_SEL	(1<<0)

#define	USB_DWC_CTRL4_USB_MODE			(1<<16)
#define	USB_DWC_CTRL4_AHB_CLKDIV(n)		((n&0xF)<<0)

#define USB_OTG_STATUS_IDPULLUP			(1<<8)
#define USB_OTG_STATUS_IDDIG			(1<<7)
#define USB_OTG_STATUS_DISCHRGVBUS		(1<<6)
#define USB_OTG_STATUS_CHRGVBUS			(1<<5)
#define USB_OTG_STATUS_DRVVBUS			(1<<4)
#define USB_OTG_STATUS_SESSIONEND		(1<<3)
#define USB_OTG_STATUS_VBUSVALID		(1<<2)
#define USB_OTG_STATUS_BVALID			(1<<1)
#define USB_OTG_STATUS_AVALID			(1<<0)

#define	USB_DWC_CTRL5_REFCLK_DIV(n)		((n&3)<<18)
#define	USB_DWC_CTRL5_REFCLK_EN(n)		((n&3)<<16)
#define	USB_DWC_CTRL5_SIDDQ				(1<<1)
#define	USB_DWC_CTRL5_COMMONONN			(1<<0)

#define	USB_DWC_CTRL6_DMPULLDOWN_PORT1	(1<<3)
#define	USB_DWC_CTRL6_DPPULLDOWN_PORT1	(1<<2)
#define	USB_DWC_CTRL6_DMPULLDOWN_PORT2	(1<<1)
#define	USB_DWC_CTRL6_DPPULLDOWN_PORT2	(1<<0)

#define	USB_DWC_CTRL7_OHC_STARTCLK		(1<<0)

#define USB_PHY_STATUS_VBUS				(1<<0)

// Bit defines used for status and enable registers
#define USB_INTR_S2A					(1<<6)
#define USB_INTR_FORCE					(1<<5)
#define USB_INTR_PHY					(1<<4)
#define USB_INTR_DEVICE					(1<<3)
#define USB_INTR_EHCI					(1<<2)
#define USB_INTR_OHCI1					(1<<1)
#define USB_INTR_OHCI0					(1<<0)

#endif // defined(SOC_Au13XX)

/***********************************************************************/
/***********************************************************************/
/***********************************************************************/
/***********************************************************************/

/*
 * Physical base addresses for integrated peripherals
 */
#ifdef SOC_AU13XX
/*
 * System Bus
 */
#define	MEM_PHYS_ADDR			0x14000000
#define	STATIC_MEM_PHYS_ADDR	0x14001000
#define UDMA_PHYS_ADDR			0x14001800
#define	DDMA_PHYS_ADDR			0x14002000
#define CIM_PHYS_ADDR			0x14004000
#define MAE2BE_PHYS_ADDR 		0x14010000
#define MAEBE_PHYS_ADDR MAE2BE_PHYS_ADDR
#define MAE2MPE_PHYS_ADDR 		0x14014000
#define USB_PHYS_ADDR			0x14021000
#define OTG_PHYS_ADDR			0x14022000
#define OHC_PHYS_ADDR			0x14020400
#define OHC2_PHYS_ADDR			0x14020800
#define EHC_PHYS_ADDR			0x14020000
#define UDC_PHYS_ADDR			OHC2_PHYS_ADDR
#define MAE2BSA_PHYS_ADDR 		0x14030000
#define LCD_PHYS_ADDR			0x15000000

/*
 * Peripheral Bus
 */
#define ROM_PHYS_ADDR			0x10000000
#define OTP_PHYS_ADDR			0x10002000
#define VSS_PHYS_ADDR			0x11003000
#define SENSE_PHYS_ADDR			0x10003800
#define	UART0_PHYS_ADDR			0x10100000
#define	UART1_PHYS_ADDR			0x10101000
#define	UART2_PHYS_ADDR			0x10102000
#define	UART3_PHYS_ADDR			0x10103000
#define	GPINT_PHYS_ADDR			0x10200000
#define AES_PHYS_ADDR			0x10300000
#define MALI_PHYS_ADDR			0x10500000
#define SD0_PHYS_ADDR			0x10600000
#define SD1_PHYS_ADDR			0x10601000
#define SD2_PHYS_ADDR			0x10602000
#define	SYS_PHYS_ADDR			0x10900000
#define PSC0_PHYS_ADDR	 		0x10A00000
#define PSC1_PHYS_ADDR	 		0x10A01000
#define PSC2_PHYS_ADDR	 		0x10A02000
#define PSC3_PHYS_ADDR	 		0x10A03000

#define PCMCIA_IO_PHYS_ADDR   	0xF00000000
#define PCMCIA_ATTR_PHYS_ADDR 	0xF40000000
#define PCMCIA_MEM_PHYS_ADDR  	0xF80000000
#endif

#endif /* _AU1X00_H */

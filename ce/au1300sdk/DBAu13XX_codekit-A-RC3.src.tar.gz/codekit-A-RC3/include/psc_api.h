/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef __PSC_API_H_
#define __PSC_API_H_

#define PSC0     PSC0_PHYS_ADDR
#define PSC1     PSC1_PHYS_ADDR
#define PSC2     PSC2_PHYS_ADDR
#define PSC3     PSC3_PHYS_ADDR



static
inline void psc_config( uint32 psc, uint32 type )
{
    PSC_SELECT  *psc_sel = (PSC_SELECT*)KSEG1(psc);
    psc_sel->sel = type;
}

static
inline void psc_enable( uint32 psc, uint32 clk_src )
{
    PSC_SELECT  *psc_sel = (PSC_SELECT*)KSEG1(psc);
    PSC_SPI   *spi;

    psc_sel->ctl |= PSC_CTL_CE;
    asm(" sync");
    psc_sel->ctl |= PSC_CTL_EN;
    asm(" sync");

    // Going to cheat a little here -- since the device ready bit is the same for
    // all available PSC configurations -- I will just use SPI data structure to
    // poll for "device ready". NOTE -- not all the status bits are the same
    // for the different configurations
    spi = (PSC_SPI*)psc_sel;
    while ( !(spi->sts & PSC_SMB_STS_SR) )
        ;
    ;

}

static
inline void psc_disable( uint32 psc )
{
    PSC_SELECT  *psc_sel = (PSC_SELECT*)KSEG1(psc);
    psc_sel->ctl &= ~PSC_CTL_EN;
    asm(" sync");
    psc_sel->ctl &= ~PSC_CTL_CE;
    asm(" sync");
}
#endif // __PSC_API_H_

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef SD_H
#define SD_H

#include "example.h"
#include "ddma2.h"

#define SD_BLOCK_LENGTH   512

#define SD_GO_IDLE_STATE  0
#define SD_ALL_SEND_CID   2
#define SD_SEND_RELATIVE_ADDR  3
#define MMC_SET_RELATIVE_ADDR  3
#define SD_SET_DSR   4
#define SD_SELECT_DESELECT_CARD  7
#define MMC_SWITCH              6
#define SD_IF_COND  8
#define MMC_EXT_CSD  8
#define SD_CSD    9
#define SD_CID    10
#define SD_STOP_TRANSMISSION  12
#define SD_SEND_STATUS   13
#define SD_GO_INACTIVE_STATE  15
#define SD_SET_BLOCKLEN   16
#define SD_READ_SINGLE_BLOCK  17
#define SD_READ_MULTIPLE_BLOCK  18
#define SD_WRITE_BLOCK   24
#define SD_WRITE_MULTIPLE_BLOCK  25
#define SD_PROGRAM_CSD   27
#define SD_SET_WRITE_PROT  28
#define SD_CLR_WRITE_PROT  29
#define SD_SEND_WRITE_PROT  30
#define SD_ERASE_WR_BLK_START  32
#define SD_ERASE_WR_BLK_END  33
#define SD_ERASE   38
#define SD_LOCK_UNLOCK   42
#define SD_APP_CMD   55
#define SD_GEN_CMD   56

#define MMC_SEND_OP_COND  1

#define SD_APP_SET_BUS_WITH  6
#define SD_APP_STATUS   13
#define SD_APP_SEND_NUM_WR_BLOCKS 22
#define SD_APP_SET_WR_BLK_ERASE_COUNT 23
#define SD_APP_SEND_OP_COND  41
#define SD_APP_SET_CLR_CARD_DETECT 42
#define SD_APP_SEND_SCR   51

#define BUS_WIDTH_4   0x02
#define BUS_WIDTH_1   0x00
#define SD_BUS_WIDTHS_4BIT  (1<<2)
#define SD_BUS_WIDTHS_1BIT  (1<<0)

#define CSD_READ_BL_LEN(X)  (0x01 << ((X & 0x00000f00) >> 8))
#define CSD_READ_BL_PARTIAL(X)  ((X & 0x00000080) >> 7)
#define CSD_C_SIZE(X, Y)  (((X & 0x00000003) << 10) | ((Y & 0xffc00000) >> 22))
#define CSD_C_SIZE_MULT(X)  ((X & 0x00000380) >> 7)
#define CSD_WRITE_BL_LEN(X)  (0x01 << ((X & 0x0003c000) >> 14))
#define CSD_WRITE_BL_PARTIAL(X)  ((X & 0x00002000) >> 13)
#define CSD_VERSION(X)			 ((X&0x00C00000) >> 22)
#define CSD_MMC_SPEC_VERSION(X)      ((X&0x003c0000) >>	18)

#define SD_CARD_STATUS_CURRENT_STATE(n) ((n>>9)&0xF)
#define SD_CARD_STATE_PROGRAMMING 0x7
#define SD_CARD_STATE_TRAN  0x4


/*
 * OCR register definitions
 */
#define OCR_STATUS    (1<<31)
#define OCR_MMC_ACCESS_MODE (3<<29)
#define OCR_SD_ACCESS_MODE (1<<30)
#define OCR_35_36    (1<<23)
#define OCR_34_35    (1<<22)
#define OCR_33_34    (1<<21)
#define OCR_32_33    (1<<20)
#define OCR_31_32    (1<<19)
#define OCR_30_31    (1<<18)
#define OCR_29_30    (1<<17)
#define OCR_28_29    (1<<16)
#define OCR_27_28    (1<<15)
#define OCR_26_27    (1<<14)
#define OCR_25_26    (1<<13)
#define OCR_24_25    (1<<12)
#define OCR_23_24    (1<<11)
#define OCR_22_23    (1<<10)
#define OCR_21_22    (1<<9)
#define OCR_20_21    (1<<8)
#define OCR_19_20    (1<<7)
#define OCR_18_19    (1<<6)
#define OCR_17_18    (1<<5)
#define OCR_16_17    (1<<4)


/* Max clock frequency speced during initialization mode */
#define F_OD 250000

/* Max clock frequency speced during data transfers */
#define F_PP 25000000
#define HS_PP 50000000

typedef struct
{
    uint32 r3;
    uint32 r2;
    uint32 r1;
    uint32 r0;
}
SD_RESPONSE;

typedef enum
{
    DM_PIO,
    DM_DMA
} SD_DATA_MODE;

typedef enum
{
    CT_UNKNOWN,
    CT_SD,
    CT_MMC
} SD_CARD_TYPE;

typedef struct
{
    SD_CARD_TYPE card_type;
    SD_DATA_MODE data_mode;
    int cid;
    int rca;
    int csd;
    int scr;
    int bus_width;
	int spec_version;
    int rd_blk_len;
    int rd_blk_partial;
    int wr_blk_len;
    int wr_blk_partial;
    long long mem_capacity;
    int high_capacity;
#if defined(CONFIG_HWBLOCK_DDMA2)
	CHANNEL_ID id;
	DDMA_DESCRIPTOR* d;
#endif
}
SD_CARD_INFO;


#define R1 0x01
#define R2 0x02
#define R3 0x03
#define R4 0x04
#define R5 0x05
#define R6 0x06
#define R1b 0x81
#define R7 0x01

static
const
int sd_cmd_response[] =
{
    0,  //00
    0,  //01
    R2,  //02
    R6,  //03
    0,  //04
    0,  //05
    R1,  //06
    R1b, //07
    R7,  //08
    R2,  //09
    R2,  //10
    0,  //11
    R1b, //12
    R1,  //13
    0,  //14
    0,  //15
    R1,  //16
    R1,  //17
    R1,  //18
    0,  //19
    0,  //20
    0,  //21
    0,  //22
    0,  //23
    R1,  //24
    R1,  //25
    0,  //26
    R1,  //27
    R1b, //28
    R1b, //29
    R1,  //30
    0,  //31
    R1,  //32
    R1,  //33
    0,  //34
    0,  //35
    0,  //36
    0,  //37
    R1b, //38
    0,  //39
    0,  //40
    0,  //41
    R1,  //42
    0,  //43
    0,  //44
    0,  //45
    0,  //46
    0,  //47
    0,  //48
    0,  //49
    0,  //50
    0,  //51
    0,  //52
    0,  //53
    0,  //54
    R1,  //55
    R1,  //56
    0,  //57
    0,  //58
    0,  //59
    0,  //60
    0,  //61
    0,  //62
    0  //63
};

static
const
int sd_app_response[] =
{
    0,  //00
    0,  //01
    0,  //02
    0,  //03
    0,  //04
    0,  //05
    R1,  //06
    0,  //07
    0,  //08
    0,  //09
    0,  //10
    0,  //11
    0,  //12
    R1,  //13
    0,  //14
    0,  //15
    0,  //16
    0,  //17
    0,  //18
    0,  //19
    0,  //20
    0,  //21
    R1,  //22
    R1,  //23
    0,  //24
    0,  //25
    0,  //26
    0,  //27
    0,  //28
    0,  //29
    0,  //30
    0,  //31
    0,  //32
    0,  //33
    0,  //34
    0,  //35
    0,  //36
    0,  //37
    0,  //38
    0,  //39
    0,  //40
    R3,  //41
    R1,  //42
    0,  //43
    0,  //44
    0,  //45
    0,  //46
    0,  //47
    0,  //48
    0,  //49
    0,  //50
    R1,  //51
};

static
const
int mmc_cmd_response[] =
{
    0,  //00
    R3,  //01
    R2,  //02
    R1,  //03
    0,  //04
    0,  //05
    R1b,  //06
    R1b, //07
    R1,  //08
    R2,  //09
    R2,  //10
    R1,  //11
    R1b, //12
    R1,  //13
    0,  //14
    0,  //15
    R1,  //16
    R1,  //17
    R1,  //18
    0,  //19
    R1,  //20
    0,  //21
    0,  //22
    R1,  //23
    R1,  //24
    R1,  //25
    R1,  //26
    R1,  //27
    R1b, //28
    R1b, //29
    R1,  //30
    0,  //31
    0,  //32
    0,  //33
    0,  //34
    R1,  //35
    R1,  //36
    0,  //37
    R1b, //38
    R4,  //39
    R5,  //40
    0,  //41
    R1b, //42
    0,  //43
    0,  //44
    0,  //45
    0,  //46
    0,  //47
    0,  //48
    0,  //49
    0,  //50
    0,  //51
    0,  //52
    0,  //53
    0,  //54
    R1,  //55
    R1b, //56
    0,  //57
    0,  //58
    0,  //59
    0,  //60
    0,  //61
    R1b,//62
    0  //63
};

static
const
int sd_cmd_type[] =
{
    0,  //00
    0,  //01
    0,  //02
    0,  //03
    0,  //04
    0,  //05
    2,  //06
    0,  //07
    0,  //08
    0,  //09
    0,  //10
    0,  //11
    7,  //12
    0,  //13
    0,  //14
    0,  //15
    0,  //16
    2,  //17
    4,  //18
    0,  //19
    0,  //20
    0,  //21
    0,  //22
    0,  //23
    1,  //24
    3,  //25
    0,  //26
    0,  //27
    0,  //28
    0,  //29
    0,  //30
    0,  //31
    0,  //32
    0,  //33
    0,  //34
    0,  //35
    0,  //36
    0,  //37
    0,  //38
    0,  //39
    0,  //40
    0,  //41
    0,  //42
    0,  //43
    0,  //44
    0,  //45
    0,  //46
    0,  //47
    0,  //48
    0,  //49
    0,  //50
    0,  //51
    0,  //52
    0,  //53
    0,  //54
    0,  //55
    0,  //56
    0,  //57
    0,  //58
    0,  //59
    0,  //60
    0,  //61
    0,  //62
    0  //63
};

static
const
int sd_app_type[] =
{
    0,  //00
    0,  //01
    0,  //02
    0,  //03
    0,  //04
    0,  //05
    0,  //06
    0,  //07
    0,  //08
    0,  //09
    0,  //10
    0,  //11
    0,  //12
    0,  //13
    0,  //14
    0,  //15
    0,  //16
    0,  //17
    0,  //18
    0,  //19
    0,  //20
    0,  //21
    0,  //22
    0,  //23
    0,  //24
    0,  //25
    0,  //26
    0,  //27
    0,  //28
    0,  //29
    0,  //30
    0,  //31
    0,  //32
    0,  //33
    0,  //34
    0,  //35
    0,  //36
    0,  //37
    0,  //38
    0,  //39
    0,  //40
    0,  //41
    0,  //42
    0,  //43
    0,  //44
    0,  //45
    0,  //46
    0,  //47
    0,  //48
    0,  //49
    0,  //50
    2,  //51
};

// Extended CSD Boot Operation byte positions
#define ECSD_BOOT_INFO             228
#define ECSD_BOOT_SIZE_MULTI       226
#define ECSD_BOOT_CONFIG_BYTE      179
#define ECSD_BOOT_BUS_WIDTH_BYTE   177

// Set this macro to 1 to enable full eMMC boot operation
// functionality.  This includes functions
// to enable/disable boot acknowledge and enable/disable
// booting directly and automatically, without first
// initializing the device, from a specific partition.
// With this macro disabled, the current implementation
// can still enable boot operation for a device, create boot
// partitions, and read/write to those partitions.
// However, during boot up, the device must first be
// intialized before attempting to read from the device.
#define EMMC_FULL_BOOT_OPERATION 1

// ECSD BOOT_CONFIG field bits
#define BOOT_PARTITION_ACCESS_OFFSET 0
#define BOOT_PARTITION_ENABLE_OFFSET 3
#define BOOT_ACK_OFFSET              6

#define BOOT_PARTITION_ACCESS_MASK   (0x7 << BOOT_PARTITION_ACCESS_OFFSET)
#define BOOT_PARTITION_ENABLE_MASK   (0x7 << BOOT_PARTITION_ENABLE_OFFSET)
#define BOOT_ACK_MASK                (0x1 << BOOT_ACK_OFFSET)

// Switch (CMD6) argument offsets
#define CMD6_ACCESS_OFFSET 24
#define CMD6_INDEX_OFFSET  16
#define CMD6_VALUE_OFFSET  8

// Switch (CMD6) Access field values
#define CMD6_ACCESS_CMD_SET    (0 << CMD6_ACCESS_OFFSET)
#define CMD6_ACCESS_SET_BITS   (1 << CMD6_ACCESS_OFFSET)
#define CMD6_ACCESS_CLEAR_BITS (2 << CMD6_ACCESS_OFFSET)
#define CMD6_ACCESS_WRITE_BYTE (3 << CMD6_ACCESS_OFFSET)

#define MMC_STATUS_SWITCH_ERROR  0x80

// Manufacturer specific command.
// Used to enable boot operation and create boot partitions
// for eMMC 4.3 devices supporting boot operation.
#define MMC_CMD_62 62

// enumeration to identify specific devices before
// performing the manufacturer specifc procedure to
// enable boot operation and boot partitions.
typedef enum
{
    SAMSUNG_MOVINAND_KLM4G2DEDD,
    SAMSUNG_MOVINAND_KLM8G2DEDD,
    UNDEFINED
} emmc_device_id;

// CMD 62 argument values used to enable Boot Operation and
// create boot partitions for the following two samsung
// eMMC 4.3 spec compliant devices:
//    SAMSUNG_MOVINAND_KLM4G2DEDD,
//    SAMSUNG_MOVINAND_KLM8G2DEDD,
// as defined in the correlating specifications:
// SAMSUNG moviNAND KLM4G2DEDD (4GB) specification,
// Section 4.1.1.1 Change boot partition size
// SAMSUNG moviNAND KLM8G2DEDD (8GB) specification,
// Section 4.1.1.1 Change boot partition size
// Exact value of argument is specified in the spec for
// first two commands.
// Third command parameter specifies the boot partition
// size as a multiple of the super block, as defined
// in the specification.
// (partition size = (ARG * 2) * super block)
// per spec, super block = 2MB
// if argument = 1, then partition size = (1 * 2) * 2MB = 4MB
#define SAMSUNG_CMD62_ARG1      0xEFAC62EC
#define SAMSUNG_CMD62_ARG2      0x00CBAEA7
#define SAMSUNG_CMD62_ARG3_SIZE 1


int sd_set_data_mode(int slot, SD_DATA_MODE mode);
int sd_write(int slot, uint32 sect, uint32 n, void* source);
int sd_read(int slot, uint32 sect, uint32 n, void *dest);
int sd_open(int slot);

#endif

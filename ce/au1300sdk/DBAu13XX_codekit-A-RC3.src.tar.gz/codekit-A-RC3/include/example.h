/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef _EXAMPLE_H
#define _EXAMPLE_H

//#define _DEBUG

#define COLOR_GREY   30
#define COLOR_RED   31
#define COLOR_GREEN   32
#define COLOR_YELLOW   33
#define COLOR_BLUE   34
#define COLOR_MAGENTA   35
#define COLOR_LIGHT_BLUE  36
#define COLOR_WHITE   37

#define DEBUG_COLOR   COLOR_YELLOW

//Debug printf
#ifdef _DEBUG
/* note: prints function name for you */
#define DPRINTF(fmt, args...) printf("\e[%dm|%s(%d)|\e[0m " fmt, DEBUG_COLOR, __FUNCTION__, __LINE__ , ## args)
#else
#define DPRINTF(fmt, args...)
#endif

#define CPRINTF(color, fmt, args...) printf("\e[%dm" fmt "\e[0m", color, ## args)
/*
#if defined(_DEBUG)
#define DPRINTF printf("\e[34m|%s(%d)|\e[0m ", __FUNCTION__, __LINE__); printf
#else
#define DPRINTF if(1);else printf
#endif
*/
/********************************************************************/

typedef signed char  int8;
typedef signed short int16;
typedef signed int   int32;
typedef signed long long   int64;
typedef signed char  s8;
typedef signed short s16;
typedef signed int   s32;

typedef unsigned char  uint8;
typedef unsigned short uint16;
typedef unsigned int   uint32;
typedef unsigned long long   uint64;
typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;


/* Needed for 36-bit MIPS32 physical addresses */
typedef unsigned long long phys_t;

typedef enum
{
    FALSE = 0,
    TRUE = 1
} BOOL;

#define NULL  0
/********************************************************************/

/*
 * Setup platform specifics
 */
#include "cp0.h"
#include "platform.h"
#include "au1x00.h"
#include "gpintr.h"
#include "stdlib.h"

void
platformPutChar (int ch);

int
platformGetChar (void);

int
platformCheckChar (void);

void
msdelay (int ms);

char
rectangles (uint16 *fb, int xres, int yres, unsigned iterations);

void
exitToYamon (void);

/********************************************************************/

#define wrReg(ADDR,DATA) *(volatile uint32 *)(ADDR) = (DATA); asm(" sync")
#define rdReg(ADDR)   *(volatile uint32 *)(ADDR)

/********************************************************************/

void *
mapPhysicalAddress (phys_t physAddr, unsigned long size, int flags);

phys_t
mapVirtualToPhysical (void *va);

/* PCI helpers */
void
pciConfigBus (void);

void *
pciMapMemAddress (uint32 base, unsigned size, int flags);

void *
pciMapIoAddress (uint32 base, unsigned size, int flags);

int
pciLocateDevice (uint16 vendor, uint16 device,
                 int *pbus, int *pdev, int *pfunc);

/********************************************************************/

#include "au1x00.h"
#include "ctype.h"
#include "pcmcia.h"
#include "gpintr.h"
#include "cp0.h"
#include "ddma_api.h"
#include "autoconf.h"   // need #define's for testsuite3

#endif /* _EXAMPLE_H */

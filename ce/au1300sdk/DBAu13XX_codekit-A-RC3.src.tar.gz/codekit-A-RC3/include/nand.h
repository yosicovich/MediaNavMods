/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/


#ifndef NAND_H
#define NAND_H

#define NOWAIT	0
#define WAIT	1

/********************************************************************/
typedef struct
{
    char* model;
    uint8 maker;
    uint8 device;
    uint32  sttime; /* timing values for chip-select */
    int  data_width; /* 8 or 16 */
    int  data_size; /* data_size + spare_size = page_size */
    int  spare_size;
    int  spare_size_ecc;	/* Calculated at startup */
    int  spare_offset_ecc;  /* Calculated at startup */
    int  bad_offset; /* offset in spare area indicates bad page */
    int  pages_per_block;
    int  blocks_per_device;
    int  cs_dont_care;
    int  rdwr_requires_spare;
    int  sequential_read;
    uint8 column_cycles; /* how many addr cycles needed for column */
    uint8 row_cycles; /* how many addr cycles needed for row */
    void (*cmd_read_data)(unsigned col, unsigned row);
    int  (*cmd_read_spare)(unsigned col, unsigned row);
    void (*cmd_write_data)(unsigned col, unsigned row);
    void  (*cmd_write_spare)(unsigned col, unsigned row);
    void (*init)(void);
    void (*flush)(void);
}
NandDevice;

/********************************************************************/

extern
    NandDevice *nand_device;

// Function Prototypes for nand.c
NandDevice *
nand_initialize (void);

int
nand_reset (void);

void
nand_show_device (void);

void
nand_enable_ecc (void);

void
nane_disable_ecc (void);

int
nand_read_page (unsigned page, void *data, void *spare);

int
nand_write_page (unsigned page, void *data, void *spare);

int
nand_write_spare (unsigned page, void *spare, unsigned offset, unsigned length);

int
nand_erase_block (unsigned block);

void
nand_erase_pages (unsigned page_start, unsigned len /* in bytes */);

int
nand_page_is_bad (unsigned page);

void
nand_dump_page (unsigned page, void *data_buffer, void *spare_buffer);

void
nand_write_image (unsigned start_page, uint8 *src, unsigned len);

void
nand_read_image (unsigned start_page, uint8 *dst, unsigned len);


/********************************************************************/

#endif

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "register.h"

char bit_test(volatile uint32* reg, int bit)
{
    char result = 'R';
    int current = *reg;

    *reg = current & ~(0x01 << bit); //Clear the bit

    if ((*reg & (0x01 << bit)) == 0x0) //Did the bit clear?
    {
        *reg = current | (0x01 << bit);    //Set the bit
        if ((*reg & (0x01 << bit)) == (0x01 << bit)) //Did the bit set?
            result = 'B';       //This bit is read/write

        *reg = current;  //Reset register
    }

    return result;
}

int register_get_default_mask(char reg_config[32], char default_config[32])
{
    int i;
    uint32 mask = 0;

    for (i = 0; i < 32; ++i) //Each bit that is readable and predictable at reset will be included in the mask
        if ((reg_config[i] == REG_RO || reg_config[i] == REG_RW) && default_config[i] != REG_UNPRED)
            mask |= (0x01 << (31-i));

    return mask;
}

int register_test(volatile uint32* reg, char reg_config[32], uint32 default_value, char default_config[32])
{
    int i;
    int errors = 0;
    uint32 mask;
    char test_results[32];

    printf("\tTesting Register: %X\n", reg);
    mask = register_get_default_mask(reg_config, default_config);
    if ((*reg & mask) != (default_value & mask))
    {
        printf("\t\tDefault Value Error. Expected: %8X, Actual: %8X\n", default_value & mask, *reg & mask);
        ++errors;
    }

    for (i = 0; i < 32; ++i)
    {
        if (reg_config[i] != REG_RES && reg_config[i] != REG_WO) //Don't test bits that are 'Reserved', No meaningful test for write-only bits
        {
            test_results[i] = bit_test(reg, (31-i));
            if (test_results[i] != reg_config[i])
            {
                printf("\t\tBit %2d Error. Expected: %s, Actual: %s\n", (31-i), register_get_pretty(reg_config[i]), register_get_pretty(test_results[i]));
                ++errors;
            }
        }
    }
    return errors;
}


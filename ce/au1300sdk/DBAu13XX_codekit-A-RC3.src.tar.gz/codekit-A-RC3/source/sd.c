/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "sd.h"
#include "register.h"
#include "ddma2.h"

AU1X00_SYS* sys = (AU1X00_SYS *)KSEG1(SYS_PHYS_ADDR);

AU1X00_SD* sd[] =
{
    (AU1X00_SD*) KSEG1(SD0_PHYS_ADDR),
    (AU1X00_SD*) KSEG1(SD1_PHYS_ADDR)
};

SD_CARD_INFO sd_info[2];

// TEO: add a scratch buffer to be used for SD switch command (64 bytes of data)
//      and MMC ECSD register (512 bytes of data)
#define SD_SWITCH_CMD_DATA_LENGTH_BYTES	64
uint8 cBuffer[512];

// Definitions used with the SD switch command
#define HS_FUNCTION_NUMBER 0x1
#define HS_FUNCTION_BIT_MASK 0x2

// two byte field, but only need to look at low byte for Access Mode field.
#define FUNCTION_GROUP1_BUSY_STATUS_BYTE_OFFSET 28//34

#define FUNCTION_GROUP1_MODE_RESPONSE_BYTE_OFFSET 16 //47
#define MODE_RESPONSE_NIBBLE_FROM_CHAR(x) ((x & 0x00FF))

// two byte field, but only need to look at low byte for Access Mode field.
#define FUNCTION_GROUP1_INFO_BYTE_OFFSET 13 //50


void sd_clear_status(int slot)
{
    sd[slot]->status = 0xFFFFFFFF;  //Clear all pending interrupts
}

void sd_flush_fifo(int slot)
{
    sd[slot]->config2 |= SD_CONFIG2_FF;
    sd[slot]->config2 &= ~SD_CONFIG2_FF;
}

void sd_power_off(int slot)
{
    sd_clear_status(slot);
}

void sd_power_on(int slot)
{
    msdelay(1);
    sd_clear_status(slot);
}

void sd_wait_busy(int slot)
{
    while (sd[slot]->cmd & SD_CMD_BUSY && !kbhit())
        ;
    if (kbhit())
        getc();
    while (sd[slot]->status & SD_STATUS_CB && !kbhit())
        ;
    if (kbhit())
        getc();
}

int sd_get_response(int slot, int response_type, SD_RESPONSE* response)
{
    SD_RESPONSE r; //Just a temp variable to store the data if no response variable passed
    if (response == NULL)
        response = &r;

    if ((sd[slot]->status & SD_STATUS_RAT))
    {
#ifdef _DEBUG
        printf(", Response Timeout!\n");
#endif
        return 0;
    }

    response->r3 = 0;
    response->r2 = 0;
    response->r1 = 0;
    response->r0 = 0;
    switch (response_type)
    {
        case R2:
            response->r3 = sd[slot]->resp3;
            response->r2 = sd[slot]->resp2;
        case R6:
        case R5:
        case R4:
        case R3:
        case R1:
        case R1b:
            response->r1 = sd[slot]->resp1;
            response->r0 = sd[slot]->resp0;
        default:
            break;
    }

    // If response type is R1b, then check if card is asserting
    // busy, and if so, wait until busy deasserted before
    // returning.
    if(response_type == R1b)
        while (sd[slot]->status & SD_STATUS_DB);

#ifdef _DEBUG
//  printf(", R0: %X, R1: %X, R2: %X, R3: %X\n", response->r0, response->r1, response->r2, response->r3);
#endif

    return 1;
}

int sd_send_command_generic(int slot, int cmd, int arg, int response_type, int command_type, SD_RESPONSE* response)
{
    uint32 sdcmd = 0;
    uint32 r;

    sd_clear_status(slot);
    sd_wait_busy(slot);

    sd[slot]->cmdarg = arg;
    sd[slot]->cmd  = SD_CMD_CT_N(command_type)
                     | SD_CMD_RT_N(response_type)
                     | SD_CMD_CI_N(cmd)
                     | SD_CMD_GO;

    // Wait for Command to complete
    if (cmd != SD_WRITE_MULTIPLE_BLOCK) //response_type == R1b), this should check the response type
        sd_wait_busy(slot);

    if (response_type != 0)
        return sd_get_response(slot, response_type, response);
    else
        return 1;
}

int sd_send_command(int slot, int cmd, int arg, SD_RESPONSE* response)
{
    switch (sd_info[slot].card_type)
    {
        case CT_MMC:
            return sd_send_command_generic(slot, cmd, arg, mmc_cmd_response[cmd], sd_cmd_type[cmd], response);
        default /*CT_SD*/:
            return sd_send_command_generic(slot, cmd, arg, sd_cmd_response[cmd],  sd_cmd_type[cmd], response);
    }
}

int sd_send_app_command(int slot, int cmd, int arg, SD_RESPONSE* response)
{
    if (sd_send_command(slot, SD_APP_CMD, sd_info[slot].rca << 16, NULL))
    {
        return sd_send_command_generic(slot, cmd, arg, sd_app_response[cmd], sd_app_type[cmd], response);
    }

    return 0;
}

int sd_get_card_type(int slot)
{
    //MMC cards will not respond to the APP_CMD Secure Digital Command.  Of course neither will an empty slot!
    return sd_send_command(slot, SD_APP_CMD, sd_info[slot].rca << 16, NULL) ? CT_SD : CT_MMC;
}

uint32 sd_get_card_status(int slot)
{
    SD_RESPONSE response;

    if (sd_send_command(slot, SD_SEND_STATUS, sd_info[slot].rca << 16, &response))
    {
        return response.r0;
    }
    else
        return 0;
}

void sd_reset(int slot)
{
    sd[slot]->enable = SD_ENABLE_CE; //Put device into reset
    msdelay(100);
    sd[slot]->enable = SD_ENABLE_R | SD_ENABLE_CE; //Take out of reset
    msdelay(100);
    sd_clear_status(slot);
}

int sd_get_relative_address(int slot)
{
    SD_RESPONSE response;
    static int mmc_rca = 0;

    switch (sd_info[slot].card_type)
    {
        case CT_SD:
            //Ask the card to publish it's relative card address (RCA)
            if (!sd_send_command(slot, SD_SEND_RELATIVE_ADDR, 0, &response))
                return 0;
            return response.r0 >> 16;
            break;
        case CT_MMC:
            //Assign a unique relative card address
            if (!sd_send_command(slot, MMC_SET_RELATIVE_ADDR, (++mmc_rca<<16), &response))
                return 0;
            return mmc_rca;
            break;
    }
}

int sd_get_card_info(int slot)
{
    DPRINTF("%d\n", slot);
    SD_RESPONSE response;
    int cid=0, rca=0, c_size, c_size_mult;
    uint32 data;

    if (!sd_send_command(slot, SD_ALL_SEND_CID, 0, &response)) //Get the CID Register
        return 0;
    sd_info[slot].cid = response.r0;
    DPRINTF("CID: %X\n", sd_info[slot].cid);

    sd_info[slot].rca = sd_get_relative_address(slot);
    DPRINTF("RCA: %X\n", sd_info[slot].rca);

    if (sd_info[slot].rca)
    {
        if (!sd_send_command(slot, SD_CSD, sd_info[slot].rca << 16, &response)) //Get the CSD Register
            return 0;

        sd_info[slot].csd = response.r2;
        printf("CSD Version %d\n",  CSD_VERSION(response.r3));

        if (sd_info[slot].card_type == CT_MMC)
		{
			sd_info[slot].spec_version = CSD_MMC_SPEC_VERSION(response.r3);
			printf("CSD MMC spec version %d\n", sd_info[slot].spec_version);
		}

#if 0
        if ( CSD_VERSION(response.r3) )
            sd_info[slot].high_capacity = TRUE;
        else
            sd_info[slot].high_capacity = FALSE;
#endif

            sd_info[slot].rd_blk_len = CSD_READ_BL_LEN(response.r2);
            sd_info[slot].rd_blk_partial = CSD_READ_BL_PARTIAL(response.r2);

            c_size = CSD_C_SIZE(response.r2, response.r1);
            c_size_mult = CSD_C_SIZE_MULT(response.r1);
            //   BLOCKNR    * MULT=2^(c_size_mult+2) * BLOCK_LEN
            sd_info[slot].mem_capacity = (c_size+1) * (1 << (c_size_mult+2)) * sd_info[slot].rd_blk_len;
            sd_info[slot].wr_blk_len = CSD_WRITE_BL_LEN(response.r0);
            sd_info[slot].wr_blk_partial = CSD_WRITE_BL_PARTIAL(response.r0);

        DPRINTF("Read Block Length: %d bytes\n", sd_info[slot].rd_blk_len);
        DPRINTF("Read Block Partial: %d\n", sd_info[slot].rd_blk_partial);
        DPRINTF("Memory Capacity: %d MB\n", sd_info[slot].mem_capacity / 1024 / 1024);
        DPRINTF("Write Block Length: %d bytes\n", sd_info[slot].wr_blk_len);
        DPRINTF("Write Block Partial: %d\n", sd_info[slot].wr_blk_partial);

        //Select this card
        if (!sd_send_command(slot, SD_SELECT_DESELECT_CARD, sd_info[slot].rca << 16, NULL))
            return 0;

        sd_flush_fifo(slot);

        if (sd_info[slot].card_type == CT_SD)
        {
            //Read the SD Configuration Register.
            //This command returns the SD Status Register in resp0.
            //The SD Configuration Register is returned as a single block read,
            //therefore we must set the block size to 8 bytes
            sd[slot]->blksize = SD_BLKSIZE_BS_N(8);
            if (!sd_send_app_command(slot, SD_APP_SEND_SCR, sd_info[slot].rca << 16, &response))
                return 0;

            sd_info[slot].scr = response.r0;
            while (!(sd[slot]->status & SD_STATUS_DD))
                ; //Wait for the data transfer to complete

            // Read in the first word from the fifo. This will be bits [63:32].
            data = sd[slot]->rxport;
            sd_flush_fifo(slot);

            // Check the bus width field of the SCR register.
			// Looks like the SCR data shows up in big endian format.
			// since we're using the 32 bit wide fifo instead of 8bit, a read to the rx fifo
			// will give us a big endian formatted word, instead of bytes starting with
			// most significant.
		    sd_info[slot].bus_width = (data & 0x00000F00) >> 8;

        }
        else
        {
            sd_info[slot].bus_width = BUS_WIDTH_1; //The bus width is always 1 for MMC cards
        }


        DPRINTF("Bus Width: %d\n", sd_info[slot].bus_width);

        return 1;
    }

    return 0;
}

int sd_set_clock_divisor(int slot, int freq)
{
    AU1X00_SYS* sys = (AU1X00_SYS*) KSEG1(SYS_PHYS_ADDR);
    int pbus;
    int divisor;

    //Compute Divisor
    pbus = (sys->cpupll & SYS_CPUPLL_PLL) * 12000000;
    pbus /= ((sys->powerctrl & 0x3) + 2);
    pbus /= 2;

    //We have to be conservative here.
    //Integer division will truncate and potentially cause this to be off by 1
    //ideally "- 1" should be included in the calculation, and the result should be rounded up
    divisor = (pbus / (2 * freq)) /*- 1*/;

#ifdef _DEBUG
    printf("Freq: %d ", freq);
    printf("Pbus: %d ", pbus);
    printf("Divisor: %d\n", divisor);
#endif

    sd[slot]->config = (sd[slot]->config & ~0x1FF) | divisor | 0x200;
}

// Function to send CMD6, SWITCH command, argument for the command
// is passed in the 'argument' parameter, pointer to data buffer
// passed in cBuffer parameter.
// After command is sent, read in 64 bytes of data
// Returns a 0 for success, and a 1 otherwise.
int sd_send_switch_command( int slot, int argument, uint8 * cBuffer )
{
    SD_RESPONSE response;

    DPRINTF("sd_send_switch_command: slot %d, argument 0x%x, buffer 0x%x\r\n", slot, argument, cBuffer);

    sd[slot]->blksize = SD_BLKSIZE_BS_N(SD_SWITCH_CMD_DATA_LENGTH_BYTES);
    sd_flush_fifo(slot);

    // Send the switch command
    if(sd_send_command(slot,
                    MMC_SWITCH,
                    argument,
                    &response) == 0)
    {
        DPRINTF("ERROR: emmc_send_switch_command(): command failed, argument = 0x%x\n", argument);
        return 1;
    }

    DPRINTF("sd_send_switch_command: response 0x%x\n\r", response.r0);
    // Check if we got an error in the response
    if(response.r0 & ( (1<<22)|(1<<20)|(1<<19) ))
    {
        DPRINTF("ERROR: sd_send_switch_command() error found in response = 0x%x\n", response.r0);
        return 1;
    }

    sd_clear_status(slot);

    // Read in the 64 bytes of data
    sd_read_bytes_pio(slot, SD_SWITCH_CMD_DATA_LENGTH_BYTES, cBuffer);

    return 0;
}

int sd_enable_high_speed(int slot)
{
	int iReturn = 0;
	char cBusy;
	int iSwitchComplete = 0;
	int i, j;
    unsigned int* destwd = (unsigned int*)cBuffer;

	DPRINTF("sd_enable_high_speed: start\n\r");

	do
	{
		// check if the function is busy before enabling HS
		do
		{
			if(sd_send_switch_command(slot, 0x00ffff01, cBuffer))
			{
    		    DPRINTF("ERROR: sd_enable_high_speed() fail to enable high speed\r\n");
			    return 1;
			}

			cBusy = cBuffer[FUNCTION_GROUP1_BUSY_STATUS_BYTE_OFFSET] & HS_FUNCTION_BIT_MASK;
			DPRINTF(".");
		} while(cBusy);

		DPRINTF("sd_enable_high_speed: confirming function can be switched\n\r");

		// confirm that Access Mode function can be switched to High Speed by checking
		// the Mode Response field of the Switch data.
		if( (cBuffer[FUNCTION_GROUP1_MODE_RESPONSE_BYTE_OFFSET] == (uint8)0xFF) ||
		    ((cBuffer[FUNCTION_GROUP1_INFO_BYTE_OFFSET] & HS_FUNCTION_BIT_MASK) == (uint8)0x0) )
		{
    	    DPRINTF("ERROR: sd_enable_high_speed() fail to enable high speed: mode response = 0x%x, info = 0x%x\r\n",
    	           cBuffer[FUNCTION_GROUP1_MODE_RESPONSE_BYTE_OFFSET], cBuffer[FUNCTION_GROUP1_INFO_BYTE_OFFSET]);
			iReturn = 1;
			break;
		}

#ifdef _DEBUG
        printf("SD Switch Command Data:\n");
        for(i=0; i< 64; i++)
		{
		     printf("    %d: 0x%x\n", i, cBuffer[i]);   
		}
#endif

		DPRINTF("sd_enable_high_speed: attempting to enable high speed\n\r");

		if(sd_send_switch_command(slot, 0x80ffff01, cBuffer))
		{
    	    DPRINTF("ERROR: sd_enable_high_speed() fail to enable high speed\r\n");
			iReturn = 1;
			break;
		}

		DPRINTF("sd_enable_high_speed: confirming that switch was successful\n\r");

		// If function became busy, start a new iteration, checking for busy again.
		if(cBuffer[FUNCTION_GROUP1_BUSY_STATUS_BYTE_OFFSET] & HS_FUNCTION_BIT_MASK)
		{
			continue;
		}

		// if the Mode Response field for Function Group1, in the Switch data, is 0xff,
		// then there was an error
		if(cBuffer[FUNCTION_GROUP1_MODE_RESPONSE_BYTE_OFFSET] == (uint8)0xFF)
		{
    	    DPRINTF("ERROR: sd_enable_high_speed() fail to enable high speed: mode response = 0x%x\r\n",
    	           MODE_RESPONSE_NIBBLE_FROM_CHAR(cBuffer[FUNCTION_GROUP1_MODE_RESPONSE_BYTE_OFFSET]));
			iReturn = 1;
			break;
		}

		// Command is complete.
		iSwitchComplete = 1;

		// Confirm the switch success by checking the Function Group 1 information field.
		if(cBuffer[FUNCTION_GROUP1_MODE_RESPONSE_BYTE_OFFSET] != HS_FUNCTION_NUMBER)
		{
			// Failed to switch
    	    DPRINTF("ERROR: sd_enable_high_speed() fail to enable high speed\r\n");
			iReturn = 1;
		}
	} while (iSwitchComplete == 0);

	return iReturn;
}

#if defined(CONFIG_HWBLOCK_DDMA2)
static volatile BOOL sd_ddma_complete = FALSE;

void sd_ddma_callback( CHANNEL_ID id, unsigned int arg )
{
    sd_ddma_complete = TRUE;
}
#endif

int sd_init(int slot)
{
    DPRINTF("%d\n", slot);
    SD_RESPONSE response;

    switch (slot)
    {
        case 0:
            // Chip-level muxing
            cpuIrqConfigure(9, GPIO_IS_DEVICE);
            cpuIrqConfigure(8, GPIO_IS_DEVICE);
            cpuIrqConfigure(7, GPIO_IS_DEVICE);
            cpuIrqConfigure(6, GPIO_IS_DEVICE);
            break;
        case 1:
            // Chip-level muxing
            cpuIrqConfigure(32, GPIO_IS_DEVICE);
            cpuIrqConfigure(33, GPIO_IS_DEVICE);
            cpuIrqConfigure(34, GPIO_IS_DEVICE);
            cpuIrqConfigure(35, GPIO_IS_DEVICE);
            cpuIrqConfigure(36, GPIO_IS_DEVICE);
            cpuIrqConfigure(37, GPIO_IS_DEVICE);
            break;
    }


    sd_info[slot].rca = 0;
    sd_info[slot].data_mode = DM_PIO;
	sd_info[slot].high_capacity = FALSE;

    sd_reset(slot);

    sd[slot]->config  =
        SD_CONFIG_SI
        | SD_CONFIG_CD
        | SD_CONFIG_RF
        | SD_CONFIG_RA
        | SD_CONFIG_RH
        | SD_CONFIG_TA
        | SD_CONFIG_TE
        | SD_CONFIG_TH
        | SD_CONFIG_WC
        | SD_CONFIG_RC
        | SD_CONFIG_SC
        | SD_CONFIG_DT
        | SD_CONFIG_DD
        | SD_CONFIG_RAT
        | SD_CONFIG_CR
        | SD_CONFIG_I  /* needed for sd_status bits */
        | SD_CONFIG_RO
        | SD_CONFIG_RU
        | SD_CONFIG_TO
        | SD_CONFIG_TU
        | SD_CONFIG_NE
        | SD_CONFIG_DE;
    sd_set_clock_divisor(slot, F_OD); //Set the clock divider
    sd[slot]->config2 = SD_CONFIG2_EN | SD_CONFIG2_DC  | SD_CONFIG2_DP;  //Enable SD Controller
    sd_flush_fifo(slot);
    //sd[slot]->blksize = SD_BLKSIZE_BC_N(1) | SD_BLKSIZE_BS_N(1); //Set block size and count to 1

    sd[slot]->timeout = 0x001FFFFF;  // max timeout

    sd_power_on(slot);
#if defined(CONFIG_HWBLOCK_DDMA2)
    // Request a DMA channel for the SD interface.
    sd_info[slot].id = ddma2_request_channel(sd_ddma_callback, 0);

    if (sd_info[slot].id == CHANNEL_INVALID)
    {
        printf("\tError: Unable to allocate ddma channel\n");
        return 0;
    }

    // Set up the DMA descriptor address.
    sd_info[slot].d = (DDMA_DESCRIPTOR*) 0xA0200000;
#endif

    if (!sd_send_command(slot, SD_GO_IDLE_STATE, 0, NULL))
        return 0;

    if (sd_send_command(slot, SD_IF_COND, 0x1AA, &response))
	{
     	// If card responds to SD_IF_COND (CMD8), is is an SDHC device, compliant with SD 2.0
		// or later. mark it High Capacity. We'll confirm that later by checking the
		// OCR.AccessMode field.
     	sd_info[slot].high_capacity = TRUE;
        DPRINTF("Found SDHC compatible card\r\n");
	}

    sd_info[slot].card_type = sd_get_card_type(slot);


    do //Set the valid voltage range for the card
    {
        switch (sd_info[slot].card_type)
        {
            case CT_SD:
                if (!sd_send_app_command(slot, SD_APP_SEND_OP_COND, 0x40FF8000, &response))
                    return 0;
                break;
            case CT_MMC:
                printf("+");
                if (!sd_send_command(slot, MMC_SEND_OP_COND, 0x40FF8000, &response))
                    return 0;
                break;
        }
        printf(".");
    }
    while (!(response.r0 & OCR_STATUS));//Loop until the device is ready

    printf("ocr:%08X\n", response.r0 );

	// Check High Capacity here by checking the Access Mode field of the OCR register.
    switch (sd_info[slot].card_type)
    {
        case CT_SD:
		    // If the SD card responded to the SD_IF_CMD(CMD8), then confirm
			// card is high capacity by checking the Access Mode field in the
			// OCR register.
		    if(sd_info[slot].high_capacity == TRUE)
			{
				// if access mode = 00, then set high capacity to false.
				if(!(response.r0 & OCR_SD_ACCESS_MODE))
				{
				    sd_info[slot].high_capacity = FALSE;
				}
			}

            break;
        case CT_MMC:
			if(response.r0 & OCR_MMC_ACCESS_MODE)
			{
				sd_info[slot].high_capacity = TRUE;
			}
            break;
    }

	printf("High Capacity = %d \n\r", sd_info[slot].high_capacity);

    msdelay(100);

    if (sd_get_card_info(slot)) //Read the card info into the sd_info sturcture
    {
        // Set the bus width
        if(sd_info[slot].card_type == CT_SD)
		{
            if (sd_info[slot].bus_width & SD_BUS_WIDTHS_4BIT) //Does this chip support 4-wire bus width?
            {
                //Enable four wire data transfer
                sd[slot]->config2 |= SD_CONFIG2_WB;
                if (!sd_send_app_command(slot, SD_APP_SET_BUS_WITH, BUS_WIDTH_4, NULL))
				{
                    return 0;
				}
            }
		}
		else // MMC
		{
            if(sd_info[slot].spec_version >= 4)
			{
				// Try to switch to 4 bit
                if(emmc_set_buswidth(slot, 4))
				{
					sd_info[slot].bus_width =  4;
				}
			}
		}
		printf("sd_init: bus width %d\n", sd_info[slot].bus_width);

        // if this is a HC eMMC card, get the ECSD to 
		// calculate the card capacity.
        if((slot == 0) && (sd_info[slot].card_type == CT_MMC) && sd_info[slot].high_capacity)
		{
		    uint32 sector_count;
			uint64 capacity_mb;
            DPRINTF("Getting the ECSD\n");
    
            sd_set_clock_divisor(slot, F_PP); //Speed up 25MHz

            // set block size
            sd[slot]->blksize = SD_BLKSIZE_BS_N(SD_BLOCK_LENGTH);

		    // Get the Extended CSD to get card defaults
		    if(!emmc_ext_csd_command(slot, cBuffer))
		    {
		        return 0;
		    }

            sector_count = (cBuffer[215]<<24) | (cBuffer[214]<<16) | (cBuffer[213]<<8) | cBuffer[212];
            
			// update the memory capacity for this device
            sd_info[slot].mem_capacity = (uint64)sector_count;
            sd_info[slot].mem_capacity *= (uint64)SD_BLOCK_LENGTH;
			capacity_mb = (uint64)(sd_info[slot].mem_capacity) / (uint64)(1024 * 1024);
            DPRINTF("ECSD: sector count: 0x%x\n", sector_count);
			DPRINTF("eMMC byte capacity: 0x%0x %8x\n", ((uint32*)(&sd_info[slot].mem_capacity))[1], ((uint32*)(&sd_info[slot].mem_capacity))[3]);
			DPRINTF("eMMC capacity: %d MB\n", ((uint32*)(&capacity_mb))[0]);
        }

#if 0
        // Set the bus speed for an SD device
        if (sd_info[slot].card_type == CT_SD && sd_info[slot].high_capacity)
		{
	            // Try to switch access mode to high speed
	            if(sd_enable_high_speed(slot))
				{
	            	// Fail to switch, so speed up clock to 25MHz
	            	DPRINTF("High speed fail, so set to 25MHz\n\r");
	            	sd_set_clock_divisor(slot, F_PP);
				}
				else
				{
	            	// successfully switched to high speed access mode, so speed up
					// clock to 50MHz.
	            	DPRINTF("HS success!\n\r");
	            	sd_set_clock_divisor(slot, HS_PP);
				}
		}
        // Set the bus speed for an MMC device
        else if(sd_info[slot].card_type == CT_MMC && (sd_info[slot].high_capacity || sd_info[slot].spec_version >= 4))
		{
                if(!emmc_speed_select(slot, HS_PP))
				{
	            	// Fail to switch, so speed up clock to 25MHz
	            	sd_set_clock_divisor(slot, F_PP);
				}
		}
        else
#endif

            //sd_set_clock_divisor(slot, F_PP); //Speed up the clock the maximum data speed
            sd_set_clock_divisor(slot, HS_PP); // TEO/CFB: Set back to original value.

        // set block size
        sd[slot]->blksize = SD_BLKSIZE_BC_N(1) | SD_BLKSIZE_BS_N(SD_BLOCK_LENGTH);
        if (!sd_send_command(slot, SD_SET_BLOCKLEN, SD_BLOCK_LENGTH, NULL))
            return 0;

        return 1;
    }

    return 0;
}

int sd_card_inserted(int slot)
{
    return bcsr->sig_status & BCSR_BIC_SD0INSERT;
}

int sd_wait_card_inserted(int slot)
{
    while (!sd_card_inserted(slot))
    {
        if (kbhit())
        {
            getc();
            return 0;
        }
    }

    return 1;
}

int sd_open(int slot)
{
    return sd_init(slot);
}

int sd_close(int slot)
{
#if defined(CONFIG_HWBLOCK_DDMA2)
    // free the DMA channel for the SD interface.
    ddma2_free_channel(sd_info[slot].id);

    // invalidate the dma channel id.
    sd_info[slot].id = CHANNEL_INVALID;

    // clear the DMA descriptor address.
    sd_info[slot].d = NULL;
#endif

    sd_power_off(slot);
    return 1;
}

void sd_wait_rxfifo_empty(int slot)
{
    while (!(sd[slot]->status & SD_STATUS_NE))
        ;
}

int sd_send_stop_transmition(int slot)
{
    sd[slot]->config2 |= SD_CONFIG2_DF; //Force clock to be on
    if (!sd_send_command(slot, SD_STOP_TRANSMISSION, 0, NULL))
        return 0;
    sd[slot]->config2 &= ~SD_CONFIG2_DF;
}

#if defined(CONFIG_HWBLOCK_DDMA2)

DDMA_DESCRIPTOR_STD* sd_ddma_read_descriptor(int slot, DDMA_DESCRIPTOR* d_generic, int bytes, void* dest)
{
    DDMA_DESCRIPTOR_STD* d = (DDMA_DESCRIPTOR_STD*) d_generic;

    d->cmd1  = bytes;
    d->cmd0  = DDMA_DESCCMD_SID_N(((slot == 0) ? DDMA_SDMS0_RX_ID : DDMA_SDMS1_RX_ID)) |
               DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
               DDMA_DESCCMD_SN |  DDMA_DESCCMD_DN |
               ((sd[slot]->config2 & SD_CONFIG2_DP) ? (DDMA_DESCCMD_SW_WORD | DDMA_DESCCMD_DW_WORD )
	                                                : (DDMA_DESCCMD_SW_BYTE | DDMA_DESCCMD_DW_BYTE )) |
               DDMA_DESCCMD_CV;
    d->source1 = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_STATIC;
    d->dest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_INC;
    d->source0 = (slot == 0) ? DDMA_SDMS0_RX_ADDR : DDMA_SDMS1_RX_ADDR;
    d->dest0 = KUSEG(dest);

     return d;
}
#endif

int sd_read_bytes_pio(int slot, uint32 bytes, uint8* dest)
{
    int i, j;

//    progress_start();
// TEO: Support for 32bit wide FIFO.
    if (sd[slot]->config2 & SD_CONFIG2_DP)
    {
        unsigned int* destwd = (unsigned int*)dest;
        // divide by 4 because FIFO is word width
        for(i = 0; i < bytes/4; i+=16)
        {
            while(!(sd[slot]->status & SD_STATUS_RF));

            for(j = i; j < i+16; ++j)
            {
                // assumes FIFO got little endian
                destwd[j] = (unsigned int) sd[slot]->rxport;
            }
        }

        // since 32 bit fifo enabled, i is number of words read. But, we
		// want to return number of bytes, so do a conversion here.
		i = i * 4;
    }
    else
    {
        DPRINTF("Writing with 8bit wide fifo.\n\r");

    	for (i = 0; i < bytes; ++i)
    	{
    	    sd_wait_rxfifo_empty(slot);
    	    sd_clear_status(slot);

//  	      progress_update(1);

    	    dest[i] = (uint8) sd[slot]->rxport;
    	}
	}

//    progress_stop();

    return i;
}

int sd_read_bytes_dma(int slot, uint32 bytes, uint8* dest)
{
#if defined(CONFIG_HWBLOCK_DDMA2)
    //ddma2_set_dest_big_endian(id, 1);
    sd_ddma_read_descriptor(slot, sd_info[slot].d, bytes, dest);
    ddma2_insert_descriptor(sd_info[slot].id, sd_info[slot].d);  //Insert descriptor into channel descriptor list
    ddma2_enable_descriptor_interrupt(sd_info[slot].d); //Enable interrupt for last descriptor

    sd_ddma_complete = FALSE;

    ddma2_enable_descriptor(sd_info[slot].d, TRUE);

    ddma2_enable_channel(sd_info[slot].id);

    while (sd_ddma_complete == FALSE) //Wait until interrupt on last descriptor sets this variable
    {
        asm("nop");
    }

    ddma2_disable_channel(sd_info[slot].id);



    return bytes;
#else

    printf("DMA reads not supported by this processor!\n");
    return sd_read_bytes_pio(slot, bytes, dest);
#endif
}

int sd_read_bytes(int slot, uint64 start_byte, uint64 bytes, uint8* dest)
{
    uint32 bytes_read = 0;
    SD_RESPONSE response;
	uint32 status;

    sd_flush_fifo(slot);

    sd_get_card_status(slot);

    // High capacity cards use BLOCK addressing, not byte addressing
    if ( sd_info[slot].high_capacity )
        start_byte = start_byte >> 9;

    DPRINTF("\tReading 0x%x %x bytes @ start block 0x%x %x, to 0x%x\n", ((uint32*)(&bytes))[1], ((uint32*)(&bytes))[0], ((uint32*)(&start_byte))[1],((uint32*)(&start_byte))[0], dest);

    if (!sd_send_command(slot, SD_READ_MULTIPLE_BLOCK, start_byte, &response))
        return 0;


    sd_clear_status(slot);

    bytes_read = (sd_info[slot].data_mode == DM_DMA) ? sd_read_bytes_dma(slot, bytes, dest) : sd_read_bytes_pio(slot, bytes, dest);

#if 0
    printf("\tReturn from getting data\n\r");

    status = sd[slot]->status;

    // check for  a data timeout or data crc error
    if(status & 0x00280000)
	{
	    // clear those interrupts
	    sd[slot]->status &= ~(0x00280000);
		printf("sd_read_bytes: ERROR (0x%x)\n\r", status); 
	}
#endif

    sd_send_stop_transmition(slot);

    return bytes_read;
}

int sd_read(int slot, uint32 sect, uint32 n, void *dest)
{
//    printf("\tsd_read Sector:%d Size:%d\n", sect, n*SD_BLOCK_LENGTH );
    return sd_read_bytes(slot, (uint64)sect * (uint64)SD_BLOCK_LENGTH, (uint64)n * SD_BLOCK_LENGTH, (uint8*) dest);

}

void sd_wait_txfifo_full(slot)
{
    while (!(sd[slot]->status & (SD_STATUS_TA | SD_STATUS_TE | SD_STATUS_TH)))
        ;
}

#if defined(CONFIG_HWBLOCK_DDMA2)
DDMA_DESCRIPTOR_STD* sd_ddma_write_descriptor(int slot, DDMA_DESCRIPTOR* d_generic, int bytes, void* source)
{
    DDMA_DESCRIPTOR_STD* d = (DDMA_DESCRIPTOR_STD*) d_generic;

    d->cmd1  = bytes;
    d->cmd0  = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
               DDMA_DESCCMD_DID_N(((slot == 0) ? DDMA_SDMS0_TX_ID : DDMA_SDMS1_TX_ID)) |
               DDMA_DESCCMD_SN |  DDMA_DESCCMD_DN |
               ((sd[slot]->config2 & SD_CONFIG2_DP) ? (DDMA_DESCCMD_SW_WORD | DDMA_DESCCMD_DW_WORD )
	                                                : (DDMA_DESCCMD_SW_BYTE | DDMA_DESCCMD_DW_BYTE )) |
               DDMA_DESCCMD_CV;
    d->source1 = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_INC;
    d->dest1 = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_STATIC;
    d->source0 = KUSEG(source);
    d->dest0 = (slot == 0) ? DDMA_SDMS0_TX_ADDR : DDMA_SDMS1_TX_ADDR;

    return d;
}
#endif

int sd_write_bytes_pio(int slot, uint32 bytes, uint8* source)
{
    int i, j;
    //progress_start();

    DPRINTF("writing %d bytes to 0x%x\n", bytes, source);

// TEO: Support for 32bit wide FIFO.
    if (sd[slot]->config2 & SD_CONFIG2_DP)
    {
        unsigned int* sourcewd = (unsigned int*)source;

        // divide by 4 because FIFO is word width
        for(i = 0; i < bytes/4; i+=16)
        {
            //sd_clear_status(slot);
            while(!(sd[slot]->status & SD_STATUS_TE));

            for(j = i; j < i+16; ++j)
            {
                // assumes FIFO got little endian
                sd[slot]->txport = sourcewd[j];
            }
        }

        // since 32 bit fifo enabled, i is number of words read. But, we
		// want to return number of bytes, so do a conversion here.
		i = i * 4;
	}
	else
	{
        printf("Writing with 8bit wide fifo.\n\r");
        for (i = 0; i < bytes; ++i)
        {
            sd_wait_txfifo_full(slot);
            sd_clear_status(slot);

            //progress_update(1);

            sd[slot]->txport = source[i];
        }
	}

    //progress_stop();

    return i;
}

int sd_write_bytes_dma(int slot, uint32 bytes, uint8* source)
{
#if defined(CONFIG_HWBLOCK_DDMA2)
    sd_ddma_write_descriptor(slot, sd_info[slot].d, bytes, source);
    ddma2_insert_descriptor(sd_info[slot].id, sd_info[slot].d);  //Insert descriptor into channel descriptor list
    ddma2_enable_descriptor_interrupt(sd_info[slot].d); //Enable interrupt for last descriptor

    sd_ddma_complete = FALSE;

    ddma2_enable_channel(sd_info[slot].id);

    while (sd_ddma_complete == FALSE) //Wait until interrupt on last descriptor sets this variable
    {
        asm("nop");
    }

    ddma2_disable_channel(sd_info[slot].id);

    return bytes;
#else

    printf("DMA writes not supported by this processor!\n");
    return sd_write_bytes_pio(slot, bytes, source);
#endif
}

int sd_write_bytes(int slot, uint64 start_byte, uint64 bytes, uint8* source)
{
    uint32 bytes_written  = 0;
    SD_RESPONSE response;

    sd_flush_fifo(slot);

    // High capacity cards use BLOCK addressing, not byte addressing
    if ( sd_info[slot].high_capacity )
        start_byte = start_byte >> 9;

    DPRINTF("\tWriting 0x%x %x bytes @ start block 0x%x %x, from 0x%x\n", ((uint32*)(&bytes))[1], ((uint32*)(&bytes))[0], ((uint32*)(&start_byte))[1],((uint32*)(&start_byte))[0], source);

    if(!sd_send_command(slot, SD_WRITE_MULTIPLE_BLOCK, (unsigned long)start_byte, NULL))
		return 0;

    sd_clear_status(slot);

    bytes_written = (sd_info[slot].data_mode == DM_DMA) ? sd_write_bytes_dma(slot, bytes, source) : sd_write_bytes_pio(slot, bytes, source);

    sd_send_stop_transmition(slot);

    //Wait for card to finish programming
    while (SD_CARD_STATUS_CURRENT_STATE(sd_get_card_status(slot)) != SD_CARD_STATE_TRAN)
        ;
    sd_wait_busy(slot);

    return bytes_written;
}

int sd_write(int slot, uint32 sect, uint32 n, void* source)
{
    return sd_write_bytes(slot, (uint64)sect * (uint64)SD_BLOCK_LENGTH, (uint64)n * (uint64)SD_BLOCK_LENGTH, (uint8*) source);
}

int sd_set_data_mode(int slot, SD_DATA_MODE mode)
{
    sd_info[slot].data_mode = mode;
}

// Function to send CMD8, SEND_EXT_CSD, to get the extended
// card specific data.
// this function will the 512 byte block of data to the
// buffer pointed to by the 'dest' parameter.
int emmc_ext_csd_command(int slot, uint8* dest)
{
    int bytes_read = 0;
    SD_RESPONSE response;

    sd_flush_fifo(slot);

    response.r0 = sd_get_card_status(slot);
    
    sd_send_command_generic(slot, MMC_EXT_CSD, 0, R1, 2, &response);

    sd_clear_status(slot);

    bytes_read = (sd_info[slot].data_mode == DM_DMA) ? sd_read_bytes_dma(slot, 512, dest) : sd_read_bytes_pio(slot, 512, dest);

    return bytes_read;
}

// Function to send CMD6, SWITCH command, argument for the command
// is passed in the 'argument' parameter.
// After command is sent, check for card busy, and wait
// until card not busy.
// Also check for SWITCH error.
// Returns a 0 for success, and a 1 otherwise.
int emmc_send_switch_command( int slot, int argument )
{
    SD_RESPONSE response;

    // Send the switch command
    if(sd_send_command(slot,
                    MMC_SWITCH,
                    argument,
                    &response) == 0)
    {
        printf("ERROR: emmc_send_switch_command(): command failed, argument = 0x%x\n", argument);
        return 1;
    }

    // Check if we got a switch error
    if(response.r0 & MMC_STATUS_SWITCH_ERROR)
    {
        printf("ERROR: emmc_send_switch_command() switch error. argument = 0x%x\n", argument);
        return 1;
    }

    return 0;
}

// Function to select the partition to read from or write to from
// this programming utility, by configuring the BOOT_PARTITION_ACCESS
// field of the BOOT_CONFIG byte in the ECSD.
int emmc_partition_select( int slot, int partition )
{
    int argument;

    switch (partition)
    {
        case 0:
        case 1:
        case 2:
        {
            // Clear the BOOT_PARTITION_ACCESS field
            argument = CMD6_ACCESS_CLEAR_BITS |
                       (ECSD_BOOT_CONFIG_BYTE << CMD6_INDEX_OFFSET) |
                       (BOOT_PARTITION_ACCESS_MASK << CMD6_VALUE_OFFSET);
            if(!emmc_send_switch_command(slot, argument))
            {
                argument = CMD6_ACCESS_SET_BITS |
                           (ECSD_BOOT_CONFIG_BYTE << CMD6_INDEX_OFFSET) |
                           (partition << CMD6_VALUE_OFFSET);
                if(!emmc_send_switch_command(slot, argument))
                {
                    return 0;
                }
            }

            // Set the appropriate bit in the BOOT_PARTITION_ACCESS field
            printf("ERROR: emmc_partition_select(): could not select partition %d\n", partition);
            break;
        }

        default:
            printf("Invalid partition selected!\n");
            break;
    }

    return 1;
}


int emmc_speed_select( int slot, long speed )
{
	SD_RESPONSE response;

    DPRINTF("%d\n", slot);

    switch (speed)
    {
        case HS_PP:
            /* Switch to high speed timing mode */
            if (!sd_send_command_generic(slot, MMC_SWITCH, 0x03B90100, mmc_cmd_response[MMC_SWITCH], 0, &response))
                return 0;
            if(response.r0 & 0x80)
			{
				printf("emmc_speed_select: failure\n");
				return 0;
			}
            sd_set_clock_divisor(slot, 50000000);
            /* Set host clock */
            break;
        case F_PP:
            /* Switch to low speed timing mode */
            if (!sd_send_command_generic(slot, MMC_SWITCH, 0x03B90000, mmc_cmd_response[MMC_SWITCH], 0, &response))
                return 0;
            if(response.r0 & 0x80)
			{
				printf("emmc_speed_select: failure\n");
				return 0;
			}
            sd_set_clock_divisor(slot, F_PP);
            break;
        default:
            return 0;
            break;
    }

    return 1;
}

int emmc_set_buswidth( int slot, int width )
{
    SD_RESPONSE response;
    switch (width)
    {
        case 8:
            if ( 0 != slot )
                return -1;
            if(!sd_send_command( slot, MMC_SWITCH,0x03B70200, &response))
                return 0;
            //Enable eight wire data transfer
            sd[slot]->config2 &= ~SD_CONFIG2_WB;
            sd[slot]->config2 |= SD_CONFIG2_BB;
            break;
        case 4:
            if(!sd_send_command( slot, MMC_SWITCH,0x03B70100, &response))
                return 0;
            //Enable four wire data transfer
            sd[slot]->config2 &= ~SD_CONFIG2_BB;
            sd[slot]->config2 |= SD_CONFIG2_WB;
            break;
        case 1:
            if(!sd_send_command( slot, MMC_SWITCH,0x03B70000, &response))
                return 0;
            //Enable one wire data transfer
            sd[slot]->config2 &= ~(SD_CONFIG2_WB | SD_CONFIG2_BB);
            break;
        default:
            break;
    }
    return 1;
}

// Function to enable/disable the boot operation and
// creation of boot partitions for a specific device.
// Currently supports the following:
// Samsung KLM4G2DEDD moviNAND
// Samsung KLM8G4DEDD moviNAND
// returns 0 for success, and a 1 if failure occurs.
int emmc_enable_boot_operation( int slot, emmc_device_id device)
{
    SD_RESPONSE response;

    switch(device)
    {
        case SAMSUNG_MOVINAND_KLM4G2DEDD:
        case SAMSUNG_MOVINAND_KLM8G2DEDD:
            if(sd_send_command(slot, MMC_CMD_62, SAMSUNG_CMD62_ARG1, &response))
                if(sd_send_command(slot, MMC_CMD_62, SAMSUNG_CMD62_ARG2, &response))
                    if(sd_send_command(slot, MMC_CMD_62, SAMSUNG_CMD62_ARG3_SIZE, &response))
                        return 0;
            break;
        default:
            break;// Do nothing.
    }

    return 1;
}

#if (EMMC_FULL_BOOT_OPERATION == 1)
// Function to enable booting from a specific boot partion
// or from the user area. Configure the BOOT_PARTITION_ENABLE
// field in the BOOT_CONFIG byte of the ECSD, based on the
// value passed in the 'partition' parameter.
int emmc_partition_enable_boot( int slot, int partition )
{
    //SD_RESPONSE response;
    int argument;

    // Clear the BOOT_PARTITION_ENABLE field
    argument =  CMD6_ACCESS_CLEAR_BITS |
                (ECSD_BOOT_CONFIG_BYTE << CMD6_INDEX_OFFSET) |
                (BOOT_PARTITION_ENABLE_MASK << CMD6_VALUE_OFFSET);
    if(emmc_send_switch_command(slot, argument))
    {
        printf("ERROR: emmc_partition_enable_boot(): failed to set boot partition %d\n", partition);
    }
    else
    {
        // Set the appropriate bit in the BOOT_PARTITION_ENABLE field
        switch (partition)
        {
            case 0:   // Device not boot enabled
                break;

            case 1:   // Enable Boot from Boot Partition 1
            case 2:   // Enable Boot from Boot Partition 2
            {
                argument = CMD6_ACCESS_SET_BITS |
                           (ECSD_BOOT_CONFIG_BYTE << CMD6_INDEX_OFFSET) |
                           ((partition << BOOT_PARTITION_ENABLE_OFFSET) << CMD6_VALUE_OFFSET);

                if(emmc_send_switch_command(slot, argument))
                {
                    printf("ERROR: emmc_partition_enable_boot(): failed to set boot partition %d\n", partition);
                }
                break;
            }

            case 3:   // Enable Boot from User Area
            {
                argument = CMD6_ACCESS_SET_BITS |
                           (ECSD_BOOT_CONFIG_BYTE << CMD6_INDEX_OFFSET) |
                           ((0x7 << BOOT_PARTITION_ENABLE_OFFSET) << CMD6_VALUE_OFFSET);
                if(emmc_send_switch_command(slot, argument))
                {
                    printf("ERROR: emmc_partition_enable_boot(): failed to set boot partition %d\n", partition);
                }
                break;
            }

            default:
                printf("Invalid partition selected: %d\n", partition);
                break;

        } // switch(partition)
    } // else

    return 0;
}

// Function to enable/disable the eMMC from sending a
// boot acknowledge pattern "010".
// Configure the BOOT_ACK field in the BOOT_CONFIG byte
// of the ECSD, based on the value passed in the 'enable'
// parameter.
int emmc_set_boot_ack(int slot, int enable)
{
    int argument;

    argument = (enable ? CMD6_ACCESS_SET_BITS : CMD6_ACCESS_CLEAR_BITS) |
               (ECSD_BOOT_CONFIG_BYTE << CMD6_INDEX_OFFSET) |
               ((BOOT_ACK_MASK) << CMD6_VALUE_OFFSET);

    if(emmc_send_switch_command(slot, argument))
    {
        printf("ERROR: emmc_set_boot_ack(): failure\n");
    }

    return 0;
}
#endif


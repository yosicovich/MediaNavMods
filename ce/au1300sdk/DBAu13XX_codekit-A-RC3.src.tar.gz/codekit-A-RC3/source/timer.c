/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
#include "example.h"

#if defined(DB1300)
#define sys_toywrite (*(volatile long *)0xb0900004)
#define sys_toyread (*(volatile long *)0xb0900040)
#define sys_toytrim  (*(volatile long *)0xb0900000)
#define sys_cntctrl (*(volatile long *)0xb0900014)

#define TICKER_SOURCE_CLOCK_FREQ 32768
#define SYS_CNTRCTRL_TTS            (1<<4)
#else
#define counter_write0 (*(volatile long *)0xb1900004)
#define counter_read0 (*(volatile long *)0xb1900040)
#define trim0  (*(volatile long *)0xb1900000)
#define counter_control (*(volatile long *)0xb1900014)
#endif  // AU13XX

void ResetTimer()
{
	DPRINTF("Timer control: 0x%x\n\r", sys_cntctrl);

    // If a write to the control registeris pending, wait.
    while (sys_cntctrl & 0x080);
	
	// Write to enable the EO bit, enable the 32.768KHz Oscillator.
    sys_cntctrl = 0x100;

	// Wait until the write has completed.
    while (sys_cntctrl & 0x080);

    DPRINTF("Timer reset.\n");
	DPRINTF("Timer control: 0x%x\n\r", sys_cntctrl);
	DPRINTF("Timer trim register: 0x%x\n\r", sys_toytrim);
}

void TimerCfg(int tick_rate)
{   
    /* Setup trim for tickRate ticks per second */
    while (sys_cntctrl & SYS_CNTRCTRL_TTS);
    sys_toytrim = (TICKER_SOURCE_CLOCK_FREQ / tick_rate) - 1;
    while (sys_cntctrl & SYS_CNTRCTRL_TTS);
    printf("TOY trim programmed with %d\n", ((TICKER_SOURCE_CLOCK_FREQ/tick_rate) - 1));
	printf("Timer trim register: 0x%x\n\r", sys_toytrim);
}


int  ReadTimer()
{
    return sys_toyread;
}

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "ddma_api.h"

//#define DEBUG 1

/**********************************************************************
                                        GLOBALS
**********************************************************************/
static    AU1X00_DDMA *ddma;         // Points Au1550 ddma engine
static    CHANNEL  channels[DDMA_NUM_CHANNELS]; // Local channel status

/**********************************************************************
                    Helper Functions
**********************************************************************/

void  ddma_channel_start(  CHANNEL *channel )
{
    channel->ptr->cfg |= DDMA_CHANCFG_EN;
}
void  ddma_channel_stop(    CHANNEL *channel )
{
    channel->ptr->cfg &= ~DDMA_CHANCFG_EN;
}
void  ddma_doorbell(    CHANNEL *channel )
{
    channel->ptr->dbell = 0xFFFFFFFF;
}


/*
 *   Function   :   ddma_intr_handler
 *
 *      This function is responsible for handling DDMA interrupts.
 *
 *  User specified callbacks can be used for application processing at
 *  interrupt time.
 *
 *   Parameters :
 *      irq   IRQ #
 *  arg   intr_handler data
 *
 *     Returns :
 *      Nothing
 *
 */
static void ddma_intr_handler( int irq, void *arg )
{
    CHANNEL *channels = (CHANNEL*)arg;
    DDMA_DESCRIPTOR  *first;
    int  i;

#ifdef DEBUG
    printf("ddma_intr_handler: intstat:%08X\n", ddma->intstat );
#endif
    for ( i=0; i<DDMA_NUM_CHANNELS && ddma->intstat; i++ )
    {
        // Get the channel number -- must shift by 1 to get proper array index
        if ( ddma->intstat & 1<<i )
        {
            int  completed=0;

            first = channels[i].dh;

//
// CTG TODO -- This will not work if there is only one descriptor in a ring :(
//
#ifdef DEBUG
            printf("dh:%x dt:%x dh_cmd0:%X\n", channels[i].dh, channels[i].dt, channels[i].dh->u.std.cmd0 );
#endif
            // move the head pointer along -- this allows user's to re-post in callback
            while ( channels[i].dh != channels[i].dt && !(channels[i].dh->u.std.cmd0 & DDMA_DESCCMD_V) )
            {
                completed++;
#ifdef DEBUG
                printf("Descriptor:%X completed\n", channels[i].dh );
#endif
                /*
                 * We need to get the next descriptor's address. We must be careful to OR in the proper
                 *  MIPS KESG0/1 address bits. These are taken from the previously configured ring pointers.
                 *  The ring pointer was passed to us by the user... so assume they are all the same.
                 */
                channels[i].dh = NXTPTR_TO_VIRT( channels[i].ring, channels[i].dh );
            }

            // Call user's callback routine
            if ( NULL != channels[i].callback )
                channels[i].callback( (void*)&channels[i], first, completed, channels[i].arg );

            // clear interrupt bits
            ddma->intstat &= ddma->intstat-1;
            channels[i].ptr->irq = 0;

        }
    }
}


/*
 *   Function   :   ddma_init
 *
 *      This function is responsible for pointing the "ddma" structure to
 *      correct physical memory location. It also initialized the channels
 *      to known values.
 *
 *   Parameters :
 *      config  User specified configuration of the channel
 *
 *     Returns :
 *      TRUE  On Success
 *  FALSE  On Failure
 *
 */
int   ddma_init( uint32 config )
{
    int i;

    /*
     * Point our ddma structure to correct
     * memory location
     */
    ddma = (AU1X00_DDMA*)mapPhysicalAddress(DDMA_PHYS_ADDR, sizeof(AU1X00_DDMA), 0);

    /*
     * Initialize the local channel status to 0s
     */
    memset((void*)channels,0,sizeof(channels));

    for ( i=0; i<DDMA_NUM_CHANNELS; i++ )
    {
        channels[i].ptr = &ddma->channel[i];
        channels[i].avail = TRUE;
        channels[i].src_id = channels[i].dst_id = 0xFFFFFFFF;
    }

    /* Let the user specify the ddma config settings */
    ddma->config = config;

    /* Disable all channel interrupts */
    ddma->inten = 0;

    /* Install the generic DDMA interrupt handler */
    cpuIrqEnable( IRQ_DDMA, irqHL, ddma_intr_handler, channels );

    return TRUE;
}


/*
 *   Function   :   ddma_get_channel
 *
 *      This function allocates a channel for a specific device, sets the default
 *  transfer size, allocates 'n' descriptors and sets the channels descriptor
 *  pointer to the beginning of the ring.
 *
 *  Channels are allocated High Number to Low Numeber. I.e. 15,14,13 etc. This
 *  assumes lower channel numbers have higher priority when priority is enabled.
 *
 *   Parameters :
 *      config  Pointer to the CHANNEL_CONFIG structure
 *
 *     Returns :
 *      Non-NULL Pointer to the newly allocated channel
 *  NULL  Failure to allocate channel
 *
 */
void *  ddma_get_channel( CHANNEL_CONFIG *config )
{
    CHANNEL   *chan = NULL;
    DDMA_DESCRIPTOR *desc_ring = NULL;
    int    i;

    /*
     * Find a channel to use -- if the user specified a channel
     *  try to find that one. If it is not available return NULL
     */
    if ( -1 != config->channel )
    {
        if ( TRUE == channels[config->channel].avail  )
        {
            chan = &channels[config->channel];
            chan->avail = FALSE;
        }
        else
            return NULL;
    }
    else
    {
        /* Find an available channel for use */
        for ( i=DDMA_NUM_CHANNELS-1; i>=0; i--)
            if ( TRUE == channels[i].avail )
            {
                chan = &channels[i];
                chan->avail = FALSE;
                break;
            }
    }

    chan->ring = chan->dt = chan->dh = config->descriptors;

    /* Setup the channels intial descriptor pointer. */
    chan->ptr->des_ptr = ~0xA0000000 & (uint32)chan->dh;

    /* Install the user's specified parameters */
    chan->ptr->cfg  = config->chan_cfg;
    chan->ptr->stat_ptr = config->chan_stat;

    /* Copy the user's callback to the local channel structure */
    chan->callback = config->callback;
    chan->arg = config->arg;

    /* Enable interrupts for this channel */
    i= (1<<((uint32) ((~0xA0000000 & (uint32)chan->ptr)-DDMA_PHYS_ADDR)/sizeof(DDMA_CHANNEL)));
    ddma->inten = ddma->inten | i;

    return chan;
}

/*
 *   Function   :   ddma_free_channel
 *
 *      This function will free all resources with a specified channel.
 *
 *   Parameters :
 *      channel  Pointer
 *
 *     Returns :
 *      TRUE  On Success
 *  FALSE  On Failure
 *
 */
int   ddma_free_channel( void *channel )
{
    int i;
    CHANNEL   *chan = (CHANNEL*)channel;

    /* Disable interrupts for this channel */
    i= (1<<((uint32) ((~0xA0000000 & (uint32)chan->ptr)-DDMA_PHYS_ADDR)/sizeof(DDMA_CHANNEL)));
    ddma->inten = ddma->inten & ~i;

    ddma_channel_stop( (CHANNEL*)channel );

    memset(channel,0,sizeof(CHANNEL));
    return TRUE;
}

/*
 *   Function   :   ddma_init_descriptors
 *
 *      This function will take a descriptor list with the first entry modfied by
 *      the user and duplicate it throughout the list.
 *  It is up to the user to assign new src,dst and cnt values when the descriptors
 *  are to be used.
 *
 *  Mainly used for duplicating SIDs, DIDs, SAM etc. it also sets up the
 *  nxt_ptrs for ring effect.
 *
 *   Parameters :
 *      list  Pointer to the list of ddma descriptors
 *  count  number of descriptors in the list
 *
 *     Returns :
 *      nothing
 *
 */
void ddma_init_descriptors( DDMA_DESCRIPTOR *list, uint32 count )
{
    DDMA_DESCRIPTOR *current = list;
    int i;
    for ( i=0; i<count-1; i++)
    {
        DDMA_DESCRIPTOR *prev;

        prev = current;
        current++;

        /* Lets make all the remaining descriptors match the first initialized one */
        memcpy((void*)current, (void*)prev, sizeof(DDMA_DESCRIPTOR));

        prev->u.std.nxt_ptr  = VIRT_TO_NXTPTR(current);
    }

    /* The last descriptor should point back around to the beginning of the ring */
    current->u.std.nxt_ptr  = VIRT_TO_NXTPTR(list);

#ifdef DEBUG
    for ( i=0,current=list;i<count;i++,current++)
    {
        printf("Descriptor %d: \n\t%08X %08X %08X %08X\n\t%08X %08X %08X  %08X\n", i,
               ((uint32*)current)[0], ((uint32*)current)[1], ((uint32*)current)[2], ((uint32*)current)[3],
               ((uint32*)current)[4], ((uint32*)current)[5], ((uint32*)current)[6], ((uint32*)current)[7] );
    }
#endif

}


/*
 *   Function   :   ddma_next_descriptor
 *
 *      This function find the next available descriptor in the ring for use.
 *
 *   Parameters :
 *      channel  Pointer
 *
 *     Returns :
 *      non-zero   Upon finding an available descriptor
 *  NULL  Descriptor Ring is full
 *
 */
DDMA_DESCRIPTOR * ddma_next_descriptor( void *c )
{
    int     isempty=FALSE;
    DDMA_DESCRIPTOR  *new=NULL;
    CHANNEL    *channel = (CHANNEL*)c;

    // Is the channel enabled?
    if ( channel->ptr->cfg & DDMA_CHANCFG_EN )
    {
#ifdef DEBUG
        printf("ddma_next_descriptor: channel->dh %X\n",channel->dh);
#endif

#if !defined(CONFIG_EXAMPLE_AU1XIDE)
        // AU1XIDE example source code allows one descriptor ddma operation at the last block transfer
        // Do we have room on the ring?
        if ( channel->dt->u.std.nxt_ptr == VIRT_TO_NXTPTR(channel->dh) )
            return NULL;
#endif
        // Check to see if the descriptor ring is empty
        if ( !(channel->dh->u.std.cmd0 & DDMA_DESCCMD_V) && channel->dh == channel->dt )
            isempty = TRUE;

        // If the ring is empty... then point new to the current tail... otherwise point to next descriptor
        if ( isempty )
            new = channel->dt;
        else
        {
            new = (DDMA_DESCRIPTOR*)( (uint32)(channel->dt->u.std.nxt_ptr)<<5);
#ifdef DEBUG
            printf("ddma_next_descriptor: List is not empty, new:%X\n", new);
#endif
        }

        // point to our new tail
        channel->dt = NXTPTR_TO_VIRT(channel->ring, channel->dt);
    }
    return new;
}

/*
 *   Function   :   ddma_lit_wr
 *
 *      This function is a helper routine to place a user's buffer pointer
 *  in the descriptor. Set size attribute and ring the channel's
 *  doorbell to begin transaction.
 *
 *   Parameters :
 *      channel  Pointer to the ddma channel ( local struct )
 *  dst   Pointer where the data should go -- useful for MEM->MEM ddma
 *  size  Size of the data in bytes
 *
 *     Returns :
 *      TRUE  On Success
 *  FALSE  On Failure
 *
 */
int ddma_lit_wr( void *channel, void *dst, uint32 size )
{
    DDMA_DESCRIPTOR *d;

    d = ddma_next_descriptor( channel );
    if ( NULL == d ) return FALSE;
#ifdef DEBUG
    printf("ddma_lit_wr: Using %X\n", d );
#endif
    if ( NULL != dst )
        d->u.std.dest0 = ~0xA0000000 & (uint32)dst;
    d->u.std.cmd1 = size;

    // We could allow user to use 4 bytes of the context
// d->c.p = context;

    d->u.std.cmd0 |= DDMA_DESCCMD_V;
    ddma_doorbell( (CHANNEL*)channel );

    return TRUE;
}

/*
 *   Function   :   ddma_tx
 *
 *      This function is a helper routine to place a user's buffer pointer
 *  in the descriptor. Set size attribute and ring the channel's
 *  doorbell to begin transaction.
 *
 *   Parameters :
 *      channel  Pointer to the ddma channel ( local struct )
 *  src   Pointer to the data
 *  dst   Pointer where the data should go -- useful for MEM->MEM ddma
 *  size  Size of the data in bytes
 *
 *     Returns :
 *      TRUE  On Success
 *  FALSE  On Failure
 *
 */
int ddma_tx( void *channel, void *src, void *dst, uint32 size )
{
    DDMA_DESCRIPTOR *d;

    d = ddma_next_descriptor( channel );
    if ( NULL == d ) return FALSE;
#ifdef DEBUG
    printf("ddma_tx: Using %X\n", d );
#endif
    d->u.std.source0 = ~0xA0000000 & (uint32)src;
    if ( NULL != dst )
        d->u.std.dest0 = ~0xA0000000 & (uint32)dst;
    d->u.std.cmd1 = size;

    // We could allow user to use 4 bytes of the context
// d->c.p = context;

    d->u.std.cmd0 |= DDMA_DESCCMD_V;
#ifdef DEBUG
    printf("ddma_tx: cmd0 == %X\n", d->u.std.cmd0 );
#endif
    asm("sync");
    ddma_doorbell( (CHANNEL*)channel );

    return TRUE;
}

/*
 *   Function   :   ddma_rx
 *
 *      This function is a helper routine to place a user's buffer pointer
 *  in the descriptor. Set size attribute and ring the channel's
 *  doorbell to begin transaction.
 *
 *   Parameters :
 *      channel  Pointer to the ddma channel ( local struct )
 *   dest  Pointer to the destination data
 *  size  Size of the data in bytes
 *
 *     Returns :
 *      TRUE  On Success
 *  FALSE  On Failure
 *
 */
int ddma_rx( void *channel, void *dst, uint32 size )
{
    DDMA_DESCRIPTOR *d;

    d = ddma_next_descriptor( channel );
    if ( NULL == d ) return FALSE;

    d->u.std.dest0 = ~0xA0000000 & (uint32)dst;
    d->u.std.cmd1 = size;

    // We could allow user to use 4 bytes of the context
// d->c.p = context;

    d->u.std.cmd0 |= DDMA_DESCCMD_V;
    ddma_doorbell( (CHANNEL*)channel );

    return TRUE;
}

void ddma_dump_regs( void)
{
    int i;
    printf("These are the configuration registers for the DDMA\n");
    printf("CONFIG:   ADDR = %08X, VALUE = %08X\n", &ddma->config, ddma->config);
    printf("INTR:     ADDR = %08X, VALUE = %08X\n", &ddma->intstat, ddma->intstat);
    printf("COUNTER:  ADDR = %08X, VALUE = %08X\n", &ddma->throttle, ddma->throttle);
    printf("MASK:     ADDR = %08X, VALUE = %08X\n", &ddma->inten, ddma->inten);

    for (i=0;i<DDMA_NUM_CHANNELS;i++)
    {
        printf("These are the values for DDMA Channel %d registers\n",i);
        printf("STATE:      ADDR = %08X, VALUE = %08X\n", &ddma->channel[i].cfg, ddma->channel[i].cfg);
        printf("DES_PTR:    ADDR = %08X, VALUE = %08X\n", &ddma->channel[i].des_ptr, ddma->channel[i].des_ptr);
        printf("STAT_PTR:   ADDR = %08X, VALUE = %08X\n", &ddma->channel[i].stat_ptr, ddma->channel[i].stat_ptr);
        printf("DB:         ADDR = %08X, VALUE = %08X\n", &ddma->channel[i].dbell, ddma->channel[i].dbell);
        printf("IRQ:        ADDR = %08X, VALUE = %08X\n", &ddma->channel[i].irq, ddma->channel[i].irq);
        printf("STATUS:     ADDR = %08X, VALUE = %08X\n", &ddma->channel[i].stat, ddma->channel[i].stat);
        printf("BYTECNT:    ADDR = %08X, VALUE = %08X\n", &ddma->channel[i].bytecnt, ddma->channel[i].bytecnt);
    }

}

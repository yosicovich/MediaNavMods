/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"

#ifndef CONSOLE
#define CONSOLE 0
#endif

#ifndef BAUDRATE
#define BAUDRATE 115200
#endif

/* used in crt0.S for exitToYamon() */
void *startupStackFrame;

/********************************************************************/

void
commonInit (void)
{
    DPRINTF("\n");
    dcacheFlush();
    icacheFlush();
    tlbInit();

    cpuIrqInit();

#if defined(AU1000) || defined(AU1500) || defined(AU1100)
    dmaInit();
#endif

#if defined(CONFIG_HWBLOCK_DDMA2) && defined(AU1300)
    ddma2_init();
#endif

//  ddma_init(0);   // Need to add some meaningful config value here

    msdelay(10);
    uartInit(CONSOLE, BAUDRATE);
    msdelay(10);

    /* Allow interrupts to occur (though all masked) */
    cpuEnableIrqs(STATUS_IE);
}

/********************************************************************/

void
platformPutChar (int ch)
{
    uartPutChar(CONSOLE, ch);
}

int
platformGetChar (void)
{
    int ch;
    uartGetChar(CONSOLE, &ch);
    return ch;
}

int
platformCheckChar (void)
{
    return uartCheckChar(CONSOLE);
}

/********************************************************************/


/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"

/********************************************************************/
void
putc (int ch)
{
    if (ch == '\n')
    {
        platformPutChar('\r');
        platformPutChar('\n');
    }
    else
        platformPutChar(ch);
}

/********************************************************************/
int
kbhit (void)
{
    return platformCheckChar();
}

/********************************************************************/
int
getc (void)
{
    int ch;

    ch = platformGetChar();
    if (ch == '\r')
        ch = '\n';
    putc(ch);
    return ch;
}

/********************************************************************/
int
getc_noecho (void)
{
    int ch;

    ch = platformGetChar();
    if (ch == '\r')
        ch = '\n';
    return ch;
}

/********************************************************************/
void
puts (const char *s)
{
    while (*s)
    {
        putc(*s++);
    }
}

/********************************************************************/
char *
gets (char *s)
{
    int i = 0;
    int ch;

    do
    {
        ch = getc();
        if (ch == '\b')
        {
            if (i > 0)
                --i;
            puts(" \b");
        }
        else
        {
            s[i++] = ch;
        }
    }
    while ((ch != '\n') && (ch != '\r'));

    s[i] = '\0';

    return s;
}

/********************************************************************/
char *
gets_noecho (char *s)
{
    int i = 0;
    int ch;

    do
    {
        ch = getc_noecho();
        if (ch == '\b')
        {
            if (i > 0)
                --i;
        }
        else
        {
            s[i++] = ch;
        }
    }
    while ((ch != '\n') && (ch != '\r'));

    s[i] = '\0';

    return s;
}

/********************************************************************/
int
srand (int max)
{
    int v = (int)cp0RdCount();

    v &= 0x0ffff;

    if ( max != 0 )
        v = v % max;

    return v;
}

/********************************************************************/
int hexchartoi(const char ch)
{
    switch (ch)
    {
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
            return (ch - '0');
            break;
        case 'A':
        case 'a':
            return 10;
            break;
        case 'B':
        case 'b':
            return 11;
            break;
        case 'C':
        case 'c':
            return 12;
            break;
        case 'D':
        case 'd':
            return 13;
            break;
        case 'E':
        case 'e':
            return 14;
            break;
        case 'F':
        case 'f':
            return 15;
            break;
        default:
            return 0;
    }
}

/********************************************************************
int isspace(const char ch) {
  switch (ch) {
    case ' ' :
    case '\f':
    case '\n':
    case '\r':
    case '\t':
    case '\v':
      return 1;
    default  :
      return 0;
  }
}

/********************************************************************
int isalpha(const char ch) {
  if (((ch >= 'A') && (ch <= 'Z')) ||
      ((ch >= 'a') && (ch <= 'z')))
    return 1;
  return 0;
}

/********************************************************************
int isupper(const char ch) {
  if ((ch >= 'A') && (ch <= 'Z')) return 1;
  return 0;
}

/********************************************************************
int islower(const char ch) {
  if ((ch >= 'a') && (ch <= 'z')) return 1;
  return 0;
}

/********************************************************************
int isdigit(const char ch) {
  if ((ch >= '0') && (ch <= '9')) return 1;
  return 0;
}

/*******************************************************************
int isxdigit(const char ch) {
  if (((ch >= '0') && (ch <= '9')) ||
      ((ch >= 'A') && (ch <= 'F')) ||
      ((ch >= 'a') && (ch <= 'f')))
    return 1;
  return 0;
}
*/

/********************************************************************
* This implementation of strtol supports only bases 8, 10, and 16   *
********************************************************************/
long strtol(const char* nptr, const char** endptr, int base)
{
    long value = 0;
    int neg = 0;
    int x = 0;
    static char safechar;  // allocate our own pointer in case none passed
    const char *safeptr = &safechar;

    // if null passed, use own pointer...
    if (endptr == 0)
    {
        endptr = &safeptr;
    }
    // set start location
    *endptr = nptr;

    // skip any preceeding whitespace
    while (isspace(**endptr))
    {
        *endptr += sizeof(char);
    }

    // determine sign
    if (**endptr == '-')
    {
        neg = 1;
        *endptr += sizeof(char);
    }
    else if (**endptr == '+')
    {
        *endptr += sizeof(char);
    }

    switch (base)
    {
        case 0:
            // determine actual base
            if (**endptr == '0')
            {
                *endptr += sizeof(char);;
                if (**endptr == 'x')
                    return strtol(nptr, endptr, 16);
                if (isdigit(**endptr))
                    return strtol(nptr, endptr, 8);
                return 0;
            }
            else
            {
                if (isdigit(**endptr))
                    return strtol(nptr, endptr, 10);
                return 0;
            }
            break;

        case 8:
            while ((**endptr >= '0') && (**endptr <= '7'))
            {
                value *= base;
                value += **endptr - '0';
                *endptr += sizeof(char);
            }
            break;

        case 10:
            while (isdigit(**endptr))
            {
                value *= base;
                value += **endptr - '0';
                *endptr += sizeof(char);
            }
            break;

        case 16:
            while (isxdigit(**endptr) || ((**endptr == 'x') && (x ^= 1)))
            { // should break after the second 'x'
                value = value << 4;
                value += hexchartoi(**endptr);
                *endptr += sizeof(char);
            }
            break;
    }

    if (neg) value = 0 - value;

    return value;
}


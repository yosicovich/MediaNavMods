


void load(void)
{
	int (*read)( unsigned long start, unsigned long end, void *dest) = 	(void*)0x9fc00810;

	/* The OnChipRom will only read 2k at first. (BUG) Supposed to read 8KB (BUG)
	 *  We need to read rest of data into dcache.
	 */
	read( 0, 2048, (void*)0x9fc09000 );
}

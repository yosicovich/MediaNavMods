
#ifndef SREC_H
#define SREC_H

#include "functions.h"

void *srecLoadImage(DataFunctions dataFunctions, const
                    char *fileName);

void eatLine();

int getStype(char *type);

int getSpair(char *value);

int isSrec();

void *readSrec();

#endif    /*
*/

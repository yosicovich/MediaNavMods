
int usbOpen(int diskno);
int usbEject();
int usbRead(int diskno, int sect, int n, void *buf);

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/


/*****************************************************************************

Image creator config file example:

UPDATE REGIONS
Destination     CF0
part.img        0
boot.img        63
android.img     137088
data.img        2237760
cache.img       2765952


Note that CF0 can be replaced with SD1 (insertable SD card) or SD0
(DB1300 on-board EMMC chip).

*****************************************************************************/

#include "filesystem.h"
#include "fat.h"
#include "functions.h"
#include "update.h"
#include "../../../include/sd.h"
#include <string.h>

UPDATE_INFO regions[MAX_UPDATE_REGIONS];
DataFunctions fileAccessFunctions;

//----------------------------------------------------------------------------
// mystrok()
// 
// PURPOSE:
// -------
// Designed to mimic the original strtok() function.
//
// The strtok() function in the current toolchain libc.a causes linker
// problems (perhaps due to its internal static variables?).  So here's
// one I rolled today that doesn't use any libc functions (that aren't
// used already).
//
// PARAMETERS:
// ----------
// pBuffer:				Initial pointer to string to be delineated - or
//						NULL for string currently being deliniated.
// pDelimiterString:	String containing list of delimiter characters.
//
// RETURN CODE:
// -----------
// Pointer to latest delineated substring, or NULL if done delineating.
//----------------------------------------------------------------------------
static char *
mystrtok(	char *pBuffer,
			char *pDelimiterString)
{
	static char	*pMyStrtokBufPtr = NULL;
	char		*pDelimiter;
	char		*pCurrentSubstring;
	char		*pCurrentSubstringEnd;
	char		*pTemp;

	//------------------------------------------------------------------------
	// If the delimiter string is empty, nothing more to do.  But don't
	// interfere with pCurrentSubstring, lest another parsing call be
	// made on the same string, but with a valid list of tokens.
	//------------------------------------------------------------------------
	if(!pDelimiterString)
	{
		return NULL;
	}

	//------------------------------------------------------------------------
	// If buffer is not NULL, then we're starting on a new string.
	//------------------------------------------------------------------------
	if(pBuffer)
	{
		pMyStrtokBufPtr = pBuffer;
	}

	//------------------------------------------------------------------------
	// If we're at the end of the string to be seached, we're done.
	//------------------------------------------------------------------------
	if(!pMyStrtokBufPtr || !(*pMyStrtokBufPtr))
	{
		return NULL;
	}

	//------------------------------------------------------------------------
	// Skip past any contiguous tokens starting the current substring.
	//------------------------------------------------------------------------
	pDelimiter = pDelimiterString;
	do
	{
		//--------------------------------------------------------------------
		// If a token is found in the substring, advance the latter's
		// pointer and restart the token string search.  If we're at
		// the end of the substring, we're done.
		//--------------------------------------------------------------------
		if(*pDelimiter == *pMyStrtokBufPtr)
		{
			pMyStrtokBufPtr++;

			//----------------------------------------------------------------
  			// If we're done, indicate such to future invocations of
			// this function.
			//----------------------------------------------------------------
			if(!(*pMyStrtokBufPtr))
			{
				pMyStrtokBufPtr = NULL;
				return NULL;
			}

			pDelimiter = pDelimiterString;
		}
		else
		{
			pDelimiter++;
		}
	}
	while(*pDelimiter);

	//------------------------------------------------------------------------
	// We're at the start of the next substring - save its lcoation.
	//------------------------------------------------------------------------
	pCurrentSubstring = pMyStrtokBufPtr;

	//------------------------------------------------------------------------
	// Search for the next nearest delimiting char in the current substring,
	// Note: since we're having trouble with using string functions in
	// libc, don't use strchr() or any other such function.
	//------------------------------------------------------------------------
	for(pCurrentSubstringEnd = pCurrentSubstring + strlen(pCurrentSubstring),
		pDelimiter			 = pDelimiterString;
		*pDelimiter;
		pDelimiter++)
	{
		for(pTemp = pCurrentSubstring; *pTemp; pTemp++)
		{
			if((*pDelimiter == *pTemp) && (pCurrentSubstringEnd > pTemp))
			{
				pCurrentSubstringEnd = pTemp;
				break;
			}	
		}
	}

	//------------------------------------------------------------------------
	// If a delimiter was found, set it to '\0' and update the pointers
	// appropriately.  If not, then the current substring is the last to
	// be delimited, so indicate such to future NULL invocations of this
	// function.
	//------------------------------------------------------------------------
	if(pCurrentSubstringEnd < (pCurrentSubstring + strlen(pCurrentSubstring)))
	{
		pMyStrtokBufPtr		= pCurrentSubstringEnd;
		*pMyStrtokBufPtr++	= '\0';
	}
	else
	{
		pMyStrtokBufPtr = NULL;
	}

	//------------------------------------------------------------------------
	// Return a pointer to the now delineated substring.
	//------------------------------------------------------------------------
	return pCurrentSubstring;
}

typedef enum INF_TYPES
{
	_CF=1,	_IDE,	_SD,	_NOR,	_NAND
} inf_t;

typedef struct
{
	inf_t type;
	int sub;
} UPDATE_INTERFACE;

static int getline( char *buffer )
{
	int bytesRead = 0;
	while ( fileAccessFunctions.read(buffer, 1) && (*buffer !=0xA && *buffer != -1) )
	{
		bytesRead++;
		buffer++;
	}
	*buffer = '\0';
	return bytesRead;
}

char tmp[256];

static int regionRead(void)
{
	int i,br;

	char *name,*sect,*end;
	char *sep="\\/:;=-\t ";

	for(i=0;i<MAX_UPDATE_REGIONS;i++)
	{
		if ( getline(tmp) )
		{
			char *ptr = tmp;

			//name = strtok(tmp,sep);
			//sect = strtok(NULL,sep);
			// Use a homegrown strtok() to step around the problem the current
			// toolchain's libc.a strtok() causes.  If using that latter, the
			// link fails.  This is of course not a fix, but a workaround.
			name = mystrtok(tmp,sep);
			sect = mystrtok(NULL,sep);

			strcpy(regions[i].filename,name);
			regions[i].sect_start = strtol(sect,NULL,10);
		}
		else
			break;
	}

	return i;
}

int isUpdate()
{
	uint32 *pGPIOBaseAddress = (uint32 *)0xB0200000; // S2 GPIO reg. address

	//------------------------------------------------------------------------
	// First check to see if button S2 is being held down during powerup.
	// If not, then skip the update image step and go on to regular bootup.
	// Otherwise, go on to do the image update.
	//
	// NOTE: this relies on the GPIO pin being configured as an input upon
	// powerup.
	//------------------------------------------------------------------------
	if (!(*pGPIOBaseAddress & 0x00000001))
	{
		printf("BUTTON S2 NOT PRESSED.\n");
		printf("FOR IMAGE CREATION, S2 MUST BE PRESSED DURING POWERUP.\n");
		return 0;
	}

	getline(tmp);
	if ( strcmp(tmp,"UPDATE REGIONS") == 0 )
	{
		printf("Found Update File");
		return 1;
	}
	return 0;
}


static int getDestination( UPDATE_INTERFACE *inf)
{
	char *str;

	if( getline(tmp) )
	{
		printf("\t Found Destination. %s\n",tmp);
#if defined(CONFIG_HWBLOCK_PCMCIA)
		str = strstr(tmp,"CF");
		if( str != NULL)
		{
			inf->type	= _CF;
			inf->sub	= *(str + 2) - '0';
		}
#endif
#if defined(CONFIG_HWBLOCK_SD)
		str = strstr(tmp,"SD");
		if( str != NULL)
		{
			inf->type	= _SD;
			inf->sub	= *(str + 2) - '0';
		}
#endif
	}
	return inf->type;
}

static void spinner()
{
	static int _spin = '\\';
	printf("%c", 8);
	switch (_spin)
	{
		case '-':
			printf("-");
			_spin = '\\';
			break;
		case '\\':
			printf("\\");
			_spin = '|';
			break;
		case '|':
			printf("|");
			_spin = '/';
			break;
		case '/':
			printf("/");
			_spin = '-';
			break;
	}
}

#define READ_BUF_SIZE	4096
unsigned char data[READ_BUF_SIZE];

static int doUpdate( int cnt, UPDATE_INTERFACE inf )
{
	int i, bytes;

	switch(inf.type)
	{
		case (_CF):
			pcmcia_wait_card_inserted(inf.sub);
			pcmciaOpen(inf.sub);

			for(i=0;i<cnt;i++)
			{
				int				sector			= regions[i].sect_start;
				unsigned char	_spinnerDelay	= 0;

				printf("\t CF: Updating region %d(%s) ... ",
					   i,regions[i].filename);

				//------------------------------------------------------------
				// If the image file can be opened, read its contents and
				// write them to the CF card.  Otherwise just print
				// "SKIPPED".
				//------------------------------------------------------------
				if(fileAccessFunctions.open(regions[i].filename))
				{
					do
					{
						unsigned char	*pData;
						int				j;

						bytes = fileAccessFunctions.read(&data, READ_BUF_SIZE);

						if(!(_spinnerDelay--))
						{
							_spinnerDelay = 16;
							spinner();
						}

						//----------------------------------------------------
						// Write the data to the CF card in 512 byte chunks.
						// Apparently this is necessary.
						//----------------------------------------------------
						for(pData = data, j = bytes;
							j > 0;
							j -= 512, pData += 512, sector++)
						{
							pcmciaWrite(sector, 1, pData);
						}

					}
					while(bytes >= 512);

					fileAccessFunctions.close();
					printf(" : DONE\n");
				}
				else
				{
					printf(" : SKIPPED\n");
				}
			}

			break;

		case (_SD):
			if(inf.sub != 0)
				sd_wait_card_inserted(inf.sub);

			sd_open(inf.sub);
			sd_set_data_mode(inf.sub, DM_DMA);

			for(i=0;i<cnt;i++)
			{
				int				sector			= regions[i].sect_start;
				unsigned char	_spinnerDelay	= 0;

				printf("\t SD: Updating region %d(%s) ... ",
					   i,regions[i].filename);

				//------------------------------------------------------------
				// If the image file can be opened, read its contents and
				// write them to the SD card.  Otherwise just print
				// "SKIPPED".
				//------------------------------------------------------------
				if(fileAccessFunctions.open(regions[i].filename))
				{
					do
					{
						bytes = fileAccessFunctions.read(&data, READ_BUF_SIZE);

						if(!(_spinnerDelay--))
						{
							_spinnerDelay = 24;
							spinner();
						}

						if(bytes)
						{
							sd_write(inf.sub,
									 sector,
									 ((bytes + 511) / 512),
									 data);
							sector += ((bytes + 511) / 512);
						}

					}
					while(bytes >= 512);

					fileAccessFunctions.close();
					printf(" : DONE\n");
				}
				else
				{
					printf(" : SKIPPED\n");
				}
			}

			sd_close(inf.sub);

			break;

		default:
			printf("\t VALID UPDATE DESTINATION NOT FOUND\n");
			break;
	}
}

int updateLoadImage( DataFunctions dataFunctions, char *filename )
{
	int retVal = 0;
	int num_regions,i;
	fileAccessFunctions = dataFunctions;
	UPDATE_INTERFACE inf;

	memset((void*)regions,0,sizeof(regions));

	if (fileAccessFunctions.open(filename) && isUpdate() )
	{
        showProgress(1);
        printf("\n---------------------------------------------\n");
        printf("Loading Update Image: %12s \n", filename);

		if ( getDestination( &inf) )
			printf("\t Destination is type:%d sub:%d\n", inf.type, inf.sub);

        num_regions = regionRead();
        fileAccessFunctions.close();

        printf("\t %d Regions to update :\n\n",num_regions);
        for(i=0;i<num_regions;i++)
        	printf("\t\t Name:%s Sector:%d\n",
				   regions[i].filename, regions[i].sect_start);

		doUpdate(num_regions, inf);

        printf("---------------------------------------------\n");

		//--------------------------------------------------------------------
		// Indicate success to the caller.
		//--------------------------------------------------------------------
		retVal = 1;
	}

	return retVal;
}

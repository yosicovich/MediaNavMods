#ifndef ELF_H
#define ELF_H

#include "functions.h"

void *elfLoadImage(DataFunctions dataFunctions, const
                   char *fileName);

#endif    /*
*/

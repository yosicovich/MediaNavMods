#include "example.h"

static int usb_dev = 0;

int usbOpen(int dev)
{
	
	char buff[512];
	set_mass_storage_device(dev);
	usb_dev = dev;
	//printf("usbOpen dev=%d\n", dev);

	return 1;	
}

int usbEject()
{
	return 0;
}

int usbRead (int sect, int n, void *buf)
{
	//printf("usbRead  sector = 0x%x num_sec=0x%x buf=0x%x device=%d\n", sect, n, buf, usb_dev);
	return usb_stor_read(usb_dev, sect, n, buf);
}

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "bin.h"
#include "fat.h"

typedef struct BinImageInfo
{
    unsigned int address;
    unsigned int length;
}

BinImageInfo;

typedef struct BinRecordInfo
{
    unsigned int address;
    unsigned int length;
    unsigned int checksum;
}

BinRecordInfo;
BinImageInfo imageInfo;
BinRecordInfo recordInfo;
DataFunctions fileAccessFunctions;

static
int
binRead(void *buffer, int bytes)
{
    int bytesRead = fileAccessFunctions.read(buffer, bytes);
    updateProgress(bytesRead);
    return bytesRead;
}

int isBin()
{

    char sync[7];
    return binRead(sync, 7) &&
           sync[0] == 'B' &&
           sync[1] == '0'
           &&
           sync[2] == '0' &&
           sync[3] == '0' &&
           sync[4] == 'F'
           &&
           sync[5] == 'F' &&
           sync[6] == '\n';
}

void displayImageInfo()
{
    printf("\n-------------------------------\n");
    printf("Image Info:\n");
    printf(" Address: 0x%X\n", imageInfo.address);
    printf("  Length: %d bytes\n", imageInfo.length);
    printf("-------------------------------\n");
}

void displayRecordInfo()
{
    printf("\n-------------------------------\n");
    printf("Record Info:\n");
    printf("  Address: 0x%X\n", recordInfo.address);
    printf("   Length: %d bytes\n", recordInfo.length);
    printf(" Checksum: %X\n", recordInfo.checksum);
    printf("-------------------------------\n");
}

int readImageInfo()
{
    return binRead((char *) &imageInfo, sizeof(BinImageInfo));
}

int readRecord(void **entryPoint)
{
    char *address;
    int bytes, i, checksum;
    checksum = 0;

    if (bytes = binRead((char *) &recordInfo, sizeof(BinRecordInfo)))
    {
//   displayRecordInfo();

        if (recordInfo.address == 0)
        {
            *entryPoint = (void *) recordInfo.length;
            return 0;
        }
        else
        {
            address = (char *) recordInfo.address;

            if (bytes = binRead(address, recordInfo.length))
            {
                for (i = 0; i < bytes; ++i)
                {
                    checksum += address[i] & 0x00FF;
                }

                if (checksum != recordInfo.checksum)
                {
                    printf("\nError:  BIN checksum error!\n");
                    return 0;
                }

                return 1;
            }
        }
    }

    return 0;
}

void *readBin()
{
    void *entryPoint = (void *) 0;

    if (readImageInfo())
    {
        displayImageInfo();
        while (readRecord(&entryPoint))
            ;

        return entryPoint;
    }

    return 0;
}

void *binLoadImage(DataFunctions dataFunctions, const
                   char *fileName)
{
    void *entryPoint = (void *) 0;
    fileAccessFunctions = dataFunctions;
    showProgress(0);

    if (fileAccessFunctions.open(fileName) && isBin())
    {
        showProgress(1);
        printf("\n---------------------------------------------\n");
        printf("Loading Image: %12s (Format = CE-BIN)\n", fileName);

        if (entryPoint = readBin())
            printf("\nImage Loaded Successfully.\n");
        else
            printf("\nError Loading Image File.\n");

        printf("---------------------------------------------\n");
    }

    fileAccessFunctions.close();

    return entryPoint;
}

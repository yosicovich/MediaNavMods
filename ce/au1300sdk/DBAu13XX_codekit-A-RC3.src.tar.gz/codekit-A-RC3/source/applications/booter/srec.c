/*********************************************************************
 *
 * Copyright:
 * MOTOROLA, INC. All Rights Reserved.
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of Motorola, Inc. This
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, MOTOROLA
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY
 *  ACCOMPANYING WRITTEN MATERIALS.
 *
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL MOTOROLA BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.
 *
 *  Motorola assumes no responsibility for the maintenance and support
 *  of this software
 ********************************************************************/

/*
 * File:  srec.c
 * Purpose:  Routines to download Motorola S-Records.
 *
 * Notes:
 *
 *
 * Modifications:
 *
 */

#include "srec.h"
#include "util.h"

DataFunctions fileAccessFunctions;

/********************************************************************/

static
int
srecRead(void *buffer, int bytes)
{

    int bytesRead = fileAccessFunctions.read(buffer, bytes);
    
    updateProgress(bytesRead);
    
    return bytesRead;
    
}

int getStype(char *type)
{

    /*
     * This routine skips all characters until an `S' is received.
     * It then returns the next character.
     * This routine is here in order to not echo characters back
     * out as they are received during a download.
     *
     * This code ignores NL,CR-LF end of line issues by waiting
     * for 'S'.
     */
    char ch;
    
    if (srecRead(&ch, 1) && ch == 'S')
    {
    
        if (srecRead(&ch, 1))
        {
        
            *type = charToInt(ch);
            
            return 1;
            
        }
        
    }
    
    return 0;
    
}

void eatLine()
{

    char ch;
    
    while (srecRead(&ch, 1) && ch != 0x0A)
        ;
        
}


/********************************************************************/
int getSpair(char *value)
{

    static
    char ch[2];
    
    if (srecRead(&ch, 2))
    {
    
        *value = ((charToInt(ch[0]) << 4) | charToInt(ch[1]));
        
        return 1;
        
    }
    
    return 0;
    
}

int isSrec()
{

    DPRINTF("\n");
    
    char ch[2];
    
    if (srecRead(&ch, 2))
    {
    
        if (ch[0] == 'S' && ch[1] == '0')
        {
        
            eatLine();
            
            return 1;
            
        }
        
    }
    
    DPRINTF("FAILURE!\n");
    
    return 0;
    
}

void *readSrec()
{

    int i;
    
    char type, length, checksum, ch;
    
    char *address;
    
//      printf("CH ADDR: %X\n", &ch);

    while (1)  //read s-records until return from inside loop
    {
    
        if (!getStype(&type))
        
            return (void *) 0;
            
        /* Get record length */
        if (!getSpair(&length))
        
            return (void *) 0;
            
        checksum = length;
        
        switch (type)
        {
        
            case
            
                    1:
                    
            case
            
                    2:
                    
            case
            
                    3:
                    
                address = (char *) 0;
                
                for (i = 0; i <= type; ++i) //formulate address, number of bytes in address based on 'type'
                {
                
                    if (!getSpair(&ch)) //get one byte of address
                        return (void *) 0;
                        
                    address =
                        (char *) (((int) address << 8) | (ch & 0x00FF));
                        
                    /* maintain 8-bit checksum */
                    checksum += ch;
                    
                    length--;
                    
                }
                //printf("Dest addr: %X\n", address);
                for (i = 0; i < (length - 1); ++i) //read remaining bytes (data) minus trailing checksum into memory
                {
                
                    if (!getSpair(address)) //read byte into memory
                        return (void *) 0;
                        
                    //maintain checksum by reading data written to memory back
                    checksum += *address;
                    
                    ++address;
                    
                }
                /* verify checksum */
                if (!getSpair(&ch)) //read checksum byte
                    return (void *) 0;
                    
                if (((ch - ~checksum) & 0x00FF) != 0)
                {
                
                    printf("\nError:  S-record checksum error!\n");
                    
                    return (void *) 0;
                    
                }
                
                break;
                
            case
            
                    7:
                    
            case
            
                    8:
                    
            case
            
                    9:
                    
                type = 10 - type;
                
                while (type-- >= 0)
                {
                
                    if (!getSpair(&ch))
                    
                        return (void *) 0;
                        
                    address = (char *) (((int) address << 8) | (ch & 0x00FF));
                    
                    checksum += ch;
                    
                    length--;
                    
                }
                
                while (length-- > 1)
                {
                
                    if (!getSpair(&ch))
                    
                        return (void *) 0;
                        
                    checksum += ch;
                    
                }
                
                if (!getSpair(&ch))
                
                    return (void *) 0;
                    
                if (((ch - ~checksum) & 0x00FF) != 0)
                {
                
                    printf("\nError:  S-record checksum error!\n");
                    
                    return (void *) 0;
                    
                }
                else
                
                    return (void *) address;
                    
                break;
                
            case
            
                    0:
                    
            case
            
                    4:
                    
            case
            
                    5:
                    
            case
            
                    6:
                    
            default
            
                    :
                    
                break;
                
        }
        
        eatLine();
        
    }
    
    return (void *) 0;
    
}

/********************************************************************/

void *srecLoadImage(DataFunctions dataFunctions, const
                    char *fileName)
{

    void *entryPoint = (void *) 0;
    
    fileAccessFunctions = dataFunctions;
    
    showProgress(0);
    
    if (fileAccessFunctions.open(fileName) && isSrec())
    {
    
        showProgress(1);
        
        printf("\n---------------------------------------------\n");
        
        printf("Loading Image: %12s   (Format = SREC)\n", fileName);
        
        if (entryPoint = readSrec())
        
            printf("\nImage Loaded Successfully.\n");
            
        else
        
            printf("\nError Loading Image File.\n");
            
        printf("---------------------------------------------\n");
        
    }
    
    fileAccessFunctions.close();
    
    return entryPoint;
    
}



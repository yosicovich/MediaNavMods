/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "util.h"
#include "example.h"

int	KernelImageSize=0;
int progress;

static
int dots;

static
int oldMode;

void stringCopy(const
                char *source, char *dest)
{

    int i;

    for (i = 0; source[i] != 0; ++i)
    {

        dest[i] = source[i];

    }

    dest[i] = 0;

}

void memCopy(const

             void *src, void *dest, int bytes)
{

    int i;

    const
    char *charSrc = (char *) src;

    char *charDest = (char *) dest;

    for (i = 0; i < bytes; ++i)

        charDest[i] = charSrc[i];

}

void memFill(void *dest, int bytes, char value)
{

    int i;

    char *charDest = (char *) dest;

    for (i = 0; i < bytes; ++i)

        charDest[i] = value;

}

void memDisp(void *src, int bytes)
{

    char *charSrc = (char *) src;

    int i;

    for (i = 0; i < bytes; ++i)
    {

        if (i % 16 == 0)

            printf("\n");

        if ((charSrc[i] & 0x0FF) <= 0x0F)

            printf("0");

        printf("%X ", charSrc[i] & 0x0FF);

    }

}

int stringLength(const
                 char *string)
{

    int i;

    for (i = 0; string[i] != 0; ++i)
        ;

    return i;

}

int stringToInt(const

                char *string)
{

    int value = 0;

    int i;

    for (i = 0; string[i] != 0; ++i)
    {

        value = value << 4;

        value |= charToInt(string[i]);

    }

    return value;

}

int charToInt(const

              char ch)
{

    switch (ch)
    {

        case '0'

                :

        case '1'

                :

        case '2'

                :

        case '3'

                :

        case '4'

                :

        case '5'

                :

        case '6'

                :

        case '7'

                :

        case '8'

                :

        case '9'

                :

            return (ch - '0');

            break;

        case 'A'

                :

        case 'a'

                :

            return 10;

            break;

        case 'B'

                :

        case 'b'

                :

            return 11;

            break;

        case 'C'

                :

        case 'c'

                :

            return 12;

            break;

        case 'D'

                :

        case 'd'

                :

            return 13;

            break;

        case 'E'

                :

        case 'e'

                :

            return 14;

            break;

        case 'F'

                :

        case 'f'

                :

            return 15;

            break;

        default

                :

            return 0;

    }

}

void showProgress(int show)
{

    if (show)
        progress = 1;
    else
        progress = 0;

}

void updateProgress(int bytesRead)
{
    static int prev_progress = 0;

    if (progress)
    {
        progress += bytesRead;

        lcdUpdateStatus();
        if ( (prev_progress + STATUS_DOT_INTERVAL)  <  progress )
        {
			static int dotcnt = 0;

			if (!((++dotcnt)%STATUS_LINE_INTERVAL)) printf("\r\n");
            printf(".");

            prev_progress = progress;
        }

    }

}


/*int setPageMode(int on)
{
 uint32* configReg = (uint32*) MEM_STCFG0_ADDRESS;
 int oldMode = (*configReg) & MEM_STCFG_PM_BIT ? 1 : 0; //read page mode bit

 if(oldMode != on)
  if(on)
   (*configReg) |=  MEM_STCFG_PM_BIT;  //turn page mode on
  else
   (*configReg) &= ~MEM_STCFG_PM_BIT;  //trun page mode off

 return oldMode;
}*/

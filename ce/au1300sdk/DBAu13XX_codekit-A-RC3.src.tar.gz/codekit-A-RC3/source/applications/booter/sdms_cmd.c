/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "sdms_cmd.h"
#include "sdms.h"

// CMD00 GO_IDLE_STATE
void sdms_CMD00(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear all status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg;

    sync();

    sdms_cmd(base) = 0x00000001; // CMD00 GO_IDLE_STATE

    sync();
}


// CMD02 ALL_SEND_CID
void sdms_CMD02(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg;

    sync();

    sdms_cmd(base) = 0x00020201; // CMD02 ALL_SEND_CID

    sync();

//      printf("CMD02  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD03 SEND_RELATIVE_ADDR
void sdms_CMD03(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg;

    sync();

    sdms_cmd(base) = 0x00060301; // CMD03 SEND_RELATIVE_ADDR

    sync();

//      printf("CMD03  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD07 SELECT/DESELECT CARD, R1b response
void sdms_CMD07(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg;

    sync();

//      sdms_cmd(base) = 0x00810701;                    // SELECT/DESELECT CARD
    sdms_cmd(base) = 0x00010701; // CMD07 SELECT/DESELECT CARD

    sync();

//      printf("CMD07  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD09 SEND_CSD
void sdms_CMD09(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg;

    sync();

    sdms_cmd(base) = 0x00020901; // CMD09 SEND_CSD

    sync();

//      printf("CMD09  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD13 SEND_STATUS
void sdms_CMD13(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg;

    sync();

    sdms_cmd(base) = 0x00010d01; // CMD13 SEND_STATUS

    sync();

//      printf("CMD13  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD16 SET_BLOCKLEN
void sdms_CMD16(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg;

    sync();

    sdms_cmd(base) = 0x00011001; // CMD16 SET_BLOCKLEN

    sync();
}


// CMD17 READ_SINGLE_BLOCK
void sdms_CMD17(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000020)
        {}   // wait when DBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear all status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg; // address of read

    sync();

    sdms_cmd(base) = 0x00011121; // CMD17 READ_SINGLE_BLOCK

    sync();

//      printf("CMD17  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD18 READ_MULTIPLE_BLOCK
void sdms_CMD18(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000020)
        {}   // wait when DBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear all status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg; // address of read

    sync();

    sdms_cmd(base) = 0x00011241; // CMD18 READ_MULTIPLE_BLOCK

    sync();

//      printf("CMD18  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD24 WRITE_BLOCK
void sdms_CMD24(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000020)
        {}   // wait when DBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear all status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg; // address of write

    sync();

    sdms_cmd(base) = 0x00011811; // CMD24 WRITE_BLOCK

    sync();

//      printf("CMD24  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD25 WRITE_MULTIPLE_BLOCK
void sdms_CMD25(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000020)
        {}   // wait when DBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear all status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg; // address of write

    sync();

    sdms_cmd(base) = 0x00011931; // CMD25 WRITE_MULTIPLE_BLOCK

    sync();

//      printf("CMD25  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD32 ERASE_WR_BLK_START
void sdms_CMD32(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg; // starting address of erase

    sync();

    sdms_cmd(base) = 0x00012001; // CMD32 ERASE_WR_BLK_START

    sync();

//      printf("CMD32  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD33 ERASE_WR_BLK_END
void sdms_CMD33(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg; // end address of erase

    sync();

    sdms_cmd(base) = 0x00012101; // CMD33 ERASE_WR_BLK_END

    sync();

//      printf("CMD33  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD38 ERASE, R1b response
void sdms_CMD38(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg;

    sync();

    sdms_cmd(base) = 0x00812601; // CMD38 ERASE

    sync();

//      printf("CMD38  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// CMD55 APP_CMD
void sdms_CMD55(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear all status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg;

    sync();

    sdms_cmd(base) = 0x00013701;

    sync();

//      printf("CMD55  cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// ACMD06 SET_BUS_WIDTH
void sdms_ACMD06(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit

    sdms_cmdarg(base) = arg;

    sync();

    sdms_cmd(base) = 0x00010601; // ACMD06 SET_BUS_WIDTH

    sync();

//      printf("ACMD06 cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// ACMD41 SD_APP_OP_COND
void sdms_ACMD41(int base, int arg)
{
    int resp, i;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait until not busy

    while (sdms_status(base) & 0x00000010)
        {}   // wait until not busy

    // wait 1 ms
    i = 0;

    while (i < 400000)
    {
        i = i + 1;
    }

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit
    sync();

    sdms_cmdarg(base) = arg;
    sync();
    sdms_cmd(base) = 0x00032901; // ACMD41 SD_APP_OP_COND
    sync();
//      printf("ACMD41 cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}


// ACMD51 SEND_SCR
void sdms_ACMD51(int base, int arg)
{
    int resp;

    while (sdms_cmd(base) & 0x00000001)
        {}   // wait when CBSY = 1

    while (sdms_status(base) & 0x00000010)
        {}   // wait when CRBSY = 1

    sdms_status(base) = 0xffffffff; // clear status bits

    resp = sdms_resp0(base); // clear RRDY bit

//      printf("SCR: sdms_status = 0x%08x\n", sdms_status(base));

    sdms_cmdarg(base) = arg;

    sync();

    sdms_cmd(base) = 0x00013321; // ACMD51 SEND_SCR

    sync();

//      printf("ACMD51 cmd = 0x%08x, argument = 0x%08x\n", sdms_cmd(base), sdms_cmdarg(base));
}

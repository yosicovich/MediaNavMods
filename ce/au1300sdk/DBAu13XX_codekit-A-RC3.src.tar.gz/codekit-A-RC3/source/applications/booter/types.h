/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef TYPES_H
#define TYPES_H

#define  BOARD_PB1000 0
#define  BOARD_KR1500 1
#define  BOARD_PB1500 2
#define  BOARD_PB1100 3
#define  BOARD_MERLOT 4
#define  BOARD_SYRAH  5
#define  BOARD_ZINFANDEL 6

#define MAX_FILENAME 13

#define TRUE 1
#define FALSE 0
#define NULL 0

#define PCMCIA 1
#define IDE  2
#define SD  3
#define USBMS		4

#define STATUS_DOT_INTERVAL  100000 //bytes read per status dot
#define STATUS_LINE_INTERVAL 40 //status dots per line

#define MEM_STCFG0_ADDRESS 0xB4001000
#define MEM_STCFG_PM_BIT 0x010

typedef int DEVICE_TYPE;

typedef signed char int8;

typedef signed short int16;

typedef signed int int32;

typedef unsigned char uint8;

typedef unsigned short uint16;

typedef unsigned int uint32;

#endif    /*
*/

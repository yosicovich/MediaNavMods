/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "partition.h"
#include "example.h"

typedef struct Partition
{
    uint8 active;
    uint8 startingCHS[3];
    uint8 type;
    uint8 endingCHS[3];
    uint32 start;
    uint32 size;
}

Partition;

typedef struct MBR
{
    uint8 bootInfo[446] __attribute__ ((packed)); //byte align structure
    Partition partitionTable[4] __attribute__ ((packed));
    uint16 signature __attribute__ ((packed));
}

MBR;

int partitionIsType(enum PartitionType type, uint8 code)
{
    DPRINTF("type: %X, code: %X\n", type, code);
    //Type codes obtained from: http://www.win.tue.nl/~aeb/partitions/partition_types-1.html

    switch (type)
    {
        case

                FAT:
            return
                code == 0x01 ||
                code == 0x04 ||
                code == 0x05 ||
                code == 0x06 ||
                code == 0x0B ||
                code == 0x0C ||
                code == 0x0E ||
                code == 0x11 ||
                code == 0x14 ||
                code == 0x16 || code == 0x1B || code == 0x1C || code == 0x1E;

            break;

        case

                EXT2:
            return code == 0x82;

            break;
    }

    return 0;
}

int partitionGetRootSector(enum PartitionType type, int partitionNumber,
                           DISK_READ_FUNCTION read)
{
    DPRINTF("type: %X, partition: %d\n", type, partitionNumber);
    MBR mbr;

    if (read(0, 1, &mbr))
        if (partitionIsType
                (type, mbr.partitionTable[partitionNumber].type))
            return mbr.partitionTable[partitionNumber].start;

    if (mbr.bootInfo[21] == 0xF8) // SD doesn't have MBR; medium identifier (offset 0x21) should be 0xF8
        return 0;  // partition boot sector is in sector 0

    return -1;
}

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef SDMS_H
#define SDMS_H

#include "example.h"

#define SDMS_BASE       0xb0600000
#define SDMS1_BASE      0xb0680000

#define SD_TXFIFO      0x0000
#define SD_RXFIFO      0x0004
#define SD_CONFIG      0x0008
#define SD_ENABLE      0x000c
#define SD_CTRL        0x0010
#define SD_BLKSZE      0x0014
#define SD_STATUS      0x0018
#define SD_DEBUG       0x001c
#define SD_CMD         0x0020
#define SD_CMDARG      0x0024
#define SD_RESP2       0x002c
#define SD_RESP1       0x0030
#define SD_RESP0       0x0034
#define SD_TOCNT       0x0038

#define sync() asm("sync")
#define wait() asm("wait")
#define nop() asm("nop")

#define REG32(addr) (*(volatile unsigned int *)(addr))

//
// GLOBAL VARIABLES
//
#define sd0 SDMS_BASE
#define sd1 SDMS1_BASE

#define sdms_txfifo(base)  REG32(base + SD_TXFIFO)
#define sdms_rxfifo(base)  REG32(base + SD_RXFIFO)
#define sdms_config(base)  REG32(base + SD_CONFIG)
#define sdms_enable(base)  REG32(base + SD_ENABLE)
#define sdms_ctrl(base)    REG32(base + SD_CTRL)
#define sdms_blksze(base)  REG32(base + SD_BLKSZE)
#define sdms_status(base)  REG32(base + SD_STATUS)
#define sdms_debug(base)   REG32(base + SD_DEBUG)
#define sdms_cmd(base)     REG32(base + SD_CMD)
#define sdms_cmdarg(base)  REG32(base + SD_CMDARG)
#define sdms_resp3(base)   REG32(base + SD_RESP3)
#define sdms_resp2(base)   REG32(base + SD_RESP2)
#define sdms_resp1(base)   REG32(base + SD_RESP1)
#define sdms_resp0(base)   REG32(base + SD_RESP0)
#define sdms_tocnt(base)   REG32(base + SD_TOCNT)

//
// interrupt business
//
#define config0_read    REG32(IC0_BASE + IC_CFG0RD)
#define config0_set     REG32(IC0_BASE + IC_CFG0SET)
#define config0_clear    REG32(IC0_BASE + IC_CFG0CLR)

#define config1_read    REG32(IC0_BASE + IC_CFG1RD)
#define config1_set     REG32(IC0_BASE + IC_CFG1SET)
#define config1_clear    REG32(IC0_BASE + IC_CFG1CLR)

#define config2_read    REG32(IC0_BASE + IC_CFG2RD)
#define config2_set     REG32(IC0_BASE + IC_CFG2SET)
#define config2_clear    REG32(IC0_BASE + IC_CFG2CLR)

#define request0_int    REG32(IC0_BASE + IC_REQ0INT)

#define source_read     REG32(IC0_BASE + IC_SRCRD)
#define source_set     REG32(IC0_BASE + IC_SRCSET)
#define source_clear    REG32(IC0_BASE + IC_SRCCLR)

#define request1_int    REG32(IC0_BASE + IC_REQ1INT)

#define assign_request_read   REG32(IC0_BASE + IC_ASSIGNRD)
#define assign_request_set   REG32(IC0_BASE + IC_ASSIGNSET)
#define assign_request_clear  REG32(IC0_BASE + IC_ASSIGNCLR)

#define wakeup_read     REG32(IC0_BASE + IC_WAKERD)
#define wakeup_set     REG32(IC0_BASE + IC_WAKESET)
#define wakeup_clear    REG32(IC0_BASE + IC_WAKECLR)

#define mask_read     REG32(IC0_BASE + IC_MASKRD)
#define mask_set     REG32(IC0_BASE + IC_MASKSET)
#define mask_clear     REG32(IC0_BASE + IC_MASKCLR)

#define rising_edge_detect   REG32(IC0_BASE + IC_RISINGRD)
#define rising_edge_detect_clear REG32(IC0_BASE + IC_RISINGCLR)

#define falling_edge_detect   REG32(IC0_BASE + IC_FALLINGRD)
#define falling_edge_detect_clear REG32(IC0_BASE + IC_FALLINGCLR)

#define test_bit     REG32(IC0_BASE + 0x0080)


#define IC0_BASE 0xB0400000
#define IC1_BASE 0xB1800000

/*
 * Register Offsets
 */
#define IC_CFG0RD  (0x0040)
#define IC_CFG0SET  (0x0040)
#define IC_CFG0CLR  (0x0044)
#define IC_CFG1RD  (0x0048)
#define IC_CFG1SET  (0x0048)
#define IC_CFG1CLR  (0x004C)
#define IC_CFG2RD  (0x0050)
#define IC_CFG2SET  (0x0050)
#define IC_CFG2CLR  (0x0054)
#define IC_REQ0INT  (0x0054)
#define IC_SRCRD  (0x0058)
#define IC_SRCSET  (0x0058)
#define IC_SRCCLR  (0x005C)
#define IC_REQ1INT  (0x005C)
#define IC_ASSIGNRD  (0x0060)
#define IC_ASSIGNSET (0x0060)
#define IC_ASSIGNCLR (0x0064)
#define IC_WAKERD  (0x0068)
#define IC_WAKESET  (0x0068)
#define IC_WAKECLR  (0x006C)
#define IC_MASKRD  (0x0070)
#define IC_MASKSET  (0x0070)
#define IC_MASKCLR  (0x0074)
#define IC_RISINGRD  (0x0078)
#define IC_RISINGCLR (0x0078)
#define IC_FALLINGRD (0x007C)
#define IC_FALLINGCLR (0x007C)

/*
 * Interrupt Controller 0 mappings
 */
#define IC0_UART0     0
#define IC0_UART1     1
#define IC0_UART2     2
#define IC0_UART3     3
#define IC0_SSI0     4
#define IC0_SSI1     5
#define IC0_DMA0     6
#define IC0_DMA1     7
#define IC0_DMA2     8
#define IC0_DMA3     9
#define IC0_DMA4     10
#define IC0_DMA5     11
#define IC0_DMA6     12
#define IC0_DMA7     13
#define IC0_PC0      14
#define IC0_TOY      14
#define IC0_PC0Match0    15
#define IC0_PC0Match1    16
#define IC0_PC0Match2    17
#define IC0_PC1      18
#define IC0_RTC      18
#define IC0_PC1Match0      19
#define IC0_PC1Match1      20
#define IC0_PC1Match2      21
#define IC0_IRDATransmit     22
#define IC0_IRDAReceive      23
#define IC0_USBDevice      24
#define IC0_USBDeviceSuspend    25
#define IC0_USBHost     26
#define IC0_ACSYNC     27
#define IC0_MAC0     28
#define IC0_MAC1     29
#define IC0_I2S      30
#define IC0_AC97     31

#define IC0_UART0_MASK    (1<<IC0_UART0)
#define IC0_UART1_MASK    (1<<IC0_UART1)
#define IC0_UART2_MASK    (1<<IC0_UART2)
#define IC0_UART3_MASK    (1<<IC0_UART3)
#define IC0_SSI0_MASK    (1<<IC0_SSI0)
#define IC0_SSI1_MASK    (1<<IC0_SSI1)
#define IC0_DMA0_MASK    (1<<IC0_DMA0)
#define IC0_DMA1_MASK    (1<<IC0_DMA1)
#define IC0_DMA2_MASK    (1<<IC0_DMA2)
#define IC0_DMA3_MASK    (1<<IC0_DMA3)
#define IC0_DMA4_MASK    (1<<IC0_DMA4)
#define IC0_DMA5_MASK    (1<<IC0_DMA5)
#define IC0_DMA6_MASK    (1<<IC0_DMA6)
#define IC0_DMA7_MASK    (1<<IC0_DMA7)
#define IC0_PC0_MASK    (1<<IC0_PC0)
#define IC0_TOY_MASK    (1<<IC0_TOY)
#define IC0_PC0Match0_MASK   (1<<IC0_PC0Match0)
#define IC0_PC0Match1_MASK   (1<<IC0_PC0Match1)
#define IC0_PC0Match2_MASK   (1<<IC0_PC0Match2)
#define IC0_PC1_MASK    (1<<IC0_PC1)
#define IC0_RTC_MASK    (1<<IC0_RTC)
#define IC0_PC1Match0_MASK   (1<<IC0_PC1Match0)
#define IC0_PC1Match1_MASK   (1<<IC0_PC1Match1)
#define IC0_PC1Match2_MASK   (1<<IC0_PC1Match2)
#define IC0_IRDATransmit_MASK     (1<<IC0_IRDATransmit)
#define IC0_IRDAReceive_MASK     (1<<IC0_IRDAReceive)
#define IC0_USBDevice_MASK   (1<<IC0_USBDevice)
#define IC0_USBDeviceSuspend_MASK   (1<<IC0_USBDeviceSuspend)
#define IC0_USBHost_MASK   (1<<IC0_USBHost)
#define IC0_ACSYNC_MASK    (1<<IC0_ACSYNC)
#define IC0_MAC0_MASK    (1<<IC0_MAC0)
#define IC0_MAC1_MASK    (1<<IC0_MAC1)
#define IC0_I2S_MASK    (1<<IC0_I2S)
#define IC0_AC97_MASK    (1<<IC0_AC97)


typedef unsigned int uchar;
typedef unsigned int *puchar;
typedef struct _sdms_param
{
    uint32 rca;
    uint32 bus_width;
    uint32 rd_blk_len;
    uint32 rd_blk_partial;
    uint32 wr_blk_len;
    uint32 wr_blk_partial;
    uint32 mem_capacity;
}
sdms_param;


//sdms_param sdmsParam (int base, int rca);
//int sdmsInit (int base);
int sdmsOpen(int slot);
int sdmsEject();
int sdmsRead(int sect, int n, void *buf);

#define SDMS_DEBUG 0

#endif

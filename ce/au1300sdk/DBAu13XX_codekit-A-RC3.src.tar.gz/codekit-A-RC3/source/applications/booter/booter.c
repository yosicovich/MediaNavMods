/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "booter.h"

#include "example.h"
#include "util.h"

#include "filesystem.h"
#include "flash.h"

#include "srec.h"
#include "elf.h"
#include "bin.h"

#include "pcmcia.h"
#include "util.h"

#ifdef LCD_STATUS
#include "lcd_control.h"
#endif

#include "window.h"
#include "pixel.h"

#if defined(CONFIG_BOOTER_SPLASH) && !defined(CONFIG_SPLASH_IN_FLASH)
 #include "splash1.c"
#endif

#include "usb.h"
/* CFB REMOVE
#include "usb_ohci.h"
*/

#define  APP_NAME   "AutoBoot"
#define  APP_REVISION "A-RC3"


#define SCREEN_WIDTH 800
#define SCREEN_HIGHT 480
#define BPP		   32
#define LINE_SIZE  3200

#define FRAMEBUF   0xA8800000

#define STATUS_BAR_START		464
#define STATUS_BAR_HEIGHT		16

#define STATUS_TICK_SIZE_IN_PIXELS  0

#define USB_BASE_PHYS_ADDR				0x14021000
#define USB_OHCI0BASE_PHYS_ADDR			0x14020400
#define USB_OHCI1BASE_PHYS_ADDR			0x14020400
#define LOCAL_KSEG1						0xA0000000

extern int KernelImageSize;
extern int progress;

void static inline au_iowrite16(u16 val, volatile u16 *reg)
{
    *reg = val;
}

static inline u16 au_ioread16(volatile u16 *reg)
{
    return *reg;
}

void static inline au_iowrite32(u32 val, volatile u32 *reg)
{
    *reg = val;
}

static inline u32 au_ioread32(volatile u32 *reg)
{
    return *reg;
}

static inline void au_clear_bits_16(u16 mask, volatile u16 *reg)
{
    au_iowrite16((au_ioread16(reg) & ~mask), reg);
}

static inline void au_clear_bits_32(u32 mask, volatile u32 *reg)
{
    au_iowrite32((au_ioread32(reg) & ~mask), reg);
}

void lcdUpdateStatus(void)
{
    int w;
    static int prev_w=-1;

#ifdef CONFIG_BOOTER_SPLASH

    if ( 0!=KernelImageSize )
    {
        w = progress/(KernelImageSize/SCREEN_WIDTH);
        if ( prev_w != w )
        {
#ifdef CONFIG_SPLASH_IN_FLASH
            window_fill_rectangle(0, BUFFER_0, 0, STATUS_BAR_START, w, STATUS_BAR_HEIGHT, 0xFF, 0x23, 0x3E, 0x99);
#else
            window_fill_rectangle(0, BUFFER_0, 0, STATUS_BAR_START, w, STATUS_BAR_HEIGHT, 0xFF, 0x99, 0x3E, 0x23);
#endif
            prev_w = w;
        }
    }
#endif // CONFIG_BOOTER_SPLASH

}

void displayWelcomeScreen()
{

    printf("\n\n%s, Revision %s\n", APP_NAME, APP_REVISION);
#ifdef CONFIG_BOOTER_SPLASH

#ifdef CONFIG_SPLASH_IN_FLASH
    memCopy(CONFIG_SPLASH_IN_FLASH_ADDR, FRAMEBUF, 0x200000);
#else
	memCopy(gimp_image.pixel_data, FRAMEBUF, 0x200000);
#endif

    window_init();
    window_enable(0, 1);
    window_set_pixel_ordering(0, PO_0);
#if 0
    window_set_buffer_format(0,PF_16BPP_5_6_5);
#else
    window_set_buffer_format(0,PF_32BPP);
#endif

#ifndef CONFIG_SPLASH_IN_FLASH
	// gimp saves in BGR format
	window_set_color_channel_orientation(0, 1);
#endif

    window_set_buffer_line_width(0, SCREEN_WIDTH*2);
    window_set_size(0, SCREEN_WIDTH, SCREEN_HIGHT);
    window_set_buffer(0, BUFFER_0, (FRAME_BUFFER_ADDRESS) FRAMEBUF );
#endif // CONFIG_BOOTER_SPLASH
}

void displayNoImage()
{
    printf("Unable to locate any bootable images\n");

#ifdef _LCD_OUTPUT_
    lcdDisplayNoImage();
#endif
}

void displayEntryPoint(void *entryPoint)
{
    printf("Program Entry Point: %X\n", entryPoint);
    printf("Executing Application\n");

#ifdef _LCD_OUTPUT_
    lcdDisplayEntryPoint(entryPoint);
#endif
}

char *t_argv[] = { 0 };

char *t_envp[] =
{
    "MAC=0",
    "bootfile=/booter.rec",
    "bootprot=tftp",
    "bootserport=tty0",
    "bootserver=192.168.0.1",
    "ethaddr=00.00.1a.19.0b.f7",
    "gateway=192.168.0.1",
    "ipaddr=192.168.0.2",
    "memsize=0x08000000",
    "modetty0=115200,n,8,1,none",
    "modetty1=115200,n,8,1,none",
    "prompt=YAMON",
    "subnetmask=255.255.255.0",
    0,
};


int execute(void *address, int argc, char *argv[], char *env[])
{
    typedef int (*EXECUTE) (int, char **, char **);
    EXECUTE executeFunction = (EXECUTE) address;

    if (argc == NULL)
    {
        argc = 1;
        argv = t_argv;
        env = t_envp;
    }

    cpuDisableIrqs();

    return executeFunction(argc, (char **) argv, (char **) env);
}

void *findImage(const char **files,
				const char **addresses,
                void *jumpAddress)
{
	AU13XX_USB	*au13xx_usb;
    void		*entryPoint;

	//-----------------------------------------------------------------------
	// If the loadXXX() routine indicates that the the image was updated,
	// repeat from the first device in the device list the search for a
	// bootable image.  Note, this relies on button S2 not being held down
	// for the whole period the image is updated (that would be
	// unreasonable - for the update takes quite a few minutes).  If said
	// button is held down still, then the update will be repeated.
	//-----------------------------------------------------------------------
	do
	{
#if defined(CONFIG_HWBLOCK_USB)
		(entryPoint = loadUSBMS(files)) ||
#endif

#if defined(CONFIG_HWBLOCK_PCMCIA)
    	(entryPoint = loadPCMCIA(files)) ||
#endif

#if defined(CONFIG_HWBLOCK_SD)
    	(entryPoint = loadSDMS(files)) ||
#endif

/*
#if defined(CONFIG_HWBLOCK_IDE)
    	(entryPoint = loadIDE(files)) ||
#endif
*/

#if defined(CONFIG_HWBLOCK_NOR_FLASH) | defined(CONFIG_HWBLOCK_NAND_FLASH)
    	(entryPoint = loadFlash(addresses));
#endif
	}
	while(entryPoint == (void *)0xFFFFFFFF);

	if(!entryPoint)
	{
  	  entryPoint = jumpAddress;
	}

	//-----------------------------------------------------------------------
	// Having found the image (hopefully), ensure that the USB device is
	// shut off, so as to prevent spurious interrupts during the Linux
	// kernel startup (not sure if this affects MS Windows CE).
	//-----------------------------------------------------------------------
	au13xx_usb	= (LOCAL_KSEG1 | USB_BASE_PHYS_ADDR);

    /*
     * Disable interrupts
     */
    au_clear_bits_32(USB_INTR_OHCI0, &au13xx_usb->intr_enable);
    au_clear_bits_32(USB_INTR_OHCI1, &au13xx_usb->intr_enable);

    /*
     * Put the host controller block into reset
     */
    au_clear_bits_32(USB_DWC_CTRL1_HSTRS, &au13xx_usb->dwc_ctrl1);

	au_clear_bits_32(USB_DWC_CTRL3_OHC1_CLKEN, &au13xx_usb->dwc_ctrl3);
    au_clear_bits_32(USB_DWC_CTRL3_OHC0_CLKEN, &au13xx_usb->dwc_ctrl3);

    /*
     * Enable all of the PHYs
     */
    au_clear_bits_32(USB_DWC_CTRL2_PHYRS | USB_DWC_CTRL2_PHY0RS | USB_DWC_CTRL2_PH1RS,
               &au13xx_usb->dwc_ctrl2);

	//-----------------------------------------------------------------------
	// Toggling the VBUS power bit.
	//-----------------------------------------------------------------------
	*(unsigned short *)(0xB980000C)	&= ~0x8000;

    return entryPoint;
}

void *loadImage(DataFunctions functions, const char *fileName)
{
    void *entryPoint;
	uint32 *pGPIOBaseAddress = (uint32 *)0xB0200000; // S2 GPIO reg. address

	if ( updateLoadImage(functions, fileName ) )
	{
		printf("\n\n\tUpdate successful\n");

		//-------------------------------------------------------------------
		// Indicate a successful update to the caller.  Here's hoping
		// 0xFFFFFFFF is not a legal entrypoint.
		//-------------------------------------------------------------------
		return (void *)0xFFFFFFFF;
	}

	//------------------------------------------------------------------------
	// If button S2 is being held down during powerup, skip looking for a
	// boot image.
	//
	// NOTE: this relies on the GPIO pin being configured as an input upon
	// powerup.
	//------------------------------------------------------------------------
	if (*pGPIOBaseAddress & 0x00000001)
	{
		return (void *)0;
	}

    if ( (entryPoint = binLoadImage(functions, fileName)) ||
         (entryPoint = srecLoadImage(functions, fileName)) ||
         (entryPoint = elfLoadImage(functions, fileName)))
        return entryPoint;

    return (void *) 0;
}

#if defined(CONFIG_HWBLOCK_NOR_FLASH) | defined(CONFIG_HWBLOCK_NAND_FLASH)
void *loadFlash(const
                char **addresses)
{
    int i;
    void *entryPoint = 0;

    for (i = 0; addresses[i] != 0 && !entryPoint; ++i)
    {
        entryPoint = loadImage(getFlashFunctions(), addresses[i]);
    }

    return entryPoint;
}

#endif

#if defined(CONFIG_HWBLOCK_PCMCIA)
void *loadPCMCIA(const
                 char **files)
{
    int i, j, slots;
    void *entryPoint = 0;

    for (i = 0; i < 2 && !entryPoint; ++i)
    {
        if (filesystemLoad(PCMCIA, i))
            for (j = 0; files[j] != 0 && !entryPoint; ++j)
                entryPoint = loadImage(getFilesystemFunctions(), files[j]);

        filesystemClose(PCMCIA, i);
    }

    return entryPoint;
}

#endif

#if defined(CONFIG_HWBLOCK_IDE)
void *loadIDE(const
              char **files)
{
    int i, j, disks;
    void *entryPoint = 0;

    if (filesystemLoad(IDE, 0))
        for (j = 0; files[j] != 0 && !entryPoint; ++j)
            entryPoint = loadImage(getFilesystemFunctions(), files[j]);

    filesystemClose(IDE, 0);

    return entryPoint;
}

#endif

#define USB_MAX_DEVICES  4

#if defined(CONFIG_HWBLOCK_USB)
void *loadUSBMS(const char **files)
{
    int i, j, disks;
    void *entryPoint = NULL;;

    /*Initialize USB subsystem and get the registered devices.*/	
    printf("Initalizing USB subsystem\n");	
    init_usb_subsystem();	

    for (disks=0 ; disks< USB_MAX_DEVICES && !entryPoint; disks++){
       if (filesystemLoad(USBMS, disks)){
             printf("Finding file in USB mass storage device\n");
	     for (j = 0; files[j] != 0 && !entryPoint; ++j)
	          entryPoint = loadImage(getFilesystemFunctions(), files[j]);
             }
        filesystemClose(USBMS, disks); 
    }

    return entryPoint;
}
#endif

#if defined(CONFIG_HWBLOCK_SD)
void *loadSDMS(const
               char **files)
{
    int i, j, slots;
    void *entryPoint = 0;

// TEO: enabling support for both SD0, the eMMC device,
// and the SD slot for an external device.
// CTG: Go in reverse order so eMMC is last on list :)

    for (i = 1; i >= 0 && !entryPoint; --i)
    {
        if (filesystemLoad(SDMS, i))
            for (j = 0; files[j] != 0 && !entryPoint; ++j)
                entryPoint = loadImage(getFilesystemFunctions(), files[j]);

        filesystemClose(SDMS, i);
    }
    return entryPoint;
}

#endif

void *loadBootImage()
{
    const
    char **files;

    const
    char **addresses;

    void *jumpAddress;

    if (platformGetBootData(&files, &addresses, &jumpAddress))
    {
        printf("files: %X, address: %X, jump: %X\n", files, addresses, jumpAddress);
        return findImage(files, addresses, jumpAddress);

    }
}


int main(int argc, char *argv[], char *env[])
{

    void *entryPoint;

    lcd_init();
    displayWelcomeScreen();

    while (!(entryPoint = loadBootImage()))
    {
        displayNoImage();
        return 0;
        usdelay(10000);
    }

    displayEntryPoint(entryPoint);
    lcd_shutdown();

    return execute(entryPoint, argc, argv, env);
}

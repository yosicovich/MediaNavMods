/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "sd.h"

static char *   SOURCE_ADDR = ((char*)0xA2000000);
static char *   DEST_ADDR = ((char*)0xA1000000);
static uint32   TEST_SIZE_MB = 1;
static uint32   TEST_SIZE;
static uint32   TEST_BLOCK_COUNT;
static uint32   MAX_BLOCK_TRANSFER;

static uint32 slot = 1;
static SD_DATA_MODE mode = DM_PIO;


/********************************************************************/


int test_sd_slot_helper(int slot, SD_DATA_MODE data_mode)
{
    //int result = 0;
	uint32 status = 0;
	uint32 blocks_to_transfer;
	char * data_address;
	uint32 * data_address2;
	uint32 * data_address3;
	uint32 start_block;
	uint32 number_of_blocks;
	uint32 temp;
    uint32 i;
    
    // TEO: vars for performance testing.
	uint32 iBeginTime, iEndTime;
	unsigned long long ullRate;

    // write data to the source location.
    for (i = 0; i < TEST_SIZE; i+=4)
    {
        SOURCE_ADDR[i] = 0xad;
		SOURCE_ADDR[i+1] = 0xde;
        SOURCE_ADDR[i+2] = 0xef;
		SOURCE_ADDR[i+3] = 0xbe;

        DEST_ADDR[i] = 0x44;
        DEST_ADDR[i+1] = 0x33;
        DEST_ADDR[i+2] = 0x22;
        DEST_ADDR[i+3] = 0x11;
    }

    //dcacheFlushInvalidateRange(SOURCE_ADDR, TEST_SIZE);
    //dcacheFlushInvalidateRange(DEST_ADDR, TEST_SIZE);

    sd_set_data_mode(slot, data_mode);
    
	blocks_to_transfer = TEST_BLOCK_COUNT;
	data_address = SOURCE_ADDR;
	start_block = 1000;
    printf("\tWriting 0x%x blocks, \n", blocks_to_transfer);
    printf("\t\tstarting at block 0x%x,\n", start_block);
    printf("\t\tfrom source address 0x%x\n", data_address);
	
    iBeginTime = ReadTimer();

	// Write data to the SD device.
	while(blocks_to_transfer)
	{
		if(blocks_to_transfer >= MAX_BLOCK_TRANSFER)
			number_of_blocks = MAX_BLOCK_TRANSFER;
		else
			number_of_blocks = blocks_to_transfer;


		if((temp = sd_write(slot, start_block, number_of_blocks, data_address)) == (number_of_blocks * SD_BLOCK_LENGTH))
		{
			// Success so update some variables
	        blocks_to_transfer -= number_of_blocks;
			data_address += (number_of_blocks * SD_BLOCK_LENGTH);
	    	start_block += number_of_blocks; 
		}
		else
		{
			status = FALSE;
            printf("\tError writing data\n");
	    	printf("\tnumber of bytes read %d\r\n", temp);
			break;
		}

		status = TRUE;
        //dcacheFlushInvalidateRange(SOURCE_ADDR, TEST_SIZE);
        //dcacheFlushInvalidateRange(DEST_ADDR, TEST_SIZE);
	}

    iEndTime = ReadTimer();
	iEndTime = iEndTime - iBeginTime;
	// TEO: debug print for performance testing
	printf("\tWrite time: %d ticks, ", iEndTime);
	iEndTime =  TEST_SIZE / iEndTime;
	iEndTime *= 1000;
	iEndTime /= 1024;
	printf( "%d KBytes/sec\n\r", iEndTime); 


	// Read data back from the SD device.
	if(status == TRUE)
	{
	    // Set up the parameters for this transfer.
	    blocks_to_transfer = TEST_BLOCK_COUNT;
	    data_address = DEST_ADDR;
	    start_block = 1000;
	
        printf("\tReading 0x%x blocks,\n", blocks_to_transfer);
        printf("\t\tstarting at block 0x%x,\n", start_block); 
        printf("\t\tto destination address 0x%x\n", data_address);
 
    	iBeginTime = ReadTimer();

	    while(blocks_to_transfer)
	    {
	    	if(blocks_to_transfer >= MAX_BLOCK_TRANSFER)
	    		number_of_blocks = MAX_BLOCK_TRANSFER;
	    	else
	    		number_of_blocks = blocks_to_transfer;

	    	if((temp = sd_read(slot, start_block, number_of_blocks, data_address)) == (number_of_blocks * SD_BLOCK_LENGTH))
	    	{
                // Success so update some variables
	    		blocks_to_transfer -= number_of_blocks;
	    		data_address += (number_of_blocks * SD_BLOCK_LENGTH);
	    		start_block += number_of_blocks; 
	    	}
	    	else
	    	{
	    		status = FALSE;
                printf("\tError reading data\n");
	    		printf("\tnumber of bytes read %d\r\n", temp);
	    		break;
	    	}

	    	status = TRUE;
		}

        iEndTime = ReadTimer();
		iEndTime = iEndTime - iBeginTime;
	    // TEO: debug print for performance testing
	    printf("\tRead time: %d ticks, ", iEndTime);
	    iEndTime =  TEST_SIZE / iEndTime;
		iEndTime *= 1000;
		iEndTime /= 1024;
		printf( "%d KBytes/sec\n\r", (uint32)iEndTime); 

        //dcacheFlushInvalidateRange(SOURCE_ADDR, TEST_SIZE);
        //dcacheFlushInvalidateRange(DEST_ADDR, TEST_SIZE);

	}

	// Verify the data
	if(status == TRUE)
	{
        printf("\tVerifying programmed data...");

 	    // Set up source and destination pointers
 	    data_address2 = (uint32 *)SOURCE_ADDR;
	    data_address3 = (uint32 *)DEST_ADDR;
     
        if (compare_memory(SOURCE_ADDR, DEST_ADDR, TEST_SIZE))
        {
            status = TRUE;
            printf("Test Passed\n");
        }
        else
        {
            status = FALSE;
            printf("Test Failed\n");
            printf("\tError, data verification error\n");
        }
	}

    return status;
}


int test_sd_slot(void)
{
    int result = 0;
	int result2 = 0;
    
	if(slot != 0)
	{
        printf("\tInsert SD card into slot %d\n", slot);   
        sd_wait_card_inserted(slot);
	}
    
    if (sd_open(slot))
    {
        result = test_sd_slot_helper(slot, mode);
        
        sd_close(slot);
    }
    else
        printf("\tError opening slot: %d\n", slot);
            
    return (result );
}

static void sdtest_print_menu(void)
{
    printf("\n");
	printf("\t SD/MMC Unit Test\n");
	printf("\t------------------\n");
    printf("?. Display this help menu\n");
	printf("a. Change the SD slot under test ");
	printf( (slot ==0) ? "(eMMC)\n" : "(external)\n");
	printf("b. Change transfer mode (");
	printf((mode == DM_PIO) ? "PIO)\n" : "DMA)\n");
    printf("c. Set SOURCE address (%08X)\n", SOURCE_ADDR);
    printf("d. Set DESTINATION address (%08X)\n", DEST_ADDR);
    printf("e. Change size of test file (%d MBytes, %d blocks)\n", TEST_SIZE_MB, TEST_BLOCK_COUNT);
    printf("f. Change maximum blocks in a transfer(%d blocks)\n", MAX_BLOCK_TRANSFER);

    printf("g. Fill SOURCE with addr=addr pattern\n");
    printf("h. Fill SOURCE with a repeated 32bit pattern\n");

    printf("i. Run a Read/Write/Compare test\n");

    printf("j. Write from SOURCE to SD device\n");
    printf("k. Read from SD device to DESTINATION\n");
    printf("l. Compare SOURCE and DESTINATION for LENGTH bytes\n");    
    
    printf("m. Show contents of DESTINATION for LENGTH bytes\n");

    printf("x. Exit\n");
    /* possible others: write spare */
}

static void sdtest_ui (void)
{
    sdtest_print_menu();
    while (1)
    {
        char choice[100];
        printf("\nChoice: ");
        gets(choice);
        switch (choice[0])
        {
            case '?' :
                sdtest_print_menu();
                break;
            case 'a' :
                printf("0: slot 0, eMMC\n");
                printf("1: slot 1, external slot\n");
                printf("Select SD device to test: ");
                gets(choice);
                slot = (uint32)strtol(choice, NULL, 0);
                sdtest_print_menu();
                break;
            case 'b' :
                printf("0: PIO\n");
                printf("1: DMA\n");
                printf("Select transfer mode: ");
                gets(choice);
                mode = (SD_DATA_MODE)strtol(choice, NULL, 0);
                sdtest_print_menu();
                break;
            case 'c':
                printf("Enter new SOURCE: ");
                gets(choice);
                SOURCE_ADDR = (uint8 *)strtol(choice, NULL, 16);
                sdtest_print_menu();
                break;
            case 'd':
                printf("Enter new DESTINATION: ");
                gets(choice);
                DEST_ADDR = (uint8 *)strtol(choice, NULL, 16);
                sdtest_print_menu();
                break;
            case 'e':
                printf("Enter test file size in MBytes: ");
                gets(choice);
                TEST_SIZE_MB = (uint32)strtol(choice, NULL, 16);
                TEST_SIZE = 0x100000 * TEST_SIZE_MB;
	            TEST_BLOCK_COUNT = (TEST_SIZE / SD_BLOCK_LENGTH);
                sdtest_print_menu();
                break;
            case 'f':
                printf("Enter maxmimum number of blocks in a transfer (up to 3072): ");
                gets(choice);
                MAX_BLOCK_TRANSFER = (uint32)strtol(choice, NULL, 16);
				MAX_BLOCK_TRANSFER = (MAX_BLOCK_TRANSFER > 3072) ? 3072 : MAX_BLOCK_TRANSFER;
                sdtest_print_menu();
                break;
            case 'g' :
			{
                uint32 j;
                for (j = (uint32)SOURCE_ADDR; j < (uint32)SOURCE_ADDR + TEST_SIZE; j += 4)
                        *(uint32 *)j = j;
                break;
			}
            case 'h':
            {
                uint32 pattern;
                uint32 index;

                printf("0: 0x11111111\n");
                printf("1: 0x22222222\n");
                printf("2: 0x33333333\n");
                printf("Select Pattern to write to SOURCE: ");
                gets(choice);
                switch((unsigned)strtol(choice, NULL, 0))
                {
                    case 0:
                        pattern = 0x11111111;
                        break;
                    case 1:
                        pattern = 0x22222222;
                        break;
                    case 2:
                        pattern = 0x33333333;
                        break;
                    default:
                        pattern = 0x00000000;
                        break;
                }
				break;
			}
            case 'i':
                printf((mode==DM_PIO) ? "\n\r\tPIO " : "\n\r\tDMA ");
                printf("Test Started.\n\r");
                if(test_sd_slot() == 0)
                	printf("\tTEST FAILED \n\r");
		        else
                	printf("\tTEST PASSED \n\r");
                break;
            case 'j':
                printf("Confirm WRITE to SD slot %d for %d BYTES (y/n): ", slot, TEST_SIZE);
                gets(choice);
                if (choice[0] == 'y')
                    sd_write_bytes(slot, 0, TEST_SIZE, SOURCE_ADDR);
                break;
            case 'k' :
                printf("Confirm READ from SD slot %d for %d BYTES (y/n): ", slot, TEST_SIZE);
                gets(choice);
                if (choice[0] == 'y')
                    sd_read_bytes(slot,0,TEST_SIZE,DEST_ADDR);
                break;
            case 'l' :
            {
                int i;
                for (i = 0; i < TEST_SIZE; ++i)
                {
                    if (SOURCE_ADDR[i] != DEST_ADDR[i])
                    {
                        printf("Compare FAILED at offset %d, expected %02X, got %02X\n",
                               i, SOURCE_ADDR[i], DEST_ADDR[i]);
                        break;
                    }
                }
                if (i == TEST_SIZE)
                    printf("SOURCE and DESTINATION are IDENTICAL!\n");
                break;
            }
            case 'm':
            {
                unsigned i;
                unsigned long *p=(unsigned long *)DEST_ADDR;
                for(i=0;i<TEST_SIZE;i+=4)
                {
                    if ( !(i%16) ) printf("\nAddr: %08X", i);
                    printf(" %08X",*p++);
                }
                break;
            }
            case 'x':
                return;
                break;
        }
    }
}

int main(int argc, char **argv)
{
    // init some variales
    TEST_SIZE = 0x100000 * TEST_SIZE_MB;
	TEST_BLOCK_COUNT = (TEST_SIZE / SD_BLOCK_LENGTH);
	MAX_BLOCK_TRANSFER = TEST_BLOCK_COUNT;

    ResetTimer();
	// set up ms timer tick
	TimerCfg(1000);

	// initialize DMA
	ddma2_init();
    
	// Start up the interface
	sdtest_ui();

	return 0;
}

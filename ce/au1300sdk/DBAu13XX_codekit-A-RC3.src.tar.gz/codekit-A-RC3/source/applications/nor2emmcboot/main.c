#include "emmc_config.h"

int main ( void )
{
#ifdef PROTOTYPE
    unsigned short * p = (unsigned short*)0xB9800014;
    *p = 0x60;
#endif
    void (*func)(void *);
    func=(void*)EXTROM_START;

    disp_string("NOR Flash: SD/MMC Init\r\n");
    sd_init();
    sd_read(0,EXTROM_SIZE,(void*)EMMC_BOOT_IMAGE_LOAD_ADDRESS);

    disp_string("NOR Flash: Finished reading eMMC boot image.\r\n");

#ifdef PROTOTYPE
    func(sd_read);
    while(1) ;
#endif
}

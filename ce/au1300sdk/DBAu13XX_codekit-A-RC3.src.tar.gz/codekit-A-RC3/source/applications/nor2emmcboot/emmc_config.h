#define GENERATE_TODO_WARNINGS  1

#define HALT_ON_ERROR           while(1);;
//#define HALT_ON_ERROR

// Read in the eMMC extended CSD register contents.
// we will parse this information to determine which
// partition to read the boot image from.
#define READ_ECSD 1

#define INIT_SDRAM // include sdram initialization
#define USE_S18

/********************************************************
                BOOTSTRAP MEMORY MAP
********************************************************/

// total size available is 16KB(DCACHE)

#define TOTAL_SIZE      (1024*16)

#define STACK_SIZE      (512)
#define EXTROM_SIZE     (1024*2)


#define BASE_ADDR       0x9FC00000
#define TOP_ADDR        (BASE_ADDR + 0xd000)

#define STACK_START     (TOP_ADDR)
#define STACK_END       (TOP_ADDR - STACK_SIZE)

#define EXTROM_END      (EXTROM_START+EXTROM_SIZE)-1
#define EXTROM_START    BASE_ADDR+0x08000

#define BOOTSTRAP_END   (BOOTSTRAP_START+7167)
#define BOOTSTRAP_START BASE_ADDR                       // 9Fc00000

#define EMMC_BOOT_IMAGE_LOAD_ADDRESS   0xA0100000

/********************************************************
                END BOOTSTRAP MEMORY MAP
********************************************************/

/********************************************************
                eMMC BootPartition Map
********************************************************/
#define EMMC_SECTOR_SIZE    512
#define EMMC_BOOTSTRAP_MAX  1024*8              // Limit to 1/2 DCACHE size

#define EMMC_LOADER         1*EMMC_SECTOR_SIZE  // sector 1 is start of loader
#define EMMC_BOOTSTRAP      0                   // sector 0 is bootstrap

/********************************************************
                END eMMC BootPartition Map
********************************************************/

#ifndef ASSEMBLER
#ifdef PROTOTYPE
    #define PROGRESS(x) \
        { unsigned short *p=(unsigned short*)0xB9C00000; \
          unsigned short *q=(unsigned short*)0xB9C00008; \
          *q = 0; \
          *p = (unsigned short)x; \
          asm("sync");  \
        }
#else
    #define PROGRESS(x)
#endif // PROTOTYPE
#endif // ASSEMBLER


#ifdef GENERATE_TODO_WARNINGS
    #define TODO_WARNING(x) { unsigned short x; }
#else
    #define TODO_WARNING(x)
#endif // GENERATE_TODO_WARNINGS


#define NULL    0

/* Convert physical address to KSEG0 address */
#define KSEG0(ADDR) ((unsigned long)(ADDR) + 0x80000000)

/* Convert physical address to KSEG1 address */
#define KSEG1(ADDR) ((unsigned long)(ADDR) + 0xA0000000)

#define KSEG_MSK                  0xE0000000
#define KUSEG(addr)               ( (unsigned long)(addr) & ~KSEG_MSK)


#define MEM_PHYS_ADDR       0x14000000
#define STATIC_MEM_PHYS_ADDR    0x14001000
#define AES_PHYS_ADDR       0x10300000
#define CIM_PHYS_ADDR       0x14004000
#define IC0_PHYS_ADDR       0x10400000
#define IC1_PHYS_ADDR       0x11800000
#define USBM_PHYS_ADDR      0x14020000
#define USBH_PHYS_ADDR      0x14020100
#define UART0_PHYS_ADDR     0x11100000
#define UART1_PHYS_ADDR     0x11200000
#define GPIO2_PHYS_ADDR     0x11700000
#define SYS_PHYS_ADDR       0x11900000
#define DDMA_PHYS_ADDR      0x14002000
#define PSC0_PHYS_ADDR      0x11A00000
#define PSC1_PHYS_ADDR      0x11B00000
#define PCMCIA_IO_PHYS_ADDR   0xF00000000
#define PCMCIA_ATTR_PHYS_ADDR 0xF40000000
#define PCMCIA_MEM_PHYS_ADDR  0xF80000000
#define SD0_PHYS_ADDR       0x10600000
#define SD1_PHYS_ADDR       0x10680000
#define LCD_PHYS_ADDR       0x15000000
#define SWCNT_PHYS_ADDR     0x1110010C
#define MAEFE_PHYS_ADDR     0x14012000
#define MAEBE_PHYS_ADDR     0x14010000


#define GPINT_PHYS_ADDR     0x10200000

#ifndef ASSEMBLER
typedef volatile struct
{
    /* 0x0000 */ unsigned long toytrim;
    /* 0x0004 */ unsigned long toywrite;
    /* 0x0008 */ unsigned long toymatch0;
    /* 0x000C */ unsigned long toymatch1;
    /* 0x0010 */ unsigned long toymatch2;
    /* 0x0014 */ unsigned long cntrctrl;
    /* 0x0018 */ unsigned long scratch0;
    /* 0x001C */ unsigned long scratch1;
    /* 0x0020 */ unsigned long freqctrl0;
    /* 0x0024 */ unsigned long freqctrl1;
    /* 0x0028 */ unsigned long clksrc;
    /* 0x002C */ unsigned long pinfunc;
    /* 0x0030 */ unsigned long reserved0;
    /* 0x0034 */ unsigned long wakemsk;
    /* 0x0038 */ unsigned long endian;
    /* 0x003C */ unsigned long powerctrl;
    /* 0x0040 */ unsigned long toyread;
    /* 0x0044 */ unsigned long rtctrim;
    /* 0x0048 */ unsigned long rtcwrite;
    /* 0x004C */ unsigned long rtcmatch0;
    /* 0x0050 */ unsigned long rtcmatch1;
    /* 0x0054 */ unsigned long rtcmatch2;
    /* 0x0058 */ unsigned long rtcread;
    /* 0x005C */ unsigned long wakesrc;
    /* 0x0060 */ unsigned long cpupll;
    /* 0x0064 */ unsigned long auxpll;
    /* 0x0068 */ unsigned long reserved1;
    /* 0x006C */ unsigned long reserved2;
    /* 0x0070 */ unsigned long reserved3;
    /* 0x0074 */ unsigned long reserved4;
    /* 0x0078 */ unsigned long slppwr;
    /* 0x007C */ unsigned long sleep;
    /* 0x0080 */ unsigned long reserved5[32];
    /* 0x0100 */ unsigned long trioutrd;
#define trioutclr trioutrd
    /* 0x0104 */ unsigned long reserved6;
    /* 0x0108 */ unsigned long outputrd;
#define outputset outputrd
    /* 0x010C */ unsigned long outputclr;
    /* 0x0110 */ unsigned long pinstaterd;
#define pininputen pinstaterd

} AU1X00_SYS;
#endif

#define SYS_PINFUNC_DMA     (1<<31)
#define SYS_PINFUNC_S0A     (1<<30)
#define SYS_PINFUNC_S1A     (1<<29)
#define SYS_PINFUNC_LP0     (1<<28)
#define SYS_PINFUNC_LP1     (1<<27)
#define SYS_PINFUNC_LD16    (1<<26)
#define SYS_PINFUNC_LD8     (1<<25)
#define SYS_PINFUNC_LD1     (1<<24)
#define SYS_PINFUNC_LD0     (1<<23)
#define SYS_PINFUNC_P1A     (3<<21)
#define SYS_PINFUNC_P1A_N(n)    ((n & 3) << 21)
#define SYS_PINFUNC_P1B     (1<<20)
#define SYS_PINFUNC_FS3     (1<<19)
#define SYS_PINFUNC_P0A     (3<<17)
#define SYS_PINFUNC_P0A_N(n)    ((n & 3) << 17)
#define SYS_PINFUNC_CS      (1<<16)
#define SYS_PINFUNC_CIM     (1<<15)
#define SYS_PINFUNC_P1C     (1<<14)
#define SYS_PINFUNC_U1T     (1<<12)
#define SYS_PINFUNC_U1R     (1<<11)
#define SYS_PINFUNC_EX1     (1<<10)
#define SYS_PINFUNC_EX0     (1<<9)
#define SYS_PINFUNC_U0R     (1<<8)
#define SYS_PINFUNC_MC      (1<<7)
#define SYS_PINFUNC_S0B     (1<<6)
#define SYS_PINFUNC_S0C     (1<<5)
#define SYS_PINFUNC_P0B     (1<<4)
#define SYS_PINFUNC_U0T     (1<<3)
#define SYS_PINFUNC_S1B     (1<<2)


#ifndef ASSEMBLER
typedef volatile struct
{
    unsigned long txport;
    unsigned long rxport;
    unsigned long config;
    unsigned long enable;
    unsigned long config2;
    unsigned long blksize;
    unsigned long status;
    unsigned long debug;
    unsigned long cmd;
    unsigned long cmdarg;
    unsigned long resp3;
    unsigned long resp2;
    unsigned long resp1;
    unsigned long resp0;
    unsigned long timeout;

} AU1100_SD;
#endif

/*
 * Register content definitions
 */
#define SD_CONFIG_SI        (1<<31)
#define SD_CONFIG_CD        (1<<30)
#define SD_CONFIG_RA        (1<<29)
#define SD_CONFIG_RF        (1<<28)
#define SD_CONFIG_RH        (1<<27)
#define SD_CONFIG_TA        (1<<26)
#define SD_CONFIG_TE        (1<<25)
#define SD_CONFIG_TH        (1<<24)
#define SD_CONFIG_WC        (1<<22)
#define SD_CONFIG_RC        (1<<21)
#define SD_CONFIG_SC        (1<<20)
#define SD_CONFIG_DT        (1<<19)
#define SD_CONFIG_DD        (1<<18)
#define SD_CONFIG_RAT       (1<<17)
#define SD_CONFIG_CR        (1<<16)
#define SD_CONFIG_I         (1<<15)
#define SD_CONFIG_RO        (1<<14)
#define SD_CONFIG_RU        (1<<13)
#define SD_CONFIG_TO        (1<<12)
#define SD_CONFIG_TU        (1<<11)
#define SD_CONFIG_NE        (1<<10)
#define SD_CONFIG_DE        (1<<9)
#define SD_CONFIG_DIV       (511<<0)
#define SD_CONFIG_DIV_N(n)  (n & SD_CONFIG_DIV)

#define SD_ENABLE_R         (1<<1)
#define SD_ENABLE_CE        (1<<0)

#define SD_CONFIG2_WP       (1<<10)
#define SD_CONFIG2_RW       (1<<9)
#define SD_CONFIG2_WB       (1<<8)
#define SD_CONFIG2_DC       (1<<4)
#define SD_CONFIG2_DF       (1<<3)
#define SD_CONFIG2_FF       (1<<1)
#define SD_CONFIG2_EN       (1<<0)

#define SD_BLKSIZE_BC       (511<<16)
#define SD_BLKSIZE_BS       (1023<<0)
#define SD_BLKSIZE_BC_N(N)  ((N-1)<<16)
#define SD_BLKSIZE_BS_N(N)  ((N-1)<<0)

#define SD_STATUS_SI        (1<<31)
#define SD_STATUS_CD        (1<<30)
#define SD_STATUS_RF        (1<<29)
#define SD_STATUS_RA        (1<<28)
#define SD_STATUS_RH        (1<<27)
#define SD_STATUS_TA        (1<<26)
#define SD_STATUS_TE        (1<<25)
#define SD_STATUS_TH        (1<<24)
#define SD_STATUS_WC        (1<<22)
#define SD_STATUS_RC        (1<<21)
#define SD_STATUS_SC        (1<<20)
#define SD_STATUS_DT        (1<<19)
#define SD_STATUS_DD        (1<<18)
#define SD_STATUS_RAT       (1<<17)
#define SD_STATUS_CR        (1<<16)
#define SD_STATUS_I         (1<<15)
#define SD_STATUS_RO        (1<<14)
#define SD_STATUS_RU        (1<<13)
#define SD_STATUS_TO        (1<<12)
#define SD_STATUS_TU        (1<<11)
#define SD_STATUS_NE        (1<<10)
#define SD_STATUS_CF        (1<<6)
#define SD_STATUS_DB        (1<<5)
#define SD_STATUS_CB        (1<<4)
#define SD_STATUS_DCRCW     (7<<0)
#define SD_STATUS_DCRCW_NONE    (2<<0)
#define SD_STATUS_DCRCW_TXERR   (5<<0)
#define SD_STATUS_DCRCW_CRCERR  (7<<0)

#define SD_CMD_RT           (255<<16)
#define SD_CMD_CI           (255<<8)
#define SD_CMD_CT           (15<<4)
#define SD_CMD_RY           (1<<1)
#define SD_CMD_GO           (1<<0)
#define SD_CMD_BUSY         (1<<0)
#define SD_CMD_RT_NONE      (0<<16)
#define SD_CMD_RT_R1        (1<<16)
#define SD_CMD_RT_R2        (2<<16)
#define SD_CMD_RT_R3        (3<<16)
#define SD_CMD_RT_R4        (4<<16)
#define SD_CMD_RT_R5        (5<<16)
#define SD_CMD_RT_R6        (6<<16)
#define SD_CMD_RT_R1b       (0x81<<16)
#define SD_CMD_RT_N(n)      (n<<16)
#define SD_CMD_CI_N(N)      ((N)<<8)
#define SD_CMD_CT_NONE      (0<<4)      /* IDLE ? */
#define SD_CMD_CT_SBW       (1<<4)      /* Single block write */
#define SD_CMD_CT_SBR       (2<<4)      /* Single block read */
#define SD_CMD_CT_MBW       (3<<4)      /* Multiple block write */
#define SD_CMD_CT_MBR       (4<<4)      /* Multiple block read */
#define SD_CMD_CT_MBIOW     (5<<4)      /* Multi block IO write */
#define SD_CMD_CT_MBIOR     (6<<4)      /* Multi block IO read */
#define SD_CMD_CT_TERM      (7<<4)
#define SD_CMD_CT_TERMIO    (8<<4)
#define SD_CMD_CT_N(n)      (n<<4)



#define GPINT_CHANNEL0      0
#define GPINT_CHANNEL1      1
#define GPINT_CHANNEL2      2
#define GPINT_CHANNEL3      3

#define GPINT_NUM_CHANNELS  4 /* 0-3 */
#define GPINT_MAX_CHANNEL   (GPINT_CHANNEL3)

#define GPINT_GPIO_PER_CHANNEL      32
#define GPINT_INTS_PER_CHANNEL      GPINT_GPIO_PER_CHANNEL

/* Total number of interrupts our architecture allows */
#define GPINT_MAX_INTS              (GPINT_NUM_CHANNELS*GPINT_INTS_PER_CHANNEL)

/* Current maximum supported GPIO/INTERRUPTs */
#define GPINT_NUM_GPIO              GPINT_MAX_INTS
#define GPINT_NUM_INTERRUPTS        GPINT_MAX_INTS

#ifndef ASSEMBLER
typedef volatile struct
{
    /* R/W1S */
//  unsigned int    pin_val0;       // 0x00
//  unsigned int    pin_val1;       // 0x04
//  unsigned int    pin_val2;       // 0x08
//  unsigned int    pin_val3;       // 0x0C
    unsigned int    pin_val[GPINT_NUM_CHANNELS];

    /* W1C */
//  unsigned int    pin_valclr0     // 0x10
//  unsigned int    pin_valclr1;    // 0x14
//  unsigned int    pin_valclr2;    // 0x18
//  unsigned int    pin_valclr3;    // 0x1C
    unsigned int    pin_valclr[GPINT_NUM_CHANNELS];

    /* R/W1C */
//  unsigned int    int_pend0;      // 0x20
//  unsigned int    int_pend1;      // 0x24
//  unsigned int    int_pend2;      // 0x28
//  unsigned int    int_pend3;      // 0x2c
    unsigned int    int_pend[GPINT_NUM_CHANNELS];

    unsigned int    pri_enc;        // 0x30
    unsigned int    _resvd0[3];     // 0x34-0x3c

    /* R/W1S */
//  unsigned int    int_mask0;      // 0x40
//  unsigned int    int_mask1;      // 0x44
//  unsigned int    int_mask2;      // 0x48
//  unsigned int    int_mask3;      // 0x4c
    unsigned int    int_mask[GPINT_NUM_CHANNELS];

    /* W1C */
//  unsigned int    int_maskclr0;   // 0x50
//  unsigned int    int_maskclr1;   // 0x54
//  unsigned int    int_maskclr2;   // 0x58
//  unsigned int    int_maskclr3;   // 0x5C
    unsigned int    int_maskclr[GPINT_NUM_CHANNELS];

    unsigned int    dma_sel;        // 0x60
    unsigned int    _resvd1[7];     // 64-7c

    /* W1S */
//  unsigned int    dev_sel0;       // 0x80
//  unsigned int    dev_sel1;       // 0x84
//  unsigned int    dev_sel2;       // 0x88
//  unsigned int    dev_sel3;       // 0x8c
    unsigned int    dev_sel[GPINT_NUM_CHANNELS];

    /* W1C */
//  unsigned int    dev_selclr0;    // 0x90
//  unsigned int    dev_selclr1;    // 0x94
//  unsigned int    dev_selclr2;    // 0x98
//  unsigned int    dev_selclr3;    // 0x9c
    unsigned int    dev_selclr[GPINT_NUM_CHANNELS];

    /* RO */
//  unsigned int    reset_val0;     // 0xA0
//  unsigned int    reset_val1;     // 0xA4
    unsigned int    reset_val[GPINT_NUM_CHANNELS];

    unsigned char   _resvd2[0x1000 - 0xA8]; // 0xA8-0xFFC

//  unsigned int    gp_int0;        // 0x1000
//  unsigned int    gp_int1;        // 0x1004
//  unsigned int    gp_int2;        // 0x1008
//  unsigned int    gp_int2;        // 0x100C
//  unsigned int    gp_intN;        // 0x1000 + (N*4)
    unsigned int    gp_int[GPINT_MAX_INTS];
} AU1300_GPINT;
#endif

#define GPINT_6     (1<<6)
#define GPINT_7     (1<<7)
#define GPINT_8     (1<<8)
#define GPINT_9     (1<<9)



#ifndef ASSEMBLER
#ifdef UART0_DEBUG
    extern void disp_string(char *);
#else
    #define disp_string(x)
#endif // UART0_DEBUG
#endif // ASSEMBLER

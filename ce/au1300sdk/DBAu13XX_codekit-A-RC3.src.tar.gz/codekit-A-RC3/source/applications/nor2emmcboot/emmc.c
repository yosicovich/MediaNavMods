#include "emmc_config.h"

/*******************************************************************
                            Defines
*******************************************************************/

typedef struct
{
    unsigned long r3;
    unsigned long r2;
    unsigned long r1;
    unsigned long r0;
} RESPONSE;

typedef struct
{
    int cid;
    int rca;
    int csd;
    int scr;
    int bus_width;
    int rd_blk_len;
    int rd_blk_partial;
    int wr_blk_len;
    int wr_blk_partial;
    int mem_capacity;
} CARD_INFO;

/* Max clock frequency speced during initialization mode */
// #define F_OD 250000
#define F_OD 400000 // in 4.3spec this can be 400kHz
//#define F_HS 26000000
#define F_HS 20000000

#define BOOTVAL ((*(unsigned int *)0xB0003C04)&0xf)
#define BOOTFAST ((BOOTVAL)==0xe)

// eMMC Extended CSD definitions for Boot Configuration
#define ECSD_BOOT_CONFIG_BYTE 179
#define ECSD_BOOT_CONFIG__BOOT_PART_ACCESS_OFFSET 0
#define ECSD_BOOT_CONFIG__BOOT_PART_ENABLE_OFFSET 3
#define ECSD_BOOT_CONFIG__BOOT_PART_ENABLE_MASK (0x7 << ECSD_BOOT_CONFIG__BOOT_PART_ENABLE_OFFSET)

/* Max clock frequency speced during data transfers */
#define F_PP    25000000 // 25MHz
#define F_PP_HS 50000000 // 50Mhz for high speed

#define BLOCK_LENGTH            512

#define MMC_GO_IDLE_STATE       0
#define MMC_SEND_OP_COND        1
#define MMC_ALL_SEND_CID        2
#define MMC_SET_RELATIVE_ADDR   3
#define MMC_SET_DSR             4
#define MMC_SWITCH              6
#define MMC_SELECT_DESELECT_CARD    7
#define MMC_ECSD                8
#define MMC_CSD                 9
#define MMC_CID                 10
#define MMC_STOP_TRANSMISSION   12
#define MMC_SEND_STATUS         13
#define MMC_GO_INACTIVE_STATE   15
#define MMC_SET_BLOCKLEN        16
#define MMC_READ_SINGLE_BLOCK   17
#define MMC_READ_MULTIPLE_BLOCK 18
#define MMC_WRITE_BLOCK         24
#define MMC_WRITE_MULTIPLE_BLOCK        25
#define MMC_PROGRAM_CSD         27
#define MMC_SET_WRITE_PROT      28
#define MMC_CLR_WRITE_PROT      29
#define MMC_SEND_WRITE_PROT     30
#define MMC_ERASE_WR_BLK_START  32
#define MMC_ERASE_WR_BLK_END    33
#define MMC_ERASE               38
#define MMC_IRQMODE             40
#define MMC_LOCK_UNLOCK         42
#define MMC_APP_CMD             55
#define MMC_GEN_CMD             56


#if 0
#define SD_APP_SET_BUS_WITH     6
#define SD_APP_STATUS           13
#define SD_APP_SEND_NUM_WR_BLOCKS   22
#define SD_APP_SET_WR_BLK_ERASE_COUNT   23
#define SD_APP_SEND_OP_COND     41
#define SD_APP_SET_CLR_CARD_DETECT  42
#define SD_APP_SEND_SCR         51

#define SD_BUS_WIDTHS_4BIT      (1<<2)
#define SD_BUS_WIDTHS_1BIT      (1<<0)
#endif

#define BUS_WIDTH_4             0x02
#define BUS_WIDTH_1             0x00

#define CSD_READ_BL_LEN(X)      (0x01 << ((X & 0x00000f00) >> 8))
#define CSD_READ_BL_PARTIAL(X)  ((X & 0x00000080) >> 7)
#define CSD_C_SIZE(X, Y)        (((X & 0x00000003) << 10) | ((Y & 0xffc00000) >> 22))
#define CSD_C_SIZE_MULT(X)      ((X & 0x00000380) >> 7)
#define CSD_WRITE_BL_LEN(X)     (0x01 << ((X & 0x0003c000) >> 14))
#define CSD_WRITE_BL_PARTIAL(X) ((X & 0x00002000) >> 13)

/*
 * OCR register definitions
 */
#define OCR_STATUS              (1<<31)
#define OCR_ADDRMODE                (1<<30)
#define OCR_35_36               (1<<23)
#define OCR_34_35               (1<<22)
#define OCR_33_34               (1<<21)
#define OCR_32_33               (1<<20)
#define OCR_31_32               (1<<19)
#define OCR_30_31               (1<<18)
#define OCR_29_30               (1<<17)
#define OCR_28_29               (1<<16)
#define OCR_27_28               (1<<15)
#define OCR_26_27               (1<<14)
#define OCR_25_26               (1<<13)
#define OCR_24_25               (1<<12)
#define OCR_23_24               (1<<11)
#define OCR_22_23               (1<<10)
#define OCR_21_22               (1<<9)
#define OCR_20_21               (1<<8)
#define OCR_19_20               (1<<7)
#define OCR_18_19               (1<<6)
#define OCR_17_18               (1<<5)
#define OCR_16_17               (1<<4)

#define sd_send_command(c,r,t,a,rsp) sd_send_command_generic(c,a,r,t,rsp)

/*******************************************************************
                            Globals
*******************************************************************/
AU1100_SD* sd =   (AU1100_SD*) KSEG1(SD0_PHYS_ADDR);
AU1X00_SYS* sys = (AU1X00_SYS*) KSEG1(SYS_PHYS_ADDR);
AU1300_GPINT* gpint = (AU1300_GPINT*) KSEG1(GPINT_PHYS_ADDR);

// if the device responds back with OCR_ADDRMODE, this this value will be 512
// this allows for sector addressing, not byte addressing
#define SECTOR_SIZE  512
//unsigned long addr_div=1;  // divide by 1 assumes byte addressing, not "sector"

CARD_INFO mmc_info=
        {0xFF,0,0,0,0,0,0,0,0};


#define R1  0x01
#define R2  0x02
#define R3  0x03
#define R4  0x04
#define R5  0x05
#define R6  0x06
#define R1b 0x81

#if 0
static const int mmc_cmd_response[] = {
                                          0,        //00
                                          R3,       //01
                                          R2,       //02
                                          R1,       //03
                                          0,        //04
                                          0,        //05
                                          R1b,      //06
                                          R1b,      //07
                                          R1,       //08
                                          R2,       //09
                                          R2,       //10
                                          R1,       //11
                                          R1b,      //12
                                          R1,       //13
                                          0,        //14
                                          0,        //15
                                          R1,       //16
                                          R1,       //17
                                          R1,       //18
                                          0,        //19
                                          R1,       //20
                                          0,        //21
                                          0,        //22
                                          R1,       //23
                                          R1,       //24
                                          R1,       //25
                                          R1,       //26
                                          R1,       //27
                                          R1b,  //28
                                          R1b,  //29
                                          R1,       //30
                                          0,        //31
                                          0,        //32
                                          0,        //33
                                          0,        //34
                                          R1,       //35
                                          R1,       //36
                                          0,        //37
                                          R1b,  //38
                                          R4,       //39
                                          R5,       //40
                                          0,        //41
                                          R1b,  //42
                                          0,        //43
                                          0,        //44
                                          0,        //45
                                          0,        //46
                                          0,        //47
                                          0,        //48
                                          0,        //49
                                          0,        //50
                                          0,        //51
                                          0,        //52
                                          0,        //53
                                          0,        //54
                                          R1,       //55
                                          R1b,  //56
                                          0,        //57
                                          0,        //58
                                          0,        //59
                                          0,        //60
                                          0,        //61
                                          0,        //62
                                          0     //63
                                      };

static const int mmc_cmd_type[] = {
                                     0,     //00
                                     0,     //01
                                     0,     //02
                                     0,     //03
                                     0,     //04
                                     0,     //05
                                     2,     //06
                                     0,     //07
                                     0,     //08
                                     0,     //09
                                     0,     //10
                                     0,     //11
                                     7,     //12
                                     0,     //13
                                     0,     //14
                                     0,     //15
                                     0,     //16
                                     2,     //17
                                     4,     //18
                                     0,     //19
                                     0,     //20
                                     0,     //21
                                     0,     //22
                                     0,     //23
                                     1,     //24
                                     3,     //25
                                     0,     //26
                                     0,     //27
                                     0,     //28
                                     0,     //29
                                     0,     //30
                                     0,     //31
                                     0,     //32
                                     0,     //33
                                     0,     //34
                                     0,     //35
                                     0,     //36
                                     0,     //37
                                     0,     //38
                                     0,     //39
                                     0,     //40
                                     0,     //41
                                     0,     //42
                                     0,     //43
                                     0,     //44
                                     0,     //45
                                     0,     //46
                                     0,     //47
                                     0,     //48
                                     0,     //49
                                     0,     //50
                                     0,     //51
                                     0,     //52
                                     0,     //53
                                     0,     //54
                                     0,     //55
                                     0,     //56
                                     0,     //57
                                     0,     //58
                                     0,     //59
                                     0,     //60
                                     0,     //61
                                     0,     //62
                                     0      //63
                                 };
#endif

/*******************************************************************
                            COde
*******************************************************************/
void sd_clear_status()
{
    sd->status = 0xFFFFFFFF;        //Clear all pending interrupts
}

void sd_reset()
{
    sd->enable = SD_ENABLE_CE;  //Put device into reset
    sd->enable = SD_ENABLE_R | SD_ENABLE_CE;    //Take out of reset
    sd_clear_status();
}

/*
 *  Can't hard code the divisor here. A running reset will
 *  keep the cpupll that was previoulsy configured, unlike
 *  powerOn that runs at 192MHz.

    NOTE*** After talking to Steve Kromer, the cpupll is going to be reset
            even on running reset, which means we'll always use the 0 div.
 */
int sd_set_clock_divisor(int freq)
{
    int pbus;
    int divisor;

    //Compute Divisor
    pbus = (sys->cpupll & 0x3F) * 12000000;
    pbus /= ((sys->powerctrl & 0x3) + 2);
    pbus /= 2;

    //We have to be conservative here.
    //Integer division will truncate and potentially cause this to be off by 1
    //ideally "- 1" should be included in the calculation, and the result should be rounded up
    divisor = (pbus / (2 * freq)); //- 1;

    sd->config = (sd->config & ~0x1FF) | divisor | SD_CONFIG_DE;
}


void sd_flush_fifo()
{
    sd->config2 |= SD_CONFIG2_FF;
    sd->config2 &= ~SD_CONFIG2_FF;
}

#ifdef PROTOTYPE
void sd_power_on()
{
    unsigned short * p = (unsigned short*)0xB9800014;
    *p = 0x60;
    sys->pinfunc |= (SYS_PINFUNC_S0A | SYS_PINFUNC_S0B);
    sys->pinfunc &= ~SYS_PINFUNC_S0C;
    sd_clear_status();
}
#endif

void sd_wait_busy()
{
    while(sd->cmd & SD_CMD_BUSY)
        ;
    // Wait for command-response to be clear, OR
    // if the Clock becomes frozen, the SD card can't send response
    // to Au1 host controller, break out for that too.
    while((sd->status & SD_STATUS_CB) && !(sd->status & SD_STATUS_CF))
        ;
}

int sd_get_response(int response_type, RESPONSE* response)
{
    RESPONSE r; //Just a temp variable to store the data if no response variable passed
    if(response == NULL)
        response = &r;

    if((sd->status & SD_STATUS_RAT))
    {
        disp_string("sd_get_response: ERROR: response timeout\r\n");
        return 0;
    }

    response->r3 = 0;
    response->r2 = 0;
    response->r1 = 0;
    response->r0 = 0;
    switch(response_type)
    {
    case R2:
        response->r3 = sd->resp3;
        response->r2 = sd->resp2;
    case R6:
    case R5:
    case R4:
    case R3:
    case R1:
    case R1b:
        response->r1 = sd->resp1;
        response->r0 = sd->resp0;
    default:
        break;
    }

    // If response type is R1b, then check if card is asserting
    // busy, and if so, wait until busy deasserted before
    // returning.
    if(response_type == R1b)
        while (sd->status & SD_STATUS_DB);

    return 1;
}

int sd_send_command_generic(int cmd, int arg, int response_type, int command_type, RESPONSE* response)
{
    asm("sd_send_command_start:");
    sd_clear_status();
    sd_wait_busy();

    sd->cmdarg = arg;
    sd->cmd     = SD_CMD_CT_N(command_type)
                     | SD_CMD_RT_N(response_type)
                     | SD_CMD_CI_N(cmd)
                     | SD_CMD_GO;

    sd_wait_busy();

    asm("sd_send_command_end:");
    if(response_type != 0) {
        return sd_get_response( response_type, response);
    }
    else
    {
        return 1;
    }
}

#if 0
int sd_send_command( int cmd, int arg, RESPONSE* response)
{
        return sd_send_command_generic(cmd, arg, mmc_cmd_response[cmd], mmc_cmd_type[cmd], response);
}
#endif

int sd_get_relative_address()
{
    RESPONSE response;
    unsigned int rca = 3;
    //Assign a unique relative card address
    if(!sd_send_command( MMC_SET_RELATIVE_ADDR, R1, 0, rca<<16, &response))
        return 0;

    return rca;
}

int sd_get_card_info()
{
    RESPONSE response;
    int cid, rca, c_size, c_size_mult;
    unsigned long data;

    asm("sd_get_card_info_label:");
    disp_string("sd_get_card_info\r\n");
    if(!sd_send_command( MMC_ALL_SEND_CID, R2, 0, 0, &response))    //Get the CID Register
        return 0;

    mmc_info.cid = response.r0;

    mmc_info.rca = sd_get_relative_address();

    disp_string("sd_get_card_info mmc_info.rca\r\n");
    if(mmc_info.rca)
    {
#if READ_CSD
        disp_string("sd_get_card_info: Get CSD\r\n");
        if(!sd_send_command( MMC_CSD, R2, 0, mmc_info.rca << 16, &response))  //Get the CSD Register
            return 0;

        mmc_info.csd            = response.r2;
        mmc_info.rd_blk_len     = CSD_READ_BL_LEN(response.r2);
        mmc_info.rd_blk_partial = CSD_READ_BL_PARTIAL(response.r2);
        c_size                  = CSD_C_SIZE(response.r2, response.r1);
        c_size_mult             = CSD_C_SIZE_MULT(response.r1);
        //   BLOCKNR    * MULT=2^(c_size_mult+2) * BLOCK_LEN
        mmc_info.mem_capacity   = (c_size+1) * (1 << (c_size_mult+2)) * mmc_info.rd_blk_len;
        mmc_info.wr_blk_len     = CSD_WRITE_BL_LEN(response.r0);
        mmc_info.wr_blk_partial = CSD_WRITE_BL_PARTIAL(response.r0);
#endif
        //Select this card
        disp_string("sd_get_card_info:MMC_SELECT_DESELECT_CARD\r\n");
        if(!sd_send_command( MMC_SELECT_DESELECT_CARD,R1b,0,mmc_info.rca << 16, NULL))
            return 0;

        return 1;
    }

    disp_string("sd_get_card_info failed to get valid rca\r\n");
    return 0;
}

int sd_init()
{
    RESPONSE response;
//    unsigned char * ecsd_data = (unsigned char *)0x9fc01c00;
    unsigned char * ecsd_data = (unsigned char *)EXTROM_START;
    unsigned char boot_partition;

    asm("sd_init_label:");
    mmc_info.rca = 0;

    disp_string("sd_init: Reset\r\n");
    sd_reset();

    sd->config  =
        SD_CONFIG_SI
        | SD_CONFIG_CD
        | SD_CONFIG_RF
        | SD_CONFIG_RA
        | SD_CONFIG_RH
        | SD_CONFIG_TA
        | SD_CONFIG_TE
        | SD_CONFIG_TH
        | SD_CONFIG_WC
        | SD_CONFIG_RC
        | SD_CONFIG_SC
        | SD_CONFIG_DT
        | SD_CONFIG_DD
        | SD_CONFIG_RAT
        | SD_CONFIG_CR
        | SD_CONFIG_I  /* needed for sd_status bits */
        | SD_CONFIG_RO
        | SD_CONFIG_RU
        | SD_CONFIG_TO
        | SD_CONFIG_TU
        | SD_CONFIG_NE
        | SD_CONFIG_DE;
#ifdef PROTOTYPE
    sd_set_clock_divisor(F_OD); //Set the clock divider
#else
    sd_set_clock_divisor((BOOTFAST) ? F_HS : F_OD); //Set the clock divider
#endif
    sd->config2 = SD_CONFIG2_EN | SD_CONFIG2_WP;  //Enable SD Controller
    sd_flush_fifo();

    sd->timeout = 0x001FFFFF;       // max timeout

#ifdef PROTOTYPE
    disp_string("sd_init: sd_power_on\r\n");
    sd_power_on();
#endif

    if(!sd_send_command( MMC_GO_IDLE_STATE, 0, 0, 0, NULL))
        return 0;

    do  //Set the valid voltage range for the card
    {
        if(!sd_send_command( MMC_SEND_OP_COND, R3, 0, 0x40FF8000, &response))
            return 0;
    }
    while(!(response.r0 & OCR_STATUS)); //Loop until the device is ready

#if 0
    // Check for sector addressing type
    // Devices larger than 2GB are required to use sector addressing.
    // Devices smaller than 2GB will use byte addressing. These devices
    //   will return OCR status without bit 30 set indicating byte addressing only
    if ( response.r0 & OCR_ADDRMODE )
    addr_div = SECTOR_SIZE;
#endif
    disp_string("sd_init: sd_get_card_info\r\n");


/****************************************************************************
        1) set bus speed
        2) Set bus width
        3) Set Block Size
        4) select Boot Partition
****************************************************************************/

    if(sd_get_card_info())  //Read the card info into the mmc_info sturcture
    {
        disp_string("sd_init: BusSpeed(HS)\r\n");
        /* Set Host controller's clock speed */
        if(!sd_send_command( MMC_SWITCH,R1b,0,0x03B90100, NULL))
            return 0;
        sd_set_clock_divisor(F_HS);

        disp_string("sd_init: BusWidth-4BIT \r\n");
        if(!sd_send_command( MMC_SWITCH,R1b,0,0x03B70100, &response))
            return 0;

        /* Enable 4bit mode on host */
        sd->config2 |= SD_CONFIG2_WB;

        disp_string("sd_init: SetBlkSize\r\n");
        // set block size
        sd->blksize = SD_BLKSIZE_BC_N(1) | SD_BLKSIZE_BS_N(BLOCK_LENGTH);
        if(!sd_send_command( MMC_SET_BLOCKLEN,R1,0, BLOCK_LENGTH, NULL))
            return 0;

        // Read in the Extended CSD to determine which partition to
        // read the boot image from.
        disp_string("sd_init: Read ECSD\r\n");
        sd_flush_fifo();
        sd_send_command( 8, R1, 2, 0, &response);
        sd_clear_status();
        sd_read_bytes_pio(512, ecsd_data);

        if(ecsd_data[ECSD_BOOT_CONFIG_BYTE] == 0xFF)
            disp_string("ERROR: Boot Config Byte = 0xFF!!");

        boot_partition = (ecsd_data[ECSD_BOOT_CONFIG_BYTE] &
                          ECSD_BOOT_CONFIG__BOOT_PART_ENABLE_MASK) >>
                         ECSD_BOOT_CONFIG__BOOT_PART_ENABLE_OFFSET;
        if(boot_partition > 2)
        {
            boot_partition = (boot_partition == 7) ? 7 : 0;
        }

        disp_string("sd_init: Read Boot Image From: ");
        switch (boot_partition)
        {
            case 0:
                disp_string("Boot Operation Disabled");
                break;
            case 1:
                disp_string("Boot Partition 1");
                break;
            case 2:
                disp_string("Boot Partition 2");
                break;
            case 7:
                disp_string("User Partition");
                break;
            default:
                disp_string("ERROR - INVALID VALUE");
                break;
        }
        disp_string("\r\n");

        {
//            int bp_access_val = (gpint->reset_val[0] & (GPINT_8|GPINT_7|GPINT_6)) >> 6;
            if ( (boot_partition == 1) ||
                 (boot_partition == 2) ||
                 (boot_partition == 7) )
            {
                int bparg = 0x03B30000;
                bparg |= ((ecsd_data[ECSD_BOOT_CONFIG_BYTE] |
                           boot_partition) << 8);
                disp_string("sd_init: Enabling Access to Partition\r\n");
                asm("boot_partition_cmd:");
                sd_send_command( MMC_SWITCH,R1b,0,bparg, NULL);
            }
            else
            {
                disp_string("sd_init: Avoid Boot Partition Command\r\n");
                disp_string("sd_init: Reading from User Partition\r\n");
            }
        }


        disp_string("sd_init: DONE\r\n");

        sd_clear_status();

        return 1;
    }

    return 0;
}

int sd_send_stop_transmition()
{
    sd->config2 |= SD_CONFIG2_DF;   //Force clock to be on
    sd_send_command( MMC_STOP_TRANSMISSION,R1b,7, 0, NULL);
    sd->config2 &= ~SD_CONFIG2_DF;
}

int sd_read_bytes_pio( int bytes, unsigned char* dest)
{
    int i,j;

    if (sd->config2 & SD_CONFIG2_WP)
    {
        unsigned int* destwd = (unsigned int*)dest;
        // divide by 4 because FIFO is word width
        for(i = 0; i < bytes/4; i+=16)
        {
            while(!(sd->status & SD_STATUS_RF))   ;
            for(j = i; j < i+16; ++j)
            {
                // assumes FIFO got little endian
                destwd[j] = (unsigned int) sd->rxport;
            }
        }
    }
    else
    {
        for(i = 0; i < bytes; i+=16)
        {
            while(!(sd->status & SD_STATUS_RF))   ;
            for(j = i; j < i+16; ++j)
            {
                dest[j] = (unsigned char) sd->rxport;
            }
        }
    }

    return i;
}


int sd_read_bytes( int start_byte, int bytes, unsigned char* dest)
{
    int bytes_read = 0;
    RESPONSE response;

    sd_flush_fifo();

    sd_send_command( MMC_READ_MULTIPLE_BLOCK,R1,4,start_byte, &response);

    sd_clear_status();

    bytes_read = sd_read_bytes_pio( bytes, dest);

    sd_send_stop_transmition();

    return bytes_read;
}

int sd_read( unsigned long start, unsigned long end, void *dest)
{
    return sd_read_bytes( start, end, (unsigned char*) dest);
}



















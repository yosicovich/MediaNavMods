/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "sd.h"

#define EMMC_BOOT_SLOT  0

/********************************************************************/

extern int VERBOSE;
static uint8 *SOURCE = (uint8 *)0xA0200000;
static uint8 *DESTINATION = (uint8 *)0xA0300000;
static unsigned PARTITION = 0;
unsigned int BOOT_SIZE_MULT = 0;
#if EMMC_FULL_BOOT_OPERATION
unsigned int BOOT_PARTITION = 3;
unsigned int BOOT_ACK = 0;
#endif
static
unsigned LENGTH = 0;

// Read in the Extended CSD, and extract the Boot Operation
// information and configuration fields
static void emmc_get_card_defaults(void)
{
    // Get the Extended CSD to get card defaults
    if(!emmc_ext_csd_command(EMMC_BOOT_SLOT, DESTINATION))
    {
        return;
    }

    // Get the card default value for partition to access
    // for reads/writes.
    PARTITION = (DESTINATION[ECSD_BOOT_CONFIG_BYTE] &
                 BOOT_PARTITION_ACCESS_MASK) >>
                BOOT_PARTITION_ACCESS_OFFSET;
    if(PARTITION > 2)
    {
        PARTITION = 0;
    }

    // Get the BOOT_SIZE_MULT value. If this value
    // is zero, that indicates no boot partition available,
    // boot mode not supporte.
    BOOT_SIZE_MULT = DESTINATION[226];

#if (EMMC_FULL_BOOT_OPERATION == 1)
    // Get the card default value for partition to boot
    // from.
    BOOT_PARTITION = (DESTINATION[ECSD_BOOT_CONFIG_BYTE] &
                      BOOT_PARTITION_ENABLE_MASK) >>
                     BOOT_PARTITION_ENABLE_OFFSET;
    if(BOOT_PARTITION > 2)
    {
        BOOT_PARTITION = BOOT_PARTITION == 7 ? 3 : 0;
    }

    BOOT_ACK = (DESTINATION[ECSD_BOOT_CONFIG_BYTE] &
                BOOT_ACK_MASK) >>
               BOOT_ACK_OFFSET;
#endif
}

static
void
print_menu(void)
{
    printf("\n");
    printf("m. Display this help menu\n");
    printf("b. Set SOURCE address (%08X)\n", SOURCE);
    printf("c. Set DESTINATION address (%08X)\n", DESTINATION);
    printf("d. Set eMMC partition to perform read/write operations on (%d)\n",PARTITION);

    printf("f. Set/unset VERBOSE messages (%d)\n", VERBOSE);
    printf("g. Show contents of eMMC partition\n");


    printf("j. Write from SOURCE to eMMC partition\n");
    printf("k. Read from eMMC partition to DESTINATION\n");
    printf("l. Compare SOURCE and DESTINATION for LENGTH bytes\n");
    printf("n. Enable Device Boot Operation ");
    if(BOOT_SIZE_MULT == 0)
        printf("(disabled)\n");
    else
        printf("(enabled)\n");

    printf("p. Fill SOURCE with addr=addr pattern\n");

#if (EMMC_FULL_BOOT_OPERATION == 1)
    printf("q. Set eMMC partition to boot from (%d)\n",BOOT_PARTITION);
    printf("r: Enable Boot Acknowledge ");
    if(BOOT_ACK == 0)
        printf("(disabled)\n");
    else
        printf("(enabled)\n");
    printf("s. Fill SOURCE with a repeated 32bit pattern\n");
#endif
    printf("x. Exit\n");
    /* possible others: write spare */
}

static
void
emmcprog_ui (void)
{

    LENGTH = 1024*8;

    print_menu();
    while (1)
    {
        char choice[100];
        printf("\nChoice: ");
        gets(choice);
        switch (choice[0])
        {
            case 'b'
                    :
                printf("Enter new SOURCE: ");
                gets(choice);
                SOURCE = (uint8 *)strtol(choice, NULL, 16);
                print_menu();
                break;
            case 'c'
                    :
                printf("Enter new DESTINATION: ");
                gets(choice);
                DESTINATION = (uint8 *)strtol(choice, NULL, 16);
                print_menu();
                break;
            case 'd'
                    :
                printf("0: User Area\n");
                printf("1: Boot Partition 1\n");
                printf("2: Boot Partition 2\n");
                printf("Enter PARTITION to perform read/write operations on: ");
                gets(choice);
                PARTITION = (unsigned)strtol(choice, NULL, 0);
                emmc_partition_select(EMMC_BOOT_SLOT,PARTITION);
                emmc_get_card_defaults();
                print_menu();
                break;
            case 'f'
                    :
                if (VERBOSE)
                    VERBOSE = FALSE;
                else
                    VERBOSE = TRUE;
                print_menu();
                break;
            case 'g'
                    :
                {
                    unsigned partition,i;
                    unsigned long *p=DESTINATION;
                    sd_read_bytes(EMMC_BOOT_SLOT,0,LENGTH,DESTINATION);
                    for(i=0;i<LENGTH;i+=4)
                    {
                        if ( !(i%16) ) printf("\nAddr: %08X", i);
                        printf(" %08X",*p++);
                    }
                }
                break;
            case 'j'
                    :
                printf("Confirm WRITE to PARTITION %d for %d BYTES (y/n): ", PARTITION, LENGTH);
                gets(choice);
                if (choice[0] == 'y')
                    sd_write_bytes(EMMC_BOOT_SLOT, 0, LENGTH, SOURCE);
                break;
            case 'k'
                    :
                printf("Confirm READ from PARTITION %d for %d BYTES (y/n): ", PARTITION, LENGTH);
                gets(choice);
                if (choice[0] == 'y')
                    sd_read_bytes(EMMC_BOOT_SLOT,0,LENGTH,DESTINATION);
                break;
            case 'l'
                    :
                {
                    int i;
                    for (i = 0; i < LENGTH; ++i)
                    {
                        if (SOURCE[i] != DESTINATION[i])
                        {
                            printf("Compare FAILED at offset %d, expected %02X, got %02X\n",
                                   i, SOURCE[i], DESTINATION[i]);
                            break;
                        }
                    }
                    if (i == LENGTH)
                        printf("SOURCE and DESTINATION are IDENTICAL!\n");
                }
                break;
            case 'm'
                    :
                print_menu();
                break;
            case 'n':
            {
                int device;

                printf("0: Samsung moviNAND KLM4G4DEDD\n");
                printf("1: Samsung moviNAND KLM8G4DEDD\n");
                printf("   WARNING: this will erase all contents from the device.\n");
                printf("Enable Boot Operation for Device: ");
                gets(choice);
                device = (unsigned)strtol(choice, NULL, 0);
                printf("Confirm Enable Device Boot Operation for device (%d) (y/n): ", device);
                gets(choice);
                if (choice[0] == 'y')
                {
                    if(emmc_enable_boot_operation(EMMC_BOOT_SLOT, device))
                    {
                        printf("ERROR: failed to enable boot operation.\n");
                    }
                    else
                    {
                        emmc_get_card_defaults();
                    }
                }
                print_menu();
                break;
            }

            case 'p'
                    :
                {
                    uint32 j;
                    for (j = (uint32)SOURCE; j < (uint32)SOURCE + LENGTH; j += 4)
                        *(uint32 *)j = j;
                }
                break;

#if (EMMC_FULL_BOOT_OPERATION == 1)
            case 'q':
            {
                printf("0: Device Boot Operation Disable\n");
                printf("1: Boot Partition 1\n");
                printf("2: Boot Partition 2\n");
                printf("3: User Area\n");
                printf("Select Partition to Boot From: ");
                gets(choice);
                BOOT_PARTITION = (unsigned)strtol(choice, NULL, 0);
                emmc_partition_enable_boot(EMMC_BOOT_SLOT,BOOT_PARTITION);
                emmc_get_card_defaults();
                print_menu();
                break;
            }

            case 'r':
            {
                printf("Enable Boot Acknowledge (y/n): ");
                gets(choice);
                BOOT_ACK = (choice[0] == 'y') ? 1 : 0;

                if(emmc_set_boot_ack(EMMC_BOOT_SLOT, BOOT_ACK))
                {
                    printf("ERROR: failed to set boot acknowledge.\n");
                }

                emmc_get_card_defaults();

                break;

            }

            case 's':
            {
                uint32 pattern;
                uint32 index;

                printf("0: 0x11111111\n");
                printf("1: 0x22222222\n");
                printf("2: 0x33333333\n");
                printf("Select Pattern to write to SOURCE: ");
                gets(choice);
                switch((unsigned)strtol(choice, NULL, 0))
                {
                    case 0:
                        pattern = 0x11111111;
                        break;
                    case 1:
                        pattern = 0x22222222;
                        break;
                    case 2:
                        pattern = 0x33333333;
                        break;
                    default:
                        pattern = 0x00000000;
                        break;
                }

                for (index = (uint32)SOURCE; index < (uint32)SOURCE + LENGTH; index += 4)
                    *(uint32 *)index = pattern;

                break;
            }
#endif // EMMC_FULL_BOOT_OPERATION
            case 'x'
                    :
                return;
                break;
        }
    }
}

int main(int argc, char **argv)
{
    if (sd_open(EMMC_BOOT_SLOT) != NULL)
    {
        emmc_get_card_defaults();

        if ( !emmc_set_buswidth(EMMC_BOOT_SLOT,4) )
            printf("doh1\n");

//      if ( !emmc_speed_select(EMMC_BOOT_SLOT,HS_PP) )
//          printf("doh2\n");

        emmcprog_ui();
    }
    return 0;
}

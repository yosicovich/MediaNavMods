/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "nand.h"
#include "test.h"

/********************************************************************/

/*
 * These declare properly aligned 8- and 16-bit buffers for
 * transferring data to/from 8- and 16-bit NAND devices.
 */
#define LARGEST_DATA_SIZE 2048
#define LARGEST_SPARE_SIZE 256
static
union
{
    uint8 data8[LARGEST_DATA_SIZE / sizeof(uint8)];
    uint16 data16[LARGEST_DATA_SIZE / sizeof(uint16)];
}
data_buffer;

static
union
{
    uint8 data8[LARGEST_SPARE_SIZE / sizeof(uint8)];
    uint16 data16[LARGEST_SPARE_SIZE / sizeof(uint16)];
}
spare_buffer;

/********************************************************************/

extern
    int VERBOSE;
static
uint8 *SOURCE = (uint8 *)0xA0200000;
static
uint8 *DESTINATION = (uint8 *)0xA0300000;
static
unsigned PAGE = 0;
static
unsigned LENGTH = 0;
extern
int NAND_HW_ECC;

static
void
print_menu(void)
{
    printf("\n");
    printf("m. Display this help menu\n");
    printf("a. Show NAND device info\n");
    printf("b. Set SOURCE address (%08X)\n", SOURCE);
    printf("c. Set DESTINATION address (%08X)\n", DESTINATION);
    printf("d. Set default PAGE number (%d)\n", PAGE);
    printf("e. Set default LENGTH (in bytes) of range (%d, %08X)\n", LENGTH, LENGTH);
    printf("f. Set/unset VERBOSE messages (%d)\n", VERBOSE);
    printf("g. Show contents of NAND page\n");
    printf("h. Erase Range (no bad block preservation)\n");
    printf("i. Erase entire NAND device (no bad block preservation)\n");
    printf("j. Write from SOURCE to NAND pages\n");
    printf("k. Read from NAND pages to DESTINATION\n");
    printf("l. Compare SOURCE and DESTINATION for LENGTH bytes\n");
    printf("n. List bad pages\n");
    printf("o. Mark page as bad\n");
    printf("p. Fill SOURCE with addr=addr pattern\n");
	printf("q. Toggle HW ECC (Currently %s)\n", NAND_HW_ECC == 1 ? "enabled" : "disabled");
    printf("z. Reset device\n");
    printf("x. Exit\n");
    /* possible others: write spare */
}

static
void
nandprog_ui (void)
{
    if (nand_device == NULL)
    {
        printf("ERROR: No NAND device or system error\n");
        return;
    }

    LENGTH = (nand_device->data_size * nand_device->pages_per_block);
    print_menu();
    while (1)
    {
        char choice[100];
        printf("\nChoice: ");
        gets(choice);
        switch (choice[0])
        {
            case 'a'
                    :
                nand_show_device();
                break;
            case 'b'
                    :
                printf("Enter new SOURCE: ");
                gets(choice);
                SOURCE = (uint8 *)strtol(choice, NULL, 16);
                print_menu();
                break;
            case 'c'
                    :
                printf("Enter new DESTINATION: ");
                gets(choice);
                DESTINATION = (uint8 *)strtol(choice, NULL, 16);
                print_menu();
                break;
            case 'd'
                    :
                printf("Enter default starting PAGE number: ");
                gets(choice);
                PAGE = (unsigned)strtol(choice, NULL, 0);
                print_menu();
                break;
            case 'e'
                    :
                printf("Enter LENGTH (in BYTES) of the range: ");
                gets(choice);
                LENGTH = (unsigned)strtol(choice, NULL, 0);
                print_menu();
                break;
            case 'f'
                    :
                if (VERBOSE)
                    VERBOSE = FALSE;
                else
                    VERBOSE = TRUE;
                print_menu();
                break;
            case 'g'
                    :
                {
                    unsigned page;
                    printf("Enter PAGE number to display: ");
                    gets(choice);
                    page = (unsigned)strtol(choice, NULL, 10);
                    memset(&data_buffer, 0, sizeof(data_buffer));
                    memset(&spare_buffer, 0, sizeof(spare_buffer));
                    nand_dump_page(page, &data_buffer, &spare_buffer);
                }
                break;
            case 'h'
                    :
                printf("Confirm ERASE at PAGE %d for %d BYTES (y/n): ", PAGE, LENGTH);
                gets(choice);
                if (choice[0] == 'y')
                    nand_erase_pages(PAGE, LENGTH);
                break;
            case 'i'
                    :
                printf("Confirm ERASE entire NAND (no bad block preservation)? (y/n): ");
                gets(choice);
                if (choice[0] == 'y')
                    nand_erase_pages(0,
                                     nand_device->data_size *
                                     nand_device->pages_per_block *
                                     nand_device->blocks_per_device);
                break;
            case 'j'
                    :
                printf("Confirm WRITE at PAGE %d for %d BYTES (y/n): ", PAGE, LENGTH);
                gets(choice);
                if (choice[0] == 'y')
                    nand_write_image(PAGE, SOURCE, LENGTH);
                break;
            case 'k'
                    :
                printf("Confirm READ at PAGE %d for %d BYTES (y/n): ", PAGE, LENGTH);
                gets(choice);
                if (choice[0] == 'y')
                    nand_read_image(PAGE, DESTINATION, LENGTH);
                break;
            case 'l'
                    :
                {
                    int i;
                    for (i = 0; i < LENGTH; ++i)
                    {
                        if (SOURCE[i] != DESTINATION[i])
                        {
                            printf("Compare FAILED at offset %d, expected %02X, got %02X\n",
                                   i, SOURCE[i], DESTINATION[i]);
                            break;
                        }
                    }
                    if (i == LENGTH)
                        printf("SOURCE and DESTINATION are IDENTICAL!\n");
                }
                break;
            case 'm'
                    :
                print_menu();
                break;
            case 'n'
                    :
                {
                    int page;
                    for (page = 0; page <
                            nand_device->pages_per_block *
                            nand_device->blocks_per_device; ++page)
                    {
                        if (nand_page_is_bad(page) == TRUE)
                            printf("Page %d is marked bad\n", page);
                    }
                }
                break;
            case 'o'
                    :
                {
                    unsigned page;
                    unsigned bad_offset = nand_device->bad_offset;
                    if (NAND_HW_ECC)
                        bad_offset += nand_device->spare_offset_ecc;
                    printf("Writing to offset %d in the spare area\n", bad_offset);
                    printf("Enter PAGE number to mark bad: ");
                    gets(choice);
                    page = (unsigned)strtol(choice, NULL, 10);
                    spare_buffer.data16[0] = 0;
                    nand_write_spare(page, &spare_buffer, bad_offset, 1);
                }
                break;
            case 'p'
                    :
                {
                    uint32 j;
                    for (j = (uint32)SOURCE; j < (uint32)SOURCE + LENGTH; j += 4)
                        *(uint32 *)j = j;
                }
                break;
                case 'q'
                    :
                    {
                        if (NAND_HW_ECC) {
                            NAND_HW_ECC = 0;
                            nand_disable_ecc();
                        } else {
                            NAND_HW_ECC = 1;
                            nand_enable_ecc();
                        }
                    }
                break;
            case 'x'
                    :
                return;
                break;
            case 'z'
                    :
                nand_reset();
                break;
        }
    }
}

int main(int argc, char **argv)
{
    if (nand_initialize() != NULL)
    {
        nandprog_ui();
        return TEST_PASSED;
    }
    return TEST_FAILED;
}

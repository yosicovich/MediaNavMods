/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*
 * Simple example program to demonstrate the Au1 core IDLE mode
 */

#include "example.h"

/********************************************************************/

void
buttonHandler (int irq, void *arg)
{
    //printf(" button handler ");
}

void
tickHandler (int irq, void *arg)
{
    //printf(".");
}

/********************************************************************/
void
idleExample (void)
{
    int i;

#if 1

    for (i = 0; i < 10; ++i)
    {
        printf("%4d: Going to Idle ... ", i);

        /*
         * Allow printf()/UART to empty else its interrupts
         * too will cause exit from IDLE
         */
        msdelay(250);

        au1_wait();

        printf("wakeup!\n");
    }

#else /* Counter 0 Match 2 */

    /* Config IC0 for TOY_Match2 rising edge */
    cpuIrqEnable(AU1000_IRQ_TOY_M2, INT_RISING_EDGE, tickHandler);

#define MATCH 3

    /* YAMON gets the RTC/TOY up and running, lets just tweak it */
    /* trim0: Modify divider so it increments more quickly */
    wrReg(0xB1900000, 2);
    /* match2_0: Write match value which survives Idle/Sleep */
    wrReg(0xB1900010, MATCH);
    /* counter_write0: Write value to start counting at rollover */
    wrReg(0xB1900004, 0);

    cpuEnableIrqs(STATUS_IE);

    i = 100000;
    while (1)
    {
        /* match2_0: update to track counter */
        wrReg(0xB1900010, (rdReg(0xB1900040) + MATCH));
        au1_wait();
        /*
        * NOTE: The irqHandler ACKs rising edge on IC0
        */
        if ((i & 0x00FF) == 0)
            *(uint32 *)0xB1100004 = 'W';
        if (--i == 0)
            break;
    }

    cpuDisableIrqs();

    cpuIrqDisable(AU1000_IRQ_TOY_M2);

#endif
}

/********************************************************************/

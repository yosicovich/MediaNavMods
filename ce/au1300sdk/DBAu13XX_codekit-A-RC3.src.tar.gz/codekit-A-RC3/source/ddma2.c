
#include "example.h"
#include "ddma2.h"


static
void inline au1550_ddma_doorbell( DDMA_CHANNEL * chan )
{
  chan->dbell = 0xFFFFFFFF;
}
static
void inline au1550_ddma_halt( DDMA_CHANNEL * chan )
{
  chan->cfg &= ~DDMA_CHANCFG_EN;
}
static
void inline au1550_ddma_start( DDMA_CHANNEL * chan )
{
  chan->cfg |= DDMA_CHANCFG_EN;
}

typedef struct
  {
    DDMA_CHANNEL  *ptr;    // Pointer to physical channel
    int    avail;    // Available?
    int    descriptor_lock; // Lock for our descriptor resource
    DDMA_DESCRIPTOR *d_head,*d_tail; // Descriptor head/tail ptrs
    unsigned long cache_bits;   // Used to store the descriptor's cache bits
    DDMA2_CALLBACK callback;   // User's Callback routine
    unsigned int callback_arg;  // User's callback argument
    unsigned int status;    // Status pointer
    unsigned long int_cnt;   // Interrupt count for stats only
    unsigned long rx_cnt,tx_cnt;  // More stats
  }
DDMA2_CHANNEL;

typedef struct
  {
    void* src;
    void* dst;
    int len;
  }
DDMA_XFER;

/**********************************************************************
                    GLOBALS
**********************************************************************/
AU1X00_DDMA       *ddma = NULL;
DDMA2_CHANNEL      channels[DDMA_NUM_CHANNELS];


/**********************************************************************
                    Function Prototypes
**********************************************************************/

/*
 *   Function   :   ddma_get_channel
 *
 *      This function allocates a channel for a specific device, sets the default
 *  transfer size, allocates 'n' descriptors and sets the channels descriptor
 *  pointer to the beginning of the ring.
 *
 *  Channels are allocated High Number to Low Numeber. I.e. 15,14,13 etc. This
 *  assumes lower channel numbers have higher priority when priority is enabled.
 *
 *   Parameters :
 *  cnt: Number of descriptors to allocate
 *
 *     Returns :
 *      Non-NULL Pointer to the newly allocated channel
 *  NULL  Failure to allocate channel
 *
 */

CHANNEL_ID ddma2_get_next_channel(void)
{
  int i;
  for (i = DDMA_NUM_CHANNELS - 1; i >= 0; --i)
    {
      if (TRUE == channels[i].avail)
        return i;
    }

  return CHANNEL_INVALID;
}

uint32 ddma2_get_descriptor_pointer(CHANNEL_ID id)
{
  return channels[id].ptr->des_ptr;
}

void ddma2_enable_channel(CHANNEL_ID id)
{
  ddma->inten |= (1 << id); //Enable DDMA interrupt for this channel
  channels[id].ptr->cfg |= DDMA_CHANCFG_EN;
  au1550_ddma_doorbell( channels[id].ptr );
}

void ddma2_disable_channel(CHANNEL_ID id)
{
// ddma->inten &= ~(1 << id); //Disable DDMA interrupt for this channel
  channels[id].ptr->cfg &= ~DDMA_CHANCFG_EN;
// channels[id].ptr->des_ptr = 0;
}

CHANNEL_ID ddma2_request_channel(DDMA2_CALLBACK callback, unsigned int callback_arg)
{
  CHANNEL_ID id;
  /* Find an available channel for use */

  id = ddma2_get_next_channel();

  if (id != CHANNEL_INVALID)
    {
      channels[id].avail = FALSE;
      channels[id].callback = callback;
      channels[id].callback_arg = callback_arg;
    }

  return id;
}

int ddma2_free_channel(CHANNEL_ID id)
{
  ddma->inten &= ddma->inten & ~(1 << id);

  ddma2_disable_channel(id);

  channels[id].avail    = TRUE;
  channels[id].d_head   = NULL;
  channels[id].d_tail   = NULL;
  channels[id].ptr->cfg   = 0;

  return 0;
}

unsigned long flags = 0;

void inline ddma2_irq_lock(CHANNEL_ID id)
{
  //spin_lock_irqsave(&channels[id].descriptor_lock, flags);
}

void inline ddma2_irq_unlock(CHANNEL_ID id)
{
  //spin_unlock_irqrestore(&channels[id].descriptor_lock, flags);
}

DDMA_DESCRIPTOR* ddma2_get_next_descriptor(CHANNEL_ID id)
{
  return (DDMA_DESCRIPTOR*) channels[id].ptr->des_ptr;
}

void ddma2_set_status_pointer(CHANNEL_ID id, uint32* status)
{
  channels[id].ptr->stat_ptr = (uint32) status;
}

uint32 ddma2_get_channel_status(CHANNEL_ID id)
{
  return *((uint32*) KSEG1(channels[id].ptr->stat_ptr));
}

int ddma2_enable_descriptor(DDMA_DESCRIPTOR* ddma_desc, int enable)
{
  if (enable)
    ddma_desc->u.std.cmd0 |= DDMA_DESCCMD_V; //Enable valid bit
  else
    ddma_desc->u.std.cmd0 &= ~DDMA_DESCCMD_V; //Disable valid bit
}

int ddma2_insert_descriptor(CHANNEL_ID id, DDMA_DESCRIPTOR* ddma_desc)
{
  if (ddma_desc)
    {
      //Point this descriptor back to itself
      ddma_desc->u.std.nxt_ptr = (ddma_desc->u.std.nxt_ptr & ~(0x07FFFFFF)) //mask off existing next pointer
                                 | VIRTUAL_TO_NXTPTR(ddma_desc);  //Or in next pointer to current descriptor

      ddma_desc->u.std.cmd0 |= DDMA_DESCCMD_V;     //set valid

      ddma2_irq_lock(id);
      if (channels[id].d_tail == NULL)
        {
          //List is empty, insert the descriptor
          channels[id].d_head = ddma_desc;
          channels[id].d_tail = ddma_desc;

          channels[id].ptr->des_ptr = CPHYSADDR(ddma_desc);
        }
      else
        {
          //Insert descriptor at end of list
          channels[id].d_tail->u.std.nxt_ptr  = (channels[id].d_tail->u.std.nxt_ptr & ~(0x07FFFFFF)) //mask off existing next pointer
                                                | VIRTUAL_TO_NXTPTR(ddma_desc); //Or in next pointer to current descriptor
          channels[id].d_tail = ddma_desc;
        }
      ddma2_irq_unlock(id);

      //au1550_ddma2_enable_channel(id);

      return 1;
    }

  return 0;
}

void ddma2_print_descriptor_chain(CHANNEL_ID id)
{
  DDMA_DESCRIPTOR* dsc;
  printf("Channel %d Descriptor Chain:\n", id);
  dsc = 0;
  do
    {
      if (dsc == 0)
        dsc = channels[id].d_head;
      else
        {
          dsc = (DDMA_DESCRIPTOR*) KSEG1(NXTPTR_TO_PHYS(dsc->u.std.nxt_ptr));
          printf(" -> ");
        }

      printf("%X", dsc);
    }
  while (KSEG1(NXTPTR_TO_PHYS(dsc->u.std.nxt_ptr)) != (uint32) dsc);

  printf("\n");
}

/*
 *   Function   :   au1550_ddma2_interrupt
 *
 *      This function is responsible for handling DDMA interrupts.
 *
 *  User specified callbacks can be used for application processing at
 *  interrupt time.
 *
 *   Parameters :
 *
 *     Returns :
 *      Nothing
 *
 */
void ddma2_interrupt( int irq, void *dev_id )
{
  DDMA2_CHANNEL *channels = (DDMA2_CHANNEL*)dev_id;
  int i;

  for ( i = 0; i < DDMA_NUM_CHANNELS && ddma->intstat; i++ )
    {
      if ( ddma->intstat & (1 << i) )
        {
          //channels[i].d_head = NULL; //All descriptors have been transfered
          //channels[i].d_tail = NULL;
          //ddma2_disable_channel(i);

          // Call user's callback routine
          if ( NULL != channels[i].callback )
            channels[i].callback( (CHANNEL_ID) i, channels[i].callback_arg );

          // clear interrupt bits
          ddma->intstat &= ~(1 << i);
          channels[i].ptr->irq = 0;
        }
    }
}

void ddma2_enable_descriptor_interrupt(DDMA_DESCRIPTOR* desc)
{
  desc->u.std.cmd0 |= DDMA_DESCCMD_IE; //Enable interrupt for this descriptor
  asm("sync");
}

int ddma2_init( void )
{
  DPRINTF("");
  int i;

  /*
   * Point our ddma structure to correct
   * memory location
   */
// ddma = (AU1X00_DDMA*)DDMA_PHYS_ADDRESS;
  ddma = (AU1X00_DDMA*)mapPhysicalAddress(DDMA_PHYS_ADDR, sizeof(AU1X00_DDMA), 0);

  /*
   * Initialize the local channel status to 0s
   */
  memset((void*)channels,0,sizeof(channels));

  for ( i = 0; i < DDMA_NUM_CHANNELS; ++i )
    {
      channels[i].ptr    = &ddma->channel[i];
      channels[i].avail    = TRUE;
      channels[i].d_head   = NULL;
      channels[i].d_tail   = NULL;
      channels[i].ptr->cfg   = 0;
      channels[i].ptr->stat_ptr = CPHYSADDR(&channels[i].status);

      ddma2_disable_channel(i);
      //spin_lock_init( &channels[i].descriptor_lock );
    }

  /* Let the user specify the ddma config settings */
  ddma->config = 0;

  /* Disable all channel interrupts */
  ddma->inten = 0;

  /* Install the generic DDMA interrupt handler */

  cpuIrqDisable(IRQ_DDMA);
  cpuIrqEnable( IRQ_DDMA, irqHL, ddma2_interrupt, channels );
  cpuIrqConfigure(IRQ_DDMA, irqHL | GPIO_IS_DEVICE); 

  return 1;
}


int ddma2_get_byte_count(CHANNEL_ID id)
{
  if (id != CHANNEL_INVALID)
    {
      return channels[id].ptr->bytecnt;
    }
}

void ddma2_set_source_big_endian(CHANNEL_ID id, int enabled)
{
  channels[id].ptr->cfg = (channels[id].ptr->cfg & ~DDMA_CHANCFG_SBE) |
                          (enabled ? DDMA_CHANCFG_SBE : 0);
}

void ddma2_set_dest_big_endian(CHANNEL_ID id, int enabled)
{
  channels[id].ptr->cfg = (channels[id].ptr->cfg & ~DDMA_CHANCFG_DBE) |
                          (enabled ? DDMA_CHANCFG_DBE : 0);
}

// Helper Functions


/*
 * Function: ddma_descroptor_mem_mem
 *
 * This function is a helper function for setting up a memory to memory descriptor
 *
 */
DDMA_DESCRIPTOR* ddma_descriptor_mem_mem(DDMA_DESCRIPTOR* d, void* src, void* dst, int bytes)
{
  d->u.std.cmd1 = bytes;
  d->u.std.cmd0 = DDMA_DESCCMD_SID_N(DDMA_ALWAYS_HIGH_ID) |
                  DDMA_DESCCMD_DID_N(DDMA_ALWAYS_HIGH_ID) |
                  DDMA_DESCCMD_M |
                  DDMA_DESCCMD_SW_WORD |
                  DDMA_DESCCMD_DW_WORD |
                  DDMA_DESCCMD_CV;
  d->u.std.source1 = DDMA_DESCSRC_STRIDE_STS_8 | DDMA_DESCSRC_STRIDE_SAM_INC;
  d->u.std.dest1  = DDMA_DESCDST_STRIDE_DTS_8 | DDMA_DESCDST_STRIDE_DAM_INC;
  d->u.std.source0 = CPHYSADDR(src);
  d->u.std.dest0  = CPHYSADDR(dst);

  return d;
}

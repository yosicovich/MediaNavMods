/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*
 * Matt's infamous "rectangles" graphics program
 */

#include "example.h"

/********************************************************************/
static void
g_fillrect (uint16 *fb,
            int color,
            int top,
            int left,
            int bottom,
            int right,
            int xres,
            int yres)
{
    int offset = top * xres + left;
    int perline = right - left;
    int eoloff = xres - perline;
    int lines = bottom - top;
    int clp;

    while ( lines-- > 0 )
    {
        for ( clp = perline; clp > 0; --clp )
            fb[offset++] = color;
        offset += eoloff;
    }
}

/********************************************************************/


/********************************************************************/
char
rectangles (uint16 *fb, int xres, int yres, unsigned iterations)
{
    int c, t, l, b, r;
    unsigned i = 0;

    while (!kbhit())
    {
        t = srand(yres - 30);
        b = t + srand(yres - t);
        l = srand(xres - 10);
        r = l + srand(xres - l);
        c = srand(0);
        g_fillrect(fb, c, t, l, b, r, xres, yres);

        if (iterations)
            if (++i == iterations)
                break;
    }

    if (kbhit())  //Return key pressed
        return getc();
    else
        return 0;
}

/********************************************************************/


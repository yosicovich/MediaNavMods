/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "ata.h"

void __inline ata_wait_busy(volatile uint8* status)
{
    while (*status & ATA_STATUS_BSY); // wait for not busy
}

int ata_dump_sectors(short* buf, int sect, int n)
{
    int i;
    for (i = 0; i < n; ++i)
    {
        printf("Sector %d\n", sect+i);
        dump_memory(&buf[i*SECTOR_SIZE], SECTOR_SIZE);
    }
}

int ata_read_sector(void* base, int sect, int n, short *buf, int reg_size)
{
// DPRINTF("\n");
    volatile uint8* regs = (volatile uint8*) base;

    ata_wait_busy(&regs[reg_size*ATA_REG_STATUS]);

    //setup sector to read from
    regs[reg_size*ATA_REG_FEATURES]   = 0;
    regs[reg_size*ATA_REG_SECTOR_COUNT]  = n;
    regs[reg_size*ATA_REG_SECTOR_NUMBER] = (sect >> 0)  & 0xff;
    regs[reg_size*ATA_REG_CYLINDER_LOW]  = (sect >> 8)  & 0xff;
    regs[reg_size*ATA_REG_CYLINDER_HIGH] = (sect >> 16) & 0xff;
    regs[reg_size*ATA_REG_DEVICE_HEAD]  = (sect >> 24) & 0x0f | 0xe0;

    regs[reg_size*ATA_REG_COMMAND] = 0x20;
    ata_wait_busy(&regs[reg_size*ATA_REG_STATUS]);

    int i = 0;
    while ((regs[reg_size*ATA_REG_STATUS] & ATA_STATUS_DRQ) && i < ((SECTOR_SIZE/2)*n) ) // while DRQ
    {
        buf[i++] = *((uint16*) &regs[reg_size*ATA_REG_DATA]);
        ata_wait_busy(&regs[reg_size*ATA_REG_STATUS]);
    }

    //ata_dump_sectors(buf, sect, n);

    return i*2;
}

int ata_read_sectors(void* base, int sect, int n, short *buf, int reg_size)
{
    return( ata_read_sector(base, sect, n, buf, reg_size));
}

int ata_write_sectors(void* base, int sect, int n, short *buf, int reg_size)
{
    volatile uint8* regs = (volatile uint8*) base;

    ata_wait_busy(&regs[reg_size*ATA_REG_STATUS]);

    regs[reg_size*ATA_REG_SECTOR_COUNT]  = 1;
    regs[reg_size*ATA_REG_SECTOR_NUMBER] = sect & 0xff;
    regs[reg_size*ATA_REG_CYLINDER_LOW]  = (sect >> 8) & 0xff;
    regs[reg_size*ATA_REG_CYLINDER_HIGH] = (sect >> 16) & 0xff;
    regs[reg_size*ATA_REG_DEVICE_HEAD]  = (sect >> 24) & 0x0f | 0xe0;

    if (n == 1)
        regs[reg_size*ATA_REG_COMMAND] = 0x31;
    else
        regs[reg_size*ATA_REG_COMMAND] = 0xc5;

    ata_wait_busy(&regs[reg_size*ATA_REG_STATUS]);

    int i = 0;
    while ((regs[reg_size*ATA_REG_STATUS] & ATA_STATUS_DRQ ) && i < ((SECTOR_SIZE/2)*n)) // while DRQ
    {
        *((uint16*) &regs[reg_size*ATA_REG_DATA]) = buf[i++];
        ata_wait_busy(&regs[reg_size*ATA_REG_STATUS]);
    }

    return i*2;
}

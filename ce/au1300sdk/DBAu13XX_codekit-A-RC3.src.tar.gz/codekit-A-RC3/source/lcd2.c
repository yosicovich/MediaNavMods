/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*
 * Example for Au1100 LCD controller
 */

#include "example.h"

int interactive_panel_select();
int panel_init();
int panel_shutdown();
int inverted_panel_init();
int inverted_panel_shutdown();
int vga_init();
int vga_shutdown();


struct panel_settings
{
    unsigned char name[64];
    /* panel physical dimensions */
    uint32 Xres;
    uint32 Yres;
    /* panel timings */
    uint32 mode_screen;
    uint32 mode_horztiming;
    uint32 mode_verttiming;
    uint32 mode_clkcontrol;
    uint32 mode_pwmdiv;
    uint32 mode_pwmhi;
    uint32 mode_outmask;
    uint32 mode_fifoctrl;
    uint32 mode_toyclksrc;
    uint32 mode_backlight;
    uint32 mode_auxpll;
    int (*device_init)(void);
    int (*device_shutdown)(void);
};

/*
 * Controller configurations for various panels.
 */
static struct panel_settings panels[] =
{
    { /* Index 0: Samsung 800x480 TFT */
        "Samsung_800x480_TFT",
        800, 480,
        /* mode_screen   */ LCD_SCREEN_SX_N(800) | LCD_SCREEN_SY_N(480) | LCD_SCREEN_SWP,
        /* mode_horztiming */ LCD_HORZTIMING_HPW_N(5) | LCD_HORZTIMING_HND1_N(16) | LCD_HORZTIMING_HND2_N(8),
        /* mode_verttiming */ LCD_VERTTIMING_VPW_N(4) | LCD_VERTTIMING_VND1_N(8) | LCD_VERTTIMING_VND2_N(5) ,
        /* mode_clkcontrol  */ LCD_CLKCONTROL_PCD_N(1) | LCD_CLKCONTROL_IV | LCD_CLKCONTROL_IH,  // /2 = 24Mhz
        /* mode_pwmdiv  */ 0,
        /* mode_pwmhi  */ 0,
        /* mode_outmask  */ 0x00FFFFFF,
        /* mode_fifoctrl */ 0x2f2f2f2f,
        /* mode_toyclksrc   */ 0x00000004, /* 96MHz AUXPLL directly */
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll  */ 16, /* 96MHz AUXPLL */
        /* device_init  */ inverted_panel_init,
        /* device_shutdown */ inverted_panel_shutdown,
    },

    { /* Index 1: VGA 640x480 H:30.3kHz V:58Hz */
        "VGA_640x480",
        640, 480,
        /* mode_screen   */ 0x13f9df80,
        /* mode_horztiming */ 0x003c5859,
        /* mode_verttiming */ 0x00741201,
        /* mode_clkcontrol */ 0x00020001, /* /4=24Mhz */
        /* mode_pwmdiv  */ 0x00000000,
        /* mode_pwmhi  */ 0x00000000,
        /* mode_outmask  */ 0x00FFFFFF,
        /* mode_fifoctrl */ 0x2f2f2f2f,
        /* mode_toyclksrc   */ 0x00000004, /* AUXPLL directly */
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll  */ 8, /* 96MHz AUXPLL */
        /* device_init  */ vga_init,
        /* device_shutdown */ vga_shutdown,
    },

    { /* Index 2: SVGA 800x600 H:46.1kHz V:69Hz */
        "SVGA_800x600",
        800, 600,
        /* mode_screen   */ 0x18fa5780,
        /* mode_horztiming */ 0x00dc7e77,
        /* mode_verttiming */ 0x00584805,
        /* mode_clkcontrol */ 0x00020000, /* /2=48Mhz */
        /* mode_pwmdiv  */ 0x00000000,
        /* mode_pwmhi  */ 0x00000000,
        /* mode_outmask  */ 0x00FFFFFF,
        /* mode_fifoctrl */ 0x2f2f2f2f,
        /* mode_toyclksrc   */ 0x00000004, /* AUXPLL directly */
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll  */ 8, /* 96MHz AUXPLL */
        /* device_init  */ vga_init,
        /* device_shutdown */ vga_shutdown,
    },

    { /* Index 3: XVGA 1024x768 H:56.2kHz V:70Hz */
        "XVGA_1024x768",
        1024, 768,
        /* mode_screen   */ 0x1ffaff80,
        /* mode_horztiming */ 0x007d0e57,
        /* mode_verttiming */ 0x00740a01,
        /* mode_clkcontrol */ 0x000A0000, /* /1 */
        /* mode_pwmdiv  */ 0x00000000,
        /* mode_pwmhi  */ 0x00000000,
        /* mode_outmask  */ 0x00FFFFFF,
        /* mode_fifoctrl */ 0x2f2f2f2f,
        /* mode_toyclksrc   */ 0x00000004, /* AUXPLL directly */
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll  */ 6, /* 72MHz AUXPLL */
        /* device_init  */ vga_init,
        /* device_shutdown */ vga_shutdown,
    },

    { /* Index 4: XVGA 1280x1024 H:68.5kHz V:65Hz */
        "XVGA_1280x1024",
        1280, 1024,
        /* mode_screen   */ 0x27fbff80,
        /* mode_horztiming */ 0x00cdb2c7,
        /* mode_verttiming */ 0x00600002,
        /* mode_clkcontrol */ 0x000A0000, /* /1 */
        /* mode_pwmdiv  */ 0x00000000,
        /* mode_pwmhi  */ 0x00000000,
        /* mode_outmask  */ 0x00FFFFFF,
        /* mode_fifoctrl */ 0x2f2f2f2f,
        /* mode_toyclksrc   */ 0x00000004, /* AUXPLL directly */
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll  */ 10, /* 120MHz AUXPLL */
        /* device_init  */ vga_init,
        /* device_shutdown */ vga_shutdown,
    },

    { /* Index 5: Samsung 1024x768 TFT */
        "Samsung_1024x768_TFT",
        1024, 768,
        /* mode_screen   */ 0x1ffaff80,
        /* mode_horztiming */ 0x018cc677,
        /* mode_verttiming */ 0x00241217,
        /* mode_clkcontrol */ 0x00000000, //SCB 0x1 /* /4=24Mhz */
        /* mode_pwmdiv  */ 0x8000063f, //SCB 0x0
        /* mode_pwmhi  */ 0x03400000, //SCB 0x0
        /* mode_outmask  */ 0x00fcfcfc,
        /* mode_fifoctrl */ 0x2f2f2f2f,
        /* mode_toyclksrc   */ 0x00000004, /* 96MHz AUXPLL directly */
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll  */ 8, /* 96MHz AUXPLL */
        /* device_init  */ panel_init,
        /* device_shutdown */ panel_shutdown,
    },

    { /* Index 6: Toshiba 640x480 TFT */
        "Toshiba_640x480_TFT",
        640, 480,
        /* mode_screen   */ LCD_SCREEN_SX_N(640) | LCD_SCREEN_SY_N(480),
        /* mode_horztiming */ LCD_HORZTIMING_HPW_N(96) | LCD_HORZTIMING_HND1_N(51) | LCD_HORZTIMING_HND2_N(13),
        /* mode_verttiming */ LCD_VERTTIMING_VPW_N(2) | LCD_VERTTIMING_VND1_N(32) | LCD_VERTTIMING_VND2_N(11) ,
        /* mode_clkcontrol */ 0x00000001, /* /4=24Mhz */
        /* mode_pwmdiv  */ 0x8000063f,
        /* mode_pwmhi  */ 0x03400000,
        /* mode_outmask  */ 0x00fcfcfc,
        /* mode_fifoctrl */ 0x2f2f2f2f,
        /* mode_toyclksrc   */ 0x00000004, /* 96MHz AUXPLL directly */
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll  */ 8, /* 96MHz AUXPLL */
        /* device_init  */ panel_init,
        /* device_shutdown */ panel_shutdown,
    },

    { /* Index 7: Sharp 320x240 TFT */
        "Sharp_320x240_TFT",
        320, 240,
        /* mode_screen   */ LCD_SCREEN_SX_N(320) | LCD_SCREEN_SY_N(240),
        /* mode_horztiming */ LCD_HORZTIMING_HPW_N(60) | LCD_HORZTIMING_HND1_N(13) | LCD_HORZTIMING_HND2_N(2),
        /* mode_verttiming */ LCD_VERTTIMING_VPW_N(2) | LCD_VERTTIMING_VND1_N(2) | LCD_VERTTIMING_VND2_N(5) ,
        /* mode_clkcontrol */ LCD_CLKCONTROL_PCD_N(7), /* /16=6Mhz */
        /* mode_pwmdiv  */ 0x8000063f,
        /* mode_pwmhi  */ 0x03400000,
        /* mode_outmask  */ 0x00fcfcfc,
        /* mode_fifoctrl */ 0x2f2f2f2f,
        /* mode_toyclksrc   */ 0x00000004, /* 96MHz AUXPLL directly */
        /* mode_backlight   */ 0x00000000,
        /* mode_auxpll  */ 8, /* 96MHz AUXPLL */
        /* device_init  */ panel_init,
        /* device_shutdown */ panel_shutdown,
    },
};

#define NUM_PANELS (sizeof(panels) / sizeof(struct panel_settings))

static AU1200_LCD* lcd  = (AU1200_LCD*)  KSEG1(LCD_PHYS_ADDR);
static AU1X00_SYS* sys  = (AU1X00_SYS *) KSEG1(SYS_PHYS_ADDR);
static int panel = 0;

void lcd_irq_deinit();
void lcd_irq_init();

void lcd_adjust_timing()
{
    uint8 hpw  = 59;
    uint8 hnd1 = 14;
    uint8 hnd2 = 14;
    uint8 vpw  = 2;
    uint8 vnd1 = 17;
    uint8 vnd2 = 5;

    char c;

    do
    {
        lcd->horztiming = LCD_HORZTIMING_HPW_N(hpw) | LCD_HORZTIMING_HND1_N(hnd1) | LCD_HORZTIMING_HND2_N(hnd2);
        lcd->verttiming = LCD_VERTTIMING_VPW_N(vpw) | LCD_VERTTIMING_VND1_N(vnd1) | LCD_VERTTIMING_VND2_N(vnd2);
        printf("------------------------------\n");
        printf("hpw: %3d, hnd1: %3d, hnd2: %3d\n", hpw, hnd1, hnd2);
        printf("vpw: %3d, vnd1: %3d, vnd2: %3d\n", vpw, vnd1, vnd2);

        c = getc();
        switch (c)
        {
            case 'h': --hpw;  break;
            case 'H': ++hpw;  break;
            case 'g': --hnd1; break;
            case 'G': ++hnd1; break;
            case 'j': --hnd2; break;
            case 'J': ++hnd2; break;
            case 'v': --vpw;  break;
            case 'V': ++vpw;  break;
            case 'c': --vnd1; break;
            case 'C': ++vnd1; break;
            case 'b': --vnd2; break;
            case 'B': ++vnd2; break;
            default: break;
        }

    }
    while (c != 'q');
}

int interactive_panel_select()
{
    char ch;
    int p = -1;
    int i;

    printf("Interactive Panel Selection Menu\n");

    while (p < 0)
    {
        for (i = 0; i < NUM_PANELS; ++i)
            printf("%X) %s\n", i, panels[i].name);

        printf(": ");
        ch = getc();
        printf("\n");

        switch (ch)
        {
            case '0': p = 0; break;
            case '1': p = 1; break;
            case '2': p = 2; break;
            case '3': p = 3; break;
            case '4': p = 4; break;
            case '5': p = 5; break;
            case '6': p = 6; break;
            case '7': p = 7; break;
            case '8': p = 8; break;
            case '9': p = 9; break;
            case 'a':
            case 'A': p = 10; break;
            case 'b':
            case 'B': p = 11; break;
            case 'c':
            case 'C': p = 12; break;
            case 'd':
            case 'D': p = 13; break;
            case 'e':
            case 'E': p = 14; break;
            case 'f':
            case 'F': p = 15; break;
            default:  p = -1;
        }

        if (p >= NUM_PANELS)
            panel = -1;

        if (p < 0)
            printf("\n\nInvalid Panel!\n");
    }

    return p;
}

void lcd_shutdown()
{
    if (lcd->screen & LCD_SCREEN_SEN)
    {
        lcd_irq_deinit(); //Disable LCD IRQ

        lcd->winenable = 0; //Disable all windows
        lcd->screen &= ~LCD_SCREEN_SEN; //Disable the LCD

        do
        {
            lcd->intstatus = lcd->intstatus;
        }
        while ((lcd->intstatus & LCD_INT_SD) == 0); //Wait for the LCD FIFO's to drain

        if (panels[panel].device_shutdown != NULL)
            panels[panel].device_shutdown(); //Run device specific deinitialization routine
    }
}

unsigned int lcd_init()
{
    lcd_shutdown();

    // Get the panel information/display mode
    panel = (bcsr->switches >> 8) & 0x0F;

    cpuIrqConfigure(29,GPIO_IS_DEVICE);
    cpuIrqConfigure(30,GPIO_IS_DEVICE);
    cpuIrqConfigure(31,GPIO_IS_DEVICE);

    DPRINTF("Using panel %d: %s\n\n", panel, panels[panel].name);

    DPRINTF("Using Internal LCD Clock: %X\n", panels[panel].mode_toyclksrc);
    sys->auxpll = panels[panel].mode_auxpll;
    sys->clksrc = (sys->clksrc & ~0x0000001f) | panels[panel].mode_toyclksrc;
    msdelay(100);

    //Setup LCD controller
    DPRINTF("lcd_horztiming = 0x%08X\n", panels[panel].mode_horztiming);
    DPRINTF("lcd_verttiming = 0x%08X\n", panels[panel].mode_verttiming);
    DPRINTF("lcd_clkcontrol = 0x%08X\n", panels[panel].mode_clkcontrol);
    DPRINTF("lcd_pwmdiv     = 0x%08X\n", panels[panel].mode_pwmdiv);
    DPRINTF("lcd_pwmhi      = 0x%08X\n", panels[panel].mode_pwmhi);
    DPRINTF("lcd_outmask    = 0x%08X\n", panels[panel].mode_outmask);
    DPRINTF("lcd_fifoctrl   = 0x%08X\n", panels[panel].mode_fifoctrl);
    DPRINTF("lcd_screen     = 0x%08X\n", panels[panel].mode_screen);

    lcd->screen  = 0; //Ensure screen is disabled before reconfiguring
    lcd->horztiming = panels[panel].mode_horztiming;
    lcd->verttiming = panels[panel].mode_verttiming;
    lcd->clkcontrol = panels[panel].mode_clkcontrol;
    lcd->outmask = panels[panel].mode_outmask;
    lcd->fifoctrl = panels[panel].mode_fifoctrl;
    lcd->pwmdiv  = panels[panel].mode_pwmdiv;
    lcd->pwmhi  = panels[panel].mode_pwmhi;
    lcd->screen  = panels[panel].mode_screen;

    //Enable the LCD Controller
    lcd->screen |= LCD_SCREEN_SEN;

    if (panels[panel].device_init != NULL)
        panels[panel].device_init(); //Run device specific initialization routine

    lcd_irq_init();

    return 1;
}

struct LCD_IRQ
{
    BOOL enabled;
    void (*handler)(int, void*);
    void* arg;
};
static
struct LCD_IRQ lcd_irqs[18];
#define NUM_LCD_IRQS (sizeof(lcd_irqs) / sizeof(struct LCD_IRQ))

void lcd_irq(int number, void* arg)
{
    //static int hex = 0;
    uint32 status = lcd->intstatus;
    //DPRINTF("%d, arg: %X, status: %X\n", number, arg, lcd->intstatus);

    int i;
    for (i = 0; i < NUM_LCD_IRQS; ++i)
    {
        if (status & (1 << i) && lcd_irqs[i].handler != NULL)
        {
            lcd_irqs[i].handler(i, lcd_irqs[i].arg);
        }
    }

    lcd->intstatus = status; //Clear all interrupts
}

void lcd_irq_deinit()
{
    cpuIrqDisable(30);
}

void lcd_irq_init()
{
    int i;

    for (i = 0; i < NUM_LCD_IRQS; ++i)
    {
        lcd_irqs[i].enabled = FALSE;
        lcd_irqs[i].handler = NULL;
    }

    lcd->intstatus = lcd->intstatus; //Clear interrupts

    cpuIrqEnable(IRQ_LCD, irqHL, lcd_irq, NULL);
}

int lcd_irq_enable(int irq, void (*handler)(int, void *), void* arg, BOOL enable)
{
    DPRINTF("irq: %d, handler: %X, arg: %x, %s\n", irq, handler, arg, enable == TRUE ? "TRUE" : "FALSE");
    lcd->intenable  = (lcd->intenable & ~(1<<irq))
                      | ((enable == TRUE) ? (1<<irq) : 0);

    lcd_irqs[irq].enabled = enable;
    lcd_irqs[irq].handler = (enable == TRUE) ? handler : NULL;
    lcd_irqs[irq].arg = arg;

    lcd->intstatus = lcd->intstatus; //Clear pending interrupts
}

int panel_init()
{
    DPRINTF("\n");
    bcsr->board |= (BCSR_SPECIFIC_LCDVEEOFF | BCSR_SPECIFIC_LCDVDDOFF);
    bcsr->board |= BCSR_SPECIFIC_LCDBLOFF;
    asm volatile (" sync");
}

int inverted_panel_init()
{
    DPRINTF("\n");
    bcsr->board &= ~(BCSR_SPECIFIC_LCDVEEOFF | BCSR_SPECIFIC_LCDVDDOFF);
    bcsr->board |= BCSR_SPECIFIC_LCDBLOFF;
    asm volatile (" sync");
}

int panel_shutdown()
{
    DPRINTF("\n");
    //Disable LCD power & backlight
    bcsr->board &= ~(BCSR_SPECIFIC_LCDVEEOFF | BCSR_SPECIFIC_LCDVDDOFF);
    bcsr->board &= ~BCSR_SPECIFIC_LCDBLOFF;
    asm volatile (" sync");
}

int inverted_panel_shutdown()
{
    bcsr->board |= (BCSR_SPECIFIC_LCDVEEOFF | BCSR_SPECIFIC_LCDVDDOFF);
    bcsr->board &= ~BCSR_SPECIFIC_LCDBLOFF;
    asm volatile (" sync");
}

int vga_init()
{
    DPRINTF("\n");
    //Nothing to do here
}

int vga_shutdown()
{
    DPRINTF("\n");
    //Nothing to do here
}

void lcd_set_background_color(uint8 r, uint8 g, uint8 b)
{
    DPRINTF("RGB(%d, %d, %d): %X\n", r, g, b, LCD_BACKCOLOR_SBGR_N(r) | LCD_BACKCOLOR_SBGG_N(g) | LCD_BACKCOLOR_SBGB_N(b));
    lcd->backcolor = LCD_BACKCOLOR_SBGR_N(r) | LCD_BACKCOLOR_SBGG_N(g) | LCD_BACKCOLOR_SBGB_N(b);
}

int lcd_get_screen_width()
{
    DPRINTF("%d\n", panels[panel].Xres);
    return panels[panel].Xres;
}

int lcd_get_screen_height()
{
    DPRINTF("%d\n", panels[panel].Yres);
    return panels[panel].Yres;
}

/********************************************************************/

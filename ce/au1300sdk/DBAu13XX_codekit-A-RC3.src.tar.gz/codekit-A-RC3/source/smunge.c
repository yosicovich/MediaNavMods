/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include <stdio.h>
/* #include <process.h>*/
#include <string.h>

FILE   *in, *out;
char   recbuf[256];
int    reclen;
unsigned long recaddr;
unsigned long offset = 0;
int    do_swizzle = 0;
int    do_swap = 0;

int  load_srec(char *line)
{
    int  i, c;

    if ( line[0] != 's' && line[0] != 'S' )
        return 0;

    switch (line[1])
    {
        case '1':
            sscanf(line+2,"%2x%4x",&reclen,&recaddr);
            line += 8;
            reclen -= 2;
            break;

        case '2':
            sscanf(line+2,"%2x%6x",&reclen,&recaddr);
            line += 10;
            reclen -= 3;
            break;

        case '3':
            sscanf(line+2,"%2x%8x",&reclen,&recaddr);
            line += 12;
            reclen -= 4;
            break;

        default:
            return 0;
    }

    reclen -= 1;

    for ( i = 0; i < reclen; ++i )
    {
        sscanf(line,"%2x",&c);
        recbuf[i] = c;
        line += 2;
    }
    return 1;
}

void dump_srec()
{
    int    cksm, i;
    unsigned long addr = recaddr + offset;
    int    len = reclen + 5;

    cksm = ((len >> 8) & 0x0ff) + (len & 0x00ff);
    cksm += (addr >> 24) & 0x0ff;
    cksm += (addr >> 16) & 0x0ff;
    cksm += (addr >> 8) & 0x0ff;
    cksm += addr & 0x0ff;
    fprintf(out,"S3%02X%08X",len,addr);
    for ( i = 0; i < reclen; ++i )
    {
        cksm += recbuf[i] & 0x00ff;
        fprintf(out,"%02X",recbuf[i] & 0x0ff);
    }
    fprintf(out,"%02X\n",(~cksm) & 0x0ff);
}

void swizzle()
{
    int  c, i;

    for ( i = 0; i < reclen; i += 4 )
    {
        c = recbuf[i];
        recbuf[i] = recbuf[i + 3];
        recbuf[i + 3] = c;
        c = recbuf[i + 1];
        recbuf[i + 1] = recbuf[i + 2];
        recbuf[i + 2] = c;
    }
}

void swap_halfwords()
{
    int  c, i;

    for ( i = 0; i < reclen; i += 4 )
    {
        c = recbuf[i];
        recbuf[i] = recbuf[i + 2];
        recbuf[i + 2] = c;
        c = recbuf[i + 1];
        recbuf[i + 1] = recbuf[i + 3];
        recbuf[i + 3] = c;
    }
}

void mungeline(char *s)
{
    if ( load_srec(s) )
    {
        if ( do_swizzle ) swizzle();
        if ( do_swap ) swap_halfwords();
        dump_srec();
    }
    else
        fputs(s,out);
}

void smunge(char *filename)
{
    char buf[132];

    in = fopen(filename,"r");
    if ( in == NULL )
    {
        fprintf(stderr,"Can't open input file %s\n",filename);
        exit(1);
    }

    strncpy(buf,filename,120);
    strcat(buf,".m");
    out = fopen(buf,"w");
    if ( out == NULL )
    {
        fprintf(stderr,"Can't open output file %s\n",buf);
        exit(1);
    }

    while ( fgets(buf,120,in) != NULL )
    {
        mungeline(buf);
    }

    fclose(in);
    fclose(out);
}

void option(char *str)
{
    unsigned long sa, da;

    switch (str[1])
    {
        case 'o':
            if ( sscanf(str+2,"%x=%x",&sa,&da) )
            {
                offset = da - sa;
                printf("changing block address 0x%08x to 0x%08x\n",sa,da);
            }
            else
            {
                fprintf(stderr,"bad format for -o: should be -o<srec-addr>=<mem-addr>\n");
                exit(1);
            }
            break;
        case 's':
            if ( str[2] == 'b' )
            {
                do_swizzle = 1;
                printf("swizzling bytes.\n");
            }
            else if ( str[2] == 'h' )
            {
                do_swap = 1;
                printf("swapping halfwords.\n");
            }
            break;

        default:
            fprintf(stderr,"Unknown option - %s\n",str);
    }
}

void main(int argc, char **argv)
{
    while ( -- argc )
    {
        ++argv;
        if ( **argv == '-' )
            option(*argv);
        else
            smunge(*argv);
    }
}

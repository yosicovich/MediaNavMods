/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "window.h"
#include "image.h"

void window_init_id(WINDOW_ID id);

//#undef LCD_PHYS_ADDR
//#define LCD_PHYS_ADDR  0x00500000
static AU1200_LCD* lcd = (AU1200_LCD*) KSEG1(LCD_PHYS_ADDR);
static WINDOW_INFO windows[WINDOW_COUNT];
static FRAME_BUFFER_INFO on_chip_ram_info;
static OCFB_INFO ocfb;

void window_init_id(WINDOW_ID id)
{
    DPRINTF("%d\n", id);
    if (id < WINDOW_COUNT)
    {
        windows[id].regs = (WINDOW_REGS*) &lcd->window[id];

        windows[id].buffer_selected = BUFFER_0;

        windows[id].fb_address[0] = (FRAME_BUFFER_ADDRESS) 0;
        windows[id].fb_address[1] = (FRAME_BUFFER_ADDRESS) 0;

        windows[id].regs->ctrl0 = 0;
        windows[id].regs->ctrl1 = LCD_WINCTRL1_PRI_N(id);
        windows[id].regs->ctrl2 = 0;
        windows[id].regs->buf0 = 0;
        windows[id].regs->buf1 = 0;
        windows[id].regs->bufctrl = 0;

        windows[id].ocfb.wscale = SCALE_NONE;
        windows[id].ocfb.hscale = SCALE_NONE;
        windows[id].ocfb.enabled = FALSE;
    }
}

void window_init()
{
    lcd->winenable = 0;
    window_init_id(WINDOW_0);
    window_init_id(WINDOW_1);
    window_init_id(WINDOW_2);
    window_init_id(WINDOW_3);
}

void window_enable(WINDOW_ID id, BOOL enable)
{
    lcd->winenable = (lcd->winenable & ~LCD_WINENABLE_N(id))
                     | (enable == TRUE ? LCD_WINENABLE_N(id) : 0);
    DPRINTF("%d: %s\n", id, (enable == TRUE) ? "TRUE" : "FALSE");
}

void window_set_origin(WINDOW_ID id, int x, int y)
{
    DPRINTF("%d: %d x %d\n", id, x, y);
    windows[id].regs->ctrl0 = (windows[id].regs->ctrl0 & ~(LCD_WINCTRL0_OX | LCD_WINCTRL0_OY))
                              | LCD_WINCTRL0_OX_N(x)
                              | LCD_WINCTRL0_OY_N(y);
}

void window_set_alpha(WINDOW_ID id, uint8 alpha)
{
    DPRINTF("%d: %d\n", id, alpha);
    windows[id].regs->ctrl0 = (windows[id].regs->ctrl0 & ~LCD_WINCTRL0_A)
                              | LCD_WINCTRL0_A_N(alpha);
}

void window_enable_alpha_overide(WINDOW_ID id, BOOL overide)
{
    DPRINTF("%d: %s\n", id, (overide == TRUE) ? "TRUE" : "FALSE");
    windows[id].regs->ctrl0 = (windows[id].regs->ctrl0 & ~LCD_WINCTRL0_AEN)
                              | (overide ? LCD_WINCTRL0_AEN : 0);
}

PRIORITY window_get_priority(WINDOW_ID id)
{
    DPRINTF("%d: %d\n", id, LCD_WINCTRL1_PRI_U(windows[id].regs->ctrl1));
    return LCD_WINCTRL1_PRI_U(windows[id].regs->ctrl1);
}

void window_swap_priorities(WINDOW_ID id1, WINDOW_ID id2)
{
    DPRINTF("%d <-> %d\n", id1, id2);
    PRIORITY p = window_get_priority(id1);
    windows[id1].regs->ctrl1 = (windows[id1].regs->ctrl1 & ~LCD_WINCTRL1_PRI)
                               | LCD_WINCTRL1_PRI_N(window_get_priority(id2));
    windows[id2].regs->ctrl1 = (windows[id2].regs->ctrl1 & ~LCD_WINCTRL1_PRI)
                               | LCD_WINCTRL1_PRI_N(p);
}

// This function doesn't just set the priority,
// it finds the window who currently has the desired priority, and swaps the two priorities
void window_set_priority(WINDOW_ID id, PRIORITY priority)
{
    DPRINTF("%d: %d\n", id, priority);
    int i;
    for (i = 0; window_get_priority(i) != priority; ++i); //Find the window with this priority

    if (i != id)
        window_swap_priorities(id, i); //If the window doesn't already have this priority, swap with the window that does
}

void window_enable_underflow_irq(WINDOW_ID id, void (*handler)(int, void *), void* arg, BOOL enable)
{
    DPRINTF("%d: %s\n", id, enable == TRUE ? "TRUE" : "FALSE");
    int irq = 10 + id;

    lcd_irq_enable(irq, handler, arg, enable);
}

void window_set_pipe(WINDOW_ID id, PIPE pipe)
{
    DPRINTF("%d: %d\n", id, pipe);

    windows[id].regs->ctrl1 = (windows[id].regs->ctrl1 & ~LCD_WINCTRL1_PIPE)
                              | (pipe == PIPE_RIGHT ? LCD_WINCTRL1_PIPE : 0);
}

void window_set_color_channel_orientation(WINDOW_ID id, CCO cco)
{
    DPRINTF("%d: %d\n", id, cco);
    windows[id].regs->ctrl1 = (windows[id].regs->ctrl1 & ~LCD_WINCTRL1_CCO)
                              | (cco == CCO_BGR ? LCD_WINCTRL1_CCO : 0);
}

void window_set_pixel_ordering(WINDOW_ID id, PIXEL_ORDERING po)
{
    DPRINTF("%d: %d\n", id, po);
    windows[id].regs->ctrl1 = (windows[id].regs->ctrl1 & ~LCD_WINCTRL1_PO)
                              | LCD_WINCTRL1_PO_N(po);

    windows[id].fb_info.pixel_info.pixel_ordering = po;
}

void window_set_buffer_format(WINDOW_ID id, PIXEL_FORMAT format)
{
    DPRINTF("%d: %d\n", id, format);
    windows[id].fb_info.pixel_info = pixel_configs[format];

    windows[id].regs->ctrl1 = (windows[id].regs->ctrl1 & ~LCD_WINCTRL1_FRM)
                              | LCD_WINCTRL1_FRM_N(windows[id].fb_info.pixel_info.pixel_format);

    window_set_pixel_ordering(id, windows[id].fb_info.pixel_info.pixel_ordering);
}

void window_set_buffer_line_width(WINDOW_ID id, int bytes)
{
    DPRINTF("%d: %d\n", id, bytes);
    windows[id].regs->ctrl2 = (windows[id].regs->ctrl2 & ~LCD_WINCTRL2_BX)
                              | LCD_WINCTRL2_BX_N(bytes);
}

void window_set_width(WINDOW_ID id, int width)
{
    DPRINTF("%d: %d\n", id, width);
    int scale = 1;

    if (windows[id].ocfb.enabled == TRUE)
    {
        switch (windows[id].ocfb.wscale)
        {
            case SCALE_2X: scale = 2; break;
            case SCALE_4X: scale = 4; break;
        }
    }
    windows[id].fb_info.width = width;
    windows[id].regs->ctrl1 = (windows[id].regs->ctrl1 & ~LCD_WINCTRL1_SZX)
                              | LCD_WINCTRL1_SZX_N(width*scale);

    if (windows[id].ocfb.enabled == TRUE)
        window_set_buffer_line_width(id, width);
    else
        window_set_buffer_line_width(id, (width * windows[id].fb_info.pixel_info.memory_width) / 8);
}

void window_set_height(WINDOW_ID id, int height)
{
    DPRINTF("%d: %d\n", id, height);
    int scale = 1;

    if (windows[id].ocfb.enabled == TRUE)
    {
        switch (windows[id].ocfb.hscale)
        {
            case SCALE_2X: scale = 2; break;
            case SCALE_4X: scale = 4; break;
        }
    }
    windows[id].fb_info.height = height;
    windows[id].regs->ctrl1 = (windows[id].regs->ctrl1 & ~LCD_WINCTRL1_SZY)
                              | LCD_WINCTRL1_SZY_N(height*scale);
}

void window_set_size(WINDOW_ID id, int width, int height)
{
    window_set_width(id, width);
    window_set_height(id, height);
}

void window_set_colorkey_mode(WINDOW_ID id, CKMODE ckmode)
{
    DPRINTF("%d: %d\n", id, ckmode);
    windows[id].regs->ctrl2 = (windows[id].regs->ctrl2 & ~LCD_WINCTRL2_CKMODE)
                              | LCD_WINCTRL2_CKMODE_N(ckmode);
}

void window_set_doublebuffer_mode(WINDOW_ID id, DBMODE dbmode)
{
    DPRINTF("%d: %d\n", id, dbmode);
    windows[id].regs->ctrl2 = (windows[id].regs->ctrl2 & ~LCD_WINCTRL2_DBM)
                              | (dbmode == DBMODE_RETRACE ? LCD_WINCTRL2_DBM : 0);
}

void window_set_scale(WINDOW_ID id, SCALE wscale, SCALE hscale)
{
    DPRINTF("%d: %dx%d\n", id, wscale, hscale);
    windows[id].regs->ctrl2 = (windows[id].regs->ctrl2 & ~(LCD_WINCTRL2_SCX | LCD_WINCTRL2_SCY))
                              | LCD_WINCTRL2_SCX_N(wscale)
                              | LCD_WINCTRL2_SCY_N(hscale);

    windows[id].ocfb.wscale = wscale;
    windows[id].ocfb.hscale = hscale;

    window_set_size(id, windows[id].fb_info.width, windows[id].fb_info.height);
}

void window_set_buffer(WINDOW_ID id, BUFFER_ID buffer_id, FRAME_BUFFER_ADDRESS address)
{
    DPRINTF("%d, %d: %X\n", id, buffer_id, address);
    switch (buffer_id)
    {
        case BUFFER_0 : windows[id].regs->buf0 = (uint32) KUSEG(address); break;
        case BUFFER_1 : windows[id].regs->buf1 = (uint32) KUSEG(address); break;
        default: break;
    }

    windows[id].fb_address[buffer_id] = address;
}

void window_set_RAM_array_usage(WINDOW_ID id, RAM_ARRAY_USAGE ram_array)
{
    DPRINTF("%d: %d\n", id, ram_array);
    windows[id].regs->ctrl2 = (windows[id].regs->ctrl2 & ~LCD_WINCTRL2_RAM)
                              | LCD_WINCTRL2_RAM_N(ram_array);

    windows[id].ocfb.enabled = FALSE;

    if (ram_array != RAM_NONE)
    {
        if (ram_array == ONCHIP_FB)
        {
            //Set the window buffers to the on-chip frame buffer (for fills and image copies)
            windows[id].ocfb.enabled = TRUE;
            window_set_buffer(id, BUFFER_0, (FRAME_BUFFER_ADDRESS) 0 /*&lcd->palette*/);
            window_set_buffer(id, BUFFER_1, (FRAME_BUFFER_ADDRESS) 0 /*&lcd->palette*/);
        }
        else if (ram_array == PALETTE_LOOKUP)
        {
            on_chip_ram_info.width = 256;
            on_chip_ram_info.height = 1;
            //Set the correct pixel format for the palette RAM 'buffer'
            on_chip_ram_info.pixel_info = pixel_configs[PF_32BPP]; //The on-chip RAM's pixel format

            window_set_buffer_format(id, PF_PALETTE); //The window buffer's pixel format, palette indecies
        }
        else if (ram_array == GAMMA_LOOKUP)
        {
            on_chip_ram_info.width = 256;
            on_chip_ram_info.height = 1;
            //Set the correct pixel format for the gamma RAM 'buffer'
            on_chip_ram_info.pixel_info = pixel_configs[PF_GAMMA];  //The on-chip RAM's pixel format

            //window_set_buffer_format(id, PF_32BPP);  //The window buffer's pixel format, 32 bpp
        }

        //RAM array is only available to the left pipe
        window_set_pipe(id, PIPE_LEFT);
    }
}

void window_set_buffer_override(WINDOW_ID id, BUFFER_ID buffer_id)
{
    DPRINTF("%d: %d\n", id, buffer_id);
    windows[id].regs->bufctrl = (windows[id].regs->bufctrl & ~LCD_WINBUFCTRL_DBN)
                                | buffer_id;
    windows[id].buffer_selected = buffer_id;
}


void window_palatize_image(WINDOW_ID id, BUFFER_ID buffer_id, IMAGE* image, uint32* pallete, int pallete_size)
{
    DPRINTF("%d, %d: %s (%X), Pallete: %X (%d entries)\n", id, buffer_id, image->info.description, image, pallete, pallete_size);
    if (buffer_id == ONCHIP_FB)
    {
        fb_palatize_image(&lcd->palette, &windows[id].fb_info, image, pallete, pallete_size);
    }
}

void window_fill(WINDOW_ID id, BUFFER_ID buffer_id, uint8 a, uint8 r, uint8 g, uint8 b)
{
    DPRINTF("%d, %d: aRGB(%d, %d, %d, %d)\n", id, buffer_id, a, r, g, b);
    fb_fill(windows[id].fb_address[buffer_id], &windows[id].fb_info, a, r, g, b);
}

void window_fill_horizontal_gradient(WINDOW_ID id, BUFFER_ID buffer_id, uint8 a1, uint8 r1, uint8 g1, uint8 b1, uint8 a2, uint8 r2, uint8 g2, uint8 b2)
{
    DPRINTF("%d, %d: aRGB(%d, %d, %d, %d) -> aRGB(%d, %d, %d, %d)\n", id, buffer_id, a1, r1, g1, b1, a2, r2, g2, b2);
    if (buffer_id == BUFFER_ON_CHIP) //Are we filling the pallete ram with a gradient?
        fb_fill_horizontal_gradient((FRAME_BUFFER_ADDRESS) &lcd->palette, &on_chip_ram_info, a1, r1, g1, b1, a2, r2, g2, b2);
    else
        fb_fill_horizontal_gradient(windows[id].fb_address[buffer_id], &windows[id].fb_info, a1, r1, g1, b1, a2, r2, g2, b2);
}

void window_fill_transparency_gradient(WINDOW_ID id, BUFFER_ID buffer_id, uint8 r, uint8 g, uint8 b)
{
    DPRINTF("%d, %d: RGB(%d, %d, %d)\n", id, buffer_id, r, g, b);
    window_fill_horizontal_gradient(id, buffer_id, ALPHA_OPAQUE, r, g, b, ALPHA_TRANSPARENT, r, g, b);
    //fb_fill_transparency_gradient(windows[id].fb_address[buffer_id], &windows[id].fb_info, r, g, b);
}

void window_copy_image(WINDOW_ID id, BUFFER_ID buffer_id, IMAGE* image, int x, int y)
{
    DPRINTF("%d, %d: %s (%X), XY(%d, %d)\n", id, buffer_id, image->info.description, image, x, y);
    fb_copy_image(windows[id].fb_address[buffer_id], &windows[id].fb_info, image, x, y);
}

void window_fill_rectangle(WINDOW_ID id, BUFFER_ID buffer_id, int x, int y, int w, int h, uint8 a, uint8 r, uint8 g, uint8 b)
{
    DPRINTF("%d, %d: (%d,%d)->(%d,%d), aRGB(%d,%d,%d,%d)\n", id, buffer_id, x, y, w, h, a, r, g, b);
    fb_fill_rectangle(windows[id].fb_address[buffer_id], &windows[id].fb_info, x, y, w, h, a, r, g, b);
}

void window_center(WINDOW_ID id)
{
    window_set_origin(id, (lcd_get_screen_width() / 2) - (windows[id].fb_info.width / 2), (lcd_get_screen_height() / 2) - (windows[id].fb_info.height / 2));
}

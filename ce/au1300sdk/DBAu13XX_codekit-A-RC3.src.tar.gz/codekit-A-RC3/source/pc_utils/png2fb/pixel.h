#ifndef PIXEL_H
#define PIXEL_H

typedef enum
{
    PF_1BPP,
    PF_2BPP,
    PF_4BPP,
    PF_8BPP,
    PF_12BPP,
    PF_16BPP_6_5_5,
    PF_16BPP_5_6_5,
    PF_16BPP_5_5_6,
    PF_16BPPI_1_5_5_5,
    PF_16BPPI_5_5_5_1,
    PF_16BPPA_1_5_5_5,
    PF_16BPPA_5_5_5_1,
    PF_24BPP_0_8_8_8,
    PF_32BPP
} PIXEL_FORMAT;


typedef struct
{
    PIXEL_FORMAT pixel_format;
    int pixel_ordering;
    int bpp;
    int memory_width;
    int r_mask;
    int g_mask;
    int b_mask;
    int a_mask;
    int r_shift;
    int g_shift;
    int b_shift;
    int a_shift;
    int r_scale;
    int g_scale;
    int b_scale;
    int a_scale;
}
PIXEL_INFO;

static
PIXEL_INFO pixel_configs[] =
{
    { //0
        PF_1BPP   //pixel_format
    },
    { //1
        PF_2BPP   //pixel_format
    },
    { //2
        PF_4BPP   //pixel_format
    },
    { //3
        PF_8BPP,  //pixel_format
        0,    //pixel_ordering
        8,    //bpp
        8,    //memory_width
        0x30,   //r_mask
        0x0C,   //g_mask
        0x03,   //b_mask
        0xC0,   //a_mask
        4,    //r_shift
        2,    //g_shift
        0,    //b_shift
        6,    //a_shift
        6,    //r_scale
        6,    //g_scale
        6,    //b_scale
        6    //a_scale
    },
    { //4: 12bpp (4/4/4)
        PF_12BPP,  //pixel_format
        0,    //pixel_ordering
        12,    //bpp
        16,    //memory_width
        0x0F00,   //r_mask
        0x00F0,   //g_mask
        0x000F,   //b_mask
        0x0000,   //a_mask
        8,    //r_shift
        4,    //g_shift
        0,    //b_shift
        0,    //a_shift
        4,    //r_scale
        4,    //g_scale
        4,    //b_scale
        8    //a_scale
    },
    { //5: 16bpp (6/5/5)
        PF_16BPP_6_5_5, //pixel_format
        0,    //pixel_ordering
        16,    //bpp
        16,    //memory_width
        0xFC00,   //r_mask
        0x03E0,   //g_mask
        0x001F,   //b_mask
        0x0000,   //a_mask
        10,    //r_shift
        5,    //g_shift
        0,    //b_shift
        0,    //a_shift
        2,    //r_scale
        3,    //g_scale
        3,    //b_scale
        8    //a_scale
    },
    { //6: 16bpp (5/6/5)
        PF_16BPP_5_6_5, //pixel_format
        0,    //pixel_ordering
        16,    //bpp
        16,    //memory_width
        0xF800,   //r_mask
        0x07E0,   //g_mask
        0x001F,   //b_mask
        0x0000,   //a_mask
        11,    //r_shift
        5,    //g_shift
        0,    //b_shift
        0,    //a_shift
        3,    //r_scale
        2,    //g_scale
        3,    //b_scale
        8    //a_scale
    },
    { //7: 16bpp (5/5/6)
        PF_16BPP_5_5_6, //pixel_format
        0,    //pixel_ordering
        16,    //bpp
        16,    //memory_width
        0xF800,   //r_mask
        0x07C0,   //g_mask
        0x003F,   //b_mask
        0x0000,   //a_mask
        11,    //r_shift
        6,    //g_shift
        0,    //b_shift
        0,    //a_shift
        3,    //r_scale
        3,    //g_scale
        2,    //b_scale
        8    //a_scale
    },
    { //8: 16bpp w/ intensity (1/5/5/5)
        PF_16BPPI_1_5_5_5
    },
    { //9: 16bpp w/ intensity (5/5/5/1)
        PF_16BPPI_5_5_5_1
    },
    { //10: 16bpp w/ alpha (1/5/5/5)
        PF_16BPPA_1_5_5_5, //pixel_format
        0,     //pixel_ordering
        16,     //bpp
        16,     //memory_width
        0x7C00,    //r_mask
        0x03E0,    //g_mask
        0x001F,    //b_mask
        0x8000,    //a_mask
        10,     //r_shift
        5,     //g_shift
        0,     //b_shift
        15,     //a_shift
        3,     //r_scale
        3,     //g_scale
        3,     //b_scale
        7     //a_scale
    },
    { //11: 16bpp w/ alpha (5/5/5/1)
        PF_16BPPA_5_5_5_1, //pixel_format
        0,     //pixel_ordering
        16,     //bpp
        16,     //memory_width
        0xF800,    //r_mask
        0x07C0,    //g_mask
        0x003E,    //b_mask
        0x0001,    //a_mask
        11,     //r_shift
        6,     //g_shift
        1,     //b_shift
        0,     //a_shift
        3,     //r_scale
        3,     //g_scale
        3,     //b_scale
        7     //a_scale
    },
    { //12: 24bpp (0/8/8/8)
        PF_24BPP_0_8_8_8, //pixel_format
        0,     //pixel_ordering
        24,     //bpp
        32,     //memory_width
        0x00FF0000,   //r_mask
        0x0000FF00,   //g_mask
        0x000000FF,   //b_mask
        0x00000000,   //a_mask
        16,     //r_shift
        8,     //g_shift
        0,     //b_shift
        0,     //a_shift
        0,     //r_scale
        0,     //g_scale
        0,     //b_scale
        8     //a_scale
    },
    { //13: 32bpp w/ alpha (8/8/8/8)
        PF_32BPP,  //pixel_format
        0,    //pixel_ordering
        32,    //bpp
        32,    //memory_width
        0x00FF0000,  //r_mask
        0x0000FF00,  //g_mask
        0x000000FF,  //b_mask
        0xFF000000,  //a_mask
        16,    //r_shift
        8,    //g_shift
        0,    //b_shift
        24,    //a_shift
        0,    //r_scale
        0,    //g_scale
        0,    //b_scale
        0    //a_scale
    }
};

//Scale, Shift, Mask pixel
static
unsigned int __inline pixel_convert(const
                                    PIXEL_INFO info, unsigned char a, unsigned char r, unsigned char g, unsigned char b)
{
    return (((a >> info.a_scale) << info.a_shift) & info.a_mask)
           | (((r >> info.r_scale) << info.r_shift) & info.r_mask)
           | (((g >> info.g_scale) << info.g_shift) & info.g_mask)
           | (((b >> info.b_scale) << info.b_shift) & info.b_mask);
}

#endif //PIXEL_H

#!/bin/bash

#This script converts png image files into srec files for use as a bootsplash on the db1300.  
#In order to use this script prepare an image at the required screen resolution and save it here,
#in the png format. Run the script.


if [ $# == 0 ] || [ $# -gt 1 ]

	then

		{ 
			echo
			echo "Usage : ./png2fb.exe <filename.png>"
			echo
			exit 0
		}

fi

./png2fb.exe -i $1 PF_32BPP 
dd if=images.bin bs=256 skip=1 of=images2.bin
mv images2.bin images.bin
objcopy -O srec --input-target=binary --adjust-vma=0xBFA00000 images.bin `echo $1 | sed -e 's/\.png/\.rec/g'`
rm images.bin


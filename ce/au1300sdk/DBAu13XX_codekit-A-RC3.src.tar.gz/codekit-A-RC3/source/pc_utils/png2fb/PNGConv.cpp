//objcopy -O srec --input-target=binary --adjust-vma=0xA0200000 test.bin test.srec


#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include <string>

#include "PNGConv.h"

using namespace std;

PNGConv::PNGConv(const
                 std::string& dest) :
    png_ptr_(NULL),
    info_ptr_(NULL),
    end_info_(NULL),
    row_pointers_(NULL),
    output_file_(dest.c_str())
{
  pixel_formats_["PF_1BPP"]   = PF_1BPP;
  pixel_formats_["PF_2BPP"]   = PF_2BPP;
  pixel_formats_["PF_4BPP"]   = PF_4BPP;
  pixel_formats_["PF_8BPP"]   = PF_8BPP;
  pixel_formats_["PF_12BPP"]   = PF_12BPP;
  pixel_formats_["PF_16BPP_6_5_5"] = PF_16BPP_6_5_5;
  pixel_formats_["PF_16BPP_5_6_5"] = PF_16BPP_5_6_5;
  pixel_formats_["PF_16BPP_5_5_6"] = PF_16BPP_5_5_6;
  pixel_formats_["PF_16BPPI_1_5_5_5"] = PF_16BPPI_1_5_5_5;
  pixel_formats_["PF_16BPPI_5_5_5_1"] = PF_16BPPI_5_5_5_1;
  pixel_formats_["PF_16BPPA_1_5_5_5"] = PF_16BPPA_1_5_5_5;
  pixel_formats_["PF_16BPPA_5_5_5_1"] = PF_16BPPA_5_5_5_1;
  pixel_formats_["PF_24BPP_0_8_8_8"] = PF_24BPP_0_8_8_8;
  pixel_formats_["PF_32BPP"]   = PF_32BPP;
}

PNGConv::~PNGConv()
{
  output_file_.close();
}

int PNGConv::convert_image(const
                           std::string& source, const
                           std::string& pixel_format)
{
  int result = 0;
  png_ptr_ = NULL;
  info_ptr_ = NULL;
  end_info_ = NULL;
  row_pointers_ = NULL;

  if (load_image(source))
    {
      if (pixel_formats_.find(pixel_format) != pixel_formats_.end())
        {
          result = save_image(pixel_formats_[pixel_format], source);
        }
      else
        printf("Error: Invalid Pixel Format\n");

      png_destroy_read_struct(&png_ptr_, &info_ptr_, &end_info_);
    }
  else
    printf("Error: Unable to Load Image '%s'\n", source.c_str());

  return result;
}

int PNGConv::load_image(const
                        std::string& png_path)
{
  png_byte header[8]; // 8 is the maximum size that can be checked

  FILE *fp = fopen(png_path.c_str(), "rb");
  if (!fp)
    {
      return 0;
    }
  fread(header, 1, 8, fp);
  if (png_sig_cmp(header, 0, 8))
    {
      return 0;
    }


  png_ptr_ = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
  if (!png_ptr_)
    return 0;

  info_ptr_ = png_create_info_struct(png_ptr_);
  if (!info_ptr_)
    {
      png_destroy_read_struct(&png_ptr_, (png_infopp)NULL, (png_infopp)NULL);
      return 0;
    }

  end_info_ = png_create_info_struct(png_ptr_);
  if (!end_info_)
    {
      png_destroy_read_struct(&png_ptr_, &info_ptr_, (png_infopp)NULL);
      return 0;
    }

  png_init_io(png_ptr_, fp);
  png_set_sig_bytes(png_ptr_, 8);

  png_read_png(png_ptr_, info_ptr_, PNG_TRANSFORM_IDENTITY, NULL);
  row_pointers_ = png_get_rows(png_ptr_, info_ptr_);
  return 1;
}

int PNGConv::save_image(PIXEL_FORMAT format, std::string input_path)
{
  char a, r, g, b;
  int x, offset;
  int pos;
  unsigned int pixel;
  IMAGE_INFO info;
  memset((void*) &info, 0, sizeof(info));

  input_path.erase(0, input_path.find_last_of("/") + 1);
  input_path.erase(0, input_path.find_last_of("\\") + 1);
  input_path.erase(input_path.find_last_of("."));

  info.signature = IMAGE_SIGNATURE;
  strcpy(info.description, input_path.c_str());
  info.width = info_ptr_->width;
  info.height = info_ptr_->height;
  info.pixel_info = pixel_configs[format];



// printf("PNGConv: Info size: %d\n", sizeof(info));
  output_file_.write((char*) &info, sizeof(info));
  /* printf("Image: %dx%d\n", info_ptr_->width, info_ptr_->height);
   printf("a_scale: %d\n", info.format.a_scale);
   printf("r_scale: %d\n", info.format.r_scale);
   printf("g_scale: %d\n", info.format.g_scale);
   printf("b_scale: %d\n", info.format.b_scale);

   printf("a_shift: %d\n", info.format.a_shift);
   printf("r_shift: %d\n", info.format.r_shift);
   printf("g_shift: %d\n", info.format.g_shift);
   printf("b_shift: %d\n", info.format.b_shift);

   printf("a_mask: %X\n", info.format.a_mask);
   printf("r_mask: %X\n", info.format.r_mask);
   printf("g_mask: %X\n", info.format.g_mask);
   printf("b_mask: %X\n", info.format.b_mask);*/

  for (int y = 0; y < info_ptr_->height; ++y)
    {
      for (x = 0, offset = 0; x < info_ptr_->width; ++x)
        {
          switch (info_ptr_->color_type)
            {
            case
                PNG_COLOR_TYPE_RGB:
              r = row_pointers_[y][offset++];
              g = row_pointers_[y][offset++];
              b = row_pointers_[y][offset++];
              a = 0xFF;
              break;
            case
                PNG_COLOR_TYPE_RGB_ALPHA:
              r = row_pointers_[y][offset++];
              g = row_pointers_[y][offset++];
              b = row_pointers_[y][offset++];
              a = row_pointers_[y][offset++];
              break;
            }

          //Scale, Shift, Mask pixel
          pixel = pixel_convert(info.pixel_info, a, r, g, b);

          output_file_.write((char*) &pixel, info.pixel_info.memory_width / 8);
        }
    }

  return true;
}


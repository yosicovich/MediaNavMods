
#include "PNGConv.h"
#include <map>
#include <string>
#include <vector>

#define PIXEL_FORMAT   'f'
#define OUTPUT_PATH    'o'
#define INPUT_PATH    'i'

#define DEFAULT_PIXEL_FORMAT "PF_16BPP_5_6_5"
#define DEFAULT_OUTPUT_PATH  "images.bin"

using namespace std;


typedef struct
  {
    string png_path;
    string pixel_format;
  }
InputImage;

typedef map<char, string> ArgumentMap;
typedef vector<InputImage> InputFileVector;

void parse_arguments(ArgumentMap& args, InputFileVector& inputFiles, int argc, char* argv[])
{
  InputImage img;
  char flag;

  for (int i = 0; i < argc; ++i)
    if (argv[i][0] == '-')
      {
        flag = argv[i++][1];
        switch (flag)
          {
          case
              INPUT_PATH:
            if (i < argc && argv[i][0] != '-')
              img.png_path = argv[i];
            else
              break;

            if (i+1 < argc && argv[i+1][0] != '-')
              img.pixel_format = argv[++i];
            else
              img.pixel_format = DEFAULT_PIXEL_FORMAT;

            inputFiles.push_back(img);

            break;
          default
              :
            if (i >= argc || argv[i][0] == '-')
              args[flag] = "";
            else
              args[flag] = string(argv[i]);
            break;
          }
      }
}


int main(int argc, char* argv[])
{
  ArgumentMap args;
  InputFileVector inputs;
  args[PIXEL_FORMAT] = DEFAULT_OUTPUT_PATH;
  args[OUTPUT_PATH] = DEFAULT_OUTPUT_PATH;

  parse_arguments(args, inputs, argc, argv);

  printf("PNG -> Frame Buffer Converter\n");
  printf("\tInput Image Count: %d\n", inputs.size());
  printf("\tOutput File: %s\n", args[OUTPUT_PATH].c_str());
  PNGConv png(args[OUTPUT_PATH]);

  for (InputFileVector::iterator iter = inputs.begin(); iter != inputs.end(); ++iter)
    {
      printf("-----------------------------------------------------------------\n");
      if (png.convert_image((*iter).png_path, (*iter).pixel_format))
        {
          printf("Converted Image: '%s'\nOutput Format: %s\n", (*iter).png_path.c_str(), (*iter).pixel_format.c_str());
        }
      else
        printf("Error Converting Image '%s'\n", (*iter).png_path.c_str());
    }
  return 0;
}

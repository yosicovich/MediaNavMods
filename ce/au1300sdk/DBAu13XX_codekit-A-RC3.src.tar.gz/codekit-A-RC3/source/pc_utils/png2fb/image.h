#ifndef IMAGE_H
#define IMAGE_H

#define IMAGE_SIGNATURE  0x00081544

#include "pixel.h"

typedef struct
{
    int signature;
    char description[100];
    int width;
    int height;
    PIXEL_INFO pixel_info;
    char padding[256 - (sizeof(PIXEL_INFO) + (sizeof(char)*100) + (sizeof(int)*3))]; //256 byte header
}
IMAGE_INFO;

typedef struct
{
    IMAGE_INFO info;
    void* pixel_data;
}
IMAGE;

#endif //IMAGE_H

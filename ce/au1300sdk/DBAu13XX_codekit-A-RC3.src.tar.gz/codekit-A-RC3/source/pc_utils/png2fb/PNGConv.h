#ifndef PNGCONV_H
#define PNGCONV_H

#include <string>
#include <map>
#include <png.h>

#include <fstream>
#include "../../../include/image.h"

typedef std::map<std::string, PIXEL_FORMAT> PixelFormatMap;

class PNGConv
{
public:
    PNGConv(const
            std::string&);
    virtual ~PNGConv();
    int convert_image(const
                      std::string&, const
                      std::string&);
                      
private:
    int load_image(const
                   std::string&);
    int save_image(PIXEL_FORMAT, std::string);
    int get_width();
    int get_height();
    
    png_structp png_ptr_;
    png_infop info_ptr_;
    png_infop end_info_;
    png_bytep * row_pointers_;
    PixelFormatMap pixel_formats_;
    std::ofstream output_file_;
};

#endif //PNGCONV_H

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "test.h"

//#define DEBUG_MESSAGES

#define WAIT_FOR_STATUS(x) \
        while(!(aes->status & x))

#ifdef DEBUG_MESSAGES
#define PRINT_AES_REG   \
                                printf("\nThe value of AES is:");\
                                printf("\nconfig reg :0x%X", aes->config); \
                                printf("\nstatus reg :0x%X", aes->status); \
                                printf("\ninterrupt reg: 0x%X", aes->intcause);

#define PRINT_AES_TC_REG   \
                                printf("\nThe value of AES_TC is:");\
                                printf("\nconfig reg :0x%X", aes_tc.config); \
                                printf("\nstatus reg :0x%X", aes_tc.status); \
                                printf("\ninterrupt reg: 0x%X", aes_tc.intcause);

#define PRINT_LINE_NUM(x) \
                                printf("\nExecuting line # %d %s", __LINE__, x); \
                                x;
#define PRINT_DATA_BLOCK(x, array) \
                                printf("\n%s", x); \
                                printf("\n0x%X", array[0]);        \
                                printf("\n0x%X", array[1]);        \
                                printf("\n0x%X", array[2]);        \
                                printf("\n0x%X", array[3]);        \
                                printf("\n0x%X", array[4]);        \
                                printf("\n0x%X", array[5]);        \
                                printf("\n0x%X", array[6]);        \
                                printf("\n0x%X", array[7]);        \
                                printf("\n0x%X", array[8]);        \
                                printf("\n0x%X", array[9]);        \
                                printf("\n0x%X", array[10]);        \
                                printf("\n0x%X", array[11]);        \
                                printf("\n0x%X", array[12]);        \
                                printf("\n0x%X", array[13]);        \
                                printf("\n0x%X", array[14]);        \
                                printf("\n0x%X", array[15]);

#define WRITE_REG(reg,x) \
                reg = x; \
                printf("\nWrite address 0x%X, Data 0x%X", &reg, x);

#define READ_REG(x,reg) \
                x = reg; \
                printf("\nRead address 0x%X, Data 0x%X", &reg, x);
#else
#define PRINT_AES_REG   \

#define PRINT_AES_TC_REG   \

#define PRINT_LINE_NUM(x) \
                                x;
#define PRINT_DATA_BLOCK(x, array) \

#define WRITE_REG(reg,x) \
                reg = x; \

#define READ_REG(x,reg) \
                x = reg; \

#endif
int AES_Read_Initial_Value_Check()
{
    AU1200_AES* aes = (AU1200_AES*)KSEG1(AES_PHYS_ADDR);

    DPRINTF("Reset Value Check\n");
    PRINT_AES_REG;

    // after reset value is all Zero
    if (((aes->config) & 0x0000007F != 0) ||
            ((aes->status) & 0x0000003F != 0) ||
            ((aes->intcause) & 0x00000007 != 0))
    {
        //printf("\t Test Fail!");
        return TEST_FAILED;
    }
    else
    {
        //printf("\t Test Pass!");
        return TEST_PASSED;
    }
}


int AES_Reg_Scan(AU1200_AES aes_tc)
{
    int i=0;
    // reset the register, default value is all zero for the registers
    AU1200_AES* aes = (AU1200_AES*)KSEG1(AES_PHYS_ADDR);

    DPRINTF("Inside AES_Reg_Scan function\n");

    //PRINT_AES_REG;
    //memset(aes, 0, sizeof(AU1200_AES));
    //PRINT_AES_REG;

    aes->config = aes_tc.config;
    aes->status = aes_tc.status;
    aes->intcause = aes_tc.intcause;

    PRINT_AES_TC_REG;
    PRINT_AES_REG;

    // Note: PS bit can not be set if do not have proper configuration
    // write Zero to intcause bit only
    if ((aes->config != aes_tc.config) ||
            (aes->status != (aes_tc.status & 0x0000003E)))
        // (aes->intcause != aes_tc.intcause))
    {
        //printf("\t Test Fail!");
        return TEST_FAILED;
    }
    else
    {
        //printf("\t Test Pass!");
        return TEST_PASSED;
    }
}

/*
   AU1200_AES aes_tc,

   char scheme, char mode, char undef_block_count, long number_of_blocks,
   long* key, long* IV, long* input_data_block,  // input
   char reuse_key, char replay_key, char IKG,  // tentative input
   char sys_clock_divider, char interrupt_en,

   long *replaykey, long* output_data_block     // output

*/


int AES_driver
(
    AU1200_AES aes_tc,
    long *input_data_block,  //input
    unsigned long number_of_blocks,  // input
    long* key, long* IV,   // input
    long* replaykey,       // output
    long *output_data_block // output
)
{
    int i=0;
    long longTemp;
    // reset the register, default value is all zero for the registers
    AU1200_AES* aes = (AU1200_AES*)KSEG1(AES_PHYS_ADDR);

    DPRINTF("\nInside AES_driver function.....");
    PRINT_DATA_BLOCK("input_data_block", input_data_block);

    //*** configuration sequence (CS, Configuration Reg)
    // ************************************************
    WRITE_REG(aes->config, aes_tc.config);
    //*** status sequence (SS, Status Reg)
    // ************************************************
    WRITE_REG(aes->status, aes_tc.status | AES_STATUS_PS ); //| AES_STATUS_IE);

    PRINT_AES_REG;
    //*** block count sequence (BS, Rx Reg)
    // ************************************************
    if (!(aes->config & AES_CONFIG_UC)) // UC = 0 means defined block count
        WRITE_REG(aes->indata, number_of_blocks);

    //*** key sequence (KS, Rx Reg )
    // ************************************************
    if (!(aes->config & AES_CONFIG_RK))
    {
        WRITE_REG(aes->indata, key[0]);
        WRITE_REG(aes->indata, key[1]);
        WRITE_REG(aes->indata, key[2]);
        WRITE_REG(aes->indata, key[3]);
    }

    //*** Initialization Vector Sequence (IVS, Rx Reg )
    // ************************************************
    int mode = (aes->config)>>5 & 0x03;
// printf("\nmode is : 0x%x", mode);
    if (mode > 0 && mode < 4)
    {
        PRINT_LINE_NUM("Must enter here for CBC, CFB, OFB IV! ");

//            WAIT_FOR_STATUS(AES_STATUS_IN)
        WRITE_REG(aes->indata, IV[0]);
        WRITE_REG(aes->indata, IV[1]);
        WRITE_REG(aes->indata, IV[2]);
        WRITE_REG(aes->indata, IV[3]);
    }

    //*** Payload Sequence (PS,Rx Reg )
    // ************************************************
    // write block 0 first
    WAIT_FOR_STATUS(AES_STATUS_IN);
    for (i=0; i<4; i++)
    {
//                 aes->indata = *input_data_block++;
        longTemp = *input_data_block++;
        WRITE_REG(aes->indata, longTemp);
    }
    number_of_blocks--;

    // write block 1...N.
    // Note: For now, all En/Description should have defined number of blocks
    if (!(aes_tc.config & AES_CONFIG_UC))
    {
        DPRINTF("\n number_of_blocks = %X", number_of_blocks);

        while ( number_of_blocks > 0)
        {
            // Write data block (Rx Reg)
            WAIT_FOR_STATUS(AES_STATUS_IN); /* In buffer is available*/
            for (i=0; i<4; i++)
            {
                //aes->indata = *input_data_block++;
                longTemp = *input_data_block++;
                WRITE_REG(aes->indata, longTemp);
            }
            // read enc/decrypted data block  (Tx Reg)
            PRINT_AES_REG;
            WAIT_FOR_STATUS(AES_STATUS_OUT); /* Out buffer is available*/
            for (i=0; i<4; i++)
            {
//                                 *output_data_block++ = aes->outdata;
                READ_REG(longTemp, aes->outdata);
                *output_data_block++ = longTemp;
            }
            number_of_blocks--;

        }
    }

    // read the last enc/decrypted data block  (Tx Reg)
    WAIT_FOR_STATUS(AES_STATUS_OUT); /* Out buffer is available*/
    for (i=0; i<4; i++)
    {
        //   *output_data_block++ = aes->outdata;
        READ_REG(longTemp, aes->outdata);
        *output_data_block++ = longTemp;
    }
    //*** key replay Sequence (KRS, Tx Reg)
    // ************************************************
    if (aes_tc.config & AES_CONFIG_RPK)
    {
        PRINT_LINE_NUM("\n Replay key... ");
//                 WAIT_FOR_STATUS(AES_STATUS_OUT); /* Out buffer is available*/
        for (i=0; i<4; i++)
        {
            READ_REG(longTemp, aes->outdata);
            *replaykey++ = longTemp;
        }
    }


}

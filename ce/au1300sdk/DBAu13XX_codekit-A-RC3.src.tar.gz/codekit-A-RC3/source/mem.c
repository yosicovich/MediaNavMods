/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"

extern int _edata, _fbss, _end;
extern int _data, _data_actual;

//Relocates Initialized Data Segment from FLASH to RAM
void copy_data_segment()
{
    int *src = &_data_actual; //End of text segment (start of data segment)
    int *dst = &_data;   //beginning of data segment (in RAM)

    if (src != dst)
    {
        while (dst < &_edata)
            *dst++ = *src++;
    }
}


void initialize_bss()
{
    int *start = &_fbss;
    int *end = &_end;

    while (start < end)
        *start++ = 0;
}

int compare_memory(char* data1, char* data2, int bytes)
{
    int offset;
    //DPRINTF("Compare: %X, %X, %d\n", data1, data2, bytes);
    for (offset = 0; offset < bytes; ++offset)
    {
        if (data1[offset] != data2[offset])
        {
            DPRINTF("Compare Error, Offset: %d, %X != %X (%02X != %02X)\n", offset, &data1[offset], &data2[offset], data1[offset], data2[offset]);
            return 0;
        }
    }

    return 1;
}

void dump_memory(char* src, int bytes)
{
    int i, j;
    int found = 0;
    for (i = 0; i < bytes; i+=16)
    {
        printf("%08X: ", &src[i]);

        for (j = 0; j < 16; ++j)
        {
            printf("%02X ", src[i+j] & 0x0FF);
        }

        for (j = 0; j < 16; ++j)
        {
            if (src[i+j] < 127 && src[i+j] > 31)
            {
                printf("%c", src[i+j]);
                if (src[i+j] == 'H')
                {
                    if (src[i+j+1] == 'E' && src[i+j+2] == 'L' && src[i+j+3] == 'L' && src[i+j+4] == 'O')
                    {
                        found = 1;
                    }
                }
            }
            else
                printf(".");
        }

        printf("\n");

        //if(found)
        //{
        // printf("Found that shit!\n");
        // getc();
        //}
    }
}

void randomize_memory(char* start, int bytes)
{
    while (--bytes >= 0)
        start[bytes] = srand(0xFF);
}

void swap_bytes(uint32* bytes)
{
    *bytes =  ((*bytes >> 24) & 0x000000FF) |
              ((*bytes >>  8) & 0x0000FF00) |
              ((*bytes <<  8) & 0x00FF0000) |
              ((*bytes << 24) & 0xFF000000) ;
}

void swizzle_memory(uint32* start, int bytes)
{
    int i;
    DPRINTF("%X, %d bytes\n", start, bytes);
    for (i = 0; i < bytes/4; ++i)
        swap_bytes(&start[i]);
}

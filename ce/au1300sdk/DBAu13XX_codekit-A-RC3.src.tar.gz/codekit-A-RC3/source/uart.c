/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"

/********************************************************************/

static AU1X00_SYS *sys=NULL;

//#define USE_UART_IRQ
#ifdef USE_UART_IRQ
#define AU1000_UART unsigned int

#define MAX_UARTS 4
#define FIFO_SIZE 1024



typedef volatile struct UART_t
{
    AU1X00_UART *uart;
    int uartNumber;
    int irq;
    int nextrx, lastrx, sizerx;
    int nexttx, lasttx, sizetx;
    uint32 rx, rxerr;
    uint32 tx, txerr;
    uint32 rxirq;
    uint32 txirq;
    uint32 mdmirq;
    uint32 linirq;
    int maxrfifo;
    int maxtfifo;
    uint8 rxfifo[FIFO_SIZE];
    uint8 txfifo[FIFO_SIZE];

}
UART_t;

static UART_t uarts[MAX_UARTS] =
{
    0
};


/********************************************************************/
void
uartStats (int uartNumber)
{
    UART_t *p = &uarts[uartNumber];
    printf("UART %d:\n", uartNumber);
    printf(" irq: %d\n", p->irq);
    printf(" inten:    %08X\n", p->uart->inten);
    printf(" fifoctrl: %08X\n", p->uart->fifoctrl);
    printf(" linectrl: %08X\n", p->uart->linectrl);
    printf(" mdmctrl:  %08X\n", p->uart->mdmctrl);
    printf(" linestat: %08X\n", p->uart->linestat);
    printf(" mdmstat:  %08X\n", p->uart->mdmstat);
    printf(" rxirq: %d\n", p->rxirq);
    printf(" nextrx %d, lastrx %d, sizerx %d\n",
           p->nextrx, p->lastrx, p->sizerx);
    printf(" rx %d, rxerr %d\n", p->rx, p->rxerr);
    printf(" maxrfifo %d\n", p->maxrfifo);
    printf(" txirq: %d\n", p->txirq);
    printf(" nexttx %d, lasttx %d, sizetx %d\n",
           p->nexttx, p->lasttx, p->sizetx);
    printf(" tx %d, txerr %d\n", p->tx, p->txerr);
    printf(" maxtfifo %d\n", p->maxtfifo);
    printf(" lineirq: %d\n", p->linirq);
    printf(" mdmirq: %d\n", p->mdmirq);
}

/********************************************************************/
void
uartPutChar (int uartNumber, int ch)
{
    uint32 ipl;
    UART_t *p = &uarts[uartNumber];
    int spin;
    int chs = 0;

    /*
     * The example infrastructure has no way to "block the process"
     * if the transmit queue is full, so must spin...
     */
    if (ch >= 0)
    {
        spin = TRUE;
        while (spin)
        {
            /*
             * Queue manipulation is a critical section activity
             */
            ipl = cpuDisableIrqs();

            /* Enqueue the character */
            if (p->sizetx <= (FIFO_SIZE - 2))
            {
                p->txfifo[p->nexttx] = ch;
                p->sizetx++;
                p->nexttx++;
                if (p->nexttx == (FIFO_SIZE - 1))
                    p->nexttx = 0;
                spin = FALSE;
            }
            else
            {
                /* re-enable interrupts to allow queue to drain */
                cpuEnableIrqs(ipl);
            }
        }
        cpuEnableIrqs(ipl);
    }

    /* Send character(s) */
    if (p->uart->linestat & (UART_LINESTAT_TE | UART_LINESTAT_TT))
    {
        ipl = cpuDisableIrqs();

        /* Dequeue a character */
        if (p->sizetx)
        {
            /* Fill Tx FIFO best we can */
            while (p->uart->linestat & (UART_LINESTAT_TE | UART_LINESTAT_TT))
            {
                ch = p->txfifo[p->lasttx];
                p->sizetx--;
                p->lasttx++;
                if (p->lasttx == (FIFO_SIZE - 1))
                    p->lasttx = 0;

                /* send the character */
                p->uart->txdata = ch;
                p->uart->inten |= UART_INTEN_TIE;
                ++p->tx;
                if (++chs > p->maxtfifo) p->maxtfifo = chs;
                if (p->sizetx == 0) break; /* no more chars */
            }
        }
        else
        {
            /* nothing to send, disable Tx IRQ */
            //p->uart->inten &= ~UART_INTEN_TIE;
            /* fix!!! doing this causes Tx stalls */
        }

        cpuEnableIrqs(ipl);
    }
}

/********************************************************************/
void
uartGetChar (int uartNumber, int *ch)
{
    uint32 ipl;
    int c, chs = 0;
    UART_t *p = &uarts[uartNumber];

    if ((p->sizerx == 0) && (ch != NULL))
    {
        /* We must wait for a character to arrive...this example
        code doesn't have the ability to "block a process" */
        //while ((p->uart->linestat & UART_LINESTAT_DR) == 0) ;
        while (p->sizerx == 0) ;
    }

    /*
     * Queue manipulation is a critical section activity
     */
    ipl = cpuDisableIrqs();

    /* Extract all characters received */
    while (p->uart->linestat & UART_LINESTAT_DR)
    {
        ++chs;
        c = (p->uart->rxdata & 0x00FF);
        ++p->rx;

        /* Enqueue the character */
        if (p->sizerx <= (FIFO_SIZE - 2))
        {
            p->rxfifo[p->nextrx] = c;
            p->sizerx++;
            p->nextrx++;
            if (p->nextrx == (FIFO_SIZE - 1))
                p->nextrx = 0;
        }
        else ++p->rxerr;
        /* else character is dropped! */
    }

    if (chs > p->maxrfifo) p->maxrfifo = chs;

    /* Dequeue a character */
    if (ch != NULL)
    {
        *ch = p->rxfifo[p->lastrx];
        p->sizerx--;
        p->lastrx++;
        if (p->lastrx == (FIFO_SIZE - 1))
            p->lastrx = 0;
    }

    cpuEnableIrqs(ipl);
}

/********************************************************************/
int
uartCheckChar (int uartNumber)
{
    UART_t *p = &uarts[uartNumber];
    uint32 ipl;
    int value;

    /*
     * Queue manipulation is a critical section activity
     */
    ipl = cpuDisableIrqs();

    if (p->sizerx)
        value = TRUE;
    else
        value = FALSE;

    cpuEnableIrqs(ipl);

    return value;
}

/********************************************************************/
void
uartHandler (int irqNumber, UART_t *p)
{
    volatile uint32 intcause, linestat, mdmstat;

    intcause = p->uart->intcause;
    switch (intcause & UART_INTCAUSE_IID)
    {
        case UART_INTCAUSE_IID_TBA: /* tx buffer available */
            ++p->txirq;
            uartPutChar(p->uartNumber, -1);
            break;
        case UART_INTCAUSE_IID_RDA: /* rx data available */
        case UART_INTCAUSE_IID_CTO: /* char time out */
            ++p->rxirq;
            uartGetChar(p->uartNumber, NULL);
            break;
        case UART_INTCAUSE_IID_MS:  /* modem status change */
            mdmstat = p->uart->mdmstat;
            ++p->mdmirq;
            break;
        case UART_INTCAUSE_IID_RLS: /* line status change */
            linestat = p->uart->linestat;
            ++p->linirq;
            break;
        default:
            break;
    }
}

/********************************************************************/
void
uartInit (int uartNumber, int baud)
{
    UART_t *p;
    uint32 clkdiv;
    phys_t physAddr;

    /* Make sure not in use already */
    if ((uartNumber < 0) || (uartNumber >= MAX_UARTS))
        return;

    if (uarts[uartNumber].uart != NULL)
        return;

    /* get the system parameter area */
    sys = (AU1X00_SYS *)
          mapPhysicalAddress(SYS_PHYS_ADDR, sizeof(AU1X00_SYS), 0);

    /* Pointer to master structure */
    p = &uarts[uartNumber];
    p->uartNumber = uartNumber;

    if (uartNumber == 0)
    {
        physAddr = UART0_PHYS_ADDR;
        p->irq = IRQ_UART0;
    }
#if defined(AU1000) || defined(AU1100)
    if (uartNumber == 1)
    {
        physAddr = UART1_PHYS_ADDR;
        p->irq = IRQ_UART1;
    }
#endif
#if defined(AU1000)
    if (uartNumber == 2)
    {
        physAddr = UART2_PHYS_ADDR;
        p->irq = IRQ_UART2;
    }
#endif
    if (uartNumber == 3)
    {
        physAddr = UART3_PHYS_ADDR;
        p->irq = IRQ_UART3;
    }

    p->nextrx = p->lastrx = p->sizerx = 0;
    p->nexttx = p->lasttx = p->sizetx = 0;

    /* Now map the peripheral */
    p->uart = (AU1X00_UART *)mapPhysicalAddress(physAddr, sizeof(AU1X00_UART), 0);

    p->uart->enable = UART_ENABLE_CE;
    msdelay(100);

    p->uart->enable = UART_ENABLE_CE | UART_ENABLE_E;
    msdelay(100);

    p->uart->fifoctrl = ( 0
                          | UART_FIFOCTRL_RFT_4
                          | UART_FIFOCTRL_TFT_12
                          /*| UART_FIFOCTRL_MS*/
                          | UART_FIFOCTRL_TR
                          | UART_FIFOCTRL_RR
                          | UART_FIFOCTRL_FE
                        ) ;

    p->uart->mdmctrl = 0;

    /* 8N1 */
    p->uart->linectrl = UART_LINECTRL_WLS_8;

    // Equation: Baudrate = CPU / (SD * 2 * CLKDIV * 16)
    clkdiv = (12000000 * (SYS_CPUPLL_PLL & sys->cpupll)) / (baud * ((sys->powerctrl & 0x03) + 2) * 2 * 16);

    p->uart->clkdiv = clkdiv;
    msdelay(100);

    p->uart->linestat;
    p->uart->intcause;

    p->uart->inten = ( 0
                       | UART_INTEN_MIE
                       | UART_INTEN_LIE
                       | UART_INTEN_TIE
                       | UART_INTEN_RIE
                     ) ;

    /* Hook interrupt */
    cpuIrqEnable(p->irq, 0, (void *)uartHandler, (void *)p);

}

/********************************************************************/





#else /* polled UART */
typedef volatile struct UART_t
{
    uint32 rxdata;
    uint32 txdata;
    uint32 inten;
    uint32 incause;
    uint32 fifoctrl;
    uint32 linectrl;
    uint32 mdmctrl;
    uint32 linestat;
    uint32 mdmstat;
    uint32 autoflow;
    uint32 clkdiv;
    char buffer[212];
    uint32 enable;
}
UART_t;

#define AU1000_UART UART_t
/********************************************************************/
void
uartInit (int uartNumber, int baud)
{
    AU1000_UART *uart;
    uint32 clkdiv;

    switch (uartNumber)
    {
#ifdef UART0_PHYS_ADDR
        case 0: uart = (AU1000_UART *)KSEG1(UART0_PHYS_ADDR); break;
#endif
#ifdef UART1_PHYS_ADDR
        case 1: uart = (AU1000_UART *)KSEG1(UART1_PHYS_ADDR); break;
#endif
#ifdef UART2_PHYS_ADDR
        case 2:
        	uart = (AU1000_UART *)KSEG1(UART2_PHYS_ADDR);
            cpuIrqConfigure(25, GPIO_IS_DEVICE);
            cpuIrqConfigure(26, GPIO_IS_DEVICE);
        	break;
#endif
#ifdef UART3_PHYS_ADDR
        case 3: uart = (AU1000_UART *)KSEG1(UART3_PHYS_ADDR); break;
#endif
        default:
            return;
    }

    /* get the system parameter area */
    sys = (AU1X00_SYS *)
          mapPhysicalAddress(SYS_PHYS_ADDR, sizeof(AU1X00_SYS), 0);


    uart->enable = UART_ENABLE_CE;
    msdelay(100);

    uart->enable = UART_ENABLE_CE | UART_ENABLE_E;
    msdelay(100);

    uart->inten = 0;

    uart->fifoctrl = UART_FIFOCTRL_TR | UART_FIFOCTRL_RR;

    /* 8N1 */
    uart->linectrl = UART_LINECTRL_WLS_8;

    clkdiv = (12000000 * (SYS_CPUPLL_PLL & sys->cpupll)) / (baud * ((sys->powerctrl & 0x03) + 2) * 2 * 16);
    uart->clkdiv = clkdiv;
    msdelay(100);

    *((int*)0xAF000000) = *((int*)0xB1100100);
}

/********************************************************************/
void
uartPutChar (int uartNumber, int ch)
{
    AU1000_UART *uart;

    switch (uartNumber)
    {
#ifdef UART0_PHYS_ADDR
        case 0: uart = (AU1000_UART *)KSEG1(UART0_PHYS_ADDR); break;
#endif
#ifdef UART1_PHYS_ADDR
        case 1: uart = (AU1000_UART *)KSEG1(UART1_PHYS_ADDR); break;
#endif
#ifdef UART2_PHYS_ADDR
        case 2: uart = (AU1000_UART *)KSEG1(UART2_PHYS_ADDR); break;
#endif
#ifdef UART3_PHYS_ADDR
        case 3: uart = (AU1000_UART *)KSEG1(UART3_PHYS_ADDR); break;
#endif
        default:
            return;
    }

    while ((uart->linestat & UART_LINESTAT_TE) == 0)
        ;

    uart->txdata = ch;

    // (*((int*)0xAF000000))++;
}

/********************************************************************/
void
uartGetChar (int uartNumber, int *ch)
{
    AU1000_UART *uart;
    switch (uartNumber)
    {
#ifdef UART0_PHYS_ADDR
        case 0: uart = (AU1000_UART *)KSEG1(UART0_PHYS_ADDR); break;
#endif
#ifdef UART1_PHYS_ADDR
        case 1: uart = (AU1000_UART *)KSEG1(UART1_PHYS_ADDR); break;
#endif
#ifdef UART2_PHYS_ADDR
        case 2: uart = (AU1000_UART *)KSEG1(UART2_PHYS_ADDR); break;
#endif
#ifdef UART3_PHYS_ADDR
        case 3: uart = (AU1000_UART *)KSEG1(UART3_PHYS_ADDR); break;
#endif
        default:
            return;
    }

    while ((uart->linestat & UART_LINESTAT_DR) == 0)
        ;

    *ch = (uart->rxdata & 0x00FF);
}

/********************************************************************/
int
uartCheckChar (int uartNumber)
{
    AU1000_UART *uart;

    switch (uartNumber)
    {
#ifdef UART0_PHYS_ADDR
        case 0: uart = (AU1000_UART *)KSEG1(UART0_PHYS_ADDR); break;
#endif
#ifdef UART1_PHYS_ADDR
        case 1: uart = (AU1000_UART *)KSEG1(UART1_PHYS_ADDR); break;
#endif
#ifdef UART2_PHYS_ADDR
        case 2: uart = (AU1000_UART *)KSEG1(UART2_PHYS_ADDR); break;
#endif
#ifdef UART3_PHYS_ADDR
        case 3: uart = (AU1000_UART *)KSEG1(UART3_PHYS_ADDR); break;
#endif
        default:
            return;
    }

    if (uart->linestat & UART_LINESTAT_DR)
        return TRUE;
    else
        return FALSE;
}

int  uartSetClkDivisor(int uartNumber, int cpu_speed, int bus_mult, int baudrate)
{
    AU1000_UART *uart;
    int  clkdiv;

    switch (uartNumber)
    {
#ifdef UART0_PHYS_ADDR
        case 0: uart = (AU1000_UART *)KSEG1(UART0_PHYS_ADDR); break;
#endif
#ifdef UART1_PHYS_ADDR
        case 1: uart = (AU1000_UART *)KSEG1(UART1_PHYS_ADDR); break;
#endif
#ifdef UART2_PHYS_ADDR
        case 2: uart = (AU1000_UART *)KSEG1(UART2_PHYS_ADDR); break;
#endif
#ifdef UART3_PHYS_ADDR
        case 3: uart = (AU1000_UART *)KSEG1(UART3_PHYS_ADDR); break;
#endif
        default:
            return;
    }

    clkdiv = (cpu_speed / (bus_mult * baudrate * 4 * 8));
    uart->clkdiv  = clkdiv;
    msdelay(10);
    return clkdiv;
}

/********************************************************************/

#endif /* USE_UART_IRQ */

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*
 * Sample code to demonstrate PCMCIA operations on the Pb1x00
 */

#include "example.h"
#include "pcmcia.h"

/********************************************************************/

static AU1X00_SYS * const sys = (AU1X00_SYS *)KSEG1(SYS_PHYS_ADDR);

//32-bit board registers
static volatile uint16* pcmcia_control = NULL;
static volatile uint16* board_status = NULL;

/********************************************************************/

/* used for the ATA functions */
static char* pcmcia_mem_base;

int pcmcia_socket = -1;

/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/
int pcmcia_card_inserted(int socket)
{
    return ((bcsr->sig_status & BCSR_BIC_PC0INSERT) ? TRUE : FALSE);
}

//This function seems a little bogus
void pcmcia_wait_ready(int socket)
{
// CTG -- todo -- implement real IRQ handler for waitready
#if 0
    int i;
    /*
     * Wait until READY (IRQ signal high)
     */
    for (i = 0; i < 1000; ++i)
    {
        if (gpioRead((socket == 0) ? PCMCIA_PC0_IRQ : PCMCIA_PC1_IRQ))
            break;
        else
            msdelay(1);
    }
    if (i == 1000)
        DPRINTF("TIME-OUT waiting for card READY!\n");
#endif
}

void pcmcia_enable_pins(int socket)
{
    // Chip-level muxing
    cpuIrqConfigure(62, GPIO_IS_DEVICE);
    cpuIrqConfigure(63, GPIO_IS_DEVICE);
    cpuIrqConfigure(64, GPIO_IS_DEVICE);
    cpuIrqConfigure(65, GPIO_IS_DEVICE);
    cpuIrqConfigure(66, GPIO_IS_DEVICE);
    cpuIrqConfigure(67, GPIO_IS_DEVICE);
    cpuIrqConfigure(68, GPIO_IS_DEVICE);
    cpuIrqConfigure(69, GPIO_IS_DEVICE);
    cpuIrqConfigure(70, GPIO_IS_DEVICE);
}

int pcmcia_reset(int socket)
{
    *pcmcia_control &= ~(BCSR_PCMCIA_PC0RST);
    msdelay(350);
    *pcmcia_control |= BCSR_PCMCIA_PC0RST;  //Deassert reset
    msdelay(100);
}

int pcmcia_power_up(int socket)
{
    DPRINTF("%d\n", socket);

    pcmcia_enable_pins(socket); //Enable muxed PCMCIA pins

    DPRINTF("3.3VDC card\n");

    *pcmcia_control |= BCSR_PCMCIA_PC0DRVEN; //Enable Buffers
    pcmcia_reset(socket);
    pcmcia_wait_ready(socket);

    return 1;
}

/********************************************************************/
void pcmcia_power_down(int socket)
{
    //Only configure board registers on boards that actually have registers

    // not required on DB1300 platforms
    return;
}

int pcmcia_interrupt_enable(int socket)
{

    /* CTG --  todo -- verify proper GPIO inputs */
    bcsr->intset_mask |= (BCSR_BIC_PC0INSERT | BCSR_BIC_PC0EJECT);
    bcsr->intset      |= (BCSR_BIC_PC0INSERT | BCSR_BIC_PC0EJECT);

}

int pcmcia_init_bcsr_pointers()
{
    pcmcia_control = &bcsr->pcmcia;
    board_status = &bcsr->status;
}

/********************************************************************/
int pcmcia_init (int socket)
{
    DPRINTF("%d\n", socket);

    pcmcia_init_bcsr_pointers();

    if (pcmcia_card_inserted(socket))
    {
        DPRINTF("PCMCIA Card in socket: %d\n", socket);
        return pcmcia_power_up(socket);
    }
    else
        DPRINTF("No Card Inserted in socket: %d\n", socket);

    return 0;
}

void pcmcia_wait_card_inserted(int socket)
{
    pcmcia_init_bcsr_pointers();
    while (!pcmcia_card_inserted(socket))
        ;
    msdelay(500);
}

void* pcmcia_map_window(int socket, int window, int size)
{
    TLBEntry t;
    uint32 base;
    void *p = NULL;

    if ((socket < 0) || (socket > 1))
        return NULL;

    if (socket == 0)
        base = 0x00000000;
    else
        base = 0x04000000;

    switch (window)
    {
        case PCMCIA_WINDOW_ATTR:
            p = mapPhysicalAddress(0xF40000000LL + (phys_t)base, 0x300, 0);
            break;

        case PCMCIA_WINDOW_IO:
            p = mapPhysicalAddress(0xF00000000LL + (phys_t)base, size, 0);
            break;

        case PCMCIA_WINDOW_MEM:
            p = mapPhysicalAddress(0xF80000000LL + (phys_t)base, size, 0);
            break;

        default:
            p = NULL;
    }

    return p;
}

int pcmcia_map(int socket)
{
    pcmcia_mem_base = pcmcia_map_window(socket, PCMCIA_WINDOW_MEM, 4096);
    DPRINTF("PCMCIA Base Address %x \n", pcmcia_mem_base);

    if (pcmcia_mem_base != NULL)
        return 1;
    else
        return 0;
}

int pcmciaEject()
{
    pcmcia_socket = -1;
    pcmcia_power_down(pcmcia_socket);
    return 1;
}

int pcmciaRead(int sect, int n, void *buf)
{
    return ata_read_sectors(pcmcia_mem_base, sect, n, buf, 1);
}

int pcmciaWrite(int sect, int n, void *buf)
{
    return ata_write_sectors(pcmcia_mem_base, sect, n, buf, 1);
}

int pcmciaOpen(int socket)
{
    if (pcmcia_socket != -1)
        pcmciaEject();

    pcmcia_socket = socket;
    return pcmcia_init(socket) && pcmcia_map(socket);
}

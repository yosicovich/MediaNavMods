/*
 * WAV file player
 */

/********************************************************************/

/*
 * Endian support routines (WAV files are little endian)
 */
#ifdef EL
#define SWAP16(X)
#define SWAP32(X)
#endif

#ifdef EB
#define swap16(X) \
 ( (((uint16)(X) & 0x00FF) << 8) | \
   (((uint16)(X) & 0xFF00) >> 8) )

#define swap32(X) \
 ( (((uint32)(X) & 0x000000FF) << 24) | \
   (((uint32)(X) & 0x0000FF00) << 8)  | \
   (((uint32)(X) & 0x00FF0000) >> 8)  | \
   (((uint32)(X) & 0xFF000000) >> 24) )

#define SWAP16(X) (X) = swap16(X)
#define SWAP32(X) (X) = swap32(X)
#endif

/********************************************************************/

/*
 * Microsoft conventions
 */
typedef signed char  CHAR;
typedef signed short WORD;
typedef signed int   DWORD;

/********************************************************************/

typedef struct
{
    char  id[4];   // identifier string = "RIFF"
    DWORD len;     // remaining length after this header
    //char  type_id[4];
}
riff_hdr;
#define RIFF_HDR_SZ sizeof(riff_hdr)

typedef struct
{  // CHUNK 8-byte header
    char  id[4]; // identifier, e.g. "fmt " or "data"
    DWORD len;  // remaining chunk length after header
}
chunk_hdr;
// data bytes follow chunk header
#define CHUNK_HDR_SZ sizeof(chunk_hdr)

typedef struct
{
    WORD wFormatTag;         // Format category
    WORD wChannels;          // Number of channels
    DWORD dwSamplesPerSec;    // Sampling rate
    DWORD dwAvgBytesPerSec;   // For buffer estimation
    WORD wBlockAlign;        // Data block size
}
common_hdr;
#define COMMON_HDR_SZ 14

#define WAVE_FORMAT_PCM  (0x0001)
#define FORMAT_MULAW  (0x0101)
#define IBM_FORMAT_ALAW  (0x0102)
#define IBM_FORMAT_ADPCM (0x0103)

typedef struct
{
    common_hdr chdr;
}
format_chunk;
#define FORMAT_CHUNK_SZ COMMON_HDR_SZ

typedef struct
{
    WORD wBitsPerSample;  // Sample size
}
pcm_specific;
#define PCM_SPECIFIC_SZ sizeof(pcm_specific)

/********************************************************************/

/*
 * File accessors abstraction
 */
static unsigned int bread = 0;

/********************************************************************/

#include "example.h"

static char *ifp = NULL;

/*
 * Memory-based accessors
 */
int
ifpOpen (char *fn)
{
    ifp = fn;
    bread = 0;
    return 0;
}

int
ifpRead (void *buffer, int size)
{
    int bytes;
    char *buf = (char *)buffer;
    
    for (bytes = 0; bytes < size; ++bytes)
    {
        *buf++ = *ifp++;
    }
    
    bread += bytes;
    
    return bytes;
}

void
ifpSkip (int size)
{
    /* skip size bytes ahead */
    bread += size;
    ifp += size;
}

void
ifpClose (void)
{}

/********************************************************************/
int
wavplay ( char isac97, char *fn)
{
    riff_hdr rhdr;
    char type_id[4];
    chunk_hdr chdr;
    format_chunk fmt;
    pcm_specific pcm;
    int chunks = 0;
    int cpayload;
#ifdef AU1550
    uint16  buf[1024/2];
    uint32  buf_idx=0;
#endif
    
    if (ifpOpen(fn) < 0)
    {
        printf("failure opening file %s\n", fn);
        return -1;
    }
    
    /*
     * Get RIFF header
     */
    if (ifpRead(&rhdr, RIFF_HDR_SZ) < 0)
    {
        printf("failure reading RIFF header\n");
        return -2;
    }
    SWAP32(rhdr.len);
    
    /*
     * Examine RIFF header
     */
    if ((rhdr.id[0] != 'R') &&
            (rhdr.id[1] != 'I') &&
            (rhdr.id[2] != 'F') &&
            (rhdr.id[3] != 'F'))
    {
        printf("not a RIFF file!\n");
        return -4;
    }
    printf("RIFF payload len %d\n", rhdr.len);
    printf("rhdr+len: %d\n", rhdr.len + sizeof(rhdr));
    
    ifpRead(type_id, sizeof(type_id));
    
    /*
     * Check for WAV file
     */
    if ((type_id[0] != 'W') &&
            (type_id[1] != 'A') &&
            (type_id[2] != 'V') &&
            (type_id[3] != 'E'))
    {
        printf("not a WAV file!\n");
        return -5;
    }
    
    /*
     * Handle RIFF chunks
     */
    while (1)
    {
        ++chunks;
        ifpRead(&chdr, CHUNK_HDR_SZ);
        SWAP32(chdr.len);
        
        printf("chunk: %d\n", chunks);
        printf("id: %c%c%c%c payload len %d\n",
               chdr.id[0],
               chdr.id[1],
               chdr.id[2],
               chdr.id[3],
               chdr.len);
               
        cpayload = 0;
        
        if ((chdr.id[0] == 'f') &&
                (chdr.id[1] == 'm') &&
                (chdr.id[2] == 't'))
        {
            ifpRead(&fmt, FORMAT_CHUNK_SZ);
            SWAP16(fmt.chdr.wFormatTag);
            SWAP16(fmt.chdr.wChannels);
            SWAP32(fmt.chdr.dwSamplesPerSec);
            SWAP32(fmt.chdr.dwAvgBytesPerSec);
            SWAP16(fmt.chdr.wBlockAlign);
            
            cpayload += FORMAT_CHUNK_SZ;
            printf("WAVE fmt-ck:\n");
            printf("    wFormatTag: %04X\n", fmt.chdr.wFormatTag);
            printf("      Channels: %04X\n", fmt.chdr.wChannels);
            printf(" SamplesPerSec: %08X %d\n",
                   fmt.chdr.dwSamplesPerSec, fmt.chdr.dwSamplesPerSec);
            printf(" AvgBytesPerSec: %08X\n", fmt.chdr.dwAvgBytesPerSec);
            printf("     BlockAlign: %04X\n", fmt.chdr.wBlockAlign);
            
            if (fmt.chdr.wFormatTag == WAVE_FORMAT_PCM)
            {
                ifpRead(&pcm, PCM_SPECIFIC_SZ);
                SWAP16(pcm.wBitsPerSample);
                
                cpayload += PCM_SPECIFIC_SZ;
                printf("  PCM BitsPerSample: %d\n", pcm.wBitsPerSample);
                if ( isac97 )
                {
                    /* avoid conflict */
                    audioHwSetSampleInfo_ac97(
                        fmt.chdr.wChannels,
                        fmt.chdr.dwSamplesPerSec,
                        pcm.wBitsPerSample);
                }
                else
                {
                    audioHwSetSampleInfo_i2s(
                        fmt.chdr.wChannels,
                        fmt.chdr.dwSamplesPerSec,
                        pcm.wBitsPerSample);
                }
            }
            else
            {
                printf("Unsupported FormatTag %d\n", fmt.chdr.wFormatTag);
                break;
            }
        }
        
        if ((chdr.id[0] == 'd') &&
                (chdr.id[1] == 'a') &&
                (chdr.id[2] == 't') &&
                (chdr.id[3] == 'a'))
        {
            int s = 0;
            int left = 0, right = 0;
            uint16 l16, r16;
            
            while (s < chdr.len)
            {
                switch (pcm.wBitsPerSample)
                {
                    case 16:
                        ifpRead(&l16, sizeof(l16));
                        SWAP16(l16);
                        
                        s += 2;
                        if (fmt.chdr.wChannels == 2)
                        {
                            ifpRead(&r16, sizeof(r16));
                            SWAP16(r16);
                            s += 2;
                        }
                        else
                            r16 = 0;
                        left = l16;
                        right = r16;
                        break;
                    default:
                        printf("wavplay: unsupported sample size\n");
                        break;
                }
// CTG
// for the au1550 -- lets setup a temp buffer of 1024k to store sound data
// then transfer to the PSC. This will keep the dma engine rolling using 1k
// data packets instead of 2 bytes :)

// remember ... the last packet isn't always going to be 1k so send it off at the
// end of this loop

                //printf("left %04X right %04X\n", left, right);
#ifdef AU1550
                
#error CTG -- this is not supported/tested!
                if ( buf_cnt == 1024/2 ) // loop on entries to buff
                {
                    audioHwSendSample_ac97( buf, 1024 ); // count is sent in bytes
                    buf_cnt = 0;
                }
                else
                    buf[buf_cnt++] = left;
                buf[buf_cnt++] = right;
#else
                if (isac97)
                {
                    /* avoid conflict */
                    audioHwSendSample_ac97(left, right);
                }
                else
                {
                    audioHwSendSample_i2s(left, right);
                }
#endif
            }
        }
        
#ifdef AU1550
        audioHwSendSample_ac97( buf, buf_cnt*2 ); // send the count in bytes ;)
        buf_cnt = 0;
#endif
        ifpSkip(chdr.len - cpayload);
        
        if (bread >= (rhdr.len + RIFF_HDR_SZ))
            break;
    }
    
    ifpClose();
    
    return 0;
}

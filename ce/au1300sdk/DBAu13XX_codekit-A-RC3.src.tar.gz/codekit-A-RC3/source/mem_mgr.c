/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
#include "example.h"
#include "mem_mgr.h"

#define DEBUG 1

/************************************************************************
      Structures
************************************************************************/
typedef struct
{
    unsigned long size;
    unsigned long inuse;
    void   *next,*prev;
    void   *context;
}
BUFFER, *PBUFFER;

/************************************************************************
      Global Variables
************************************************************************/

/************************************************************************
      SOURCE
************************************************************************/
static void dump( void *list )
{
    PBUFFER plist = list;

    printf("\n\nDumping list %08X", list );

    while ( plist && plist )
    {
        printf("\nNode: %08X", plist);
        printf("\n\tsize:%d inuse:%d next:%08X prev:%08X context:%08X",
               plist->size, plist->inuse, plist->next, plist->prev, plist->context );
        plist = plist->next;
    }
}

static void * init( void * mem, unsigned long size )
{
    PBUFFER plist = (PBUFFER)mem;
    PBUFFER tmp;

    /* The first data entry willnever change */
    tmp    = mem;
    plist->size  = size - sizeof(BUFFER);
    plist->context  = NULL;
    plist->inuse  = 1;
    plist->prev  = NULL;
    plist->next  = (PBUFFER)((uint32)plist + sizeof(BUFFER));

    plist = plist->next;

    /* All entries will occur after this one */
    plist->size  = size - (sizeof(BUFFER)*2);
    plist->prev  = tmp;
    plist->next  = NULL;
    plist->inuse  = 0;
    plist->context  = NULL;

    return mem;
}

static void destroy( void * mem )
{
    PBUFFER list = (PBUFFER)mem;
    memset( mem, 0, list->size );
}


static void * alloc( void * pool, unsigned long _size, void * context )
{
    PBUFFER pcurrent=(PBUFFER)pool;
    PBUFFER new;
    unsigned long size;
    void  *ptr;

    /* Round requested size 32bit boundry */
    if (_size & 0x03) size = (_size & ~0x3) + 0x4;
    else size=_size;

    do
    {
        if (!pcurrent) return NULL;

        if ( (!pcurrent->inuse) && (pcurrent->size >= size + sizeof(BUFFER)) ) break;

        /* Goto next node in list */
        pcurrent = pcurrent->next;
    }
    while (1);

#ifdef DEBUG
    dump(pool);
    printf("alloc: pcurrent:%X req_size:%d new_size:%d\n", pcurrent,_size,size);
#endif
    /*  If we get to this point -- pcurrent is a valid descriptor
     *  First thing we need to do is create a new descriptor for the left over data
     * and fill in the proper values. Only do this if we have left overs
     */
    if ( pcurrent->size != size )
    {
        new     = (PBUFFER)((unsigned long)pcurrent + size + sizeof(BUFFER));
        new->size   = pcurrent->size - size - sizeof(BUFFER);
        new->inuse   = 0;
        new->prev   = pcurrent;
        new->next   = pcurrent->next;

        pcurrent->next   = new;
        pcurrent->size   = size;
        pcurrent->context  = context;
        pcurrent->inuse  = 1;

    }

    // Prepare to zero-out the newly allocated memory
    ptr = (void*)( (uint32)pcurrent + sizeof(BUFFER));
    memset( ptr, 0, size );

    /* return a pointer to the actual data area */
    return ptr;
}

static void free ( void * buffer )
{
    // We pass the actual data buffer to the user -- now we must compensate
    // for the header being sizeof(BUFFER) ahead of the user's pointer
    //
    PBUFFER pbuf  = (PBUFFER)((uint32)buffer - sizeof(BUFFER));
    PBUFFER pprev;
    PBUFFER pnext;

    pprev = pbuf->prev;
    pnext = pbuf->next;

    /*
     * We have to merge the nodes when they are freed
     *  There are four cases :
        *    1) Prev and Next nodes are also free
        *   2) Prev node is free
        *    3) Next node is free
     *    4) No neighbors are free
     */
    if ( pprev && (!pprev->inuse) && pnext && !(pnext->inuse) )
    {
        pprev->size += pnext->size + pbuf->size + (sizeof(BUFFER)*2);
        pprev->next = pnext->next;
        ((PBUFFER)(pnext->next))->prev = pprev;
    }
    else if ( pprev && (!pprev->inuse) )
    {
        pprev->size += pbuf->size + sizeof(BUFFER);
        pprev->next = pbuf->next;
        ((PBUFFER)pbuf->next)->prev = pprev;
    }
    else if ( pnext && (!pnext->inuse) )
    {
        pbuf->size += pnext->size + sizeof(BUFFER);
        pbuf->next = pnext->next;
        pbuf->inuse = 0;
    }
    else
        pbuf->inuse = 0;
}

static void * get_context( void * buffer )
{
    PBUFFER pbuf  = (PBUFFER)((uint32)buffer - sizeof(BUFFER));
    return pbuf->context;
}

void GetBufferInterface(PBUFFER_INTERFACE Interface )
{
    Interface->version   = 0x00100001;  // 1.0.0
    Interface->init   = init;
    Interface->destroy   = destroy;
    Interface->dump   = dump;
    Interface->alloc   = alloc;
    Interface->free   = free;
    Interface->get_context  = get_context;
}

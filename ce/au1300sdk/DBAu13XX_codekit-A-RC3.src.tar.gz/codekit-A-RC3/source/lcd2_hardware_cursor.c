/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "image.h"
#include "frame_buffer.h"

//#undef LCD_PHYS_ADDR
//#define LCD_PHYS_ADDR  0x00500000
static AU1200_LCD* lcd = (AU1200_LCD*) KSEG1(LCD_PHYS_ADDR);


void
hwc_set_color(int index, uint32 color)
{
    DPRINTF("%d: %X\n", index, color);
    switch (index)
    {
        case 0: lcd->hwc.cursorcolor0 = color; break;
        case 1: lcd->hwc.cursorcolor1 = color; break;
        case 2: lcd->hwc.cursorcolor2 = color; break;
        case 3: lcd->hwc.cursorcolor3 = color; break;
        default: break;
    }
}

typedef struct
{
    uint32 color;
    BOOL used;
}
COLOR_MAP;

int
hwc_load_image(IMAGE* cursor, void* hwc_address)
{
    DPRINTF("%s: (%X)\n", cursor->info.description, cursor);
    FRAME_BUFFER_INFO info;
    info.pixel_info.pixel_format = PF_2BPP;
    info.pixel_info.pixel_ordering = PO_3;
    info.pixel_info.bpp = 2;
    info.pixel_info.memory_width = 2;
    info.width = 32;
    info.height = 32;

    fb_palatize_image((FRAME_BUFFER_ADDRESS*) &lcd->cursorpattern, &info, cursor, &lcd->hwc.cursorcolor0, 4);
}

void
hwc_set_position(int x, int y, int x_offset, int y_offset)
{
    DPRINTF("XY(%d, %d), OFFSET_XY(%d, %d)\n", x, y, x_offset, y_offset);
    lcd->hwc.cursorpos  = LCD_CURSORPOS_HWCXOFF_N(x_offset)
                          | LCD_CURSORPOS_HWCXPOS_N(x)
                          | LCD_CURSORPOS_HWCYOFF_N(y_offset)
                          | LCD_CURSORPOS_HWCYPOS_N(y);
}

void
hwc_enable(BOOL enable)
{
    DPRINTF("%s\n", (enable == TRUE) ? "TRUE" : "FALSE");
    lcd->hwc.cursorctrl = (enable == TRUE) ? LCD_HWCCON_EN : 0;
}

uint32*
hwc_get_pallete()
{
    return (uint32*) &lcd->hwc.cursorcolor0;
}

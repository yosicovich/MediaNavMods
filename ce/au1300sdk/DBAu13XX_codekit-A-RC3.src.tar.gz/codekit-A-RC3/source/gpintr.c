/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "gpintr.h"


#define GET_INT_CHAN_AND_BIT(irq)   \
 unsigned long chan,bit;     \
 chan = GPINT_BANK_FROM_INT(irq);  \
 bit = GPINT_BIT_FROM_INT(chan,irq);  \


#define InterruptEnable(x)  xxAbleInterrupt(x, TRUE)
#define InterruptDisable(x)  xxAbleInterrupt(x, FALSE)

static
void (*irqDispatch[NUM_IRQS])(int irq, void *arg);
static
void *irqArgument[NUM_IRQS];


AU13XX_GPINT * const gpint =
    (AU13XX_GPINT *)KSEG1(GPINT_PHYS_ADDR);


/*
 *   Function   :   xxAbleInterrupt
 *
 *      Assume interrupt has already been configured and we are just en/dis'abling mask.
 *
 *   Parameters :
 *      u32Interrupt        Interrupt Number from 0-127
 *  bEnable    TRUE = enable; FALSE = disable
 *
 *     Returns :
 *      TRUE  Successfuly modified
 *      FALSE  Failure to modify intr
 *
 */
static BOOL xxAbleInterrupt( unsigned long u32Interrupt, BOOL bEnable )
{
    GET_INT_CHAN_AND_BIT(u32Interrupt);

    if ( u32Interrupt >= GPINT_MAX_INTS )
        return FALSE;

    if ( bEnable )
        gpint->int_mask[chan] = bit;
    else
    {
        // ack it first
        gpint->int_pend[chan] = bit;
        gpint->int_maskclr[chan] = bit;
    }

    return TRUE;
}


/*
 *   Function   :   ConfigureInterrupt
 *
 *      Configures interrupt
 *
 *   Parameters :
 *      u32Interrupt        Interrupt Number from 0-127
 *  u32Mode    Value of the gp_intX register
 *
 *     Returns :
 *      TRUE  Configured
 *      FALSE  ERROR
 *
 */
BOOL cpuIrqConfigure( int irq, int mode )
{
// TODO -- some sanity checking goes here :)  -- Maybe I don't need this function
    if ( irq >= GPINT_MAX_INTS )
        return FALSE;

    gpint->gp_int[irq] = mode;
    return TRUE;
}

/*
 *   Function   :   InterruptQuery
 *
 *      Queries for interrupt value
 *
 *   Parameters :
 *      u32Interrupt        Interrupt Number from 0-127
 *
 *     Returns :
 *   Value of interrupt
 *
 */
int cpuIrqQuery( int irq )
{
    GET_INT_CHAN_AND_BIT(irq);
    return(gpint->pin_val[chan] & bit);
}

/*
 *   Function   :   GPINT_AckInterrupt
 *
 *      Clears the interrupt logic for IRQ
 *
 *   Parameters :
 *      u32Interrupt        Interrupt Number from 0-127
 *
 *     Returns :
 *   Nothing
 *
 */
void AckInterrupt( unsigned long u32Interrupt )
{
    GET_INT_CHAN_AND_BIT(u32Interrupt);
    gpint->int_pend[chan] = bit;
}


#define DISPATCH_IRQ(IRQ) \
 if (irqDispatch[IRQ] != NULL) \
  (*irqDispatch[IRQ])(IRQ, irqArgument[IRQ])

void cpuIrqHandler( void )
{
    uint32 Status;
    int irq, result;

    Status = cp0RdStatus();

    if (Status & STATUS_SWI0)
    {
        Status &= ~STATUS_SWI0;
        cp0WrStatus(Status);
        DISPATCH_IRQ(IRQ_SWI0);
    }
    else if (Status & STATUS_SWI1)
    {
        Status &= ~STATUS_SWI1;
        cp0WrStatus(Status);
        DISPATCH_IRQ(IRQ_SWI1);
    }
    else if (Status & STATUS_PERFCNT)
    {
        DISPATCH_IRQ(IRQ_PERFCNT);
    }
    else if (Status & STATUS_COUNTER)
    {
        DISPATCH_IRQ(IRQ_COUNTER);
    }
    else
    {
        irq = gpint->pri_enc;
        AckInterrupt(irq);
        DISPATCH_IRQ(irq);
    }

}


/********************************************************************/
int
cpuIrqEnable (int irq, int polarity, void (*handler)(int, void *), void *arg)
{
    /*
     * NOTE: Status[IE] explicitly left untouched,
     * though Status[IM] is altered.
     */
    int bit;
    uint32 Status;

    if ((irq < 0) || (irq >= NUM_IRQS))
        return -1;

    if (handler == NULL)
        return -2;

    if (irqDispatch[irq] != NULL)
        return -3;

    /*
     * Install handler
     */
    irqDispatch[irq] = handler;
    irqArgument[irq] = arg;

    /*
     * Status[IM]/Cause[IP]
     */
    if (irq == IRQ_SWI0)
    {
        /* NOTE: Causes an interrupt iediately */
        Status = cp0RdStatus();
        Status |= STATUS_SWI0;
        cp0WrStatus(Status);
    }
    else if (irq == IRQ_SWI1)
    {
        /* NOTE: Causes an interrupt iediately */
        Status = cp0RdStatus();
        Status |= STATUS_SWI1;
        cp0WrStatus(Status);
    }
    else if (irq == IRQ_PERFCNT)
    {
        Status = cp0RdStatus();
        Status |= STATUS_PERFCNT;
        cp0WrStatus(Status);
    }
    else if (irq == IRQ_COUNTER)
    {
        Status = cp0RdStatus();
        Status |= STATUS_COUNTER;
        cp0WrStatus(Status);
    }
    else
    {
        Status = cp0RdStatus();
        Status |= (0xF<<10); // CP0 IntrReq0:3 enabled. Bits 10,11,12,13
        cp0WrStatus(Status);
        xxAbleInterrupt(irq, TRUE);
    }

    return 0;
}

/********************************************************************/
void
cpuIrqDisable (int irq)
{
    return;
}

/********************************************************************/
void
cpuIrqInit (void)
{
    extern
        uint32 asmIrqHandler[];
    extern
        uint32 asmIrqHandlerEnd[];

    uint32 *v = (uint32 *)0x80000200;
    uint32 *p, *q;
    int irq;

    /*
     * NULL dispatch table
     */
    for (irq = 0; irq < GPINT_MAX_INTS; ++irq)
    {
        irqDispatch[irq] = NULL;
        irqArgument[irq] = NULL;
    }

    /*
     * Install simple IRQ handler.
     */
    p = asmIrqHandler;
    q = asmIrqHandlerEnd;
    do
    {
        *v++ = *p++;
    }
    while (p < q);
    dcacheFlush();
    icacheFlush();

    /*
     * Point Status[BEV] into RAM at 0x80000000
     */
    cp0WrStatus(cp0RdStatus() & ~STATUS_BEV);

    /*
     * Point interrupt vector to 0x80000200
     */
    cp0WrCause(cp0RdCause() | CAUSE_IV);

    /*
     * Set GPINTR to known state (no IRQs allowed)
     */
    for (irq=0;irq<GPINT_NUM_BANKS;irq++)
        gpint->int_maskclr[irq] = 0xFFFFFFFF;

}

/********************************************************************/
uint32
cpuDisableIrqs (void)
{
    /*
     * This function disables interrupt by setting Status[IE] = 0.
     * The previous value of Status[IE] is returned.
     */
    uint32 Status;

    Status = cp0RdStatus();
    cp0WrStatus(Status & ~STATUS_IE);

    return (Status & STATUS_IE);
}

/********************************************************************/
void
cpuEnableIrqs (uint32 status)
{
    /*
     * This function restores the Status[IE] to the value
     * contained in 'status'. (so Enable is a mis-nomer,
     * but it pairs well with the Disable name)
     */
    uint32 Status;

    Status = cp0RdStatus();
    Status &= ~STATUS_IE;
    Status |= (status & STATUS_IE);
    cp0WrStatus(Status);
}

/********************************************************************/


/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include <stdarg.h>
#include "example.h"

//
// dprintf - printf using no resources
//
// understands the following formats:
//
//  %c - character
//  &d - decimal
//  %x - lower case hex
//  %X - upper case hex
//
//  all formats can have a field width specifier as in %8x and can
//  also have leading zeros as in %08x.
//

static int
fmtnum(char *buf, unsigned int n, int base, char *digits)
{
    int  i;

    i = 0;
    if ( n == 0 )
    {
        buf[0] = '0';
        return 1;
    }

    while ( n != 0 )
    {
        buf[i++] = digits[n % base];
        n /= base;
    }
    buf[i] = 0;  // terminate string
    return i;
}

void
printf (const char *fmt,...)
{
    void  ((*putcf)()) = (void *)putc;
    va_list  argp;
    int   *i;
    char  *charp;
    int   f1, pbi, ival;
    int   lzflag, rjust;
    int   c;
    char  pbuf[40];
    int   col;

    va_start(argp,fmt);
    col = 0;
    while ( c = *fmt++ )
    {
        if ( c == '%' )
        {
            f1 = 0;
            c = *fmt++;
            if ( c == '-' )
            {
                rjust = 1;
                c = *fmt++;
            }
            lzflag = (c == '0');
            while ( isdigit(c) )
            {
                f1 = f1 * 10 + c - '0';
                c = *fmt++;
            }

            if ( c == 'x' )
            {
                i = (int *)va_arg(argp,int);
                pbi = fmtnum(pbuf,(int)i,16,"0123456789abcdef");
            }
            else if ( c == 'X' )
            {
                i = (int *)va_arg(argp,int);
                pbi = fmtnum(pbuf,(int)i,16,"0123456789ABCDEF");
            }
            else if ( c == 'd' || c == 'D' )
            {
                i = (int *)va_arg(argp,int);
                ival = (int)i;
                if ( ival < 0 )
                {
                    (*putcf)('-');
                    ival = -ival;
                    ++col;
                }
                pbi = fmtnum(pbuf,ival,10,"0123456789");
            }
            else if ( c == 'c' )
            {
                i = (int *)va_arg(argp,int);
                pbi = 0;
                (*putcf)(i);
                ++col;
                --f1;
            }
            else if ( c == 's' || c == 'S' )
            {
                i = (int *)va_arg(argp,int);
                pbi = 0;
                charp = (char *)(i);
                while ( *charp )
                {
                    (*putcf)(*charp++);
                    ++col;
                    --f1;
                }
            }
            else if ( c == 't' || c == 'T' )
            {
                pbi = 0;
                while ( col < f1 )
                {
                    (*putcf)(' ');
                    ++col;
                }
                f1 = 0;
            }

            f1 -= pbi;
            while ( f1 > 0 )
            {
                if ( lzflag )
                    (*putcf)('0');
                else
                    (*putcf)(' ');
                ++col;
                --f1;
            }

            while ( pbi > 0 )
            {
                (*putcf)(pbuf[--pbi]);
                ++col;
            }
        }
        else
        {
            (*putcf)(c);
            ++col;
        }
    }
    va_end(argp);
}

void
sprintf (char *out, const char *fmt,...)
{
    va_list  argp;
    int   *i;
    char  *charp;
    int   f1, pbi, ival;
    int   lzflag, rjust;
    int   c;
    char  pbuf[40];
    int   col;

    va_start(argp,fmt);
    col = 0;
    while ( c = *fmt++ )
    {
        if ( c == '%' )
        {
            f1 = 0;
            c = *fmt++;
            if ( c == '-' )
            {
                rjust = 1;
                c = *fmt++;
            }
            lzflag = (c == '0');
            while ( isdigit(c) )
            {
                f1 = f1 * 10 + c - '0';
                c = *fmt++;
            }

            if ( c == 'x' )
            {
                i = (int *)va_arg(argp,int);
                pbi = fmtnum(pbuf,(int)i,16,"0123456789abcdef");
            }
            else if ( c == 'X' )
            {
                i = (int *)va_arg(argp,int);
                pbi = fmtnum(pbuf,(int)i,16,"0123456789ABCDEF");
            }
            else if ( c == 'd' || c == 'D' )
            {
                i = (int *)va_arg(argp,int);
                ival = (int)i;
                if ( ival < 0 )
                {
                    *out++ = '-';
                    ival = -ival;
                    ++col;
                }
                pbi = fmtnum(pbuf,ival,10,"0123456789");
            }
            else if ( c == 'c' )
            {
                i = (int *)va_arg(argp,int);
                pbi = 0;
                *out++ = *i;
                ++col;
                --f1;
            }
            else if ( c == 's' || c == 'S' )
            {
                i = (int *)va_arg(argp,int);
                pbi = 0;
                charp = (char *)(i);
                while ( *charp )
                {
                    *out++ = *charp++;
                    ++col;
                    --f1;
                }
            }
            else if ( c == 't' || c == 'T' )
            {
                pbi = 0;
                while ( col < f1 )
                {
                    *out++ = ' ';
                    ++col;
                }
                f1 = 0;
            }

            f1 -= pbi;
            while ( f1 > 0 )
            {
                if ( lzflag )
                    *out++ = '0';
                else
                    *out++ = ' ';
                ++col;
                --f1;
            }

            while ( pbi > 0 )
            {
                *out++ = pbuf[--pbi];
                ++col;
            }
        }
        else
        {
            *out++ = c;
            ++col;
        }
    }
    va_end(argp);

    *out = 0;
}


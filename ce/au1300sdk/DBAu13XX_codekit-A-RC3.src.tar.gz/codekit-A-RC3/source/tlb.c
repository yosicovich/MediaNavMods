/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*
 * Sample code to demonstrate TLB manipulation
 */
#include "example.h"

/********************************************************************/

typedef struct PTE
{
    uint32 EntryLo0;
    uint32 EntryLo1;

}
PTE;

/*
 * Level 1 Page Table, array of pointers to real PTEs
 */
PTE *L1PTE[256];

/*
 * Level 2 Page Table, array of PTEs
 */
PTE L2PTE[4096];

/* Simple virtual alloc scheme...arbitrary, just stay out of KSEG0,1 */
static char *lastVA = (char *)0x50000000;

/********************************************************************/
void
tlbInit (void)
{
    extern void asmTlbInit (void);
    extern uint32 asmTlbRefillHandler[];
    extern uint32 asmTlbRefillHandlerEnd[];
    uint32 va;
    int i;

    uint32 *v = (uint32 *)0x80000000;
    uint32 *p, *q;

    /*
     * Install TLB Refill handler.
     */
    p = asmTlbRefillHandler;
    q = asmTlbRefillHandlerEnd;
    do
    {
        *v++ = *p++;
    }
    while (p < q);
    dcacheFlush();
    icacheFlush();

    /*
     * Clear Status[EXL, ERL]
     */
    cp0WrStatus(cp0RdStatus() & ~(STATUS_EXL | STATUS_ERL));

    asmTlbInit();

    cp0WrPageMask(0x00000000); /* 4KB pages */
#define PAGE_SIZE 4096

    /*
     * Initialize L1PTE and L2PTE
     */
    for (i = 0; i < 256; ++i)
        L1PTE[i] = NULL;
    for (i = 0; i < 4096; ++i)
    {
        L2PTE[i].EntryLo0 = NULL;
        L2PTE[i].EntryLo1 = NULL;
    }

    /* Connect L2PTE */
    va = (uint32)lastVA;
    va >>= 24;
    L1PTE[(int)va] = L2PTE;

    /* For test purposes only */
    //L1PTE[0] = L2PTE;
    //L2PTE[0].EntryLo0 = (0x00000000 >> 6) | 0x17;
    //L2PTE[0].EntryLo1 = 0;

    /* FIX!!! L1PTE must meet alignment requirements first
    cp0WrContext((uint32)L1PTE);
    */
}

/********************************************************************/
phys_t
mapVirtualToPhysical (void *va)
{
    phys_t pa = NULL;

    if ((va >= (void *)0x80000000) && (va < (void *)0xC0000000))
    {
        pa = (phys_t)((uint32)va & ~0xE0000000);
    }
    else
        printf("ERROR: must walk PTE array\n");

    return pa;
}

/********************************************************************/
void *
valloc (unsigned long size, unsigned long flags)
{
    /*
     * Allocate a chunk of virtual address space
     * FIX Someday let flags specify an alignment?
     */
    void *va;

    /* NOTE: There is no check for overflow of the single L2PTE */

    /* round size up to (PAGE_SIZE * 2) */
    size = (size + ((PAGE_SIZE*2) - 1)) & ~((PAGE_SIZE*2) - 1);
    if (size == 0)
    {
        va = NULL;
    }
    else
    {
        va = (void *)lastVA;
        lastVA += size;
    }
    return va;
}

/********************************************************************/
void *
mapPhysicalAddress (phys_t physAddr, unsigned long size, int flags)
{
    void *va = NULL;
    int pteIndex;
    uint32 lo0, lo1, offset, cca;
    int i;

    /* First 512M physical is KSEG0/KSEG1 */
    if ((physAddr >= 0x00000000) && (physAddr < 0x20000000))
    {
        if (flags)
            va = (void *)KSEG0((void *)((uint32)physAddr));
        else
            va = (void *)KSEG1((void *)((uint32)physAddr));

        return va;
    }
    else
    {
        /* virtual mapping */

        /* round size up to (PAGE_SIZE * 2) */
        size = (size + ((PAGE_SIZE*2) - 1)) & ~((PAGE_SIZE*2) - 1);
        if (size == 0)
            return NULL;


        offset = physAddr & ((PAGE_SIZE*2) - 1);
        physAddr = (physAddr & (phys_t)~((PAGE_SIZE*2) - 1));

        va = valloc(size, 0);

        /* NOTE: There is no check for overflow of the single L2PTE */
        /* now create PTE entries */
        pteIndex = (int)va;
        pteIndex <<= 8;
        pteIndex >>= (8 + 13);
        for (i = 0; i < size; i += (PAGE_SIZE + PAGE_SIZE))
        {
            /* 36-bit PA */
            lo0 = (uint32)((physAddr + (phys_t)i + (phys_t)0        ) >> 6);
            lo1 = (uint32)((physAddr + (phys_t)i + (phys_t)PAGE_SIZE) >> 6);
            if (flags == FALSE)
                cca = 2;
            else if (flags == TRUE)
                cca = 3;
            else
                cca = flags;
            //if (flags)
            {
                lo0 |= ((flags<<3) + (1<<2) + (1<<1) + (0<<0));
                lo1 |= ((flags<<3) + (1<<2) + (1<<1) + (0<<0));
            }
            //else
            //{
            // lo0 |= ((2<<3) + (1<<2) + (1<<1) + (0<<0));
            // lo1 |= ((2<<3) + (1<<2) + (1<<1) + (0<<0));
            //}
            L2PTE[pteIndex].EntryLo0 = lo0;
            L2PTE[pteIndex].EntryLo1 = lo1;
            ++pteIndex;
        }

        return va + offset;
    }
}

/********************************************************************/
void
unmapPhysicalAddress (void *va, unsigned long size)
{
    /*
     * Must zero the PTEs ***AND*** use tlbp to determine
     * if any valid mappings are still in TLB, and if so
     * whack it
     */
}

/********************************************************************/

#if 0
void
tlbDump (void)
{
    int index;
    uint32 hi, pm, lo0, lo1, oIndex, oEntryHi;

    /* Save */
    oIndex = cp0RdIndex();
    oEntryHi = cp0RdEntryHi();

#if 0
    /* Raw dump */
    for (index = 0; index < 32; ++index)
    {
        cp0WrIndex(index);
        asm volatile (" tlbr");
        printf("%2d Hi %08X Pm %08X Lo0 %08X Lo1 %08X\n", index,
               cp0RdEntryHi(), cp0RdPageMask(), cp0RdEntryLo0(), cp0RdEntryLo1());
    }

    printf("\n");
#endif
    /* User friendly dump */
    printf("Idx ASID VA       PgM  PA0        C DVG  PA1        C DVG\n");
    for (index = 31; index >= 0; --index)
    {
        cp0WrIndex(index);
        asm volatile (" tlbr");
        hi = cp0RdEntryHi();
        pm = cp0RdPageMask() | 0x00001FFF;
        lo0 = cp0RdEntryLo0();
        lo1 = cp0RdEntryLo1();

        printf("%2d", index);
        if (index == cp0RdWired())
            printf(" W");
        else
            printf("  ");

        if ((hi & 0x000000FF) == (oEntryHi & 0x000000FF))
            printf(" m");
        else
            printf("  ");
        printf("%02X ", hi & 0x000000FF);
        printf("%08X ", hi & ~0x00001FFF);

        pm = ((pm | 0x00001FFF) + 1) >> 1;
        if (pm < (1 * 1024 * 1024))
            printf("%2dK  ", pm >> 10);
        else
            printf("%2dM  ", pm >> 20);

        printf("%01X_", (lo0 & 0x3C000000) >> 26);
        printf("%08X ", (lo0 & 0x03FFFFC0) << 6);
        printf("%d ", (lo0 & 0x00000038) >> 3);
        printf("%c", (lo0 & 0x00000004) ? 'D' : '.');
        printf("%c", (lo0 & 0x00000002) ? 'V' : '.');
        printf("%c  ", (lo0 & 0x00000001) ? 'G' : '.');

        printf("%01X_", (lo1 & 0x3C000000) >> 26);
        printf("%08X ", (lo1 & 0x03FFFFC0) << 6);
        printf("%d ", (lo1 & 0x00000038) >> 3);
        printf("%c", (lo1 & 0x00000004) ? 'D' : '.');
        printf("%c", (lo1 & 0x00000002) ? 'V' : '.');
        printf("%c ", (lo1 & 0x00000001) ? 'G' : '.');
        printf("\n");
        //printf("%2d  Hi %08X Pm %08X Lo0 %08X Lo1 %08X\n", index, hi, pm, lo0, lo1);
    }
    printf("\n");

    /* Restore */
    cp0WrIndex(oIndex);
    cp0WrEntryHi(oEntryHi);

}
#endif
/********************************************************************/


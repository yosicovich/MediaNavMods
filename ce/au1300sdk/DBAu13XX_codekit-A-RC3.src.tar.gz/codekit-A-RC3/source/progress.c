/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

typedef struct
{
    char progress_char;
    char line_prepend;
    int chars_per_line;
    int bytes_per_char;
}
PROGRESS;

PROGRESS progress =
{
    0,
    0,
    40,
    5000
};

static int progress_count = 0;
static int progress_bytes = 0;

//Routine to setup status output
void progress_configure(char progress_char, char line_prepend, int chars_per_line, int bytes_per_char)
{
    progress.progress_char = progress_char;
    progress.line_prepend = line_prepend;
    progress.chars_per_line = chars_per_line;
    progress.bytes_per_char = bytes_per_char;
}

void progress_update(int bytes)
{
    progress_bytes += bytes;
    if (progress.progress_char)
    {
        while (progress_bytes >= progress.bytes_per_char)
        {
            if (progress_count && (progress_count % progress.chars_per_line == 0))
            {
                printf("\n");
                if (progress.line_prepend)
                    printf("%c", progress.line_prepend);
            }

            printf("%c", progress.progress_char);
            progress_bytes -= progress.bytes_per_char;
            progress_count++;
        }
    }
}

void progress_start()
{
    progress_count = 0;
    progress_bytes = 1;
    if (progress.progress_char && progress.line_prepend)
        printf("%c", progress.line_prepend);
}

void progress_stop()
{
    if (progress.progress_char)
        printf("\n");
}

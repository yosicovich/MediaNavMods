/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "ata.h"

/*
 * The address signals for IDE are routed such that each ATA register
 * occupies 32 bytes of physical address space for cache-line DMA optimization
 */
#define IDE_REGISTER_SIZE 32
static uint8* ide_mem_base = (char *)KSEG1(IDE_PHYS_ADDR);
static char icon[] =
    {'-', '\\', '|', '/'
    };
#define MAX_ICON 3

int ide_reset()
{
#if defined(PB1200) || defined(DB1200) // || defined(PB1550)
    DPRINTF("\n");
    bcsr->resets &= ~(BCSR_RESETS_IDE);
    msdelay(100);
    bcsr->resets |= BCSR_RESETS_IDE;
#elif defined(FICMMP)
    platformClearConfigBits(FICMMP_CONFIG_IDERST);
    msdelay(100);
    platformSetConfigBits(FICMMP_CONFIG_IDERST);
#endif

    return 1;
}

int ide_init()
{
#if 0 //defined(FICMMP)
    printf("Powering up drive... ");
    gpioWrite(FICMMP_IDE_PWR); //Power up IDE
    int i;
    for (i = 0; i < 100; ++i)
    {
        printf("\b%c", icon[i%4]);
        msdelay(100);
    }

    printf("\bComplete\n");
#endif

    return ide_reset();
}

int ideEject()
{
    DPRINTF("\n");
    return 1;
}

int ideRead(int sect, int n, void *buf)
{
    //DPRINTF("sect: %d, n: %d, buf: %X\n", sect, n, buf);
    return ata_read_sectors(ide_mem_base, sect, n, buf, IDE_REGISTER_SIZE);
}

int ideWrite(int sect, int n, void *buf)
{
    DPRINTF("sect: %d, n: %d, buf: %X\n", sect, n, buf);
    //return sect*n;
    return ata_write_sectors(ide_mem_base, sect, n, buf, IDE_REGISTER_SIZE);
}

int ideOpen()
{
    return ide_init();
}

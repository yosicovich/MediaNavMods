/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*
 * Sample code to demonstrate CACHE manipulation
 */
#include "example.h"

#define DCACHE

#ifdef ICACHE
#define _CACHE "ICACHE"
#define COP "0x4"
#define TAG cp0RdITag
#define DATA cp0RdIData
#endif

#ifdef DCACHE
#define _CACHE "DCACHE"
#define COP "0x5"
#define TAG cp0RdDTag
#define DATA cp0RdDData
#endif

/********************************************************************/
void
cacheDump (void)
{
    uint32 addr = 0x80000000;
    int way, set, word;
    uint32 tag;

    printf("%s\n", _CACHE);

    for (set = 0; set < 128; ++set)
    {
        for (way = 0; way < 4; ++way)
        {
            addr = 0x80000000 + (way<<12) + (set<<5);
            printf("%08X: ", addr);
            printf("Way %d ", (addr & 0x00003000) >> 12);
            printf("Set %d ", (addr & 0x00000FE0) >> 5);

asm volatile (" cache "COP",0(%0)" : : "r" (addr) );
            asm volatile (" nop");
            tag = TAG();
            printf("Tag: %08X  ", tag);
            printf("PA %08X ", (tag & 0xFFFFF000) | (set<<5));
            printf("MRU %d ",  (tag & 0x00000C00) >> 10);
            printf("NMRU %d ", (tag & 0x00000300) >> 8);
            printf("LRU %d ",  (tag & 0x000000C0) >> 6);
            if (tag & 0x02) printf("L ");
            if (tag & 0x01) printf("V ");
            printf("\n");
#if 0
            printf("    ");
            for (word = 0; word < 8; ++word)
            {
asm volatile (" cache "COP",0(%0)" : : "r" (addr + (word * 4)) );
                asm volatile (" nop");
                printf("%08X ", DATA());
            }
            printf("\n");
#endif
        }
        printf("\n");
    }
}

/********************************************************************/


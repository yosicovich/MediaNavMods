/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

//Frame Buffer manipulation routines

#include "example.h"
#include "frame_buffer.h"
#include "image.h"

void fb_fill_data(FRAME_BUFFER_ADDRESS address, uint32 data, int bytes)
{
    DPRINTF("FB: %X, %X %d bytes\n", address, data, bytes);
    int i;
    int words = bytes / 4;

    for (i = 0; i < words; ++i)
    {
        address[i] = data;
    }
}

void fb_fill(FRAME_BUFFER_ADDRESS address, const FRAME_BUFFER_INFO* info, uint8 a, uint8 r, uint8 g, uint8 b)
{
    DPRINTF("FB: %X, aRGB(%d, %d, %d, %d)\n", address, a, r, g, b);
    int x, y;
    uint32 pixel, packed_pixels;

    //Scale, Shift, Mask pixel
    pixel = pixel_convert(info->pixel_info, a, r, g, b);

    switch (info->pixel_info.memory_width)
    {
        case 8:  packed_pixels = pixel | (pixel << 8) | (pixel << 16) | (pixel << 24); break;
        case 16: packed_pixels = pixel | (pixel << 16); break;
        case 32: packed_pixels = pixel; break;
    }

    fb_fill_data(address, packed_pixels, (info->pixel_info.memory_width * info->width * info->height) / 8);
}

//hmm, this should probably be deprecated by the next function.  Although this creates a corner to corner gradient
void fb_fill_transparency_gradient(FRAME_BUFFER_ADDRESS address, const FRAME_BUFFER_INFO* info, uint8 r, uint8 g, uint8 b)
{
    DPRINTF("FB: %X, RGB(%d, %d, %d), W: %d, H: %d\n", address, r, g, b, info->width, info->height);
    int max = info->width + info->height;
    int maxAlpha = 0x0FF; //info->pixel_info.a_mask >> info->pixel_info.a_shift;
    int x, y;

    for (y = 0; y < info->height; ++y)
    {
        //printf("Row %d[0]: %X\n", y, &address[(y * info->width) + 0]);
        for (x = 0; x < info->width; ++x)
        {
            address[(y * info->width) + x] = pixel_convert(info->pixel_info, ((((x + y) * 100) / max) * maxAlpha) / 100, r, g, b);
        }
        //printf("Row %d[%d]: %X\n", y, x--, &address[(y * info->width) + x]);
    }
}

void fb_fill_horizontal_gradient(FRAME_BUFFER_ADDRESS address, const FRAME_BUFFER_INFO* info, uint8 a1, uint8 r1, uint8 g1, uint8 b1, uint8 a2, uint8 r2, uint8 g2, uint8 b2)
{
    int x, y, fb_index;
    int width = info->width;
    int width_scale = 100;
    //We have to scale up the width in order to get the necessary resolution to do a clean gradient
    int scaled_width = width * width_scale;

    //calculate how many color shades to increment/decrement with each pixel.
    int a_delta = (a2 > a1) ? (a2 - a1) : (a1 - a2);
    int a_mod = (a1 == a2) ? 0 : scaled_width / a_delta;
    if ((a2 != a1) && scaled_width % a_delta != 0)
        a_mod++;
    int a_dir = (a2 > a1) ? 1 : -1;

    int r_delta = (r2 > r1) ? (r2 - r1) : (r1 - r2);
    int r_mod = (r1 == r2) ? 0 : scaled_width / r_delta;
    if ((r2 != r1) && scaled_width % r_delta != 0)
        r_mod++;
    int r_dir = (r2 > r1) ? 1 : -1;

    int g_delta = (g2 > g1) ? (g2 - g1) : (g1 - g2);
    int g_mod = (g1 == g2) ? 0 : scaled_width / g_delta;
    if ((g2 != g1) && scaled_width % g_delta != 0)
        g_mod++;
    int g_dir = (g2 > g1) ? 1 : -1;

    int b_delta = (b2 > b1) ? (b2 - b1) : (b1 - b2);
    int b_mod = (b1 == b2) ? 0 : scaled_width / b_delta;
    if ((b2 != b1) && scaled_width % b_delta != 0)
        b_mod++;
    int b_dir = (b2 > b1) ? 1 : -1;

    DPRINTF("FB: %X, W: %d, H: %d, BPP: %d, Mem Width: %d\n", address, info->width, info->height, info->pixel_info.bpp, info->pixel_info.memory_width);
    DPRINTF("A (%d->%d), R (%d->%d), G (%d->%d), B(%d->%d)\n", a1, a2, r1, r2, g1, g2, b1, b2);
    DPRINTF("A: (%d,%d), R: (%d,%d), G: (%d,%d), B: (%d,%d)\n", a_mod, a_dir, r_mod, r_dir, g_mod, g_dir, b_mod, b_dir);

    for (x = 0; x < scaled_width; ++x) //increment through columns
    {
        if ((x % width_scale) == 0)
        {
            for (y = 0; y < info->height; ++y) //incrment through each row in this column
            {
                fb_index = (y * info->width) + (x / width_scale); //calculate the index into the frame buffer for this pixel
                switch (info->pixel_info.memory_width) //we have to index into the right data type depending on how big each pixel is
                {
                    case 8:  ((unsigned char*) (address))[fb_index] = (unsigned char)  pixel_convert(info->pixel_info, a1, r1, g1, b1); break;
                    case 16: ((unsigned short*)(address))[fb_index] = (unsigned short) pixel_convert(info->pixel_info, a1, r1, g1, b1); break;
                    case 32: ((unsigned int*)  (address))[fb_index] = (unsigned int)   pixel_convert(info->pixel_info, a1, r1, g1, b1); break;
                }
            }
        }

        //increment/decrement the shade of each color element
        if (a_mod && (x % a_mod) == 0)
            a1 += a_dir;
        if (r_mod && (x % r_mod) == 0)
            r1 += r_dir;
        if (g_mod && (x % g_mod) == 0)
            g1 += g_dir;
        if (b_mod && (x % b_mod) == 0)
            b1 += b_dir;
    }
}

void fb_fill_vertical_gradient(FRAME_BUFFER_ADDRESS address, const FRAME_BUFFER_INFO* info, uint8 a1, uint8 r1, uint8 g1, uint8 b1, uint8 a2, uint8 r2, uint8 g2, uint8 b2)
{
    int x, y, fb_index;
    int height = info->height;
    int height_scale = 100;
    //We have to scale up the height in order to get the necessary resolution to do a clean gradient
    int scaled_height = height * height_scale;

    //calculate how many color shades to increment/decrement with each pixel.
    int a_delta = (a2 > a1) ? (a2 - a1) : (a1 - a2);   //compute the delta between the two colors
    int a_mod = (a1 == a2) ? 0 : scaled_height / a_delta;  //compute the number of color changes needed (scaled x100)
    if ((a2 != a1) && scaled_height % a_delta != 0)   //if not an even division, round up one so we don't go over
        a_mod++;
    int a_dir = (a2 > a1) ? 1 : -1;        //determine the direction of the color change

    int r_delta = (r2 > r1) ? (r2 - r1) : (r1 - r2);
    int r_mod = (r1 == r2) ? 0 : scaled_height / r_delta;
    if ((r2 != r1) && scaled_height % r_delta != 0)
        r_mod++;
    int r_dir = (r2 > r1) ? 1 : -1;

    int g_delta = (g2 > g1) ? (g2 - g1) : (g1 - g2);
    int g_mod = (g1 == g2) ? 0 : scaled_height / g_delta;
    if ((g2 != g1) && scaled_height % g_delta != 0)
        g_mod++;
    int g_dir = (g2 > g1) ? 1 : -1;

    int b_delta = (b2 > b1) ? (b2 - b1) : (b1 - b2);
    int b_mod = (b1 == b2) ? 0 : scaled_height / b_delta;
    if ((b2 != b1) && scaled_height % b_delta != 0)
        b_mod++;
    int b_dir = (b2 > b1) ? 1 : -1;

    DPRINTF("FB: %X, W: %d, H: %d, BPP: %d, Mem height: %d\n", address, info->height, info->height, info->pixel_info.bpp, info->pixel_info.memory_width);
    DPRINTF("A (%d->%d), R (%d->%d), G (%d->%d), B(%d->%d)\n", a1, a2, r1, r2, g1, g2, b1, b2);
    DPRINTF("A: (%d,%d), R: (%d,%d), G: (%d,%d), B: (%d,%d)\n", a_mod, a_dir, r_mod, r_dir, g_mod, g_dir, b_mod, b_dir);

    for (y = 0; y < scaled_height; ++y) //increment through columns
    {
        if ((y % height_scale) == 0) //We only draw the line every y/scaled_height times.
        {
            for (x = 0; x < info->width; ++x) //incrment through each row in this column
            {
                fb_index = ((y/height_scale) * info->width) + x; //calculate the index into the frame buffer for this pixel

                switch (info->pixel_info.memory_width) //we have to index into the right data type depending on how big each pixel is
                {
                    case 8:  ((unsigned char*) (address))[fb_index] = (unsigned char)  pixel_convert(info->pixel_info, a1, r1, g1, b1); break;
                    case 16: ((unsigned short*)(address))[fb_index] = (unsigned short) pixel_convert(info->pixel_info, a1, r1, g1, b1); break;
                    case 32: ((unsigned int*)  (address))[fb_index] = (unsigned int)   pixel_convert(info->pixel_info, a1, r1, g1, b1); break;
                }
            }
        }

        //increment/decrement the shade of each color element
        if (a_mod && (y % a_mod) == 0)
            a1 += a_dir;
        if (r_mod && (y % r_mod) == 0)
            r1 += r_dir;
        if (g_mod && (y % g_mod) == 0)
            g1 += g_dir;
        if (b_mod && (y % b_mod) == 0)
            b1 += b_dir;
    }
}

//This function only supports PO_0 or P0_3
void fb_palatize_image(FRAME_BUFFER_ADDRESS index_buffer, const FRAME_BUFFER_INFO* index_info, IMAGE* image, uint32* pallete, int pallete_size)
{
    DPRINTF("%s: (%X)\n", image->info.description, image);
    uint8 used_colors[16];
    uint32* source_pixels = (uint32*) &image->pixel_data;
    uint32 packed_pixels;
    int i, j, c, shift, warning = FALSE;
    int pallete_index = 0;
    int shift_start = 0;
    int shift_direction = 1;

    if (index_info->pixel_info.pixel_ordering == PO_0)
    {
        shift_start = 31 - (index_info->pixel_info.bpp - 1);
        shift_direction = -1;
    }

    DPRINTF("Shift start: %d, shift Direction: %d\n", shift_start, shift_direction);

    for (i = 0; i < pallete_size; ++i)
    {
        used_colors[i] = FALSE;
    }

    DPRINTF("Source Pixels: %X, Index Data: %X, Index Width: %d\n", source_pixels, index_buffer, index_info->pixel_info.bpp);

    for (i = 0; i < (image->info.width * image->info.height); i += j)
    {
        packed_pixels = 0;    //Empty the packed pixel color-index register
        shift = shift_start;

        for (j = 0; j < (32/index_info->pixel_info.bpp); ++j) //pack an entire register
        {
            for (c = 0; (c < pallete_size) && !(used_colors[c] && (pallete[c] == source_pixels[i+j])); ++c); //Find this color in the map

            if (c == pallete_size) //This color doesn't exist yet
            {
                for (c = 0; (c < pallete_size) && used_colors[c]; ++c); //Find the first free color in the map

                if (c == pallete_size) //does this image use too many colors?
                {
                    c = 0; //just use the first color instead
                    if (warning == FALSE) //only warn the user once
                    {
                        printf("\tWarning: Hardware Cursor image uses too many colors (%d)\n", c);
                        warning = TRUE;
                    }
                }
                else //Insert this color into the color map
                {
                    used_colors[c] = TRUE;
                    pallete[c] = source_pixels[i+j];
                    DPRINTF("Pallete Color[%X]: %0X\n", &pallete[c], pallete[c]);
                }
            }

            packed_pixels |= (c << shift); //Pack this color-index into the WORD

            //Move the shift value by the size of each pixel
            //Depending on the pixel-ordering, we either increment or decrement the shift
            shift += index_info->pixel_info.bpp * shift_direction;
        }

        index_buffer[pallete_index++] = packed_pixels;
    }
}

//get ready for some crazy math
void fb_copy_image(FRAME_BUFFER_ADDRESS address, const FRAME_BUFFER_INFO* info, IMAGE* image, int x_origin, int y_origin)
{
    DPRINTF("FB: %X, Image: %X\n", address, image);
    int x, y;
    int fb_index, im_index;
    int x_offset, y_offset;

    if (x_origin < 0)
        x_offset = x_origin * -1; //start drawing with the first visible pixel (not off the screen)
    else
        x_offset = 0;

    if (y_origin < 0)
        y_offset = y_origin * -1; //start drawing with the first visible pixel (not off the screen)
    else
        y_offset = 0;

    //A. start iterating with the first visible row (not off the top of the screen) of the image.
    //B. iterate through each row in the image
    //C. stop iterating at the first row that would run off the bottom of the screen
    //      [A]           [B]                   [C]
    for (y = y_offset; y < image->info.height && (y + y_origin < info->height); ++y)
    {
        //printf("Row: %d\n", y);
        //A. start iterating with the first visible pixel (not off the left-side of the screen) of the current row.
        //B. iterate through each pixel in the row
        //C. stop iterating at the first pixel that would run off the right-side of the screen
        //      [A]           [B]                  [C]
        for (x = x_offset; x < image->info.width && (x + x_origin < info->width); ++x)
        {
            fb_index = ((y + y_origin) * info->width) + (x + x_origin); //Compute the index in the frame buffer for this pixel of the image
            im_index = (y * image->info.width) + x;      //Compute the index in the image for this pixel


            //printf("Column: %d, Addr: %X\n", x, &((unsigned int*)  (address))[fb_index]);
            switch (info->pixel_info.memory_width) //We have to index into the right data type depending on how big each pixel is
            {
                case 8:  ((unsigned char*) (address))[fb_index] = (unsigned char)  ((unsigned char*) (&image->pixel_data))[im_index]; break;
                case 16: ((unsigned short*)(address))[fb_index] = (unsigned short) ((unsigned short*)(&image->pixel_data))[im_index]; break;
                case 32: ((unsigned int*)  (address))[fb_index] = (unsigned int)   ((unsigned int*)  (&image->pixel_data))[im_index]; break;
            }
        }
    }
}

//get ready for some crazy math
void fb_fill_rectangle(FRAME_BUFFER_ADDRESS address, const FRAME_BUFFER_INFO* info, int x_origin, int y_origin, int width, int height, uint8 a, uint8 r, uint8 g, uint8 b)
{
    DPRINTF("FB: %X\n", address);
    int x, y;
    int fb_index;
    int x_offset, y_offset;

    if (x_origin < 0)
        x_offset = x_origin * -1; //start drawing with the first visible pixel (not off the screen)
    else
        x_offset = 0;

    if (y_origin < 0)
        y_offset = y_origin * -1; //start drawing with the first visible pixel (not off the screen)
    else
        y_offset = 0;

    //A. start iterating with the first visible row (not off the top of the screen) of the image.
    //B. iterate through each row in the image
    //C. stop iterating at the first row that would run off the bottom of the screen
    //      [A]           [B]                   [C]
    for (y = y_offset; y < height && (y + y_origin < info->height); ++y)
    {
        //printf("Row: %d\n", y);
        //A. start iterating with the first visible pixel (not off the left-side of the screen) of the current row.
        //B. iterate through each pixel in the row
        //C. stop iterating at the first pixel that would run off the right-side of the screen
        //      [A]           [B]                  [C]
        for (x = x_offset; x < width && (x + x_origin < info->width); ++x)
        {
            fb_index = ((y + y_origin) * info->width) + (x + x_origin); //Compute the index in the frame buffer for this pixel of the image

            //printf("Column: %d, Addr: %X\n", x, &((unsigned int*)  (address))[fb_index]);
            switch (info->pixel_info.memory_width) //We have to index into the right data type depending on how big each pixel is
            {
                case 8:  ((unsigned char*) (address))[fb_index] = (unsigned char)  pixel_convert(info->pixel_info, a, r, g, b); break;
                case 16: ((unsigned short*)(address))[fb_index] = (unsigned short) pixel_convert(info->pixel_info, a, r, g, b); break;
                case 32: ((unsigned int*)  (address))[fb_index] = (unsigned int)   pixel_convert(info->pixel_info, a, r, g, b); break;
            }
        }
    }
}

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "nand.h"

/********************************************************************/

static
AU1X00_STATIC * const
mem = (void *)KSEG1(STATIC_MEM_PHYS_ADDR);

int NAND_HW_ECC = 0;

#if 0
#define wrReg8(REG,DATA) REG = DATA
#define rdReg8(REG)   REG
#define wrReg16(REG,DATA) REG = DATA
#define rdReg16(REG)   REG

#else
#define wrReg8(REG,DATA) _wrReg8(& REG, DATA)
#define rdReg8(REG) _rdReg8(& REG)
#define wrReg16(REG,DATA) _wrReg16(& REG, DATA)
#define rdReg16(REG) _rdReg16(& REG)
#define rdReg32(REG) _rdReg32(& REG)
#define wrReg32(REG,DATA) _wrReg32(& REG, DATA)
static
void
_wrReg8 (volatile void *addr, uint8 data)
{
    *(volatile uint8 *)addr = data;
    asm volatile (" sync");
}

static
uint8
_rdReg8 (volatile void *addr)
{
    asm volatile (" sync");
    return *(volatile uint8 *)addr;
}
static
void
_wrReg16 (volatile void *addr, uint16 data)
{
    *(volatile uint16 *)addr = data;
    asm volatile (" sync");
}

static
uint16
_rdReg16 (volatile void *addr)
{
    asm volatile (" sync");
    return *(volatile uint16 *)addr;
}

static
void
_wrReg32 (volatile void *addr, uint32 data)
{
    *(volatile uint32 *)addr = data;
    asm volatile (" sync");
}
static
uint32
_rdReg32 (volatile void *addr)
{
    asm volatile (" sync");
    return *(volatile uint32 *)addr;
}

#endif

/********************************************************************/
/* FIX!!! This belongs in au1x00.h */
typedef volatile struct
{
    uint32 stcfg;
    uint32 sttime;
    uint32 staddr;
    uint32 reserved;
}
AU1X00_STCHIPSELECT;

#define MEM_STSTAT_PWT  (1<<5)
#define MEM_STSTAT_EWT  (1<<4)
#define MEM_STSTAT_BOOT  (3<<1)
#define MEM_STSTAT_BSY  (1<<0)

#define MEM_STNDCTRL_IE  (1<<8)
#define MEM_STNDCTRL_CS3O (1<<7)
#define MEM_STNDCTRL_CS2O (1<<6)
#define MEM_STNDCTRL_CS1O (1<<5)
#define MEM_STNDCTRL_CS0O (1<<4)
#define MEM_STNDCTRL_BOOT (1<<0)
typedef volatile struct
{
    uint8 cmd;
    uint8 reserved0[3];
    uint8 addr;
    uint8 reserved1[3];
    uint32 reserved2[(0x20-0x08)/sizeof(uint32)];
    union
    {
        uint8 data8;
        uint16 data16;
        uint32 data32;
    };
    uint8 reserved3[12];
    uint32 trig;
    uint32 reserved4;
    uint32 rst;
}
AU1X00_NAND;

static
AU1X00_NAND * nandif = NULL;

/********************************************************************/

static
void col1_read_data (unsigned col, unsigned row);
static
int col1_read_spare (unsigned col, unsigned row);
static
void col1_write_data (unsigned col, unsigned row);
static
void col1_write_spare (unsigned col, unsigned row);

static
void col2_read_data (unsigned col, unsigned row);
static
int col2_read_spare (unsigned col, unsigned row);
static
void col2_write_data (unsigned col, unsigned row);
static
void col2_write_spare (unsigned col, unsigned row);

static
void lba_init(void);
static
void lba_flush(void);
static
void lba_write_spare(unsigned unused, unsigned page);
static
int lba_read_spare(unsigned unused, unsigned page);
static
void lba_write_data(unsigned unused, unsigned page);
static
void lba_read_data(unsigned unused, unsigned page);


static
void default_flush(void)
{}

static
NandDevice nand_devices[] =
{
    {
        .model = ("Toshiba TC58DVM92A1FT00"),
        .maker = (0x98),
        .device = (0x76),
        //.sttime = (NAND_TIMING),
        .data_width = (8),
        .data_size = (512),
        .spare_size = (16),
        .bad_offset = (0), /* NOTE: It's really 0 thru 6 */
        .pages_per_block = (32),
        .blocks_per_device = (4096),
        .cs_dont_care = (0),
        .rdwr_requires_spare = (0),
        .column_cycles = (1),
        .row_cycles = (3),
        .cmd_read_data = (col1_read_data),
        .cmd_read_spare = (col1_read_spare),
        .cmd_write_data = (col1_write_data),
        .cmd_write_spare = (col1_write_spare),
        .init = (NULL),
        .flush = (default_flush),
    },
    {
        .model = ("Samsung K9F1216U0A-YCB0"),
        .maker = (0xEC),
        .device = (0x56),
        //.sttime = (NAND_TIMING),
        .data_width = (16),
        .data_size = (512),
        .spare_size = (16),
        .bad_offset = (0),
        .pages_per_block = (32),
        .blocks_per_device = (4096),
        .cs_dont_care = (1),
        .rdwr_requires_spare = (0),
        .column_cycles = (1),
        .row_cycles = (3),
        .cmd_read_data = (col1_read_data),
        .cmd_read_spare = (col1_read_spare),
        .cmd_write_data = (col1_write_data),
        .cmd_write_spare = (col1_write_spare),
        .init = (NULL),
        .flush = (default_flush),
    },
    {
        .model = ("Samsung K9F1208U0A-YCB0"),
        .maker = (0xEC),
        .device = (0x76),
        //.sttime = (NAND_TIMING),
        .data_width = (8),
        .data_size = (512),
        .spare_size = (16),
        .bad_offset = (6),
        .pages_per_block = (32),
        .blocks_per_device = (4096),
        .cs_dont_care = (0),
        .rdwr_requires_spare = (0),
        .column_cycles = (1),
        .row_cycles = (3),
        .cmd_read_data = (col1_read_data),
        .cmd_read_spare = (col1_read_spare),
        .cmd_write_data = (col1_write_data),
        .cmd_write_spare = (col1_write_spare),
        .init = (NULL),
        .flush = (default_flush),
    },
    {
        .model = ("Samsung K9K4G08U0M"),
        .maker = (0xEC),
        .device = (0xDC),
        //.sttime = (NAND_TIMING),
        .data_width = (8),
        .data_size = (2048),
        .spare_size = (64),
        .bad_offset = (0),
        .pages_per_block = (64),
        .blocks_per_device = (4096),
        .cs_dont_care = (0),
        .rdwr_requires_spare = (0),
        .column_cycles = (2),
        .row_cycles = (3),
        .cmd_read_data = (col2_read_data),
        .cmd_read_spare = (col2_read_spare),
        .cmd_write_data = (col2_write_data),
        .cmd_write_spare = (col2_write_spare),
        .init = (NULL),
        .flush = (default_flush),
    },
    {
        .model = ("Samsung K9G8G08U0M (MLC)"),
        .maker = (0xEC),
        .device = (0xD3),
        //.sttime = (NAND_TIMING),
        .data_width = (8),
        .data_size = (2048),
        .spare_size = (64),
        .bad_offset = (0),
        .pages_per_block = (128),
        .blocks_per_device = (4096),
        .cs_dont_care = (0),
        .rdwr_requires_spare = (0),
        .column_cycles = (2),
        .row_cycles = (3),
        .cmd_read_data = (col2_read_data),
        .cmd_read_spare = (col2_read_spare),
        .cmd_write_data = (col2_write_data),
        .cmd_write_spare = (col2_write_spare),
        .init = (NULL),
        .flush = (default_flush),
    },
    /*
     * For LBA-NAND we don't worry about the "data" partition.
     *  This utility will only read/write the PNP and
     *  possibly the VFP.
     */
    {
        .model = ("Tosiba LBA-NAND = (PureNandMode) THGVN Series"),
        .maker = (0x98),
        .device = (0xDC),
        //.sttime = (NAND_TIMING),
        .data_width = (8),
        .data_size = (2048),
        .spare_size = (64),
        .bad_offset = (0),
        .pages_per_block = (256),
        .blocks_per_device = (1),
        .cs_dont_care = (0),
        .rdwr_requires_spare = (1),
        .column_cycles = (2),
        .row_cycles = (3),
        .cmd_read_data = (lba_read_data),
        .cmd_read_spare = (lba_read_spare),
        .cmd_write_data = (lba_write_data),
        .cmd_write_spare = (lba_write_spare),
        .init = (lba_init),
        .flush = (lba_flush),
    },
    {
        .model = ("Micron MT29F2G"),
        .maker = (0x2c),
        .device = (0xDA),
        //.sttime = (NAND_TIMING),
        .data_width = (8),
        .data_size = (2048),
        .spare_size = (64),
        .bad_offset = (0),
        .pages_per_block = (64),
        .blocks_per_device = (4096),
        .cs_dont_care = (1),
        .rdwr_requires_spare = (0),
        .column_cycles = (2),
        .row_cycles = (3),
        .cmd_read_data = (col2_read_data),
        .cmd_read_spare = (col2_read_spare),
        .cmd_write_data = (col2_write_data),
        .cmd_write_spare = (col2_write_spare),
        .init = (NULL),
        .flush = (default_flush),
    },
};

#define SIZEOF_NANDDEVICES (sizeof(nand_devices) / sizeof(NandDevice))

NandDevice* nand_device;
int VERBOSE = TRUE;

/********************************************************************/

/*
 * Methods for generating read and write commands with addressing.
 * Unfortunately NAND devices differ in implementation, so these
 * are necessary.
 */
static
void
nand_send_page_addr (unsigned page)
{
    int i;
    for (i = 0; i < nand_device->row_cycles; ++i)
    {
        wrReg8(nandif->addr, (page & 0xFF));
        page >>= 8;

    }
}

static
void
col1_read_data (unsigned col, unsigned page)
{
    /* Col is byte offset relative to data area */
    if (col >= (nand_device->data_size/2))
    {
        col >>= 8;
        wrReg8(nandif->cmd, 0x01); /* 'B' Area */
    }
    else
        wrReg8(nandif->cmd, 0x00); /* 'A' Area */

    /* Convert col to word (not byte) offset */
    if (nand_device->data_width == 16)
        col >>= 1;

    /* 1 beat of column address */
    wrReg8(nandif->addr, (col & 0xFF));

    nand_send_page_addr(page);
}

static
int
col1_read_spare (unsigned col, unsigned page)
{
    /* Col is byte offset relative to spare area */
    wrReg8(nandif->cmd, 0x50); /* 'C' Area */

    /* Convert col to word (not byte) offset */
    if (nand_device->data_width == 16)
        col >>= 1;

    /* 1 beat of column address */
    wrReg8(nandif->addr, (col & 0xFF));

    nand_send_page_addr(page);

    return WAIT;
}

static
void
col1_write_data (unsigned col, unsigned page)
{
    /* Col is byte offset relative to data area */
    if (col >= (nand_device->data_size/2))
    {
        col >>= 8;
        wrReg8(nandif->cmd, 0x01); /* 'B' Area */
    }
    else
        wrReg8(nandif->cmd, 0x00); /* 'A' Area */

    /* Convert col to word (not byte) offset */
    if (nand_device->data_width == 16)
        col >>= 1;

    wrReg8(nandif->cmd, 0x80);

    /* 1 beat of column address */
    wrReg8(nandif->addr, (col & 0xFF));

    nand_send_page_addr(page);
}

static
void
col1_write_spare (unsigned col, unsigned page)
{
    /* Col is byte offset relative to spare area */
    wrReg8(nandif->cmd, 0x50); /* 'A' Area */
    wrReg8(nandif->cmd, 0x80);

    /* Convert col to word (not byte) offset */
    if (nand_device->data_width == 16)
        col >>= 1;

    /* 1 beat of column address */
    wrReg8(nandif->addr, (col & 0xFF));

    nand_send_page_addr(page);
}

/* xxxxxxxxxxx */
static
void
col2_read_data (unsigned col, unsigned page)
{
  //  printf("----\n");

    /* Col is byte offset relative to data area */
    wrReg8(nandif->cmd, 0x00);
//    printf("[0x%X] <= 0\n", &(nandif->cmd));

    /* Convert col to word (not byte) offset */
    if (nand_device->data_width == 16)
        col >>= 1;

    /* 2 beats of column address */
    wrReg8(nandif->addr, (col & 0xFF));
//    printf("[0x%X] <= 0x%X\n", &(nandif->addr), (col & 0xFF));
    col >>= 8;
    wrReg8(nandif->addr, (col & 0xFF));
//    printf("[0x%X] <= 0x%X\n", &(nandif->addr), (col & 0xFF));

    nand_send_page_addr(page);

    wrReg8(nandif->cmd, 0x30);
//    printf("[0x%X] <= 0x30\n", &(nandif->cmd));
}

static
int
col2_read_spare (unsigned col, unsigned page)
{
    /* Col is byte offset relative to spare area */
    col2_read_data(col + nand_device->data_size, page);
    return WAIT;
}

static
void
col2_write_data (unsigned col, unsigned page)
{
    /* Col is byte offset relative to data area */

    /* Convert col to word (not byte) offset */
    if (nand_device->data_width == 16)
        col >>= 1;

    wrReg8(nandif->cmd, 0x80);

    /* 2 beats of column address */
    wrReg8(nandif->addr, (col & 0xFF));
    col >>= 8;
    wrReg8(nandif->addr, (col & 0xFF));

    nand_send_page_addr(page);
}

static
void
col2_write_spare (unsigned col, unsigned page)
{
    /* Col is byte offset relative to spare area */
    col2_write_data(col + nand_device->data_size, page);
}

/********************************************************************/
static
int
nand_wait (void)
{
#define TIMEOUT 1000000
    int timeout;

    /* look for HI to LO transition */
    timeout = TIMEOUT;
    while ((mem->ststat & MEM_STSTAT_BSY) != 0)
    {
        if (--timeout == 0)
            break;
    }

    while ((mem->ststat & MEM_STSTAT_BSY) == 0)
    {
        if ( VERBOSE ) printf(".");
    }

    return 0;
}

/********************************************************************/
int
nand_reset (void)
{
    wrReg8(nandif->cmd, 0xFF);
    return nand_wait();
}

static
    int
nand_reset_ecc (void)
{
    wrReg32(nandif->rst, 1);
    return nand_wait();
}

static
    void
nand_trigger_ecc(void)
{
    wrReg32(nandif->trig, 0);
    nand_wait();
}

static
    int
nand_check_ecc_status(void)
{
    int corrected;

    if (mem->ststat & MEM_STSTAT_DF) {
        return -1;
    }

    if (mem->ststat & MEM_STSTAT_SN) {
        corrected = (mem->ststat & MEM_STSTAT_NEC) >> 8;
        return corrected;
    }

    return 0;
}

/********************************************************************/
static
void
nand_read_id (uint8* maker, uint8* device)
{
    wrReg8(nandif->cmd, 0x90);
    wrReg8(nandif->addr, 0x00);
    *maker = rdReg8(nandif->data8);
    *device = rdReg8(nandif->data8);
}

/********************************************************************/
static
int
nand_locate_device(uint8 *maker, uint8 *device)
{
    int i;

    *maker = 0xFF;
    *device = 0xFF;

    /* Must issue reset, have no idea what was happening previously */
    if (nand_reset() == 0)
    {
        /* Read first Maker and Device identification bytes */
        nand_read_id(maker, device);

        for (i = 0; i < SIZEOF_NANDDEVICES; ++i)
        {
            if ((nand_devices[i].maker == *maker) &&
                    (nand_devices[i].device == *device))
            {
                nand_device = &nand_devices[i];
                {
                    int total_size = nand_device->data_size + nand_device->spare_size;

                    /* FIX!!! Give NandDevice a chance to read remaining ID codes */
                    if ( nand_device->init )
                        nand_device->init();

                    nand_device->spare_size_ecc = nand_device->spare_size - ((total_size / 528) * 13);
                    nand_device->spare_offset_ecc = nand_device->spare_size - nand_device->spare_size_ecc - 13;
                }
                break;
            }
        }
    }

    /* Sometimes there may be more id data following, ignore */
    if (nand_device != NULL)
    {
        nand_reset();
        return 0;
    }
    else
        return -1;

}

/********************************************************************/
void
nand_show_device (void)
{
    unsigned size;
    size =
        nand_device->data_size *
        nand_device->pages_per_block *
        nand_device->blocks_per_device;

    printf(" Model:  %s\n", nand_device->model);
    printf(" Maker:  0x%X\n", nand_device->maker);
    printf(" Device: 0x%X\n", nand_device->device);
    printf(" Width:  %d\n", nand_device->data_width);
    printf(" Data:   %d bytes\n", nand_device->data_size);
    printf(" Spare:  %d bytes\n", nand_device->spare_size);
    printf(" Block:  %d pages\n", nand_device->pages_per_block);
    printf(" Size:   %d blocks\n", nand_device->blocks_per_device);
    printf(" Total Size: %dKB (%dMB)\n", size>>10,size >> 20);
}

/********************************************************************/
NandDevice *
nand_initialize (void)
{
    uint8 maker, device;
    AU1X00_STCHIPSELECT *cs = NULL;
    uint32 nand_phys;
    int csnum;

    printf("%s\n", __FUNCTION__);


    /*
     * Interrogate the static controller to determine where NAND is.
     * Note that only one chip-select is allowed to be NAND type.
     */
    if ((mem->stcfg0 & MEM_STCFG_DTY) == MEM_STCFG_DTY_NAND)
    {
        cs = (AU1X00_STCHIPSELECT *)&mem->stcfg0;
        csnum = 0;
    }
    else
        if ((mem->stcfg1 & MEM_STCFG_DTY) == MEM_STCFG_DTY_NAND)
        {
            cs = (AU1X00_STCHIPSELECT *)&mem->stcfg1;
            csnum = 1;
        }
        else
            if ((mem->stcfg2 & MEM_STCFG_DTY) == MEM_STCFG_DTY_NAND)
            {
                cs = (AU1X00_STCHIPSELECT *)&mem->stcfg2;
                csnum = 2;
            }
            else
                if ((mem->stcfg3 & MEM_STCFG_DTY) == MEM_STCFG_DTY_NAND)
                {
                    cs = (AU1X00_STCHIPSELECT *)&mem->stcfg3;
                    csnum = 3;
                }

#ifdef CONFIG_PB1550
    /* NOTE: Board requires different switch settings for x8 and x16 NAND. */

    /* Pb1550 chip-select dorked in YAMON, correct here */
    cs->stcfg  = 0x00400005;
    cs->sttime = 0x00007774;
    cs->staddr = 0x11203FFF; /* 0x12000FFF also works but requires TLB */
    //CPLD Control to NAND devices *requires* GPIO206 ouput High
    gpio2Write(206, 1);
    printf("STCFG%d:  %08X\n", csnum, cs->stcfg);
    printf("STTIME%d: %08X\n", csnum, cs->sttime);
    printf("STADDR%d: %08X\n", csnum, cs->staddr);
#endif

#ifdef CONFIG_PB1200
    // This is only applicable to PB1200-DDR2 S/N: 004 with the
    // large block NAND workaround in place. Setting GPIO[3] to 1
    // disables the external workaround on ALE and CLE.
    gpioWrite(3, 1);
#endif

    if ((cs == NULL) || ((cs->staddr & MEM_STADDR_E) == 0))
    {
        printf("ERROR: No NAND chip-select detected!\n");
        return;
    }

    /*
     * Au1550 settings:
     * stcfg[18,17, 6],NAND Result     stcfg[18,17, 6],NAND Result
     *        0, 0, 0, x8   OK                0, 0, 1, x8   OK
     *        0, 1, 0, x8   OK                0, 1, 1, x8   OK
     *        1, 0, 0, x8   OK                1, 0, 1, x8   OK
     *        1, 1, 0, x8   OK                1, 1, 1, x8   OK
     *
     *        0, 0, 0, x16  OK                0, 0, 1, x16  OK
     *        0, 1, 0, x16  OK                0, 1, 1, x16  OK
     *        1, 0, 0, x16  OK                1, 0, 1, x16  OK
     *        1, 1, 0, x16  OK                1, 1, 1, x16  OK
     *
     * Au1200 settings:
     * stcfg[18,17],NAND Result      stcfg[18,17],NAND Result
     *        0, 0, x8   OK                 0, 0, x16  OK
     *        0, 1, x8   OK                 0, 1, x16  OK
     *        1, 0, x8   FAIL               1, 0, x16  FAIL
     *        1, 1, x8   FAIL               1, 1, x16  FAIL
     *
     * Au1200 databook errata:
     * Bits 18:17 must be 01 (or 00), not 10 as mandated by databook!
     */
#if defined(CONFIG_AU1200)
    cs->stcfg &= ~((1 << 18) | (1 << 17));
#endif

#if defined(CONFIG_AU1300)
/*    cs->stcfg  = 0x00440045;*/
      cs->stcfg  = 0x00420045; /* 0x440045 will not work when chip select is 0 */
#endif

    /*
     * Must ALWAYS set NW=1 for x8 operation in order to do the
     * READ ID operation correctly.
     */
    cs->stcfg |= MEM_STCFG_NW;

    /*
     * Compute NAND interface physical address
     */
    nand_phys = ((cs->staddr & MEM_STADDR_CSBA) << 4);

    if (nand_phys == 0)
        printf("ERROR: Improper NAND chip-select detected!\n");

    else
    {
        // Map physical address to obtain valid virtual pointer
        nandif = (AU1X00_NAND *)mapPhysicalAddress (nand_phys, sizeof(AU1X00_NAND), 0);
        printf("\nNANDCtrlr: phys %08X, virt %08X\n\n", nand_phys, nandif);
    }

    /*
     * Identify which NAND device in use
     */
    if (nand_locate_device(&maker, &device) == 0)
    {
        nand_show_device();
    }
    else
    {
        printf("ERROR: Unknown NAND: Maker %02X, Device %02X\n", maker, device);
        return;
    }

    /*
     * Tailor the chip-select settings to the NAND device in use
     */
    if (nand_device->data_width == 16)
    {
        printf("Clearing NW for 16-bit NAND\n");
        cs->stcfg &= ~MEM_STCFG_NW;
    }
    else
    {
        printf("Setting NW for 8-bit NAND\n");
        cs->stcfg |= MEM_STCFG_NW;
    }

    if (nand_device->sttime != 0)
        cs->sttime = nand_device->sttime;

    /* IMPORTANT: Most NAND need CE# asserted... */
    if (nand_device->cs_dont_care == 0)
        mem->stndctl |= (MEM_STNDCTRL_CS0O << csnum);

    printf("\n");
    printf("STCFG%d:  %08X\n", csnum, cs->stcfg);
    printf("STTIME%d: %08X\n", csnum, cs->sttime);
    printf("STADDR%d: %08X\n", csnum, cs->staddr);

    if (NAND_HW_ECC)
        nand_enable_ecc();

    return nand_device;
}

/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/

    void
nand_enable_ecc (void)
{
    mem->stndctl &= ~MEM_STNDCTRL_ECR;
    mem->stndctl &= ~MEM_STNDCTRL_DFS;
    mem->stndctl |= MEM_STNDCTRL_ECE;

    nand_reset_ecc();
}

void
nand_disable_ecc (void)
{
    nand_reset_ecc();

    mem->stndctl &= ~MEM_STNDCTRL_ECE;
}

// spare in this case will only read 12 bytes
    int 
nand_read_page_ecc (unsigned page, void *data, void *spare)
{
    int i;
    int sector_bytes = 2048;
    int bytes;
    uint32 tmp[130];
    uint8 *data8 = data;
    unsigned col = 0;
    int status = 0;
    int stat;

    //printf("Reading page %d with ECC\n", page);

    if (data)  memset(data, 0, 2048);
    if (spare) memset(spare, 0, 12);

    while (sector_bytes) {
        nand_device->cmd_read_data(col, page);
        nand_wait();

        nand_trigger_ecc();

        for (i = 0; i < 129; i++)
        {
            tmp[i] = rdReg32(nandif->data32);
        }

        stat = nand_check_ecc_status();
        if (stat == -1)
            return -1;
        else if (stat > 0)
            status += stat;

        if (sector_bytes >= 515)
            bytes = 515;
        else
            bytes = sector_bytes;

        if (data)
            memcpy(data8, tmp, bytes);

        sector_bytes -= bytes;
        data8 += bytes;
        col += 528;
    }

    if (spare)
        memcpy(spare, ((uint8*)tmp) + bytes, 12);

    return status;
}

int
nand_read_page_raw (unsigned page, void *data, void *spare)
{
    /* This routine reads the entire data and/or spare areas */
    int i;

    if (data != NULL)
    {
        nand_device->cmd_read_data(0, page);
        nand_wait();
        if (nand_device->data_width == 16)
        {
            uint16 *data16 = data;
            for (i = 0; i < nand_device->data_size; i += sizeof(uint16))
            {
                data16[i/sizeof(uint16)] = rdReg16(nandif->data16);
            }
        }
        else
        {
            uint8 *data8 = data;
            for (i = 0; i < nand_device->data_size; i += sizeof(uint8))
            {
                data8[i/sizeof(uint8)] = rdReg8(nandif->data8);
            }
        }
    }

    if (spare != NULL)
    {
        if (data == NULL)
        {
            if ( nand_device->cmd_read_spare(0, page) )
                nand_wait();
        }
        if (nand_device->data_width == 16)
        {
            uint16 *spare16 = spare;
            for (i = 0; i < nand_device->spare_size; i += sizeof(uint16))
            {
                spare16[i/sizeof(uint16)] = rdReg16(nandif->data16);
            }
        }
        else
        {
            uint8 *spare8 = spare;
            for (i = 0; i < nand_device->spare_size; i += sizeof(uint8))
            {
                spare8[i/sizeof(uint8)] = rdReg8(nandif->data8);
            }
        }
        //wrReg8(nandif->cmd, 0x00); /* reset to beginning of page - maybe Samsungx8 specific */
    }
    else if ( nand_device->rdwr_requires_spare )
    {
        if (nand_device->data_width == 16)
            for (i = 0; i < nand_device->spare_size; i += sizeof(uint16))
            {
                uint16 tmp;
                tmp  = rdReg16(nandif->data16);
            }
        else
            for (i = 0; i < nand_device->spare_size; i += sizeof(uint8))
            {
                uint8 tmp;
                tmp = rdReg8(nandif->data8);
            }

    }

    return 0;
}

int
nand_read_page (unsigned page, void *data, void *spare)
{
    if (NAND_HW_ECC)
        return nand_read_page_ecc(page, data, spare);
    else
        return nand_read_page_raw(page, data, spare);
}

/********************************************************************/

// Only 12 bytes of spare will be written
int 
nand_write_page_ecc (unsigned page, void *data, void *spare)
{
    int i;

    //printf("Writing page %d with ECC\n", page);

    nand_device->cmd_write_data(0, page);
    if (data)
    {
        uint32 *data32 = data;
        for (i=0; i<2048/4; i++)
        {
            wrReg32(nandif->data32, data32[i]);
        }
    }
    else
    {
        for (i=0; i<2048/4; i++)
        {
            wrReg32(nandif->data32, 0xffffffff);
        }
    }

    if (spare)
    {
        uint32 *spare32 = spare;
        for (i=0; i<12/4; i++)
        {
            wrReg32(nandif->data32, spare32[i]);
        }
    }
    else
    {
        for (i=0; i<12/4; i++)
        {
            wrReg32(nandif->data32, 0xffffffff);
        }
    }

    wrReg8(nandif->cmd, 0x10); /* page write confirm */

    nand_wait();
    wrReg8(nandif->cmd, 0x70); /* read status */

    // Status[0] == 1, write failed
    return (rdReg8(nandif->data8) & 0x01);
}


int
nand_write_page_raw (unsigned page, void *data, void *spare)
{
    /* This routine writes the entire data and/or spare areas */
    int i;

    if (data != NULL)
    {
        nand_device->cmd_write_data(0, page);
        if (nand_device->data_width == 16)
        {
            uint16 *data16 = data;
            for (i = 0; i < nand_device->data_size; i += sizeof(uint16))
            {
                wrReg16(nandif->data16, data16[i/sizeof(uint16)]);
            }
        }
        else
        {
            uint8 *data8 = data;
            for (i = 0; i < nand_device->data_size; i += sizeof(uint8))
            {
                wrReg8(nandif->data8, data8[i/sizeof(uint8)]);
            }
        }
    }

    if (spare != NULL)
    {
        if (data == NULL)
        {
            nand_device->cmd_write_spare(0, page);
        }
        if (nand_device->data_width == 16)
        {
            uint16 *spare16 = spare;
            for (i = 0; i < nand_device->spare_size; i += sizeof(uint16))
            {
                wrReg16(nandif->data16, spare16[i/sizeof(uint16)]);
            }
        }
        else
        {
            uint8 *spare8 = spare;
            for (i = 0; i < nand_device->spare_size; i += sizeof(uint8))
            {
                wrReg8(nandif->data8, spare8[i/sizeof(uint8)]);
            }
        }
    }
    else if ( nand_device->rdwr_requires_spare )
    {
        if (nand_device->data_width == 16)
            for (i = 0; i < nand_device->spare_size; i += sizeof(uint16))
            {
                wrReg16(nandif->data16, 0xFFFF);
            }
        else
            for (i = 0; i < nand_device->spare_size; i += sizeof(uint8))
            {
                wrReg8(nandif->data8, 0xFF);
            }

    }

    wrReg8(nandif->cmd, 0x10); /* page write confirm */

    nand_wait();
    wrReg8(nandif->cmd, 0x70); /* read status */

    // Status[0] == 1, write failed
    return (rdReg8(nandif->data8) & 0x01);
}

int
nand_write_page (unsigned page, void *data, void *spare)
{
    if (NAND_HW_ECC)
        nand_write_page_ecc(page, data, spare);
    else
        nand_write_page_raw(page, data, spare);
}


/********************************************************************/
int
nand_write_spare (unsigned page, void *spare, unsigned offset, unsigned length)
{
    /*
     * This routine is provided since the SPARE area is likely to
     * be written sparsely, that is, not all the spare will be
     * written at once. Case in point, the need to mark a page as
     * bad only need modify a single byte.
     */
    int i;

    if (NAND_HW_ECC)
        nand_disable_ecc();

    if (spare != NULL)
    {
        nand_device->cmd_write_spare(offset, page);
        if (nand_device->data_width == 16)
        {
            uint16 *spare16 = spare;
            for (i = 0; i < length; i += sizeof(uint16))
            {
                wrReg16(nandif->data16, spare16[i/sizeof(uint16)]);
            }
        }
        else
        {
            uint8 *spare8 = spare;
            for (i = 0; i < length; i += sizeof(uint8))
            {
                wrReg8(nandif->data8, spare8[i/sizeof(uint8)]);
            }
        }
    }

    wrReg8(nandif->cmd, 0x10); /* page write confirm */

    nand_wait();

    wrReg8(nandif->cmd, 0x70); /* read status */

    if (NAND_HW_ECC)
        nand_enable_ecc();

    // Status[0] == 1, write failed
    return (rdReg8(nandif->data8) & 0x01);
}

/********************************************************************/
int
nand_erase_block (unsigned block)
{
    unsigned page = block;
    wrReg8(nandif->cmd, 0x60);
    nand_send_page_addr(page);
    wrReg8(nandif->cmd, 0xD0);
    nand_wait();
    wrReg8(nandif->cmd, 0x70); /* read status */
    // Status[0] == 1, write failed
    return (rdReg8(nandif->data8) & 0x01);
    /* FIX!!! Check Write Status Bit - mark every page as BAD ??? */
}

void
nand_erase_pages (unsigned page_start, unsigned len /* in bytes */)
{
    unsigned page_end, roundup, page;
    unsigned block_start, block_end;
    unsigned bpage_start, bpage_end;

    /* Make len an even multiple of data_size */
    roundup = (len % nand_device->data_size);
    len += roundup;

    page_end = page_start + ((len-1) / nand_device->data_size);

    if (VERBOSE)
        printf("Request erase of pages %d to %d\n", page_start, page_end);

    /* Convert start and end pages into block numbers */
    block_start = page_start / nand_device->pages_per_block;
    block_end = page_end / nand_device->pages_per_block;

    /* Convert block numbers into equivalent page number */
    bpage_start = block_start * nand_device->pages_per_block;
    bpage_end = block_end * nand_device->pages_per_block;

    if (VERBOSE)
    {
        printf("Page %d is in block %d (page %d)\n", page_start, block_start, bpage_start);
        printf("Page %d is in block %d (page %d)\n", page_end, block_end, bpage_end);
    }

    bpage_end = (block_end + 1) * nand_device->pages_per_block;
    for (page = bpage_start; page < bpage_end; page += nand_device->pages_per_block)
    {
        if (VERBOSE)
            printf("Erasing block %d (page %d)\n", page / nand_device->pages_per_block, page);
        nand_erase_block(page);
    }
    if (VERBOSE)
        printf("\n");
}

/********************************************************************/
int
nand_page_is_bad (unsigned page)
{
    unsigned bad_offset = nand_device->bad_offset;

    if (NAND_HW_ECC) {
        bad_offset += nand_device->spare_offset_ecc;
        // Can't read the status bits with ECC on
        nand_disable_ecc();
    }

    if ( nand_device->cmd_read_spare(bad_offset, page) )
        nand_wait();

    if (nand_device->data_width == 16)
    {
        uint16 data16;
        data16 = rdReg16(nandif->data16);
        if (NAND_HW_ECC)
            nand_enable_ecc();
        if (data16 != 0xFFFF)
            return TRUE;
    }
    else
    {
        uint8 data8;
        data8 = rdReg8(nandif->data8);
        if (NAND_HW_ECC)
            nand_enable_ecc();
        if (data8 != 0xFF)
            return TRUE;
    }
    return FALSE;
}

/********************************************************************/
void
nand_dump_page (unsigned page, void *data_buffer, void *spare_buffer)
{
    unsigned j;
    uint8 *p;
    unsigned spare_size;
    int status;

    if (NAND_HW_ECC)
        status = nand_read_page_ecc(page, data_buffer, spare_buffer);
    else
        status = nand_read_page(page, data_buffer, spare_buffer);

#define DUMP_DATA
#define DUMP_SPARE
#ifdef DUMP_DATA
    printf("Page %d DATA AREA:\n", page);
    p = (uint8 *)data_buffer;
    for (j = 0; j < nand_device->data_size; ++j)
    {
        if ((j % 16) == 0)
            printf("%04X: ", j);
        printf("%02X ", p[j]);
        if (((j+1) % 16) == 0)
            printf("\n");
    }
#endif
#ifdef DUMP_SPARE
    printf("Page %d SPARE AREA:\n", page);
    p = (uint8 *)spare_buffer;
    spare_size = NAND_HW_ECC ? nand_device->spare_size_ecc : nand_device->spare_size;
    for (j = 0; j < spare_size; ++j)
    {
        if ((j % 16) == 0)
            printf("%04X: ", j);
        printf("%02X ", p[j]);
        if (((j+1) % 16) == 0)
            printf("\n");
    }
#endif
    printf("\n");

    if (status)
        if (status == -1)
            printf("ECC Decode failed!\n");
        else
            printf("ECC Syndrome not zero.  %d bits corrected\n", status);
}


/********************************************************************/
void
lba_init(void)
{
    /*
     * Reboot/reset the device
     */
    wrReg8(nandif->cmd, 0);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, 0xFD);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->cmd, 0x10);
    nand_wait();

    /*
     * Switch to BCM for writing PNP.
     */
    wrReg8(nandif->cmd, 0);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, 0xFC);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->cmd, 0x30);
    nand_wait();
}

/********************************************************************/
void
lba_flush(void)
{
    wrReg8(nandif->cmd, 0);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, 0xF9);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->cmd, 0x30);
    nand_wait();
}

void
lba_send_addr( uint8 page )
{
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, page);
    wrReg8(nandif->addr, 0);
    wrReg8(nandif->addr, 0);
}

/********************************************************************/
int
lba_read_spare(unsigned unused, unsigned page)
{
    int i;

    wrReg8(nandif->cmd, 0);
    lba_send_addr(page);
    wrReg8(nandif->cmd, 0x30);
    nand_wait();

    /* Bit bucket the data -- but it is required since the
       lba device only transfers data+spare bytes.
     */
    for (i=0;i<nand_device->data_size;i++)
        rdReg8(nandif->data8);

    return NOWAIT;
}

/********************************************************************/
void
lba_write_spare(unsigned unused, unsigned page)
{
    int i;
    uint8  data8[4096];
    uint8   spare8[128];

    nand_read_page( page, &data8, &spare8 );

    wrReg8(nandif->cmd, 0x80);
    lba_send_addr(page);

    /* ReWrite our data */
    for (i=0;i<nand_device->data_size;i++)
        wrReg8(nandif->data8, data8[i/sizeof(uint8)]);

}

/********************************************************************/
void
lba_read_data(unsigned unused, unsigned page)
{
    wrReg8(nandif->cmd, 0);
    lba_send_addr(page);
    wrReg8(nandif->cmd, 0x30);
}

/********************************************************************/
void
lba_write_data(unsigned unused, unsigned page)
{
    wrReg8(nandif->cmd, 0x80);
    lba_send_addr(page);
}

/********************************************************************/
void
nand_write_image (unsigned start_page, uint8 *src, unsigned len)
{
    /*
     * This routine takes an image that resides in a linear memory
     * buffer at src, and writes it into consecutive NAND pages while
     * honoring bad NAND pages (skipping and/or marking).
     */
    unsigned page, roundup, rcode;
    uint16 spare = 0;

    /* Make len an even multiple of data_size */
    roundup = (len % nand_device->data_size);
    len += roundup;

    /* NOTE: There are some nice things that *could* be done with regard
    to determining the number of pages needed for src+len, then roudning
    up to end of block boundary (should there be bad blocks), so that
    writing can fail if it does not fit within allowable pages */

    for (page = start_page; (int)len > 0; ++page)
    {
        if (VERBOSE)
            printf("Writing page %d with %08X ... ", page, src);

        /* skip bad pages */
        if (nand_page_is_bad(page) == TRUE)
        {
            if (VERBOSE)
                printf("skipped bad page\n");
            continue;
        }

        do
        {
            rcode = nand_write_page(page, src, NULL);
            if (rcode != 0)
            {
                if (VERBOSE)
                    printf("marking bad page\n");
                nand_write_spare(page, (uint8 *)&spare, nand_device->bad_offset, 1);
                ++page; /* try next page */
            }
            else
            {
                if (VERBOSE)
                    printf("OK\n");
            }

        }
        while (rcode != 0);

        len -= nand_device->data_size;
        src += nand_device->data_size;
    }

    nand_device->flush();

}

/********************************************************************/
void
nand_read_image (unsigned start_page, uint8 *dst, unsigned len)
{
    /*
     * This routine reads consecutive NAND pages (while honoring
     * bad page markers) and stores it into the linear memory
     * buffer at dst.
     */
    unsigned page, roundup;
    int status;

    /* Make len an even multiple of data_size */
    roundup = (len % nand_device->data_size);
    len += roundup;

    for (page = start_page; len != 0; ++page)
    {
        if (VERBOSE)
            printf("Reading page %d with %08X ... ", page, dst);

        /* skip bad pages */
        if (nand_page_is_bad(page) == TRUE)
        {
            if (VERBOSE)
                printf("skipped bad page\n");
            continue;
        }

        status = nand_read_page(page, dst, NULL);

        if (VERBOSE)
            if (status == -1)
                printf("ECC decode failed\n");
            else if (status > 0)
                printf("ECC corrected %d bits\n");
            else
                printf("OK\n");

        len -= nand_device->data_size;
        dst += nand_device->data_size;
    }
}

/********************************************************************/

/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"
#include "pcmcia.h"

/********************************************************************/
/********************************************************************/
/********************************************************************/
/********************************************************************/

void print_sector(int sect, char* buf)
{
    int i, j;
    printf("\n\nSector: %d\n", sect);

    for (i = 0; i < SECTOR_SIZE; i += 16)
    {
        printf("%4X: ", i);
        for (j = 0; j < 16; ++j)
            printf("%2X ", buf[i+j] & 0xFF);

        printf(" ");
        for (j = 0; j < 16; ++j)
        {
            if (buf[i+j] >= 32 && buf[i+j] < 127)
                printf("%c", buf[i+j] & 0xFF);
            else
                printf(".");
        }
        printf("\n");
    }
}

void
dumpCIS2 (uint16 *tuple)
{
    int i, done = FALSE;
    uint8 link;

    do
    {

        if ((*tuple & 0x00FF) == 0xFF)
            link = 0;
        else
            link = *(uint8 *)(tuple + 1);

        for (i = 0; i < (link+2); ++i)
        {
            printf("0x%04X,\n", tuple[i]);
        }

        if ((*tuple & 0x00FF) == 0xFF)
            break;

        tuple += (link + 2);

    }
    while (!done);
}

/********************************************************************/
static void
handleTuple (uint8 *tuple)
{
    uint8 *data;
    uint8 link = tuple[1];
    int i, offset, pwr, tmng, iodesc, irqdesc, miscdesc;

    switch (tuple[0])
    {
        case CISTPL_NULL:
            printf("CISTPL_NULL\n");
            break;
        case CISTPL_DEVICE:
            printf("CISTPL_DEVICE\n");
            data = &tuple[2];
            offset = 0;
            do
            {
                if (offset == 0) /* Device Type */
                {
                    printf("      Device Speed: ");
                    switch (*data & 0x07)
                    {
                        case 0: printf("Null\n"); break;
                        case 1: printf("250ns\n"); break;
                        case 2: printf("200ns\n"); break;
                        case 3: printf("150ns\n"); break;
                        case 4: printf("100ns\n"); break;
                        case 5: printf("Reserved\n"); break;
                        case 6: printf("Reserved\n"); break;
                        case 7: printf("Extended Speed\n"); break;
                    }
                    printf("      Write Protect: ");
                    printf("%s\n", *data & 0x08 ? "yes" : "no");
                    printf("      Device Type: ");
                    switch (*data & 0xF0)
                    {
                        case 0x00: printf("No device\n"); break;
                        case 0x10: printf("Masked ROM\n"); break;
                        case 0x20: printf("OTPROM\n"); break;
                        case 0x30: printf("UV EPROM\n"); break;
                        case 0x40: printf("EEPROM\n"); break;
                        case 0x50: printf("FLASH EPROM\n"); break;
                        case 0x60: printf("SRAM\n"); break;
                        case 0x70: printf("DRAM\n"); break;
                        case 0x80: printf("Reserved\n"); break;
                        case 0x90: printf("Reserved\n"); break;
                        case 0xA0: printf("Reserved\n"); break;
                        case 0xB0: printf("Reserved\n"); break;
                        case 0xC0: printf("Reserved\n"); break;
                        case 0xD0: printf("Function Specific\n"); break;
                        case 0xE0: printf("Extended Type Follows\n"); break;
                        case 0xF0: printf("Reserved\n"); break;
                    }

                    if ((*data & 0x07) == 7)
                    {
                        ++data;
                        printf("Extended Device Speed\n");
                    }
                }
                else

                    if (offset == 1) /* Device Size Speed */
                    {
                        printf("      Device Size Code: ");
                        switch (*data & 0x07)
                        {
                            case 0: printf("0: 512 bytes\n"); break;
                            case 1: printf("1: 2K bytes\n"); break;
                            case 2: printf("2: 8K bytes\n"); break;
                            case 3: printf("3: 32K bytes\n"); break;
                            case 4: printf("4: 128K bytes\n"); break;
                            case 5: printf("5: 512K bytes\n"); break;
                            case 6: printf("6: 2M bytes\n"); break;
                            case 7: printf("7: Reserved \n"); break;
                        }
                        printf("      Num address units: %d\n",
                               (*data & 0xF8) >> 3);
                    }

                ++offset;
                ++data;
            }
            while (*data != 0xFF);
            break;
        case CISTPL_VERS_1:
            printf("CISTPL_VERS_1\n      ");
            data = &tuple[2];
            printf("\"");
            for (i = 2; i < link; ++i)
            {
                if (data[i] != 0xFF)
                {
                    if (data[i] == 0)
                    {
                        printf("\" ");
                        if (data[i + 1] != 0xFF)
                            printf("\"");
                    }
                    else
                        printf("%c", data[i]);
                }
            }
            printf("\n");
            break;
        case CISTPL_MANFID:
            printf("CISTPL_MANFID\n");
            data = &tuple[2];
            printf("      ");
            printf("PCMCIA MANF: %02X %02X\n", *data, *(data + 1));
            printf("      ");
            data += 2;
            printf("PCMCIA CARD: %02X %02X\n", *data, *(data + 1));
            break;

        case CISTPL_FUNCID:
            printf("CISTPL_FUNCID\n");
            switch (tuple[2])
            {
#define FUNC(F) case CISTPL_FUNCID_##F: printf("      " #F "\n"); break;
                    FUNC(MULTIFUNC)
                    FUNC(MEMORY)
                    FUNC(SERIAL)
                    FUNC(PARALLEL)
                    FUNC(FIXEDISK)
                    FUNC(VIDEO)
                    FUNC(LAN)
                    FUNC(AIMS)
                    FUNC(SCSI)
                    FUNC(CARDBUS)
                    FUNC(INSTRUMENT)
                    FUNC(SERIALIO)
                    FUNC(VENDOR)
                default: printf("      Unknown device!!!!\n"); break;
            }
            printf("      ");
            printf("POST: %s\n", tuple[3] & 0x01 ? "yes" : "no");
            printf("      ");
            printf("ROM: %s\n", tuple[3] & 0x02 ? "yes" : "no");
            break;

        case CISTPL_CONFIG:
            {
                int radr, rmsk;
                printf("CISTPL_CONFIG\n");
                data = &tuple[2];
                printf("      ");
                printf("TPCC_RADR: %d\n", radr = (*data & 0x3));
                printf("      ");
                printf("TPCC_RMSK: %d\n", rmsk = ((*data & 0x3C) >> 2));
                ++data;
                printf("      ");
                printf("TPCC_LAST: %02X\n", *data);
                ++data;
                printf("      ");
                printf("TPCC_RADR: ");
                for (i = 0; i < radr+1; ++i)
                {
                    printf("%02X ", *data);
                    ++data;
                }
                printf("\n");
                printf("      ");
                printf("TPCC_RMSK: ");
                for (i = 0; i < rmsk+1; ++i)
                {
                    printf("%02X ", *data);
                    ++data;
                }
                printf("\n");
            }
            break;

        case CISTPL_CFTABLE_ENTRY:
            printf("CISTPL_CFTABLE_ENTRY\n");
            data = &tuple[2];
            printf("      ");
            printf("COR: %02X\n", *data & 0x3F);
            printf("      ");
            printf("Defaults: %s\n", *data & 0x40 ? "yes" : "no");
            printf("      ");
            printf("If Cfg Byte: %s\n", *data & 0x80 ? "yes" : "no");
            if (*data & 0x80)
            {
                ++data;
                printf("      ");
                printf("Interface Type: ");
                switch (*data & 0x0F)
                {
                    case 0: printf("Memory\n"); break;
                    case 1: printf("I/O\n"); break;
                    case 2:
                    case 3: printf("Reserved\n"); break;
                    case 4:
                    case 5:
                    case 6:
                    case 7: printf("Custom\n"); break;
                    case 8:
                    case 9:
                    case 10:
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                    case 15: printf("Reserved\n"); break;
                }
                printf("      ");
                printf("BVD1/BVD2: %s\n", *data & 0x10 ? "yes" : "no");
                printf("      ");
                printf("Card WP: %s\n", *data & 0x20 ? "yes" : "no");
                printf("      ");
                printf("READY: %s\n", *data & 0x40 ? "yes" : "no");
                printf("      ");
                printf("WAIT: %s\n", *data & 0x80 ? "yes" : "no");
            }
            ++data;
            printf("      ");
            pwr = *data & 0x03;
            switch (pwr)
            {
                case 0: printf("No power description\n"); break;
                case 1: printf("Vcc power description\n"); break;
                case 2: printf("Vcc and Vpp power description\n"); break;
                case 3: printf("Vcc Vpp1 Vpp2 power description\n"); break;
            }
            tmng = *data & 0x04;
            printf("      ");
            printf("Timing description: %s\n", tmng ? "yes" : "no");
            iodesc = *data & 0x08;
            printf("      ");
            printf("I/O description: %s\n", iodesc ? "yes" : "no");
            printf("      ");
            irqdesc = *data & 0x10;
            printf("IRQ description: %s\n", irqdesc ? "yes" : "no");
            printf("      ");
            printf("Memory Space: %d\n", (*data & 0x60) >> 5);
            printf("      ");
            miscdesc = (*data & 0x80) >> 7;
            printf("Misc field: %d\n", miscdesc);
            ++data;
            if (pwr != 0)
            {
                printf("      ");
                printf("TPCE_PD:\n");
#define SIDENT "        "
                if (*data & 0x01) printf(SIDENT "Nominal supply\n");
                if (*data & 0x02) printf(SIDENT "Minimum supply\n");
                if (*data & 0x04) printf(SIDENT "Maximum supply\n");
                if (*data & 0x08) printf(SIDENT "Continuous supply\n");
                if (*data & 0x10) printf(SIDENT "Max current 1s\n");
                if (*data & 0x20) printf(SIDENT "Max current 10ms\n");
                if (*data & 0x40) printf(SIDENT "Power down supply\n");
                if (*data & 0x80) printf(SIDENT "Reserved\n");

                ++data;
                switch (*data & 0x07)
                {
                    case 0: printf(SIDENT "100nA, 10uV\n"); break;
                    case 1: printf(SIDENT "1uA, 100uV\n"); break;
                    case 2: printf(SIDENT "10uA, 1mV\n"); break;
                    case 3: printf(SIDENT "100uA, 10mV\n"); break;
                    case 4: printf(SIDENT "1mA, 100mV\n"); break;
                    case 5: printf(SIDENT "10mA, 1V\n"); break;
                    case 6: printf(SIDENT "100mA, 10V\n"); break;
                    case 7: printf(SIDENT "1A, 100V\n"); break;
                }
                printf(SIDENT "Mantissa: %d\n", (*data & 0x78) >> 3);
                printf(SIDENT "Extension: %s\n", *data & 0x80 ? "yes" : "no");
                if (*data & 0x80)
                {
                    ++data;
                    printf("      ");
                    printf("Extension: %02X\n", *data);
                }
                ++data;
            }
            if (tmng != 0)
            {
                printf("      ");
                printf("Wait Scale: %d\n", (*data & 0x03) >> 0);
                printf("READY Scale: %d\n", (*data & 0x1C) >> 2);
                printf("Reserved: %02X\n", *data & 0xE0);
                ++data;
            }

            if (iodesc != 0)
            {
                int ranges, addrsz, lensz;
                printf("      ");
                printf("Decode addr lines: %d\n", *data & 0x1F);
                printf("      ");
                printf("16bit IO: %s\n", *data & 0x40 ? "yes" : "no");
                printf("      ");
                printf("8bit IO: %s\n", *data & 0x20 ? "yes" : "no");
                printf("      ");
                printf("Ranges: %s\n", *data & 0x80 ? "yes" : "no");
                if (*data & 0x80)
                {
                    ++data;
                    ranges = *data & 0x0F;
                    addrsz = (*data & 0x30) >> 4;
                    lensz = (*data & 0xC0) >> 6;
                    printf(SIDENT "Ranges: %d\n", ranges);
                    printf(SIDENT "Addr Sz: %d\n", addrsz);
                    printf(SIDENT "Len Sz: %d\n", lensz);
                    ++data;
                    for (i = 0; i < ranges; ++i)
                    {
                        int j;
                        printf(SIDENT "Range %d: ", i);
                        printf("Address: ");
                        for (j = 0; j < addrsz; ++j)
                        {
                            printf("%02X ", *data++);
                        }
                        printf("Block Len: ");
                        for (j = 0; j < lensz; ++j)
                        {
                            printf("%02X ", *data++);
                        }
                        printf("\n");
                    }
                }
                else
                    ++data;
            }

            if (irqdesc)
            {
                printf("      ");
                printf("MASK: %d\n", *data & 0x10 ? 1 : 0);
                printf("      ");
                printf("Level: %d\n", *data & 0x20 ? 1: 0);
                printf("      ");
                printf("Pulse: %d\n", *data & 0x40 ? 1 : 0);
                printf("      ");
                printf("Share: %d\n", *data & 0x80 ? 1: 0);
                if (*data & 0x10) /* MASK */
                {
                    printf(SIDENT "NMI: %d\n", *data & 0x01 ? 1 : 0);
                    printf(SIDENT "IOCK: %d\n", *data & 0x02 ? 1 : 0);
                    printf(SIDENT "BERR: %d\n", *data & 0x04 ? 1 : 0);
                    printf(SIDENT "VEND: %d\n", *data & 0x08 ? 1 : 0);
                    ++data;
                    printf(SIDENT "IRQ0: %d\n", *data & 0x01 ? 1 : 0);
                    printf(SIDENT "IRQ1: %d\n", *data & 0x02 ? 1 : 0);
                    printf(SIDENT "IRQ2: %d\n", *data & 0x04 ? 1 : 0);
                    printf(SIDENT "IRQ3: %d\n", *data & 0x08 ? 1 : 0);
                    printf(SIDENT "IRQ4: %d\n", *data & 0x10 ? 1 : 0);
                    printf(SIDENT "IRQ5: %d\n", *data & 0x20 ? 1 : 0);
                    printf(SIDENT "IRQ6: %d\n", *data & 0x40 ? 1 : 0);
                    printf(SIDENT "IRQ7: %d\n", *data & 0x80 ? 1 : 0);
                    ++data;
                    printf(SIDENT "IRQ8: %d\n", *data & 0x01 ? 1 : 0);
                    printf(SIDENT "IRQ9: %d\n", *data & 0x02 ? 1 : 0);
                    printf(SIDENT "IRQ10: %d\n", *data & 0x04 ? 1 : 0);
                    printf(SIDENT "IRQ11: %d\n", *data & 0x08 ? 1 : 0);
                    printf(SIDENT "IRQ12: %d\n", *data & 0x10 ? 1 : 0);
                    printf(SIDENT "IRQ13: %d\n", *data & 0x20 ? 1 : 0);
                    printf(SIDENT "IRQ14: %d\n", *data & 0x40 ? 1 : 0);
                    printf(SIDENT "IRQ15: %d\n", *data & 0x80 ? 1 : 0);
                }
                else
                {
                    printf(SIDENT "IRQ: %d\n", *data & 0x0F);
                }
                ++data;
            }

            if (miscdesc)
            {
                printf(SIDENT "Max twin: %d\n", *data & 0x07);
                printf(SIDENT "BVD2 audio: %d\n", *data & 0x08 ? 1 : 0);
                printf(SIDENT "Read only: %d\n", *data & 0x10 ? 1 : 0);
                printf(SIDENT "Power Down: %d\n", *data & 0x20 ? 1 : 0);
                printf(SIDENT "Reserved: %d\n", *data & 0x40 ? 1 : 0);
                printf(SIDENT "Extension Byte: %d\n", *data & 0x80 ? 1 : 0);
                if (*data & 0x80)
                {
                    ++data;
                    switch (*data & 0x0C)
                    {
                        case (0<<2): printf(SIDENT "No DMA\n"); break;
                        case (1<<2): printf(SIDENT "SPKR#\n"); break;
                        case (2<<2): printf(SIDENT "IOIS16#\n"); break;
                        case (3<<2): printf(SIDENT "INPACK#\n"); break;
                    }
                    printf(SIDENT "DMA width %d\n", *data & 0x10 ? 16 : 8);
                }
            }

            break;

        case CISTPL_DEVICE_OC:
            printf("CISTPL_DEVICE_OC\n");
            data = &tuple[2];
            printf("      ");
            printf("Monitor MWAIT: %s\n", *data & 0x01 ? "yes" : "no");
            printf("      Vcc & Wait bits: ");
            switch (*data & 0x06)
            {
                case (0<<1): printf("5V Vcc\n"); break;
                case (1<<1): printf("3.3V Vcc\n"); break;
                case (2<<1): printf("Reserved for x.xV Vcc\n"); break;
                case (3<<1): printf("Reserved for y.yV Vcc\n"); break;
            }
            break;

        case CISTPL_JEDEC_C:
            printf("CISTPL_JEDEC_C\n");
            data = &tuple[2];
            printf("      ");
            printf("Manfid: %02X\n", *data);
            ++data;
            printf("      ");
            printf("Devid: %02X\n", *data);
            /* FIX!!! check for optionals */
            break;

        case 0xFF:
            printf("END OF CIS!!!\n\n\n\n");
            break;
        default:
            printf("??\n");
    }
    printf("      ");

    /* point to data following the Tuple/Link header */
    if (tuple[0] != 0xFF)
    {
        data = &tuple[2];
        for (i = 0; i < link; ++i)
        {
            printf("%02X ", data[i]);
        }
    }

    printf("\n");
}

/********************************************************************/
static uint8 tuplebytes[256];

void dumpCIS (volatile uint16 *tuple)
{
    /* NOTE: The volatile qualifier is necessary on gcc3.0.4 since it will
     * optimize the conversion of a 16-bit tuple pair to an 8-bit byte by
     * changing 16-bit accesses into [what it thinks is] the appropriate
     * 8-bit access, which wreaks havoc with big endian */
    uint8 data;
    uint8 link;
    int i, done = FALSE;

#if CIS_DEBUG
    for (i = 0; i < 256; ++i)
    {
        if ((i % 16) == 0)
            printf("\n%04X: ", i);
        data = (*((volatile uint8 *)&tuple[i]) & 0x00FF);
        printf("%02X ", data);
    }
    printf("\n");
    return;
#endif

    /* NOTE: There is no need to byte or address swap when doing
     * big-endian vs little-endian. The reason being the interaction
     * of the static bus controller and the SBUS, and the fact that
     * on reads the static bus controller replicates the reads across
     * the sbus word (which makes it correct for both endians), and
     * on writes it pulls the data from the sbus which was correctly
     * placed there by the processor (of either endian mode). So it
     * just works for both endian modes! */
    do
    {
        data = *(volatile uint8 *)tuple;
        link = *(volatile uint8 *)(tuple + 1);

        for (i = 0; i < link + 2; ++i)
            tuplebytes[i] = (*((volatile uint8 *)&tuple[i]) & 0x00FF);

        printf("%04X: Tuple %02X, link %02X ", ((uint32)tuple & 0x0000FFFF), data, link);
        handleTuple(tuplebytes);

        if (data == 0xFF)
            done = TRUE;

        tuple += (link + 2);

    }
    while (!done);

    printf("\n");
}

void pcmcia_dump_info(int socket)
{
    volatile uint16 *p;
    if ((p = pcmciaMapWindow(socket, PCMCIA_WINDOW_ATTR, 0)))
    {
        volatile uint8 *b;
        volatile uint16 junk;
        /* do access to force TLB update */
        junk = (volatile)*p;
        DPRINTF("Socket %d Attribute: %08X\n", socket, p);

        DPRINTF("Dumping CIS:\n");
        dumpCIS(p);
        DPRINTF("COR:  %02X\n", *(((volatile uint8 *)p) + 0x200));
        DPRINTF("FCSR: %02X\n", *(((volatile uint8 *)p) + 0x202));
        DPRINTF("PRR:  %02X\n", *(((volatile uint8 *)p) + 0x204));
        DPRINTF("SCR:  %02X\n", *(((volatile uint8 *)p) + 0x206));
        DPRINTF("ESR:  %02X\n", *(((volatile uint8 *)p) + 0x208));
        DPRINTF("IOB0: %02X\n", *(((volatile uint8 *)p) + 0x20a));
        DPRINTF("IOB1: %02X\n", *(((volatile uint8 *)p) + 0x20c));
        DPRINTF("IOB2: %02X\n", *(((volatile uint8 *)p) + 0x20e));
        DPRINTF("IOB3: %02X\n", *(((volatile uint8 *)p) + 0x210));
        DPRINTF("IOSR: %02X\n", *(((volatile uint8 *)p) + 0x212));
        DPRINTF("\n\n");
        //unmapWindow(socket, PCMCIA_WINDOW_ATTR, 0);
    }
}

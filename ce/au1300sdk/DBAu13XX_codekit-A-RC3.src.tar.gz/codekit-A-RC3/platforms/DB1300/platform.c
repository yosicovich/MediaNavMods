/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#include "example.h"

/********************************************************************/
//                       Boot Image Locations                       //
static const char* const flashAddresses[] =
    { "BE000000",
      "Nand|7D0",  //Nand flash, block 2000
      0
    };

static const char* const fileNames[] =
{
	"_update_.inf",
	"eboot.bin",
    "nk.bin",
    "vmlinuz.elf",
    "vmlinux.srec",
    "vmlinux.rec",
    0
};

static const void* const jumpAddress = 0x0;
/********************************************************************/

void
platformInit (void)
{
    DPRINTF("Db1300 platformInit() \n");
}

/********************************************************************/

void
au1_sleep (void)
{
}

/********************************************************************/

int
platformGetBootData(const
                    char*const
                    ** files, const
                    char*const
                    ** addresses, const
                    void** jump )
{
    *files  = fileNames;
    *addresses = flashAddresses;
    *jump  = jumpAddress;
    return 1;
}


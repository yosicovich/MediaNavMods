/*****************************************************************************
Copyright 2003-2009 RMI Corporation. All rights reserved.

Any transfer or redistribution of the source code, with or without modification,
IS PROHIBITED, unless prior written consent was obtained. Any transfer or
redistribution of the binary code for use on the RMI Alchemy Family,
with or without modification, is permitted, provided that the following
condition is met:

Redistributions in binary form must reproduce the above copyright notice,

this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution:

THIS SOFTWARE IS PROVIDED BY RMI Corporation 'AS IS' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL RMI OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

#ifndef DB1300
#define DB1300
#endif

#define AU1300
#define AU13XX
#define SOC_AU13XX

#define CONSOLE 2

/*
 * Frequency info
 */
#define CPU_FREQUENCY   (12000000 * 33)
#define CPU_SD      2


#define DBDMA_AC97_TX_CHAN DSCR_CMD0_PSC1_TX
#define DBDMA_AC97_RX_CHAN DSCR_CMD0_PSC1_RX
/* SPI and SMB are muxed on the Db1200 board.
   Refer to board documentation.
 */
#define SPI_PSC_BASE        PSC0_PHYS_ADDR
#define SMBUS_PSC_BASE      PSC0_PHYS_ADDR
/* AC97 and I2S are muxed on the Db1200 board.
   Refer to board documentation.
 */
#define AC97_PSC_BASE       PSC1_PHYS_ADDR
#define I2S_PSC_BASE        PSC1_PHYS_ADDR

#define BCSR_PHYS_ADDR 0x19800000

#ifndef ASSEMBLER
typedef volatile struct
{
    /*00*/
    u16 whoami;
    u16 reserved0;
    /*04*/
    u16 status;
    u16 reserved1;
    /*08*/
    u16 switches;
    u16 reserved2;
    /*0C*/
    u16 resets;
    u16 reserved3;

    /*10*/
    u16 pcmcia;
    u16 reserved4;
    /*14*/
    u16 board;
    u16 reserved5;
    /*18*/
    u16 disk_leds;
    u16 reserved6;
    /*1C*/
    u16 system_control;
    u16 reserved7;

    /*20*/
    u16 intclr;
    u16 reserved8;
    /*24*/
    u16 intset;
    u16 reserved9;
    /*28*/
    u16 intclr_mask;
    u16 reserved10;
    /*2C*/
    u16 intset_mask;
    u16 reserved11;

    /*30*/
    u16 sig_status;
    u16 reserved12;
    /*34*/
    u16 int_status;
    u16 reserved13;
    /*38*/
    u16 reserved14;
    u16 reserved15;
    /*3C*/
    u16 reserved16;
    u16 reserved17;

}
BCSR;
static BCSR* bcsr = (BCSR*) KSEG1(BCSR_PHYS_ADDR);
#endif


/*
 * Register bit definitions for the BCSRs
 */
#define BCSR_WHOAMI_DCID	0x000F
#define BCSR_WHOAMI_CPLD	0x00F0
#define BCSR_WHOAMI_BOARD	0x0F00

#define BCSR_STATUS_DCDMAREQ 	0x0010
#define BCSR_STATUS_IDEDMAREQ	0x0020
#define BCSR_STATUS_SWAPBOOT	0x0040
#define BCSR_STATUS_FLASHBUSY	0x0100
#define BCSR_STATUS_IDECBLID	0x0200
// Poorly named bitfield
#define BCSR_STATUS_SD0WP		0x0400
#define BCSR_STATUS_SD1WP		BCSR_STATUS_SD0WP
#define BCSR_STATUS_INPACK		0x0800
#define BCSR_STATUS_OTG_OC		0x1000
#define BCSR_STATUS_USBHOST_OC	0x2000
#define BCSR_STATUS_PCWP		0x4000

#define BCSR_SWITCHES_OCTAL		0x00FF
#define BCSR_SWITCHES_DIP_1		0x0080
#define BCSR_SWITCHES_DIP_2		0x0040
#define BCSR_SWITCHES_DIP_3		0x0020
#define BCSR_SWITCHES_DIP_4		0x0010
#define BCSR_SWITCHES_DIP_5		0x0008
#define BCSR_SWITCHES_DIP_6		0x0004
#define BCSR_SWITCHES_DIP_7		0x0002
#define BCSR_SWITCHES_DIP_8		0x0001
#define BCSR_SWITCHES_ROTARY	0x0F00

#define BCSR_RESETS_ETHERNET	0x0001
#define BCSR_RESETS_CAMERA		0x0002
#define BCSR_RESETS_DC			0x0004
#define BCSR_RESETS_IDE			0x0008
#define BCSR_RESETS_TV			0x0010
#define BCSR_RESETS_VDDQ_SHDN	0x0200
#define BCSR_RESETS_OTP_PGM		0x0400
#define BCSR_RESETS_OTP_SCLK	0x0800
#define BCSR_RESETS_OTP_WPROT	0x1000
#define BCSR_RESETS_OTP_CSB		0x2000
#define BCSR_RESETS_OTG_PWR		0x4000
#define BCSR_RESETS_USBHOST_PWR 0x8000

#define BCSR_PCMCIA_PC0DRVEN	0x1000
#define BCSR_PCMCIA_PC0RST		0x8000

#define BCSR_SPECIFIC_LCDVEEOFF	0x0001
#define BCSR_SPECIFIC_LCDVDDOFF	0x0002
#define BCSR_SPECIFIC_LCDBLOFF	0x0004
#define BCSR_SPECIFIC_ETH_FIFO  0x0008
#define BCSR_SPECIFIC_CAM_CS	0x0010
#define BCSR_SPECIFIC_CAMPWRDOWN 0x0020

#define BCSR_LEDS_DECIMALS		0x0003
#define BCSR_LEDS_LED0			0x0100
#define BCSR_LEDS_LED1			0x0200
#define BCSR_LEDS_LED2			0x0400
#define BCSR_LEDS_LED3			0x0800

#define BCSR_SYSTEM_POWEROFF	0x4000
#define BCSR_SYSTEM_RESET		0x8000

/* Board Interrupt Controller Registers */
#define BCSR_BIC_IDE			0x0001
#define BCSR_BIC_ETH			0x0002
#define BCSR_BIC_CF				0x0004
#define BCSR_BIC_PC0			BCSR_BIC_CF
#define BCSR_BIC_PC1			0
#define BCSR_BIC_VIDEO			0x0010
#define BCSR_BIC_HDMI			0x0020
#define BCSR_BIC_DC				0x0040
#define BCSR_BIC_FLASH			0x0080
#define BCSR_BIC_PC0INSERT		0x0100
#define BCSR_BIC_PC0EJECT		0x0200
#define BCSR_BIC_AC97			0x0400
#define BCSR_BIC_AC97PEN		0x0800
// Poorly named. Actually SD1
#define BCSR_BIC_SD0INSERT		0x1000
#define BCSR_BIC_SD0EJECT		0x2000
#define BCSR_BIC_SD1INSERT		BCSR_BIC_SD0INSERT
#define BCSR_BIC_SD1EJECT		BCSR_BIC_SD0EJECT

#define AU1X00_EXTERNAL_INT     AU1000_GPIO_5

/* SMSC LAN91C111 */
#define AU1XXX_SMC91111_BASE        (0xA9000000)
#define AU1XXX_SMC91111_END     (0xA97FFFFF)
#define AU1XXX_SMC91111_MEM_SIZE    (AU1XXX_SMC91111_END - AU1XXX_SMC91111_BASE + 1)
// shared IRQs
#define AU1XXX_SMC91111_IRQ     AU1X00_EXTERNAL_INT

/* DC_IDE and DC_ETHERNET */
#define AU1XXX_ATA_BASE         (0xA8800000)
#define AU1XXX_ATA_END          (0xA8FFFFFF)
#define AU1XXX_ATA_MEM_SIZE     (AU1XXX_ATA_END - AU1XXX_ATA_BASE +1)

#define AU1XXX_ATA_REG_OFFSET       (5)
#define AU1XXX_SMC91111_OFFSET      (0x300)

#define IDE_PHYS_ADDR           0x18800000

//#define NAND_PHYS_ADDR   0x1C000000

#define PCMCIA_MAX_SOCK         1
#define PCMCIA_NUM_SOCKS        (PCMCIA_MAX_SOCK+1)

#define SD_MAX_SLOT         0
#define SD_NUM_SLOTS            (SD_MAX_SLOT+1)

#define PCMCIA_PC_IRQ           7
#define PCMCIA_PC0_IRQ          PCMCIA_PC_IRQ
#define PCMCIA_PC1_IRQ          PCMCIA_PC_IRQ
#define PCMCIA_CARD_COUNT       2


#define FLASH_AMD_MIRRORBIT
#define FLASH_START_PHYS_ADDRESS    0x1E000000
#define FLASH_END_PHYS_ADDRESS      0x1FFFFFFF
#define FLASH_BLOCK_SIZE        0x00020000
#define FLASH_ALTERNATE_ADDR        0xBDC00000

#define NAND_FORCE_CE_GPIO      215

